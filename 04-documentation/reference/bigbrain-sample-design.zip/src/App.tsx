/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import Sidebar from "./components/Sidebar";
import DashboardHome from "./components/DashboardHome";
import BrandDNA from "./components/BrandDNA";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Bell, 
  User, 
  HelpCircle,
  Search,
  Command
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";

export default function App() {
  const [activeTab, setActiveTab] = useState("home");

  return (
    <TooltipProvider>
      <div className="flex h-screen bg-background overflow-hidden">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
        
        <main className="flex-1 flex flex-col min-w-0 relative">
          {/* Top Header */}
          <header className="h-16 border-b border-border/50 bg-background/80 backdrop-blur-md flex items-center justify-between px-8 sticky top-0 z-10">
            <div className="flex items-center gap-4 flex-1">
              <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-muted rounded-full text-muted-foreground text-xs font-medium border border-border/50">
                <Command className="w-3 h-3" />
                <span>K</span>
                <span className="mx-1 text-muted-foreground/30">|</span>
                <span>Search everything...</span>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" className="text-muted-foreground">
                <HelpCircle className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-muted-foreground relative">
                <Bell className="w-5 h-5" />
                <span className="absolute top-2 right-2 w-2 h-2 bg-primary rounded-full border-2 border-white" />
              </Button>
              <div className="h-8 w-px bg-border mx-2" />
              <Button variant="ghost" className="gap-2 px-2">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs">
                  EP
                </div>
                <span className="text-sm font-medium hidden sm:inline-block">Ellie P.</span>
              </Button>
            </div>
          </header>

          {/* Content Area */}
          <ScrollArea className="flex-1">
            <div className="max-w-7xl mx-auto p-8 lg:p-12">
              {activeTab === "home" && <DashboardHome />}
              {activeTab === "dna" && <BrandDNA />}
              {activeTab !== "home" && activeTab !== "dna" && (
                <div className="flex flex-col items-center justify-center h-[60vh] text-center">
                  <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mb-4">
                    <Search className="w-8 h-8 text-muted-foreground/40" />
                  </div>
                  <h3 className="text-xl font-display font-semibold">Section Under Construction</h3>
                  <p className="text-muted-foreground mt-2 max-w-sm">
                    The {activeTab} module is currently being synthesized. Check back soon.
                  </p>
                  <Button variant="outline" className="mt-6" onClick={() => setActiveTab("home")}>
                    Return to Dashboard
                  </Button>
                </div>
              )}
            </div>
          </ScrollArea>

          {/* Right Context Pane (Optional/Hidden on small screens) */}
          <div className="hidden xl:block w-80 border-l border-border/50 bg-background p-6 overflow-y-auto">
            <h4 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-6">Contextual Intelligence</h4>
            
            <div className="space-y-6">
              <div className="space-y-3">
                <h5 className="text-sm font-semibold">Active Project</h5>
                <div className="p-3 rounded-lg bg-muted/30 border border-border/50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium">Robotics Policy Paper</span>
                    <Badge className="text-[9px] h-4">High Priority</Badge>
                  </div>
                  <div className="w-full bg-muted h-1 rounded-full overflow-hidden">
                    <div className="bg-primary h-full w-2/3" />
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-2">65% complete • Due in 3 days</p>
                </div>
              </div>

              <div className="space-y-3">
                <h5 className="text-sm font-semibold">Related Knowledge</h5>
                <ul className="space-y-2">
                  {['EU AI Act Summary', 'Boston Dynamics Interview', 'Ethics in Autonomy'].map((item) => (
                    <li key={item} className="flex items-center gap-2 text-xs text-muted-foreground hover:text-primary cursor-pointer transition-colors">
                      <div className="w-1 h-1 rounded-full bg-primary/40" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-6 border-t border-border/50">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">System Status</span>
                </div>
                <p className="text-[11px] text-muted-foreground leading-relaxed">
                  Vector engine indexed 14 new documents. Semantic graph updated.
                </p>
              </div>
            </div>
          </div>
        </main>
      </div>
    </TooltipProvider>
  );
}

