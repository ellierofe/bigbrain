import { 
  Target, 
  Compass, 
  Heart, 
  Volume2, 
  Users, 
  Package, 
  Columns, 
  Workflow,
  Edit3,
  Save,
  Info
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { motion } from "motion/react";

const dnaElements = [
  { 
    id: "vision", 
    label: "Vision", 
    icon: Target, 
    content: "To become the leading strategic partner for deep-tech founders navigating complex regulatory and market landscapes.",
    desc: "Your long-term aspiration and the 'why' behind your work."
  },
  { 
    id: "mission", 
    label: "Mission", 
    icon: Compass, 
    content: "Synthesizing complex information into actionable strategy for the robotics, defence, and energy sectors.",
    desc: "What you do every day to achieve your vision."
  },
  { 
    id: "values", 
    label: "Values", 
    icon: Heart, 
    content: "Intellectual Rigor, Radical Clarity, Future-Focused, Human-Centric Technology.",
    desc: "The core principles that guide your decisions."
  },
  { 
    id: "tone", 
    label: "Tone of Voice", 
    icon: Volume2, 
    content: "Authoritative yet accessible. Sophisticated but devoid of jargon. Calm, precise, and visionary.",
    desc: "How you sound to your audience."
  },
  { 
    id: "audience", 
    label: "Audience Segments", 
    icon: Users, 
    content: "Deep-tech founders, Venture Capitalists in hardware, Government policy makers in innovation.",
    desc: "Who you are speaking to."
  },
  { 
    id: "pillars", 
    label: "Content Pillars", 
    icon: Columns, 
    content: "The Future of Autonomy, Defence Sovereignty, Energy Transition Strategy, The ADHD Advantage in Consulting.",
    desc: "The core themes you consistently create content around."
  }
];

export default function BrandDNA() {
  return (
    <div className="space-y-8">
      <header className="flex items-end justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Badge variant="outline" className="text-[10px] uppercase tracking-widest text-primary border-primary/30 bg-primary/5">Strategic Core</Badge>
          </div>
          <h2 className="text-3xl font-display font-bold text-foreground">Brand DNA</h2>
          <p className="text-muted-foreground mt-1">Your single source of truth for strategy and communication.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2">
            <Edit3 className="w-4 h-4" />
            Edit Mode
          </Button>
          <Button className="gap-2">
            <Save className="w-4 h-4" />
            Save Changes
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {dnaElements.map((element, i) => (
          <motion.div
            key={element.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.05 }}
          >
            <Card className="h-full bg-white border-border/50 shadow-sm hover:shadow-md transition-all group">
              <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center text-muted-foreground group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                    <element.icon className="w-4 h-4" />
                  </div>
                  <CardTitle className="text-base font-semibold">{element.label}</CardTitle>
                </div>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground/40 hover:text-muted-foreground">
                        <Info className="w-4 h-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="top" className="max-w-[200px] text-xs">
                      {element.desc}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </CardHeader>
              <CardContent>
                <Textarea 
                  defaultValue={element.content}
                  className="min-h-[100px] bg-muted/30 border-none resize-none focus-visible:ring-1 focus-visible:ring-primary/20 text-sm leading-relaxed"
                />
              </CardContent>
            </Card>
          </motion.div>
        ))}

        {/* Specialized Sections */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="md:col-span-2 lg:col-span-3"
        >
          <Card className="bg-white border-border/50 shadow-sm">
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center text-muted-foreground">
                  <Workflow className="w-4 h-4" />
                </div>
                <div>
                  <CardTitle className="text-base font-semibold">Methodologies</CardTitle>
                  <CardDescription>Your proprietary frameworks and processes.</CardDescription>
                </div>
              </div>
              <Button variant="outline" size="sm">Add Framework</Button>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl border border-border/50 bg-muted/10">
                  <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-primary" />
                    The Synthesis Loop
                  </h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    A 3-step process for turning raw technical data into market-ready strategy: Capture, Connect, Communicate.
                  </p>
                </div>
                <div className="p-4 rounded-xl border border-border/50 bg-muted/10">
                  <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-green-500" />
                    ADHD-Optimized Workflow
                  </h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    Leveraging hyperfocus for deep research while using BigBrain to manage the "executive function" of organization.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
