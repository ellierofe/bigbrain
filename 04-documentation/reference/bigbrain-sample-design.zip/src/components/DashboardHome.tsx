import { 
  ArrowUpRight, 
  Clock, 
  FileText, 
  Mic, 
  Plus, 
  Sparkles, 
  Zap,
  ChevronRight,
  MoreHorizontal,
  Inbox,
  Network
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { motion } from "motion/react";

const inputQueue = [
  { id: 1, type: "Transcript", title: "Client Call: Robotics Strategy", date: "2h ago", status: "Processing" },
  { id: 2, type: "Voice Note", title: "Idea: Energy Sector Content Pillar", date: "5h ago", status: "Ready" },
  { id: 3, type: "PDF", title: "Research: Defence Tech Trends 2025", date: "Yesterday", status: "Ready" },
];

const connectionSuggestions = [
  { id: 1, title: "Link 'Robotics' to 'Defence'", desc: "Semantic overlap detected in methodology sections." },
  { id: 2, title: "New Content Pillar?", desc: "High density of notes around 'AI Governance'." },
];

export default function DashboardHome() {
  return (
    <div className="space-y-8">
      <header className="flex items-end justify-between">
        <div>
          <h2 className="text-3xl font-display font-bold text-foreground">Welcome back, Ellie</h2>
          <p className="text-muted-foreground mt-1">Your second brain has synthesized 4 new insights today.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2">
            <Plus className="w-4 h-4" />
            Quick Capture
          </Button>
          <Button className="gap-2">
            <Zap className="w-4 h-4" />
            Generate Strategy
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Stats / Overview */}
        <Card className="bg-white border-border/50 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Knowledge Nodes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-display font-bold">1,284</div>
            <p className="text-xs text-primary mt-1 flex items-center gap-1">
              <ArrowUpRight className="w-3 h-3" /> +12 this week
            </p>
          </CardContent>
        </Card>
        <Card className="bg-white border-border/50 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Content Pieces</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-display font-bold">42</div>
            <p className="text-xs text-muted-foreground mt-1">8 in draft, 34 published</p>
          </CardContent>
        </Card>
        <Card className="bg-white border-border/50 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Input Queue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-display font-bold">7</div>
            <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
              <Clock className="w-3 h-3" /> 3 need review
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input Queue */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-display font-semibold flex items-center gap-2">
              <Inbox className="w-5 h-5 text-primary" />
              Recent Inputs
            </h3>
            <Button variant="ghost" size="sm" className="text-primary">View all</Button>
          </div>
          <div className="space-y-3">
            {inputQueue.map((item, i) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className="hover:border-primary/30 transition-colors cursor-pointer group">
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center text-muted-foreground group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                      {item.type === "Transcript" && <FileText className="w-5 h-5" />}
                      {item.type === "Voice Note" && <Mic className="w-5 h-5" />}
                      {item.type === "PDF" && <FileText className="w-5 h-5" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-sm truncate">{item.title}</h4>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-muted-foreground">{item.type}</span>
                        <span className="text-[10px] text-muted-foreground/40">•</span>
                        <span className="text-xs text-muted-foreground">{item.date}</span>
                      </div>
                    </div>
                    <Badge variant={item.status === "Processing" ? "secondary" : "outline"} className="text-[10px] uppercase tracking-wider">
                      {item.status}
                    </Badge>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        {/* AI Suggestions */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-display font-semibold flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              Connection Suggestions
            </h3>
          </div>
          <div className="space-y-4">
            {connectionSuggestions.map((suggestion, i) => (
              <Card key={suggestion.id} className="bg-primary/5 border-primary/10">
                <CardHeader className="p-4 pb-2">
                  <CardTitle className="text-sm font-semibold text-primary flex items-center gap-2">
                    <Zap className="w-3 h-3" />
                    {suggestion.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {suggestion.desc}
                  </p>
                  <div className="mt-4 flex gap-2">
                    <Button size="sm" variant="outline" className="h-8 text-xs bg-white">Ignore</Button>
                    <Button size="sm" className="h-8 text-xs">Review Connection</Button>
                  </div>
                </CardContent>
              </Card>
            ))}

            <Card className="border-dashed border-2 bg-transparent">
              <CardContent className="p-8 flex flex-col items-center justify-center text-center">
                <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mb-4">
                  <Network className="w-6 h-6 text-muted-foreground" />
                </div>
                <h4 className="font-medium">Knowledge Graph</h4>
                <p className="text-xs text-muted-foreground mt-1 max-w-[200px]">
                  Explore the semantic map of your thoughts and research.
                </p>
                <Button variant="link" className="mt-2 text-primary h-auto p-0">Open Visualizer <ChevronRight className="w-3 h-3 ml-1" /></Button>
              </CardContent>
            </Card>
          </div>
        </section>
      </div>
    </div>
  );
}
