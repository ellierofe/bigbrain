import { 
  Brain, 
  LayoutDashboard, 
  Dna, 
  Inbox, 
  Network, 
  FileText, 
  Sparkles,
  Settings,
  Search
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const navItems = [
  { id: "home", label: "Dashboard", icon: LayoutDashboard },
  { id: "dna", label: "Brand DNA", icon: Dna },
  { id: "inputs", label: "Inputs", icon: Inbox },
  { id: "knowledge", label: "Knowledge Base", icon: Network },
  { id: "content", label: "Chat", icon: FileText },
];

export default function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  return (
    <aside className="w-64 bg-sidebar text-sidebar-foreground flex flex-col h-screen border-r border-border/10">
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
          <Brain className="w-5 h-5 text-primary-foreground" />
        </div>
        <h1 className="text-xl font-display font-bold tracking-tight">BigBrain</h1>
      </div>

      <div className="px-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-sidebar-foreground/40" />
          <input 
            type="text" 
            placeholder="Search knowledge..." 
            className="w-full bg-sidebar-foreground/5 border-none rounded-md py-2 pl-10 pr-4 text-sm focus:ring-1 focus:ring-primary/50 placeholder:text-sidebar-foreground/30"
          />
        </div>
      </div>

      <nav className="flex-1 px-3 space-y-1">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors",
              activeTab === item.id 
                ? "bg-primary text-primary-foreground" 
                : "text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-foreground/5"
            )}
          >
            <item.icon className="w-4 h-4" />
            {item.label}
          </button>
        ))}
      </nav>

      <div className="p-4 mt-auto border-t border-border/10">
        <div className="bg-primary/10 rounded-lg p-4 mb-4">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-xs font-semibold text-primary uppercase tracking-wider">AI Insights</span>
          </div>
          <p className="text-xs text-sidebar-foreground/70 leading-relaxed">
            System detected a connection between "Robotics Ethics" and your "Defence Strategy" pillar.
          </p>
        </div>
        
        <button className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-foreground/5 transition-colors">
          <Settings className="w-4 h-4" />
          Settings
        </button>
      </div>
    </aside>
  );
}
