# State Change Mastermind - Jul, 22

# Transcript
**Speaker 2 | 00:04**
Hello, Robert. Hey, how are you doing, Ray? So my headphones are not connected. Apologies.

**Speaker 3 | 00:20**
Never good, welcome to the club. Ray, join us too. And then Demetrius, I'm just going to send him a quick note and hello to all.

**Ellie Rofe | 00:33**
Hello.

**Speaker 3 | 00:53**
Alr right, I'm sure you just served pion. There he is, all right, just a very instant. I press send, he's like shown up by...
All everybody's here. Wonderful. And Demetrius. You're back in the airpla.

**Speaker 4 | 01:15**
This this true?

**Speaker 3 | 01:17**
Pretty cool. All right, well, let's go around the horn. What is true today that was not true this time last week? Ellie, can we start with you.

**Speaker 2 | 01:25**
Maam?

**Ellie Rofe | 01:28**
Thanks, everyone, for the feedback from last week. That was really helpful. What's true, I think, is one of the best things. I had a call with a client I'm doing a favor for a guy who's introducing me to lots of people.
So, they've raised a certain amount of investment, but not tons, and they are stuck. I think what's lovely, and Ray said to me a while ago, "You will feel a little bit divorced until you start doing the work again."
Before the call, I had this: "Well, this guy used to do some VC work, and he's pretty switched on." The website looks like they've got some decent messaging, so maybe I won't be able to help them.
Then he showed me the deck, and I was like, "Yeah, that's a hot mess." I can definitely help these people because they have not given an investment thesis at all. They haven't told anyone why they should put money into them. They've got incredible technology, mapping human cells to such a degree that they can test target drugs and all sorts of stuff.
It's incredible. But haven't told any company where they should actually invest. So it's like, "Okay, this is very cool." I'm pushing through with that process that has enlivened me a bit. I am on the sofa with a cup of tea. I'm feeling a bit up and down as I get into fasting and I think probably withdraw a bit from things like caffeine and sugar and maybe even the processed food or whatever. Although we don't do much, but...
Yeah. So ups and downs physically, but generally feeling much better and pushing forward with the report staff and research via VCS. I've been ingesting different things, including Josh Wolfe at Lux Capital, who does some really interesting letters to LPs. So they're limited partners.
I've been ingesting those and saying, "What's interesting here? What trends are happening here?" They're very cutting-edge stuff.
It's been a really interesting process. So, good week. I think he.

**Speaker 3 | 03:43**
Cool, I appreciate you sharing those. Robert, can we check in with you? Was true today that's not true. When we went last week for forchard.

**Speaker 2 | 03:53**
So what's true today? That wasn't true last week. I got some... I got the technology working that we discussed before, but I managed to get this proof of concept working, which is essentially another MCP that works, that provides value or at least demonstrates some type of functionality for that enterprise. Old technology that we were discussing last week, like universe databases, all stuff. I actually got it working, which is great.
So, that's my strength, I guess you could say. To me, that's not so much of a problem as getting that working. My problem is actually just sharing it and talking about it. Because I'll just disappear in my cave.
I'll make something and then I'll just keep it to myself, and then I guess it's not good enough. And then so I try to break those habits. I made a video about it yesterday. I shared that video. I actually emailed a contact that I have that I had launched with at that restaurant with the company.
So I actually he emailed me back already with a link to where this seems like a secret Google group or all these developers hang out to discuss Universal all stuff.
So that's great. So I get it that way. So I'm going to share it there as well. I've just been trying to be more aware in every way. I'm looking at the stuff that's right in front of me. There's an opportunity for anything, just in terms of raising reputation.
I appreciate it. Those are things that if I'm not aware of, then it's not going to be possible for anybody else to see it, right? No matter how much good counsel or advice I get. If I don't
stop for a second and really think about what's in front of me, then it's not going to be clear. For example, there's a person who is a very nice guy. He actually used my Xano MCP to power pretty much half of the application they built, which is called Leo.
It's like their AI, and they're the most popular thing about their running on Zapier. Yeah, exactly. Yeah, hilarious. [Laughter] Exactly. Then so I keep seeing these posts about Leo, and I see Bennois post about it, and then it keeps getting all these likes. I'm thinking, I should make a post about Leo, too, or something like that because it's obviously people are liking Leo and talking about it. It's so cool. It works with Xano.
I'm just sitting there, I'm like, even this is something that I should post about. It just doesn't pop into my head. So anyways, after thinking, just then it pops into my head, and I say, "Okay, so I'll send a message to Augustin." He always wants to hop up on the phone, and I'll make a post about Leo and so on. I'll just put some energy towards that, and something might come or might not come, but I think it's worth something, right?
Yeah, exactly. Like you said, it's good. It's already there and it's providing value. So why not? I'm that's one of the best things I can get out of it.
The other thing is just to say that. I don't know, this is okay. This is like me going back into the way that I think about things, but I feel like I had a realization about how the MCP tool could work in a much better way.
The way I realized that is because of working on the other MCP tool. When I worked on the Universe one, I approached it in a way that essentially... I approached it in a way that I created middleware that would make it more MCP-friendly.
This type of interface that sits in the middle and then acts as a bridge to communicate with DMCP in a way that the MCP minimizes the tokens that are needed, making it more efficient. I then hosted that on fly.io.
After actually looking at the notion MCP, which they recently came out with, I was looking at it, and I thought, well, the original notion FCP was using JSON.
It seems like they've made more MCP-friendly endpoints or some type of interface that it accepts their Markdown now. The point is that I could do the same thing to create an interface that just makes it easier instead of the LLM having to, for example, write out all the syntax or Xanoscript it and say, "Give me an off," and then the middleware will know what that is.
I'll have my library and so on. And that's not a very hard thing for me to do relative to everything else. I know how I can actually go about that and get a pretty quick win. So I have a few things I'm trying to do now. I'm being stretched in five different directions.
But I think that's good, and probably as an entrepreneur, I think we're not really looking for stability anyway. We're trying to keep things changing. So yeah, that's it.
That's what I'm working on.

**Speaker 3 | 09:55**
I appreciate you sharing. Beatrice? What kind of week has been for you? What is true today that was not true last week? Then we can get into your hot seat.

**Speaker 4 | 10:08**
It's the work that I moved entirely from Athens. So we were changing entirely the place, jobs, and everything. My girl will start a new business in a pharmacy ward, she will run her own pharmacy. And we're looking around how what we can do in terms of automating workflows around by GE ERP. We have to purchase it, and it's quite expensive. We think that it's buggy, and you know that from previously.
Anyway, a website for the new staff. What's true today that wasn't true last week is that while the pressure of the past week of packing our staff for two days, well, I had to do my calls, join our communities, do my shipments. It was quite challenging and avoiding at the same time. For me, I realized that a very challenging project came to the door last week, and I went about to join it. It was a request from a client, by the way. This client owns the best client profile.
Alright, so they're my persona. And they came back to me and said, "Look, we don't really know what exactly we want to build, but we have some struggles in our operations in terms of how we deliver and how we can improve the customer experience we offer to our clients."
So they thought initially to use transcripts of their conversations with the client on weekly sessions, email conversations with the client, and Slack messages from our channels. They engage with the clients, collect all of these data, and build an AI experience that can create responses for humans when a new request comes to their door.
So, when the client posts on Slack or sends an email, the knowledge base will be updated, and they will have a response. So, Ray gave me a very nicely... I have to say... I go and bring something that works first without bringing any automation stuff on that.
Last Friday, after the truck came to take our belongings and I kept my laptop open to do the call with the client, I gave them an MVP using Zapier's chatbot and the knowledge base. I realized that the knowledge base was only for specific clients and was quite huge, and the chatbot is not that comfortable in finding the right responses.
In any question, they started giving... I don't have enough information, sorry. I don't have enough information. Sorry, it's a nightmare. Thankfully, the client came to this and said, "We'll talk again, and we don't see the real value of having something like that."
Well, the problem is that after the conversation, our project manager has to go on the project management tool and create tasks, assign tasks, and so on. So, okay, let's do the opposite. Let's take transcripts, analyze them, fit them to a middle step for one week. Google Sheet, where your managers can review the results and validate if Claude or ChatGPT works better.
First of all, because we have the analysis from both models, and I see huge differences and explain my methodology that they like. Again, the challenge remains of what we are building now.
If finally we'll validate back their claims by decreasing the friction in their customer support or the customer experience they offer, right? This is the goal taken all about that. Discussing that last Friday with Ray and I realized that something useful to discuss today, guys, is how do we bet or how do we quote our proposal for solution? The problem. Not talk about the financial part, which has to be part.
But how do we present the solution? Their challenge. Because the client came to me asking for that and came back to them with a Google Doc, a single Google Doc pointing out the challenges and making a structure of the steps.
I recorded myself in 15 minutes. By the way, I like it more than sending a huge document or an email. At the end of the day, our experiences through Vido... I recorded myself, I explained a couple of things about the solution, and so on. They agreed.
We moved forward. I think what again would be useful to discuss is how we should present the solution we proposed to the client when we took the client as a problem?

**Speaker 3 | 16:14**
Which part of the solution we talking about? Right now? You're talking about, like, the in your story, you talked about, like, building you building one thing and then discovering there's everything that was more valuable, right? As you move through that, you sort of asking what you what the pitch would look like for before doing the V1 or even what the pic looks like now having done the V1, getting into the V2, like which part of the it's sort to center us all in the right frame of mind, right?
Like, at which phase are you imagining the, you know, wanting to have this conversation that you want to be focusing us on?

**Speaker 4 | 16:49**
I imagine it in both cases. In both cases, I had to give a demo in second for V2. It was like a continuous switch and the initial one and the V1. Okay, so in that case, we could say that for the V1, but again, in the overall of the video, I had to give them a workflow for the solution they agreed to move forward with the purchase of doing that.

**Speaker 3 | 17:28**
Okay. Okay, well, let's throw it up into the four-hour. I actually see the gears moving just underneath your skin and your forehead. So, could we enlist you for your pitching thoughts on this?

**Ellie Rofe | 17:36**
God, yes, sorry, I'm on mute. Yeah, I mean the pitch, the fundamental pitch question whenever you're proposing anything is why should they care? So, I think that to me is the underlying thing when you're devising a proposal. There is an element where you have to have things that you care about as well, because you have to scope things.
So, you have to make sure that they... What you're putting in there isn't just about them to make sure that you're not over-promising or opening yourself up to a thousand years of scope creep.
I suppose... I mean, I think the video thing is very good in terms of giving people an AA connection, a human connection to something. Did they presume they wanted written stuff though, right? They didn't.
So, they were just happy with the video proposal.

**Speaker 4 | 18:51**
Yes.

**Ellie Rofe | 18:52**
Wow. Interesting. So, where are you feeling? It sounds like you've done it in a way that makes sense to you and has made sense to them. So, where's the question coming from? Is there something that doesn't feel right?

**Speaker 4 | 19:12**
Yeah. I think the reason they move forward is that currently their business hearts their hearts a lot. They spend... They have huge time on delay for customer response. They counted that the team is over. They run in over workload.
So, they were somehow in a rush. They were quite sensitive to say no, right?
I was surprised that they said yes, to be honest.

**Ellie Rofe | 19:48**
So you're feeling like they were on the verge of just saying yes and almost all desperation, let's go.

**Speaker 3 | 19:48**
So. Yeah.

**Ellie Rofe | 19:58**
But you want it where it's a persuasive process for people who aren't quite that, haven't quite got that burning problem.
Okay? As I said, the biggest thing is always why? So a structure I'm working with a lot, it's a very difficult investment environment at the moment, and a structure I've been playing with my last two clients and considering when I'm reading and trying to speak with VCs and learning about stuff is just putting the investment thesis upfront.
So, just stating very clearly why you're suggesting doing something and what the benefits are to them, and then beating out the evidence of that afterwards. So, saying, "I should suggest..." So, taking that model into your world, I suggest we create this because this is why it's going to be amazing.
Then break that down in a pitch that breaks down into the market, the product, the technology, the moat, the competitors, whatever, but the timeline, et cetera. But it would be similar things for you.
Why this? Why? I've identified this as the best thing. It would be like the market is really their business, like how they work and what they're doing and why this fits within their operations, their current ecosystem, and why this is better than other options. How long it will take. That's my instinct.
I mean, I haven't scoped or given proposals for tech work like that. So, I'm applying models from other worlds into it in case that's useful. But I can't give a definitive thing that I know has worked for me because I haven't done it.

**Speaker 3 | 22:00**
Okay, well, let's keep the ideas flowing. Robert, can we get your thoughts on this?

**Speaker 2 | 22:07**
I think that first of all, when you send the video, did you just send a video? Then they just watched it offline, and then they sent you back an email or something, and then they said, "We'll do it just so..." Just to be clear about the dynamic like was like.

**Speaker 4 | 22:26**
It was just a televideo.

**Speaker 2 | 22:30**
Was. Okay, so you said... And then again, I'm sorry because I think some of my questions are actually going to be similar to Ellie but just to understand where... What is it that you're trying to do? What is it that you are unhappy about specifically, just to be clear? What is that thing that you're trying to improve?

**Speaker 4 | 22:58**
I was unhappy for something. I'm just trying to become better and better at doing this. So I'm bringing that because I felt I think that you guys too have to give a proposal or a call to someone who comes for your services, right?
So I think this conversion will be useful for the fourth of us. And think how can I become better and better? My core KPI is how can I have more percentages, have conversions because for that case I don't count them as conversions because they were in a rush.
But for the next one, I wouldn't be in risk or I would like to decrease the risk.

**Speaker 2 | 23:44**
Okay, well, I don't think that them being... Why is it bad that they're in a rush? Maybe that's a question. Because that seems like something that's ideal for you. Why can't other people be in a rush?
That's not something that is only unique to them, is there or maybe that's your hungry crowd, right? They have a pain. So I'm wondering why is that something that you feel is not replicable in the future or not to your advantage?

**Speaker 4 | 24:19**
Because when someone is in a rush, they say yes more easily than.

**Speaker 3 | 24:26**
They are, do.

**Speaker 4 | 24:28**
That's the point.

**Speaker 2 | 24:30**
But how come? How come? Okay, let's say you have a customer right now that he's in a rush. Can you get the next customer to be in a rush? And then the third one and the fourth and the fifth one. Or is that like, is this circumstance so unique that this person is the only people who'll ever be in a rush?
And that's kind of what I'm trying to drive.

**Speaker 4 | 24:46**
At this point, the thing is that thinking about my best persona, the best persona wants things to be done as soon as possible. So even if they are not in a rush, they bring things in a rush. So somehow we have the time pressure, but they at the moment this company hurts because of the time consumed.
It's not quite often for me to meet these kinds of people, businessmen or managers, who are in this situation, quite sensitive to say yes to everyone.

**Speaker 2 | 25:35**
Yeah. Well, I would say that, first of all, I think that for me, I would be happy. Maybe I would embrace it a little bit, try to look for it. And again, I know that probably you can see all the factors that are in front of you.
If you feel like it's something that is not going to apply to your interactions and in the near future or for every other customer, and you're trying to essentially improve the way that you pitch from the way that it sounds or the way that you approach that situation, I would say that in general, and I don't think there's a right or wrong answer for any of this stuff, but in general, I would say that probably sending a video, I would do it in a live call. I would pitch during a live call, and I'll probably make it less of a pitch if that makes sense, but that's just my own style of conversation. I don't really pitch or create decks or stuff. I just have conversations with them, and I almost try to massage the solution through the conversation with them.
That's just me. And again, there are times when I come in with Express Agenda that I want to present something, but usually, it's rooted in the fact that they know what I'm going to present more or less because it's not really a surprise.
I think that's maybe the main thing that I was to... There are a lot of factors that come into play, but if there's one thing that I try to do, it's to keep them consistently on the same page. By the time the words are coming out of my mouth, they know more or less what I'm going to propose. The only time where it's ever been a lukewarm or anything worse reaction is when they weren't on the same page. You're like, "What is this?"
So, I'm not trying to surprise anybody. I'm trying to make it so that, essentially, more or less, through the conversation, they're describing the solution that they want themselves. I'm just drawing it out of them.
Then eventually, we have a conversation where we finalize what it is that they want. But really, they're very much part of the process for me. So, they're closing themselves. At least that's how I feel a lot of the time. I can't really convince somebody to do something that they don't want to do, and I don't want to. I'm just there to be a type of rubber duck that can talk back and just elicit, maybe just ask interesting questions and take the conversation towards where the solution is organically going to come up. It's
going to be like they see the steps that led towards it in the conversation, but that's me and my own approach towards it. Just to say, maybe the last thing is that I've done it in the past where I would send a video where I would try to do that part offline.
I've never felt totally in control of it. And maybe that's the part that's the reason why I don't do that so much anymore, because... But when I'm talking to somebody on the phone or in a call, I can... I can change strategies. I can adjust it, say, "Okay, we don't have to do it this way. We can do it this way instead." And so on, right?
If I have a video that's very... It's very set. So that's it. I can't change strategies on the spot. I can't address any questions that they might have in the middle. So that's maybe the reason why I wouldn't send a video just because it doesn't off for me any opportunity to pivot in real time, but I'm not sure if that really helps.
But those are my two cents.

**Ellie Rofe | 29:33**
But I think that you picked up on something that.

**Speaker 3 | 29:34**
We can.

**Ellie Rofe | 29:35**
Sorry, Ray.

**Speaker 3 | 29:37**
No, actually, I wanted to bring you into the conversation, particularly on this question of the hungry crowd. Please lead with whatever thought you have.

**Ellie Rofe | 29:45**
Well, I understand what you're saying about not every client will have this feeling that they have their hair on fire in the same way.
So that's like... But I think maybe you're underestimating the role that you get in the project brief and talking to them played as well, because the proposal is a proposal to me, it's really a documented...
It's more like it's almost legalistic. It's a documented thing that's like, "This is the thing we're going to do now. We've agreed on it." I know that you're going away and considering architecture and other wider considerations.
But a huge amount of the reason that people will choose you is because they trust you and they think that you can do the job. And so your process and the things you've been talking to them about prior to that proposal, then being in touch with you and feeling like you know what you're talking about and that you are a trustworthy pair of hands that they can put their company in, is probably doing a lot of the heavy lifting.
I know people who have been desperate. They haven't just gone straight to the first proposal they hear. You know that there's desperation and there's stupidity, and they're two separate things. So I wouldn't underestimate the fact that you have already been doing the sale before then.

**Speaker 3 | 31:16**
The. the... I was hoping, Ellie, that I thought that the part of the question is, to whom do you pitch and how do you figure out who these people are and how the way that you communicate can actually be starting to qualify the people that you're talking to.
You know, the hungry crowd, right? That's Alex Trebek's analogy, right? The hot dog stand, right? I was wondering whether you based on what you've been hearing Robert say and what you were hearing Dimitri say and describing the journey that he's been on here, thoughts he has of signals and how he might be able to better speak to the hungry crowd.
Right, or make their mouths water, right? Remind them about how hungry they are as part of this question of pitching or maybe just bare about communication, right? To kick off an engagement.

**Ellie Rofe | 32:13**
So I mean, that really sits in where their awareness is, right? Of their problem. So, to a certain extent, it sits in awareness, but yes, the hardest people to sell to are people who don't know they have a problem.
The vast majority of people who are selling things like hot cakes are selling them because people know they want hot cakes. There's a... If you are trying to sell to people who don't know they need what you are offering, then you have to frontload a huge amount of education.
It's so just as a slight tangent to show a separate example of this, if you create a new brand category. So if you create something that's completely separate from everyone else, it's incredibly highly differentiating because no one else is doing it.
So you stand out, but you have to put huge amounts of effort and investment into education, into getting people to go, "I care about this. I didn't know I cared about it, but now I know." That's the hardest thing to do, especially as a freelancer or as a solo person rather than someone with a big budget and loads of brand awareness and stuff.
So really, you do need to be talking to people whose hair, if not on fire, is at least smoldering. They're like, "I want the bucket water to put this out." I think maybe there's an element where you're thinking sales is convincing people of something they don't want or not directly that because I know that you're more nuanced than that, but
I don't... I think you're really pushing people over the line who already need something, and you are already doing a huge amount of that heavy lifting yourself. Does that make sense?

**Speaker 3 | 34:17**
If I can, I just start putting that a little bit in terms of structure.
I think there are a lot of good ideas here, and Li and Robert, I appreciate both your perspectives on this because I think I'm putting it into words, ideas that you've expressed. There are basically three types of professional service engagements.
Okay? There are innovation, gray hair, and playbook. Playbook is the one that people talk about like, "Hey, we're going to have a super repeal process." You've done it, your company's done it a bunch of times before. You can hire cheaper people to do it. This is the basic economics of an agency. When you're doing that, it's because we have the playbook, and we're going to do the playbook for you. Gray hair is when you're hiring the best person in the world for handling this thing that they've done a bunch of times before. This is classically what you hire a lawyer for, right? You're a lawyer who's done mergers and acquisitions, a whole bunch of four, or who has defended this criminal case or whatever, right?
Because it's... We all bet the company's stuff, and there are really higher margins. So which are the kinds of people you want to hire them in the situation? Then the third is innovation, which is you're hiring to have something that hasn't been done before and you're hiring for intellect.
I think the trick is, since you don't quite have the gray hair yet, the easy pitch is going to be category number one. The category, the category number one, category number three.
The problem with the playbook pitch is it's not necessarily a committed pitch. That drives down costs. Often, you're talking to other people who are building agencies or whatever, they're often talking about their playbook stuff.
But that is pushing down the ability to command rates. In fact, what was happening to you before, earlier in your something other engagements, you did it before. They kind of have the quality of being a playbook without you having done much before, right?
So it's both commoditized and doesn't quite have that compensate curve, which pushes things down. Being in the AI space puts you in a really good position to be doing the innovation sale, right?
You guys are selling your own credibility, right? Your character by someone who they want to trust with this. They are already inclined to want to step into the unknown bed, right?
Because that's what they're buying into. This person, right? They have a hard problem, and you're providing something that's not the known solution because you don't have the known solution yet. Later, you'll be able to turn those into playbooks, but you don't have those yet.
To do that, you need to remind them that they have a big problem. And you need to remind them that the nature of the technology you're bringing to them can solve the problem, and you're a really good person that they want to work with to solve that problem. You want to put those three things together, right? The upside, the pain. You want them to feel acutely hungry. You want the thing to look especially delicious, and you want them to trust that they buy it from your cart. They're going to get that delicious thing that's going to...
That's going to slack their hunger, you know? I think that's the essence of what the pitches and what the proposals need to convince some of all three of these things. Now, I think to Ellie's point, there's a question of awareness: are they aware of how hungry they are?
You can help with that, too. Your marketing can be out there reminding them of how hungry they are. What I really like about this engagement you're doing with this guy, Adam, is their customer service is all boxed up, right? Their sales processes...
That's content, man. If you're out there talking about how these things are challenging, not that people do them poorly, not discouraging, just like these things are hard in the current era, it's even harder. There's so much information coming through multiple platforms, right?
Just an appreciation that these things are hard and that AI has an interesting opportunity to make them easier. Now, do to put yourself in the class of the stuff that they want to be doing. Then the pitch is, this is all new, right?
That's why this innovation. I think that's what you're getting at, being challenging. You did this thing with him, and in the first round, you made something that was interesting but didn't quite work right. You did what you said you would do. You did it well, but... What you did was able to surface the next thing that came over.
I think that's what you want to be selling them on. I think the kind of thing that you want to be selling them on is that there's a discovery process here, right? There are opportunities in 2025 that are not yet made in playbooks. They have a business. They want to go fast, they want to find where they want to get an edge, right?
That you can get that edge, but the edge involves some risk. So they're like, "Well, we know there's some risk to it, but who are we going to? Who's our trustworthy partner to work with us?" Who's going to be giving us focus and giving us service and do it with credibility and character and integrity, and you're all those things.
So the job... I think of the pitch. I'm not even a big fan of using the word pitch here because it feels like the stereotype that Ellie was describing before, like AAA. It's a magical incantation to get them to part with their money. As opposed to just...
I think we've been hearing about so far. Which is just a restatement of the alignment that you already have with the client, as you do, right? That's one of the reasons why he's like, "Yeah, just give me something that I can buy."
What you want to do is talk to clients who feel that same way about the engagement. There are clients out there who want to feel that same way about the engagement, and they're being pitched by these hucksters, right? People are saying, "I'll make you a big promise.
I'll guarantee you X, and you're like, "Look, I'm not going to make you promises because this is all discovery. I've done this before, right? I've found really good solutions. And it's about how it's going to intersect with your business.
Maybe if you want to sit on this for five more years, sure, there's going to be an established playbook that's going to be much cheaper, and you'll be able to do the same way every time, but that's not the way the world looks on 2025.
But there are things you can do in 2025 that we sure couldn't do in 2024. There's hope for your business, and you can be selling them. You can be not selling them. That hope that I think the words really just provide them that hope, right?
That's an immediate feeling. That's a positive thing. They're getting out of this from day one. They get hope, right? Then you get to give them the hope of actual results based on your process of working together.
I think there's a structure that goes with that too, of saying that you're going to work fast, right? Which reduces costs, which is kind of what you're already doing with this guy, right? It requires you to have a little bit of Slack in your schedule, but that's not really a problem for you in the present day. You're going to work fast like, "Okay, we're going to do the first experiment in a day, and you're going to get this."
I think it's where we're going to work this way, but we're going to do it on a time and materials basis, right? If you're feeling like the first experiment didn't work, that's okay. We can part ways.
I'll put it down, but really, the first experiment will then lead them to... Do they want to continue with you, or do they want to do another experiment? If they are excited about doing another experiment with you, then they want to pay for the first one and they want to pay for the second one, right?
So you can derisk it for them through an MBG on the first round of this and have a good shot at them being able to say, "Wait, he was able to get a taste." This almost works, right? But you can't promise that you're going to deliver something that works in production and blah.
Other people will make that promise, but I think you... Your integrity is that you won't. Because you're not in a position to make that promise. It's all too new. If I think if your integrity is right and you demonstrate expertise in the marketplace, you understand the tech and you understand their business, which is the intersection in which you live, then the right kinds of clients are going to say yes to that, and the wrong kinds of clients will say no to that.
All those clients who said no to that aren't losses on your part; they're qualifications out. Because there are lots of people who hire other folks in the industry, like a lot of Joe Lee's. Joe Lee was just speaking in the industry, and you and I were in that CA early today.
He works with lawyers, and they're very conservative clients, and they love them, right? But you're not talking about providing what Joe would provide, right? You're talking about doing the kinds of things that Joe wouldn't do because he doesn't take those kinds of risks with his customers.
But as a result, you have a great opportunity to be doing like a half dozen of these engagements and then, through that experience, be able to turn things to a playbook far faster than anyone else. That's what looks like for you in the fourth quarter, right?
But in the third quarter, it is very much an innovation play, I suppose, to a play with play. Anyway, as I was listening to Ellie and Robert and thinking about this idea of the hungry crowd and this combination of what kinds of things you can offer,
I mean, Robert was talking about what the delivery vehicle was for. Ellie was talking about the "who" versus the "what" of that. The. Yeah, I think you've got a wonderful opportunity for very lucrative contracts, but it's going to be a different sale than what you see your neighbor making, right?
Because those folks are selling whatever they're selling, but they're selling. I've been there before, right? I have my playbook, and you're in it's just not a playbook play. I think that's great because then you get to do things other folks can't do, and you'll develop experience and
be able to keep on selling for a high amount. In fact, you'll probably be able to sell it for more in the 4th quarter because you derisked even more because of the curve you've gone through in the 3rd quarter.

**Ellie Rofe | 43:59**
Ray, can I ask a follow-up on that? Would you... So, just as a slight up with my partner's business, he does renovations, and he used to just go in and quote for the whole job, and now he gives them a quote for the design and planning phase upfront before quoting everything else.
Because everything after that depends on what happens in that design and planning phase, but the beauty of that phase is that that's the bit that gets people really excited, so he that's the shorter phase. He derisks the longer term thing, saying you're going to end up spending less on this in the long term because we're not going to waste months and months doing the wrong things and choosing the wrong paints or whatever on that score.
So, that discovery phase becomes the initial through-the-door product, which is a very short process, almost like a fixed-rate discovery phase that then leads to the process. So, you're charging for the discovery phase as well. Is that a model that you think works Here?

**Speaker 3 | 45:04**
It can. The idea of the audit or discovery as an initial engagement is an old-school technique in the world of professional services.

**Ellie Rofe | 45:12**
1.

**Speaker 3 | 45:15**
It can provide value, but only if the audit itself provides value if they don't continue with you.

**Ellie Rofe | 45:22**
Yes.

**Speaker 3 | 45:22**
So Nolan Norton is a consultant, technical consulting firm out of Massachusetts. They had a balance scorecard product that they would do. They could fairly quickly do the interviews and they would provide this balance scorecard.
Then the idea behind the balance scorecard was that they would then identify opportunities for further engagements. But they had enough branding and energy behind this idea, like, "Hey, this scorecard would be valuable for you." They could go in, they could do that engagement. It would be a small engagement as much a viable product for prospects.

**Ellie Rofe | 45:52**
4.

**Speaker 3 | 45:53**
And the client would buy that. It would be some money they would have gone through purchasing or whatever. Now they have their foot in the door, right? But that balance scorecard itself is something that makes the director who bought it look good. Just for holding that even if they do nothing else for now.
Others had then gone down this road. I think they were on to really popularize this as a model in the 1980s, and then other consulting firms started trying to do this as well through the 1990s. It didn't work nearly as well for anyone else. Why didn't it work? It didn't work because people sought what it was, which was a hunting license, right?

**Ellie Rofe | 46:33**
Hu.

**Speaker 3 | 46:34**
So think this idea of having an initial engagement that involves more discovery is a great thing, right? The trick is you want to make sure that the first product you're offering is providing them with value.
So, this is where you want them to part with money, and you want them to get value for it. This is where Marty Kagan's idea of product development really kicks in. It's like you're not selling the wheel. You sell them a skateboard. By selling the skateboard, they actually get some motion. They're feeling good about that motion. They like to have a bigger vehicle, right?
If you sell on the wheel, that's cool. I'm holding a wheel. Now, what am I supposed to do? This thing... The vision exercise, for example, that your partner's doing, might be the easy way for them to buy. It could be like, "All right, let's make this thing more real." No matter who you hire, you're going to be able to be a better customer to those folks as a result of having done this.
By the way, if you hire me, I'm just going to comp the cost of this engagement. We're going for the part we do on a going-forward basis that can be a very compelling sale because it provides them with immediate value that they're unable to make money on either way.
That improves the trust, and because it improves the trust, your partner is not the best person to be doing the follow-up work. That's the foot-and-door aspect of it. So, yeah, I think that's...
I think that kind of thing is fantastic. It's not automatic, though. So, I bring it because clients recognize hunting licenses when they see them. Just like you talk about other things, they recognize when they see them. They're not just going to go buy the first thing they see in that regard.
Actually, I thought the way that Demetrius had done this was, "Hey, we have this first idea, and it would take a day. Let's do that.

**Ellie Rofe | 48:17**
One.

**Speaker 3 | 48:17**
Let's see how well it works, and then be able to take the next step can make a lot of sense.
If there's an audit version of that, I'm down with that, too, but I have the feeling that so much of what you're doing right now, Demetrius, is discovery. Anyway, it's discovery. "Hey, what kinds of things work?" You just want them to be coming along for the ride with you and be breaking it into these smaller pieces.
Then, once you've got a prototype, "Okay, now let's have a conversation about how to more productionize it." I think if you can bring them along for those pieces as you go, as opposed to having them commit to the whole journey when there's still a whole bunch of risk in that,
I think that could be easier to sell. But that's really... But that's what the lawyers call a question of fact, right? You go, you find out from them what they really want to buy. This guy, Adam, seems to be like, "I like you, Demetrius."
Right? I trust you because of the stuff that we've been doing. Now he's just getting more and more returns on that trust. Then, I think for someone who's coming in for the first time, the question is, "How do you give them the opportunity to build more trust with you in a way that creates immediate value for them?"
This is where the shorter engagement drives a lot of value for that. This is where you have an idea, right? That's at that business tech, Intersect. It seems like there's an opportunity there, and you derisk it by saying, "Hey, first engagement, one day, we either make something that's interesting for you, or you don't have to pay me."
If it's interesting but doesn't quite work, but it's feeding into the next thing, like what you just did with Adam. I think they want to pay you because people always pay you. Not for the work you did, but because we're going to do...
That's why they screw you on the last.

**Speaker 4 | 50:06**
But we're talking for guys, and the trust is something that is not offered. It's a win. So my question is how can we win it in a 30-minute conversation for the first time with someone who is unknown? We are unknown to them. They may know us from our content. This is helpful, definitely. This brings some credibility to our face, but at the end, we have to win it in 30 minutes. The discovery goal. What is the thing we have to take care of during this 30-minute conversation? The have.

**Speaker 3 | 50:53**
Okay, that's an excellent question. How do you put those survey minutes to work? Robert, can we start with you this time?

**Speaker 2 | 51:00**
I was just going to say that I think that really you did the best thing to do, which is to have them trust you before they come on the call with you. I know that's getting around the question. I appreciate that the question is if they don't know you at all.
I think that's a hard situation for anybody to handle. I think if I don't know somebody, if I'm on the call, I don't know that person at all, and it's not their fault. It's not my fault, but it's going to naturally be an uphill battle.
They're going to have to explain everything about themselves during the calls because I don't know anything about it. I don't even know how I ended up on the call if I don't know them.
But I know I got something. But I think the point is that I've had a lot of conversations with people. I've had conversations with people who just blow me off and don't care.
Almost all the time, it's when they've never consumed any of my content or anything beforehand or very little. Then there's no that. Yes, there are. I mean, I have to work harder during those calls, right?
Because... And that's just the nature of it. It will take more energy in order to assuage them or whatever it takes in order to do the work that the content could have done over time at their own pace and so on.
Those types of people, when they show up, they just require less. I would just say that I don't know if they're for me. If I'm going to get on the phone with somebody and they don't know anything about me, I just try to show them as much as I can. I don't really like to share my screen.
"Okay, I'll show you what I can do, but what's your problem? Show me your problem, I'll fix it right now." I'll read the room a little bit, I'll read the situation, and then I'll see.
Okay, here's my community. Okay, here's what everyone says, here's what everyone else says about me. Here's... I'll share my screen and show it. Usually, if I do that, then they get the idea pretty quickly that maybe they haven't come across to content, but if I show them all the stuff I've made and I show them what other people have said, and I share my screen and it's right there in front of them, usually, they're going to... Most of the time, they're... I see the switch, right in their behavior where all of a sudden now they realize I have something in my head that they want.
So the attitude and energy will change towards, like, "I want this thing." I can feel that switch. Then, in the minority of cases, you get some people who feel like they don't like that because they start to feel like you're not a vendor.
I'm looking for a vending machine, and you're presenting yourself as trying to make your. Which I am trying to make myself look good, and I'm a business owner and so on. They that's not what they were looking for, and that's fine.
Then they'll self-select themselves to not be doing business with me. But, yeah, I'll try to... Well, what was the word? The eagle wall, I guess. I suppose the... I showed them the eagle wall, the digital eagle wall, right?
Here's all the stuff I've done, here's all the things people say.

**Speaker 3 | 54:45**
Cool. Ellie, could we get your perspective on this.

**Ellie Rofe | 54:50**
Yeah, I think I come from it from a slightly, possibly a slightly different perspective, maybe a very optimistic perspective. But I think the vast majority of business owners are desperately trying to find vendors they can trust,
and they have been burned. So they are cautious. But, my God, if they feel they can trust someone, if they feel like someone knows what they're doing, then their little heart starts to leap because there's been so much nonsense and crap thrown around them, I think. Asking good questions and listening to what the person is saying.
So asking questions that demonstrate that you know what their problems are or that you understand the things they're struggling with makes a massive difference. And listening closely to what they're saying in response.
So you're not just going through a rote list of questions that you have, but you're trying to listen to what they're caring about. Then, if you can, on that call, you demonstrate a little bit of the value you're able to offer.
I get introduced to people who... I get a referral to someone, but they have no idea who I am. In the process of that first call, I listen and understand the company. I show obviously engagement with the company and what they're doing in interest. I ask questions that taste of the questions I would ask in my initial discovery messaging workshop stuff.
If they show me their pitch, they've normally either shown me their pitch that they've sent to me beforehand. I give them a not damning but an insightful look into some of the things that might not be right in their pitch and ways we could improve it.
Those things start to give them, I guess, what Ray is talking about. You understand the problem. You highlight the problem. You show them the benefits. You show them they couldn't trust you. It's like that. That credibility factor.

**Speaker 3 | 56:42**
Yeah, I think that makes a lot of sense. What's the expression? You have two ears and one mouth. Following up on that can produce a lot of trust. Then, yeah, it does depend on who they are and how they're coming in the room, to Robert's point.
You can freewire for trust. I actually find that people who are referred have very low trust, right? Because they don't trust the person who referred you, but they don't really know you.
So this becomes the get-to-know-you session. There's no sale to be made. I find most of the time in these calls you listen to them, you learn something interesting from them. You come across as an inquisitive, interesting, and useful person, like they say, "Yeah, I see why that person likes you."
Then, they move on, and then there's going to be a subsequent conversation that's more likely to work, but I find it in general that those kinds of referrals are often overrated because it'll send someone who's less qualified in your direction just because they're not feeling the pain right
now. You should totally check out this hot dog vendor, right? But if you're not hungry for a hot dog in that moment, you went and checked out the vendor because your friend told you to. But that's not the same as being raided by a hot dog.
What you do is remind them that they're hungry. And that's listening to them and reflecting back to them. The thing I do with those intro calls is I get these cold intro or Fred intro or whatever.
I never really had the expectation that they're going to do anything up to including even joining the state change, but I always send them a copy of the call, and I do find this turns into goodwill, and more likely to be turning in stuff later on.
So, always be presenting yourself as if you're going to record right and then be giving that back to them. I found this to be a nice giveaway for that kind of thing that helps build that up.
But if they don't know you, there's not a sale to be made. But if they do know you, I think of people as being like people who are ready to buy from you. People who are almost ready to buy from you, and people who are not ready to buy from you.
And you can think of your processes as moving people from one bucket to the next. Many people will never be ready to buy, but many people will never be almost ready. But how do you sort of move them up by one step?
Because it's very rare. It happens, but it's very rare that people jump from bucket one to bucket three. I know this. Yeah, sure. All right, any final thoughts here before we wrap up for the hour?

**Speaker 2 | 59:23**
I think I would just say that I don't know, I'll just think about this DM, but I just thought that in a long enough time, in a long enough timeline, if you live forever, that you'd eventually do business with everybody.
They'd eventually switch packets. But the problem is, there's just not enough time for that. If I lived until the end of time, I'd probably do business with every single person in the world because every circle...
It's just a moment in time. I think, like you've told me before, that things line up, but it's nothing personal. It's just looking for the opportunities that are more timely.
I think what that is available now. If you can't help, then just the business grows with every new client and every new interaction.

**Speaker 3 | 01:00:06**
So I think that takes us to the end of our hour. Thank you all very much. This was an awesome conversation, and we'll be doing this again next week. I'll see you all at the end of this week.

