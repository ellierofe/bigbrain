# State Change Mastermind - Jan, 13

# Transcript
**Robert | 00:03**
Hello.

**Ray | 00:04**
Good afternoon.

**Robert | 00:06**
How are you doing, Rick? I'm well. Hello, Ellie.

**Ellie Rofe | 00:11**
Good afternoon. How are you?

**Robert | 00:17**
Good, I am a little tired, I'm good.

**Ellie Rofe | 00:25**
January is hit already. Hey.

**Ray | 00:28**
Yes, certainly.

**Robert | 00:31**
Second week like that second week.

**Ellie Rofe | 00:36**
I'm finding by Energy. Sorry.

**Ray | 00:39**
No, please hear f your energy.

**Ellie Rofe | 00:41**
I'm finding it's wildly up and down at the moment because I'm doing alternate day fasting, so it's a fascinating ride. It's pretty good, though. I'm getting back used to it.

**Ray | 00:56**
That, yeah, th that that's that sounds like quite the journey. Oof. Okay, well, let's go around the horn here. Like what is true today that was not true a week ago. And then we'll get into Robert's hot seat and deme. How about we start with you since Li is just taken? Quick. Drink of water.

**dimitris@3nuggets.io | 01:18**
Buny I'm pretty good, I've done sorry. A lot of progress after our past conversation last week was so helpful to me, and after closing the conversation, I had a very clear clue how to complete this. NDP. 
So it can be very helpful for me to onboard people in the experience of nose graphs and give them somehow a simulator of playing by uploading their data. It was very useful. I've done most of the technical engineering part. 
It's almost done. Now I'm just doing fine tunings. I'm improving the way it processed the data into the database, these kind of things. But anyway, it works pretty fine. And I had a conversation with a sales consultant who he established actually a framework. He would love to make it a brain, a digital brain into a database. 
And we had very thoughtful conversation where I realized many things, many problemsen spoken by the mouth of the guy. Most of those problems were already. Described from Li in my branding work in communication, whichs that we done so targeted work, and I'm very glad for that. 
And, yeah, that's it. I'm, pushing myself to complete it. I'm gonna upload a couple of videos on that. I'm going to do some reach out to people for getting into that and testing. That's my plan. And last Friday we had a very interesting conversation with Robert and David from the community about how we can build those graphs know as databases using the SQL the Zoho SQL database. Instead of going to the graph database, it was mostly engineering and technical conversation, focusing on what is the solution and finally why it works. It was very interesting to me.

**Ray | 03:45**
Super cool. Yeah. And is the meet up from Friday now on is on YouTube yet, or is it still sort of processing or.

**dimitris@3nuggets.io | 03:56**
It's going to be on 8 pm in one hour from now.

**Ray | 04:00**
Super cool schedule, scheduled release. Okay, cool. Ellie, can we check me with you? Was true today. It was not true. Week ago.

**Ellie Rofe | 04:13**
Generally speaking, I'm finding a lot more momentum. ACM calls working really well. I have got my brains gone. I say a course are working really well. Clearly my brain isn't working very well. 
And I had a really good call with Maddy at Lumia. So the client that that's out raising on the revised pitch deck now and on Friday afternoon with some feedback and I particularly loved it because a it's really useful for me to hear what feedback she's getting, not just from her point of view, but just the market in general and how VCS are thinking about stuff.

**Ray | 04:38**
2.

**Ellie Rofe | 04:55**
There's more VCS from software and consumer shifting over into hard tech as well. 
And so you're getting different feedback from them compared to people who are used to investing in hardware, for example. So that's really useful for me to understand better the landscape. And she is immediate. 
I mean, within the first week, she had a couple of people organize a second meeting with the partners of their firm and lots of people. She had sent an old debt to some people, and she had to. She was trying to bridge the narrative of the deck she'd sent with the deck that we'd put together. 
And some of those meetings overran. They all asked for an extra 30 minutes to hear the whole story because they were intrigued, which I think an awful lot of people just like. We're out of time if it wasn't an interesting meeting. 
So. So it's really good signs, and I'm just hopeful that it can push through from second meetings and interest into something more tangible. And then I had a really interesting call yesterday with the chairman of a political party that I've been talking with a little bit and helping a little bit on the edges about doing a proper concerted brand strategy. 
And. And I talked about the opportunity window, thinking about how I pitch or help people pitch their company, thinking about timing window. And that really translated to the chairman of the party and to the head of coms. I'm just not sure because the leader of the party wasn't in that meeting and I'm not sure whether he's going to go for it. 
But if he does, that would be a really fascinating brand strategy project that will then lead into fundraising work. So it will go the other way around to the other stuff. And so it's good. And I'm just posting daily on LinkedIn, and I'm trying to gage what does or doesn't get any attention and what is or isn't interesting. 
So here it's good.

**Ray | 07:08**
Super cool. And I can I ask any insights you gathered from, like last week of what you're finding more traction versus less traction on in terms of like with the whole LinkedIn posting, what you're finding people find to be more or less interesting?

**Ellie Rofe | 07:20**
Well, it's a bit early to tell real patterns, but what I do find amazing is the gap between. I just looked at the impressions, actually, and like, one has a impressions and one has thirty. And obviously there's time between them, but I'm not. They're both really about fundraising for hard tech and how it's, you know, how it's different from other things or whatever. 
So they both had that foundation. But one of them was more about the three areas it pushes at in terms of the amount of capital, the timelines and the risk profile. And one of them was about how geopolitics and hard tech are intertwined. 
And the geopolitics one didn't get any reach whatsoever, which was surprising to me. I'd have probably thought it was the other way, but I don't know whether LinkedIn is sort of trying to strangle political discussion because it's too.

**Ray | 08:13**
No.

**Ellie Rofe | 08:14**
I don't know. It will be. It will be interesting because it wasn't particularly a political post. It was just about how politics impacts your. Your. 
You know, the. The investment story?

**Ray | 08:24**
Yeah, it's a really interesting point about like where the w what where the filter is and that because I don't associate LinkedIn when I'm sort of when I sometimes up in the feed having any political stuff in it. 
So it makes me wonder there are people who are posting political stuff and it's just getting squelched.

**Ellie Rofe | 08:36**
No. I mean, I do see quite a lot of sort of, for want of a better term, I'm just being lazy, but sort of cultural or political stuff. But this was specifically like, you know, China US. Decoupling and multiplarity and, saber rattling and things like that. 
And it just might be that that's just downgraded in the algorithm, but it's fascinating. And I'll continue to experiment, I think.

**Ray | 09:11**
Super cool. All right, I appreciate sharing. And then Robert how what is true today it was not true week ago and let's ease into your hot seat. How can this group be helpful in having you have the most successfully possible?

**Robert | 09:29**
So true today, not to a week ago, I made some new stuff in general, like maybe I'll show my screen really quickly and I'll kind of show some things that I, worked on or updated. So this is my website. My face is still on it. 
But I have made the Designer side of me happy. Happier, I suppose, with, like, just like adjusting some, stuff so it doesn't look like, you know, such a hot mess like it did before, and trying to just introduce more things that are, I think, closer to, like, the conversations that I have with people. 
It's not perfect or anything yet. This is just something that I kind of wanted to put up there to just represent some of the things that are. I looked at my old website and I just didn't feel like it really reflected my conversations that I've been having more lately. It doesn't show me Claude code. It doesn't show. It just felt like somebody else's website. 
So and now that's not the case anymore. It has like, you know, these little things and so on and just in general, like making it easy to just get in contact with me is really the main point. It's very much similar to the previous one. 
It's just like just a few touches here and there and certainly could make it better. I'm gonna change the fabric and stuff like that, but. But I just want to put this up there. And. Then there's the actual. The to the MCP tool, which is something that like I think has some good marketing, potential because I have this thing that I made which is like your Workspace Explorer and just loading a whole bunch of information right now. 
But basically, this is like something that I think is good material to market with and which is what it's always been. I just wanted to share this because, like. Maybe it would. Maybe. Maybe it just might be, like, you know, fuel for advice, right? 
Like, hey, go use this thing, go do this thing with that thing. But so to kind of just share a little bit of, like, what it does, it's basically allow. And then, like, what it's doing is it's taking snapshots so that, you know, as I navigate, it won't load it anymore because it's storing all this information so that, like, as I revisit it will then just pull from like the previous one like and start to take snapshots and so on. 
But anyways, this is the whole point of this is to kind of, like, enable agentic development, which goes into, like, the marketing side of things. I'm trying to see if I could create something that, like, augments the experience, and maybe just, like, expands it in a unique way, like. 
So the idea is, like. Okay, you can come into here and, you could hit, like and just as an authorized one, but the point is, I can see everything from here, and I can copy information from here. I can like, you see, like I made this is custom context, so I can copy commands and like, just I can run all the tests all at once, for example, and I can see like the results for them and like, the ideas to copy them all at once, like really quickly and so on. 
And so, yeah, there's that stuff, that I'm trying to. I suppose it. I feel like I'm just making so much stuff lately that I'm not even excited, like, about it. Like in some way, like I like to make this stuff, but I'm not so attached to it in a good way. I this took me like two days to make it. 
So anyways, I'm just saying that probably I'm not looking at this is like, this is going to go change the world. It's like, no, I'm just. What can I do with this week? That's more my thinking, which I think is a good way to think about things. 
And another thing, probably the most important thing, to be honest with you, is I was reached out to by Perksh and he wants to have a meeting on Friday. And, he heard very positive things about snapping through my client and like, all the softer, positive things I've said. 
So obviously I accepted. And it's already on the counter and everything. And. I suppose, maybe that's maybe if I was going to think about, like, what to do or the thing you get maybe the most help with this week, like, in general, might be just to, like, how do I use or what do you guys think about, like, how I could use the stuff in front of me or. Or even, like, how would you advise me to even handle the theion with precash to be hon. 
Because that's something that I like to try to figure out. I find that preparing for stuff like that usually, well, almost 100% of the time leads to a better outcome. Like, if you if I think about it a little bit before about, like, what is. What does this person want? 
And I find that anytime I go and prepared like that, it greatly increases the chances that it will actually be a conversation to lead to other things. So, yeah, that's like so that's what's new within the last week. There's other stuff too, but like, that's probably the highlights.

**Ray | 15:40**
Okay, so that what you'd like is. Well, can you put in the form of question what would be the, you know, think a topic or question you would like to get, you know, these people's brains on for the next, you know, 42 minutes?

**Robert | 15:54**
Richard so I think the question is something along the lines of what should I do with Precaush in some way? Okay? And I know it's kind of a hard question. I mean, everybody has different levels of experience with, you know, or awareness of him and the whole things surrounding him and Zan and everything. 
But I think that's really. I don't want to underestimate, you know, what that is. That's a major conversation, that and so I want to treat it like a major conversation. I have a lot of minor conversations throughout the week. I would call that a major one.

**Ray | 16:33**
Okay, all right, let's go around here. Demetris, would you mind if I start with you, sir? Can we, you know, clarifying questions, thoughts where where's your brain at with robert's question.

**dimitris@3nuggets.io | 16:52**
I understand very well, why you count so important this conversation with Perksh, because it can unlock a couple of new opportunities for the next steps, right?

**Robert | 17:06**
Yeah.

**dimitris@3nuggets.io | 17:09**
The thing is, what about you get into this conversation with? No anymotion and surprises from your side, but get into the conversation bringing to them a lot of questions in order to understand what they want to achieve, where they want to drive the business so you can figure it out, how you can be a vulnerable partner helping them to the journey. Or if their direction is opposite in your own direction, think more seriously how you're going to handle the next steps. 
Yeah, I found myself many times in the past been so emotional getting in those conversations when someone from a big brand or someone. I thought like, wow, this guys talking to me now. Yeah, which led me to the lower position, not to the strong one. 
But I found when I bring questions, counting everyone equal to me is more valuable for both of us. It makes the conversation more clear, and so on. And it doesn't create any emotional expectations for the future before you get into there. 
So you have disappointments, for example. Now I think it's very critical to understand why he wants to get into the conversation, what he's looking, what he wants to achieve and in those conversations being open to the other, not enigmatic or strategic or just been immediate and clear. It helps them to un hide their secrets, let's say her, their thoughts and engage and find something that can have a commonplace.

**Robert | 19:14**
Yeah, no, I appreciate that. I think. I think that's what I'm trying to get to really is like, is to try to is to think about him more than to think about, my myself. And, yeah, no, so I appreciate that. 
I think, I'm. I'm trying to figure out, because usually I find, like, a end of conversations like that. It's not like the person will. I found that usually it's less likely that other person will even have an idea of what they want. 
Like even if it's a CEO of a company. Like, usually it always comes for a conversation. Like. So, like, I have found that for me to make anything happen, I usually have to be the one who's prepared with something. 
But like. But I totally take your point that, like, the attitude of the conversation. I have to balance it out somehow that, like, you know, which I'm good at, right? Like, I think maybe I'm a little too good at some sometimes. 
You know, being, very chill, would like with the conversation and everything. I probably don't think I'm I don't think I'm giving off the energy of like, that he want he wants something. I feel like the opposite. 
Maybe they might be thinking, what? What the hell does Guy even want? But and to that point, I just think, yeah, like, so yes, balanced. And then the other side of it is I think I'm just searching for like what does that takeaway like if I could have like there usually is something harmless to offer that's like a yeah, anyways, I'm just thinking out loud, so like, yeah, I appreciate it. 
Yeah.

**dimitris@3nuggets.io | 21:03**
I think from those conversations, the. The main goal is to get information you couldn't get, without joining this conversation. If you know something more after those 3045 minutes that there was no probability knowing this thing without joining this conversation, you're a winner. 
If you learn something that even Ray could tell to you. As transferring information from Parcast to Rain Ray to you, this conversation could be avoided.

**Ray | 21:48**
That's a good point. I realize the way that you express that to the what is the it's like a Telean secret. What can you learn from that conversation? You couldn learn elsewhere. Alie could bring you in the conversation, ma'am.

**Ellie Rofe | 22:04**
I mean, I don't think I've got anything as good as that. I can tell you that's absolutely ideal in terms of how to approach these things. Do you know what? Obviously, I. You and Ray have probably been discussing things, Adam, on some level over the last six months to a year. Do you know where they are at the moment, what they're trying to do?

**Robert | 22:32**
Well, I think that. No, but at the same time, yes, like I think that the answer can be that I know that they I don't think I have any idea. And I think so yes and no. You know, like, yes, I know that they have no idea. 
So I think, yeah, I my idea of Xano is honestly, I don't really. I think about things sometimes a little bit too much. If I. And I think maybe if I was maybe more dim witted about it. Probably would. It would be to my benefit. 
But like if I the more deeply the more I really think about it, I will really get into the weeds of like of Xano and like their product and everything. Like, I can go very. I can really think about it for so much that it all comes back to almost me saying, like, what? Trust me, I can come all the way, fall back, circle, like, logically and convince myself that, like I that it's better to work on something else, like just by. 
But by me convincing myself that, like, to set my horizons higher, how I and for all the reasons of like that I am not trying to pull somebody up to me. I'm just looking for opportunities that pull me up. 
And. But however, if I'm just going to look at it from just a very simple point of view. I just think that like, I enjoy using their software a lot. I think. And honestly, the reason I pick it up is not because anyone's holding a gun to my head, but because I genuinely find that it fits into my workflow better than anything else that I could find. 
And I enjoy having conversations about it. And that's really as that's the only thing I could really ask for would be maybe just more would just be to introduce to other, you know, more people who would appreciate my services. 
Like the more that I can make Xano look good if I can help them. Hitched their wagon, maybe more tightly to cloud code, if that's what they're interested in, if they're interested in being closer to the workflows that people that I've put together and that people have put up their hand to say, like, hey, I like what you're working on. 
If they're interested in that, then I can support them with that like I could I can only help with I can't otherwise like. And there is no reason to think that they would expect anything otherwise. I think maybe that's just. They're just not aware of even what. What I'm really up to. 
But the more I think about it, maybe that's just what I have to offer is just. It's my field report, I suppose from the field of being out there in the market and which does take energy to go out there and to do the things that I've done. 
So maybe that's the benefit to precaus is that I've been like a soldier out there doing this stuff, and I can come back and be like, hey, this is what this is what's going on out there. By the way, in case you're interested to know. Boots on the ground like we have. This is what's happening.

**Ellie Rofe | 25:48**
Interesting, yeah. I mean, absolutely. If you're doing the market research that they are not, then that's incredibly valuable. 
But like. So I the reason I was tapping away, by the way, a minute ago was. I was just trying to look at his socials to see what he's talking about at the moment.

**Robert | 26:02**
Two.

**Ellie Rofe | 26:05**
And the last thing he's talking about is amazing. Sal Robert Bulos from the Zano community is building. 
So he's claimed this publicly. He's excited about it publicly on LinkedIn.

**Robert | 26:15**
There's actually something there you go. Okay, this is good I didn't even know about this? Okay, I'm getting messages, this is interesting. Okay, I didn't know about this. I didn't. I didn't. I didn't even open up LinkedIn today, so I actually didn't even. I didn't even know. 
So I'm getting bombarded. Like, I'm afraid to open up my email sometimes because, I'm getting like, get one email from Perksh and then get an email from, like, the whole gamut, the whole range from, like, you know, from free to free. 
But anyway, it's not. But I appreciate it. And I think. Yeah, I'm. Now. You give me more to think about.

**Ellie Rofe | 27:07**
Well, I think it's a it gives you a beautiful opening. Because if I was preparing for this meeting, I would probably be thinking, what are my ideal things? I'd like to come out of this. In what way can this give me? Either some kind of financial relationship with Zano, some kind of partnership and publicity relationship with them, something that can help my business in some way. 
So I like that you're asking what can I do for Zano? But what can they do for you? I think those are two sides of the question that are important to ask. And I know that you're a very service mindset, but as I know, it's a big company and it's you know, they can bring something to you as well. 
Because he's trying to claim this publicly. He's ca you know, and that's not ownership of it, but he's sharing this and he's not sharing a ton at the moment, and see, I mean, just from a quick glance. 
So I'd be thinking planning in my head some examples of things that I would think are useful, acceptable, best case scenario, and then some things that I'm like, maybe if he suggests this or we talk about this, I'm not so interested because it doesn't have this upside unless something comes through in the call, but because he's done that. 
I mean, like Dimitri said, the thing you really want is information. And so. And he probably really wants information. And so I'd be like, thank you so much for calling out. What was it you really liked in it, you know, and just get him to start talking to you about it.

**Robert | 28:46**
Yeah, for sure.

**Ellie Rofe | 28:49**
What? What did you like? 
From what you saw?

**Robert | 28:54**
Yeah, I would maybe just like add that like and do something I'm wondering because. And it's nothing to do actually with. It's a bit of a different angle from any device you gave. 
So it's not like me as saying like it's not a pushback or anything. It's a different point of view, which is should I avoid actually getting into the weeds of giving a demo? I think in a certain way because I feel that like the. I don't know if Precaush actually uses Xano like or actually because there's different types of conversations like if I show if I have a conversation with somebody who's a developer and I show them the tool and everything and the tool doesn't necessarily it might have some bumps on the road or something. 
Like, the demo doesn't always go perfect for AI. If you're showing it to a builder, usually they're pretty forgiving, right? Because they know exactly, like, what it is that you're showing them and all that stuff. 
If I show it to per. KSH he might, and I my intuition tells me that it lands on him differently, though. He's like, is this thing finished? Is this thing done? Is this thing working? And so anyways, I'm just saying that like, the dog that doesn't bark, I suppose, like the. 
Just in case, like, you know, you guys give me all this good advice, and then I decide to go and share my screen and show him something that I shouldn't have shown him. So it is just kind of putting that out there like, you know, maybe there's conversations where you do a demo and there's conversations where you show it in a different way depending.

**Ellie Rofe | 30:32**
It's interesting. You'd hope that the CEO of a SAS company is aware that, you know, there are occasionally teething issues.

**Robert | 30:39**
That's what I'm afraid of, because I've had a conversation with him before, and. And really, like, it took the positive word of mouth from other people for him to like to actually initiate this next conversation, like a lot of positive like. 
I mean, it had to it's been a while since I spoke to him last, and like. And I'm just thinking about this, like. So why, you know, why is it that this guy, you know, kind of what is it that matters to him? 
Like, what is it that makes him run away from something or come closer to it and so on? But. Anyways.

**Ellie Rofe | 31:09**
Yeah, I mean, I would from the very edges of what I can.

**Robert | 31:10**
Yeah. Just stop.

**Ellie Rofe | 31:18**
I'm on the very edges of understanding much about it, but what I can gather is they aren't doing the market research work that you have been doing. I wouldn' go in there too. 
Like, I'm the underdog and I have to impress percush.

**Robert | 31:32**
Two.

**Ellie Rofe | 31:32**
You have already impressed him because he's gotten the call and he's interested on some level, and like, well, the worst case scenario is he's going to be angry. Probably not. 
Like he's just caught right in front of the entire community. So why would he be like. So just I would let him reel out as much as possible. Just ask questions like Dimitri said and just. But with an understanding of what's in this for me rather than how can I impress Prakash? 
Because it's yes, he's the CEO of a important company and a big part of your, you know, your business ecosystem. So it's not like you want to piss him off, but you have been doing stuff with their technology that they haven't been doing, you know, market connection as much as anything.

**Robert | 32:20**
True.

**Ellie Rofe | 32:23**
So.

**Robert | 32:24**
Yeah, I appreciate that.

**Ellie Rofe | 32:24**
So just hope that you do have things to offer. Otherwise you wouldn't be on that call.

**Robert | 32:33**
I'm going to try to remember that I should put it on a board behind, like the computer and say, you areorth it.

**Ellie Rofe | 32:41**
My friend's husband has got a T shirt that says I bring nothing to the table. Just imagine you're wearing one that says I bring something.

**Robert | 32:49**
I am the table.

**Ray | 32:56**
There's a lot to be said for I am the table. You know, the [Laughter] idea of, like, both the secrets and like, what can he do for you? I think are both, you know, really important, ideas like what the being able to make use of time. 
Like, what can you get from him that you couldn't get somewhere else? Right? Like, you got a little bit of backchannel stuff from me. Whatever. But like, what does he think? And this gets like, you know, both their questions, like, you know, you and you were like, hey, what are they doing? Not much. I don't know. What does he think of himself as doing, right? His self perception is going to be the biggest secret that you can get here. 
And whether you think you know, how you think that actually relates to objective reality is actually not the important part. The important part is how he sees the world. And then that allows you to understand better as someone you will be able to do business with and that that's the kind of secret you can get from him that you can't get from anything else, right? 
Yeah. So letting him talk about, like, what he thinks. And then there's a question of, like, what you can do for him. And I think every situation that' something you can do for him is something that involves him paying you or and see him hooking you up and then come and I can imagine one, two, three ways this work that could be in whatever order, right? Number one, he can be hooking you up with Xano customers. 
Yeah, I just got a report from Fazeler, VP of sales. And it actually shocks me a bit how little responsibility they take for. And, you know, the client tried this initiative and didn't work out, and that's why we lost them. That means they're not our ICP. No, they weren't involved in making it successful, right? 
And that's something you provide. Like you can help make things more successful. You help things go radically faster, become much more useful. Like there there's a whole story about, like, the stuff you've been doing with Scott. You were involved in collab work, which is a success story that they are crowing about internally. 
And whatever you may think about your relationship with those folks over there, like that's that sort of is in the wind column you associate with, you know, so like there's there you're associated with like children who wins. 
And I think there's a let's put Robert in more of these clients because when clients spend money on Robert, they're more likely to keep spending money on Xano, and that's a pretty good trade for them.

**Robert | 35:14**
Yeah. You know.

**Ray | 35:15**
So that. That become, like, the easiest form of it. Yeah, I think the second form of it, I think is a and I think this is actually very unlikely, given what I've seen the past, but like, it's out there. Is Xano hiring you for something? 
Right now the thing, Sams only got so much money whatever. But the, but you know, I know I've advocated for Crash before, like, that he's told Harry, you, and the I'm not sure that's a best deal for you, but I do think it's like a really good deal for him. 
So the. So I can see something going down the road of like either doing something for Xano or whatever in terms of like, you know, potentially like teaching more about Claude code and like what kind of value you've been able to get out of this. This is the kind of thing where there's nothing but value for you because you are not competing with their MCP this is something we've talked about a little bit before. The more they get their stuff in gear in terms of having better MCP, and the more the Zoho more like the snappy MCP server is not liable for you, the more you're going to get paid. 
Yeah, because you will be able to derisk like they just want to take all of Snappy. MC PAGE they're gonna care less about how you build it. They're going to have their own ideas about how they want to build things for the insights you have within it. Hey, you got too many tools. Let's talk about their tooling. Whatever. You being able to do a consulting call with other people, I think, is a way that you might be able to make, you know, non trivial money. I can see them buying like a pack of hours from you in order to be able to educate their people on a on AI and a Gennic building using Xano. 
And having seen how they're doing it internally, they could use the education now, whether they see that themselves or not. That, like, falls in the category of secrets, right? That you can get like something that only precasal knows how he perceives that situation. 
But I do think a great way for them to make money from you because it would improve their product for relatively short outlay. And you'd be able to. You know. And. And. And then I think would like I say it would improve your position, right? 
Because since you are core to that, that's a much stronger position. It's not the MCP because it's third party and any of the snappy skills which are third party. The closer the third party is to being about Robert, the bigger the one it is for you. The closer the party tools are being about Xano, the more risk you're introducing into it. People want the Xano stuff to be from Zan and they want the you stuff to be from you. 
And like the more you're able to create that the market, the more money you're going to make. That's something you even be willing to potentially give away. I don't think you have to. I think there's money to be made in the middle. The third categories of buying SA and like acquiring the intellectual property to like the stuff that you do and like having you be in their professional services, this falls in the category like how they would hire you and how they would, you know, they sort of hire you out. 
I think this is probably the heaviest lift. But like when you're having these conversations, every conversation you have with somebody else in New York ecosystem is as acquisition as an undercurrent, right? M&A is always undercurrent whenever you're talking to another player big, small, whatever you're building relationships for, whatever that ultimate transaction might be. 
Yeah, so I'd just be paying attention to that. I don't think there's anything that happens super short term. I think it's much more likely to be in the first two categories, of which the first one doesn't involveter nickel. 
Yeah, but that but the where they are, how they see themselves, how they see their AI or accelerated development initiatives, these are things that you can learn about and then that puts you in a better position to be able to serve them better.

**Robert | 38:55**
Yeah, and I'm pretty. Yeah.

**Ray | 38:56**
The more then, the more you get paid, either by them, by their customers, by somebody.

**Robert | 39:01**
That actually really helps. I think. I really think that actually there is a very easy to make the first category, especially the where because of the fact of like the. I know the positive words that he's received about me because I have literally seen, like, my client, like, share their screen while they would show me, like, what they're typing, like, into the select, like, to send it off to people. 
So I know the messages that he's getting. I it wouldn't be very hard for me to imagine that. Like, it would make him happy to know that. And it is very easy to like to offer that, but it would make him happy to know that he could basically just direct people towards me and he'll know that I'll take care of them and that I'll. 
You know, it's a short term thing. And then probably the most. Like the. Like something that I could definitely achieve out of the conversation on Friday. But I think the second one that you mentioned. Actually, I didn't think about that at all. 
But it does depend on, as you said, like, how he views the world and, like, what he perceives to be true and not true. But. But there is. But I do genuinely think that if they were to, become better, if that's the problem, like then for them to become better at a genenttic building. 
I think that is something I could definitely, like, helped them with. It would not just help them with. But I think that they could make the use out of it more than anybody else. That. That anyone that I could possibly think of, obviously, because they could just turn around and just go crazy with the marketing around all of that if they were just able to do it more themselves and just build on that stuff. 
So okay, just that was helpful. Thank you. I need actually already feel actually I feel ready for the conversation already bring them in, roll them in, but I think, no, I'm gonna, how would you prepare maybe that's another maybe. 
That's a question like, would you like from here? Like if you were just in my position. And now you have the rest of your week coming along, and you're going to have conversations like this coming up. I'm kind of curious about that. 
Like for yourselves, like alien Demetris, how do you prepare if you're in my shoes? But in general like you. Like I said, you have something coming up. You want to have this conversation. You feel like you're mostly ready, but is there something that you prefer to that you like to do in general? 
Like do you know, to tap something in front of you or maybe not, but just want to see if there's any hard won lessons there as video.

**Ray | 41:52**
Yeah. Sorry, I was just since we.

**Ellie Rofe | 41:55**
You go to me.

**Ray | 41:58**
I was offering to start with LA since we started with you last time. Doings.

**Ellie Rofe | 42:01**
Alright? Well, I, as you can tell immediately, as soon as you mentioned the meeting, I went onto his socials. I want to know what people are thinking, what they're saying. I'm nosy. I am. I would even possibly. I don't know if you remember when I showed you that DA prompt I had. 
Like, I can't remember the prompt because I haven't opened deer in a while, but, like, chuck it into his X account's LinkedIn and like, get. Get a vibe of him. Not that it actually really matters. It's not like you have to rehearse or understand all that detail or it's going to radically shift the meeting. 
I think for me, it's just a case of pushing my mind into, like, who is this person I'm talking to? And what we're going to chat about. Mostly, I would do some real daydreaming about what I actually want.

**Robert | 42:44**
Yeah.

**Ellie Rofe | 42:48**
What would be the most exciting thing for me? 
And where there might be, I guess, instinctively, because my background. I do a little bit of like, I guess, informal SWAT analysis, right? Where I'm like, what are the potential opportunities, what are the potential threats, et cetera? 
So it would really vary depending on the tone of the meeting. What I think might be there. But I think daydreaming is fun as long as you don't hang too many hopes on it. But because it starts to categorize what you like, gut instinct, what you actually really want from this and everything else is obviously negotiable.

**Robert | 43:20**
Yeah.

**Ellie Rofe | 43:31**
But no, I think for me, I like a lot of information, even if I never use it. I'm a bit more of a like suck it all in. Just understand it. Because sometimes you can be chatting about something and then they mention something and you go, yeah, I remember I saw that. Or, you know, whatever it might be. 
And it feels like a connection to them. It feels like you've prepped a bit and taken the meeting seriously. But, you know, there's.

**Ray | 43:55**
Two.

**Ellie Rofe | 43:55**
But. But I wouldn't. I think what I wouldn't be doing is thinking that meeting is going to be an outcome. I just think it's gonna be something really interesting and Demetrius's point holds 100%. What can I find out? 
Like be like Sherlotte?

**Robert | 44:11**
Yeah, cool.

**Ellie Rofe | 44:12**
What? What information can I gather? What clues can I get as to what the future might be?

**Robert | 44:18**
No, I appreciate that, thank you.

**Ray | 44:24**
St so on shit does what do you think?

**dimitris@3nuggets.io | 44:30**
You for preparation for meetings, it depends always on the purpose of the meeting and the input. Okay, so if it's an introductory call, we. It depends on what other information you have on your hands, how you can use them in general. My preparation, except the cases where I have to present something, it's mostly ten minutes ago so I can have refreshed this, information, not forget anything. 
I will get better to know who is the guy, what he's looking, mostly. Okay, so that's it. And I'll bring down some notes. What would be the mast and the mass of this conversation. How I would love to guide this conversation. 
And for example, amast is to accept the request of a very low price when it is requested. Okay, these kind of things can be requested. Things that I may hesitate to support during the conversation. Putting in a rectangle, my guidelines. 
Okay. Mass two lines, masts and the other two lines. And I be there. And I find conversations are more valuable for the other side. So they want to engage with me again and again. When they spend more time talking. 
So the more questions they bring to me, the better. So what I do is from the conversation and trying to bring them valuable questions, things that nobody else would let them think. So what? What happened from that approach people? It happens a lot. They came to me and said, Wow, nobody mentioned that. I never thought about it. This shows how you think and I like it. 
Yeah, they count me as a as more strategic thinker, putting the complex things in boxes so I can manage them, these kind of things, but just getting into the conversation, I would say, bringing questions, being open, and that's all. This is it. In the past, I used to do more work. One two hours before. I wanted to scan the guy's LinkedIn profile. I want toy search for him on Instagram on Facebook, see what's going on.

**Robert | 47:26**
Bullit, right? Yeah, no, I appreciate that. I think, I would maybe I'll ask you guys this. This would be interesting if you think if it's a good way to look at it in general that. For certain people or for certain conversations. Or if you take people in general, you can put them into two buckets. 
Like they're either experienced or they're not experienced buyers. And, that experienced buyers will have, like, a certain type of conversation with you. And that inexperienced buyers will have another type of conversation. 
And if I speak to an experienced buyer the way that I would speak to an inexperienced buyer, it would piss them off. And if I did the vice versa, it would. It wouldn't. The inexperienced buyer doesn't want to hear necessarily the pragmatic things they want to hear about their dreams and like and that stuff versus the experience by has heard that shit before and they just want you to kind of like, you know, just maybe necessarily just get to it. 
So. I don't know. I like to try to have frameworks in my mind, but just. And all that stuff, I bring it in with me, so I'm just voicing it in case there's anything to push back on. But I thank you. I appreciate it.

**Ray | 48:57**
Yeah, the, can I ask about the when for each of you as you consider the question preparing for the meeting. Me just you alluded to the ten minutes ago thing, which I thought was interesting. Like sort of how do you think about the time directly before or the longer time horizon for program for meeting.

**dimitris@3nuggets.io | 49:18**
What do you mean with the question of the when.

**Ray | 49:21**
Well, like, when do you put in the time to be preparing, presenting your brain for the beating? It's kind of what I'm getting at.

**dimitris@3nuggets.io | 49:28**
When I started using this approach. You mean?

**Ray | 49:33**
Robert has a meeting sometime on Friday afternoon? Let's say 2 pm Friday afternoon, right? But allocating time to, you know, to preparing for an important meeting. What time before 2 pm Friday afternoon would you allocate? 
Right. For preparing, you know, for that meaning for doing the kinds of mental exercise. Mental and research exercisely. They've both been talking about.

**dimitris@3nuggets.io | 49:59**
2030 minutes before the call maximum. Otherwise, you know what you start you bringing imaginations, the brain get gets more emotional and starts, you know, it starts another trip, it goes for holidays, right? 
It's dreaming in this conversation we have to be logic say more.

**Robert | 50:30**
I'm sorry, because I wanted to ask one more question because. Sure. I actually have AI have a meeting in 7min with Luke and Lu is like I don't know how to describe it, but like. But I think Maxie Ray, you probably put it best on once to me. 
I think you told me he's a bad entrepreneur or something along those lines. And I think I understand what, like what you mean by that, because he. I just feel like he just wastes my time a lot. Honestly, not in a bad way. 
Like, he's a great friend to have. He's very. He's funny. Like. I mean, he's great to have in a group meeting, I suppose, like, but whenever it comes down to, like, okay, we're going to do this XYZ. He just likes to haggle a lot, and it just immediately just makes me feel like focusing on other things. 
So I have a meeting with him now in six minutes, and I'm. And I know that I'm going to get into this conversation with him. And. And yeah, I don't know, Lu. Like there's a few people who kind of fit into this bucket where like, they really, they are again, like not the people who are gonna necessarily like they're not the opportunities that are going to transform my, you know, my business and life or anything. 
But and I'm trying to figure out, like, how to handle them and give them what they need, but at the same time, not not be like having just, like, Groundhog Day type of like, you know, repeating the same conversation with them. 
It's like, okay, now what next? What now what next? It's like. I think that this nicer feeling when things are moving ahead and when things are moving forward, it is. It's better for everybody. And so, yeah, I just wanted to just kind of raise that because, like, today it's Luke Tomor at somebody else. 
Like, I think as I as I'm doing better and better, there's other versions of this, right? Like they are going to keep coming. So it's not so much about like how do I handle Luke? It's more the question is just the situation in general to apply it as a framework. 
And so yeah, but you know, within this case, it's like this conversation coming up, but hopefully that makes sense. I just want to raise that.

**Ray | 53:11**
Well, okay, can we put that in the form of question for a second? I appreciate your express concern about like the. The use of time with OP, which is the meeting and format. So I'm sort of going to look for. I'm trying to get that, you know, the concission so that we can get Ellie and Betrice each. Give you six seconds on the subject to help you out for the next meeting.

**Robert | 53:32**
Basically, how do you deal with somebody who wants to, I it doesn't. I feel like the every way that I tried to get the words kind of mouth always sounds. It just sounds mean. How do you deal with somebody who just likes to haggle with you? He's a much nicer person than I'm making it sound, but, like. 
But someone you get along with, and you're helping them out and everything, but they want maybe a little bit more than what they're willing to necessarily pay for. Or like, do you or do you just say, screw it? 
Like, I'm just gonna, like, tell them what the price is, and then this guy's not really and just and that's said, just move on with it. He wants to pay it, he wants to pay it, he doesn't goodbye. Is that just what it boils down to?

**Ray | 54:31**
Okay, six seconds each. Do we just share with you?

**dimitris@3nuggets.io | 54:34**
Yeah, one thing comes to my mind is that, you want to be negative, but at the same time, do it politely, right? And you're a very polite person. So I see the opportunity if you raise your price for this guy. 
But I don't know if that's the right one, the right thing. When this similar situation came to me, what I did was to bring them exercises. So look for the next time we have to do this thing before that thing you're going to do. 
If he avoid to do it means he's a crocodile. All the time. He wants you. Go and build for him. Then you can politely explain to them that you know this is how we have to work. If you don't like it. I'm very glad to meet you with Ray because Ray is very good in doing that. 
And you're going to have a good match. Thanks. If he likes that. Maybe you get the opportunity to convert this crocodile to a available bird.

**Robert | 55:42**
Yeah.

**Ellie Rofe | 55:47**
And I would probably start asking myself as a general question, am I what a my indexing higher on? And it's a slightly forced dichotomy, but bear with me. Service or leadership.

**Robert | 55:59**
One.

**Ellie Rofe | 56:00**
Because I think that one of the things I've realized and it's a shift into consultancy versus being a service provider is that you have to show leadership to clients and that is the form of service. And I think sometimes I get the sense that being deferential feels like service, but leadership can be service. 
And that would be my sort of underlying question.

**Robert | 56:30**
That was just really very good point actually I never thought about that.

**Ray | 56:35**
That was gold. Yes, think about this in terms of leadership and subservice is a fantastic approach. It elevates you, right? Keeps you from. Well, this guy's just sort of a tire kicker. No, maybe he's a guy who's in need of leadership, which is not the same thing as being in need of service. 
And then you can decide how you can provide him with that leadership. And leadership comes in small doses.

**Robert | 56:56**
Yeah, I would just say that really actually that. Yeah, I didn't ever really think about that. And I think part of it might be. It's gonna sound funny, but, like, I think part of it just might be the a lot of time of having conversations with, like, at least within this context. They're older than me. By like, at least like a at least within a conversation I've had by a noticeable amount. 
Like, obviously, they are obviously older than me, so sometimes I feel, just to like. I don't want to say, like, I'm just treating them. I don't I hold myself back a little bit, like to I don't want to necessarily feel like, I'm talking like I'm, you know, talking to them as if they're. 
Yeah, as if I'm their leader. But actually to the. The truth is now if I really do think about it that probably is the case like that should just treat it that wa so thank you. I genuinely never thought about that and that's helpful.

**Ray | 58:04**
That's so cool and I really love the way that putting yourself in leadership mindset.

**Robert | 58:08**
Don't I take it with in like in 60 seconds. Yeah.

**Ray | 58:12**
All right, go forward be gents and Gary, those secrets thank you. All this has been fantastic. We'll do again. Thanks.

