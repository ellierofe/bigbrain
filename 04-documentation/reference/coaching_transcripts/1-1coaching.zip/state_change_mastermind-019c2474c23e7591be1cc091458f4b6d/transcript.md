# State Change Mastermind - Feb, 03

# Transcript
**Robert | 00:02**
Hello.

**Ray | 00:03**
Hey Robert.

**Robert | 00:05**
Hey Ray, how are you?

**Ray | 00:07**
All right sir Dimitri, I see you sir and Li as is Claude.

**Ellie Rofe | 00:14**
No.

**Robert | 00:19**
Or is it just me?

**Ray | 00:20**
Sorry.

**Robert | 00:21**
What is Claude down for anybody else or is it just me?

**Ellie Rofe | 00:25**
It's just work for me now.

**Robert | 00:29**
It's working. Working for everybody tries to survive.

**Demitris | 00:35**
Which means I have some troubles. But at the moment, it works. API works, but not pretty. Well, I had some errors not expected once back and forth.

**Robert | 00:51**
Okay, cool.

**Ray | 00:53**
I might just quickly say, Ellie, I appreciate, like, it's just a different angle on the same room, but I think your backdrop seems quite nicely composed.

**Ellie Rofe | 01:02**
Yes, we're getting now I've done a like quarter turn and hilariously, I dug out about 7000 different old film equipment bits and bobs and then just worked out.

**Robert | 01:02**
Yeah.

**Ellie Rofe | 01:14**
The best is a MacBook. There we go.

**Ray | 01:17**
And then I just tilted a little bit, and like, all of a sudden, yeah, it's, yeah, but it really does look, you know, nice.

**Ellie Rofe | 01:21**
Yeah.

**Ray | 01:25**
I like a little bit of window. I like the lights behind you.

**Robert | 01:28**
It's all for guys.

**Ellie Rofe | 01:30**
Thank you.

**Ray | 01:32**
Okay, well, let's get into it, let's go around the horn. What kind of what was true today? That was not true week ago, and then. Robert, it's your hot seat today. We'll get into it with you. So with all that in mind. Ellie, can we start with you?

**Ellie Rofe | 01:49**
What is true today, there's sort of stepping stone. Good news in that I spoke with Maddy. Either the robotics or materials or client. And she's got a third of the money committed so far, which isn't too bad. She's been out for less than a month with the new deck and, it was really interesting. I was really. I really appreciate her sharing it that she shared a transcript a fathom transcripts of the video as well of a call with an investor and I got to see some a it's always great. 
It's useful for me to see how the investors are asking questions, but I want to see how some of how she was responding to questions and helped cope through a bit more on tightening up things that because she's an engineer, she was like, it's the future. We don't know what will happen because she's like, I haven't been able to measure that and give me some coaching on that. 
And potential progress with the SDP, potential progress with UBS so there's sort of lots of things bubbling away. And I'm trying to make more connections on LinkedIn, and as of tomorrow, I'll be working on sort of trying to get a bit better. 
I've been trying to get some sort of system to get more content out there, but that's, slowing down. I am doing an interview tomorrow. I've got another person who said yes, I need to just send out some more invites. 
So we're getting there. We're getting there.

**Ray | 03:22**
Super cool. Yeah, the great thing. I mean, as sort of realized having done recorded like, you know, six or seven interviews or, you know, sort of BIGDCAST style things over the course of last week like, wait. That turns into a lot of content because you know, then you can do Schwartz or whatever out of it. 
So it's so much easier to cut it down, right, than to than start with blank sheet paper.

**Ellie Rofe | 03:45**
Yeah, that's what I'm hoping. That I just get more and more insights and interesting things to talk about from talking with other people. And that would be nice.

**Robert | 03:52**
Sure.

**Ray | 03:54**
That sounds fantastic. I can't wait for it. 
Deters, can we check in with you? What kind? What was true today was that two week ago.

**Demitris | 04:04**
I had, I processed guys, the update on the service I was working on. We reviewed it last week together and I found very useful all these updates and mostly the preparation feature so I can prepare the analysis for a couple of transcripts and transferred to the other user so he can find it prepared for him because it takes some time to be completed. 
And now I'm focusing mostly on putting content into the market, into LinkedIn and on YouTube. And at the same time, I'm trying to get in contact with salespeople, revenue people, all of these kind of group of people and professionals. 
So I can start a conversation where instead of trying to make a cold out rat figure out which are their main troubles, what kind of questions they may have. So, I can start warming up a conversation with them. 
So later on I can invite them to use it. And the a guy who is a sales consultant and he has a pretty defined framework for his clients contacted me before Christmas. He scheduled a call with me on Friday, the upcoming Friday to get started with. He asked me to do the, configuration with the MCP using chat PT and he gave me a nice opportunity to learn how to do it because I didn't know that. 
And I figured out that itok me more than finishing a marathon. Which is crazy. [Laughter] Yeah, because there are many dependencies to do it in terms of the massine. Because the communication is not like how it communicates from Claude side. 
It's quite technical part. It was an opportunity to have a better learning on that. But the thing is, you build a server inside your machine, you use a middle network service like Claude and Claude talks with your machine and transfer the information to P and back and forth. 
And all this triangle is quite technical. Special specifically for non technical people. Which that's my approach. And I find it so weird, but the thing is, most of those people prefer using just TPT.

**Ray | 06:47**
That's a good point. Yeah. And then the, so right now the server you're using is a local server, right? M px style or u vx or something. Yeah, and then and you're sort of going through the dance in order to be able to route it through a network. 
So yeah, okay, cool that in well, actually, it's cool that you've found this neat point of friction, right? That you might be able to do something about in terms of fasilting people's ability to work with their tech. 
That's really neat, man, very neat. Okay, the and Robert, can we turn to you, sir? You know, was true today. That was not true, I guess. Last time we saw it two weeks ago. And how can this group be a service to you and help you have the maximum good week, you know.

**Robert | 07:42**
Ahead for sure. And, sorry about that. Last week I was. I touched base with Ray afterwards, but just was sick. And. And. Yeah, that wasn't a good day for me, but. So just apologies that I wasn't able to make it last week and. 
And Demetris, like, I would be happy to help with the MCP stuff. Like, I'm pretty sure that, you know, we could probably. I could probably help make it less than a marathon. And as far as what's true today, that's not that wasn't true a week ago. I would say I've been developing, like my system that I've trying to use it as a way to, you know, be able to create more content and. 
And just be, using it to respond to things more quickly and just offload things. And just try to see if I can turn it into, content at the same time. Just hit a few targets all at once and it's pretty cool. I'm trying to leverage it, though, to make it something that turns the wheel for the. For the business as soon as it possibly can. 
And I have some interesting meetings, I think, coming up, like today and this week. And one of them is interesting just because he has an interesting email. It's leo@autoparts.com, so it's business email Leo at Auto Parts, he has no message, he has nothing, no other provided. 
It's just somebody named Leo and he works auto parts. So, and then I have another meeting with somebody who actually Perkash has. Described to me as an investor who want to get in touch. And that's all I know about that as well. 
And I have that on Friday. So those are interesting. Conversations, they stand out a little bit as opposed to somebody who wants to set up Claude Code, right? Like, there's a few different types of conversations. 
And yeah, and actually, I'll show you this because I think this is kind of cool. I'm gonna share my screen really quickly. So I'm getting. You've probably heard of Claude Bot by now or Mult Bot or open Claude. 
So I actually have one running on Digital Ocean on a droplet. And now slowly, it's all coming together. My master plan. You can see, like. Okay, so intelligence is being added to this. It's adding in context is pulling out actions. 
And I'm starting to test now dispatching those actions over to the Claude boot, right? And like, I'm starting to get back responses like, you know, what's the color? You know? And then this was actually the Claude response. 
So that was just like, I only started this like an hour ago. And then I had some technical issues with Claude, but now I'm back. I'm using Gemini now. But anyways, so I'm just trying to see if I can take everything or many things as much as possible and then start to, you know, basically turn 95% of my work into like a video game or like where I'm just clicking. I'm saying dispatch. Go do the work. 
And then we'll see what I do with my day from there. I suppose what is left? I'm not really sure after all that, but that would be kind of cool to find out.

**Ray | 11:46**
Super cool. All right. So, you know, the it sounds like you got a bunch of interesting stuff in terms of the progress of the business. What, how can you put this group to work to be helping you make, you know, make more progress, make more profit in the course of next week.

**Robert | 12:10**
But I'm always open to, I think, advice on, you know, like, should I just start to what you think I should even just do with the stuff in front of me? I think. Right? Because I think that I'm. There's a lot of stuff that I'm always bouncing between and working on. 
And. And so there's. I'm not always going to see all the things that I could do or all the things that I could actually take action on, which is kind of the point of the things that I'm doing here. It's like to tie together all the dots. 
So if there are low hanging fruit, like. I guess my question would be like, is there anything easy that you'd think that I could do? That would, you know, just be a good idea for me to do. And then and that and then that would be, I think, great. Those are high leverage things to me. 
You know, should I, for example, if I if I'm looking at this, am I missing an opportunity to share it, maybe more openly? I would say, like earlier on, am I over focused on it? I'm not sure. Like.

**Ray | 13:36**
Okay, well, open before looking for. Based on what you've heard so far about what Robert was doing and what he's been hearing, what's your counsel of what you think maybe he should be doing? I think that's what we're. Is that a good restatement of your question?

**Robert | 13:51**
Yeah, I just want to make sure that I just have a good perspective, and I'm not drinking my own coolid, basically. Okay.

**Ray | 13:57**
Well, Ellie, can we start with you? And sort of. Can we bring the uncool aid to it?

**Ellie Rofe | 14:03**
[Laughter] you're saying I'm on cool, that's very unfair.

**Ray | 14:07**
[Laughter].

**Ellie Rofe | 14:13**
The it's fine, I'm not the, I think sharing that is really interesting. I like talking through or what your thinking is behind it. 
Because the beauty is you're building stuff, and that's you're building something for yourself. But it shows how you think about building stuff and what you can achieve. And, you know, how you're looking at it sounds like you're trying to integrate a lot of things to remove multiple points of friction to help with, you know, making your day more fun and more interesting. 
Like you said, making it like a video game rather than, you know, having to dive into 17 different bits of software and it all feel boring. I think that's great. Like, keep talking about that. Keep sharing it wherever. 
Like in your own snappy group and on LinkedIn and wherever else you think that's useful marketing.

**Robert | 15:07**
Okay. And you would say that, is it AI guess it's kind of. Is it feasible, I suppose, or is it a good way to, even run a business? Like, I suppose, like for me to. And then that's something I don't really know because I like, but I'm just wondering, yeah, like as I want to share it. I'm kind of wondering, yeah, is it the right direction? I think, like, for.

**Ellie Rofe | 15:46**
Well, I think you can share. I mean, there have been really interesting, like run it as an experiment. Answer your own question, is this a good way to run a business?

**Demitris | 15:57**
Yeah, sure.

**Ellie Rofe | 16:01**
I left, you know, MCP servers and Claude and whatever else run business for two weeks. This is what happened.

**Robert | 16:10**
Yeah, that's actually good.

**Ellie Rofe | 16:12**
Yeah, like exactly.

**Robert | 16:13**
Just turn it into, like, a public experiment, like when David Blaine freezes himself into, like, a block of ice or something.

**Ellie Rofe | 16:23**
Yeah, people love those experiments as well, because they feel honest. They feel like you're not kind of just talking, you're not shaping a narrative, you're just going. Here's what happened. Join me.

**Robert | 16:33**
Yeah, no, it's cool. I appreciate that. I like that perspective on it. It makes it more fun. It's like.

**Ray | 16:46**
Can we just give me get you away in here? Your thoughts are. Yeah.

**Demitris | 16:53**
What makes you, thinking yourself, like that?

**Robert | 17:01**
Think of the.

**Demitris | 17:03**
Where do you count yourself as not cool or overthinking on these things?

**Robert | 17:12**
No, but overthink. Sorry, did I say I'm not cool? [Laughter].

**Demitris | 17:20**
This is what they understood. I'm cool.

**Robert | 17:24**
No, I think I was saying that I. I think I was saying I didn't want to drink my own Kool Aid. So I don't want to, like, delude myself, like, into, you know, into thinking. I guess, just to. Sometimes I don't want to be like. 
I think I'd know that this is seems like it's sometimes a lot of assumptions. It's easy to. I've seen other people really fall in love with their own ideas. Like, you know, and you learn stuff in the future. 
And certainly I look back into the past, and I recognized that some of my ideas were bad. So I'm wondering if like if the. Yeah, I was trying to get some of that. I suppose I'm trying to always leave myself exposed to like, just, I think any anything that I could be missing and I'm inviting criticism, I suppose that is what I'm saying.

**Demitris | 18:29**
I wouldn't say that there are bad ideas in general, not only for your or race or at least anybody's ideas are bad. E when we look in the past, we can figure out ideas that didn't work for some reason, or they worked pretty well for another reason. 
And the most important is to focus in the future, because the past is past and we cannot change it. What you can keep from back there is the learnings. So the ideas you tested and worked on them in the past can used for the future. 
And I see that many ideas fail before one succeed. You don't want every idea to be a successful idea. You just want the one that can succeed for you. And looking back, I know you more than one year now. 
Look what happened back. Yeah, you are the first guy who build the ch Deelic MCP service, which you build an MCP server building other MCP servers, which is crazy. Even if we tell it's home, you cannot fill it. 
And another many things. You adopt the new technology in the new GERS way fast and you build them very fast. So this is a huge strength on you now, the way you see those things being applied. It depends on your what's coming up in your environment. 
Maybe you are sitting with so technical people instead of you're sitting with business people or people who could be your ICP so you could, you know, give them the release in their hand and start building further on their direction instead of building on your own direction. 
And maybe this causes you thinking like that.

**Robert | 20:45**
I appreciate that. And that's really interesting. When you mentioned, that actually when you're sitting in a conversation with a person who's much more business minded and then you start to talk about the things that you're working on and they automatically don't want you to do it for yourself, they just want you to do it for them. 
That's all they want. They just want you to do the same thing that you're doing. Just do it for them. And that's. But that's really interesting because it's. It is. Yeah. It's just like. It depends on the room that you're sitting in, right? 
Like, if you're speaking, though, with technical people, then you're just going to kind of like, play ping pong with each other, which is great, right? Like, which is fun, but now it's true, more conversations being had. Thank you.

**Ray | 21:42**
You know, the there's a current in here, right? Of what are you doing internally, what are you doing externally, right? And the, I think of this as like a circle, right? And you got your. The. The. The perimeter right of the circle. 
And then you have the area right that's sitting inside it. And as you increase the size of a circle, you change basically the ratio of, like the size of the area in the middle to the perimeter on the outside. 
Yeah. And I think as you get larger, you have, you know, more stuff on the inside than you have on the outside, right? I sort of imagine like, you know, taking all the people in the company and being able and stuffing them as close as you can to each other, right? How many of them would be on the outside? 
And then those people should be focused on the outside, right? And when you are solo or very small, it's easy to see that. Like, everybody's job is to be on the outside. And the trick is. And you still need to invest right in, like, building things up, but you're looking for, like. How can you be going back and forth? This gets like Ellie's point, like it's compelling content. The trick is building in public, you know, the thing where people go sideways building in public is they build to their other builder friends, right? 
And not necessarily to their market, which is why what you really want to do is serve in public. So I might propose that like there's you know what creates utility for you are things that like allow you to either, you know, study or sell, right? The only private work you should be doing really is for shipping, right? Or for the accumulation of secrets and then you can be sharing with the world because they're going to be the things that like are your you know downstream you know value because they form your equity like you're a technical secrets your market secrets and your market reputation right? Your foundational, you know value that you have you know as business. 
So I think you know what I was listening to. LI I was thinking about a line from Darma Shah of Hostpot talking about how, every media company has is starting to have a tech company inside and every tech company is starting to have a media company, you know, inside because these things just sort of go hand in hand, right? You need technology to do media, so you actually have an advantage for it, something you've already seen like that remotion stuff you've been doing. You're sort of seen an example of that, right? 
But that's yeah, it's a technical example of that's technical advantage you have on the media side. And then you've already seen I hope you've already seen how compelling your content can be, particularly when you're doing it in conversation with people. 
And that's been sort of a high value place for you to be, you know, as well. And I sort of think about, like this flow that I'm hearing of, you know, that this sort of pointing me in the direction of how can you be taking these things you're doing for yourself and letting other people know about them? 
So that they can say, wait, that's awesome. I want that to happen to me. Because you're then inspiring them, right, in a direction of how their business could be better as a result of this technology. 
Otherwise, you're in a position of saying, hey, I do, just to completely cartoonize it, you know, I do, you know, Agentic building in Xano. They're like, what do I care about now? But like, a lot of the stuff you're showing far more compelling, right? 
Like this is, you know, agentically being able to get X done, you know, and like, there's a little bit of like you're doing some technical setup and like the frankly, the, you know, what color is the sky is a cute example, but not actually showing value yet. 
But as it does things for you know, doing more of that in public is going to be valuable, right? Because other people say, wait, hey, there's something there. And then, like, how do you do that? And I actually think that the thing you've already done in done is compelling which is just have the meetings right you talking to are people you short are people them going o and that's compelling content. 
It's like the easiest thing in the world for you to make too, because it's like, you know, instead of you making a video where you're prepping and then you've got to go stare at the screen, like, what's that stuff going to look like? Do all those things too, to the extent they're easy for you. 
But like how can you decrease the cost of that production so that you can be, you know, sharing more of that, you know, both, you know, because I think that the more you share, the more it's, you know, to reach this point, it becomes more useful to the business audience, right? 
Because it's about the application of it, and to, you know, to Ellie's point. It's authentic, you know, and how can you just sort of show more Robert out there? Because I think Robert is what's compelling. I was just having I had a conversation. 
Well, you know, we're all friends here. I just had a conversation with Scott Lusso over at Asian Dashboards, they're dumping in very soon.

**Robert | 26:32**
Really?

**Ray | 26:33**
So.

**Demitris | 26:34**
Didn't get it.

**Robert | 26:35**
So what?

**Demitris | 26:37**
So? I didn't get what you said. What? This conversation was called Xano.

**Ray | 26:43**
Which is a you know the backend system that like they've been using they're not lone people are dumping it off.

**Robert | 26:52**
I have a meeting with him actually after in half an hour or so.

**Ray | 26:55**
And there's in confidence and he didn't share with me to share it with you, but like the. But my, you know, my impression is like they're hitting walls right with you know, and like you're making things go faster, but like you're you basically you are you're fixing the thing that is just continuing to leak and be broken, right? 
And yeah, down road to let's go build on something else, which seems about right. And we've already had the conversation, you and me, about like, you know, some other technology you can be building on top of. 
Yeah, but the reason that I bring that up is that makes the point about, you know, authentic about ellie's point about, like, being in the market, sharing with more people, you know, being authentically you. Demetrius's point about like, sharing more about like what's going on with the utility of what you're doing, especially since it's really not based on Zoho and that so much easier for you to be, you know, growing a practice, you know, in more fertile soil. 
Yeah, right. Which is the business problem to try and solve and then the technologies you use to do it. I just got a voice message from another state changer who is switching project entirely from like Xano to using Convex and is over the moon about Convex. 
So glad that I TED about Convex like cross exam of that business. But that that's sort of is what's happening here, right? But the. But like to the extent that you're talking about how to solve problems and how to do it with technology, they have a higher degree of trust in there's a lot to be done there, you know? 
So yeah, the all of which is by way of saying that like I think you take the confluence of what Ellie and DA are saying there's, you know, of what are the business problems, right? And be sharing those out there in a way that is easier for you to share. There's a lot of money to be made.

**Robert | 28:48**
That's really interesting points, actually, and I think that's a really good point about. But talking about different technologies, I've only kind of just realized that even though I was building everything on Xano, but as I built more of a frontend for it and it showed how it was actually, you know, the front end just puts it into context so that people then can see like the results of it. 
And so then it those posts actually started to perform, noticeably better. I just noticed, as you were kind of as you were saying that like I just started thinking about it. So I think, yeah, that kind of to do more of that would seem like a good idea, obviously, and I think, yeah, like when it comes to the thing with Scott, one thing I've realized is that not everyone can use a tool as good as I can. 
So, I think there's quite a learning curve to being really effective with building on Xano agentically. And I think that, yeah, that's the thing. I'm not sure. It depends on really how far a person wants to go with it, but, there's only so much I can do, really, by myself. 
I think part of the point is to enable Scott, to enable him. So yeah, I just have to think about what that looks like because I ultimately I'm trying to think of like there are people who don't who like it being Ontano. 
But ultimately, the company itself needs to survive. Like whether or not I like it or not, it needs to stick around. So yeah, it just kind of makes me think about, you know, the other technologies. 
Okay. Thank you. I heard you told me just to say, like, what if I it's not for me to think about, so all I can really say is thank you.

**Ray | 31:09**
If you're out there, you're experimenting with more stuff and you're sharing it in the way that Ellie was talking about. Right? And you are. You know, you can talk about Cortec, but like, I think you know, be talking about, like, how it is useful for you, the fact you're building this stuff. You, I think is a really good hook is like how I'm helping my business. 
And it's like, yeah, people and say, hey, I want some of that. How can I get that? And people will be tempted to say, can I just sort of buy that product for you? Which is not exactly even the right way for them to be thinking about it. 
Yeah, but the. But the idea but like if you have more and more better ideas of like how you can have this thing that sort of is wrapping around you. I think that gets to be a pretty, you know, strong hook.

**Robert | 31:58**
It. It just makes me think about like CA part of it is that I want to be delivering a mechanism for them to enjoy the building process themselves. And I find it. I'm not sure if I'm really viewing with what's happening with what the market is telling me like even though I'm building with a tool and I'm in joining building with a tool, what the market is telling me is that it's too hard for most people and I'm not sure. 
And I have to listen to that like I have to so I'm trying to consider what that means in terms of I have to come up with another way for the client to build.

**Ray | 32:50**
And what if youthing was building it on top of a super base or on top of N yeah, of Convex and you know where your North Star is? Does this create a more delightful experience? Yeah, its life for others. I don't know. 
But Alie, I'd really like to bring you back to this part of the conversation because this is a question of like, what would come across being appealing, right? And grow his market. And you've sort of listened to me. Eitherther on, I think long enough to be having your own thoughts percolated up. I'd love to be getting whatever sort of top of mind for you on that.

**Ellie Rofe | 33:26**
I was. I was thinking about one of the threads I kept thinking about is. What we were talking is, whenever there's a new technology or whenever there's something that I see bubbling up on X or LinkedIn or something, I head over to YouTube and I type in and see what people are saying about it. 
And there's a couple of people I've. I've seen there who are really useful. And they have experimented in public. They have just kept working. Kept working, and instinctively, I wouldn't have done it. I'd have been like, no, I need to make this perfect before I get out there and start talking to people about it. 
I mean, need to make this the final thing. And what they've all done is just experiment in public and build an audience of people. And I think what's really powerful about that, about just showing people you're working when you're talking about building and the people you're trying to talk to are if you're not doing about full like service stuff but sort of done with you things or tools to help builders build. You are working with an audience who has a huge tolerance for learning and for shifting tactics. 
If there's something new that's going to make things faster and better. Because they think much like you do. But you're very head ahead of the curve. You are. You have spent a year really digging into this to the point that you are master of these tools in a way that other people aren't. 
And I think possibly you just need to give yourself permission to just recognize that when you go out there and tell people how to use a tool or how to stitch things together or what backend is or isn't working best at the moment or whatever, you will be giving much more signal than an awful lot of the noise out there. 
So you. I think you just need to give yourself permission to talk freely and share your expertise because it's really honed in a way that lots of other people aren't. But they're just loud and they're talking about it and they're getting a lot of attention and they're getting a lot of like money, I suspect to.

**Robert | 35:37**
No, well, thank you. I think you're right, should probably. Yeah, I think it was a quote by Napoleon. And I was saying that, like, people probably under overestimate the downside of doing anything or like, what's the actual risk of like, you know, and when he went in a little too far right with it. 
But that yeah, but still, yeah, we could take a page from that.

**Ellie Rofe | 36:01**
Just a raged Porson it's fine.

**Robert | 36:11**
But yeah, for sure, I think and that's part of what I'm trying to do hopefully even with some of my efforts here is to even, maybe just turn some of those things that for me, I just hate doing repetitive stuff. 
I think like, I just hate the idea of if I have to look into the future. And I'm always if I'm imagining myself, like, doing something like, I'm gonna answer, I'm gonna post this video and I'm going to post it again and I start I can't think of doing it more than twice before it starts to, like, really bother me. 
So, I think, yeah, part of all this is sorry, that go ahead.

**Ellie Rofe | 36:48**
Post the same video. MORE Videos. Sorry, just to clarify. Do you mean post the same video over and over again or posting different videos? 
Like just becoming a video creation machine.

**Robert | 37:01**
I mean, just in general, the idea of having it come from anywhere except for really the conversations that I'm having because that seems like the most efficient place to capture it and to not have a way that, you know, to just the work is being done now. I'd like live right. 
Like I think that that's the thing. I'm just trying to get it at the most opportune time and set up all the circumstances to get it in its best form so that it serves itself and presents itself well downstream, which is really hard to control all of those things. 
But I but yeah, like the thing for me is that to just. Yeah, but pointing my interest then and. And my interest is just I like to build systems. So I guess all of this is like a roundabout way to. Anyways, try to make good on the make good and just bring in a level of consistency to it that would be hard for a human to ultimately keep up with. 
Like something for me to go to surpass even what I would be able to do as a regular person, right? Like because then I felt it would have that quality that larger companies have their strength of constant motivation, right?

**Ellie Rofe | 38:12**
No.

**Robert | 38:19**
Like the fact that they don't typically slow down, like they're always pushing and always trying to expand. To try to bring some of that to a solar preneur. Type of setup, I suppose to see if can I turn. Can that be a cron job? Can. 
You know. Can the motivation of my business be a cron job or just my motivation fires off every, you know, like ten minutes on a schedule. The if everything else. It seems like the technology is there, so hard to ignore it, at least for me.

**Ellie Rofe | 38:53**
Do you need a human in this loop though, do you need someone who can just you don't want any other humans, fair enough.

**Robert | 38:59**
Yeah, me, just me.

**Ellie Rofe | 39:04**
Well, I think like you like building.

**Robert | 39:05**
Well, I think.

**Ellie Rofe | 39:07**
And I suspect there is an audience out there that it might take a while to build up, but if you just streamed yourself building stuff so people could see how you build something not like' because people watched people play Minecraft, you know, people never thought that would be a thing, but then, you know, millions of people watched them.

**Robert | 39:18**
Yeah.

**Ellie Rofe | 39:26**
But maybe you just film yourself, build stream yourself building something, and then get someone else who's a human to turn that into a video that is actually a how to or something. Like, maybe that's there's a workflow here that is just you do what you're best at and then you palm off stuff onto someone else who can do the bits that would make you want to cut your own head off with boredom.

**Robert | 39:51**
Like, I think the same way that I. That I want there there's a way that the way that I wanted to build this anal tool, the reason I wanted to build it was to build a thing that builds more things. 
So I would ideally it's. I'm trying to get to the point where you can tell me that and then the agent will go build it.

**Ellie Rofe | 40:14**
Right.

**Robert | 40:14**
It seems like more efficient than me to go and build exactly what you just mentioned. 
Like for me to go put specific effort into that rather than to create the mechanism that would then just capture exactly what you just said and just dispatch and then make sure that it falls through with a level of quality where you know that it's not slop. 
And then I've solved multiple problems all once for every request. Yeah. Anyways, this is just, you know.

**Ellie Rofe | 40:38**
So strain yourself solving these problems. And then by the time you fixed it, you can launch the video that people will be like, I've been waiting to see what you can turn out here.

**Robert | 40:42**
Yeah, exactly.

**Ellie Rofe | 40:48**
And you can launch the video created by the process that's created by the agent that you haven't touched. That's a fantastic experiment. It's a really interesting angle. You know, not just constant content creation, but film yourself working so people can see how you think. 
And that's exciting and interesting and they'll understand things from that. The real. Like the real diehards. And you'll build a bit of an audience. But then get the thing to do the repurposing of that you can't be asked to do because it's boring. Which I get.

**Robert | 41:26**
This is becoming very so meta that it's hurting my head a little bit. I'm trying to figure out what I'm where my responsibility even lies anymore. Or for what level I'm what am I doing exactly? 
So. But no, do I?

**Ellie Rofe | 41:41**
You just giving your brain hands analyzing the brain.

**Robert | 41:45**
Yeah, or I'm. I'm creating my little army of, I suppose my little management team. You know, I might buy my workers who just don't ever get tired and hopefully do a good job.

**Demitris | 42:08**
Robert I'm a really big fan of the idea from Li, about the streaming, honestly, just do it with all the platforms you are using on.

**Robert | 42:24**
So, okay, let's say for streaming, like, would you mean something just like YouTube? Like just to go onto YouTube and LinkedIn, yeah, and just to my computer. You guys want to watch me work? Yeah.

**Demitris | 42:39**
That's it. Where you can just explain what you're doing at the moment, explain the reason why you're doing this selection on the screen where you click at this button instead of another button. And what are you gonna work on that? Definitely. 
It's interesting.

**Ray | 43:01**
The other thing that I think might make this there are people who do a lot of that streaming. And then I think it's good practice to be seeing if you can do it solo. I think it's worth asking. Is it what can you do to make it a little bit easier for yourself? 
Right now? One thing you can do is do it with a front, right? If you have like a guest on like, hey, I'm going to do these this hour or whatever two hours that you're going to go stream and be showing yourself with the fact you have someone to talk to about it who then be asking you things about it, okay? Not it's not just sort of you coding by yourself, it's you coworking, right? That makes as of both communication and the art. 
But leaving aside, like how compelling or more or less would be. It's sort of the minor stars what lets you play uneasy for this, right? If you can just turn on the camera and just sort of working, give it a go. 
If you can do it with a person, give that a go. And then I think that the big idea that you will need to be comfortable with is failing on camera. Yeah, and not having b I fail that. I guess we'll just cut that out. No, I feel that we're showing it. We just live stream is done. 
And so if you allow yourself to do that because what you're then showing is like how to create more value, right? You're learning, you're discovering along the way, and that's some really exciting stuff, you know? 
So in both those cases, the objective is not perfection, it's just sharing. I just got off of doing two recordings this morning. I did one which is a taped, if you'll see the analogy of recording, right? Just a recorded recording which went, which is going to get processed and put up a little bit later. This is like with Toby and JC the those guys who I set you up the episode with the and then I did another one with Yasin Essen Nadier, who we're you know, it's just livestreamed. We just use restream. 
It's out. It's done. And then because and then I just have it attaching to my channels right to my YouTube and my LinkedIn. And then because it shows up in my YouTube, it actually now goes into an automation that goes into my. That through app is, you know, it goes into Opus and because it goes into Opus, it gets turned into ten social media clips. 
And because ten turn into social media clips, they all get scheduled up for me over the course of the next, you know, week and a half or whatever. And now I've got, you know, more and more content, right? 
That's just sort of out there. I'm not going to pretend that content is as compelling as like something I've cracked to myself. Like the chair lip shorts really do better, and I've got a whole bunch of that backed up that need to get processed. 
But the. But the it becomes play uneasy, right? So one being able to have an interesting conversation. People find it. People found it. People were on it immediately. They were like, sending questions because we've done enough times. People have. 
You know, they get the alert and then they come and watch it and the shorts become like a source of value. But the cool thing is if you can make it like about like where is the business value, right? 
If you are that bridge between technology and business, which is what you are. And then. And then, you know, combine that with the idea of, you know, working with technologies that make that easier for you to do right. You're bringing Claude Bot into it or you're bringing Codex, right, the new Codex app, which you know, has, you know, automation, what have you. What parts of this really matter? Or. Or whatever technology is more useful for you in the context of, like, this control center you're building for yourself or the next control center build for yourself or whatever. 
But because you do always have this North star of like what's, you know, how do you do this in a way that can be helpful to you? WT tells the story of how it might be helpful to them, right? So about that, you know, personal productivity meets business productivity meets technology. 
Yeah, what you do is really compelling.

**Robert | 47:02**
I hope like that's a. You know, I haven't. I'm not sure some the. Yeah, I guess I just don't want to lose the touch, you know, the or whatever the taste for something good. And, but and just while you're saying that. I was thinking about how, like you because you were saying, like, the content sometimes will vary in terms of quality. 
And it just made me think about some of. You know, a lot of companies have put out ads that are not very good like. Or even like I think Coca Cola will even is like turning out to like AI ads nowadays. 
And like, everybody already knows who Coca Cola is and McDonald, but they still keep trying to remind us that they exist. And I think there's going to be something to that. Just trying to stay at top of mind what the mark is like, hey, I'm still here. Hey, I'm still here. 
Like even if because a lot of people don't even watch the video necessarily, but they'll see the clip pop up, and then they'll just. Okay. Like just still there. Yeah. And then you might achieve like this omni, you know, present like type of, you know, effect. 
I think like if maybe that's something that plays into it in terms of how the engines eventually, you know, make that work for you. But, yeah, no.

**Ray | 48:37**
If I might. I say, I think about this. I think about, like, you know, your focus on building something that's specifically for Xano. Demetrius's focus on using Claude plus Neo 4J. Ellie's focus on doing, you know, pitch tech specifically for biotech. Each of these, you know, your businesses have expanded when you have loosened up right from those areas of hyper focus because you start with those and that sort of tells you where the market is, right? The thing. 
It's called Cunningham's law, right? That the. The best way to get an answer on the Internet is not to ask a question, but to say something and see how many people tell you it's wrong. Yeah. But, like, it tells you what your distance is. 
Right? From true North. And like look at LI working with, you know, hard tech and you know, thinking a little more, you know, broadly about like what that means for, you know, marketing to investors and marketing to the market. 
You know, Demetris, the work that you're doing, you know, as you sort of expand the universe beyond just the like you were just talking about the chat chpt part, right? And that's crazy as some of that tech is, right? 
Like that's what people care about. And how can you be going to more where they need to be. And Robert, for you know, I'm thinking about, you know, getting a little bit less tied to that particular, you know, backend technology because even though it's something you build. Yes, it's something a lot of effort into it has established that you're a really smart person thinking about this stuff. 
And like, you have clients who yesterday used you because you were doing all this stuff with Xano. Tomorrow they might not use you because they're no longer associated with, you know, that even your stuff is sort of like. 
Sort of, you know, because you're able to make it work, but they can't make it work. So what, what's the low code pitch on it? Right?

**Robert | 50:15**
Yeah.

**Ray | 50:15**
But then if you're doing that with other tech, they might want to use like Supa, right or Codex, probably both. You have you now are your compelling une the technology your commitment to speed right and to doing things with a lot less work right? Speed and lazy at the same time sort of I think for your pic and then using the tech that they actually care about because you sort of you know you're following your nose in terms of what that true North is.

**Robert | 50:45**
Speed and lazy. I like speed.

**Ray | 50:50**
I think there there's a lot to that, you know, and the and through it all. And this, I think, is where Ellie was getting to. And I think I'm hearing this from doing interest too. And I sort of appreciate your thoughts. 
I think there's a part of this that's just about what is genuinely Robert right. And what is the accent of the technology you have to be working with today? And the genuinely robbert part? That's where the big equity value is right? 
Because you will continue to be you. And the more of you we can put into the market. Connecting you with the things they care about today. Fantastic. And if you are then ready to be helping them with the things that they want to work on tomorrow, that will lead to both new business and el rollover business. Xeno all stuck. Their role of business is based on whether people want to keep on using Xano. You don't need to be stuck because your rollover business is whether about people like you and their attention to a person is going to be more enduring than attention to a piece of technology.

**Robert | 51:51**
Yeah, I think. And that's the part that makes me, it's hard to see the future right now a little bit like to see where the technology is going. I feel like there's been periods of time where I've where it was more clear or like at least like where the next where the technology will be in six months, for example. 
Like, I'm not saying it could see much more clearly than that, but like. Or even whatever person can see up to six months even my not. It's not 4k resolution or anything. You know, it's going to still be like, you know, it's still blurry, but. 
But like, right now, it's. I think. Yeah, it just is Zoho dying a quicker death than I expected and stuff like that. So. But I think that that's maybe just aware. But I think, though, that because it's a back end. I can focus on the front end in the meantime. 
And, you know, because by nature, it is the back end and it's kind of invisible. I can switch it out. And if that's what's happening, if the market is going in that direction, you know, and everything that comes to that.

**Ellie Rofe | 53:04**
I think the thing you underestimate. So one of the people I look to when I've been doing vibe coding, for example. I'm not a coder, so, you know, you'll have a different audience, but I don't really care what tools he's using. I really don't. 
And he doesn't. He'd, you know, he'd tests them all out. He, you know, puts whatever he thinks is the most effective thing in front of you. I like the way he thinks. I like the way he thinks about planning something or putting something together or. Or the expertise that he has is not tools. 
And I don't think when I've seen you work or I've seen the stuff you produce. I don't think the expertise you have is tools. It's how you think. And on top of that, your. I know that you're like, I don't want to just be loud, and I don't just want to be like, sending outloads of bullshit into the ether, because it's just not you. 
But that in itself is your differentiator. You're conscientious, you're thoughtful, so as you're thinking about things, as you're showing you're working. You stand out, and you will. With comics. They say you have to find your audience, right? Every comic writes jokes, but every comic has a completely different audience because not everyone finds them funny. As you're building out and you're showing how you think and what you do. 
It's so much more than. Zano. It's so much more than snappy. It's. It's how are thinking about things.

**Robert | 54:31**
And it's a lot of work. And that's the thing I think too, is. Is the. Is just like to always be putting it out. It takes. Yeah, it just takes like a constant, you know, synthesizing of everything in order to be able to form it and then to and to deliver it to people. In the way that.

**Ellie Rofe | 54:56**
Show you working it out rather than the synthesized version. If that's too much initially, yeah.

**Robert | 55:02**
That's compelling.

**Ray | 55:03**
Too.

**Ellie Rofe | 55:04**
Really compelling.

**Ray | 55:07**
Everyone here is working on this stuff, they want to understand it. Sure, there are people who would love to have the prepackaged. Here's how you do X. The problem is the world's not that stable. You'll spend more making that, then it'll have shelf life. 
But you being the person who's working on it, who's thinking about it, you're helping them think about it. And they're coming along that journey with you know? Then. Then it's like, are they ready to run? 
And if they're ready to run, are they ready to run with you? And that not only becomes part of the content, but becomes the basis for like what a consulting or coaching engagement looks like because you now you're both running race together. 
It's a it's harder to work with vectors than it is to work with points, right? Like, linear algebra is harder to do than regular algebra, calculus, all that stuff. Because it's like you're dealing with, like, the Matrix all at once. 
Yeah. And the. And that's what we've got here in this market. It's just more complicated because of that because it's so changing because it's a vector and not just a point. And but you're there and you're working in. 
And, you know, the people who have worked with you say wonderful things about you and the people who. And. And like, if you can sort of show those qualities that they really love and you can be out there in the market. 
I think that would be, you know, very well, it'd be this word again, compelling. You know, I look at like, you know, hey, what tech should you be using? Probably like try using tech that's going to be maybe make your life easier like this.

**Robert | 56:38**
Or timely and maybe timely would be the. I'm kind of getting like a, there's a common thread that seems to be just around the theme of just the timing of things like just taking advantage of the timing and having a quick turnaround time in terms of just and I just actually came to mind the other day, Ray, when you mentioned, like the idea of. 
Okay, so Claude Bot is popular. And then James was talking about, you know, what are the opportunities. And it's like, well, okay. Then setting up, you know, this thing Mac Mini's for example, right? 
And I'm not saying that that's what I would do. But the point is, though, that to stay with the market and with the trends and to kind of put up offers quickly and maybe even tear them down quickly. And maybe there's something to that as well where it's just like the offer if the offer was like, always just based on the opportunity like that was at hand. 
And if it was. But it's obviously an art like a there would be an art to that, I suppose, right? Like maybe to pulling that off well.

**Ray | 57:50**
And there's discovery that goes with it. Mean that you don't like? I have to do that forever. Knows what you do next. Yeah. You're discovering where True North is, and then you're pointing yourself that way, right? 
But you don't want the. I think the part of the reason I was talking about like the three, you know, sort of FCA was, you know, if you stay focused on one thing for a while, right? Then you stay off of True North. The value came from when you were in the market, you could see how close you were and then you were right, the sooner you woulddjump, the better. 
And like, what you're getting at is just a, you know, willingness to say. That's more of a continuous thing. And I think that has as much to do with ego as anything else, right? Being willing to kill your darlings along the way. Hey, I had this really good idea. Wait, it doesn't quite work. 
But wait, this is everything in the market. It seems to be an okay thing. And then you're sort of being pulled that way combined with your technical insight. Because when you can marry technical insight with market insight, that's power.

**Robert | 58:47**
Yeah, I appreciate that. Thank you all. I just gathered some amazing feedback and myself and my agents will be discussing this. You know, I'll be reviewing with digital versions of all of you and well.

**Ray | 59:10**
My avatar is looking forward to it and not avatarself. We'll see you at the end of the week. And we'll do this again next Tuesday. Take Cris. Great.

**Robert | 59:18**
Take care record.

