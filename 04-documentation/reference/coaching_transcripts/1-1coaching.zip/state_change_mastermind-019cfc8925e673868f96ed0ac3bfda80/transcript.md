# State Change Mastermind - Mar, 17

# Transcript
**Ellie Rofe | 00:01**
They with an EMCY.

**Robert | 00:02**
With an MCP tool now, and it's very interesting because the MCP tool forces the paradigm, which I find helpful because it's a good mold in a way. It's like I don't really care what's happening behind it.
I think maybe that's an interesting case for MCP tools that the response is standard, like you can control that experience. So what I find to be useful about that is to use that as a forcing function basically to say that it has to end up this way if it doesn't end up in this mold, then it hasn't achieved this is what I perceive to be the goal right now.
It does actually work with that mold. It works the same way. It's as if I'm using Xan, it hot deploys instantly from through GitHub to the fly server and just can instantly curl it. There's no difference.
It's actually crazy. I don't know. I've never seen anything like that before. I think it... Yeah, I'm patting myself on the back doing my own horn, I guess. So anyways, no, but I actually seriously... That would be whenever we have a minute maybe when I do my update would be amazing to get your input.

**rhdeck | 01:36**
Yeah, sure. Well, it's gonna be, you know, you it'll be your show today. We're just waiting on. Wait. Demetrice.

**Robert | 01:44**
Ellie, how are you doing?

**Ellie Rofe | 01:46**
Hello. I'm very well, thank you. And you? It sounds like interesting things are happening.

**Robert | 01:52**
Yeah, you know, hopefully, you know, that's as interesting as I think it is, but I think that's maybe what I'm looking to confirm today, is it? Is this actually interesting?
I'll let you guy. I'll let you guys be the judge of that.

**Ellie Rofe | 02:11**
Fair enough. Thank you for that, skill, by the way of.

**Robert | 02:19**
Nice. How has that been going?

**Ellie Rofe | 02:21**
Yeah, really well. I've done a lot of scraping and ingestion and playing around with it. Actually, I think tomorrow and the next day I'm going to be looking at more testing and asking questions and seeing how it's responding.

**Robert | 02:44**
Actually, I just thought about this because the skill is actually using Neon and Fly, and so how's that been going?

**Ellie Rofe | 02:52**
Really well. Yeah, I haven't noticed any particular issues with it.

**Robert | 02:54**
Nice. So, like, you're like, I would be curious. Like, it's the interaction with it. You're just able to focus mostly on what you need, and the technology side kind of just takes care of itself.
I think it's working out that way.

**Ellie Rofe | 03:10**
Well, that's why I just need a double-check that it is tomorrow. I've been leaving it to take care of itself and just going...

**Robert | 03:14**
Okay.

**Ellie Rofe | 03:16**
I'll stay hands-off and see how that goes. I might go in and go, "Wow, this is chaos, but we'll see what's happening."

**Robert | 03:23**
Interesting. I think that would be I showed something when I eventually share my screen that would maybe be helpful with that cool a me just he guys.

**Ellie Rofe | 03:31**
Okay, fabulous.

**calendar-invite@lu.ma | 03:38**
How are you? Sorry for being late.

**rhdeck | 03:42**
Glad to be here. Let's go around the horn here. Ellie, maybe just start with you. Was it true last week? That was true today. It was not true a week ago.

**Ellie Rofe | 03:54**
[Laughter] I was back in the UK last week, so it was a bit chaotic, but I... I managed to keep things ticking over a little more than I sometimes do. And I had some in person meetings, which was great.
I've got some, which I just discussed with you, a sort of progress and sort of road block with UBS, but I'm thinking about whether he's saying I'll just come along to the event in November and then we'll get you in for next year, and I'm going to try and give a counterproposal, to run a sort of thematic scene through that event.
So it's interesting. I think probably this time last year, I wouldn't have been thinking about giving a counter proroposal like that. I've just been like, okay, that's a dead end. But I think I'll work in these sessions.
And generally, a bit of growing confidence is making me think. Okay, well, I'll just, you know, not take that no for an answer, but try and turn it into something else. And had. I've. I've been asked to speak at the Crick Institute or be on a panel there, which is great.
That's a very sort of prestigious biotech institution in London. And yeah, otherwise, we've just been doing loads of interviews. And as we were just discussing sort of ingesting and finding data. And then, you know, this week is now that I'm back in the calm of home and not running from pillar to post. This is like a time of consolidation and thinking about things and following up.

**rhdeck | 05:32**
Makes sense. And.

**calendar-invite@lu.ma | 05:35**
We just... Could you check you with these, sir?

**rhdeck | 05:37**
Was true week yeah, was true weekgo.

**calendar-invite@lu.ma | 05:42**
It's true that I've made some big progress on the brain graph. The tool replaced 90% of the project, killing 90% of it and making replacements. Inspired mostly from the investigation I've done for Ellie's project a couple of days ago where I found some opportunities for improvements and I found a better pricing model to apply on the platform which will be integrated today. Something interesting. Yesterday I had a chat with the guys who created the Falkor DB who sent me a LinkedIn request right after making my first setup saying, "Hey, we saw that you signed up. We would love to connect. We want to learn more about you, and we plan to do some content together and engage communities, both sides, so we can help each other."
Mostly these are the things that run at the moment. Yeah, I think that's it of the strongest part.

**rhdeck | 07:09**
The, yeah, very cool and Robert, can we check in with you, sir? Like, what is, you know, it's your hot seat. Today was true today was not true week ago, and like, how can this group be of maximum service to you?

**Robert | 07:23**
Sure, true today is and not true week ago. Well, first of all, I had another good week with, the. I'm sorry, what was that? That sounded like a loud piano or something, just so I don't know.

**rhdeck | 07:42**
That it might have even been from my computer. I did. Okay, yeah.

**Robert | 07:46**
All right, just make sure. All right, so. Day not three weeks ago, I had a good week with another week with, clients, this week I felt actually I started to notice. I don't know. Like things that might repeat with clients that seem to be seem to land positively on them. Such as when the project, when you've done some work. Just to let them know that you're pausing the hours.
Like if you start to feel like you're not running out of things to do. But just tell them you're posing the hours like to not even run into any type of situation where any of my time or is being put towards something that's like low value.
I think, again, like, I'm not sure. Maybe this is at the edge of my experience when it comes to, like, covering clients. But it seems like it blends well, because I've done it twice now, and like. And, for.
And basically, the first time I did it, you end up resuming the hours is my point. But on something that's meaningful, like, that's what seems to happen. So, yeah, I just kind of want to point that out.
So it's good and kind of puts me back on to the my focus is, I suppose, on the market right now on trying to, move more effectively into the market. And I think actually. So I'm gonna just share my screen, and then I'll show something that I think is cool.
So, like, I'm trying to systemize these things more, you know, so like, to create these assets more efficiently, right? And, like, more consistently at the same time. I like to get, like, the same style, like, and even to get it to be, like, high quality, right?
And to have this just be a machine. And this is actually a skill file. The whole thing is just a skill file. And it goes from. I just ask for what I ask it to look for topics. It goes through all the conversations, pulls out ideas, pulls out. I tell it to mostly focused on technology because I think that's the interesting part mostly in the conversations like all the different technologies because people always ask they one of the things that people want to they want to stay up to date with stuff, and they're like, how do you stay up to date with everything?
So I think like just being like sharing stuff, kind of just like taking it. Actually, the way that I modeled this was as a news team, as like a newspaper. That's my. That was the analogy that I gave. I said, you're just as a newspaper, you know?
And like, now we need a media person. I used to say before that I didn't like giving, you know, creating those types of roles for AI to say that you're this person. But I was considering that the other day. I was thinking, well, let me just do the opposite of what I think is true.
Like. So just to see what that's like. And. And so then I just said, give them rolls because that's something that I knew I wouldn't usually do. And. And it seemed actually that it represented itself really well in terms of like the results.
You know, this is even creating thumbnails for YouTube. Like, with my picture in them and, like, everything. Like, when I say everything. I'm talking about, like, just, you know, even for advertising, the weekly meetup, you know, all totally just took me like eight hours to be honest with you yesterday to make if not more like I had to go through. I was going crazy by the end.
And so anyways, this is kind of just is firing off. I've never gotten such good results with AI generated stuff to bounce with you. Like, I think it just looks really clean and just represents itself nicely.
And, yeah, I think that, you know, just a way to try to move things along that way. And, the other thing is, I made this, which is something that I'd like to I'm going to move into the market with, which is basically right now I'm just calling it back in Dashboard.
And this is like something that is, something that evolved from a lot of conversations that Ray and I have had over the last, well, forever. But like you know, in a lot of ways, but like specifically the last few weeks.
And the idea is that to be able to just connect whatever stack that you have on your back end into the here and then, it would just represent it, right? So this is for example, Neon Fly and GitHub. And it turns it into like a Xano experience basically so that you can just immediately deploy to those to that stack.
And you can have observability into the stack. So you can like, you know, is obviously work in progress, but, you know, the idea to come and to be able to see your tables and to be able to edit, you know, the title of it or to. I don't know, actually. Actually, here, we edited it from here, so it's like, I'm gonna call this task so good you want to rename it.
Okay, we'll see. So we're renaming it, and it renames it on Neon, right? And if I, you know, just want to rename it back, for example, and then there's like, organization that's being added on top of it, right?
So like for example, adding in like providing a like a service on top of it for organization, if that makes sense because there's obviously not API groups over there, right? It's like I'm introducing that concept and in offering the tools to be able to add to organize your things that way while still maintaining whatever is true over on the other side of the technology.
So. Like this, for example, is like. Okay. Let's just help you organize your stuff. And then, you know, now we're like, you know, getting organized, and then you can see, like, okay, so what are the endpoints? Those are all very recent.
And you know, what are the endpoint so you can see all your endpoints. And then here I'm, you know, get into like there's a whole bunch there's still more to do here. And then, like I said, there's the aspect of being able to build with it, right?
So, over here. So I actually. So right now, this is in the middle of. Of planning another, move with it. But you can see this is actually the MCP tool that I for it to really just drill in on the idea that it's there's no difference between using it and versus using Xano.
Like I'm so I don't I want to be imperceptible to me. So and actually and I would know that because I use the tool more than and anybody and that is actually what the experience is like. It I can it can instantly deploy to fly and to GitHub and just one motion, right?
So like it just instantly deploys and it can crot test it right in immediately. And that's what's enabling at least me to build onto Zano very effectively. So... But now I'm able to have the observability and the functionality and totally in my own control, like any platform that I want basically, I can do... I could expand this over into other languages, which I'm going to because the GitHub app, the code analysis part of this already supports those other languages.
I've already made it go through that loop and just go through Kobol and MongoDB and those other ones. So right now, I'm actually... This plan is actually to have it rebuild itself onto Fly. Neon because I want to take it off Zoho immediately.
So the first assignment is to rebuild itself onto Fly. Neon onto a new provisioned database and that's it. That's my TED talk.

**rhdeck | 16:09**
Okay, how can this group be of maximum service to you?

**Robert | 16:13**
I think it would be very helpful to know... Yeah, just in a way, I'm always open to ideas on what to do next and just how to make my life easier because I'm obviously running a little bit hot right now where I'm working on all this stuff.
So a lot of it's obviously out of work. So, I'm always... If there's something that I can do to make my life easier, chill out with one thing or if there's a 20% I can focus on, I'm always... I like to think that I try to be coachable.
So I'm open to being coached.

**rhdeck | 17:04**
Let me throw open the floor. Alright, I'm going to pick on you first.

**calendar-invite@lu.ma | 17:12**
Yeah. What struggles do you have so we can give specific suggestions to make your life easier?

**Robert | 17:24**
Getting all the... I would say getting in control of all the systems that are. I don't know. Like, that may or may not seem necessary, I suppose. But like, for example, the. I just feel like I use a lot of technologies and I use a lot of things, and they're all kind of. I'm trying to consolidate things to just be more effective.
So maybe that's one area like if I'm thinking about like where am I experiencing friction right now and struggle might be somewhere in the area of operations like trying to. And that's why I'm trying to make this skill and everything.
But yeah, trying to and getting out of my own way a little bit to try to have the stuff make it to the market, I think has been a challenge.

**calendar-invite@lu.ma | 18:31**
It's very often for me to have this need. But I come up with the question, "What if I solve it?" Because sometimes I realize that having so clear all these stuff and things we're doing, it's actually... For me, it never helped me. It just made me feel more comfortable and I have a clean space in the room, everything is structured very well and all this, which is nice.
It's nice to take a photo.

**Robert | 19:10**
Sounds nice.

**calendar-invite@lu.ma | 19:13**
It is. Everybody enjoys coming on a desk that is ready to accept a new day. With all the challenges, everything is in the right place. But in terms of actual usage of this approach, I have some concerns from myself.
But if this works for you, that's nice. One idea to keep track of all this progress is to use your knowledge base. You already have the knowledge base, so feed everything in there and ask... Or create a skill that can create you a plan that can give you back a visualization of what you think as random but it's not randomly created during the week and give you a follow-up at the end of the week with a clear structure, "Hey, this is what you did. This is how it relates to the past work. These are the domains you are making progress in. Whatever you need...

**Robert | 20:17**
I'll guide idea. Actually, I have like a self update of a, you know, something to just. I've actually thought about that in some ways, this would actually it's kind of what I'm looking for. Like those life hacks.
Maybe that's the word. So. I'm just. I think I'm looking for life. Hacks yeah, that's an interesting one.

**calendar-invite@lu.ma | 20:41**
If that works for you, it can help you because I had the same need, but I realized that it didn't work for me, so I just avoided it. Okay, let's move forward. Then it's going to be great if you find this way.

**Robert | 20:59**
Yeah, well, I yeah, I mean, I think that, anything to make it easier, you know, in terms of just. Yeah, like, there's there. Sometimes it's just. I don't know what it is about making things, doing things a hard way, but I just want to, not do that.
And, like, if there's a way I can just ingest the information in a easier way, that's definitely to the better. Yeah. Thank you.

**rhdeck | 21:39**
I can bring you the conversation.

**Ellie Rofe | 21:43**
As a non-developer, when I look at that beautiful back-end dashboard, is that how all developers think? Or is this something that you have? Is this a way that you think? Because you've worked with an... Or is this opinionated? Is it normal, like a standard?

**Robert | 22:09**
I would say it's heavily influenced by the Xano and. But it's opinionated in the sense of yes, it's very opinionated because even, like because outside of Xano, this is not a framework that normally, is used to look at a back and stack like that.
Like it's because they're disconnected.

**Ellie Rofe | 22:37**
One?

**Robert | 22:39**
That's where I actually had a lot of struggle with the AI and just even really just being uncompromising. Like me just. And it putting up so much resistance to the very idea of what I was trying to do.
Like it was just like. Like every opportunity I get down to the wire, down to the last detail, it was. I had to keep reminding him. I'm like, do you realize what we're trying to do? Like, just stop taking us in opposite direction?
And then especially when it comes to deploying from GitHub, like hot deploying from GitHub to fly, it just kept saying no. It's like, you know, this isn't like, you know, don't do like all this stuff.
So anyways, yes, I think that, kind of informed my by my opinion of which is to only focus on this and to purposely not get too involved with whatever the right way of doing things is.

**Ellie Rofe | 23:40**
I just think there might be a beautiful opportunity here for you to teach. Like if this is if you've been through the like, learn, experiment, build, and you're in that process.
Maybe this is a chance in. In Ray's model to. To get into some. Like get some people in a call with you and just start teaching it because it's it is a an innovation.

**Robert | 24:06**
Is it? That's a very interesting point. I think I did, yeah, like, it does seem like it would be. There's something maybe to that in the sense of especially again, like I'm still trying to figure out, like, as this kind of goes along, like how novel it is because I'm still and it seems like it has those qualities.
Like I haven't seen that go away. And like, if it continues to. I suppose define itself that way as having it. I'm waiting so far the results I'm letting. I guess I'm not trying to like let that part of it be what the sharpest point of the spear is.
But now it's starting to become like if this is actually keep even across different sexs has the common quality of just being a certain way of building. And that's an interesting thing about it does it in the way that it builds if that's thelling part that's that is something that I'd have to think about what to do with that. I suppose that is a very interesting point about that, actually.
Okay, thank you. Yeah, no, I thank you.

**Ellie Rofe | 25:21**
Sorry, well, I don't know what experience developers feel about this stuff.

**Robert | 25:23**
No, I was just saying thank you. Please go ahead.

**Ellie Rofe | 25:28**
Whether an experienced developer goes, "Finally, this is the thing I've been looking for." Or if they're like, "I have my way of doing things or whatever."

**Robert | 25:35**
I don't like it. They don't like it. But that's the thing that they're not my customer really. It's actually all the other people who are now interested in this stuff. That's a huge market now for a flood of a wave of people.
I think that I have one foot in that world and the other foot in the developer world. So, I'm trying to maybe just bridge that gap. Yeah, and how I know that is because the experience when it boils down to it... Even just with the Xano MCP has nothing to do with Xano.
It's just about them interacting with it through the MCP. They don't even log in to Zoho. So they don't actually... When it comes to... They never actually end up really learning how to click through Xano and use it that well.
They mean to a certain degree, but... They don't need to, but the point is that this is the same experience. Then if that's true, right, because it doesn't matter whatever it is on the backend, it whatever it is, this is the same thing.
So yeah, to create something there it's interesting exactly who needs to... Clarious.

**Ellie Rofe | 26:49**
I mean, I haven't even looked at neon yet because of the prompt. You gave me something else, and I'm not even that, but it's fascinating to me because there are.
Yeah, I couldn't tell you what. I couldn't tell you what the dashboard looks like. I couldn't even tell you what color it uses. And? Nothing.

**Robert | 27:07**
And I think it's kind of it's not a great feeling, like, in some ways, right? It's like. And I and that's one thing that perplex me about. I'm like, how come I just can't see. I want to see my stuff.
Like. I' I just, you know, I'm just being like, you know, I'm going like, ape brain, just simple, like, you know, chimpanzee brain, like, where is my stuff? Like, I just don't see it and like. And so I see Xano, I want the same thing. I'm like, I just this works for me, just give me the same thing.
And so far, yeah. And this is a product of that.

**Ellie Rofe | 27:41**
It's fascinating to all the people I've seen teaching Vibe coding basically. They're in ideas, they're switching around all the tools on that side of things. But one of the bigger problems is the opacity, especially for non-developers who are in this world, because it's complex, it's messy, and we don't know how to read that, and it takes a while to try and filter through it.
So I think it might be a really interesting opportunity to just teach people this paradigm that you're building in. This is how I structure and think about the backend, and this is how I see everything, no matter what the ID is creating or the model is creating. This is... I can see at a glance what is actually going on.
That in itself is really novel and solves a big problem.

**Robert | 28:28**
Yeah. And it just has a lot of. It has a certain lightness to it, I think, because it doesn't it wasn't made with, the idea of it needing to be necessarily like extensively interacted with as from the front end through the GI because it's the presumption is that AI will be driving those changes, and then this front end is just representing them.
So that part is, you know, makes the development of it easier. But still, like there's something compelling there, I think because, yeah, the intellectual property because which is actually like kind of which has already happened with the Zoho MCP like I would even get. I even got an e mail from Luke where basically he was like asking me if I would open source the Zoho MC P because he said that, or he's willing to work on it or something, because, he said that it's the backbone of his business in his own words, so.
And, like, he just doesn't know what it would do if it would go away. Now, the thing is that in my. I'm not going to do. I just don't I mean, I think that, he can I'll be around. I'm not going anywhere.
So he's fine. Like, you know. But. Like. But the point is that that's a good thing, right? To get to have that type of dependence, to be honest with you. Like, you know, it's not a bad thing for a business.
So, if I can continue that and I can have. But I can have the flexibility to work with even different stacks. Just. Seems like a good idea.

**Ellie Rofe | 30:21**
Yeah, I think a lot of it we talked about before. I know I'm... I'm a bit obsessed with this analogy at the moment, even though it's old, but the idea of learning from the branches and then filling in the trunk of information and stuff.

**Robert | 30:33**
Yes.

**Ellie Rofe | 30:33**
I think a lot of people like me, who aren't coders, who have spent time building with no-code tools and models and things. It's hard to know what you don't know, and it's hard to see things in a structure because you've worked in lots of different front ends of structure, different ways of showing who is or isn't.

**Robert | 30:53**
No.

**Ellie Rofe | 30:54**
If you don't understand the underlying stuff, which is... I mean, that's what Xano does, and that's what you're doing, right? You're structuring the backend so that people can go, "This is what this bit does. This is what this bit does."
I can see it all and I can understand it. If that's platform agnostic, you have a model that you can teach people to help them. I think it's really quite powerful. I think a lot of people are lost in vibe coding.

**Robert | 31:22**
Yeah, no, for sure. I mean, like, I think that there's just sometimes too much jargon and too much over complication of certain things and just. Yeah, like, I would much rather just have. I find that there's a remarkable amount of things that you could strip away and be left still with, you know, with just what you need and you'll be able to make what you want happen.
And, you know, I just don't like I one thing that annoys me. It just happens with the Ai te in making this, which was annoying me is just like I feel like sometimes it's being pedantic. It's just it's it knows what I want.
Like, I don't know, like it's just hooked on to certain words, like just holding me to it. And when really the point is like just achieving the objective and rather than getting stuck on the terms in the middle.

**Ellie Rofe | 32:25**
I think it is really interesting.

**Robert | 32:29**
Yeah.

**calendar-invite@lu.ma | 32:33**
I think as you... As we said in that other conversation, you have pretty good skills on vicoding that definitely can apply it in multiple domains, not only on Xano for example. I see a nice opportunity to create sub-services on the main services, trying to even use these skills for better positioning yourself in the market or even strengthening it even more by creating content.
Because I see vibe coding workflows attract more people because they think that. Okay, I can do that too, so they can engage with the persona easier. But the thing is not to do the video coding is actually to run the mechanics which you actually know and that's the core thing in the center.
Even sub-services like master classes for doing that thing. How you use, for example. Even the title is interesting. I use the same tool to replace itself and restructure it by itself.

**Robert | 34:03**
Yeah, it has a you know, there's a lot of you can have fun with that concept. It's an interesting concept. Yeah, or video, actually. Yeah. And which is maybe part of that part of what I'm trying to figure out too, is how to make it entertaining or like interest or, you know, appeal input, which is goes back to the skill, you know, and everything.

**calendar-invite@lu.ma | 34:30**
For the entertainment part, I don't know if it's necessary. I see entertaining content has views and engagement.

**rhdeck | 34:39**
That's true.

**calendar-invite@lu.ma | 34:42**
But I don't think that entertaining content is the same level of valuable as the known and converting content.

**Robert | 34:53**
Yeah.

**calendar-invite@lu.ma | 34:54**
The thing is, someone who engaged with you and with us, they're not engaging for entertainment. They engage for the knowledge and with the problem solution. The way you can make it entertaining is by making the conversation enjoyable.
So they will... People who will join this mastermind conversation will not feel bored for these 60 minutes. If you achieve that, I think that's fine because after analyzing many videos on YouTube, trying to figure out how I can make it better for my case, I realized that those entertaining videos have so much video editing.
So professional editing. So many effects. Keep hidden the actual value. So if you just transcribe the video, you proceed to analysis. You see that this three-hour video has just one paragraph of value and the effect...

**Robert | 35:58**
Yes, that's true. And I don't know how to feel about that. I don't know how...

**calendar-invite@lu.ma | 36:09**
Yeah, you know what? When I started learning about nodes, graphs, and all of this stuff, I found a nice YouTube channel run by a guy who's Greek by the way, and he's one of the top three voices in the domain in Europe. He runs the scientific labs. He runs many activities with zero social media engagement. He has views with videos with two views.
I am the second guy because I watch most of his videos because I find them so nice for me for learning. Ray has some horrible boring videos with strong knowledge inside a place to accept as a complement.
It's boring to watch it staying on the screen. Seeing me, even me, I'm even more boring. I can't watch my videos, but I know the knowledge inside that it's so valuable. For example, the case study six-minute video about how he used the MCP staff to find nice ideas for domain names and ran the loop immediately from one prompt. It took him six minutes. There's no reason to stay for six minutes. There is six minutes for a user watching on the screen too much time, they cannot engage.
That's why I'm calling them boring and even worse.

**Robert | 37:55**
No, I don't. I mean, I totally get what you mean. I think that I couldn't watch some of my own videos. I mean, I can't watch. I mean, there was actually one video that I posted. It was one of the first ones where I was talking about the MCP. Anyways, it was after I got the video. I was after I was speaking for an hour.
I think it was actually just where... It was that I was giving a state change presentation at the time, but just about making a lot of MCPS, a lot of endpoints on Zano. It was like... It was like the early times of that.
And then I didn't record it really in the best way at the time. You compute from that. Like, I didn't, so I didn't really. So I it was difficult for me to watch. I was like, there's no way people are gonna watch it. Just.
And then I would get messages from people like I watched the whole thing and like they and that they enjoyed it. And I'm like, wow, if you'd watched that, you might watch anything. I mean, at that point it kind of changed the way that I even saw about the content because they liked the topic so much that it got them to want to book a call if the video was crapped.

**calendar-invite@lu.ma | 39:06**
I'm closing my thoughts with this sentence. Guys, I watched the live videos from Jason Kalkanis. Do you know him? He runs a weekly live session on YouTube and on LinkedIn, and he has many talks about OpenAI and products from OpenAI. In this live session, he's similarly boring.
Honestly, he tries to make some jokes, but he's not that good at that. But he's pretty good at bringing questions to the guy. So the actual outcome there is no reason for you to open your TV or open your monitor on screen and start watching his conversation. No way.
Maybe you start playing in the background, but sometimes because people share their screen, you have to engage on the screen to learn it. But if you join them live, the experience is totally different.
Some pieces of this content are very valuable because they went live. The same happened with some live videos from Krisp, though. Okay, it was quite better because he was very well prepared for the questions.
But Kalkanis... Live your life. My life. Events are in the same barrel.

**Robert | 40:41**
Thank you. I appreciate it. Give me a lot to think about.

**calendar-invite@lu.ma | 40:46**
Just do it.

**Robert | 40:48**
Just exactly what we've got to think about.

**calendar-invite@lu.ma | 40:52**
Let me just go and do the stuff like... No, worse for the engagement.

**Robert | 41:04**
Great, very. I just want to get your input. I know we jumped over a whole bunch of different stuff. But I think... Obviously, I would like to hear your thoughts.

**rhdeck | 41:22**
I think there there's what's what can be compelling about this offer is how it works. What they already have people who have raced in, they've gotten too complicated. They're in over their heads and they're throwing them, you know, a life preserver.
You know, yeah, given them out of the this is my you know, and like the videos become. This is how it saved my bacon, right? I have dived in just like you. I get into these all night recessions, and this is how I get out.
And.

**Robert | 41:58**
That. That's.

**rhdeck | 41:59**
Compelling, right? Yeah, my friend Zano just sent me six strategy docs, which they'd like me to read for a meeting I'm having tomorrow with them. I'll tell you that they recognize this as a market.
Their approach to the market is that you should be doing it their way from the beginning, right? I have to tell you, I see that all the time in engineering web companies, and it's almost always a mistake.
Because now, in order for you to use this benefit, that's over here, you need to buy into these previous seven steps, right? You need to use our way from the beginning. So instead of you saying, "You're drowning," here's a life preserver, you're saying, "You're drowning.
That's too bad. Hey, somebody else thinks about going swimming. Maybe we want to carry this with you." That can be a harder pitch.

**Robert | 42:55**
Yeah.

**rhdeck | 42:56**
Getting people to buy insurance on the house isn't on fire yet is, of course, good. People should do that, but then... If they're not absolutely made to do that, that's a regulatory thing. Like, I had fire insurance and had this condo, and so being forced by an... Because they've already been burnt, right?
A lot of state change stuff is people who have been down this road and they got burnt and then they joined state change. That's how they go about it, right? It's their second swim. Assuming the first swim didn't kill him.
I'd love to be able to bear that, but that's what you've got, right? Is that life preserver? If you can shrink... People need to have done beforehand in order to profit from it. I think you win in this market because people want to run fast, they want to get in trouble, and they generally believe, and I think generally correctly, that the market will eventually catch up to them.
Wait, I'll get in trouble. Then technology keeps some training. This will get better if you can be offering that, offering them that. Because all these people who are getting trouble and the market hasn't caught up, that's a sweet space for you to be.
That's compelling context, right? It's a compelling hook. It's a psychographic ICP that just keeps on growing because lots of people have been going out swimming and getting in trouble.

**Robert | 44:11**
Yeah.

**rhdeck | 44:11**
But that's one of the reasons why I talk about not having it be a backend or universal backend, but being a backend. Visibility and the idea of it's not read-write, it's read. Maybe you offer a little bit of write, but I actually don't think that's even the best part of it.
It's like the documentation you showed, turning into the infragraphics and what have you... That's compelling stuff. Now think about the regulatory thing you get to lean into, like when they need to be doing their sock to or something.
I've got all this stuff and I need to document it. Now, how am I going to give this one button? Yeah, and then that's part of its visibility. Now, if you're thinking about, "Okay, what comes after that?" You make that visibility AI visible so they can close the loop.
Now the AI... Yeah, taking these observations, taking all this complexity, whatever, and turning it back into... Either cleaning up the code or making it more rational or finding performance opportunities or whatever, right?
But now you're in this wonderful position of helping people with stuff they have made that's in production or they're trying to get in production. The people usually have money for that the way they don't when they're going from zero to one.
So that's what I think. Yeah, show me this kind of tooling. That's where I see the opportunity being. The more you are the person who just pushes the code, right? Because you're staying up until four in the morning and doing that stuff. You're not going to see that, right?
Because you're staring at the code and not looking at the forest.

**Robert | 45:38**
Yes, true. I mean...

**rhdeck | 45:44**
Wow, this is a good point that Al is making lots of VIB coding influencers out there who have gotten into these, you know, trouble situations. And you're that becomes compelling content. You become the compelling, you know, guest to be talking about this stuff because you're not.
And you're gonna be nicely different because you're not a person. You know, if Cameron Booth, right from Xano goes on one of those podcasts, he's like, yeah. Well, here's how you do it without getting in trouble. You like woo party, right?
And here's your he regrets pill, here's my hango cure. And. Yeah, the. The latter is. Is an easier sell.

**Robert | 46:34**
Yeah, I think that there's... Sorry, go ahead. Yeah, right, it comes with a cab. I can't help all the party animals, but I think that... Yeah, I have to. I mean, it's definitely, interesting in that like, it could have a decent mode around it.
I think in terms of the technology too, because of the part where, well, I've built it using other things that I've built in order to build faster. So like I kind of just trying to create more leverage for myself.
So I think that there's a bit of depth to the code analysis part at least, but we'll, you know, that will remain to be, you know, seen. I think the proof of that is just if anybody else makes it and so far the XANOCP nobody else has made.
I think Xano would have. I mean, Xano made one, but like, it's not, as you know, preferred to use. So we'll see about like, whatever happens with that side of this, but I think anyway, it's a big opportunity is.
And probably just like. Yeah, the educational part of it, the consulting side, whatever the closer engagements become.

**rhdeck | 47:57**
Yeah, this is a cup, this is a bottle, and you're having them pour their data right into that bottle. But then the real value though, is your services as... So right, you being able to tell them about the wine in that bottle, and that can be consulting, that can be manifested in skills and all sorts of software, right?
But it's going to be okay. Yeah, I've caught this stuff, and I can see it. That's table stakes. Like you say, someone else is going to be able to do that because you can code it, soak it in, or have somebody else do it.
But you have coded before other people, and you do engagements with people. You will get insights about this stuff, and that becomes people patterns. It's hard to see. Now, really, your competitive position is built on the experience curve.

**Robert | 48:45**
Yes, yeah, which actually does one side of that is already done because like it. I mean, to me again, like when I get into the engagements with people, we're actually not really logging into Xano at all.
So like the experience is actually very much focused on like using cloud code and using V zero like. So the experience is already there, in my opinion. From what it is, as far as... Well, there's that side where I'm still hammering it out, the other side, but, assuming the problem continues to be solved and become more stable and a solution becomes more stable, I've already gotten some good reps, and I would just say with that market insight, I suppose it is already helping to fuel this.
Yes, you're right that even if I take the same thing and put it in somebody else's hands, there's really the bulk of the work is actually in the adapting on the spots and the communicating it to another person, who wants to be personally communicated to them.
I think there's a lot to that, and at the same time, using it to create an asset in the middle. That's the most... So far, with Zoho snapping FPCP, that's what I've been able to leverage it to do to create at least more recently, especially my most high-value engagements have been by using that as a vehicle.
So if I can use this as that vehicle, I think then this can go to even higher, bigger engagements because the projects themselves... If I could aim for an even bigger project like that, some like the other Brownfield project that's... There comes an interesting product for prospects, I suppose, or... Probably for prospects, I would guess.

**rhdeck | 50:37**
Cool. Thank you. All right, alright, so Robert, you were looking for some feedback on this thing, sort of as part of your, you know, next turn of the wheel, right? Which is that sort of this observability stuff how you know the have you gotten what you're looking for from that are you looking for we'd be a couple to you.

**Robert | 51:02**
I'm like my I feel like I already have so much to take in. I can't even possibly like, I can't even think of anything else. I feel saturated when it comes to in the best way. I mean, I feel actually just very grateful because I think I really like the exact answers for what I'm supposed to do in, like, every category.
So what more could I really ask for? I just want to make sure that I'm making no side of everybody else's time here, too. So I want to ask in return, like, if there's anything that for anybody else that, like, whether it's related to me or related to yourselves. I'd just be happy to.
You know, to make sure that we're. We're able to discuss it.

**rhdeck | 51:55**
Anything else anybody wants to raise then, before we wrap it up here today?

**Ellie Rofe | 51:59**
No, I think Robert needs to take the thousand ideas that I can see pinging around in his brain. [Laughter] A pinball.

**Robert | 52:04**
Yeah, it hurts. I feel like I can feel it bouncing like my head's going to explode.
Yeah, it really hurts.

**rhdeck | 52:18**
Then. Then, friends. Thank you so much. We'll be talking at the end of the week and we'll meet again on SC next Tuesday.

