# State Change Mastermind - Jul, 15

# Transcript
**Speaker 2 | 00:01**
Got the whole group together.

**Ellie Rofe | 00:01**
We got the whole group together.

**Speaker 3 | 00:04**
Hello everyone.

**Speaker 2 | 00:09**
Fantastic. All right, well, let's go around the horn. What kind of week has been true today? That was not true this time a week ago, and Robert could be... Hey, look, for Robert, definitely has this sharp trim going on too, Yes.

**Speaker 3 | 00:27**
So my brother's wedding was this weekend, and it was actually excellent. It's kind of amazing. This is a very short thing, but I asked Ray for advice on writing a best man speech.
That was a week before I had to write it, so I had already been thinking about it for six months, and I just couldn't get an angle on it. But just to say that was the perfect approach, basically Ray's advice was to humanize my brother and share that perspective.
So I just wrote it from that angle, and I couldn't have imagined it going better. It was one of those... It's ridiculous, actually, how well it went where everyone was like, "I imagine..." Before leading up to it, I almost imagined in my dreams that people would laugh and cry and say, "You did such a good job."
But that's a dream, right? That would be amazing, but holy crap, it actually went over extremely well. I'm just buzzing from it. I just can't believe that I actually pulled it off so well.
So I'm just happy for my brother. Thank you, Ray, really for your advice because that was just really amazing from a grip perspective and not a common perspective.
Because I was listening to the other speeches, and I could see my... Like. Things sound different when you're saying it to a microphone, to a whole group of people. I have a middle brother who got married.
I have a youngest brother. He's so... The middle brothers, the one who got married, the youngest brother likes to pull the middle brother's tail. There's always the one who likes to pull the tiger's tail.
He just comes up and he's just delivering one-liner after one-liner. Because my middle brother is a lawyer, so he's making lawyer jokes back-to-back of lawyer jokes. It was just like, "Danny, please, just put me out of my misery.
Just put me down. Take me out to the back and put me down." I just couldn't take it anymore. I see my brothers like this at the table. My dad is a bit nuts. So, he goes up there and starts making serial killer jokes.
Literally, because he just watches murder shows all the time. So he's like, "You guys know that in Canada, if you kill somebody, you get 25 years?" So, it's... I don't know, I try to make a connection between that and being married for 35 years.
It didn't land like that, and the crowd was like... So, Bin was definitely... Yeah, I appreciate it, Ray. I actually think in a funny way, that this type of work really helped me with it.
Because I talk to people all the time, and I have to make quite a bit of sense when I speak to people, so it helps. Other than that, that was something that really consumed me for just a while.
Especially leading up to it, it consumed me for the days leading up to it. And obviously, because there's family. Right now, I'm sitting on the couch because I've been recording.

**Speaker 2 | 03:45**
In progress.

**Speaker 3 | 03:46**
My space has been occupied, you know, my workspace. But to say that I actually had a meeting yesterday with Perksh and Andrew from Zano. Yeah, and that went very well. I took your advice, Ray, and it was a very tight meeting.
There's so much to discuss when they have a lot of questions about what I thought about Xanoscript. I told them that it's not smooth to use, but I gave my opinion. It was very...
Then I just made the easy suggestion: "Weapon, with Daniel Petro, let's do it." They loved it. So that was very positive. I had another meeting with the market... With somebody yesterday.
Actually, he left me a video testimonial after the meeting because he felt so positive about it. He told me that he literally blew his mind. He actually found it very complimentary. I felt validated. It's funny
that he felt that way. He was not aware of the work that Ray and I are doing. He thought that nobody else was working on cutting-edge stuff, but he was using my name. He said that in his mind, he didn't think that anybody else except for us were doing that. He asked me, "Who do I learn from?" I was like,
"Ray." I don't know who else I can learn from. I guess I just learned from Ray and I read long-form content. I do a lot of the work and so much of
it. It was an excellent conversation. He's a person who knows his stuff, but so am I. He felt that he could benefit quite a bit from me, and I'm just getting back into it now.
That's it. I'm just coming back into the work and trying to use the energy to do things better than I did before. It's like a new opportunity.

**Speaker 2 | 06:02**
Excellent. Can I just quickly ask, after you had that meeting, do you then follow up with Daniel?

**Speaker 3 | 06:08**
I did not, but I did follow up with Precaution Andrew. But I should follow up with Daniel.

**Speaker 2 | 06:13**
Yeah, if Daniel's the actual next step is you know, these things, what's the expression time kills all deals?

**Speaker 3 | 06:21**
That's a good one. I actually haven't heard that expression before, but I will follow up with Daniel.

**Speaker 2 | 06:29**
Cool. Excellent, wonderful. Do we just check in with you, sir? What kind of week has it been? Was true today. That was not true last ago.

**Speaker 4 | 06:39**
What is true? Starting a journey and building an AI agent. Or at least finding a way to build an AI agent who is scalable in terms of the knowledge base. So the knowledge base can be improved every week using the data that comes from the conversation with the clients.
So I'm reading a lot around this area. I'm learning a lot. Today I joined the Office Arts. It was incredible feedback from people there, finding new ways. I'm running the "I call it personal experiment" on LinkedIn, which means publishing more and more personal content at this time, which means stuff that is only attable from me.
In terms of the results of this, of doing this, I feel it's quite early to talk about it. We're at the beginning of the second week. But what I realized is that if you run through the first week, it works then like an octopus of creating new ideas for the upcoming week and then the week that follows.
So the challenge was to find what I have to talk about for the first week. But having feedback, having joining conversations, the idea comes and it can just be on a calendar and spend the timer with a deadline and just put it today. I used the same technique of scheduling my recording before joining this session.
And I did it. I don't know what it looks like, a holding of 10 minutes, which is fine. If I have a 2-minute video, that's counted as a win. So, yeah, that's it for me.

**Speaker 2 | 08:42**
Fantastic. You make a really good point about being early. It reminds me of a thing that Tim Ferris likes to send around, which is advice he got about strength training, saying he needs six weeks. The other thing is, it's
a useful way of looking at it, right? You should be feeling some progress, right? But you're in it, and you're not really expecting to see real results for that period of time. It puts a clock on it, right? It keeps us from thinking it's going to be forever while at the same time keeping us from being all instant gratification. Pilot, that's very cool, man. Congratulations.
All right. Ellie, I think it is you in the hot seat this week. So maybe we could start with your week, which is leading up to today, and how we can be of service to you for the next 45 minutes.

**Ellie Rofe | 09:29**
The six-week thing is probably something we'll come back to. The check-ins were quick for... There's a long time. So, what's new this week? One of the things that is new is I'm now forty-five, and I was forty-four when I spoke to you last.
So, it was my birthday yesterday. Thank you.

**Speaker 3 | 09:47**
Many happi time happy day.

**Ellie Rofe | 09:52**
And the lead-up to that, I was actually a bit poorly. It's... I have obviously spoken with Ray a little bit about this. It was slightly hard to describe, and I won't go into depth because I don't want to make three men uncomfortable by crapping on about things like perimenopause, but I have not been at my peak.
So, one of the things I've been doing in the past week is refocusing a lot of attention on my health, specifically around my time of life and what that is as a woman. And so a lot of my study has been around fasting things like Jason Fung, The Obesity Code, and Mindy Pelts, fast like a girl and ultra-processed women and all sorts of stuff. I don't actually eat that much processed food because I live in the middle of nowhere in France.
But I've been trying to almost brainwash myself with health this past week, and today I've started feeling better, which is a natural cycle thing rather than actually anything I've been particularly doing, especially as it was my birthday weekend. I didn't do much fasting.
So that's been... I'm feeling really positive today. The week's been a bit fragmented because of mood and things like that, but energy more than anything and lack of focus. All sorts of things.
But I had some good wins, actually. I spoke with a guy I used to work with at an equity house. He used to do stock research into pharma, and I had a really interesting experience.
One of my studies was listening to Robert Cialdini's Influence, which is fantastic. It's so well done, and a lot of it is stuff you probably know anyway, but it is so good to re-listen to it and understand it.
He talks about reciprocity and basically how people feel indebted once you give them a favor. The classic is the person on the street who gives you a rose or a flower wrapped in foil and then expects you to do a favor for them, and you feel indebted.
It's a classic confidence trick almost, but this guy is a non-executive on a startup biotech. They don't have money to do a pitch deck at the moment because they're always raising. So I said to him, "Look, it's quiet for me at the moment. I'm in this transition phase. I could do with getting a bit of noise and testimonials and taking the process that I've been developing for another run.
I'll do it for free or on deferred payment if they want some help with a pitch deck to raise because they do need to get money in. He'd been very helpful. He's always been a lovely man, but as soon as I did that, he said, "I'm meeting with a financial PR person at the weekend who does lay work with Biotech."
I'll talk to her and get you introduced to her so that, because she could probably introduce you to some CEOs that are raising literally the next sentence. Once we'd organize it, I was seeing that in motion and it was incredible when you realized what's happening.
So that was really good, and that felt positive. I've got a meeting in with the guy that I'm doing the... It will be tightly bounded work on his pitch, and I'm getting back up into motion now on the dailies that I'm doing.
I think that's it all ties in, I guess, to the thing that I could probably do with some help on or some reflection and mirroring or whatever, which is I'm at forty-five. I'm not... I've never been particularly... I'm...
This is a big milestone around a thing, but I have been thinking that by the time I'm fifty, my partner and I will have... Fecklessness. There have been times when I've been very wealthy, but I've never saved much.
So by the time I'm fifty, we need to have pension stuff, rigorous pension stuff in place. I'm currently torn between part of my thinking is diversifying. So we live in this house in France, we will be renovating it into a retreat for about six to eight people. It will be a luxury small holding, as it were, that can host people that we could then Airbnb as well if we needed to. I'm thinking of having bricks and mortar because I don't know what's going to happen. We're in such flux with AI, I mean, even bricks and mortar, we don't know what's going to happen to economies and how much people are going to be spending on this kind of stuff.
But thinking of diversifying. Some creative work. A Substack idea. And part of me is... I'm doing daily reps, and I need to give them six to eight weeks, especially as we're in the summer. It's not like that. There's a bit of a lag, and then suddenly as you head towards September, people start picking up a bit more and engaging a bit more if they haven't been over the summer. Do I...
And I'm not shipping a ton at the moment. So do I spend time in these diversifying things or should I be hammering, cold calling, or trying to find funky, interesting ways of marketing the pitch business?
Because that is obviously the immediate cash flow, and that cash flow is going to be going into helping to renovate the home and onto future business opportunities there as well. Does that make sense? I feel like I've just waffled quite a quite.

**Speaker 3 | 15:47**
Yeah.

**Speaker 2 | 15:50**
It does. It's. Yeah, but rather than characterize the question at all. I'm going to throw it to the for to both see how they re characterize it as well as what council comes around and maybe Robert, we could start with you, sir.

**Speaker 3 | 16:06**
I want to just be crystal clear. What were the two options? One option is to call, and then to.

**Ellie Rofe | 16:15**
Should I be yeah, should I be going right?

**Speaker 3 | 16:16**
Yeah.

**Ellie Rofe | 16:20**
My marketing strategy as it stands and even my study stuff, it's not filling my week at the moment. And it's whether I double down on that and keep pushing more marketing and trying to come up with different. Interesting. Gimmicky ways? I don't know. Or just say, right, that's my compounding interest.
That's the thing that's going to be getting results over time, and I can't expect it to all suddenly return immediately. Do I then put some time and focus into this diversification as well so that I've got other irons in the fire?

**Speaker 3 | 16:59**
That's interesting. I mean, I think that so you're essentially saying, is it better to chase two rabbits instead of one?

**Ellie Rofe | 17:13**
Possibly.

**Speaker 3 | 17:13**
Essentially, I would say.

**Ellie Rofe | 17:13**
That's a great thing.

**Speaker 3 | 17:18**
I mean, I think that if you're going to chase two rabbits, it might be good if, in case,
you catch one of them and you find out that you didn't like it. Then you'd be happy that you were chasing the other one. But I think that you want to chase the one that you want anyways, right? The one that you're pursuing with the business and what are the core, central focuses that relate to the upbound calls and everything.
For me personally, I think maybe I can only just say what I would do. I'm not sure. Maybe this is all anecdotal. Maybe it's not based on... It's actually a tough question for me because it's hard for me to base it in anything
empirical. You should do this or that. I can't base it in anything empirical. But I think that if you put more energy into one thing, you might get more out of it. It might become...
I think that there's a certain point where, at least for me, I put a lot of time into just this space, into the space that I'm trying to become an expert in, and I found that it's been rewarding that way because the more that I move into that top percentage in that space, the more that it's just immediately recognized.
Then, that's just from the words of other people where they recognize the positioning that I've put for myself. And I know, like, a lot, even, like I was mentioning at the beginning of the call, the person asking me, "Who did you learn from?"
and all this stuff. I don't really even have a great answer other than I just work with Ray, but I'm very committed to it. I put so much time and so much work into it that I naturally am more ahead of other people.
I think that maybe that applies to everybody. The more time you spend doing this, doing the one thing, then I think there are a lot of opportunities that actually open up behind that.
I think there's a lot of power in focusing on one thing. Again, that's just... There are a lot of factors that play into that. So I'm just speaking very generally, but I can just say that for me, I've noticed a difference in being very much focused on this as my space. This is what I'm going to do. I don't... I used to, in another life, try to do Bitcoin on the side or things like that, and I found that it just distracted me.
Honestly, I don't have the stomach for it when it comes to that particular kind of thing. I just don't, and I felt and I think I don't do that anymore. I don't have any other... This is my business, and everything that I do goes towards this business.
I found that I've been rewarded for that by all my focus is there, and that means I'm just more in touch, and I'm more likely to see any changes that are coming. I can see them from further away because I'm always connected to it.
I think there's only so much energy. If you're going to put energy into something else, there has to come from somewhere, so it's going to naturally come from your business or wherever else that energy currently exists.
It's going to... That means that it's going to be less going into that, so know nothing comes for free, but then maybe that's the trade-off, right? So again, it depends. Every person has a different circumstance, but personally, if I knew... That's just what I want, which I know this is what I want. I just keep doubling down.
Then I find that if I can succeed to the degree that I aspire to in this field, those are things that I can turn around and turn in to basically send out the money and make your work as soldiers for me. The money. Go do the work and do the diversification.
Then let me stay in my zone of expertise that I've established, but just.

**Ellie Rofe | 22:17**
Yeah, no, it's really interesting and very helpful, I think.

**Speaker 3 | 22:17**
That's just my 2 C2 cents.

**Ellie Rofe | 22:26**
I think part of the reason I'm feeling like I've got time is because the study side of things, a lot of it is interesting, but it's refreshing stuff for me because I have done this.
I mean, I've done Pitchdex since I was 21, and I've had breaks and stuff, and I've changed my emphasis in what I do over time. When I first started out, I was doing formatting and design, and that's shifted more and more to the content and the storytelling and the structure and almost like
how to present and coach the CEOs and ways to extract that data. I'm not saying there's nothing for me to learn, but it feels like I'm not sure where to put that energy, that sort of real learning energy, when I keep thinking, "Well, should I try and build a tool for this?"
And I'm like, "I feel like that's just me trying to create another boondoggle like Google." Should I do something like Ums.

**Speaker 3 | 23:38**
That's not a bad idea, actually. For just to decide to interject, but to say that I think there's a. For me, there's something that I relate to there, because every once in a while, I inevitably come to a point where I'm tinkering.
Maybe that's the equivalent of how you feel with your stuff. Because eventually, I get to work on the boilerplate page or an ag-grid even with the MCP tool. And there comes a point where it's just diminishing returns.
For me, just part of my core business strategy is actually to learn and to always be learning and to always try to develop new things. I think that the more that I... Again, I think it's the goal, whatever it is, as long as it's chosen strategically, then there can be something that you're studying it, that you can turn around and use to raise your reputation in the market and fulfill your curiosity for working on something new.
Make that part of your delivery. So, if it can hit all those things and then it can scratch that itch for you, for me, that's a very key part. Otherwise, I would go insane. I would still be working on the boilerplate if I didn't get bored of the things that I'm working on, and I'm always getting bored by the things I'm working on, which is fine, it's great. I just try to get bored of it while other people are getting interested in it.
So that I'm just working on the next thing. In two months, I'm already on something that they're just realizing what I made three months ago, and I'm already on to the next thing, raising my reputation.
I think that if you can connect in this game, I think of running a business online, it's good to be, I think, a type of polymath. If you can do everything, and you can do more, if you can create software, if you can do those things, then...
I mean, I can't possibly see how that's... I can't. I think that that's another form of diversification. Maybe it's diversification in your own skills. Right. Just I guess you're talking about diversifying.
Maybe I'm imagining it one way, but now maybe that's another way to frame it: that you're diversifying in your Plan B, which is still related to making Plan A work. It's not like something that's going to go and take you in totally different directions.
It's like a variation that seeks to bolster your core efforts.

**Ellie Rofe | 26:22**
To stor.

**Speaker 2 | 26:30**
Could we bring two interests in this conversation?

**Speaker 4 | 26:40**
Ali? With your permission, I guess [Laughter] from what you mentioned, you feel on a or on a pressure to adding money in on the weekly base, right?

**Ellie Rofe | 26:45**
Have my.

**Speaker 4 | 27:00**
Am I correct? Is this the financial goal you have as a business?

**Ellie Rofe | 27:05**
Sorry. You cut out of it there.

**Speaker 4 | 27:08**
I'm sorry.

**Ellie Rofe | 27:09**
That's okay.

**Speaker 4 | 27:11**
Just to clarify the business goal at the moment.
Is it to bring more revenues on a weekly basis? So we have to define the actions to achieve that.

**Ellie Rofe | 27:28**
I mean, my goals in terms of getting clients are quite conservative, like they don't have to be extensive at the moment. Two clients a month that tide me over nicely until I can expand.
That's it. It's not so much a weekly thing as me thinking two clients a month is a good thing to be aiming for within the next six months and then work out how I best scale that from there.

**Speaker 4 | 27:55**
So.

**Ellie Rofe | 27:57**
Whether it's me bringing in more people to help with certain parts of the execution or me increasing prices and doing more, you know, that kind of thing.

**Speaker 4 | 28:08**
And your services, you include the copywriting, code coding, pitch decks, and the branding stuff because I know you have the experience of doing that.

**Ellie Rofe | 28:22**
So at the moment, I am just focusing on pitch decks if a client asks me. So one of my clients who's on a hiatus at the moment because he wanted to do an interim raise before he did his big raise.

**Speaker 4 | 28:34**
TOMM how much time does it take from your current activities?

**Ellie Rofe | 28:36**
I think they've run out of cash, if I'm honest with you. So once this interim raise is done, he asked me if I'd help with the website. That will involve branding, copywriting, et cetera.
But that's a back-door offer. That's not the front door. It's only... I think the company is right to do it because otherwise, those projects are an absolute nightmare.

**Speaker 4 | 29:06**
How much time does it take to get into a new engagement? Have the introductory call, which is usually free, and then start having paid hours with them.
How long does this remain?

**Ellie Rofe | 29:24**
So at the moment, there isn't stuff... I'm just still in that trying to get people in. So I'm working on these calls and connections and stuff. So I'm in hiatus with a client. I'm waiting for another one.
So at the moment, I'm not shipping anything, generally speaking, mostly when... Funny enough, the guy I spoke to the other day said everyone in biotech is raising all the time. There's another point when they don't need money.
That's true for a lot of heavy, capital-intensive businesses. But mostly, my focus is on saying, "Let's push this through fast so I can create the process I'm using." I can create a pitch deck in 20 hours from start to finish, with them having to give about five hours or six hours of their time in that process, and the rest of it is me doing behind-the-scenes work to collate their ideas, push them together, put them into the outline, et cetera.
So the deck itself isn't that intensive. And the time from speaking with someone first to getting started? It can be two days, it can be two months. It depends on where they are in their processes.
So at the moment, people are getting referred to me. It's not like inbound from marketing activities. So at that point, some of them were someone said I should pitch about this pitch deck.
Then they say, "Well, actually, we've got these events coming up in these conferences, and we want to be a bit tied up with it or we're just trying to work out our clinical trial strategy or something like that."
So it really varies. Does that help?

**Speaker 2 | 31:14**
Yes.

**Ellie Rofe | 31:14**
No. How long is a piece of string?

**Speaker 4 | 31:18**
Yeah, that makes sense.
You know what? I feel like we're on the same position somehow. I try to be more focused so I avoid the less qualified people knocking my door and having the pressure of finances.
I have to keep it in balance instead of doing that fast lead.

**Ellie Rofe | 31:44**
And?

**Speaker 4 | 31:48**
Let's call it the bad lead. So since we want to bring results, currently you get results from referrals from what you said, right?
So the first action I would add in my day list is to find success stories from the past and reach out to them asking for new referrals. Reminding them of the incredible experience they had with your engagement. This is the number one again, you have already. The second is to list the channels from where we can get new leads. The channels you already know you already tested.
For example, maybe it's LinkedIn or specific communities, talking with in other communities and so on, and schedule some time in there delivering value being there. I try to find new communities. EI try to find every single week a new community and try to investigate. Not that good to do it every week, but for the first week where you may find one or two, you may have nice engagements, at least for the talk.
Then what I would do is start reaching out to contacts on LinkedIn. You already know who you follow and who you try to engage with. You have a very great view of understanding who they are in terms of profiling.
I'm a very big fan of having these skills. So why not to reach out to them with a question instead of a proposal? Where are you at the moment? Are you going to pitch? Just give them a question if they're going to pitch.
From there, you're going to understand if they are an actual prospect or maybe they will be later in the future. Introduce yourself as a response to their message. Just try to have a conversation with new people.

**Ellie Rofe | 34:17**
M.

**Speaker 4 | 34:21**
Because I'm really sure the most recent followers you acquired or people you sent a request to, they are very well profiled by you. That's why I think about it. The next thing, since Robert mentioned creating a new product from you, I've tested your two products: the product you sent us via email and the case study we did on February at the end of February with Claude Generation. It helped define ourselves if we can put it to market. We're personally and I'm totally sure guys here in the room. We're very glad to guide you and build it in minutes and do it. I don't feel comfortable saying, "Hey, this is a strategy we must do."
I lack experience around it, but we can definitely give it a try. We can definitely give it a shot, and I'm very glad to be a member with you on this journey. Create videos around it a bit. Create videos as an experiment because I have this experience. I visit almost every 15 days this conversation on my Claude and review it.
And so I know that it can bring value. I think that we have to extrovert it to the audience to know you more.

**Ellie Rofe | 36:07**
And these things came out to.

**Speaker 4 | 36:15**
And for sure we can always schedule as many accountable sessions and start pushing our content to the audience. This strategy will pay you back after three to four weeks. This is what I saw from my statistics.
It's not something immediate, but there's definitely something worth it to invest in. And even when the reconstruction comes to your door, because of the timeline you have, then you will be time-pressed.
So, as Ray says, when you don't have time, just raise your prices. [Laughter].

**Speaker 2 | 37:03**
So I.

**Speaker 4 | 37:04**
That was helpful.

**Ellie Rofe | 37:07**
It's helpful. It's working as a mirror. I'm slowly bringing pieces together, trying to assimilate them, I think. So if I'm looking a bit blank, it's not because I'm not finding it useful or impressive.
It's just the way I process these sometimes. But.

**Speaker 2 | 37:34**
Robert put his finger on it. Chasing two rabbits. The framework I might think about is often the advice about doing a side hustle, like real estate or doing a B&B or something is predicated on somebody who has a steady job, right?
That's a source of income and is not a complete occupation of their age and intelligence, right? How can they then put that excess energy and intelligence to work to create equity value for themselves? Right?
So you have a more speculative venture, right? That can be higher returns versus that where you're selling time and money, which is your day job type approach. And I think, as a diversification scheme, that can make a lot of sense because otherwise, you're over-indexing something that just creates current cash flow, right?
So, having investments that have a more risk premium makes a lot of sense, doing the same thing you do with your money, right? You don't leave all your money in bonds all the time.
Do that with your time as well. The trick here is that the alternative you actually aren't going between something that's high cash flow and low risk and something that's high risk and more speculative. You basically have two things that are speculative, and I think that makes it look a lot more like chasing two rabbits because it's not like you're holding a rabbit and you're chasing another. You don't have a rabbit and you need to get them.
I think those things can both be of interest to you, but you probably want to pick what your focus is, and if the issue is cash flow, you might ask, "Okay, what do you need to be doing to create cash flow that takes some risk off the table?"
But I would probably focus more attention on the thing that you think is going to be wealth-generating for you. I hear what you're saying in terms of time of life, whatever. I'm older than anybody in this room.
But the focus I've had come around to, particularly in the course of the last two years, is the number one thing I can do to improve finances, which is just to make more money and to just improve. The people in this room all have a lot more talent than you have income.
What I think of what we're doing here is creating an alignment between talent and income, right? The study cellship thing. It just. It's just a means to an end, right? So how could you do that in a way that's going to create more value for you?
Okay, so that's one consideration, right? What was low risk was high risk? Then there's a second thing that you're bringing up. I think that is something that both Demetrius and Robert have, and they've both grown on to a slightly different way.
But I would highlight his own concern, which is throwing good money after bad, or overfilling small opportunities, right? You are reaching out to people and not really hearing back, right?
You could do more of that, but you don't really have the expectation that it's going to produce a lot more in the way of results. I hear this all the time from founders who think, "I should be doing more."
It is true that in general, you start with more because that's the better new framework, right? But things get filled up, and then you look for what's better, right? That goes with that.
Then what is the new that goes after the better as you get each of these things maximized? I think that what happens is usually when I first hear about it, people just need to be doing the more. What's really happening? They're getting bored with it.
Then what happens is it's not producing returns anymore, and it looks a little bit like what you're describing right now. We need to switch to better and to new because you've optimized this by throwing more.
It is the thing that's right in front of you, but then what's a little bit more adrift to that? I thought Drew's comments about video were really on target for that, right? Let's just get some video out there, not you about the specifics of fundraising or what have you, but you, as I think you have made the comment before, how effective it's been just rebuilding trust with Demetrius, right?
Then, as you are reaching out to other people, they're like, "Hey, what's going on with LA? They go, click, and they see something about you, and they can click, and from their point of view, absolute safety, right?
Because they're on LinkedIn or whatever. They can learn a lot about you in 30 seconds. That, I think, could be quite valuable. When they see it's not just one but a series, that becomes a proof of life thing as well. That probably falls in the category of new because it's not really being well exploited right now.
I think the category of that is like what kind of thought leadership matters, and you've been describing your studying so far. I think really all marketing. Marketing and marketing. Right? Yeah, hi. Maybe you...
If you want to be an expert in helping sell two chickens, there are two things you can be an expert in. One, you can be an expert in selling, and the second, you can be an expert in chickens. Right? So what's going on with the investors? One of my favorite follows on Twitter is a woman named Meghan Reynolds because she gives me more insight into the world of BVC than just about any other follow-up graph going on. She doesn't write a word about VCs; she covers the LPs, right? She covers the asset managers, major asset managers who are deciding where they're going to go to put their money on the VC and for me, that's far more interesting because it tells me where the money is going to be, where the pools are being built.
Then go to the rest of it. What are you thinking more upstream and studying more upstream? That will allow you to deliver more useful content that is about the upstream, which can be very useful to your target audience, right?
Because you're waiting, you know what the investors are thinking? Because that's your job to be the investor whisper, right? To connect these two things. Not to mention, it could be quite useful for you to have more and better relationships with the investors themselves because they want these companies to come in and do a good job pitching because a good job pitching isn't pulling the wool over their eyes; it's giving them clarity as to what the real value is here and otherwise. They sit in this meeting and they have no idea whether there's value.
That's the reason they're not making the investment. But they're not feeling particularly good about it because they know they're missing good stuff that way because of this failure of communication.
So when I was listening to the story, I was thinking about how I think you were describing the dichotomy that you were, I think, a little bit of a false one. Which was I keep on doing this stuff that I think is already over-indexed. Or I go do this thing that's completely over here, which involves doing real estate.
If what you want to do is a real estate thing, that's a whole conversation that's worth having and figuring out. "Hey, where do you want to be focusing your attention?" But the reason I described as a false choice is that I think there are these other angles to be improving your position in the market in terms of what secrets you have, the knowledge of reputation aspects, both that can produce really good results for you in that kind of six-week time frame.
Because we're just following along. The Hermosy thing of saying, "Well, instead of just doing more, let's do better." Zano.

**Ellie Rofe | 45:15**
Can we gain that out? Because I did think. I have thought about this and I can't work it out. Maybe you just expressed it, but I had thought about just getting in touch with VCs and trying to get a state of the market thing and pulling it together into a series of information I could share on LinkedIn and a report or whatever. What's in it for them?
It's not like I'm really well known. I know two VCs, and they might potentially introduce me, but these people are busy and they're constantly getting people asking for their time. So what's the angle?
If we can help me brainstorm that because maybe I've just got some false beliefs or limiting beliefs, whatever we might term them.

**Speaker 2 | 46:10**
Well, when we're talking about these investment houses, what is the state of industry research on them as investment houses, right? So like, where, if you look at it from the LP point of view, right, the people keep thinking that the job of a VC is to go find great founders.
It's actually the conduit. It starts with the LP going through them and then goes that way, right? They're the buyer.

**Ellie Rofe | 46:37**
H.

**Speaker 2 | 46:38**
The thing they sell is on the other side of it, but the reason that I bring all that up is what's the say of secondary research? You have now a lot of skills around working with AI as well. I wonder whether you have some competitive edge you can bring to bear in this specific zone of the market of insight around what's going on in the world of biotech and pharmaceutical investing, right? Being able to take secondary research instead of saying, "Well, I got to read it all." Can you have the bot help you with that?
Right? Can you be generating useful insights? Can you be delivering something to them that they find interesting? Then, if you have that as a bit of a starting point, and this is what you were talking about, what to build.
This is allowing you to put some of your AI stuff to work, but not so much for the purpose of just the pure marketing, right? But for self-understanding of the market, which it's giving you the entree, right? Hey, this is something useful.
What I'm doing is combining AI with a couple of conversations with really smart people. It's 30 minutes. I would, with your permission, dial in and make that the most useful insights ever to learn more about
your views on this. The reason I'm talking to you is because, based on my research. Blah. And then they're feeling good about it. And then, like, I would like to... I put you on the thank you of it.
And I'd be giving you the complete access to it. I remember my dad was in... He did strategy consulting for big companies back then. One of his favorite sales techniques was the survey, right? You go and you would send a survey or they call them up and ask questions, do the interview, and then what they would get in return would be the survey, right?
So, really what he got out of it was conversations that allowed him to look smart to all these different companies that could potentially become clients. You have something similar. You get to build reputation as you're building secrets, right?
Because you get an understanding of the market that no single player has, and you're able to share some of that back with them. I think if their approach and the initial people who will do the conversation with you will do it because they know you, right?

**Ellie Rofe | 49:12**
H.

**Speaker 2 | 49:13**
So there's no arm's length first person, right? But then you do this first couple of people, you want them to have the experience of that conversation. It's like, "Wait, hey, I'm pretty smart. She's asking the right kinds of questions. You should talk to X." Then you're talking to X because you got it referred, right? It's great because you're only looking for advice, you're not looking for money.
This could be lower friction. Now I don't know if this is going to work, but I'll tell you, this is a strategy that works over and over.

**Ellie Rofe | 49:39**
Yeah.

**Speaker 2 | 49:42**
So I think it has more odds than average. You don't go in cold on this.
To your point, you've learned a lot of the basic smarking. You're just being refreshed. Yeah, but what's been going on in the world of biotech investment and financing over the past five years? It's going to be novel to you because that's the game you've been out of, right?
So what does it look like post-pandemic? How has it changed? Is there any useful insight to be had about that? I think if you look at it from that point, not in terms of biotech companies but again, in terms of the investors because that's your half of the equation. You will have content that, even if it feels pedestrian in the context of them, will feel, "My goodness, you understand the chickens from the point of view of the foxes."
So I think there.

**Ellie Rofe | 50:32**
Yeah.

**Speaker 2 | 50:33**
I think there's like, you know, open territory. That you can be exploiting. Here, just by being a little bit more, expansive, right in your view of like what you are allowed to do that would move your business forward.
And I actually think this seems like it feels like a zone where there is a lot of money to made.

**Ellie Rofe | 50:57**
Can agree. It's something I had thought about and then wandered away from, I think, and probably preemptively. Can you just explain what you were doing? How would AI be incorporated into the survey.

**Speaker 2 | 51:17**
So what I would start with is secondary research, what's the state of the industry analysis? Some of the private equity firms are putting this up, but the major investment houses are putting this stuff out, and who are the investment houses?

**Ellie Rofe | 51:26**
Four. Yeah.

**Speaker 2 | 51:33**
And your budget for them to get some of that? That might be paid or whatever, but a lot of this is kept away for free because it's sales stuff from the likes of Goldman Sachs, JP Morgan, and whatever else, right? Just like their analyst stuff, and the fact that there's a lot of stuff and it's somewhat... Some of it can be a little bit inscrutable. Some of it is going to feel like there's a little bit of bias to it or whatever, but you now know your way around, you put AI to work for you. You can take these documents and turn them into Markdown and throw them into something huge like Google Gemini or something and start to compare and contrast what's going on, what seems to be going through here, what is not what was true that wasn't true before, as you sort of give it things in time order, right? You can be playing with the data in a way that one could not play with data, say even a year ago, right?
So you get to use that you're familiar with that exists today. They're useful today. You have to use the knowledge you've been building over the course of the last 20 years plus to understand
the data that's been coming over the last several years, that seems like a pretty powerful combination that allows you to generate secrets and insights that other folks probably a bunch of other folks know intuitively, but most folks don't, and gives you some insight.

**Ellie Rofe | 52:48**
Yeah.

**Speaker 2 | 52:49**
And the very fact that you're using AI for that process makes it all more sellable, right? It's a story that goes into it, which helps sell you a storyteller, blah, but that's what the AI is for, and then the whole survey thing, you can then combine that with the firsthand information you get. You can take the transcripts and say, "Let's put that in the context of what we've already learned." right?

**Ellie Rofe | 53:11**
H.

**Speaker 2 | 53:12**
How do these things fit together? Where do these things get contradicted? Where it's going. What's interesting about it?
You could just be doing what you do, which is asking interesting questions. You could ask both the person when you're in the room for 30 minutes, but even more with the AI, and you are in a position where you can be asking lots of questions without time limits on the AI. The big problem is if you just ask the AI these questions, it's bullshit, right?

**Ellie Rofe | 53:21**
Hu.

**Speaker 2 | 53:38**
But if you start by loading it with good data, which is not a super thing to do, it's something you already know how to do. We, like Demetrius was talking about, the stuff he did for the sessions. He didn't say change. My goodness,
this allows you to show your... Once again, the process can be as interesting as the result, right? Because you get to talk about how you're taking this data, you're putting it to work in AI, you're generating unique insight from it, right?
This is all part of your process for gaining more insight. It's not just gaining insight that's internal to your business; it's insight that goes across to what there are people looking to buy.
Then that becomes more exciting, right?

**Ellie Rofe | 54:24**
Yeah.

**Speaker 2 | 54:24**
And gives you more opportunity to be creating more credibility in the market. It definitely falls in the category of better at the very least.
I think there's probably a dash now in there as well.

**Ellie Rofe | 54:36**
M that feels like not just a more valuable experiment but one that gives a tangible product that I know people would be interested in, that these founders would be interested in.
Okay, that's really interesting. Okay, chase one rabbit. Videos. VCS.

**Speaker 2 | 55:12**
Is there a way for us to take chase one rabbit and make that a VCS as well to make it like.

**Ellie Rofe | 55:15**
[Laughter] Vocus.

**Speaker 3 | 55:16**
3vi?

**Ellie Rofe | 55:18**
No. [Laughter].

**Speaker 2 | 55:30**
A couple of thoughts from Robert Danger, and then we'll bring it to an end.

**Speaker 3 | 55:36**
I was just going to add that if it is of help that I'd be happy to, for us to schedule a time where it could be of support, especially with developing an AI product.
If there's something in the world of MCP, I know quite a bit about it. If there's something that would help you, I'd be more than happy, right? This group is one of.

**Ellie Rofe | 56:09**
That's incredibly kind. Thank you, that's really kind.

**Speaker 3 | 56:11**
Yeah, of course. Well, yeah, it'll be more than my pleasure. I just totally want you to know that. You could turn around and that could be whatever it is. If you have an idea that you see something out there, just as... Whatever it takes to help you grow faster with it. I would have put that on the table. I would be happy to help.

**Ellie Rofe | 56:40**
I think I'm going to go and do a bit of planning and research now, and I'm sure I'll be taking you up on that.

**Speaker 3 | 56:47**
Sure, please do.

**Speaker 2 | 56:51**
All right, I guess we'll all head back into chasing our rabbits. Thank you so much, Robert, Beriz, and Ellie, and we will do this again next week. Thank you, it was wonderful.

**Ellie Rofe | 57:00**
I really appreciate that. That was incredibly helpful. Thank you.

