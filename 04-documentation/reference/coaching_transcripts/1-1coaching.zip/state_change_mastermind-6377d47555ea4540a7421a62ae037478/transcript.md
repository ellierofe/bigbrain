# State Change Mastermind - Aug, 19

# Transcript
**Ellie Rofe | 00:04**
Hello?

**Ray | 00:07**
Good afternoon, Klly Hoy doggie.

**Ellie Rofe | 00:09**
Okay, right. Sorry, my speaker is just coming online.

**Ray | 00:18**
I am very well this afternoon. I feel like it. It's a little bit of a return for me because my sons have been hither and thither and yon for the majority of the last couple of months.
Now, for the last few days, we've actually had our usual morning school routine. It's just getting back into that.

**Ellie Rofe | 00:38**
Does you answer again?

**Ray | 00:40**
It's really fun. I was just talking with them both about yesterday. We were looking at stocks and bonds as a spectrum, right? Of corporate finance. Today, we're talking through the sources of the Great Financial Crisis, right?
How leverage played. We're doing a course in corporate finance right now, so this is all of a piece. It's just delightful to have these types of conversations in the morning.

**Ellie Rofe | 01:09**
Yeah. How do you define the curriculum? If you don't mind me asking?

**Ray | 01:15**
Initially, I was doing it fairly straightforwardly, looking for workbooks that related to subjects in grade by grade.
So, when we first pulled them to do the homeschooling thing, I moved them right up to fourth grade just to keep it interesting for them because, frankly, a lot of the stuff at the earlier grades is a lot of repetition.
They were ready for something a little more exciting, so we did that and worked away through the elementary school and middle school curricula fairly rapidly. That means over the course of the first couple of years and then
we're getting into high school stuff. And how do we then pick those, and do we do like a history book or a math, which are pretty exciting, and just trying to keep it forward, trying to develop their thinking right in advance is a tricky thing with kids of that age. They're very smart and they're able to handle complicated ideas, but they don't have attention spans.
So, the idea we're just scaling up the size of the project is not quite in tune with where they are developmentally in terms of how long they work on a problem, but their ability to handle complex problems is really high.

**Ellie Rofe | 02:36**
Yeah. M.

**Ray | 02:39**
So one of the reasons why... Actually, I am now a firm believer that kids should be taught calculus much earlier because calculus, I would say, is complicated without being big in scale and stuff, right?
They don't... It doesn't need to be correlating with writing 20-page papers. 20-page papers. They don't really have the patience for that, but to do a rather complicated math problem, they definitely have the patience for us.
We're doing integrals, whatever. Right before they were going on their little tour of the world, we finished up introductory linear algebra and got them into the basics of what we would call deep learning or the machine learning side.
We had started working on this finance course, but you asked a question about how to pick, and that's actually where I initially had a lot of it, where I was following a curriculum from a company called Carson Dellosa.
Yeah, but as that curriculum expired because it's really only good if you're doing elementary, middle school, or high school as we call it here in secondary school. And as I start getting them into what we would ordinarily be doing more at the collegiate level here, picking those things gets more challenging.
So the experiment I'm doing right now is mixing things from MIT and Yale, both of which have significant open-sourced and recorded courses. So, like a lecture series from MIT and the corporate finance is actually for MIT Sloan School, right?

**Ellie Rofe | 04:10**
Yeah.

**Ray | 04:17**
Which is their MBA school.
And giving them the lectures right, with Professor Andy Lowe over there, and then working through the primary textbook between the two of those, how to get them a good grounding because they've got the patience to work through it and they don't have the entitlement of being 23 years old.
I don't want to do a reading or whatever it is. The opportunity to just give them that kind of insight from great professors and people who have written these serious textbooks is just enormous.
There's a lot of just getting in there and getting out of the way and allowing us to have these conversations in the middle. They're just about how to connect the ideas together. Sorry, long answer.

**Ellie Rofe | 05:01**
Are there any subjects you have to teach yourself before you teach them? Or do you learn alongside them? Or are you pretty much over the stuff you go through?

**Ray | 05:12**
I learned alongside them a lot. I was trying to get ahead, and then I realized that they learned so fast. One, when we started the whole know, this open courseware stuff, one of their early reactions was, "This is too slow." Here they are going for material that ordinarily would be among people who are twice their age, and their reaction is, "Can this go faster?" They reach over because they know the videos can go faster, and they start watching a thing at 2X and it's just blipping, flipping along.
They're like, "Okay, yeah, now this is fine. So yeah, I'm just trying to keep up, that's the answer to your question. Frankly, with the three of us, I've learned that a pattern works well and can be a lot of fun.

**Ellie Rofe | 05:49**
Right. Enough.

**Ray | 06:01**
So one of the reasons why I'm trying to keep up with the three of you is to check in on what the last week has wrought. Dietrich, can we start with you, sir? What is true today? It was not true last week.

**Speaker 3 | 06:20**
Guys, I had a conversation yesterday with Ali. What is true that wasn't true since yesterday is that I had the experience to see for the first time in my life marketing terms in crystal view and explanation. Even on my MBA, I didn't have the experience of understanding well what exactly we have to do, because in all of those conversations, everything was too theoretical and too general for me.
Yesterday, first of all, she explained to me a couple of things why they matter, what these matters are, what should be an actual action plan, which should be my KPI around a 8, not random stuff, but specific things on go and doing these things and find a way to communicate. She shared with me a closed conversation we started together and was super amazing. Solving the problem. I had mentioned a few weeks ago about the packing, how to pack on myself between principles and value propositions to my audience.
Even in all of this attitude, even if without having specified my target audience that much, I thank you again. In terms of what I've done so far for the business, I'm just collecting things I have to do because this is the last week for Dogel for the pharmacy.
So I'm generally totally distracted from my business. I collect what I have to do. I apply principles in the pharmacy business. I've learned so far from these conversations and so on. And the last point is that today I had a conversation with a consultant from the team from Daniel Pursley. If I pronounce his name, yeah. Thank you. It was an enjoyable conversation. I joined that to learn from the specialists, from the gurus, let's say, of the market, how they try to sell what they are, what their promises are, and how they do it. All of these, I found that they're good enough, not that good with experience.
I have already been in talks with you guys here and in state aid in general with all those marketing conversations. Because the point is that they share the promises, they share that they have the framework and the methodology.
But they didn't give any specific point about what you can go and do. They used the pricing paid, something suggested from Ray in the past. But when we are in conversation, we show the pricing table on a web page.
So it is from the client's side that I could realize what the impact of looking at the prices is and explain how it works. Yeah. So that is my experience so far. They sent me a couple of things to investigate, and everything is moved for the weekend.

**Ray | 10:21**
Co cool, I appreciate the update. All right, Ellie, what is what was true today it was not true. Weekgo.

**Ellie Rofe | 10:29**
What's true today? I had. I've had quite a few calls over the last few days with near peers. I guess you call them on that I've connected with on LinkedIn.
It's been really interesting. I think I've been having a. I'm resistant to LinkedIn anyway, as you know, and I'm both fully into it and very resistant. It's like a lovely tussle. And so I've been having lots of these calls because I wanted to try engage whether people are actually getting, business through LinkedIn in this sector with these people. What I've gathered so far is that a lot of the people who are getting business directly from LinkedIn in this sector are working. They are working in biotech, but they're working more with companies that are producing something. They're not in the R&D space so much. They're working with companies that are providing instruments or devices or whatever. Not all of them, but the most of them that are getting leads. What I have realized though, is it is just a brilliant place to connect with people.
As networking is such a huge part of it, I am still following that group of people and finding the other people in the industry that I need to be connected with and connecting with them. And probably a far cry from where I used to be. I'm not trying to pitch them or anything. I don't really have anything to pitch them. They're not founders, but I am sending my calendar link and saying, "I'm in this industry, I'm trying to connect with peers, and I'm booking a call."
So I've had some really interesting calls with people who are... Someone's introducing me to a VC, someone's introducing me to some people who run life sciences conferences. It's all just grist to the mill.
Then, as we discussed, the content stuff is... I'm not writing it with the expectation that I'm going to found it. It isn't necessarily going to see it on there. Maybe they will, maybe they won't, but I am right. The expectation I am caning my own brain and refining my thinking and getting smarter.
So yeah, it's all been very positive, interesting stuff, very positive.

**Ray | 12:49**
Excellent. Yeah, the energy from getting to meet with those people. Are you seeing any trends in the market as a result of these conversations? Or are you having... They're more scheduled than they are actually having...
So far.

**Ellie Rofe | 13:02**
The trends in the market, people who are on the investment side are all saying the same thing, which is that investments dried up. Someone was talking about how they're making, they're building huge labs like 8,000 square feet.
I think of labs in Canary Wharf, which is expensive real estate based on the 2021 boom. And who knows if there's going to be companies available to go into them because UK companies are struggling to get funding. I did speak with someone who was involved with Choose New Jersey, which is about getting inward investment into New Jersey in particular.
I think one of the things I need to be doing is trying to reach out into America as well. I have worked with American clients before. Anyway, it's fine, [Laughter] but yeah, it's just... It's obviously so much easier for me to go to Oxford or Cambridge.

**Ray | 13:54**
Americans are fine.

**Speaker 3 | 14:02**
S.

**Ellie Rofe | 14:06**
It's so much easier for me to connect with people in those regions. But I think American, Cambridge, and places like that are probably where a lot of the movement is happening. So I need to find ways in their long term as well.

**Speaker 3 | 14:24**
Got it.

**Ray | 14:24**
Okay, cool, I appreciate the update. Robert, what is true today? That was not true the same week ago.

**Speaker 4 | 14:33**
So, I had a great conversation with Ali. And, you know, she was just very, first of all, very generous with your time and your energy, and I just appreciate that. I felt bad. Later on, I was like, my gosh. I goes, you know, we ended up we spoke for, like, really went through it for like two and a half hours.
And, yeah, it was and like, I just.

**Ellie Rofe | 14:59**
Was it that long?

**Speaker 4 | 15:04**
I know, afterwards, I was mentally... It took the amount of energy to... We started in one place. We ended up in a completely different place.
We got there in logical steps. It put me overall in a good position that I feel like I'm leveraging now, which is just in trying to be more clear into actions that I need to take in order to execute on that, knowing more clearly. Exactly.
Okay. So these are the people with these systems. Then, if you only have a certain amount of energy per day, which we all do, then it helps, right? Just looking at everything and deciding what's important and what's not in light of that, and obviously everything else as well with the website and stuff.
It's just that it was a great session, and it's something that I feel continues to serve me even in the decisions that I'm making now, which is trying to basically take whatever choices I'm making, whether they're small or big, and just align them with finding those types of customers who are the ones that are, let's just say, they have just systems in general. Ray, you gave me a great piece of advice, which is just dropped the word "legacy" from my vocabulary.
It's just systems because people who have those systems don't view them as legacy. They just view them as their systems, but the idea is to help those people, and I've been the biggest change between today and seven days ago is probably just the actions that I'm trying to take every day in that direction.
So, I'm poking people from Rocket Software. Basically, I'm trying to... Sorry, I was just thinking about something. I have a few things. I have a few interesting developments because I have the community and everything is going on. The cofounder of Kajabi apparently has joined my community, so that's cool.
So that's cool. Then I have another call today with somebody who I'm not particularly excited to talk to, but I'll be honest. He knows how much I charge, and he's interested in an MCP. I'm not sure how seriously I'm taking his ideas, but whatever.
It's something. I have another call tomorrow with somebody. And so I'm trying to get that wheel turning. If the metric is basically just how many calls... I'm trying to just increase the number of calls I'm having in general.
That's the same way I look towards the conversations that have to do with systems in general or those types of customers. It's just trying to generate the calls, just get to the calls, and the other thing is that I think that the MCP meetups are doing quite well. We did another one last week, and have another one coming up tomorrow, and people are showing up. I've had calls before where,
when I first started my community, nobody would show up to anything that I was hosting. Nothing. I would sit for a whole year, every week, with nobody showing up. It's funny, I was the first person who showed up. It took six months.
The first thing he said was just to shut it down. I should just stop doing this. So that was the first person to show up in the beginning. But just to say that now I can make a post and I'll have five, six people immediately sign up.
I'm confident knowing that I have stuff to talk about. Just because I had nothing to talk about back then. So that's it. I have... I'm kind of spinning around like crazy, but yeah, that's what happened in the last seven days.

**Ray | 20:04**
Cool. Alright, so, with all that in mind, Robert, today is your task. How can we be of service to you today? How can we help you make the coming seven days as good as we can be.

**Speaker 4 | 20:23**
I think, you know, it's a it's always AI feel like a tough question for. For me to answer. But I think that I'm just mostly interested in. Again, I'm. I don't know if this is the right question to ask, but I'm kind of interested in everyone's perspective in terms of...
I think that we all look at each other and have things that we'd want to like. We all see what each other is posting on LinkedIn and the efforts that we're making, and I don't know if we ever really have an opportunity to just ask each other about what we're doing or just say, "Hey, why don't you do this and that or whatever?"
So I'm curious, is there anything... I'm turning it around, but I have a website. I have the posts I make, how this stuff is, and everyone here knows the stuff that I'm working on and is interested in.
I'm curious. Is there anything about what I'm doing that you'd say you want to tell me? Is there anything you want to tell me and say, "Hey, I think you should do this more. I do this more. You should change this." I'm putting that out there because I don't know if the time for that really comes.
So, yeah, that's what's on top of my mind right now. Is there something about what I'm doing or anything I've done that you've ever wanted to tell me? "Hey, should stop doing that or hey, should change this or hey, you should focus on this messaging more or do less of this, do more of that.

**Ray | 22:17**
That's okay. Well, throw open the floor. Any things you were seeing in Robert's output or what you're seeing of Robert's marketing that makes you have a particularly high or low reaction.
I think everyone's staring at their screens because they're looking but they just brought up your material. Robert, yeah.

**Speaker 4 | 22:43**
Looking at your.

**Ray | 22:45**
So if I might, while we're looking for a minute. I think there's a bit of... What is that you're not doing right now? What's not barking in the night? What are the channels to which you're not availing yourself? You have something that Ellie, Deitris, and I do not have that I think is worth discussing, that it is useful in 20 and 25 in a way that might not have been useful as recently as a couple of years ago, which is you are in a city, you're in Toronto.

**Speaker 4 | 23:15**
Interesting. Yeah.

**Ray | 23:17**
There is a whole meetup culture and available to you to be able to meet with more people, right? And make connections both with fellow foxes, right? But with chickens, because there's a lot of market that's right outside your doorstep in a way where Ellie needs to make many more steps outside of her doorstep in order to be reaching the market.
Same is true for Deitris. The same is true for me. I live on a mountain. I'm 200 miles from town, and I got to experience this a little bit more. That was my sons were just spending two weeks with my wife. They were house sitting, cat sitting.
But at an apartment in Cambridge, Massachusetts, they were right next to MIT. They were rock-throwing distance from IBM's AI headquarters in Cambridge and a whole bunch of other biotech as well as information technology companies, right? They're all about... They were able to go to museums and go to universities, but there's a whole meetup thing happening right after work. People get together and they do these. You are in a wonderful position to be able to go get a talk and you are a very interesting person to be talking to. Now, I appreciate that being in person is not the same thing as talking on these rectangles, right?
But it is access to the market where you can be conveying trust at a higher level of resolution because it's in person as opposed to being mediated by these low rectangles. And there's opportunity to be learning more and opportunity to be betting, and so both in terms of study and sell. I don't know what you're currently doing with that, but there is...
But we are now at the end of the summer, getting into a range of a lot more stuff happening, into... I'm not sure... In Canada, it's Labor Day, but like Labor Day, it's usually in the US, the beginning of the fall season, usually be back-to-school season.
As we get out of that, which is the traditional summer break for colleges, we see that stuff start to pick up, right? There's a window between now and, say, December, right? Where it's going to be a lot easier to do because it's not going to be chilly and unpleasant outside.
Yeah, right. So, the thing I look at is you're not currently doing it, and the fact that you're running those meetups so well in the corners of the last couple you did, which have just been bangers, by the way, for those of you who haven't gotten to attend. The... I there... I would wonder if you could cheaply avail yourself of those things...
And be able to increase your reach in a way that is cheap for you, dear for us and for much of your competition.

**Speaker 4 | 26:02**
Yeah, I actually think that's pretty spot-on. Probably... I mean, it's something that I'm very comfortable with because it just feels like almost... It's weird now to think about it as being something that was a long time ago, but it wasn't that long ago that using Zoom was weird.
Now, most of my interactions in professional work and everything were all in person. I had never had a single Zoom meeting, and everything I did was an in-person presentation in front of just...
So I appreciate that. The idea of walking into a room like that is actually not unfamiliar to me. So it feels like something that. I think it's worth, doing. I just don't know how to imagine. I guess the experience, but probably the first step is to take is just to follow those links that you kindly sent me, right? Which is, you know, just sign up and just show up for one of those. One of those events.
But, yeah, I think that you're right. That and I've only heard good things about people showing up to those types of. I've it seems like there always seems to be some type of business to be had at these types of places. This is just from, you know, just hearing the stories of other people going.
And it always seems to be that from showing up to these type of things, that there always seems to be chickens somehow. And even though, like, you'll look at it and you'll think, maybe. I guess the way that I would by default think about it just. Or the way that I have always put it away in my head has always been me thinking of it in terms of that there will be other just only other foxes there.
But there always seems to be somebody who wants to do business with you. It seems speaking as a person who's never been.

**Ray | 28:03**
Right and while chickens are the most valuable, I would not discount the value of running in some fox as well, particularly in your chosen domain because you're switching domains, right? This is why Elliot is like going to meet peers, right? She's meeting other foxes from her domain, people with whom she will not buy her stuff, but they're both going after potentially going after the same chickens and potentially noncompetitive or even a symbiotic way there. There are lots of... I'm looking right now...
Across August, there is stuff as soon as this week, right? That's sort of out there, and it should ease into what you think makes sense. But, like, I think it's lying there on the ground.
But based on my experience in Boston doing this a couple of times, they're not crazy about attending yet, even for topics like AI. There's an opportunity to have a real conversation, which then you can turn into content, you can turn into recordings, you can turn into all sorts of good stuff.
Anyway, that's what I wanted to seed with while I was buying time for Ellie and Beatrice to be taking a look at stuff. I'll turn over the four to whoever would like to kick off the second part of the conversation.

**Ellie Rofe | 29:25**
Did you want to go, dimetris?

**Speaker 3 | 29:29**
Yeah, I'm thinking about that. From my perspective, the most enjoyable thing I ever did from my university years when I was a student was joining those meetups. So it was like the weekly hangouts we have in this community here. Not only the mastermind, the other ones too, there are some of them that are failures definitely because of the personalities that join.
Yeah, but you should not criticize every single group based on one experience. The first rule I would mention is not to ever disappoint. From that, joining these meetups is a huge opportunity to learn from local people what they're doing.
You will find incredible opportunities because people from the countryside join those meetups, and it's more enjoyable. In Athens, this wasn't true, but in Thessalonica, which was a more rural area, I expect it is the same, and the second thing is why not to start creating your own meetup there?
For example, why not organizing an MCP meetup powered by Snappy and Zano where you can have the funding of Zano? For example, we're planning to do something similar with Zapier in Athens, in the middle or at the end of September. It depends.
How can you do it? You can. It's quite easily. What do you want to achieve? The first purpose, the core purpose of the adup, the midup, is the networking. Really, nobody cares what was presented, but if something attractive and interesting was presented, it always motivates. I joined in data analytics, meetup back in February, if I remember well, in Athens.
The guy was talking about the revenue ops workflows he made in a company he joined. Nothing about data. He didn't even mention a percentage as a KPI, which was incredible. Then it inspired the conversation after that. The bear.
So you can select a place where you can have some space to put some chairs at a projector or a TV for the presentation, and everything can start as a conversation or without a presentation like we do or what you do on Wednesday's conversations.
So I would suggest this definitely to do it on a monthly basis or on a quarterly basis. That would be amazing. It doesn't cost you and at least five people will join. In my experience, those meetups with less people are more enjoyable and interactive.
The other thing is, why not to connect? I don't know how good an idea that would be, but why not to connect with a university? You live in an area with a strong, really strong university community. Why not to contact a teacher?
Sorry, a professor who is in this domain and ask him to do a seminar for his students. You just put a huge present, a huge Ferrari in front of his desk. Yeah, because that way, he connects more with his students and he shows to other tutors his projects and his workload. I don't know how exactly it works.
In Greece, unfortunately, universities are totally connected with politics and parties, unfortunately. But sometimes I see TE tutors looking for these kinds of opportunities to make connections with consultants with big companies and create subgroups of people. Why not to join that and give opportunity to students?
The reason I'm mentioning that is that I see guys' things getting super viral from the younger generation in uni always bucking the Facebook, bucking YouTube, and years back in Instagram, university students were a target group, and this created a hype. They are not the people who will you convert. There are people who can let you create something that will be valuable for the target audience.
I think.

**Speaker 4 | 34:49**
Okay, I was just going to say that, I think that it's actually... I'm not sure how it is in Greece, but I think it's a good idea, especially because here it's mostly just up to the professor or up to the teacher.
I mean, I think it's just about asking. Even as I think about it, there are opportunities that I think about where they're asking for people. They're looking for people to come speak on a certain topic.
So, yeah, I appreciate that because now it's getting me thinking about some of the stuff that I've thought about, and it's like, I'm not going to go and talk at a school, but now I think about it, I'm like, "Maybe I could go actually go and speak to a classroom." I certainly could, yeah. No, it is really interesting.
This is actually... These are really good answers to my questions, actually, because all this stuff is stuff I've never thought about. So, I'm getting... I'm definitely getting the answers to the question that I asked.
So, yeah, thank you, Jimmetrice. If I'm a lot of these things, I don't have a lot to say back because they're all totally things that I have never put that much thought into before.
So, yeah, if I'm a little bit short on words, it's not because I don't find your feedback great. I'm just like it's all new to me.

**Ray | 36:26**
Yeah, and not for nothing, I think that's really good and smart to be saying that they'll be looking to get more from your fellow masterminds, right? Get them to talk more. And my rule I have learned at Masterminds is that you get feedback in the hot seat.
Basically, your answer is two words, thank you, right? That way, you're getting them to give you more. You can choose what you're going to do with the council, right? But I think you're on this approach totally great, and I think you've already got the intuition for it. Let's turn it over to Ellie and get her thoughts on your original question.

**Ellie Rofe | 37:02**
I love everything that's been said so far, actually. Just to reflect, meeting up with near peers and adjacent people, there are two parts to it.
I've always avoided it, partly because I didn't really want to be doing it and I didn't feel like I wanted to be fully into this. I'm not part of that industry, right? That was part of it. Part of it was that I was to do with impostor syndrome and feeling a bit like, "I don't know enough." I'm not a scientist, et cetera. The more I speak with people, the more confident I get, the more I realize my positioning. The more I realize that there aren't that many people who are specialists in the pitch deck for BI biotech and life sciences. I get to know who I might be able to refer for work that I don't want to do for clients.
It's there's a huge amount of good going on there, which just... You get ideas, you start talking about things, and you realize where patterns are about how founders behave, their thought patterns, or whatever.
I loved the idea of talking at universities because it is instant credibility. It instantly puts you there as an expert. I've given a talk at the University of Toronto on MCP, BAM, that's incredible.
I think allied to all of that really is, based on the discussions we had on Friday as well. I know that it wasn't you, it was AI that didn't realize it was that long, but we definitely went through some stuff and worked out who you were talking to and what you wanted to say.
I think that is where meeting up with people in person as well will help. Because the one thing I would say from my marketing brand positioning side of things is I don't think you're talking to your clients enough.
I think there's some really interesting stuff in LinkedIn posts, but I'm not sure that you're talking to the people that you are trying to help. You're not saying, you're not talking about their problems with trying to adapt their systems to the world of AI, you're not telling them how easy it could be to turn this kind of mesh of databases and APIs and all that kind of stuff into a system that sings and talks to each other and helps. You're not showing them what that looks like when this face is talking with this piece.
I think, and actually getting out and talking to them in person, the beauty of doing that is it gives you a frame of reference. When you are writing stuff as well, you actually have someone to talk to. When I used to write comedy, every now and then I would put a picture of someone that I loved joking around with behind the laptop screen, poking up above it to help me with the tone and key me into that. I'm writing to this person.
I think when you're going out and talking with people, you will start to have that more when you're writing stuff so you can literally write stuff they need to hear.

**Speaker 4 | 40:12**
B.

**Ellie Rofe | 40:26**
Which I think will help.
It's not that you're not doing it right. You're doing loads of really great stuff. It's about your positioning, which is why my little brand strategy heart leapt when I heard you give a talk at the University of Toronto, for example.
It's like you're positioning yourself, and we spoke briefly about how you get yourself to the point where every time there is a talk or a conference about MCPS, people are inviting you. They want you to be there because you are the expert on MCP in crossover systems, whatever you want to call them.
That's your positioning, and so that's where I was like, "Yes, that's exciting." I think you need to talk more about it because then it positions you in people's minds as the person who does this, not just MCP but MCP for these people.

**Speaker 4 | 41:20**
Yeah, for sure. I think the amount of... It's funny because I feel this. I definitely feel like this internal resistance to doing it just because it's out of my happy place or my comfort zone.
Which is I recognize as an indicator that's good to move towards because well, I can even just my own resistance is not that hard to overcome for showing up and speaking to people.
But I know that for most people, they won't want to do that. They're not going to do that. So I like the device because it feels like rolling loaded dice in a way. They're more likely to show up.
Well, or to... I don't gamble, so I'm not sure what you want to look for when you roll dice, but whatever. Let's say double sixes are good, hopefully. I'm not sure if they are, but the point is that if I feel like showing up to those things, doing those things, will just... It almost feels like you're 80% going to get something out of it if that makes sense.
Even showing up. There would be competitions in school, and there would be... You're supposed to invent something or come up with something, and it wasn't that hard to come up to be in first place, second place every time.
If you just... Because there weren't that many people, not many people would even sign up for it and go for it. And I think that was... It reminds me of awards in schools. A lot of people wouldn't even apply to them.
So you just applied to all these awards, and you would just get awards. So trying to hang on to the positive reinforcement. But, yeah, no, and I definitely take your point about writing to specific people.
I think that's for sure that's something that I need to speak with people to figure it out, right? And I think for me, it's the fact that, for better or for worse, I always just TED to write a... I guess that's why I work so hard in trying to build something or create something because whatever I want to write about, I want to be based on something that's real.
So I don't have real conversations, but I can build something real so that I can talk about that and be like, "Hey, this thing that exists." But then there's that line where, okay, talking about this specific implementation, we'll do XYZ for you.
Then I'm like, "Well, I haven't..." I just can speak about it hypothetically, but then I'm like, "Well, I really..." It has to be concrete. Or would feel something more concrete.
Maybe not whatever definition of concrete is, but something that feels more really legitimate. Because I feel that it immediately is recognized by people when it's legitimate even in the way that you write about it, in the way you speak about it and the conviction that you'll have.
So, all to say that essentially, if I do the other... If I do all those actions, probably show up to the schools and talk to people, and if I try to take on more... If I show up to the hangouts and organize hangouts and do that stuff, then it will probably exponentially increase the quality of the content that I'm putting out and the people that I'm declaring on who I'm writing towards.
So, yeah, thank you just.

**Ellie Rofe | 45:24**
Yeah, sorry, I was gonna say I do. I totally get that. I haven't done it for these people, therefore, I feel like I'm selling air. I'm not selling anything real.
But at the very least, you can talk about the experiments you've been doing and why you've been doing them and what they do for those systems.

**Speaker 4 | 45:45**
Yeah, for sure.

**Ellie Rofe | 45:50**
If you've done that with a Universe system, then talk about it, and I know you've mentioned it, but we really like this: what it can do.

**Speaker 4 | 45:57**
For sure. S.

**Ellie Rofe | 46:04**
We talked about features, outcomes, and benefits.
I think we talked about that, but thinking about what it is that this is doing for people rather than just the tech side of it and talking about it, talking about how updating a system with an MCP that's built on Universe can create this, can do this, and you can pick one for each thing.
If you create an MCP for.

**Speaker 4 | 46:34**
Yeah.

**Ellie Rofe | 46:36**
For your Universe system, you can do this amazing benefit, and then just talk about the experiment.

**Speaker 4 | 46:47**
It it's a way to I think just almost forced myself to put a bow on it in a way, like to in a sense of that it's tough to walk that line because I don't know how much of a bow to put on top of it.
To say like, I'm the person who knows about this technology and I'm here almost to reflect the questions that you asked towards me.
And then I'll come up with the solution by massaging it together in real time. And they're almost describing the solution to me versus I'm the person who's going to come and present this answer to you that that's more formed, and then you're going to look at it and say, I want that thing and that it answers the question that what if I gave you something you never knew you wanted, like in the first place?
And that's requires. I think where Ray was telling me in our talk recently was that it requires them to believe more about me or whatever that I'm offering. This is where it gets into the very edge of where I fall off into the void of my own thoughts at this point. I'm just staring into the darkness there, but the answer is almost to just not overcomplicate it.
I feel like my instinct is just to turn around and just say, "Generate more calls." If I just go into the market more, then it'll bring me more clarity into that whole area where I have no idea of what I'm staring into yet.
So, yeah, just to say that I'm battling with this, but all this certainly helps.

**Ellie Rofe | 48:46**
Yeah the question is whether you want to be an MCP expert or the MCP expert in translational MCP PI. I don't know what you want to call it, because I agree with Ray that they're not going to call it legacy, right? They're not going to call their own systems legacy.
But you know that you're talking about old systems. The title on your thing recently was brilliant, by the way. I've lost it, but you wrote something like "Bridging a 50-year Gap." Yeah, "Bridging a 50-year gap.

**Speaker 4 | 49:24**
Yeah, bridging a 50-year gap. Actually, that seems to resonate quite well. That post at Angle has gone to quite a few people, sorry. I was just... There's a lot to me. Why? Just to say that something interesting came up recently. I noticed that Shopify has adopted the MCP UI, and they've... Well, I saw the way that they implemented it.
Just as again, I'm not trying to get stuck into building things, but just to say that probably brings more clarity to me in terms of where the value is for those because that company has gone...
Actually, I tried their MCP that they put together, and I set it up and put it through. I'm just curious to see how it was built. It wasn't law. I've already done all the hard stuff behind just now. This final stage is not really the part that's going to kill me.
But there was a bit more clarity there in just seeing what's going on in the market. Why would this company go and use this technology? What is it that they're aiming for and gearing towards?
Just seeing how it shows up nicely on the screen. You're having this chat with this AI, and then it shows you the actual buttons, the Shopify. It says, "Hey, click. You can." How much do you want to order? I'm going to choose 2345.
I click, and it actually takes you through that flow, and then it's like, "This actually looks like something." I can't even compare to anything else, right? There's a whole bunch of value layers and just how easy it is from there as an MCP to connect to other things.
So, yeah, I'm just kind of raising that as maybe just a way for me to put more of an answer to that question, maybe just for myself in terms of what is it that I'm offering? What is it even for those universe data?
For those legacy systems, what is a benefit to them? There are a lot of benefits, but maybe that's one way to imagine it in a way that sits well with people who are like, "I like this shiny thing."
Then it can look good as well as perform well.

**Ray | 51:57**
If I might, I think the most important thing in what you just described was you were talking about Shopify Plus MCP. Shopify, first of all, a Canadian story, right? So, hometown team thing, but you're not talking about the technology. I thought you started really strong. Shopify is doing this thing great. Shopify Plus is your area of technology, great. That's about the business side. You're no longer nerding out in technology. You're talking about how it connects the business.
Then you started to go off the rails. You started talking more about the UI part, right? And your part, I find to be very interesting as well. As a fellow technologist, even as a strategist, I find it to be really interesting.
In terms of talking to others, I know that saying this is something that Shopify is really into. This is something that these other companies are really into. This is something that Anthropic is, and Anthropic is so popular that the AI companies have gotten over their competitiveness and are all adopting the same standard. In fact, there's plenty of it, technologically, that's like, "Man, why are we even doing this?"
When I talk to engineers about MCP, I looked at it and I don't think it's very good. Who cares? It's a social construct, right? Likely, it's how the market is adopting it. You being able to speak to that is, I think, really quite strong.
When I think about, "Okay, who should you be talking to?" at the University of Toronto, it's not their computer science department. It's their business school, right? They have an undergraduate business school too, right?
Well, you've got a couple of local universities you've been working with that way. There's a meetup circuit in terms of... Then those are just the live parts. Then there's what this means for content.
I think this idea of once you start opening the door, "Okay, how to think about those events?" You're now thinking about it. Wait, how can you not think about the business side of it?
Because you're not the nerd on this one, right? You and I have these conversations. But I've met the nerds on these. Right? They are far more into the technology, right? They don't care about the business part. You care about both, right? In that intersection you live in, that's the reason why there's money to be made and why there's commerce to be done anyway. All of this is by way of saying that I thought the bit that you were getting into was really strong, and looking back at this,
Krisp... I would dial in on that part because I think that could be a really good piece of content and conversation to be having. And yeah, I think you're talking more about MCP, about its applications, about the business side of it, about the social context as opposed to the depth of the technology or I built a thing, right? You become the expert rather than the builder, and that, I think, is a very profitable place for you to be.

**Speaker 4 | 54:47**
Appreciate that. Thank you. That'll be my wise answer.

**Ray | 54:55**
All right, we got a couple of minutes left, and then I've got to run. Is there any other way this group can be of service to you? Or other ideas, either from Ellie or from Dietri? Right as this conversation has turned here, Dietri, you've heard a couple of things from both Ellie and myself and didn't know if you had thoughts over the top here. That might be helping pile on top for Robert here.
Okay, sorry, I didn't mean to totally put you on the spot.

**Speaker 3 | 55:29**
At the moment, [Laughter] nothing to add. From my perspective, I agree with what is mentioned, and I think there are tons of ideas from today's session to move forward and make them action. I would suggest adding an action plan in the next 30 minutes after the call. Add an action plan including at least one or two things of what we discussed today in order to make it a reality.
Otherwise, you will not see the situation change for sure.

**Speaker 4 | 56:05**
I appreciate that too. I think that's great advice, actually, and I'd like the time frame of the 30 minutes, actually, because it shouldn't take more than 30 minutes.

**Ray | 56:21**
I fact, all right, then I think we'll leave it there. That was a great question to be asking, and I thought it led to just fantastic insights from you. Ellie, I thought that and the whole thing, I thought, was just great. I appreciate and work with you all. Ellie, I think you're up next week.
We will be talking individually at the end of this week, and we'll meet again in a week's time to see them.

