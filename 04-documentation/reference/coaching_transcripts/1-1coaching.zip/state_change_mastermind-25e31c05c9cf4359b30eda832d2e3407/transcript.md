# State Change Mastermind - Sep, 23

# Transcript
**Ellie Rofe | 00:00**
As I can be providing marketing.

**Ray | 00:01**
Right. To provide marketing in addition to the findability of the stuff. Then you can be taking the videos once again, putting them through whatever the thing is to turn them into shorts. That can then be going out into the world where my general expectation is that the events get fewer views on the first round, right?
But they are a seed for getting more content onto your channel, showing regularity of posting or whatever. Because right now my content is really inconsistent. But the podcast I do with Ecen is continuous.
Just every week it shows up, and then that is feeding the shorts, and that is becoming the distribution machine or how all that flows through. Demetrius was asking us to talk about top of funnel, and this is turned into a conversation about video.

**Ellie Rofe | 00:55**
Sorry. What was the first conversation About.

**Ray | 01:00**
Well, Demetrius and Demetri... You can correct me if I'm wrong. I think his question was about marketing and just getting more awareness into the market,
revisiting top of market from top of funnel from Omore.

**Ellie Rofe | 01:13**
One.

**Ray | 01:15**
First principle. Robert brought up the importance of basically idea-based marketing, right? Having interesting ideas and then sharing them because people will be interested in you based on the quality of it.
Based on the quality of the idea, not based on how well you write generally because I think cars are getting into it or how well you speak, but basically, if you're talking about the thing that's interesting to them in that moment,
then we're going from there, talking about how YouTube actually is a little more of the channel for that than LinkedIn is, and that there's TikTok X whatever, which are one extreme of... And you know, algorithmically driven. River of information, right?
But you certainly don't see anything that's all that old, right? It's like, "Hey, what's the right stuff?" From the last few hours, then you have LinkedIn, which is algorithmically driven but resurfaces things for days, which is one of the reasons why the content tends to work a little bit better on LinkedIn. It's usually in the context where people are more businessy in the way they're thinking about things.

**Ellie Rofe | 01:56**
Yeah.

**Ray | 02:12**
And level above that, which is basically YouTube. I'm not sure there's really a competition in terms of media for longer-form content, but that is really where you get to have something where you have enough time to be thinking about an idea or sharing a how-to or what have you.
I was owning that in the case of state change, which is my product for prospects.

**Ellie Rofe | 02:32**
Four two.

**Ray | 02:33**
The two main things people talk about when they're coming in the door are either my form-based marketing, participation on whatever forms and what, et cetera, or the YouTube channel.
They're not talking about the shorts; they're talking about the longs because the longs are what they found through their searches or whatever. That tends to be the end. I think that's... Then you make content for those people, and then you can provide more content for those people who are interested in it.
There are some strategies around, in terms of depth and breadth for how to work with that, but I think that might be the medium that we've all talked around a little bit but hadn't gotten as deep into.
So we were just putting some more bones on that in this conversation so far.

**Ellie Rofe | 03:21**
Okay, thank you so much for catching me up and apologies for being so late. It sounds good to me.

**Ray | 03:29**
Yeah, very good. Can I ask how... I mean, how you have been on your adventures in approaching video over the course of the last few months?

**Ellie Rofe | 03:42**
They've been a bit limited. I have to be honest, I have been starting to think more about video for YouTube. Another... I haven't actually looked too much into the metrics here.
So, I don't know how much of it is talk and how much of it is real, but I know that lots of people who have struggled with lots of people who are in the market of ideas rather than just a flow of marketing basic content, constant noise on there. A lot of people who have talked about Substack as a new venue, my instinct, my complete gut feel on this is that it's very good for politics. I am unsure how good it is for...
I mean, very good. You know, not necessarily quality, but in terms of noise and eyes on it, I don't know how well it does in other verticals. I don't know how well it does in business or lifestyle or stuff. I suspect there's a relatively strong creative lifestyle thing there.
But I do know people from the business world are moving over to Substack as well. I still get the impression that Substack is more of an engagement platform. I don't know if it's great at the top of the funnel stuff. I feel like it's more about engagement with people once you have hooked them in on X or TikTok or whatever.
But it's another place. It leans heavily on it. It's a marketplace of ideas.

**Ray | 05:24**
Yes.

**Ellie Rofe | 05:25**
So yeah, it's an interesting area to potentially look at if you want to do writing. But I completely agree that YouTube just does seem consistently because it's not actually social media and because it's not linked to the social media algorithms in the same way. It just does seem if you can get the SEO right, it just seems to work really well. As a marketing lead,
I'm behind everyone on it, but I'm thinking more and more about it as the major channel and just pushing full into video.

**Ray | 06:00**
Yes, I like Substack. I like the idea of having not micro blogging, but like more complete explications. Let's get like 500 words or whatever to like sort of to get work out an idea.
And I did that I've written, like a few years ago, I wrote like a hundred essays and a hundred days.

**Ellie Rofe | 06:17**
He.

**Ray | 06:18**
That was great to get those ideas out, and there is some amount of appetite for it, but I think you're basically right that it's not really top of funnel.
It's shareable, which is actually useful. I had a couple of essays that had a little more takeoff for me because someone I already had a connection to picked it up and re-shared it because, "Hey, this is a smart idea. Let's talk about that." But you're totally right, there's a difference. I think the irony here is that small, short-form text in social media is more shareable but not as deeply engaging, right? Substack is more deeply engaging and not quite shareable, long form. In contrast, what I'm finding on YouTube is that longer-form video is more shareable and findable because it gets surfaced on the second largest search engine in the world, which is YouTube's engine, where number one is Google and the.

**Ellie Rofe | 07:18**
Yeah.

**Ray | 07:22**
But the shorts are actually more about engagement because they get viewed by the people who are already following you more or less. I'm actually discovering that there are some other things I'm doing that are capturing more people who weren't previously part of it.
But overall, I think that the weirdness of the economy is that long form works for long form, and it's attractive for video but engaging for text. And short, engaging for video but attractive for text.

**Ellie Rofe | 07:58**
Yeah, interesting. I hadn't thought about it like that, but it makes a lot of sense. You definitely consume short-form video, but it doesn't seem to convert as well because it's just that kind of snacky brain rock. Let's go. Keep pushing through. People just slide through them. Whereas on YouTube, I generally use it when I want to find out something.
It's very much like an intention-based search a lot of the time.

**Ray | 08:30**
Yes.

**Ellie Rofe | 08:33**
But. Yeah. Really. Interesting.

**Ray | 08:36**
How to X is a good hook. Or as it so does happen, amazing I Xed, which it picks up both intensely, right? But one of them seems to then, when they look at it, say, "Hey, what was amazing? I want to learn what the amazing thing is."
By the way, when you're using those two, Buddy and BitIQ have free tiers that are useful for the level you're likely to start with in terms of quantity, and then as you do more quantity, they have paid tiers that are relatively cheap, but the...
But I live with those extensions just turned on when I'm inside YouTube. This gives me a lot more insight into what other people's traffic levels are, right, what my traffic level is as a benchmark.
Hey, this is a channel that's in the same domain but doing really well. Why are they doing well? Here are the channels, here are the things that seem to drive it. This is the one that's really sticking out. It isn't like the others. These are little plugins I find to be extremely helpful for getting more insight out of this relatively data-rich environment.
From your point of view, your point about SEO is that if you think... I think this comes back to Robert's point. The best SEO I find on YouTube is the idea, right? There's a little bit of massaging around the edges.
But we think about SEO as being some sort of black art, but it's really if you talk about something remarkable that people actually care about. They will probably watch your stuff or they're more likely to watch your stuff because there's a whole lot of people talking about the basic stuff or focusing on what's going to do well with SEO, when in fact, what I care about is not that thing. It's not going to do with...
So, I care about this particular problem based on my search query. That was something that I was interested in with X, so what's the X? What's the thing that you do that's interesting and just teaching? I find education just to be the easy way in on that.
But we're talking about three tiers to it. The first is the shorts, which I tend to find more engaging and attractive. The second is the long-form that is more attractive and can be engaging too. People see that, they're like, "Okay, hey, you're a real person now, let's maybe have a conversation."
Then the third tier is events where, like, I've been doing that with the stuff I've been doing with E-Cene over the course of the last several months. Robert has those assets now from the MC meetup he's been doing.
When I look at them, I'm like, "Hey, that's the thing that really sticks out." What Robert has is being, "Hey, here's the MCP meetups." So he's a guy who does MCP meetups. Now I have that proof of life, and I go click into it.
This is then setting him up to be able to get more of that business over that. Then spend off for construction.

**Ellie Rofe | 11:39**
When you're doing obviously that's... format, and they have different levels. Do you consider different topics or different ways into things depending on where things are?
So, you have people who are like awareness-style content. Do you talk about things differently to stuff where it's engagement level or conversion? Do you have a different approach? Are there different topics that bring people into the no-code, low-code space, and then topics where people who are already quite involved get Hook.

**Ray | 12:18**
So there's a whole set of these around this, and there are people who... They're actually YouTube channels about making better YouTube channels, and they can be decent.
But I have found that I thought Robert's insight from the beginning. I appreciate you coming in, but it's about the idea, right? Really, the key one, people come in because they have some sort of problem or some sort of opinion or whatever, and they're looking to learn more about that topic or think more about that topic.
Then, the rest of the content, they find our stuff that is of interest to them. But what this is, offering something really broad doesn't seem to help. It doesn't seem to be all that. I think if what you have is a big audience, right?
Then the YouTube algorithm trusts you, then there's an opportunity to expand out in that direction. But what I found is offering something sharp, right? That I think is... Hey, it's going somewhere more specific, but about a top... When I look at my YouTube page, "Convert Rates" and I look at the videos I've done really well. The videos have done more well measured by a number of views, they're not the ones that are most general interests, they're the ones that are of that... They tend to be more specific. Like one of my most popular ones, "Testing with Flutterflow", right? Testing on the device with Fireflow.

**Ellie Rofe | 13:48**
Yeah.

**Ray | 13:49**
That is not a super easy topic. That is very accessible to a lot of folks, but a lot of people who are going to Fireflow have that problem.

**Ellie Rofe | 13:53**
Three. Yeah, and that's kind of what I'm wondering is there are people who are just getting into no code. Low-code testing on FlutterFlow might not be the first thing they're looking for, but they might be looking at setting up Workflows on Slack, for example.

**Ray | 14:05**
Yes. Twom.

**Ellie Rofe | 14:19**
And that's kind of what I mean about the state of play of the people. Like are you trying to capture people early so they understand who you are and when they're ready for that? Five percent. It's just a natural progression. Or are you just trying to catch people who are ready for the 5%?

**Ray | 14:36**
So far, my approach has been largely people who are ready for the 5% so they can know that there is hope. One of the things I found about the change is that I almost never get to people before they got burned, not ready to put in any money because they've been sold on a promise that, "Hey, this stuff is easy."
It's not until they... This stuff can be hard, and then they... Who can help me with the hard part? Wait, Ray was able to help me with the hard part. It's a free product. Then that's sure... The rest of the funnel is what I found to be most effective, right? There are lots of people who are like, "Hey, I'm doing this as a side project." Can you give me some advice about X? I could,
but they want more attention, and they don't really have a great willingness to pay. It's a sucky deal. I don't really like to be in the PLG section on a service basis, right?
That's kind of what the content is for. Then the C... Like the super simple stuff, the thing that the... Sorry, the other thing I found to be hacky about pointy content is that pointy content is actually easier to make.
It is probably true that, at most universities, was certainly true at Yale that the most senior professors taught the most introductory courses. The harder thing to do is a survey-type broad stuff well than to do something more pointy.
Now, the truth is, probably given the experience curve that I've been on over the course of the last two years, I should be stretching. The way for me to stretch myself is to do what you were just describing.
That's probably what I should be doing to expand both my own horizons of ability as well as reach out to more folks. I think when you're considering, "Hey, what should I be doing over on YouTube?", the easy way to get in is to offer pointy stuff about more popular topics.
So, people who want to do vibe coding stuff, people who want to vibe code Wiz, I would hit that drum all the time if I were Robert. There are lots of pointy aspects to it that involve snappy. That involves just thinking about,
"Okay, here's other stuff in that section." There's a ton of content you can do, and you can pick the 1% of it that seems the most interesting/easiest for you to accomplish. I would encourage that because you do more of those, you win, right?
It's really about that confluence. What is that part that you find interesting, right? The market wants it. It's like the hedgehog hypothesis. It's a combination of what you care about, what the market's willing to pay for, and then what you can be world-class at.
I think all three of you can be world-class educators, right? That's what you do with your practices. So, it's the first two that matter, right? What do you care about enough that you can get off your dust to be making the video about it?
Then combined with that, people actually would care about that topic. And what I've found so far is the specific doesn't matter nearly as much as the general. Like the fact that I made something about Flutterflow, my MyZano content does okay, and it converts because people then see other cross-referencing, Xano expertise or whatever.
But Xano is this, and Flutterflow is this, which is terrible for me because I don't really want to be that much in the Flutterflow business. But that's why the other confluence matters. The part that you then care about, right?
If you can identify, "Hey, this is where there's a space in the market." This has a problem area, not even the super-specific thing. Then the bit of it, they're like, "Wait, I care about this part." This part seems really interesting to me.
That's then what makes it easy for you to do and get a lot more attention. It has been my thank you so far. I'm sorry. I don't need to be dominating the conversation. And yeah, so then the wheel keeps straying for me, like once we have more content.
Right on. Once you have that outlet for creating content, that actually then reinforces the study part because now I need to get more ideas into my head so I can then be turning those things into content. I mentioned Li at the beginning shortly before you got on that I made a commitment to another group that I need to make three long YouTube videos this week so you three can hold me to that as well.

**Ellie Rofe | 19:14**
Okay.

**Robert | 19:17**
I would just add to that, I think I've been trying to shorten the amount of time between when I realize an idea has the qualities of being interesting or pointy or edgy and then talking about it, recording it, and then putting it out there, whatever it takes to put it out there, because everything expires.
If I wait too long, then the idea is no longer pointy or sharp. Or like, if I think about the stuff that I did years ago or even months ago, if I were to go and try to talk about some of those things now, it just wouldn't be received the same
way. Because things have moved and things have changed, and so sometimes I find that anyway, the best way to keep my finger on that pulse is to just pay attention to the conversations that I have with people.
So because I have those calls on Wednesdays, and then I have calls on Fridays with this smaller group, which is just more like a not that group, not so much on Fridays, but in general, whenever I hop to a call, even if I hop to state change calls, there's... If I've been paying attention, there are parts of the conversation where people lean in, where all of a sudden something really resonates.
Maybe that's something that only happens in the first 5 minutes of the conversation, but there's a part, and I think there's content there, right? Just being able to identify what that thing is that made everybody go, "Okay,
that's interesting." Then there's something there, I think, and that's the thing that I tried to do. I think that there's an opportunity. I think that that's something that itself would translate well to just making a video about that, right?
There's some type of validation, I think, if we're looking for a sign, but maybe that's a sign signatrice.

**Ray | 21:20**
I appreciate we'd use the hour. How has this been helpful to you from a point of view? Like, [Laughter].

**Demitris | 21:28**
Absolutely. Tons of thoughts are coming into my brain and things to reprioritize for the next couple of days. It was crystal clear what works.

**Ray | 21:43**
The other thought I had, Ellie, was that it might behoove us to do a session on, like, you know, YouTube. Right? And like, what's worked tooling, setting up the channel. What have you? Some things I've learned from building out the channel stuff in terms of being able to cross-ply if that would be of interest to you as well, we can figure out a time, say, maybe next week to put that kind of thing together.

**Ellie Rofe | 22:14**
Yeah. Very much appreciated.

**Ray | 22:18**
Cool.
All right, then what I will do is I will put together a poll and send it to the three of you to see what crosses your availability. And we'll take it from there.

**Robert | 22:32**
One quick thing. I sent out an invite for tomorrow. By the way, it works for both of you for the content meetup. We've been just trying to stay consistent. So yeah, let me know if the time doesn't work. I just want to throw that in there.

**Ellie Rofe | 22:46**
Good for me.

**Robert | 22:46**
Sure.

**Ellie Rofe | 22:49**
Okaybulous.

**Ray | 22:50**
Great. It was great working with all of you today. And we will do this again next week.

**Robert | 22:55**
Thank you.

