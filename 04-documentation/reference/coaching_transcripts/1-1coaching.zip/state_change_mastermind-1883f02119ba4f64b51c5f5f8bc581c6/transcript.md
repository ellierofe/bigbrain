# State Change Mastermind - Sep, 09

# Transcript
**Speaker 2 | 00:02**
No, it is actually... It is very unique, and I've never seen it before. I can tell you that it's very unique, and it's... [Laughter] yeah.

**Ray | 00:14**
It is unique. I like the glass, particularly on the side, which I appreciate is sort of an unfinished room, but like, that is. I think the whole thing really looks. Yeah, sort of speaks to you as a as an intellectual and as a builder.

**Speaker 4 | 00:32**
No, thanks for the compliment, guys. I wouldn't expect it.

**Ray | 00:36**
Thank you. Yeah, I appreciate it. Things will get built out, and it'll be harder to actually do calls from there. Just like right now, it's hard not to do calls from there because you're working there, but I think it's worth maybe doing some video with that backdrop because I think I like it.
I think it sells.

**Speaker 4 | 00:52**
Really? Yeah, and I'm scared about that. I'm going to try it and.

**Ray | 00:58**
Hello, Ellie. Ellie is joining us from the island and not from the continent today.

**Ellie Rofe | 01:03**
Yes, I'm in the little, rainy island. Which is why my spiritual home has kicked in and I've got a big cup of tea. I'm living it's there.

**Ray | 01:18**
Super. All right, well, let's go around the horn and what kind of week has been. We will start with the best backdrop, which is, of course, as usual, what was true today that was not true last week.

**Speaker 4 | 01:33**
Many things are true today, guys. The first thing is that I'm a co-founder in a pharmacy with 50%. [Laughter] So we passed all the bureaucracy processes, so we are getting ready to start running the business. The reason I feel proud about this project is not that we achieved it on time because we had too many time limitations and pressure, but mostly because it's the first case study, a real case study where I deployed my core business principles, which is to avoid spending money. I would like to have this approach into what returns to you upfront approach, totally different.
So we were on a limited budget. We had some struggles with all of these new things. We are going to do big things and fabulous things. But we made things that work and convert from the first day. Even before we start operating, we had some nice positive signals. Going back to my own business, the truth is that I had three new engagements where I really enjoy starting work with them and making progress.
Again, I put the same upfront approach of "Let's go and build something before the end of the week so we can go and make sales based on that." So we minimized everything. I would like to have this.
Everything is out. Put in some manual work. But the pre is to validate the idea and do the proof of concept. Last thing about my digital twin thing and the switch for the services. This workflow remains on it. It took some pose for the past week because I had all of these changes and I couldn't remain consistent on that.
But the thing is that today I completed my upload to Google Drive, my documents, and from this week I'm starting to post again. Get into the process. I didn't have a chance to improve my website based on your fabulous feedback, guys, last week, but this is scheduled for the current week.

**Speaker 2 | 04:09**
Super.

**Ray | 04:10**
All right, Ellie was true this week. It was not true last week.

**Ellie Rofe | 04:14**
Well, I'm in the second week of my three weeks of disruption, so I'm I've had the brother in law last week and traveling to the UK. So I'm. I'm not as productive as I like to be, but I've had the first call with my new client. That was really interesting. Throwing up some new challenges. A different, slightly different kind of business. Instead of drug development, it's more of a diagnostic play, which is a slightly different ecosystem.
But again, it's lovely to see as we worked through the pitch deck that there were things that were missing that I could help with, crucial things that she hadn't thought about. That always makes it feel like the imposter syndrome lessens a little when that happens.
I have been working out, with much help from Ray, how to put together a portfolio because what I do is messy and has a structure. I've got pictures I can show of the little boxes and everything about that.
But people really want to see the design. So I was trying to work out the actual user experience of it. People think that they want to see a before and after design, but what they really need to see is how I actually help with the strategy of something.
Tell stories with visuals, animation, and things. So it's been a bit of an interesting challenge for me in terms of how to best put that together. Ray had some great ideas there, and I haven't had a huge amount of time to implement them yet, but that's the plan over the next few days.

**Ray | 05:53**
Super. Robert, what was true today? That was not true this point last week, and then we can get into your hot seat.

**Speaker 2 | 06:03**
Sure. What is true today? Well, I got a client. Thank you for your referral, Ray, and for the work we did over the weekend, which was just like a whole... I felt like a whole other side of Ray even.
Like it was just to be able to see if I don't know if anyone here has ever been in, truly in the rave vortex. When you see, he is offended that the problem exists. And it was like... I felt like it changed me a little bit, because Justin just takes you right through how his brain sees things, and I'm pretty... I like to think at least that I'm a pretty easy-going person, so I've worked with a lot of... I enjoy... I'm not...
If I'm not... How can I put this? I feel like I recognized your way of approaching the problem was to just relentlessly stay focused and attack it. It was something that stayed with me,
honestly. Every time I sit down and I look at the computer, I'm like, "My gosh!" I can just hear... I can just feel Ray's voice still there, just like, "What is this change?"
Let's forget this, let's... crap, next thing, this is... do the next thing. What are we doing? So yeah, I honestly have it, and the clients are super happy because we just made a ton of progress, and I think even they were so surprised about how much cut done.
So yeah, it feels like I honestly can't believe that it's only Tuesday because over the weekend, so much got done. I feel like it's Friday already. But just on the very positive one, and I mean, just on the very positive way, it was like nothing.
I've never seen anybody be able to tear apart a problem like that. It was really something to experience. In terms of... But yeah, overall, really, that's a huge difference for me. Probably the biggest change in the last seven days was that whole experience of just Friday or Thursday being tipped about the CLOS and then closing them on Friday and then working on Saturday, working on Sunday and then delivering on Monday. It was very turbulent and very humbling to work with Ray and to see how much better I could be. And then to just work on that and just to work to become better and. And to do things better and to just really see just so close, like what does it mean to deliver this the level of service like that you deliver, Ray, right?
And like the what you do for people like as I know you do a lot of things for people, obviously. And like, you know, we just consult like you tell us about business advice and everything. But that was the first time to really see like the very core like something that you really like, I don't know, like the whole a different type of problem that you solve, which is maybe what you would consider it very close to like your the development side of your services.
And, yeah, that was something I was ready for. More like a consulting type of discussion, like how we have our nice and chill calls like, Holy crap, my computer's too slow for this. I'm too slow for this.
Yeah, that's what happened. Well.

**Ray | 10:15**
I'm upshot is that it happened, which I'm... Yeah, how terrified I am of that description that you give it. But how can we help you in the coming league? Ben? It's your seat. How can this group be of service to you?

**Speaker 2 | 10:30**
Sure. I was thinking about this for the last few hours, how this is tough because I feel like I've gone so much, how even just in the last few days that it feels... This is hard. Sorry. How can I get help?
Maybe I'll... If it's okay, I'll just talk about maybe the thing on my mind the most. Maybe just to get advice on how do you guys have any tips on basically keeping a stay consistent, essentially, right?
Because even just over the weekend and everything, as obviously some focus goes into one thing and then I kind of everything something else will get less attention, right? Like, I won't post about it as much as I need to on other things. I won't, for example, post about MCP Wednesday.
I should have posted about it, but I was just putting everything that I had into focusing on this client. Then, obviously, the energy went away from another area, even in certain things when it comes to Ray. You brought up a really good point about how there are a lot of automation opportunities for getting incoming messages and then you could perhaps just automate that. Have you guys found basically ways to just remove the pebble from your shoe?
I think that's what I'm looking for. Sometimes I find that a really small thing can be just that. The auto-responder. That one little auto-responder, for example, might really remove that pain.
That's something that you know from having it sit in your mind. Rather than every day is just something that just kicks it out the door and gets that response out to somebody. Or like you, I'm just wondering from your perspective, actually, more than just me just giving examples. I'm wondering, is there any ritual that anyone could perhaps share, automations, or ideas on, to just keep everything chugging along?
I'm asking because I know that there's stuff. I could go out and I could look online, and it'll be very... There's all kinds of advice, but I'm just... I know that we are all actually people who have to get stuff done in reality.
That's why I'm asking because I think that stuff from a pragmatic point of view, it would be interesting that those types of advice... I'm not even looking for anything crazy or fancy. I mean, look, just for the something that you actually use and do because I think that that's a validated thing and that's something probably very hard-won from actual experience.
So I'm interested in that, and maybe I'll just figure out my doorknob question in the meantime.

**Ray | 14:06**
All right, well, let's quickly ask. Sort of go around the horn here. How do you deal with, the as Robert puts it, the pebbles in your shoe, the got to do things that are, know maybe not where the excitement is. Ellie could start with you.

**Ellie Rofe | 14:31**
Yeah. I'm not the best person to talk about this because consistency has always been a bit of my bête noire, but the one thing I found which I'm leaning towards trying to find again is that I had been working with Charlotte on this, and it didn't work out in particular there, but the best thing is external accountability.
I had my process with Charlotte working on this, a call at 9 am my time every day, a 15-minute call, half an hour call, whatever, where I just literally externally expressed what I was going to be doing that day and what I'd done the day before.
Then I had, and I still do have it, I just haven't been keeping up with it as well. I had a big task, a digital planner, blah, and Notion, which I love, but if I don't keep up with it, then it's useless.
So I would transfer it. It's somewhere in this room, but as I'm in bags and stuff at the moment, it's not here. I would transfer what I was doing that day onto a little printed planner that I have with a calendar and the task and stuff.
I reflected after I was asking you guys about systems, that to me was the best way to get things done. Done, in terms of just actually hoofing through things. You have to hoof through if you can't automate things. The other thing I feel at the moment for me and I don't know, I have a tendency to overengineer solutions to problems.
So I'm trying to avoid this. I feel like until I have a somewhat regular process with clients coming in and understanding how to build a rhythm with it a bit more, it's going to be harder. So I'm trying not to rush into automations or solutions like that unless I can see that it's definitely a problem that needs fixing.
I think I don't know why I keep mentioning him in this group, because I do. There are lots of other people I actually prefer, but Daniel Priestley has a concept of a perfect repeatable week, and I think it's slightly... He's talking about creating a business where you can run the same week over and over again and reliably get clients in. I don't think it's a terrible idea.
I think it's quite hard as a solo consultant to reach that. I think he's talking much more about creating a kind of digital product business and things like that, but... He talks about it,
and he says one of the hardest things as a business owner is that as soon as you get to something like that, you then want to play with things again or you want to change things or you want to tinker with stuff and do something new.
So I suppose partly what I'm trying to say is I would be looking for patterns where there is actually something that is really a problem to solve versus something you're resisting doing because it's not fun, in which case I would find, for me, I would find external accountability to push me through those tasks.

**Ray | 17:45**
Cool. Beatrice, can you get your way in on this.

**Speaker 2 | 17:52**
Robert.

**Speaker 4 | 17:54**
Did you find, which are those, things that are... These are the marks to do in your daily schedule, and which are the most common disruptions from doing that?
Yes.

**Speaker 2 | 18:19**
I would say that the probably the mean the most, the things that I really have to do, I think without getting too specific to make it, you know, overcomplicated that way. I would say just in general, some type of, external communications probably like, you know, responding or create putting a message out there. Anything that has to do with... Gonna put this post out or do whatever or make this video and so on...
And I'm definitely getting better at it. But... Yeah. Probably what's stopping me is just probably just the need to prove to myself that it's... Almost like, I don't know how to describe it, but living up to myself, I suppose, like meeting my own standard.
It's not good enough, then it'll be good enough. Then 2 o'clock, 3 o'clock, 4 o'clock. It's too late for a post. Then the brain juice is not there anymore. Versus there's this period of time during the start of the day where you're just ready, and
you would deliver it at your best and so on. But then getting you feeling overstimulated, thinking about it to the point where I overanalyze it and I think about it too hard, essentially rather than just kick it out the door.
So yeah, maybe that's the issue.

**Speaker 4 | 20:11**
From my perspective, since the domain where you recognize the struggle is in communication and engagement with the audience outside your business, I would say that this is the thing that you shouldn't replace. You shouldn't replace yourself with something like AI-generated because people who want to talk to you, who know you, because you are very good at communicating with the audience, they don't want to have AI responses, even if, let's say, imagine a personality who is ironic or funny.
Yeah, they expect an ironic way of response, all right, so they will recognize it immediately. That is AI-generated because they know you from the other communication you're doing. So I would say, don't think about how you can replace yourself from doing that. I would say find these steps that you could improve in terms of the time.
For example, from one way, maybe track yourself with a time tracker on being engaged in the community or joining specific things. This is the easiest thing. The other thing is about your content. You can have some automated workflows and some standard operational procedures to generate the final version, and at the end, you have to remind yourself what the goal is. Is the goal to deliver a post 100% perfect, or to deliver a nice and well-standing post every single day or every three days?
So I think this is the thing. We have to focus. So instead of consuming three hours and doing that, you have to keep track yourself, maybe on that. Again, of course, I'm not the best person to talk about it. I struggle with that.
I have my mentality ups and downs that affect me a lot, and it matters. But I see that when I have wins, it starts working. Usually, what makes me progress is all the things that have in delay. When I see something for the second and third day in delay, I feel stressed and everything is... Nothing can work for me.
But this is for me. Alright, so I would say trying to find these things that are little hucks for your brain and put them to work. But always remind yourself what the value of what you are doing is.
Because maybe sometimes, to engage in a community, maybe it's not that valuable to treasure yourself to engage in that specific day.

**Speaker 2 | 23:41**
Yeah, I appreciate that. I'm just thinking about it.

**Ray | 23:53**
Well, Mark Twain said this. If you got... Swallow... A frog... Swallow first thing in the morning, you've got... If you fall, two frogs fall, the bigger one first. I tried to do things where my brain is fast, but there's a bit of like, "What are you doing?" What's bringing you joy is another thing I do look for here, like the things that you think you've got to do. I would just challenge the premise, right? Do you have to do them? You got all four ELS from Tim Ferriss to work with, right? Delegate, eliminate, automate, liberate, basically procrastinate.
But, you know, there are some things that are really important that you should think about. Okay, well, what's important? What's important? To study cellship, right? How do you know? Put these on the board and if a particular activity is not working for you, how to be doing it better? I'm saying there are some things that are about the speed of response that there are things that are interruptible, and then there are things that are important but never urgent, right? This gets like issues of accountability as well.
Hey, I know I need to go do a post and sort of put myself out there and share something, but there's no triggering event. You're not reactive to it. This is where, sometimes, scheduling is a mental trick for that.
It's three o'clock, I get my ding, I'm supposed to do this thing, and I'm responding to my calendar or better. This is where accountability can come into play, right? This is what Ellie was talking about.
If you have external accountability, then you're a partner. Great. That is the time that you're going to be solving this problem. Now we're going to go create some media. I think you and Dimitris were doing a bit of this at one point, and I thought it was good and it seemed to be good for you in creating content. It might be something to revisit as well, so that creates that kind of external facilitation to it.
Anyway, but that's one category of a problem that forms a stone in your shoe and becomes an ever-increasing stone as you procrastinate. Man, it's been two days. I have three days, I've done four days. I haven't done it.
You pay a price because you can't go back in time, right? And this way, consistency to your wish that the word is used at the beginning of this matter. The second type of prop. And not for nothing, just to finish a thought on that, this is the thing I like to use automation for.
I will use social media scheduler, and this is where you can use a little bit of delegation and a lot of automation to have posts going out for you, right? If you're making sure something is going out.
Then, as it moves, you're able to fill in. It helps by creating a content stream of stuff that can be getting you some sort of positive reinforcement. This is essentially what I do with the trailer videos and what I've been doing more recently with the BIGCAST videos, which is just putting them up on Link and letting the schedulers take care of them. It doesn't get YouTube, so actually, I get fine engagement on YouTube. LinkedIn cares more, so I get a lot less engagement. Although some on both YouTube and Twitter and the others, and I just don't worry about it too much.
Then, I still get inbounds. People say, "Hey, I found your video about X." It's still 60% of the inbound for state changers like for me. That's how people who did not otherwise know about me, who weren't referred by a person, discover me.
So, a real asset that is valuable and one of the things about creating content, particularly if it's not just carried away by the river, right? If it's something that could be repeatedly put into the stream, which is what you two can do, it creates value. That's where disconnecting yourself from it can help. We talked about Opus clips a little bit before, and there's a question of quality and how tight it is. I find for shorts, I can do a pretty good job. The expectations of shorts are different. For lungs, it does not do as good a job.
But then again, we really for longest to articulate an idea. So how can we make it easier for you to articulate an idea? I look for that as well. Okay, that's one kind of thing, right? The thing that is important but never urgent, right? Important and urgent and not joyful.
It's joyful, but you don't have the problem, right? The problem is where it's important, not urgent, therefore it's not being triggered. You're not on fire, not getting burned by it. But it's not joyful, it's not being driven toward it, and that makes it easier to procrastinate. We talked about a couple of techniques about... The second type of problem though is the responsiveness problem, the interrupt, right?
It is just true that the business will come to you much more reliably if you are responsive, right? People who email you and hear back from you immediately. One, they will say nice, one, they will more likely do business with you, and two, they will remember that and we'll talk about that to others because it's remarkable. It doesn't happen that often.
I think I've alluded more than once to some subset of yalls about Seth Golden's observation that the number one competitive advantage she found among plumbers was willingness to answer the phone. Now, this is where automation, I think, really can help.
Actually, this is where ancient technology, I think, can be really extraordinary, because when you have inbounds from things that can be caught by automation systems, I'm not saying don't reply to your email, I'm saying the first reply can be automated and they won't necessarily mind if you apply, right?
But what happens is something comes in and just goes dark, and not for nothing. That happened a little bit with the thing that I referred to you just last week, right? Yeah. Third, I made the intro Friday. She's like, "Where is Robert? I'm in pain here. What's going on here?"
Like, "By heaven, you responded, and it was because you just weren't looking at your email or whatever." Yeah, that's the thing that needs to not happen, right? You want when something comes in to be able to jump on it.
Yeah, and it's easy for them. This is where I've got auto-responders, like when people do forms on the website. But similarly, if you... This is where the agent approach can be really handy. "Hey, when something comes in, it looks like it might be a lead. Let's reply with a brief so that they can schedule something."
Yeah, and then you can do more right there. I think we get caught in all the things technology can do for us when there are such simple things, like, "Hey, this looks like a lead, so send it or apply to send a text."
So you get the ding, saying this is more important than the other. That way, you're not being interrupted by everything coming through the inbox. You only need to know the latest demand curve newsletter or whatever you need to know about these kinds of inbound and having it check that is really extraordinary.
I think Demetrius actually has some special expertise here that he might be able to share with you as well. But it falls in the category of how you can then not be spending your time...
I have to go look through my inbox and look through all this trash and whatever. No, this is something a machine can do for you and pretty cheaply, too. The amount you spend on Zapier or whatever is trivial compared to...
I'd say it's time savings, but the more important thing is the better responsiveness. Yeah, I look at automation and I really want to add automation. It's not just going to save me time, but it's going to produce better results for the client and will increase the impact.
This is an example of fact. Because they will be happier when they can book time with you. They've made their next step. You, similarly, will be happier because you can then have that call. You much rather have that on your calendar than have the now, we need to go back and forth and make up a spoke email or whatever.
It's like if they... That was the reason why they contacted you, right? So, "Hey, you just got an intro from me and whoever you can just do the immediate audit reply, and no one can be offended.

**Speaker 2 | 31:46**
Yeah. I just want to say that it's very helpful in a way to think of it in terms of a way to make it just the way that you described it. Like a way to make it fun, I suppose, because you're describing it in a way that I can imagine doing it.
It would be fun to get it done rather than when you start. I think it's funny because I'll start even to do work for the... Even doing that work for the client, and then realizing as I'm doing it, I'm actually getting to exercise this snappy tool while I'm doing this. I'm like, "This is driving this next thing." This feels fun all of a sudden, and now I really... Cause whatever I tap into that thing that keeps me obsessed over the snappy tool...
All of a sudden, I felt that energy coming into using it for the client. Perhaps if I can... Yeah, that just stood out to me. If I can find whatever that excitement is, then all the better, I suppose, for the results.

**Ray | 32:54**
Yeah, absolutely. It is finding the fun in it, finding the joy in it that I think is important. There are enough different ways you can create value because, at least three of you in this room, are talented enough that you can do things in multiple ways and still create a whole lot of value.
So pick the one that's bringing you joy. Now, if you're doing something that's bringing you joy but is neither important nor urgent, then that's snowboarding. But that doesn't count, right, as making professional progress?
So we're asking about that important and urgent section, right? What might be called type 1 and type 2 time, right? To use a Coby Stripe framework for it and wanting to just make sure that we cover them.
The thing is, the important, the urgent stuff I think really responds well to automation. The more you can get urgent off your desk because urgent is handled, and you're focusing your attention on things that are important but not urgent.
I think you're going to enjoy it a lot more because that's where the creativity of the exercises exercises.

**Speaker 2 | 34:11**
For sure. I appreciate that. I think there's... Yeah, I mean, I think that as you said, maybe there's one thing, and now I think I'm going to my doorknob question, and it's really actually a question that doesn't... It's more like... Hey...
If I just were happy to do a co-building social media creation call, whatever format that works for you, Demetris and Ali, just to even if we're not necessarily recording a call with three of us.
That's the output. Even if everybody's muted and recording their own stuff or whatever format it ends up being in. I just wanted to put that out there that if that's something that it would be helpful for you as well, I just want to put that forward because I think that would be good. I can't imagine it would go downwards in terms of results. I feel like it would either slightly go up or more. I can't imagine it being a negative thing.
So maybe that's the biggest thing I could ask for help with in a lot of ways.

**Ellie Rofe | 35:34**
It sounds good. As in, just hopping on a Zoom call and creating some social media on a live session, basically.

**Speaker 4 | 35:40**
Exactly.

**Speaker 2 | 35:43**
Yeah. Just being very outcome-focused about it. This is going to be, by the end of this call, have one video, one post, or whatever it is, whatever it takes to get to.

**Ellie Rofe | 35:58**
Yeah. I'd love that. I mean.

**Speaker 2 | 36:07**
That's that was that that's like my probably that in itself, if we can just even just get down if we get that on the Condor, I think that'll probably make us all more money. So probably that's like my I know it's not really a question, but I mean, it's not a question that, you know, we that involves a lot of discussion right now.
But yeah.

**Ray | 36:27**
If you all are in, I think a good use of the next five minutes is getting that on the calendar because you have three here. The usual county approach works for two parties, but it does not work for three. It just completely falls apart.
So, let's take a couple of minutes, everybody. Open if you're in for it, which is fine. Then, open up your calendar and take a look and ask the question, what would we... I mean, we're getting towards the end of Demetris and Ali's day here.
So, starting tomorrow, yeah, would VFO.

**Ellie Rofe | 37:06**
What time?

**Speaker 2 | 37:06**
I would like to.

**Ellie Rofe | 37:07**
Time from Robert.

**Speaker 2 | 37:08**
Yeah, well, for me, as Ray mentioned, just because my time zone is earlier. I actually would like to make sure that it works for both of you, firstly, because I'm pretty flexible, so I just would...
I know I'm turning it back around on you, but I'm like.

**Ray | 37:26**
Does that work for you tomorrow? For me, there's a phenomenon of like there there's this cartoon of like two people sort of saying, no, you go first. No, you go first. As and as a result, nobody goes to the door right.

**Speaker 2 | 37:40**
For nine o'clock then.

**Ray | 37:44**
Ten This one time... Do you have any others that work for you?

**Speaker 2 | 37:46**
Tomorrow does well, anytime between 10 am and 1 pm. Okay.

**Ray | 37:59**
Ten am, 11 am, 12 pm. Yes, those are the ones we have available, we are ending it.

**Speaker 2 | 38:05**
Yes.

**Ray | 38:06**
I got it, alright. Do I ask to be... Interestingly, if we were to narrow it to that three-hour window, what does that look like for you'all?

**Speaker 4 | 38:19**
But I have a question. What time is 10 am in your time zone? Is it the time we get started today?

**Speaker 2 | 38:28**
No. It's are two hours earlier than today.

**Ellie Rofe | 38:33**
Is about 4 pm in.

**Speaker 2 | 38:33**
There.

**Ellie Rofe | 38:35**
I don't know if you're in CT or you're further along.

**Ray | 38:43**
Then we're still in BST, right? That's until November.

**Ellie Rofe | 38:53**
I'm in BST now, yeah. Demetrius, if you're in CT, Central European.

**Ray | 39:01**
One hour further, you are t.

**Ellie Rofe | 39:02**
Yeah. So for me, I can do 10 am and probably 11 am tomorrow. After that, I can't do do.

**Speaker 4 | 39:17**
It worked for either, ten and eleven, but not on twelve, so I think ten and eleven is the best fit for the three of us.

**Speaker 2 | 39:30**
All right, I will send out the invite right now.

**Ray | 39:39**
So sometimes we talk about high-level strategy. Sometimes they're just trying to buck a calendar.

**Speaker 2 | 39:55**
And. I sent that out for now, tomorrow. I think that gets in the way of mechanisms. I think that's a very interesting mechanism, at least to me.
It's like leaving my alarm clock in the bathroom instead of leaving it next to me. So, I have to get up. I physically have to get up to go turn it off. I think there's some type of... It's something that just forces you to do something.
I already feel like we've got something done, even if it's in the future. So, thank you both for that, appreciate it.

**Ray | 40:44**
Super, right.

**Ellie Rofe | 40:45**
Present.

**Ray | 40:48**
I think that was a really good idea. It brings back the idea of external accountability about just getting... Having that intensity right and bringing some of the joy and the fun of the collaboration of it.
That's a wonderful idea. All right, how else can I? Is there any other way that we can be of assistance to you today? Still your hot seat? We have a few minutes. If I can, we can put them forward for you, for sure.

**Speaker 2 | 41:15**
I could talk about more stuff in my head. So, I would say, because this one I'm trying to figure out, I would... I'm trying to imagine if this was like the Ray program in a way, if this is like a boot camp and you're showing up and you had to get your assets together on the first just to even do the program. I imagine you go into boot camp and then they shave your head and then they tell you, "Now we're going to take what you're going to need. A website. We're going to put your face up on the website. We're going to take ten pictures of you. You're going to do these poses, and then you're going to be like, "I'm trying to think of it on and again." Maybe this is just the way I'm thinking about it,
but almost everything is to boil down into mechanical or just your certain. But your war chests, certain things that you have that you need in order to go out there and take part and do this thing right of this game of making money online.
What are the things that you need to do? Maybe, as for me, I found that thinking about it was helpful in certain ways, but I'm just making... I'm trying to think, is there something that you would imagine that makes up that war chest for you?
Like I'm picturing it as I said, you need the website, you need your face up there. Are there other assets and other things that you see as part of that? If you wanted to do this program and you wanted to do this, then what are the things you would need in that first week?
Because, yeah, I think that it's actually, as much as it seems very basic, that the basics are what make up everything. You'd need perhaps one way to look at it, and it would be every week you would make one. You would send out one newsletter, and it would be on Tuesday at ten am, and you would post one video, and it would be on Wednesday at eleven. You would write, "I'm trying to describe something that's hard for me to imagine, but hopefully, that makes sense." I'm trying to get towards what is that? What are the fundamentals?
What do you define that in your mind? If you can picture it that way or if you've thought about it that way? Okay.

**Ray | 44:08**
Well, can we go around the horn here and get some thoughts on this? Dri, can we start with you in your fantastic background?

**Speaker 4 | 44:22**
First of all, guys, we don't have any contract with the audience to post and do the job every single week at the same rate, right? So we shouldn't have this pressure on our background. We have to be consistent.
However, even if we post once a week, we have to give the value for the same thing we are doing and for the problems we're going to solve, right? Secondly, what works is the ideation. I found myself the previous few weeks to be the pain point for this thing when I don't have any idea to talk about.
So we need inspiration. So how do we get inspiration? We talked many times about the resources inspiration, but the thing is how we get inspired. How our brain gets inspired. Inspiration means like a light, it takes the idea, the input imagines something else and takes the release one step further.
So I found myself struggling a lot to solve that. I had to take breaks. I had to say, okay, I don't have a contract with doing that. I have to enjoy it. I find myself doing it on Sundays for the rest of the week. It didn't work for me.
So I use different things, and I'm trying to put random ideas like a random text, like voice recordings into a Slack channel for that purpose, or immediately into the content calendar, a user-friendly table.
So everything is stored there. I have a backlog of ideas and I have a schedule of ideas. I put them. I don't track the schedule all the time, but the good thing is that I have a pool of concepts. I can take it, put some imagination, add some text, maybe add some screenshots or stuff like that and just go and ask for his thoughts. What do you think about it? Is it good? Which are the strengths and so on?
Then just spend some 10-15 minutes to improve it and this is done. The crazy thing is that from that pool, I don't use most of them, but the pool works for inspiration. So when I don't have anything to say, go read them. They're quite easy to read if you give communicative titles.
So you know immediately what the description says before I join into the record. I read it, I say, "Right, let's do something like that." We can always look around for stuff that happens around us, like new announcements, very important things we have to put into alarming.
For example, very recently, one week ago, someone used eleven labs to clone the voice of a guy, a Greek guy. He contacted his mother on the phone saying, "Hey, Bob, I'm your son, and I need money."
I'm going to send you a girl to put all your gold stuff you have at home, and she's going to put it to the bank. It was a robbery. So this is something that an AI expert can talk about. I heard this story while I was talking on a cafeo outside with grand people.
So I say, "Wow, yeah, this comes from us. We have to be responsible for that." That's cool. So, closing my kid's description, I would say use something to pull ideas, not to use them, but just to inspire you. Anything that comes from books, from conversations, from anything, and that's all you can use for me. I feel very comfortable completing the session tomorrow in 60 minutes, having at least one deliverable from my side because I have this calendar already set up, and it goes for me.

**Speaker 2 | 49:14**
I appreciate that. I think it actually does help me form the answers to the question.

**Ray | 49:24**
Ellie, we get your thoughts on this.

**Ellie Rofe | 49:28**
So if the assets you'd need to keep the business rolling like the minimum...
Okay, so I guess mine is less. They are assets, but they're not tangible. As always, from my brand strategy point of view, the first things I would always suggest people have is what I used to call a minimum viable brand.
So, it's not really about the design, although the design is useful to have some basic parameters laid out, like a logo, colors, whatever, just to give you consistency and not make you constantly recreate the wheel there. To me, understanding your audience or having a deep audience analysis in place, even if that's going to update and change, but having an understanding of who you're talking to, understanding what you're selling to them.
Again, that will change at this point, that will always evolve. Then the relationship between them, which is the positioning. How are you positioning that offer to the audience in a way that makes it stand out to them and stand out apart from competitors? Those are the kind of three strategic assets.
I think that's the minimum viable thing you need to push forward. Once you have that, lots of other things are a little bit easier because you're clear on the central thing, which is who you're talking to, what you're offering to them, and how you're phrasing that offer in a way that makes it meaningful to them and attractive to them.

**Speaker 2 | 51:09**
Yeah, it's really interesting because.

**Ellie Rofe | 51:09**
Does that make any sense?

**Speaker 2 | 51:13**
That's really interesting because I feel like the way you describe it is the minimums that you have to, the minimum amount of experience that you need in order to be able to go out into the world and deliver services. It's like a high-end consultant, which is actually maybe gets to the heart of actually, beyond the website and obviously, you need a website, you need Stripe, you need pictures and all that, but other than underneath that, you need some level of expertise, right? Which is as you described if you don't have an idea of who your customer is and what your offer is and all that stuff.
It implies that's missing. So, yeah, it's very helpful.

**Ellie Rofe | 52:03**
It's just a starting point, but once you start talking to some people and you start working out what they might need and you start working out how they might need it differently to how other people are doing it, there are gaps in the market. Basically, you end up on a feedback loop. There are other things I would put in that feedback loop in a full brand strategy, but for the initial thing, that feedback loop, the more you talk to people and the more you deliver offers, the more you try and express what you're offering to people, the clearer that gets and the better it gets.
You know, Ray, at his level of expertise and experience, will have really defined things, and he'll be adding offers in because he's done all this work and he knows who he's talking to, he can see the gaps in the market, and he's adding offers in. In terms of shoring up the diversification of revenues in his business and making sure that he's getting people at different points.
At the early stage that we're at, it's an establishing phase. So, it takes some time to keep going around that wheel and recalibrating things a bit. I think that sounds true to your experience, Ray. Or is that like... Do you still feel like you're going around that wheel a lot?

**Ray | 53:26**
I was thinking about that. I was thinking you're giving me a lot more credit than I think it might deserve on a lot of these fronts, but I think that's just always going to be true, right there. There's a whole gap and gain aspect of this that you can come really far.
So, you're going to be asking, "Hey, if there's this part yet to go. And I think it is important to take time to step back and celebrate the gain, right, of what you've accomplished. At the same time, you're being pushed forward by the gap of what you could have, and I think "have" is actually an important word. I really... We talked about it briefly at the beginning of this conversation, we'll bring it back at the end because I think he has a few, I think really key insights over the course of his career, and I think one of them is "taken assets."
There are other people who talk about this term, but I think he wrote a book. He called it "24 Assets." I think it is a good way of just thinking about your business because if you view it as I am building these assets and you can own those assets when you're supposed to be creating, right? Then what you have is a process.
My God, I keep turning that crank, and my arm hurts. Why do I have to keep turning this crank? As opposed to you having something that is working for you. This is one of the reasons why I like YouTube as a way of creating content.
So, I'll tell you that people don't... People who join don't tell me they found me on LinkedIn. They tell me they found me on YouTube. I find many other people, particularly when you're just getting started, you're more found on YouTube because YouTube is a river, right?
You're flowing by people. Whereas YouTube is... It has a quality of being a bit more lake, and you are searchable. They're findable. If you can get to a certain level, you can be put in people's feeds, but a lot of it is, how can you be found?
It's essentially an SEO strategy, and that's the thing. The SEO thing creates an asset that is redounding to your brand, and that as you create more content, you can be deciding how you can be taking these ideas you have. Those are your real assets, right? Those are the geese right behind the golden necks.
How can... Then, you can repackage them to then go back out into the world in ways that have longer staying power or sharing staying power. I think, as intellectuals, we all trade in ideas, and what you want to be, you care about the ideas you have.
That's your knowledge. You care about your reputation, right? For being someone who has ideas and ideas that are worth listening to, and therefore, you're worth listening to. That's a reputation. Then, you put these two things together, and that's how you turn those things into wealth in different ways.
While I describe those things vaguely, I think when you look at them as assets, you can start to see some clear pathways, right? How do you monetize? What is an asset that helps you monetize? A rate card helps you monetize, right?
Yeah. Automation that likes responses to people quickly so that they pick up the darn phone and they're able to get them in front of you, right? That helps you monetize. That's an example of code.
So, the second one is an example of code as an asset, right? The first one having a rate card that is an example of content as an asset. Then, you don't need to create week, right? Have content. Now, you have a problem of distributing that content.
That's what I did up with or what you're doing. Someone comes in, and you're like, "How do I respond to this?" I could just have a Notion page. I can send it to decide how to do business.

**Speaker 2 | 56:50**
And.

**Ray | 56:50**
Yeah, it helps. Not everyone says yes to that. It's not cheap, but the amount of load that is required of me in order to be able to do that part has gone way down. So I transferred it from being on this recurring labor to an asset, right?
The asset can be code, it can be content. Another asset is just your reputation or a community of people who are then referring things to you. You're out in the world,
and you're doing things to build these assets. I think we have a view that what you're trying to do is build assets as opposed to just trying to drive income. You are where you are as a business,
and that's an undercurrent, I think, of conversations I've had with all three of you. When you look at that way and when you start to build those assets, you create a business that creates value for you both because you will enjoy it more, right?
It starts to pay you more. An asset is only an asset that touches the market. So, Stay is an example of something we did a lot of study with. You bolted it up a lot. You haven't contacted the market a lot with it, and you can see just that little bit you've done has generated some opportunity for you.
People are excited about this. So then the work you can do is to be better contacting the market. That's the part of the multiplier that you can use to make that asset more valuable to you.
Then you'll have other assets along the way that can be helping you as well. Some things that you're talking about are missing that are helpful. I gotta tell you, the number one thing I have is a rate card. Having a description of this is what it's like to work with me,
and this is roughly what it costs. So, clarifying... Then people can decide to do business. They decide not to do business. There's no guarantee that the rates they see today are going to be the rates they see tomorrow. In fact, it actually really helps to have people then see it a couple of times in the course of six months, and when they see the rates going up, that is increasing the pressure for them to be moving their business forward, right?
Because they know if they delay again, then things just keep on going up. But yeah, I think thinking in assets is super helpful. This is why the minimum viable brand, I think, is such a useful idea from Ele, right?
What are just a couple of assets that help people who are interested in knowing about you understand you, right? What does that offer? What is the way that you interact with the market, and is that a useful, interesting subject for when you all meet up know.

**Speaker 2 | 59:22**
Tomorrow for sure. Thank you all very much. I really appreciate it, and it certainly answered my question. I'm going to work on my assets.

**Ellie Rofe | 59:32**
What your assets are?

**Ray | 59:34**
I mean, just good luck with the refit of the pharmacy, and we'll be... I'll talk to you all at the end of the week. Bye.

