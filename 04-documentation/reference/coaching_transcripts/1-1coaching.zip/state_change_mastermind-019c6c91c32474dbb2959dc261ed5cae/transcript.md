# State Change Mastermind - Feb, 17

# Transcript
**Ellie Rofe | 00:02**
A.

**Robert | 00:02**
Yeah, I don't know, it's just the brand. You know, some people have a big beard, like you told me once. I feel like that picture is, you know, getting some of those qualities.

**Ray | 00:13**
Obvious for me, you know, all good. The other thing I find I wonder if it's like the picture of Dorian Gray, right? Is sort of it. It stays the same age as I keep on, you know? Yeah, exactly, but. But the other thing I was noticing, Robert, just in terms of, like, you know, zoom stuff is like Dimitris and Ellie having their name with their full names next to them. I actually find it to be pretty helpful. Yes.
And it doesn't need to be. Robert versus. It's questions like how you want to be addressed is the first part right, and the second is like making clear who it is. Because, you know, that way when you're doing a meeting with a bunch of clients or whatever, it's like, hey, there's Robert, there's your avatar, there's your whatever.
And it sort of looks like you're a.

**Robert | 00:58**
Yeah, right. Real person for sure. Actually, I'm trying to yeah, no, I'm trying to.

**Ray | 01:04**
Try to change it. You're a real person because we all know you're actually...

**Robert | 01:07**
Yeah, robot, yeah, the real Robert's actually doing the dishes upstairs, [Laughter].

**Ray | 01:15**
So good. Ellie, it's... It's good seat. Cas, how are you doing today?

**Ellie Rofe | 01:20**
Yes, sorry, I'm a bit late. I got a call just as I was about to come on from someone at the SDP trying to finalize some details to get this project kicked off.

**Ray | 01:33**
Well, we gladly take a back seat to money around here, that is, it's a big part of all...

**Ellie Rofe | 01:33**
But yes. [Laughter].

**Ray | 01:42**
Okay, well, congratulations on that. And maybe we can just sort of go around. Maybe we can start with Uli.

**Ellie Rofe | 01:46**
No.

**Ray | 01:46**
What is true today that was not true when we met a week ago?

**Ellie Rofe | 01:50**
Yes, I mean very little. Because I had a bit of a... Just a week slightly marred by not just illness. I injured my back on the roof early in the week. I tried to do fasting and insanity later in the week, and I just basically... Was a bit of a physical wreck and thus a mental wreck on many levels.
But the SDP thing is progressing. I did get progress on the portfolio and finally worked out the structure, and I sent a draft to Paul, who said he's going to give me some feedback because he's the one sending it on internally, so that's good.
So, yeah, there's a bit of motion, but it's been a little bit of a "nothing week." I mean, there have been good things happening, but in terms of my energy and what I feel like I've got done, it feels like it's been a bit of a "nothing week."

**Ray | 02:48**
I hear that not for nothing, but in another meeting I was in just yesterday, there was a comment about how the person had their business, and they felt like they hadn't been able to work on the business in the last two weeks.
This was the best two weeks that business ever had, and maybe there's a lesson there.

**Ellie Rofe | 03:03**
[Laughter] Yeah, but stop.

**Ray | 03:07**
Yeah, okay, well, we'll keep going around. Robert was true today, was not true for you a week ago.

**Robert | 03:16**
I would say I'm trying to... Okay. So treat it not a week ago. Mostly just, further developments on I would say maybe I would just categorize it as the internal tools for the business. And like I suppose like tech if technology and all those things are competitive advantages then than investment in, you know, in a time and energy into developing those things to be like of a more AI powered agency.
So, yeah. And it's been good. So like, I've been able to fold it into the conversations as well, which has been then to the benefit of those conversations, I have been actually started, this like pretty much officially working with Mark Peterson.
Yeah, and we'll see how it goes, but, it's been, I mean, it, you know, it's been positive. Like, I'm going to meet with him and his team. Tomorrow. We actually already met today and yesterday, and so I was able to like, get some good information out of him and just kind of figure out, like, where would be like a good area to help him with.
But like, overall, I'm just, like, looking and I'm just trying to just see what's, like, the biggest opportunity that I can create. Because I'm to be honest, I look at everything and I'm just like, okay, this is good.
Like, you know, it's fine, but, I'm sure, like, I'm already, I don't know, I'm getting restless. Like, I just, you know, I'm just kind of like, okay, whatever kind of like, in the best in a way, like, I you know what I mean?
So, yeah.

**Ray | 05:13**
I do. I trying to remember who it is. Who. Who talks about, like, you know, go find the next bigger check. You know, like there're there's current and then there's, like what's sort of the level up. And sometimes we're trying for the first check, and sometimes we're, like, looking at what's the thing going up?
So I hear what you're talking about. That's a super cool place to be. Yeah, and Betris, can we check in with you? What is more true this week and how can this how can we put the resources of this group at your disposal to help you have an even better one?

**Demitris | 05:49**
What's true today? Nicelyput. I've completed most of the final edits into the survey. Tomorrow, I have a demo live event, and I started a series of Mastermind sessions every Wednesday. People can have access from the interface of the app, so they can click one button and join these Zoom sessions. Today, I split the day. Half of it was doing my work and my homework for the communication where I struggle a lot.
This is what I would like to talk about. The other thing I do, and currently I'm doing, is trying to improve the UI of the interfaces because they look pretty old and quite horrible. I know that behind the scenes they work, but the look and feel make sense for people when they look at it.
So, I'm going to try to improve them. By the way, I used the cloud code desktop and some skills to redesign. It goes pretty well. It does the job very well for me. The thing is, how can we communicate with a professional who has these skills when we don't know the language? This is where the gap between humans and the mass-human lies.
I had the same difficulty talking to Claude with those skills to do the redesign like I'm talking with someone who has to do it as a person. I don't know whether your language... Don't ask me about design styles. What does it mean?
All these kinds of words... So, I did it in an opposite way. I said, "Okay, take a full scan of the pages, recognize what is important, and feel free to make it look good and nice." I don't know what the final example is. The night is long.
I will soon let you know. By the way, all the database is fully cleaned, so every user... You're going to receive an email invitation tomorrow morning. So you can get into that and test it because new features are added to the chart. Three agents taking care of finding useful information for you for end users.
So I would say this is quite true for the side of communication. I came with the question, guys, how can we create content easily? Or in other words, how can we create effective content easily?
I'm mostly talking about the text, not the videos. Even if it's horrible to start talking to nobody, you can deal with that. It's like a Loom. You don't have to look at the screen, and it runs, it flows, but the text is the thing I have to work on. Let me specify what I mean by easy and effective.
First, what is the framework that someone can follow to spend time? That means easy to me and effective communication into the market like he's talking right? Putting his face out to the market. Here's an interesting example. I posted it on stage. There was a report from a company analyzing 6,000 LinkedIn profiles looking for common things, what works and what doesn't work, and so on, and they gave a very good report. This is the lead magnet for them, so someone can sign up for their platform that can use their platform to generate content for them today. Use the platform.
The result was horrible. It was horrible because it had no thoughts, no input for me to give my personal side of view and who I am, what I'm doing, and who I'm talking to. They were creating copy-pasted outputs. While the challenge is, how can you talk like nobody else?
So you can be recognizable, but you can have the engagement. Maybe it's a little bit philosophical, I don't know. I don't want to bother you, I don't want to burn out. I think content is a common subject for conversation.

**Ray | 11:38**
Let's open this one up. Ellie, you have the mic.

**Ellie Rofe | 11:41**
[Laughter] Yeah, absolutely.

**Ray | 11:42**
You don't have Mudon. So can we start with you?

**Ellie Rofe | 11:47**
So it is such an interesting challenge. Funnily enough, I have been reconsidering producing a very light version of Google for myself because I get frustrated with what I'm...
I'm pretty good with AI, but I get frustrated with the lack of context and how much effort I have to put in to try and get something that doesn't sound like AI. I will say the model is so important.
I don't think ChatGPT can do anything but sound like ChatGPT. It is incapable of picking up inflection or anything. It's like an amalgam of Reddit and other internet text into a very generic voice.
But Claude 4.6 is better. It's not ideal, but better. Gemini can be really good, really strong with voice, and it was one of the early ones to really pick up on voice and be able to sound much more human.
So I think when I was creating Google, there was the context that you need to put into it. What does the model need to understand about your business? So the audience, their problems, their desires, etc.
Your offer and what you do, who you are, and that kind of thing. Then you have the tone of voice layer. I have a structure I had for that which was effectively a kind of elevation of the God, is it? Nielsen four dimensions of tone of voice where it's like, "God, I wrote these things and played around with this for so long, and I can't even remember them." Respectful or irreverent.
It's four different spectrums: serious or humorous? Formal or informal? Calm or enthusiastic. That's really for you. I UX text, but it's a good start, and then you can add some other stuff onto it.
So you have what the AI needs to know about your business, which is the context. Then you have the tone of voice, which is how it should shape the output. Then you need the brief for what the output itself is.
So you need to have some very strict parameters for AI to understand. Within that brief, you need to be able to say to it, "When you're creating a LinkedIn post in text, these are the important things, these are the hooks you can create. These are the most effective hooks to create."
So it's managing all those different dimensions and putting them into AI, and I have actually... I have to say I haven't got some amazing, useful solution for you directly because I have really found it a pain in the bum.
But I am considering trying to just do a fast, quick build for my own personal use [Laughter]. I have all the structure I was using to help me do it because I find content incredibly painful.
So I would say that's some of it. I think it's much harder for you, as we discussed, because you're doing it in a second language, and the language you're then writing in is not just a different language, but it is a different thought structure.
So you have to adapt two steps. Not just vocabulary, but the frameworks and patterns of thinking that are evident in Greek are very different when you're trying to shift them into a LinkedIn hook for an Anglo audience.
But yeah, that's my initial pass at that one.

**Demitris | 16:04**
What is interesting is that every time I put myself under high pressure of time, say, "Okay, go and put anything outside very fast right now." So I am myself. I do it on the time that works to me.
Finally, this receives higher engagement than the one where I'm working for three, four hours for three hundred words.

**Ellie Rofe | 16:32**
H.

**Demitris | 16:34**
Putting all AI work together. Looking around for all the best practices and all the things...
Here's the thing I can't realize. What is the pattern that makes the output work so I can make it a framework so I can adapt it?

**Ellie Rofe | 16:55**
If that's where you get success, then I suspect the framework is a tricky one because it's authenticity. If you're going fast, then people will recognize something that feels artificial. By the time it's gone through four hours of working in AI...
So it's something that's... It's difficult because it's a gut feel that people have, and I haven't done a huge amount of research. I know some people have been trying to look into it, but even when you take away certain grammatical devices that AI uses like "it's not X's Y, etc." a lot of people can... Not everyone, by all means...
Look at some posts on Twitter that have huge amounts of likes and people telling them they're an amazing writer. It's very obviously ChatGPT-like. Fine. But there is... Certainly for anyone who's a relatively sophisticated reader or spends a lot of time reading content, they can tell, even on a gut feel, that something is AI, so you can't manage AI to get everything right. What I tend to find with AI is let it give you the structure if you're really struggling, then draft posts, then just read them and put them away for a bit, then go back to them.
So it might be that there's a multi-stage editing process. If you go back to something with fresh eyes, you might be able to look and go, "That doesn't sound like me. I'd never say that." Or something like that.
So the... What do we used to call it? The drawer edit. I think we used to call it or something where you'd put something in a drawer for a few days, and by the time you come back to it, it's basically editing itself because you. You've got fresh eyes on it.

**Demitris | 18:48**
Yeah, I know this feeling super cool.

**Ray | 18:55**
Barbara, we'll bring you into a mix here.

**Robert | 19:00**
Yeah, well, I would just say that I think a lot of it is just practice. And I think that you have. I mean, it's hard for me to remember, but. But like if I try to force myself to remember our. When our when we first interacted.
And if we were to pull up those videos, I'm like 99% sure that there would be for any one of us, right? Like a knowable difference between how we communicate. Year ago. And I think maybe this is just a part of it. Is that because even for myself, you start to eventually become aware of how you are communicating.
And then you're in that gap between like you're just aware of how it could be better, but you're not necessarily. But you're in frustration zone where it's not. You don't have the capability yet to perform yet at that level that you want to.
But I think this is how you start to close that gap right into where you want to be. At least for me, that's how I found it to be. That, like, I would notice something and then it would bother me. You know? Energy flows towards it and maybe it starts to change the behavior a little bit, right?
Like, it's hard to do, but I think. I mean, it's kind of a non answer in a way, but like, I don't know, because I don't have AI mean, if we're talking about writing in general, I think that's a very Hard Thing for me to describe in terms of how do you actually write?
Well, find it to be just, I suppose just it. I maybe I'll just. I would say that I think essay structure has always served me well. Maybe I would say that like, I have always found essay structure to be, you know, something that makes a lot of sense. Just like, open up with a. With a thesis like.
And then, you know, three paragraphs, each one like is, you know, supporting your point and then, you know, in a conclude conclusion like in general those. I think that type of structure works quite well for even videos and for other things like that.
And otherwise though, like in terms of creating content, I would say just like, yeah, good models for sure. Like they make obviously a difference. But probably, like, for me, I find the best stuff just comes when I mostly just record myself and then use AI to clean it up and then that's it.
Like, I find that usually the big waste of time is when I'm. I mean, I've don't I don't know if I've ever actually really come away with a if I from a good experience with this, if I started off with asking the AI like, well, what should I write about today?
And then I start to get into that rabbit hole with it, you know, like it can really. Like, you know, time can really fly by, and I'll have nothing by the end. And versus if I just start to talk and I just say, okay, this is what I'm thinking right now, and then this is what I you know, I've been doing this. Been doing this or I don't know, like.
But I usually can think of something to say, and then. And then I'll if I speak for long enough, I'll eventually come to a point. So I. That's how I get my writing done, though, nowadays. And it's not too different from the before times of AI it's just that I record myself a lot more and I'm speaking out loud a lot more now just versus just mostly before I choose to keep it on my head and just kind of like think in silence.
And now I'm just like. Now I'm just talking out loud all the time. Yeah, exactly. The pockul, you know, do you. Does anybody remember this episode of Twilight Zone where somebody goes to the future and they have all these heads like everybody has an implant. It makes them super knowledgeable. Or is it just my...
Okay, I remember watching that and I was thinking, "Wow, that would be crazy if that exists, and pretty much it does now." So anyways, I'm going to try to find it. Yeah, but that would be my two cents.

**Ray | 23:04**
Boman I hear that I the, you know, the one of my favorite expressions is that the best way to make a small fortune is to start with a large one. And the and there you can make a larger fortune often just by talking.
Like you talk about recording, but like, can you just sort of get more words out of yourself? I find talking is sort of a shortcut to this, right? And sort of keeps me like, if I'm writing, like, I can get stuck on this thing, but if I'm just sort of talking, I will I'll repeat myself. I won't say all great things, but then I can say go pick out the good turns of phrase. The key is that's picking out my terms of phrase, and that makes it sound less like AI not totally perfect. Often I'm trying to put into more of a structure that, like, has a little bit of AI sound to it, and frankly, I have a lot of ticks in the way I speak that sound more like AI it's not just an X, it's a Y my god, that sounds like me, which is, and yeah, you're absolutely right.

**Ellie Rofe | 24:04**
[Laughter].

**Ray | 24:11**
So the... But I think speaking can help a lot. One thing you might try doing with AI is turn it from a creator of content to an asker of questions. The reason for this is to get you to talk more, right? That creates more of that big pile.
It's actually one of the reasons why creating content's easier when you're in conversation with somebody, right? Because if somebody else is actually asking questions and drawing things from you...
So if you can do it through conversation, all the better. That's one thing that's great for this Krisp stuff, right? But you can do that with AI by asking it to be in the role of an interviewer.
I've actually found that to be helpful. I was doing that to help out someone with their strategic position piece, and I was trying to figure out what I think about this.
So I got the AI basically to ask me questions about what I think about this or using previous questions to build on that. Okay, go deeper about that, whatever, right? Or acting like an investigative journalist and using that to pull more out of me.
Then each time it would ask a question. I would just hit my function button. That's why I've got my Mac Whisper tied to and talk press it again. It cleans it up, gives it back to the AI, and then did that several cycles, right? I'm not going to pretend that was instantaneous, but the key is AI is not creating the content.
It's certainly not creating the ideas. Those are your ideas. What AI can do is package the content, right? And that's a whole small fortune made from a large one. So, how can you get more of your ideas out of your brain and into a place where the machine can work with them for a lower cost? For me, it's the sound of my own voice, right? I find voice really helps with that.
I'm using Mac Whisper, which is a tool that Rob put me onto that I found to be super helpful. I think Robert's using something else, usually using Whisperfone now or something.

**Robert | 26:08**
Yeah, I'm using Super Whisper now, but it doesn't replace, I mean, Mac Whisper. Yeah, one time payment and keeps updating it, right?

**Ray | 26:19**
It's all local, and I can use it anywhere. I don't need to worry about my continuity. But that's all detailed. The point is, how can you just get more ideas right out in the zone of the AI so the AI is not in a position of creating content? I'm not saying, "Hey, go come up with words or whatever." I'm saying if you are my words, sift out the good ones. I repeated myself four times.
Maybe you want to pick one of those, right? You don't need to repeat yourself to... What's the good stuff? Let's pull that out. Then you know a package that so it can be used for someone else.
Then the AI is doing what it does well, which is data transformation, what it does not do where I think things go off the rails. What you're asking it to create one other idea as it regards that because I thought Robert would make a good point about how far we've come. Your library of older content. One of the best pieces of writing advice I've ever gotten. I don't know if you've heard this one too. Ellie is the...
You know, when you're stuck writing. Go collect everything you've written for the last year. Emails, posts, whatever, put into a document. The exercise of doing that can actually surface a lot of ideas.
Like, "Hey, that was a good idea." I only ever said to one person. There's something else. Here's the other gag. By pulling that stuff together, it's all like context for an AI and once again, you're in a position of having to pull out the good stuff, right? Which is you as opposed to asking it to create anyway.
So that's the thinking I have. If you give AI, "Okay, go create some good articles for me." I'll create whatever articles it can create. But that... Well, one, there's a quality problem, but two, it's not you, right? The whole point of all this posting stuff is authenticity, and authenticity is about sharing you with the world and that you are someone worth talking to. They don't want... They don't care about talking to AI. They can talk to Claude for a lot less money than it costs to talk to you, so...
But how... You do have good ideas. You do have stuff that's worth seeing. You've said a lot of good stuff, including really useful stuff to me that has produced a lot of value for me.
I think if you turn around and you share that with more people, they will get value from it too. They will then see you as someone who is a source of that value, which is not for nothing. True, right?
It's just a question of being able to connect that and to package it and distribute it. The job of the networks is to distribute it, and then the AI can be used to package it. But you don't need to create content that way, right? The creation process that you've probably already done, let's just get that out of your brain, right?
That's where the AI part can come in or out of that corpus of stuff that you already have. I'm not saying that's the solution for every single problem, but I think it can really help.

**Demitris | 29:20**
Yeah, it can definitely help in finding the ideas where at this point I feel pretty good. I'm at the level where I can increase the list of the pool of ideas, the concepts where a struggle is when I have to make the final shipping a struggle in the hook, which is the most important. I'm struggling in connecting the rest. Last Friday, Ray gave a nice suggestion.
Write it first as a draft and just ask AI what the core value is in this context because I don't have consistency. So finding the core points, ask AI to just move it to the top and do the job as a good point. Any other idea close to that in terms of writing?
Because even if I do videos, for example, where I feel more comfortable anymore than writing text, I need some text to follow. So I struggle at this point.

**Ray | 30:47**
Why have text to follow?

**Demitris | 30:51**
It can be alone. You have something to write when you post a video.

**Ray | 31:03**
Okay, I don't know what I'm flipping through on the LinkedIn app. The videos it shows me don't... It doesn't show any text going on with posts just in terms of what importance is... I'm trying to get at.

**Demitris | 31:19**
This is true, but what about on laptop or desktop devices?

**Ray | 31:30**
That's a good point. I think the regular feed just shows videos plus content together. I think that's totally correct. I'm looking at a couple of these. I'm just. I'm just flipping through my LinkedIn right now, just sort of looking at the heat.
And some of them have some text, but like, this one here has like ten words and go straight to the bit. Just by way of like it. It doesn't all have to have lots and lots of text is whatever we're looking at.

**Robert | 32:06**
Yeah, I would wonder if... Maybe we are our own harshest critic. Are you over criticizing yourself when it comes to this? Maybe because I've never really... Do you...? It's never set out to me that this was like... To me, you're produced, you're putting out content, and it's getting better, and I would say that there's a glass half full. You know that if you keep just doing this, that it will continue to get better, you know?

**Demitris | 32:46**
This is true. What is discouraging is not the over criticizing but that I put too much effort consuming too much time without getting results.

**Robert | 33:03**
But are you feel like are you actually not getting results? Like that's the part. But you feel. You know, I think, like, Dan Salivan talks about the gap in the game. So, you know, what's the. You're looking at the gap, but, like, what's the gain of like how of how far you've come?

**Demitris | 33:26**
Well, I don't have people interacting, adding a comment, getting into a conversation. So then nothing from all of this.

**Robert | 33:37**
So then what's the so what's the like, you know, so before that, so what are you writing about them, right? Like if you were to take it a step back before that point because it's never. I think that you can look at it like very pragmatically and that it is not anything personal or like you could always just break it down. Its like, what are the topics that you're writing about, right?
And rather than and put it on that like this is necessarily like a something like, they don't, but you're writing skill. Maybe there's nothing wrong with it at all. Or maybe the, you know, just putting it forward that perhaps it could be the topics and other patterns, right?
And like in what is it that you write about, right? And which ones have more success, which ones with less success like some type of data, right? Like, you know, because we're talking about like, well, how the market is responding essentially, right?
And are they looking for great writing or are they looking for topics that resonate like. And how much does the quality of the writing really impact that, right? When it comes to what the job of it is to do, which is to generate calls, I presume?
Just. Yeah, like, I mean, you know, I'm just. I don't even know.

**Demitris | 35:11**
You made a good point.

**Ray | 35:13**
Made a good point.

**Ellie Rofe | 35:17**
Yeah. I guess it's the question of what there are multiple questions in this. Firstly, just to contextualize, LinkedIn is significantly harder than it was even a year ago or two years ago.
So I don't... It's going to be difficult to expect massive leaps and bounds in LinkedIn unless you really like hitting clickbait to try and drag up follow accounts. But even then, what it's trying to do...
This might be an interesting thing to understand. I noticed my feed radically shift when I started talking specifically about hard tech and pitch decks and stuff. It actually... The algorithm is pretty good. People are getting angry with it because it's got more refined.
So they can't use a trawler net. You have to use a fishing line. That's why people are getting really angry about it. But my feed became people who were trying to fundraise, people who were talking about fundraising, and people who were building companies, and about 90% of the other stuff got filtered out. All my mates who I've known for years but have done something that's completely irrelevant to me or whatever.
I started getting random likes from people I don't know and haven't connected with before. Now, when I'm talking about stuff that lots of people are already talking about, pitch decks, raising, etc.
I think where some of your issues might be here, which is completely external and there are ways to think about it. You are talking about a brand-new idea. There's not a ton of people using it in terms of keywords that the AI is using in the algorithm to try and push you in front of people or to push people in front of you.
It's not got the same breadth of content to base itself on. So I don't know whether there are ways to talk about it. That strips it back to something that other people might be talking about so that you... It's maybe a bit short to...
But maybe there are some ideas we can brainstorm around that in terms of how you can talk about this stuff in ways that people might already be using those terms. So it puts you in front of them because it knows that this person is really interested in understanding how to do X with Y or whatever. I don't know.
I think that's part of it. But just accepting that LinkedIn is much harder. So are you filtering for likes and engagement, or are you filtering for people connecting with you, trying to...? What are you measuring?
Because there's an old saw that basically the vast majority of people who end up getting in touch with you on places like LinkedIn have never liked a single post, and they don't know they haven't commented on anything.
People who comment all the time don't buy from you. I mean, it's not like one-to-one, but so there's a question of whether I think sometimes where the signal is and where that signal is being pushed.
Don't necessarily worry too much about engagement. Worry about whether people are connecting with you and you're building relationships with peers as well as clients.

**Demitris | 38:48**
An interesting point.

**Ray | 38:55**
You know, there there's something here too, like I was thinking about like, you know, if the standard is replies, then you are looking for more text because people reply. That's text to things they're reading. People don't reply to videos, right?
So like there's a bit of and part of this is sort of matching the median. But how comfortable are you with that? Right? So there's a little bit of, you know, I kind of wonder whether it's just sort of are we circling the right thing?
And it hadn't really occurred to me until now this might be a thing is are is your yeah. Are you trying right now to get people to engage right? And by engage, what you really mean is reply. Which means that you want them to use text to express themselves back to you.
Right? When you expressed before your. Not total comfort with expressing yourself in the written form. I was just wondering, is this plain, dear? Are we just going around here just so that we can not play to your strengths?

**Ellie Rofe | 40:14**
TikTok, how do you know?

**Ray | 40:18**
Video?

**Robert | 40:19**
I think there's something really to be said about... I mean, for me, I'm very comfortable with writing, but it's hard to get a video out of me. But... Hey, but my writing will...
My video is getting... My video is catching up. Writing is... My writing is ahead of it. I don't think you can maybe use your strength and let your writing catch up.

**Ray | 40:49**
Just thinking about what we were just saying and I'm sorry, I don't mean to be dominating that the... This is why you meet. It matters because you know the way they will respond is in kind, right?
If what you're doing, if what you have is a video and your video is worth watching and your video is promoting your meetup is another way of interacting with you on video. Live voice, right? It's sort of that becomes the next step as opposed to them applying to you on... That's like with a medium point of view becomes another good reason for you just have more frequent meetups.
But I'm sure as I think about what the medium you want to communicate on is, right? That puts your best self forward. Where is it that we're trying to figure out how to shove a square peg into a round hole with all different media that we work better or worse on, and if you understand what your alignment is, then you can be playing to those strengths, right?
I think if we say, "Wait, we're trying to do more on LinkedIn." But LinkedIn as a text medium or LinkedIn revise aren't necessarily TED then that's not the nature of the engagement's going to play to your strengths. The meetup sort of feels like it's in the right direction, but it's an idea I've only just sort of started, you know, noodling around, so it's not super well developed yet.
I think there' be smart good stuff there, I think.

**Demitris | 42:32**
Yeah, that's a good idea. What other options are there to attract more people? If live events are on LinkedIn, is there anything else that comes to your mind that I could use?

**Ellie Rofe | 42:58**
So you're talking about marketing channels. That's how I'd think of it. I mean, there are broadly social media marketing channels. Knowing where you thrive and which platform your people are on helps you choose if LinkedIn isn't right for you because it is broadly a text, image, to an extent, based medium.
But it doesn't promote videos that much. As far as every analysis, the algorithm can show if your majority content is video, then put it on LinkedIn, but that's best to be a secondary platform.
So YouTube, TikTok, and I know that there are parts of it there. There are a hell of a lot of discussions happening by experts. So it's finding the right people.
Videos work well on all those places. Obviously, YouTube, TikTok, which is primarily videos, and I think you'd be surprised how many people are on there. It's like the niche audience. I think there was one of the biggest content creators on the not biggest on TikTok, but she just did Excel videos on TikTok and became huge.
So it's not just funny dancers and stuff. So there are the social media platforms, then there's obviously if you have a mailing list, you can do email marketing. If people have said that they'll be marketed to you by you.
So you can keep an... That's really about keeping at the forefront of people's minds, reminding them that you're there. It is written again. You can obviously link out to videos, but you need to write the subject heading, etc.
Events in person or online events. But, yeah, there's... Let me see if I can find something. I'll let someone else talk for a minute.

**Ray | 45:07**
Robert, can we bring you back to the conversation?

**Robert | 45:14**
What would be of, you know, what's on your mind, Dimitris? Like, just to be able to respond maybe to what you're thinking right now?

**Demitris | 45:30**
Well, I'm thinking to find a list of, things I have to focus on and things I have to do every day for the next one to weeks so I can, attract people for. For the service and like, one like a.

**Robert | 45:49**
Yeah, I think it's good to make a plan, like. I mean, like a A, you know, a strategy, I suppose. Like something repeatable that you want to do for. But I feel like you're the person who would be taught.
Like, if I was to think of a person who would know exactly what to do for that. I would probably reach out to you. Because I think that you know, that to me you have. Described those things to me in the past before and in very clear ways.
So, like, you've. I've been trying to pick up and try to implement those things to this day. So what you tell yourself?

**Demitris | 46:41**
Well, I think where I struggle is I want to fight this magic recipe of the things that can guarantee me that it's going to work because I get disappointed so early when I don't see engagement, I don't see people coming up.
You know what? It's been three months now where I'm trying to make a business in a new service, totally new one. I struggle to communicate it because it's quite technical. I see other people communicating it very effectively.

**Robert | 47:17**
What is itm that you're trying to what is it that you're trying to communicate? You're saying you see other people communicating it.

**Ray | 47:25**
Like...

**Robert | 47:26**
I'm just wondering what... Well, it is.

**Demitris | 47:28**
I saw one guy who is a LinkedIn consultant, and he's doing live events, and he plays a lot with video, and what he's doing is he builds a knowledge base, a knowledge graph. He shows the visual, but he doesn't explain to you how he gets into that point. You just see it, which is fancy and so nice and it's attractive.
So the medium attracts you. He explains to you how to do a couple of steps using some text documents. He shares the files like "Here are the things, here are my list of prompts. Go upload them and do cloud and do the similar job, and you're going to have it."
But he doesn't explain to you how you can build a graph that can be there for you and so on. Even from that point, only the ions in his existence. Speaking very fast because he talks very fast. He gives himself credibility.
He solves the problem that many people have with personal branding on LinkedIn. Many people have it.

**Ellie Rofe | 48:41**
Was to push back a little bit there. He is a LinkedIn expert. If that is your benchmark, that's really hard. His whole life is using that platform to make his own business and get other people's business, so learn from him by all means.

**Ray | 49:03**
Yeah.

**Robert | 49:06**
To marketers like all...

**Ray | 49:07**
The way...

**Ellie Rofe | 49:08**
Yeah, exactly. Bizops. That's a very high benchmark to have. That's like me going out and starting to skate and then going, "Why can't I win another gold?" It's like you're [Laughter] tough on yourself, but learn from him and see whether there are things that you like in the way he does it and then copy it in your way.

**Demitris | 49:27**
Firefox.
I'm already coughing him.

**Ellie Rofe | 49:42**
Does it work?

**Demitris | 49:46**
He is very good at that. I copied many ideas, concepts, even the redesign is copied from him.

**Ellie Rofe | 49:54**
Okay, but be careful. [Laughter].

**Robert | 49:57**
Yeah.

**Ray | 49:59**
If I might, there's a good fraction of this of what do people want to learn about and hear about and are you delivering that to them? Nobody wants your content. Yeah, nobody wants to spend time on it right where they want our solutions to their problems.
If you are either entertaining TikTok right or educational on the subjects that they care about, if you are helping them make progress, then they get value and they reward you through building up trust, engagement, and things there.
If you go take a look at your YouTube, even in your shorts, there's a significant tail-off. A few things get a lot of views, and a whole bunch of them get very few. The thing is that the ones that get a lot of views have issues in common, right? Things that
they care about. The part of what you're doing by throwing more spaghetti against the wall is you're discovering what things people care about more or less. But if you want people to be responding more, you probably need to be focusing on those things that they care about the most. This gets to Ellie's point about this guy who's helping with the marketing. You'll want to wear LinkedIn with marketing. They're coming to the person. He's giving them useful content or was believed to be useful content.
They believe they're making progress through consuming that. You've got some of that too. So when you're asking, "How do you make content?" I think there's a little bit of... You're separating it from what you're separating the "how you're writing" from what you're writing or "how you're creating" from what you're creating.
What do the people care about? How can you deliver that value to them? And like, we actually think braingraph is a wonderful story. I think if you talk about that in a clear way, there's a lot of benefit to be had with that. Hey, here's how to do the same really fast. You were talking about Neo 4J with Claude. That was a good story.
I think that kind of how to for knowledge grass has a lot of value to it. I wouldn't want to have you get stuck in the cul de sac, right? But in the discovery processes, what else is like that? What else has those qualities right that you can use to extend your reach into other people who might not care about that particular technology?
But wait, what they really want to do is solve this problem. How can you help them solve it? Right? And like where they believe they can be making that progress for free, but really what they're doing is they're building more trust with you, which then can lead to other stuff.
But I mean, when I look at your content, the differentiator. I don't think it's so much about the quality of how well you're writing or what have you. I think it's what you're writing about. And the there's and it might be worth just sort of doing that review or isn't it hard to do it yourself, give it to AI do that review for you, right? That we get more neutral assessment.
And you might find that there are some trend lines in there of these things correlate with that higher level of engagement. So we've talked some about like how did about the how to get more ideas how do you how to get more words better how you know what platforms do you use.
And all those are good things, but you know, encourage you to check in on the what's? Because I think you've got some good wets, you've planted some good hooks, you've caught some fish, right? And you haven't caught custom anything big enough that you can, like, land it in the boat yet, but, like, you won't be able to follow up on that stuff because they. They built a little bit of trust in you.
Then what's their opportunity to go build more, get higher returns on that? I think you've seen some of that. Your data is going to give you some of those hints and directions like, "Hey, this stuff doesn't seem to produce as much of this stuff, even if you think this stuff is more useful."
It might be later that you find stuff that doesn't have as many views but does have a hard correlation with sales. But I think that's a round two thing, right? That's where you have sales.
Then there's a difference between the things lead sales versus things that are just leading to attention. Right now you're looking for either at this point.

**Demitris | 54:02**
Very good point, that one. I don't speak for the problems. Today my homework was to write down the problems as we did early together before Christmas. I did it manually and it took me one hour to list 30 problems specifically from my investigation and already my experience talking with people.
So I have exactly those cases. Right after I said, "Okay, if someone asked me randomly on the street this question, how I will give him an answer." In that way, I try to transfer my voice of tone into this text. I use words like, "Bro, I'm sorry." No. These kinds of things are written there.
Yeah, I think that's the good point. Now the thing is, how can you use all the incredible suggestions from this conversation and this homework for the next step to start making viable content which talks about the problem and the solution? Problem solution.
That's only this. Not service, not things. Nothing. Great points. Thank you. Guy, super appreciate it.

**Ray | 55:23**
All right, I think that takes us to the end of the hour. It was awesome to work with you all and we will do this again next week from today.

