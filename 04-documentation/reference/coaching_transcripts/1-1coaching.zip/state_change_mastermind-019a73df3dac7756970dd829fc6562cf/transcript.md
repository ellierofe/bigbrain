# State Change Mastermind - Nov, 11

# Transcript
**Ray | 00:03**
A bit of a purple filter over you made it look very YouTube studio. Are you sure? [Laughter].

**Demitris | 00:16**
Because the recording is in progress, I use my webcam because the other one is broken and this one is a lower quality and works better.

**Ray | 00:29**
Well, I know about working better. What I think I'm seeing is just a little bit of color. Well, was it? It was a more severe color correction and created the blue and purple hue around everything you think.
You know, there's some serious studio opportunities, right?

**Demitris | 00:49**
[Laughter] I'm working on that.

**Ray | 00:53**
But anyway, I just thought it was a cool look. Yes, you are looking more human now. I think it's as the computer adjusts to lighting. What have you and Ellie, where do we find you today?

**Ellie Rofe | 01:06**
I'm in the UK.

**Ray | 01:08**
Right.

**Ellie Rofe | 01:09**
I'm in my mum's little dining room with a very harsh overhead light. Hence, I have a lovely reflecting halo.

**Ray | 01:21**
The, that's, that that's cool. And Robert, we find you still with Reservoir Dogs in the background.

**Robert | 01:29**
Yes. So I was thinking, actually, yeah, it would be funny. It's an easy thing for me to change, so I might just make it movies, different movies. I find a potential with it.
It's like there's something I can do with that because it just has so much focus. Maybe it'll be like The Godfather one eventually. Or I can just keep rotating through different movies [Laughter] or.

**Ray | 01:56**
You know, yeah, the one which, you the one in which the client gets rich, right?

**Robert | 02:02**
Yes, I know, right? The Godfather one would be good for prospecting.

**Ray | 02:11**
Your prospecting. Your trip wires offer they can't refuse. Absolutely.

**Robert | 02:14**
Exactly.

**Ray | 02:15**
Okay, Absolutely. Exactly. Okay, well, let's go around the horn. What do we know today that we didn't know a week ago? Ellie, can we start with you, ma'am? Maam.

**Ellie Rofe | 02:23**
Sure. I had a call as good as you can get when someone gets on the line and says, "I've already chosen a vendor for this project." I really liked your website,
and I wanted to talk to you in case we could do some work for the next raise. By the end of the call, she had asked me for a custom package in case the current vendor didn't really deliver something she felt comfortable with, so I could do a review with her or whatever.
So I put that together, and that led to some really useful conversations with Ray about the way I've been thinking about it. I start with someone who is getting ready to raise, and there's this whole big, complete package.
Actually, a lot of people start raising, and they find it really difficult and actually need someone to help. Is there a way I can have a more reactive package that can say, "Right, let's meet you where you are, let's do something quick and iterative."
Then I'm building out this event, which will be interesting to test because it's now a paid event because we want people to turn up and do a full half day, targeted at seed to Series A level.
It's me and the lady who does investor alignment investor outreach stuff. There's a decent amount of crossover. It's really fascinating because we're doing it fast, and it's very experimental.
Suddenly, she's quite... She's actually quite a fan of Tony Robbins, I think. So there's lots and lots of this affirmation language coming through. Then I'm like, "But can't we just make it pragmatic and literal?"
So it's fascinating to see how two different people, at this point, I think I'm deferring a bit more to her and letting her run with it because it means more to her. But, yeah, it's an interesting sort of... How you market something when there's a partnership is really interesting.

**Ray | 04:35**
Yeah.

**Ellie Rofe | 04:36**
But good. It's moving along, and it would be amazing if we could get five to ten people in and just get them some results before the end of the year. So things are ticking along.

**Ray | 04:53**
Super cool. And you were saying before the end of the year, you even get the results for the new year or you even start the program for the end of the year?

**Ellie Rofe | 05:02**
So it's a half day on the 5th of December, and then there's like a pop-up community group.

**Ray | 05:06**
Okay, got it right.

**Ellie Rofe | 05:11**
The gold, they roll into January and they're raising.

**Robert | 05:11**
Okay. Super cool.

**Ellie Rofe | 05:14**
But they've got a plan to make sure they raise effectively.

**Ray | 05:19**
Super cool. Alright, Robert, can we check in with you? What was true, what did you know today that you did not feel.

**Robert | 05:27**
So yeah, I actually just trying to turn the wheel and pretty much just do more marketing in these different areas. I posted to the rocket forum. So I'm getting more in there, and I've noticed just looking through there that there's little to no discussion actually about AI.
So it's interesting because it could point to whatever it means, but I think it's just in my mind. I don't know what I was imagining because as you go through the form, you see there's a lot of discussions around when you get deep into the technology and more about people who are really working with this stuff.
They have nobody else to talk to about it, so they're just asking each other about these things that are really the cutting edge of technology. So, they have a place to discuss it.
But when it comes to the AI part of the discussion, it's like a ghost tab because that's not really what they're in or anything like that, right? I don't think that's what's happening.
So which is... I think... But which is actually an opportunity, I think, because I have a person's perspective that doesn't mean it's not something that's important to this technology or space.
I've seen the other side of the discussion where the rocket company themselves is trying to figure out essentially how to move ahead with this stuff. So, it's not like in a way, I have enough perspective to see that it's not a tar pit.
It's just something that I think is unexplored and probably pretty early. So, yeah, doing that and trying to basically just that, trying to stop myself from studying too much, which is hard, but
I've managed to maybe just hold myself back in a few different ways. I've got the MCP working very well, so that's been good. I have been up and down with it over the last week because I refactored it, which introduced a lot of bugs, so I fixed them.
Then the other thing that I did was something I took a page from your book, Ray. I was trying to think of what I could do for this thing that I've put together. That would not fall into the category of "tankering", but more like an actual meaningful change to how it operates.
So that it just is interesting to myself in terms of generating Xanoscript through the SDK, and I realized that probably one thing that might fall into that category for me would be to remove it from the middleware and just put it entirely into the MCP, the actual SDK itself, because I don't have there's no external libraries to it or anything.
It's just pure; it's completely isolated in itself. So it could run on the cloud worker as anything else; it's all it is, just an engine that just takes in a certain input and just spits out an output without any other dependencies or anything.
So, in order to shorten that feedback loop, just take it, make it a tool, and then allow it so that the AI can just rapidly use it without having this latency between it and the middleware and just allow it to spit out, like, use it as an engine to say, "Okay, I'm making Xanoscript." Making Xanoscript is tricky. Now let me use this tool that makes it 95% or oftentimes 100% perfect.
Then it can make the actual submission of it a second step. So what that really allowed me to do is be able to just actually let it fill in the gaps on its own, essentially. And so it's working better.
That was one of the things that only took me an hour to do. So it brought a very interesting, I felt, new thing to explore in terms of how much effort it takes. It's not like a one-week thing; it's a one or two-hour thing.
So that's interesting to me as I've been working on that. It makes the people happy. Luke is a person who... I'm happy that he's happy because he represents something to me in the sense of the type of people I'm trying to help.
So he's happy that the STI, the tool itself, is working better. He's he thinks it's a very select solution and all this stuff. And I think the only other thing that's on my mind is I want to be. I think I want to be I want to ask for more.
I think during my negotiations with, like, prospects and so on. Like, I want to. I feel that I've, like for more favorable terms in the sense of just ask for, like, fifty percent upfront or something along those lines.
I think I've been a little bit loose with. Like. I've been pretty easy to work with. But I think that just the nature of people is that they then they kick the can down the road when it comes to, like, paying the bill.
And it just it's kind of shitty. So I have that situation now with, like, one person who, you know, who's just taking too long to, like, to pay their invoice. And now I'm just trying to learn from this essentially, right, like, so yeah, all kinds of stuff, ups and downs.

**Ray | 11:41**
Sorry about the collection challenge. Yeah, Dimitris, could we turn to you, sir? What do you know today that you didn't know a week ago? And how can this group be of service to you today? Because today is your time in the sun, your house seat.

**Demitris | 12:01**
In terms of knowledge, it's not any specific. I learned something new. I focused mostly on the past week doing the marketing stuff for myself. I've put a rule to create content for every single day on LinkedIn and on YouTube, so I'll try to be consistent on that. I see that the quality of what I distribute is quite lower,
but I feel more like thought publishing. So it seems more realistic, and I think the views are even more realistic. The number of views and the interactions instead of the bias of one posted went very well and so on. I launched the meetup for the upcoming Friday with Ray, where the plan is to not talk about the digital trends but actually explore how we can do data scraping using MCP servers. I
thought that I had a great conversation last Friday with Ray talking about this thing and how these two things can be combined in terms of the core purpose of the meta was for the digital trends, how scraping matches,
and we thought that it's about the data finding and importing part, which matters. And sometimes we struggle to find it or we struggle to access them. We plan to do it tomorrow. I have planned to do some promotion for the event. I sent already to previous meetings, attend this personal email saying, "Hey, we're gonna do this and so on. This is what we're gonna discuss and so on."
For the main question about what I have to discuss today, guys, I don't have a specific question at the moment. I feel like I am in a stage of doing things and waiting for the results. So I don't feel like I have something specific to bring here.
I would love it if you guys brought a subject and discussed it with all of us. What do you think about it?

**Ray | 15:02**
Okay, well, let me ask you this. What is it that you want? What was your main goal, and perhaps get a little bit into goal-setting stuff? What is your objective for, say, the end of this month?
I was talking a little bit with Robert about this in his coaching session. I'm not sure if you and I had a similar conversation, but what is the thing you are fixing to be true on December first, that is not true today? Because then you can back up from that to...
Okay, well, what are the necessary preconditions for that? Then that can be driving activities. I certainly hear what you're saying. You feel like you're doing a bunch of stuff, and then you're stepped away from what the fruits, right? Will be of those labors.
But that's a starting process and saying downstream with that as results, but before that is intent. So, yeah, would you be up for discussing a little bit like what your thinking is about what you want from the month of November?
Then that can probably link to... Okay. Then what we were trying to make true. Then that implies what the set of actions are.

**Demitris | 16:19**
My goal is to achieve having at least one prospect for an introductory call, not an actual engagement coming from my marketing activities, which are mostly posting on social media and LinkedIn, and YouTube. The difference from September and October is that I feel more comfortable finding the idea, working the idea, and creating the final piece of content to be distributed. I feel more fluent recording myself. I don't care that much for perfection. I deal with that and move forward.
So, yeah, of course, there are many things to improve in these things so I can get closer, but at the moment, what I'm experimenting is the process that can keep me consistent first. And secondly, there are some tags in my content, like categories, like educational stuff, more critical stuff, or these kinds of things.
The number one goal is to have one introductory call from these activities because at the moment I have... From other resources. Last week, two people submitted a contact request through the Zapier Partner Page where I'm a partner page, and I don't promote it that much.
So with both of them, we had a call. The first one scheduled an engagement call. It was today, and we started working already. The other one asked me for a specific something like a quote where I had to describe my approach and solving his problem, which, by the way, includes data scraping.
So I delivered that. But they came from another source. The Zapier partner page is not the source I can trust. First of all, it's about the branding. I don't want to do brand on a specific product. I used to do it with her table, and it didn't work that well.
It's good to be close to a very well-rounded product. That's a different approach. And secondly, it's the tenth request I received and two out of ten responded to me back. So I received ten requests from the Zapier partner page, and only two responded back.
So this is not that safe a resource to invest that.

**Robert | 19:26**
Yeah, I hear that.

**Ray | 19:28**
Although I did notice something. I'm just going to put this into the chat for a second because we're talking about Zapier, this is your profile, right, on the Zapier partner directory.

**Demitris | 19:43**
From the URL, I guess. Yes. Okay.

**Ray | 19:46**
The reason I bring it up is that there's this red review section.

**Demitris | 19:54**
Yeah.

**Ray | 19:55**
And an opportunity there to get people who like you, your existing clients, or other people just to speak well about you. This can even just be a useful trigger because then people who say nice things about you in that context because you're giving to, "Hey, this is for my profile, right?"
Then, it becomes a triggering event that then has some nice things about you that you can then be using here and elsewhere. I bring it up because while I appreciate the focus is on the social media part, this seems like a cheap thing to create content that has become shareable.
Because then they're saying, "Hey, they're your client, and you can have a story to tell that can help with that." Anyway, okay, so if your primary goal is to find out to get from those... Can I ask when people are coming in there, have they selected you from the Zapier solution partner, or are these others? Do you ask them how they found out about me? No, for yourself, no.

**Demitris | 21:06**
I didn't ask. I guess they submit... I guess, right? It's not good. They submitted a general request. And Zapier made the delegation and sent me the notification. Or they just put some filters on partners looking for a person who has a match and a couple of criteria most to use.

**Ellie Rofe | 21:24**
Some fers.

**Demitris | 21:34**
Most probably one of the criteria is the price, and they just have to click the contact button.

**Ray | 21:43**
That's you're imagining they're doing right or they're telling you that story.

**Demitris | 21:47**
Yeah, I ig.

**Ray | 21:52**
Can I ask Robert and Ellie, like what do you do when you're meeting a prospect for the first time and whether what kinds of onboarding questions you're using because this gets to your question, would be just about like, seeing that work bear fruit. Part of it is being able to know whether it's bearing fruit and what that data you know and how you're getting that data. I can speak to my experience on this in a minute, but I really appreciate Ellie and Robert, you could share what you do to help identify where clients are coming from, if anything at all.
Yeah, I was just.

**Robert | 22:28**
Gonna say. I asked him. I just say, "Hey, how did you find me?" By the way. Just so that I know what's the best way for me to approach this conversation is because I know there's a lot of ways people can find me. Depends on if you through the community or if you came through whatever.
So just to make the most out of your time, you just mind sharing with me what you know, what your experience is like? What brought you here to this conversation? And that's usually got something going for the next couple of minutes at least.
So a lot of the time I'm doing it because I don't even really proceed with the conversation unless I can answer that question to let me know how they found it. Because if I don't ask a question, I really run the risk of spending a lot of time speaking about something that has nothing to do with what they really came in to discuss or I just made it just... I'm explaining Zoho to somebody who actually really already knows Xano or I'm explaining MC how to set up MC CCP to somebody who already knows how to set it up or trying to look...
Yeah, so basically it's I'm just asking what brings them there, and part of it is, one part of their answer usually answers that question.

**Ray | 23:34**
Okay, cool. Ellie, can I ask you how? How do you purchase?

**Ellie Rofe | 23:41**
I've pondered this a bit.

**Ray | 23:42**
I beg your pardon, I believe your microphone's off.

**Ellie Rofe | 23:46**
It certainly was, I have pondered this a bit. Because people send me their deck, so we already have a conversation opener.
It's there and it feels like the thing that I should be focusing on. I have generally avoided the first call asking how people found me. Sometimes it's obvious as well, like some of the messages you're on LinkedIn or whatever.
So I, yeah, I've been a bit torn on whether to ask or not because it feels like in the context of someone who sent me their deck and we're trying to barrel through their fundraise, it just feels like I'm asking a question that's outside of bounds at that point.
But I don't know, that was just a hunch, really. It's not something I've done deliberately. I have been considering more UTM tracking and making sure I can track where people are coming from rather than just ask them.
But maybe I'm just overcomplicating that and I just should ask.

**Ray | 25:01**
Yeah, I usually lead right in with the first question I usually ask someone for the first time is where do I find you in the world? And that gets them to speak a little bit about their context.
Then the flip of that, which is... Yeah, and how do you find me? What brought you to my door? I'll often say both those things because I didn't say things twice, and that I find that opens them up in the first sixty seconds, right?
I've established that I care where they are. I know where they are, which gives me a sense of the time zone difference. I've got the information right about how they came in and said, "Well, I found you on all those communities that I frequent."
Then I saw your YouTube, or maybe they found it because I found a YouTube about X, and then I watched a bunch of Ys, and then whatever. They answer the question. They don't spend minutes on it, right? They're...
But they usually have a pretty good top of mind. This is the zone in which I associate you with, right? They may not be the only way they interact with you, but that tells me what's top of mind, not to tell you like 60% of YouTube that people describe because that's how they found there's a thing to do with.
That's one of the reasons why I've been so enthusiastic about using YouTube because I found that it really does produce leads. My experience is that by putting it very much at the very beginning of the call, not doing an easing in and then asking, but having to be part of the easing in, I'm able to get the license to ask that question.
Then, within 120 seconds at the beginning of the call, we're launching into, "Okay, what's the nature of the challenge here?" I found that to be pretty helpful, which I bring up because just having a tactic right for how you're going to find out where people are coming from is, I think, going to be important for you to get the confidence that your approaches are helping or aren't helping, right? Whichever the case may be. Can I ask Robert how Luke got into your... into your meetup?
Right, because now he's all over it. He likes to have a weekly conversation with Robert, but he's clearly a frequent flyer. He's come back and forth in terms of being a client of yours. How did he come into the door for you?
Because I think about that and I think about Luke's story, which is one that you would want to replicate, but I think it's the kind of thing that Dem is looking to replicate in these additional marketing issues you're doing, like the meetup that I'm participating in too on Friday.

**Robert | 28:04**
Yeah, I mean, it's really interesting. Luke is actually, a person who when I'm sorry, I'm just thinking back a little bit just to be accurate, but basically, I first of all, a lot of the. I would just say that being on marketplaces in general, like being on the Xano Agency page, being on those places, that's where that conversation started, right? Not necessarily through Luke, but through a person who he was, I suppose, like working, kind of like four, I suppose at the time, like that person was considered like the lead on the project or something along those lines, like he was some type of team leader and but he wasn't the main person I was speaking to. He was kind of brought in as like, hey, here's a person name was Andrew, and I was like, okay, good.
Like Andrew is the client in my mind and I'm dealing with Andrew and Lu is another person on his statement. But I was doing well by Andrew. And then. And actually at that time, what I was trying to do, which ended up working out was just to be easy to work with in the sense of like, I'm not just selling to the person Andrew, I'm selling to Andrew's team.
So Luke, in the sense of like, you know, if Luke wanted to reach out and he was like, hey, let's just I want I need help with something. I made it very easy for that. So, that's what happened. Luke reached out in parallel and said, "Hey, I have these small projects I need help with." So,
I ended up pretty much just making him another client. At that time, I was doing a lot of hands-on stuff. I was building. I was the only one who really knew how to use these tools that I was making. It was very early on relative to now.
I would just say that Luke was someone who self-selected himself. He was a person who, because I kept putting out stuff, he was just interested, and he picked it up. He wanted it.
I just kept trying to use him as a North Star, trying to get feedback from him. I would stay very engaged with him. Even to this day, I don't look at him as my big opportunity, just going to explore my business or anything, but he's been very... I feel like he's been more of an asset to me in the sense that he helped other people build trust in me more quickly.
How did he end up in this position? It's really been a result of the fact that it's hard for him to find these tools anywhere else, and that I am genuinely trying to help him.
So, he built a lot of trust with me over time, and he seems to have built a level of... I don't know what he's built, but I know that I help him make more money. Basically, he wants to go and do things and build faster.
I'm the best person for him to talk to about those things. There's nobody else really for him to speak about these things with. Like, when it really gets down to the details of it and the fact that he's using StampYou and all this stuff, I'm speaking his language, and he's using my tools, so he's very much in my ecosystem now.
I've always been just very encouraging for him, and I've always been like, if he ever had an issue or something, he doesn't have to ask me very hard for me to go in to fix it.
I have really done my best to try to make him feel like the more energy he puts into this, I will be there to help him go quicker. It's just reinforced the relationship, I think, more than anything.
Until now, he's a person who I think, yeah, he gets the idea that I've had plenty of opportunities that I could have not answered him at all. There's no obligation for me to
answer him. But I think he got the idea after a while that there doesn't have to be an obligation, that I am just genuinely trying to be helpful. So, Luke is basically a product of, I think, whatever I put into the market, he's a thing that or that developed, very... I made it, I created it very purposely.
I really wanted him to stick around, I wanted him to succeed, and so that's Luke. Luke is just a reflection of what I hope other people would benefit from, and he and again, it's self-selecting. He was in the circumstance.
I think that you throw a lot of seeds. There are a lot of people who I've had the beginning of that conversation with, and it doesn't work out. The birds were coming to take the seeds right from the... That's just the way it is.
I mean, and... And that's fine, but if I do it at the scale... If I do it with a hundred people, or if I do it with two hundred people, I've had a lot of conversations, and a few people will end up staying and going further.
Some people will only come for a couple of sessions and then leave. So, I think it's a combination of things, but it's a game of numbers more than anything. It's something that had a lot of ups and downs as it goes along, but I always took it as a positive challenge. That and this...
He wasn't always happy with me. At times, I created situations where he was depending on this tool, and I had to fix the tool for him to even be able to continue his work.
But I always tried to look at it as a positive thing. That means that he needs a tool, and so that means I'm making something useful. Just like any relationship, it has ups and downs.
I've tried to take care of the relationship with Luke, and I feel like it shows for that.

**Ray | 34:56**
Okay. Part of the reason I was asking about Luke is it falls in the category of where do people come from that you find in these events? He's worked deep into the event.
It sounds like the story is essentially that he was a person who served on the periphery because he was working with an existing client, and then he came to you. He developed more affinity to you through the event,
and then that turned into a more significant client relationship.

**Robert | 35:21**
Yep. Through the community as well. I would just say, like he was, you know, I had him join the community and he's in my ecosystem like I'm always making. If I make a post, he sees it. If I release a product, he sees it.
And so all that stuff just keeps building up. He could never escape me. He's on my LinkedIn, he's in my school community, and so on. So I think that the network effect was something helpful because I worked on things that released him. He has to see it. How does he see it? He sees it because he's somehow in my channels.

**Ray | 35:54**
Okay, well, you make an interesting point about the being in your channels and sort of like the fact that you put out stuff. This is where people can find you. And then they have a way they can sort of maintain a relationship with you, right? Without having direct, without having to be a consulting relationship.

**Robert | 36:10**
Yeah. So I just want to add one more thing that I find to be true in the sense that it's helpful because it's not just Luke. I have other people who, the way that the conversation gets...
If they're not there in my network, then they're basically the ones to reinitiate the conversation. Not just because I follow up with them, but because they see my LinkedIn posts and they see all that stuff.
So they are the... I think the only reason it went up is because Luke kind of... So to say that I wasn't pushing him, it was my... I would every time. I see this when I post on LinkedIn that people will... You can turn on the lights and see all the roaches in the kitchen.
Everyone's there all of a sudden. I would just see, as soon as I make a post, someone sends me a message and says, "Hey, I'm sorry I didn't answer you. I want to talk to you about this thing. I meant to do this thing. I completely forgot about the conversation, but...
Just to say... Look, AI couldn't imagine me being in this position now. If it wasn't for the fact that, if I was always chasing him, I was like, "Hey, please, can you try this? Can you try this?" There's a lot of it that was actually focused on other things that makes people want what they can't have, I think, right. There's this nature to it.
So whatever that... I'm not sure how good that is for me in my case, but yeah.

**Ray | 37:47**
Okay, well, those are interesting points. Ellie, can I maybe turn the conversation back to you? What's your ecosystem? Do you feel like there are people you don't know? I suppose there are people you don't know, but there are people who know you, but you don't know that they know you. There are people who know you, and they're people who you're actually doing business with, right?
Imagine that being a little bit of a funnel type thing and, what do you know, particularly for that second-to-last category? There's this universe of people who are almost customers,
but who are not customers, right? But maybe the timing isn't right or whatever. But there's some degree of relationship there. Robert was alluding to how his social media is in, seeing some of the stuff that he's getting out of it.
It is like those people who are almost... What do you think that looks like for you in terms of being able to have people who will be able to continue to know you and build up that trust, and for the prime moment to come along.

**Ellie Rofe | 38:53**
I think it's been lacking. To be honest, I think I've been focusing a bit more on project delivery and direct relationships, which I'm finding less useful than they used to be. In 2020, you'd get people referring you, and people would just jump straight in, and there were just less referrals going on, and people were just a bit less reactive.
I think it's part of what I'm trying to solve or not solve, but create more of an engine forward. If this event works out really nicely, then the goal is to create two strands of people who know me but are working with me. Yet, it's like the people who we've brought through the workshop who don't engage in a project with us but then know us, and they are people who are planning to raise next year, so they are cradle to grave. Get them early. Not quite cradle to grave, because the cradle bit will be a longer-term project where I'm trying to talk to people about spinouts from academia and those talking through incubators and accelerators, that kind of thing.
Then, the other piece of it is that I need to build on social media. Far more is if you're in the middle of a raise and it's not working, let's talk. That's what we discussed on Friday. I'm building the website, I'm building the landing page of the event. There's lots of content generation going on behind the scenes at the moment, but...
But yeah, I think that's what's been lacking. I think I've been focusing in the wrong places, and it needs to be social media and understanding where people are. There are different points in a customer journey and where they are on it and how I can connect with them then, even if they're not going to buy from you for 3-9 months.
I think there are statistics. The reason email lists are meant to be really good and newsletters and that kind of thing is because most people don't buy from you for somewhere between three months and two years.
So, it's like you just have to keep pushing people into that process so that at some point, the number of people matures into the point at which they want to work with you is enough to keep you sustaineds.

**Ray | 41:14**
He.
Right. And there's just a... The proof of life aspect that goes along with saying, "Wait, hey, here are these people who are engaging with Robert, like the fact that he has a post. I think he has multiple posts."
I was noting that for your social media. It's a question of who's putting it on and who's engaging with it, right? Not just how much engagement, but who they are. Then does that imply what a potential next step could be in terms of not necessarily doing the main core offer, but it implies what a prop for prospects can look like.
That's something you and I have talked about a little bit, is that what that tripwire early product can look like? Robert, of course, you've been doing that quite a bit with this Snappy Staff, right?
Seeing how that could look. Can I ask about the interest in the other thing about putting these kinds of outreach out? When we think about the jab, right hook aspect of it, the right hook, which is the sale, if the sale is out of scale
with what your clients are used to buying from that kind of decision-making structure, it can become harder. Do the people do jab right hook directly into a $10,000 engagement?
I guess that will depend on the market, depends on the timing, what have you. But this question of whether there's the thing that's easier to buy at the front, right, that has that clear value proposition, is relatively low risk in the short term. Have you been giving thought to that question of what that earlier offer might look like that is easing them into that flow so that people can be going from social media to YouTube or what have you. Then I will say, "Hey, wait, there's this way that I can do business with you to further improve that trust." trust.

**Demitris | 43:33**
That's a good question. To be honest, I do not.

**Robert | 43:42**
Ask.

**Demitris | 43:45**
That not... much on my content at the moment. What I do is just share ideas, thoughts, suggestions, experiences. This thing, and nothing asked to do for us, engagement. The only ask I posted is yesterday for the launch of the event on the upcoming Friday, which is one type of ask.
It's not actual business engagement, but it's an engagement with me. That was the only one I did so far. far.

**Ray | 44:21**
Yeah, no, that's what you mean. It's not commercial in that they're not paying you money for it. Yeah, I hear you saying, "I actually think that the event makes for a pretty good right hook because it does have a product for prospects' quality to it in that you're asking them to commit their time, and that's not as good as gaining them to quit their money." I'm all for making happy money, but as a way to start,
I thought... You know, Li, you were in the room, you told me you think I'm off base here, but I thought that last... The meetup that you did with Mitch... I thought it was phenomenal, and I learned so much from it. I thought you were great in it, and I'm really great by waiting to see the Opus stuff coming out, right?
See some of those bits and see more and hopefully we'll get some more of that content and see which albums were produced for you. But I thought it's the right topic, it's engaging, it's high value. It does have the feel of... By the way, this helps answer your question of how to move them up the flow, right?
What happened with Robert? There's someone who knew him. He got to know Robert a lot more, basically through the event, right? That accelerated the trust, which then turned into a commercial relationship and perhaps a whole journey.
Luke is quite the character, but the thing I'm thinking about here is if that event were more regular. When was the last time we had the event? That was it, two weeks ago, three weeks ago.

**Demitris | 45:57**
I figured it was three weeks ago.

**Ray | 46:00**
If it were more regular, what you could have is content, and then your CTA, the right hook, is to join the event, and then gain them the next step on the ladder, right? To have more of a relationship with you. You're not asking them to make the big leap.
Then we can ask, like, how else can we introduce the steps to make it easier for them to get across those? Because right now, it's like, "Hey, you're down here, it's free, it's social media, you're scrolling along."
From the trust relationship we have in there now, we're going all the way up here, right? I'm not saying that nobody will do that, but that seems like there's a play on hard aspects. So how can we be helping them? How can we give them the chance to accelerate that? No life trust development?
I thought the event that you did with Mitch because I missed the first one because it was a state change event that conflicted with the second one. I thought the second one was phenomenal. The thing I've seen with Robert is that even when there aren't a lot of people up there, Robert is impressive, and that creates both content and the direct relationship. The dress relationship is pretty great because, I mean, the conversations that you've had with Wes, Robert, and with Luke, just got to bear witness to.
I mean, that was. That was building up your reputation.

**Robert | 47:16**
You know.

**Ray | 47:17**
People who otherwise... How would they get in? So, all of which is by way of saying that I think that when you combine those, it's like installing the stairs, right? Because you're giving them the next thing up they can do that would be a commitment of their time.
Okay, then what's the next thing up from there? That's where Robert's charging for Snappy became part of that, which is not, I don't think, making him giant bucks by itself.
But everybody who does the lead stream for his core offer... To someone who's gotten even more buy-in for that. Right? So, how can we get there in between? I guess what I'm trying to get at is what opportunities we have that we all have to make it easier for the client to grow their relationship with us in a way that is delivering more value to them sooner, right?
Derisking the core so that they can get even more value because we know that they work with you, they're going to get a lot more value, right? It's not just a matter of you getting paid, it's a matter of you being able to deliver value to them.
Then how... So, how can we make that easier? Faster? I think the event falls into that category. I think that then becomes a jab, right? Hook. So, if what you're doing is you have an event once a week and you are able to have a mix of social media posts that are thought leadership and letting people know the event is happening, that becomes your jab, right? Hook strategy, right on the content side.
That doesn't need to be the whole thing forever. But it's the thing you have right now to offer, and that gets people in, and then they can go up to the next level. But I think that the... Yeah, when we're talking about this at the beginning, the idea of having... Yeah, we're going to social media and we're going to test because I want social media to turn into business for me, and I think Ellie, you use some language.
I know you didn't mean it this way, but you used some language that made it sound almost like a passive relationship, like you're waiting for the content to do the work, but that's not actually what happens, right? The content is a tool that allows us to build a relationship with the customer and the...
I appreciate that we all know this, but I think the way that we can put that into action is to ask, "What's the step that comes after that?"
I don't think we need to build a whole staircase necessarily, because we don't necessarily know what higher steps look like, but I think there's a... Can you get them from the zero step to the one step, and to that we need to have a one step?
I think you almost have a one step right now, Dimitris. Certainly, we do this week. Let's put that to work, and then I might say, "Can we repeat it the following week?" I'll show up for the meetings.
I think they're great.

**Ellie Rofe | 50:30**
Can I?

**Ray | 50:31**
I don't so much for you, Ellie. Go ahead. Sorry.

**Ellie Rofe | 50:34**
They are amazing, and I learned a lot. The only question I have is who the target audience is.

**Ray | 50:45**
Four.

**Ellie Rofe | 50:46**
Because there is a difference between the mechanics of what you do and people who are interested in the mechanics of what you do and the promise of what you do and people who are interested in the promise and sometimes that person is the same person, and they are your client, and sometimes that person is peers. They're interested in the mechanics, and clients want to know how
it works. It's like why it's better than just dumping their information into a digital twin of software. Something that calls itself a digital twin, but is just dumping information into something that is basically more like a Claude project or whatever.
That's the only nuance because I think the content is absolutely brilliant. It's just whether it can be slightly shaped to the people you want to buy from you versus the people who are just really interested because they want to do this themselves or they want to do it for other people.

**Ray | 51:47**
That's such a good point. This is where you bring in a guest, right? If your guest is technical and your business is... If your guest is business, you're technical, you know, because you're obviously the person at the air section between the two.
I think this is how... I mean, there needs to be more awareness of who the eventual customer is, but I think the core market promise is being right at that nexus of the business value and the technology and this cool new technology, right?
Because digital twins are a nexus idea, and you bring someone on who you perceive to be more technical. You talked before about how much you enjoy the business side of this, right? Perhaps even more the tech side, and that can be a great way.
So, the content you bring that you are then... Okay, here's how it links to your business, and the person who's coming in is using it right in their business. You can be talking more about technology and getting into the nitty-gritty of it, as being a...
Yeah, how you keep on that, keep that being complementary, and keep on adding more value to it, right? You don't need to worry about that. You're going to have two, right? It's always an A to B because you can flip between the two.
The fact that you can flip between the two is your big promise. But could you be the person who links those two things? I don't know. It's sort of a how-to, and I think there's a really good point: are there existing customers or other people on the business side who can be talking more about the business aspect of it, right? Which then allows you to integrate. Ironically, Mitch's thing was actually quite technical, which I think is partially because he's really enjoying the type of court even though he's someone who I think was being a little bit more on the business side when he was at his hes drers.

**Ellie Rofe | 54:05**
It's all fascinating and it was abstract and it was philosophical and it was technical, but it's like you by the end of that, if you're bringing on people that you want to pay you to do this for them, you want them to be going, my God, is you want one of those not that was really interesting. There's lots of stuff I don't quite understand. How does this help my business?
That's the only gap I see. I'm not. I'm not trying to, you know, detract from the quality of the content and the value because I found it genuinely one of the best things I've attended for the quality of the content and the value I got from that.

**Ray | 54:44**
Well, that's a good point. I mean, what would you say about... I appreciate we're coming over with the hour, but why I appreciate you and I use the analogy of air and ground with your partnership...
Is that the kind of thing that you think maybe Demeter should be? He's the connector to whatever the more high-flying thing is. It's coming from whoever that guest is who might be technical or business or whatever, but being able to connect that back to how people will be able to get value from it.

**Ellie Rofe | 55:16**
I think the question prior to that is what are you promising people? Why are you asking them to show up? Because once you've got that framing, then you can choose what the relationship is. What,
like, Laurel and Hardy or whatever, you want. But I think the question before any of that is why are people turning up? Because at the moment, I think people are turning up because they're technical and they're really interested.
I don't... I genuinely don't know. Maybe I'm wrong. Maybe some of those people would be clients, but I get the impression that most of those people are just wanting to learn about the concept itself as potentially part of their offerings or something. They want a DIY. How can you flip what you're offering and all that incredible insight and cutting-edge understanding of this, a way of applying AI and knowledge graph and all that kind of thing to someone who you want to pay you for?
It is... Here's why. You're going to waste your money on things that don't actually bring you the value of AI, and you're going to get disheartened by thinking that AI actually isn't as clever as it can be.
Here's how we make it as clever as can be. You can get ahead of everyone else in this hour session. You can understand how AI can help your business more than anyone else. I'm going slightly into sales tactics, but that's what I'm saying. What is the promise to the people that you want to pay you?

**Demitris | 56:57**
V good points to think about because I never thought about these answering these questions.

**Ellie Rofe | 57:06**
By the way? I don't think it's either or. I think you can have both. I think you could do different sessions because what you're doing with Ray, with Mitch is really good and it's thought leadership material and stuff. I just think, have maybe have something that's more commercially designed.

**Demitris | 57:26**
Designed commercially or...

