# State Change Mastermind - Sep, 30

# Transcript
**Ray | 00:02**
Hello Robert, how are you today?

**Robert | 00:05**
Good, how are you doing gy Gussy?

**Ray | 00:07**
It feels insane to me to have actually empty bookshelves in this room right now. We got new bookshelves, and it has new capacity, and it hasn't quite filled in yet. As opposed to my office, which has been the store of not only the bookshelves but half a dozen boxes of books that boys were only willing to put in boxes
because I said otherwise they have to leave home if they aren't actually going to be on the shelves because it's bare, and they like their books, and they've slowed down like history. Hey, they were reading this last year, and that was so sweet.

**Robert | 00:41**
But it's kind of weird to see them empty, actually, now that you mentioned it does look a little too spacious back there.

**Ray | 00:50**
And don't think they'll stay very empty for very long. I think they're quite excited to get to the library, borrow a bunch of books, and have more books that then move back to DA's office. We have another office out in the living room and what have you.
All right, well, we should get a drink here in a minute, I would imagine. Today, it is your hot seat, Robert. Maybe we can do a quick round-up of what the week has been so far.
Ellie, could we start with you last rejected? You actually had some pretty interesting conversations, and if I recall, in pubs or tea houses in London or out in the UK, maybe other.

**Ellie Rofe | 01:32**
[Laughter] Pubs, tea houses, come on... [Laughter] Yeah, pubs in the countryside, in London, in a town called Buntingford, just for full, ridiculous tweens.

**Ray | 01:48**
Two.

**Ellie Rofe | 01:50**
No, it's been good. It's been an interesting week with a bit of financial catastrophe as I come back from France, so I'm pushing to make some cash flow, which is interesting. I'm in the Upwork world and trying to push for all sorts of different work whilst still trying to get that bigger engagement going on. I've been working through...
I've been giving Claude research an absolute hammering this week because I have been working on figures for a pitch deck and trying to work out how to effectively do that for a prescient company. Because the woman who had been building that had used ChatGPT in an unnerving effect and had created like such wild statistics. I can't tell you.
So I've been hammering the hell out of Claude research and trying to refine that. In the process, I've been refining a process by which to research on Claude using projects. One of the most frustrating things I find about Claude at the moment is that you very quickly hit this...
By the way, this conversation's run out of memory and there's no recourse at that point. So, building this iterative thing there. Yes. So it's been a bit of a scramble for cash and a slower, very deep work with this client, including trying to work out analogies for some very deep science.
So I've been existing on two quite different planes of brain work, I guess. Hi, Deatrice.

**Demitris | 03:45**
Hey, guys.

**Ray | 03:46**
Welcome back. We're doing the quick round the horn. What kind of week has it been for you?

**Demitris | 03:55**
A very interesting one. I started with a call conversation with Miss Van Dusen about the digital twins and how we're going to build knowledge graphs. We're going to focus the conversation mostly about the business impact and solutions we can build for the business, unless it goes into the tech part. Of course, we're going to have tech references, but it's at the moment an open call. I'm very happy for that. I don't have... We don't have that much engagement so far.
Does it matter? We push on that. Today I had an interesting experience exploring the Microsoft tools about the automations, the Power Automate and all of these things. Here are the worst tools, I think, in the market. They're too painful to build stuff.
Honestly, they have strict grid rules. I started building a demo for a client who asked me to create a demo, and according to Claude, that list said, "Okay, in your plan because you're on the free trial." No matter if you're gonna pay, you cannot do this, XYZ actions in the API.
So I'm planning to invite the client to the demo and we will see if it can work on his end into his account. If it works, that's fine. If it doesn't work, I keep the letterons and move on.

**Ray | 05:46**
Okay, cool. Alright, and then Robert, we turn to user... What is true today that was not true a week ago.

**Robert | 06:01**
So true today is not true a week ago. I would say, well, I have a person who subscribed to the Snappy tool officially and paying for it. Actually, it's as soon as I just put a wall up and I said that you can't use this.
I just went to sleep and put up a wall. So, if you want to use this... I didn't actually... You could still use it for free. It's just that I made it slightly more inconvenient, just a little bit. I didn't even expect it.
If he had messaged me, I probably would have just told him how to just keep using it for free. But he actually just went and found a way to sign up. Because I just threw it up there and it didn't actually turn him into unlocking certain things for him.
Like the rest, it just lets you pay. It doesn't actually unlock anything for you. So then that was great motivation to do the following steps, right? Because now there was actually a person to do it for.
So that's what I did, and I was like, "Okay, cool, let me just fix this for you." I think then... So there was that, and then there was with the client Summer.
But with her, I feel like over the last week, I came to AI... I don't know. I thought about how I was feeling and what it was really like, what it really means to even try to provide a service like this to somebody and where it is. What does it mean? Where are the wins? What is it that you're actually trying to move through?
I felt that this was the most critical stage of the engagement in some ways. Something like that towards some level, at some stage, it gets a little tough. If you just have to power through, you can turn something that seems to be like, "This is not working." This is not working into, "This is working, and it's not that far away from working, and it is working now." It just allows you to break through.
But you just have... I think I've just been off the horse for so long that I had a bit of a splash of cold water in my face where I was like, "They're unhappy. I'm taking it a bit personally and so on."
Then I just thought about it. I'm like, "You know what? There's actually a really big opportunity here to come through and then just really make it work, go through the hard part, the ugly part at the end." That's what I did. I dedicated a couple of hours yesterday. Nothing crazy. I just sat down and I just massaged out certain things, and I feel that it's just better for the business, or I just felt like more of a professional, I suppose.
Over the weekend, for example, I felt the confidence to send her an invoice for the hours that we had over the week after. During that week, there was a bit of friction between us where she said... I had put up my hand and basically said, "Hey, how about more hours?"
Then that didn't... There was friction between us, and then I think for me, where I leveled up a little bit was actually to just say, "Okay, here's the next invoice."
Okay, fine. You had that discussion. We did work. Here's the invoice for the work we did. It was fine. I got past that boogeyman in my head a little bit. Or if I send this next one, is she going to say it again in my face?
But then I have to acknowledge that I was part of the reason why there was friction. The first time, when I did... The second time, I handled it differently. She saw that she understood what she was paying for. She was the one volunteering to make it easy to pay for that.
So that was a nice feeling to feel like we can have a good client relationship and we can make something out of this. With that same client, I tried to basically just leave a prophet in whatever it is.
If she asked me to show up, which she did. Like she wanted me to look into a problem, and that's what she's paying for my time on the phone. I took it as an opportunity to leave a profit to go and say, "Okay, I'm going to really figure this out for you and just..."
Really make it so that this is like the time that you spent with me. I investigated this for you and I drew a circle around the problem so accurately and so clearly that it's going to make the next stages for fixing it super easy.
It'll benefit everybody else on the team as well when they see the clarity behind the research and the testing and everything that I did and I'll be able to communicate it in a clear way and so on, deliver it to the team.
So, I guess, yeah, there was all of that. I just made the Snappy tool itself better. So, right now I'm just getting hammered in all directions. Honestly, my messages are getting blown up from people who are either using the tool, but then
there's always something that's not going perfectly for each person, so yeah, I'm just... But I'm trying to just move things more towards the cash register, just going to check and trying to make a game out of that.
Maybe that's what I'll say at the end. I feel that sometimes I just have Stripe open and just to look at Stripe, look at the numbers and to say, "Okay, what if this was my game of just sitting here and going, 'He paid for this.'
I have my subscription going up, and I can see that it's like I'm leveling up a bit here. This is fun if I can just gamify it in some type of way or something along those lines. So, yeah, anything to get out of my own way, basically.

**Ray | 13:07**
Well, today is your hot seat, Robert. How can we be putting this time to work that will help you have a better week? That is making the cash register. And helps keep you out of your own way.

**Robert | 13:23**
I think, I was thinking about this, and I think I feel like I was listening. I was listening to Jim Roan a lot, and he was saying that if you want to feel... If you're stuck or you're feeling not great about something, which is not that I'm not feeling not great, but sometimes I just don't know how to ask for... I don't know how to ask necessarily for aid to make me feel better, but rather, I think what makes me feel better is making other people feel better.
Because then it'll be like if some... If you're not... Because everything is already in you. If somebody else asks you for advice, you'd be amazed by the stuff that comes out of you. Then 'cause it's already there.
So I almost want to ask, what I feel like I want to turn it around a little bit and ask about how the... Is there like... What does everybody think? In a way, is there a way to the game of making money online? Is there a way to enjoy the chase a little bit?
I know maybe that's not the door knob question yet. Maybe I'm getting there, but I'm almost looking... Have you ever felt a time when it was really easy and it was just really effortless and that this could be easy instead of it being hard?
And is there a way to identify that? If that makes sense? When it comes to making money.

**Ray | 15:17**
How to get to the point where it's feeling easy and feeling fun and not feeling like.

**Robert | 15:22**
Yeah, exactly, like. And I think I'm kind of... I got a glimpse of it at times, but I... It's like a cat. I can't chase the cat. I have to wait till the cat comes to me, and if I chase, the cat just runs around the room.
I almost feel that if I... But I don't know, I... So I'm almost wondering. Yeah, if that's... How do you let your ambition serve you rather than you serving your ambition and just always putting yourself through this rather than it taking you to where you want to be? If that makes sense.

**Ray | 16:09**
I think we'll probably do a little bit of development on the question as well as we go along here. With your permission, let me start with Demetrius. Demetrius, could we get your thoughts on this question?
We start with gamification. We had to... Yes, where you felt that economic flow, right? How you can and what's worked for you. I appreciate that sometimes we don't feel that, but when have you felt that?
What does feel like that for you and what do you associate with.

**Demitris | 16:44**
So the question is, when is the time or what is the point that makes the money flow? Just to clarify.

**Ray | 16:56**
Let's explain one.

**Robert | 16:58**
Yeah, I would say probably in the past, I think maybe because it's a thing that's happened, and then you can, in a sense of... Okay, so we know it's happened. But I'm open to ideas. I believe in me. I wish I knew. I'm so... It's very un... I'm still figuring out this part at the very edge of how I feel and what I'm thinking.
So, it's a bit hard for me to put it into words, but something along the lines of trying to draw a line between the times when you were making money and it was something that you had leverage on, it was feeling good, and you were enjoying the process of it.
I'm trying to see if there's anything there that I can take away and connect into as I look at my opportunities and I try to see what type of business I'm trying to grow and what type of practice I'm trying to develop and understand
myself. What would that look like? Like, what does that look like? To just get up every day and be like, "This is amazing. This is fun. It's a game. It's like picking up any new game, and I'm having fun and making money.

**Demitris | 18:22**
And my perspective, the process is never enjoyable because it doesn't sell the payment back upfront. If you know that doing all of this stuff, at the end of the day, you can go to a cash register and take your money, the expected money from your seat you gave during the day, automatically, the same process would be enjoyable for you.
But the thing is that the payment comes back to us quite after the seed period. The seed period is like the farming business we sow at the beginning of the season, and we pay back after a couple of weeks or months. This is a nice understanding for me, taking out too much stress from my brain during the summer where I realized that people who started texting to me were people from activities I used to do before. I was posting into communities, and people found my personal communities and they came back to me from there.
So it was the seed three or four months ago that paid me back today. So back in that time, definitely, it wasn't enjoyable because I felt like, "Okay, I have my resources, and I just get out with my gun and stop shooting out."
But this is not shooting. It was sitting. So I would say, let's go one step back and think about it a little bit differently. What we are doing should be enjoyable, no matter if it pays back the same day, no matter if it's paid back in the end of the week or three months later. What we're doing with all of this approach, videos, conversations, new stuff. What? The brilliant stuff with Ele. With this Claude conversation. All of these are not for paying back immediately.
It's like using it as a way as a channel to flow outside the seed and attract people just to express our interests that can be interesting for other people and join us. And this is how we say that. So let's take out how much time it will pay us back. The thing is, do you enjoy what you're doing during the day, even if you're doing video editing? Of course, video editing, going, editing...
It's not the most enjoyable stuff. We are people who want to see the progress, check things off our checklist. This is done, and so on. Translate it with actual results like if I do 12,345, I will get X box.
If I do this, I will take that. Yes, this is about the marketing. The marketing AC... Correct me if I'm wrong, is the multiplier. Is this 10% of our value? We put it to the business, but it works like a multiplier.
If we don't put it, we don't have anything, but it's needed to put it, no matter how we count the values back. A nice sign that you enjoy what you're doing is that you are making huge progress from where you started.
If we go back in February, you start learning about MCP in one and a half months, you created the snappy MCP server in one month later, you started creating tools for that. One month later, you had greater improvements.
So you... I know it's quite hard to record the video and show it. Yes, but this is the way to communicate the video staff. Why don't you turn on the camera while you're working? Record yourselves when you are doing that, even when you are at them and why this doesn't work at them and this AI just broke... Only in my packages like that, even that at the end... If you fit the transcript into a... You can ask him for questions. Now, coming back to the initial question, when and what... When is it something we shouldn't care that much about because maybe it's quite far in the future, but what is exactly what we're doing, what we're doing, and we're making progress.
Weekly, we put something new, right? So this is what I think. I think it sounds quite generic and quite philosophical. [Laughter] I'm sorry for that.

**Ray | 23:49**
It's all about how you think about the stuff. So I think that that's helpful. Both the specifics and the general ideas that you were talking about. Could we bring Ali into this conversation?

**Ellie Rofe | 24:00**
Yes, you can bring Ali. That's still trying to even process ideas about it, but there are a few different angles I've been thinking of, some of which have been prompted by Demetrius, Robert, and some of which I'm trying to figure out.
I think in terms of enjoying making money and it being fun, I have been part of various entrepreneurial groups. Copywriting is a fantastic one to be involved in for this and ads and things like that. There are people who, I think temperamentally, just love making money, and they are so focused on it that they find an absolute joy in turning, like getting that ding.
It's not quite Wolf of Wall Street, but not far away. So, they will devote their entire time to tweaking the copy on a sales page or working on an upsell or finding a new mechanism to rinse an extra bit of lifetime value out of each customer.
That's huge levels of gamification. They literally just are looking at all these numbers and all these percentages in their funnels and all that kind of thing, going, "This is how I make money, and I love it."
I'm just going to constantly keep working at nudging all those margins, profits, and percentages upwards. I think Ray has often referred to us as intellectuals, service providers, people for whom it is important to make money.
But it might not be the driving instinct. I think in those cases, gamification might be more along the lines of what Demetrius is talking about in terms of understanding what really drives you beyond just the making money.
I wonder whether part of what's so joyful about those clicks is... And, Ray, I'm stealing this from you because you were talking to me about it yesterday, but the idea of compounding, a flywheel, or whatever metaphor you want to use... You have done so much hard work pushing that flywheel into motion, and you literally just pop up a paywall, and someone paid you.
So it's that feeling of the flywheel starting to turn that's exciting because... And it's not just because there's a bit of money in your account. I think maybe it's a validation of the work you've put in that you've done so much hard yards behind that screen on your own, and someone goes, "Yes, I'll pay for that straight away."
So that is a really nice gamification thing in terms of you're witnessing your work. I don't know how gamified that is, actually, but you're witnessing your work turn into something. In terms of it being easy or joyful on a constant level, I don't know. The most money I've ever made was mostly free freelancing. I was between $10,000 and $20,000 a month.
That money was lovely, but some of it got wasted because I just had so little time to myself that I was just spending it on takeaways or ordering things because I didn't have time to do stuff myself. Whatever.
There's a phrase I love. It sounds pessimistic, but I quite like it because it's actually a bit like that. That's interesting framing. It's saying that there never isn't a challenge, which is a new level, a new devil.
So I think every time you get to the "All right, I've achieved." Okay, that brings its own challenges, devilish challenges, joyful problems to solve. Who knows? So that's kind of... I think those temperamental approaches, understanding...
Maybe it never gets easy, but maybe that's part of the joy, maybe a philosophical thing, and just understanding that you have pushed the flywheel into motion, and that's an incredible thing to have done.
So the momentum that you can create from there will make it faster and easier.

**Robert | 28:20**
I appreciate that. Right? Right.

**Ray | 28:25**
Yeah. The thing is, what I found is that game vacation isn't really a thing. The question is, where do you find the joy in it? I think going and looking, what is it about this that you are enjoying?
I think you're going to find that you're like, "Hey, this little thing, this is kind of fun. This is kind of addictive, right? Getting the notifications off of Stripe." I totally recommend setting up a Stripe, setting up something to be gained notifications whenever people are paying you through Stripe. I get that from a change.
I gotta say, it's actually kind of nice for even these memberships or whatever the monthly is, being able to see these things come through along with people's names. "Hey, this person just re-appt." Sure, I know it was automatic.
I know it wasn't them making this decision. It's a little bit of money, it's a little bit of free market validation. I was thinking about this, in the study cellship kind of way, right? What kinds of validation do you get from each of these things?
Where's the joy coming from each of them? The joy of discovering new things you didn't see before, which is the way alloted with you would gain joy out of, like the Snappy and the MCP stuff.
Right, when you were working on it earlier this year, there's the... I think we talk about cell... There's the question of applause from others, right? The idea that people are saying, "Hey, this is cool."
They're paying attention to you, and you're getting that kind of external emotional reward out of it, right? Where people say, "Hey, there's something here. We would love to be able to visit with you. We want to listen to you. We want...
And what they're giving you is the gift of something else that's scarce, reaching their attention. Then third comes shipping, which is the ability, which is the assignment that you are having an impact on them through getting paid.
This is where having those checks come in is basic. This gets to, I think, your point. It's not about money for its own sake. It's money as a validator, right? That what you've been doing has worth. Chris, we were talking about Jim before, and I think one of Jim's disciples is named Kris Weiner. Chris Weiner is very into things like network marketing and Avon, whatever.
Leaving that issue weird and slipping the side. He does tell this story about Roan about doing seven or something and saying, "We did good work," right? That being an indicator to him that this is her being the high side, right?
Having had an impact or what have you, and that the money is really an indication that you are having an impact on it, giving you that kind of validation. I think for each of these things, being able to have an impact for which we are paid, having something that is worth talking about, which gets reflected in intention and knowing things, right, that you're finding intellectually satisfying, I find those to be where the wins you're getting on each of those dimensions become pretty helpful to me.
I think you've found that it's not about getting one giant check, it's about, particularly early on, just having more of the small ones can be quite satisfying, right? Hey, that came through. That makes
you feel better as a result of that. What's going on with that? That's not about getting super wealthy, right? That's not like the high-end femina stuff or I don't mean to presume that the people we're talking about were hiring femina people, but
that's not like making millions and millions of dollars, right? It's just validation. It's from outside talk about internal versus external motivation, right? Internal motivation is obviously better, right, because it's more sustainable.
But that doesn't mean there's no value from the external. Then, when we talk about gamification, what we're really talking about is how do we get those signals of external market validation that can then be feeding them to buff us up a little bit.
I don't think there's anything wrong with that, and in fact, I think the great temptation is to say that when we're not getting that from the market, that there's something wrong with the market, as opposed to something that we should just be adjusting and tuning ourselves a bit better to the market.
I think what we're all discovering is we're using our radar here to figure out, "Okay, what does the market really want?" How is that aligned with what I care about? This is the hedgehog principle, right? The Jim Collinsing, right? This is what do you care about that's important, right? What's the market will to pay for that's important?
That's the thing we're talking about right now. Then, what can be world-class at that, and that alignment of those three things is where it all really sings. The thing is, you all care about multiple things. You're
talented people. You can do multiple things, and then how does that align with the market? Robert, I think what you're getting at here is that when the money is coming in, if you're not doing something totally weird and artificial, sometimes you do things that are weird and artificial, but that's not the case for you right now. The reason why it's singing for you right now is that this is something you care about.
You know, this is something you're good at, and the market is validating at the same time, and you're getting the endorphins of, "Yes, I have that alignment." This is a Mark and Andreson talk about product-market fit.
We've all heard the term before, but I don't know if you know Andreson's definition of it, which is when you feel it's obvious when you have it, and you're wondering what it's like until you do.
That's what I think is a useful way of looking at it if you have that feeling, great, let's latch on to that. That means you've got those in line, among those three things, and that doesn't last forever. You start caring about different things, right? Or you no longer have a competitive advantage on that particular thing. Someone else has figured it out, or the market has moved away from it. I can't tell you how many of the.

**Ellie Rofe | 41:12**
H I think I put this... This is training, I guess, which I'm struggling to step out within the immediate term. I put this into vision and purpose, right? Because that's the brand strategy world that I live in.
I think one of the interesting things and this is a useful conversation for me, all of these are, is how much your steps should be pushing you towards the vision you have or being driven by the purpose you have.
So, the vision is if I keep doing my work and get as successful as I'd like to be. How will the world look different if once I've done it, what will be the positive changes that happen because of your work in the world and your "Why do I do this?" "Why do I care?"
I think that's one of the interesting questions. How often do you link back to that, and how often do you just stay pragmatic? For me, my purpose is I really like being effective, I like helping people, and when I'm in terms of the pitch deck work I'm doing with...
I think one of the reasons biotech is easier for me than some of the SaaS stuff is because they really are doing stuff that genuinely saves lives or makes things absolutely incredible. When you're doing pitch decks with someone who's got a kid with retinoblastoma, which is the type of eye cancer, and the stuff they're working on might help that kid, then it's...
It's very like it. It helps drive you along. You're like, "Okay, I'm a small cog in this wheel, but if I can help these people get money, they might be able to create a difference for people." So that ties into my values. As you've said, Robert, I like to help other people.
That's much more inspiring to me than just acquiring wealth for myself, for example, or just beating other people in a game of wealth or whatever it might be. So I think tapping into your values and how that drives the "why" of what you do and what you hope would be different.
I struggle a bit more with vision sometimes because I get lost in just trying to get stuff done or the day-to-day of things that are irritating me or things that are difficult or things that are just distracting me or whatever.
But that's how I think about those things if that makes sense.

**Ray | 47:30**
Tech stuff was looking like, right? What was the old demand for was the new demand for? What are people looking for now in the market, and part of it involves us listening to the market and then retooling so that what you're giving them is what they're looking for. Just another slight example. Robert, you and I were talking a little bit about my characterization of this thing that you're doing with Summer Delaney right over at CLAU.
Yeah. And summers reach out to me. So I have a little bit of a picture of what's going on there, most of which is shared, Robert, of course, but the her situation is one that I think exists more in the market, which is it's a company on fire. They have grown, they have been successful, they have stuff that is not quite working anymore, right?
They had stuff that they built when they were pretty successful that is now like, "Wait, we need to look at this again." Because you put something in complicated, you got to maintain it.
They didn't maintain it, which we all do, right? Now, what does that look like? And wait, there's demand in the market for that because this is something we're going in, making the client money as opposed to building a new greenfield application, which can be seen as easier, fun, what have you, but much more disconnected for money. I and you know, I should be a little more sympathetic to that because it's a good reason that people show up at State Change is because something's on fire, right?
They have some sort of problem. I can't figure out how to solve this problem, right? They come in, they do that, the question is what is it that the market's really looking for there, right?
I think you've caught a little bit of that, right? There's a little bit of that when you're going in with summer. You've seen both where the needs are, but the pressure that comes with actually serving a real need as opposed to having a nice conversation with someone who's not really going to move forward. No, in the things going on with that, there's the... In this MCP stuff right now, you're putting some money. You've spent some time learning and figuring out where the demand is. I have had some conversations trying to align to get it more towards where we think the market needs it to be right.
It's not coming from internal ideas of this would be a wonderful thing based on scientific principles. It's based on what the market seems to have out there and seems to lack right. Putting strength against weakness, and
I think there's a big opportunity for you on that front. What is hard out there that you can provide, right? That you get joy out of, and then it is amazing that when you hit the fit, it shows itself.
I think right now you're seeing that, and we're all very glad that you're seeing that. I think there's a little bit of a lesson here that I'm taking away from this week of how we can all loosen up our ideas of what we are supposed to be, right, in order to mesh with the market and what it needs.
Yeah, not to say that you let go of your principles or anything, right? It's about that intersection, which of the principles and which of the things that you can be world-class at and link up with that market demand.
So I think when that hits, it hits really well. I tend to find that people of talent... It's really about picking which of those things are useful, right? Then reaching out and then connecting that with the market.
It can be hard. Certainly has been hard for me. I really appreciate it if you guys have thoughts about how to do it better more systematically to find that connection, right?
So that the market has a chance to say, "Yeah, this part, I love that." Then they're able to do that, and then you're able to get those little things of your Stripe payments coming through or of the payments from invoices coming through or whatever.

**Robert | 51:41**
Yeah. And I think that even just to say that, even for me, it seems not obvious that... I suppose when I look at the... Whatever seems to be a fit... It feels like it's a fit, but I'm not... It feels like maybe just the experience. Would I...?
You know, you get enough experience that you start to be a bit skeptical. You're like, "I hope I'm not deluding myself that it's a fit, and it's like..." Then you think maybe this would only be a fit for five people, really be a fit for ten people, and then that's one type of fit, and then wondering, "Yeah, will it be a fit for a hundred people? Will it be a fit for two hundred people?"
I guess that remains to be seen. Maybe that's the salesmanship part or just maybe just based on how well I communicated, which maybe just joined that. But I think that, yeah, overall, I selfishly, maybe I want it to be fun. I suppose it's always one of my North stars. I always like to try to make it fun.
I think that it sometimes means that I make my own life harder in pursuit of that, but whatever I do end up working on will just get my whole heart into it. Maybe the MCP is benefiting from that, I suppose, but...
Yeah, I guess that, as you're saying, it's hard sometimes to know who I'm supposed to be doing it for. It's difficult to know that in real time. I'm taking it from cues of what other people are saying, "Hey, that's good. You did a good job at this. You're an expert."
I'll pay you to... I'll call you an expert rather than before I even call myself an expert. I'm like, "These people are calling me an expert, and that means I must be good at this." So maybe that's just being aware. No.
But yeah, just saying that I think that touches on probably my doorknob question, something where my doorknob question is what you're saying, Ray. Which is just figuring out what I'm supposed to be or what I'm supposed to be doing and how that aligns with making money and seeing if there's a click of joy when all those things connect.
Because that seems to me the only way to do this, sustainably, and something that's... Yes, there's... Because it requires a lot of energy to keep up and doing this every day. So I better enjoy it.
I think I better make it a priority to build something that I enjoy. Otherwise, I'm going to build a very elaborate prison for myself.

**Ray | 54:44**
I think that's right. I think there's this trope out there for so-called "build in public," which I don't think super well of because I don't think most people care about the details of the technical parts of where you're building. They do care about themselves and how you're going to serve them.
One of the reasons I talk about the cell being important is the intellectual cell, share your ideas, right? People do care about the ideas part. But I think the other aspect is where's your market?
Where and how much are you responding to right or at least in sync with the market? You it's possibly fellow travelers, but you're not actually responding to the market, but you're actually in line with them.
But you've got to be going the same way. It's like the old joke about the French Revolution. You got to find out where they're going so you can leave them there. The thing. I think the thing about the MCP stuff that you're doing right now is that MCP's not something that came deep from what you were working on.
When we first met, right? Of course, the standard didn't even exist back then, right? You got into it because you felt this incipient market demand. You made the Snappy thing based on seeing a connection with the market, right?
More in springtime, and you got some attention for it, and then you built on that attention for it, throwing a pound of spark there. You thought of anything. There's a lesson of waiting. This was a 150-day course that really could have been 60.
Yeah, right. And how you might be able to do that for next time. I think that would be a useful thing to think about a little bit. But the reason bringing up MCP as a market is that you have a set of talents, right? None of those talents is defined as MCP, right?
But you were able to focus your talents through that lens in a way that the market cared about. I think for all of us, there's a lesson of that lensing effect. Where is it that people are saying, "I've got this problem, and the only cure is MCP"? What is your... The old SNL joke, right? I've got
a fever, and the only cure is MCP. What is your... Then, how is that linked to your talents that you didn't want to cross-apply into? I think there's a lesson here. This spring, you and we all had this conversation six months ago. You didn't know what MCP was, right? Or maybe we just fairly talked about it or something, right?
But we're not really talking about it until I.

**Robert | 57:27**
I definitely had no idea, but... Yeah.

**Ray | 57:32**
But these discoveries can then lead to turning into significant practice in a not-too-long period of time. Yeah, there's stuff we need to do to put food on our table. Food on our table today.
But it's not like we need to do years of homework in order to get there. I think there are pathways or weeks. Particularly when we're in a market that is moving as fast as one is right now, it's exhausting to do it, to be sure.
But there's juice in there, and when I think about your question, I think that's where it is. It's like, "How well are you synced with the market.

**Robert | 58:13**
Right?

**Ray | 58:14**
And is the thing that's really giving you that joy, and the metrics of and the measures of that synchronicity are, "Hey, you're gaining these little checks, you're getting attention, you're getting written this, you're seeing the number 23 everywhere."
Yeah, that's a really good thing because then it keeps you out of your shell, right? You're then connecting with the market because it's a positive thing to be connecting with the market, and then you're not doing it alone.
So that's why that's what I'm thinking about, like the building and having you talking about building a prison. I think that's when you are connected with the market and you're connected with your peers. You're able to keep it something that's creating ever-greater value, and that's the opportunity you have.
I think when you're getting those positive feedback notes, that's what they're telling you. You're doing that successfully.

**Robert | 59:09**
Yeah, I really actually thank you for that. I think that actually really hit. Hits the nail on the head about especially just taking my interest in something and then being able to focus it on something and but then reducing the timeline for how long it actually takes from okay idea like conception of idea and in 60 days. Can I have can you know, like those amusements parks that like those are those theme parks where they'll just show they'll show up in town and they'll just set up in like a day and in a parking lot somewhere.
And then. And then they'll just start making money on the next in two days, I suppose. Trying to set it up quick, like a Carney or something. And having the... And maybe there's... Being able to then sell and then to enjoy the space of that and before it expires, enjoy being a little bit ahead of everybody else, establishing just being a month or two ahead of everyone else.
It's in a space that... In the right space at the right time and having the right people to talk to in order to just even know what to focus on. Yeah, no, I'll take that for sure. That just gives me plenty to think about.

**Ray | 01:00:36**
Cool. You three are the right people for me to be talking about, and this is the right time to be doing it, and we will do this again next week. Thank you.

**Robert | 01:00:46**
That's good. Thanks, Guy. I appreciate it. Thank you. Bye.

