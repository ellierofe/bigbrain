# State Change Mastermind - Oct, 14

# Transcript
**Ray | 00:04**
Hello, Demetris.

**Ellie Rofe | 00:09**
Hello. How are we?

**Ray | 00:13**
Very well.

**Ellie Rofe | 00:14**
Okay.

**Ray | 00:14**
Right, and I was just thinking about Demetris's backdrop where he's got the new bookshelves put up, he's got the books behind him. I think it's a good look.

**Ellie Rofe | 00:23**
Nice.

**Demitris | 00:25**
Thanks guys. I have to enrich it with some more stuff. But I'll come this week, might.

**Ellie Rofe | 00:34**
Doesn against blaming you. You've managed to. To put the books. You know. Where there's spare space.

**Demitris | 00:41**
Yeah, [Laughter].

**Ellie Rofe | 00:44**
But.

**Ray | 00:46**
That is fantastic. Now, before we dig into it here, Demetris and I were having a little bit of a DM previously, and you were asking just a fantastic question. It's very timely for you because you've got an engagement that's coming up.
So I was wondering whether we could do our "around the horn", even though it is about two weeks, do it a little bit more quickly and maybe do a little bit of a mini hot seat if that would be okay to work on. Demetris's question because I think there's wisdom from around the table that could be had on this, and maybe it can just be a seeding of the conversation that comes after that, and then step into it more fully for you. Alie, I appreciate this has some impact on your access to clock.
So, and.

**Ellie Rofe | 01:32**
Don't worry. Not bothered at all.

**Ray | 01:37**
Okay, well, then let's quickly take thirty seconds or sixty seconds and think about what is true today that was not true when we all met as a group two weeks ago. And, Robert, can we start with you, sir?

**Robert | 01:48**
For sure. Interesting. So what's true today is not true a week ago. I would say that overall, I am working on trying to expand my horizons with working on some of the self-related to the OpenAI Dev Day and trying to...
I've set up more systems for myself in general to just be more... to cover my weaknesses essentially, and that both of those things go very deep into the efforts that I've put into them.
But in the spirit of keeping it quick, I would just say that it's just been a good exercise in trying to build out more of those systems around me that will just make me more reliable to my clients and to partners.
So that feels good, and I'm just overall making Snappy better. I have more... I think I have another client since in the last week that I've received. So I have four customers now for Snappy and, like officially, like paying on a recurring basis.
I'm just trying to send out more invoices, basically, and just to get more people interested in it. I'm just trying to beat that drum of trying to sell these things. And yeah, so mostly as well as changing last week.

**Ray | 03:39**
Super, and Detris, can we check in with you? I appreciate we got the thing coming up with you just second here, but like, just we're broadly looking at the week. What is true for you today that's not true for you when we met two weeks ago.

**Demitris | 03:56**
What is true today? The truth is that I found some specific resources. I mean the IBMS channel on YouTube, I'm investigating more on core services. I want to investigate digital twins, knowledge graphs, and how to improve it. I actually... What is true, most of the things are about studying new things and learning.
And I'm excited for that because it's inspiring. I started doing my recordings more fluently. Found a way to record the video. We've tried to make it with a transcript before, so I read the text.
Well, I'm recording, so I know from previously what I say. Recording stopped.

**Ray | 04:50**
Recording in progress.

**Demitris | 04:52**
And, yeah, I mean, the paths where I try to create content and start posting the most I can.

**Ray | 05:06**
Okay, cool. I appreciate you guys. Sort of blipped out there for a second. And Lisa, we just checked with you, ma'am. What is true in your practice today was not true this time two weeks ago.

**Ellie Rofe | 05:18**
Yes. I've done quite a lot of shipping. Not for a huge amount of money, sadly, but I have done quite a lot of shipping, which has revived it. I mean, obviously, the study ship cell model works.
It's revived a lot of the study side of things for me. It's gonna be lots of ideas for sell, and the focus for where we get to my hot seat is around a kind of research analysis. And that will feed to sales and posting and all sorts of other stuff.
So it's feeling good from a point where I was still not loaded. I'm still not rolling around in cash. Like Scrooge with ducks, but I am. I'm just feeling more positive about the direction ahead.
And I can't wait to talk to you a bit later about that. I'm more interested in Demetrius's question.

**Ray | 06:11**
Yep, right now, Demetrius, with your permission, you were... When you and I were talking about this, I suggested maybe doing this here. And you were very thoughtful about not wanting to intrude on Lisa's time.
But at the same time, we were looking for Lisa's counsel. So I thought that should be a great opportunity. Put the brain against the problem. Maybe you could share just a little bit about your situation, and then we can be opening up to the group and seeing how we can be of maximum service and helping with your question about the quoting.

**Demitris | 06:41**
Yeah, thanks, guys. And thanks, Ellie, for the opportunity to discuss today. The request came yesterday night from a referral guy and it is about scraping data from the Spotify platform, which is available only for the artists, right?
We want to take the count of streams for every specific song in specific playlists, because artists can make money on Spotify by creating playlists, not only by creating songs. This company manages multiple playlists and they get paid for that.
So they want to track this number so they have an artist account which is counted as a business account. This information is not available on the API. Five years ago, the same request came from the company that yesterday gave this referral and we had the same project back in that time. There wasn't this expansion of AI so we couldn't do that. My knowledge was not that good.
So I asked another guy who is a friend of mine, a programmer but whose knowledge is limited in these kinds of things. It's not that flexible and we lost the project because we couldn't deliver it. We started it, failed. We paid only 50% which was just for our pain and we just canceled it yesterday. The GA request is right. We have again the same limitations, but the tools are available, are more, and the team is open to a semi-manual, semi-automated solution like a Chrome extension and so on. This is what I'm thinking to do. What is the challenge? The challenge is that I cannot guarantee them the working time and the final result. Let's say that in ten hours I will bring you this solution and it is going to work for X number of months, right?
Because we talk about a tricky thing. We have to build a scraper. And my question is, how can we quote this to a client saying.

**Ray | 09:16**
Look.

**Demitris | 09:17**
I have to work, you have to pay me because I don't want to do it for free, right? But I don't know if it's going to work. I don't know when it's going to be done, and I don't know if it's going to be available for you.
So what I'm thinking is, how can I communicate the split of the risk?

**Ray | 09:43**
Okay, Ellie. The first name he had dropped when asking about this question was yours. Could we start with you?

**Ellie Rofe | 09:49**
Yeah, I don't know, but I can try. I think clearly conveying that it is because you're dependent on systems that you can't control to finalize this project. I would make it clear that you can't promise,
but within your scope, if I would be tempted, I don't know anyone else thinks about this. I'd be tempted to do a good, better, best type approach. You'd be the best case scenario in this kind of space of time if you're willing to put yourself up to something and just have check-ins along the way to see if they're happy with the progress made.
It is difficult because it's so speculative, but I'd be trying to say these are the stages of the project as I see them initially as we go through because this is exploratory, we might have to adjust this. So, we'll have check-ins.
I think this is the minimum price that's going to take. This is the ceiling we'll put on it before we say this isn't feasible. That just seems like a collaborative, honest approach, but I don't know.

**Demitris | 11:18**
Yeah, it makes sense to me. Put in the minimum effort, so get the minimum price, and if we get it done, we pay the rest. The follow-up question is that, let's say that I will not invest the rest of the week. I'm going to invest a maximum of ten hours in that.
All right? So, the fifth hour is going to be 50% of the time because they will ask me for the price. And the purpose of this question is how to calculate this minimum effort price. So I'm thinking maximum working hours ten for the investigation.
So on the half, I will know what's going on, ideally in five hours. Should I, at my rate on these hours, should I add a specific price? What do you think?

**Ellie Rofe | 12:25**
What's the value of this tube? What do they need? It form.

**Demitris | 12:30**
Good point. There is no service offering these numbers. There are many businesses who do exactly the same thing and all the other platforms that say that, they offer that.
I think they require an artist account to be authorized and get the data. So from my investigation for the first step, I found a couple of platforms to suggest them so we can have a look, review them. If this works, fine.
But the previous client said that these platforms are not accurate.

**Ellie Rofe | 13:10**
Right.

**Demitris | 13:11**
So it has a big advantage and the guy is thinking to resell the service to other guys because he knows if we achieve it, he can do it.

**Ellie Rofe | 13:23**
Okay. Is there anything in... I mean, whether this matters or not is very much up to you and the client. But is there anything in the terms of use for Spotify that blocks you from this kind of scraping?

**Demitris | 13:37**
Yeah, Spotify is like Facebook, very strict on the ways you can access them. Because we have to build either a bot that will log in with a proxy server like a bot that logs in and takes the data and finds the right AU and so on, which this is what we tried five years ago and failed, or alternatively use a browser extension like Bardine or ZATi to somehow automate it. They accept if it has semi-modular jobs here.

**Ellie Rofe | 14:20**
Yup, yeah. So God, what was the name of the one I saw at no-code low-code? I could find it for you, but there are things that you can set up with structure to do agentic scraping and things. I guess a side question is if this is against Spotify's terms, how are they going to resell it on any meaningful basis?
But that's... Yeah, I don't know. I'd be questioning how much of a case study this would be for you, because I'm not sure that you want to be advertising that you're hacking platforms like that, although maybe you do. It depends.
Maybe you do. Maybe that's exactly what you want to be advertising. I don't know. But yeah, in terms of things I would... Is ten hours realistically enough in terms of the investigation? How fast can you move on that?
Because it feels like when things are exploratory... Even if you put ring-fencing around time and say, "I'm just going to do this for this long or whatever," there are certain problems that can suddenly become a two-hour problem.
So I don't know if that's enough time for you.

**Demitris | 15:41**
Yeah, because in terms of development, I have to test three tools: Zapier, Chrome extension.
If it works, I can invest one hour and 30 minutes on that. If it fails, it doesn't get me any closer to this thing, it's gone. The next one is Burden, which is more for that case. If it doesn't work, I have three hours and 30 minutes to work with a service like Bright Data.
It's a scraping service. If we achieve that, that's fine.

**Ellie Rofe | 16:26**
Okay. I am listening to you. I'm just looking for something as well.

**Demitris | 16:29**
Yeah, and you gave a real nice point: how much is it worth investing in something that is not a core service or the corporate.

**Ellie Rofe | 16:46**
Just look like they might have changed their value proposition now possibly with things changing. But that was the guys I met at No Code Low Code. In case they were advertising this as something where you could go and scrape data from LinkedIn and stuff. I don't know if they got in trouble or whether they just shifted it because there's a better market.
It might be worth looking at just as a side note. Yeah, I'd be tempted to say if you're happy with a certain amount of money as a base case and then a bonus, I guess, as
a backend success fee. So you have your... I'd be tempted to say it's ten hours at my base rate, and this is what my base rate is. If it's a success, then we package it up for you, and it's a bonus or something. I don't know that.
I mean, not framed like that, but that's what I'd be thinking in terms of the cost.

**Ray | 17:55**
Can bring Robert in the conversation.

**Ellie Rofe | 17:57**
He.

**Robert | 17:59**
For sure. I would just say that I don't know, solving these types of problems. I feel like they're always... There's unpredictability to it. Otherwise, they would just do it themselves because it's just like a cat and mouse game to try to outsmart the platform.
It's not something that I wouldn't commit to solving something like this within, let's say, I'm going to solve the whole problem within ten hours of time. I would maybe only commit to the first part of it, just at least seeking to understand the problem for them, do the thinking for them because that's what has to be done. I feel that what they're doing, that's what the first thing that has to be done is to figure out how this is going to be done.
Even that is something that we're trying to solve something that is difficult, right? Like it's like you're going up against Spotify systems, which are designed to stop this from being possible.
Otherwise, a lot of people would do it. So I think that, anyways, that's where most of the value is then as well, which is in just the thinking and the very beginning. Then, after the doing, once you know what needs to be done, it's going to be... If you know what you need to do, if you have the blueprint for it,
it's going to be more or less straightforward. I think the most valuable part is really what you're providing at the very beginning, which is even just saying how you're going to do this before you even write a single line of code, right?
You... It makes a difference between saving yourself months of time versus potentially, if a person knew what they were doing and had the right strategy, it would take... It could take hours of time, right?
What's that worth to them? If the problem is... If the upside of getting it solved is whatever that represents to them, but either way, the quality of the investigation part, I think, just makes such a big difference downstream of how the rest of the experience goes. Maybe just something to be set for that: what are you selling here then?
If that's the most valuable part of it, and it makes a difference of months of time versus days of time, just in the way you choose to approach it. Maybe that's what you're selling.
It's not the whole thing, but you're selling just to get the answer to that question.

**Ray | 20:43**
Yeah, I think.

**Demitris | 20:44**
I'm sorry.

**Ray | 20:46**
I was just gonna say... You mean the guy who's tried this and failed before means you've got some experience with this, right? So you say, "Hey, look, I tried this before. This did not end well when we tried this a couple of years ago. State-of-the-art technology is newer. I'm using some other cool stuff. We can look into this, but more importantly, you can probably say I have put another 60 minutes into it, right?"
So I think there's a question of, like, "What are you?" One of your questions is, "How do you charge for it?" What have you? I think there are different levels of risk, right? What are you willing to do on spec?
I think the answer is probably more than zero. You don't because you actually don't want them to even hire you for a couple of hours if you think it's likely it's just going to fail, right? You being associated with a loss doesn't help you at all, right? Even if they pay you for it, it didn't lead to the kind of referral business.
So I kind of suspect that there are 60 minutes in here that you could spend to get a much better sense of what's going on here. When I think about how to spend the 60 minutes, I think about using MCP stuff, like the kind of marvelous work you've done so far with using the graph database stuff right there. There's Puppeteer MCP, right? There's Playwright MCP stuff out there. This puts you in a position that rather than figuring out how to go configure something using Bardine and trying to build an app with Structure, you can zero in on the hard question: Can you scrape Spotify, or REST API, or artist screens? Can you automate a browser to do it in the stupidest way possible?
Right? So you're not trying to come up with something clever that's going to be super repeatable. But can it be done at all? If you had it on your desktop, could you just have it done through being able to kick it off through a chat?
If you could do that, I think there's a good chance that you can be making good progress on that question in an hour. That doesn't involve using BT, doesn't involve using late, no, it doesn't involve using SAP, it doesn't involve any of that stuff, right? It involves using things that are closest to you and that you have the easiest response rate with.
Because you're going to have your browser over here on the right, running the extension or whatever it is, it's Line and Playwright to go do its thing. Then you are chatting with it over on the left, using whatever tool you prefer that has some local aspect to it. I was actually just... I did a demo, something along these lines in State Change Office Hours yesterday, and I was blowing minds with how quickly it could get done, using work for that, right? This wasn't about me, though, and I'm just saying that the demonstration of doing it through chat can be very impressive in terms of how quickly things can come together.
That's not the same as having a repeatable thing that they can ship, but I don't think that's... You can significantly derisk, right, by saying, "Hey, look, I gave it an hour, and I think there's something here."
I think in two hours for you, we could get great... The point is Ellie's point. You get greater clarity, right? I think there's a good chance that we can be saying here's a demo of how something could look, and then maybe there's ten hours beyond that of how to be turning it into a repeatable system and owning that. Like, the wheels come off the wagon, right?
I think in two hours for you, we could get great... The point is Ellie's point. You get greater clarity, right? I think there's a good chance that we can be saying here's a demo of how something could look, and then maybe there's ten hours beyond that of how to be turning it into a repeatable system and owning that. Like, the wheels come off the wagon, right? But right now there's a big risk in it. And I think that big risk is not ten hours away from getting taken away. It's really the core of it that's risky. This gets to the thing about hacking Spotify, yeah, that's basically what we're talking about. Can you hack Spotify?
Because if you can, then everything else is just superstructure around that. So, I think this gives you now an idea of how to structure an engagement. A 60-minute you could do before you talk to them, two hours you could do after, and you'd only offer if you thought based on the first hour there's a good chance to produce something and the second two are to produce basically a minimum viable product, not even viable, right? A demonstration to show. Here's how it's working right now. You get to that point, you're talking about systemization for the next ten hours, or you don't get to that point and they pay you for two hours of your time. You part Friends.

**Demitris | 25:13**
So they pay for those, right? I'm sorry.

**Ellie Rofe | 25:15**
None no different.

**Demitris | 25:18**
So they pay for those two hours working on the MCP, right?

**Ray | 25:24**
That proposal, yes, and because you would give them the MCT, they could have that as an output. That would then be able to help them somewhat, assuming it works. Probably if it doesn't work, they're going to screw you.
But I would propose that probably, you just want to say that would be paid work. There's a first step that you want to do unpaid, like you're willing to take the leap right that you've done the leap of faith.
The leap of faith will limit to an hour. Then you're saying you're giving. Now you're leaping my way. That's the two hours. Then, if your hour and my two hours lead to good results for a three-hour investment at that point, then you're doing the rest, and you're having a much higher degree of confidence that this is going to be producing good results.

**Demitris | 26:10**
For be honest, guys, I didn't get exactly that how to structure this can we demonstrate that more?

**Ray | 26:25**
Sure. Alie did D does my. The structure I was laying out make any sense to you.

**Ellie Rofe | 26:31**
Yeah, what I was going to interject with at one point was that the second step is really going back to them. These are the words you could probably use because it makes it sound sexy and exciting, saying the next two hours. I spent an hour reacquainting myself with this problem because I tried to fix it a while ago, but things have changed.
I've worked out there are a couple of tools and bits of tech. Don't just say tools because that sounds like you're just using something they could use. Say there are some new coding paradigms or whatever words you want to put around it that sound complex and opaque. That I've discovered. I can spend the next two hours investigating them and seeing if I can hack Spotify for you. Then it sounds sexy, it sounds exciting.
So you do an hour upfront, just working out. As Ray was saying, what the tools are then you say, "I've spent an hour reacquainting myself with the problem." Just Grattis, because I tried to do this before and it wasn't possible.
I think it might be possible. Pay me for the next two hours. I'll see if I can have Spotify for you, and if I can get results for you, we can try and turn it into a system.

**Demitris | 27:37**
And if I don't get any results, you just lost two hours of consulting.

**Ellie Rofe | 27:42**
Yeah? Yeah, not even lost. Just say. You know. That's. That's basically the.

**Robert | 27:48**
It learned if it learned as well during that time, right?

**Ellie Rofe | 27:49**
Yeah.

**Robert | 27:51**
Like going to be a byproduct. Even if I can't see it as moving backwards on the problem, I think... I mean, if it was really... I think there are obviously many ways to look at it. I would just think that spending that time, you'd make some type of progress towards it.
And if maybe that's just another... You would be able to get something out of it rather than understanding that it's not doable and not spending the three months doing it then and so on. That's a pro.
But in a lot of ways, right? You just saved a lot of money and didn't explore this thing. Right? Or in doing the thing?

**Ellie Rofe | 28:32**
Unlike other consultants who would just waste 20-30-40 hours of your time just hacking away at this. We're going to set it up like thist.

**Demitris | 28:46**
Do they want to know about the solution? I'm thinking as an experiencer because usually they are quite busy. They don't want to know more about the tech thing. And I feel it. If I invite them, they will feel okay spending two hours of our work.
So they lost two hours of internal hours and the payment.

**Ray | 29:20**
That's the risk.

**Ellie Rofe | 29:21**
They're not willing. I mean, if they're not willing to speculate two hours of your time on a product that they could resell, then they don't seem particularly serious as a speculator to investigate.

**Demitris | 29:31**
Good point.

**Ray | 29:33**
Yeah, I think yeah, that is such a key point. And seriousness is about, like, willingness for them to... One, there's two dimensions to it. I would propose that 1. How important is this for their business, right? How do they see themselves making money at it? Is this a cool case where they're willing to invest it very low, right? Or is it? This is super strategic. Really want to make this go.
They're hiring you to give it the best swing they can. The access and this really matters is where they are on the tech front. You know, some clients, especially very small clients, are like, "I'm a very busy person. I'm doing all my sales. I'm hiring a lackey to go do these buildings for me." Great, you will go take care of that stuff over there, right?
I'll pay you a couple bucks, but... They don't really value the work. They don't want to do it themselves. They don't want to be engaged with it. This is work I don't really like to be involved in because it usually gets priced down and has a lower likelihood of success because of the lack of engagement with the principal.
Right, with a client. But it will tell you that if your feeling is like, "Well, we're agent people, and we don't deal with this tech stuff, and we're hiring someone else to do this tech stuff."
Why are you bothering us with this? It's going to be two hours of my time. Okay, that's telling you that they're not the kind of people who are looking to take risks. They should be using tech
that is very well established, and there's no confusing this with tech that is very well established. This is all hacky new stuff. If they want to do hacky new stuff because they can see a whole lot of money and they have that kind of risk profile, boom. There's money to be made and a wonderful relationship to be had.
But selling risk to someone who's risk-averse and frankly, selling safety to someone who wants risk is a mismatch. I don't know the client's rights, but everything we're talking about here is basically how to share risk with them.
You're not eliminating the risk. This is a high-risk engagement. If they're in for that, here's what you know. We've been talking about a way to stage it, manage it, and sell it. If they're not in for a high-risk engagement, neither you nor they should be wasting their time.

**Ellie Rofe | 31:50**
HI don't know. The pure details of what their revenues are, their profits, and how much they'd be spending on you for this...
If they're saying, "I could get this system up and running and sell it to people for $10,000 a year," and they're not willing to spend a grand on investigation or something, then that seems to me like they're not matching the level of the potential reward with the potential risk they're willing to outlay, especially as they are asking you to hack one of the biggest platforms in the world.
It's not some janky little thing that you can just probably try and get something to have a look at. It's a huge platform that has probably its own desire to monetize or protect this data. So, you know that you need to frame it to them that this isn't just some piddling little thing. You are giving them a very quick turnaround on the feasibility of something.
That's quite a complex problem.

**Demitris | 32:53**
How can I test the solution? It can be a worthy 60-minute section even if it fails? Because in scraping, they have to share email and password on the mC CPA stuff, right? So, I don't have their own. I can create a demo account for me, create a playlist there, upload some songs, and start using it.
That's fair, but the question is, how can I guarantee that this can be a 60-minute valuable engagement even if it has a loss?

**Ray | 33:40**
I use a timer on my phone. Sorry, I use the timer on my phone. Yeah, and set it for 60 minutes.

**Demitris | 33:52**
Yeah, how can I be viable? 60 minutes for them, I say.

**Ellie Rofe | 33:57**
I think you'll put too much pressure on yourself, Demetrius, to turn up with something amazing.

**Ray | 33:58**
For.

**Ellie Rofe | 34:02**
Value after an hour, the value of your exploration and further understanding and then getting closer to understanding whether this is a feasible product line or not. You don't get a solution in that time. You don't get a full solution in two hours.
But it's basically a feasibility study.

**Demitris | 34:30**
So it's going to be mostly R&D for them.

**Ray | 34:34**
Absolutely. The whole thing is R&D. You're developing something that doesn't exist. The endgame of all this is developing something that doesn't exist. That's a definition of development.

**Demitris | 34:48**
Good point.

**Ray | 34:50**
And might just say, I think Ellie's point about the standard here. My joke about the one-hour thing was that you limit yourself to an hour because then you've made progress. You raise your head after an hour, and after an hour, you know more than you did before.
You either have a belief that this could be a good engagement, or you don't have that belief, and you can't prove a negative. That's why we talk about the hour thing. That's why it's not ten hours.
After an hour, you're forcing yourself to stop and say, "Okay, well, based on that hour, do I think I can make meaningful progress?" If the answer is, "Well, I didn't make meaningful progress in that hour," I don't really know what's going on, then that implies it's a trap.
That's what I say, and I say it can't prove the negative of not being able to move fast, but you can use the reasonable investment to say, "Look, I don't think I was stupid for trying it at the last hour. I didn't get there. Let's rewind and say that to them."
Hey, tell them that. I tried it several years ago, and I actually gave it another hour just now. The absence of their API plus the difficulty of using these tools means I think it's not impossible, but I think it would be expensive.
So, if you're interested in having a high-risk, expensive engagement conversation, we can totally do that. But I want you to... You know what that is. Going in. The last thing I want to do is take your money when it's not the engagement you want to do.

**Demitris | 36:24**
Very good point here. I think to hours consulting. Even with the team involved, it's worth it because they can learn something they didn't know from previously.

**Ray | 36:37**
So thank you for the one hour of you working on scraping. Using MCP could be super high value for you and just create more greater learning returns for you.

**Demitris | 36:49**
Or it's gonna be for sure. Yeah, the thing is how it can be valuable, how they can count it as a viable thing to pay for that.

**Ray | 37:01**
Yes. Well, let's keep in mind that 1h is study, the two hours are ship, right? So the hour... It's just the one hour might eventually turn into you being able to get the engagement, but as you try to learn so that you can gain comments on whether or not you think you should be proposing the two hours to the client.

**Ellie Rofe | 37:20**
So I've just realized the clients want to be on the call with you for the two hours.

**Demitris | 37:27**
Maybe they can say something like that. But I expect they will accept it to work together.

**Ellie Rofe | 37:35**
Because I have... If it's an exploratory thing, I know you normally do working with live with people and teaching them what's going on, but if it's exploratory, I just wouldn't have them on the call.
But I think it'll slow you down massively.

**Demitris | 37:49**
Yeah, another thing, a little bit technical one, they have to share the credentials on the chart of the AI for the MCP access.

**Ellie Rofe | 37:52**
So you're not wasting any of their time. Their time, and they're not wasting your time asking questions when you need to be working more intuitively and instinctively, thinking and moving fast.
Then, if they want to work through it hand in hand with you later, as per your normal MMO, then great.

**Demitris | 38:30**
Right.

**Ray | 38:32**
Probably this is part of what you need to determine in the first hour, but yes, I would expect so.

**Demitris | 38:38**
Yeah. So, I don't know if they will accept that thing. Maybe because there's the rule for not sharing credentials on the chat, hey.

**Ray | 38:53**
We saying, "Hey, don't share will find out what they actually require. Very well. We don't want AI to know the credentials. Okay, well, then that's the data point. I don't know, and it depends how you up the MMO, whatever.
But I get what you're saying with that, but I'm now... They can't always mark... There's a checkbox you can turn on, so all the chats turn into, please don't save them into whatever.
But I'm not... If that turns out to be a blocker for them, okay, well, then it's a non-starter. I'm not sure if I do that to keep you from doing the hour. I think the hour actually has a lot of leverage for you.
But I would keep it to an hour, and then you can be telling them on the two-hour thing what you think will be necessary. If their answer is, "Well, we didn't really care about this project. We thought maybe we'd be able to go sell some other people for fifty cents each."
Really, if you could charge us only ten cents, we'd be willing to do it. You're like, "What have we been talking about here?" There are all sorts of things you can learn as a result of that.
But I do think that taking the first hour is a good look. You are limiting your exposure on that is good business. You are doing it particularly focusing on the issue of scraping and the hard part, the hacking. Spotify, as Ellie puts it, is I think the highest value place for you to concentrate your attention.

**Demitris | 40:34**
And last question in case the MTP thing fails, is it worth it to try No-Code or other solutions?

**Ray | 40:48**
Maybe you'll know more at that point. The reason I like the MCP approach is because it's so fast to iterate, right? It had a much higher probability of getting things done in an hour or two hours. The problem with all these no-code things is that they are easy to do at the expense of time, so that can make it easy for them to own, but not fast for you to develop.
So the way you derisk this is by moving it forward on the timeline, and then it's going to be the productionization of it that you want to be moving more into something that has an own ability characteristic.

**Demitris | 41:29**
Super important point, this thing. Yeah.

**Ray | 41:37**
This doesn't need to be the last word on the conversation, but I would like to... Ellie, Robert, if Demetrius were to be reaching out to you on this question for helping progress on this, that'd be awesome. With that in mind, and to Demetrius, you feel like you're okay to have all conversations, then let's turn our attention to Ellie.
And Ellie, you've been very generous today. We're all very grateful for it. It's been two weeks. [Laughter] I'm grateful to all of you for accommodating me last week.

**Ellie Rofe | 42:12**
Yes.

**Ray | 42:17**
Last week was just an awful week for me. I got bit by a dog, and I got the whole illness thing going with that. How can we be of service to you?

**Ellie Rofe | 42:30**
Are you feeling any better? By the way? You seem a bit brighter than Friday.

**Ray | 42:35**
I am so much better. Even Friday heading into Saturday was the first day I started to feel halfway normal. Sunday I felt normal. Monday, Tuesday. The yes of the came much better.

**Ellie Rofe | 42:46**
Brilliant. Good to hear. Right, so a brief window, I realized I spoke with Roy about this on Friday. I've realized that there's been all sorts of research type projects.
I've been thinking about researching wider trend data in the market, researching and interviewing VCs and stuff. And actually, there's a research project that ties in with the pitch deck analysis tool, and that is absolutely directly involved in what I do, which is to research and do a survey on loads of pitch decks themselves.
So, things that have things that are in the public domain initially and then ask people to send them to me. There are two parts to it, and partly I think I'm blending them. What I really want is what I described, which is your kind of understanding of data structure, data analysis, anything like that as any ideas that pop into your head as I describe it.
I'll show you a quick example of what I'm trying to do in a minute. There is the quantitative or broad scope research project where I'm looking at trends and patterns across pitch decks. These are
all hard tech, by the way, rather than SaaS and things like that. So, they're all stuff that requires some kind of R&D investment. They tend to have longer development lines and some sort of capital.
It's slightly more capital-intensive generally, and whilst a lot of them are aided by AI, they're not AI-only. I want to stay away from that side of things. So, there's the research trend thing where I would look at broad data across the range of decks I look at and say, right. These.
You know, series A tends to have this pattern of getting funded. The visuals of this matter or the visuals of this don't... Or whatever. There's going to be a lot of stuff that I could potentially find out because there's how long is a piece of string with a pitch deck.
Then the other side of it is how this becomes a lead generation, even if it's paid lead generation type tool, something that I can eventually turn into an analysis tool that spits out a bit like I've got already, but more refined and based more on statistical analysis as well. That spits out a recommendation for people for their first pitch deck.
Maybe there's even tiers of that where one of them is free and then they get the more investigative version of it with me for a week for two grand or something and et cetera. So I have thrown together something in Notion initially.
It's surprisingly difficult to find pitch decks that are actually pitched and not just a heavily redacted or completely made up version of a pitch deck that someone's put together because they're trying to sell something.
So I've just hacked this together in Notion where I will add a pitch deck to this pitch deck database and I'll capture some key metadata on it, basically like which round it was or what the vertical is.
So these are different hard tech verticals and how much was raised when it was raised. This is going to be really important because funding markets and the funding landscape shift and change over time.
So I want to be able to analyze what is or isn't getting funded at different times or how, anyway, times, lead investors, investor type. This is just metadata I'm trying to think of that might be useful. This is like a roll-up of the slides, which I'll show you in a minute.
So this is the quick overview. I've realized that these two things should actually be in the reviews database. But we'll get there. And this is... I've moved it, so I'm just going to delete that.
Then there is the slides database. So what I've done here is used Claude, and I get Claude to rip through the PDF and spit out some JSON that then gets pushed into Ocean via the MCP for both the initial pitch deck entry and then the basics of this analysis. Then I go through slide by slide and add my notes.
At the moment, I think one of the questions I have is how best to turn qualitative stuff into something really, super valuable on a meta level or something that all these notes and things that I add here, how do I actually make them useful?
So at the moment, I'm just going through and adding notes on each slide. I'm looking at each slide. I'm starting to add design notes as well, so that there's a concept of the content and the concept of the design, and they're slightly separate things because I think it's important to start to talk about design a bit more. You can see the slide type, which is a basic version of the color coding structure thing I had before. A little summary of what the slides are on a word count to start looking at word count density. Any key metrics or proof they've added to each slide because I talk a lot, and I want to keep talking more publicly. I talk a lot with clients about proof and evidence of the things that you are.

**Ray | 48:25**
Recording stopped.

**Ellie Rofe | 48:26**
Has Ray disappeared?
Yeah.

**Demitris | 48:29**
Yeah.

**Ellie Rofe | 48:30**
Okay. Whether it's clear or not. Because sometimes people have stuff that's actually less clear than more clear. Then these are... So that's the slides each slide, and then this is a deck-level review of it.
So this one, the opening style is a product. It just shows you the product. The first problem slide is like slide three, et cetera. In fact, this one is an interesting one because it's got a summary that shows all of these things.
Then this... I need to add the options, but this is which sections in that structure thing aren't in there at the moment. I think this probably needs to... Or it could just be a formula roll-up type thing.
Maybe I'll have a look at how that might work in Notion then. I am giving them scores across different commercial, like investment readiness values here. That's the total score, but they've each got a different weighting depending on what series it is.
So, by series B, the commercial stuff is more important than the scientific stuff generally. So, this is like the weighted investment thing, which is 88%, and then just some again, like handwritten stuff about improving visual storytelling.
Then there's a design score. I think I need to refine this a bit. This is something AI spat out, and I haven't thought about it in depth, but there's a design score, which is again, an average of these figures.
Then the other thing I want to try and work out and attach this to slides and Deex is what patterns I see in them. So, I'll be adding to this as I go. But, are there too many jargon in it? Is there proof early and proof often? Positive and negative patterns, and then again, attaching those to individual slides where necessary.
There might be different slide patterns, and attaching them to the review so I can see by deck which patterns were there. So, that's where I've got to so far with it. I just opened it up for the last few minutes on any immediate ideas that pop into your head about how I can improve this or make it easier on myself or anything else.

**Ray | 51:04**
All right, you just me calling me first.

**Demitris | 51:07**
Yeah, and I find it so impressive. It's fantastic how you structure the logic for reviewing the documents, even having the design review the content, the points, all the things that matter. Without being a specialist, I understand that I saw what was important since the core question is how you can convert it to a product. I'm thinking, how could this be used to create some piece of value upfront for the founders who are looking for the tech?
Maybe it could be a product that can be used before they meet you somehow or run with you the workflow. When they are on the call sharing information, you get the data and you guide them and explain them. I find that these are reports.
Still remember the experience of uploading my CCA V after my graduate. I could find the errors were good enough, but what was useful is how to fix my errors. I have this trouble with my website and I'm going to send you an email for that and need your help. The thing is, it's quite easy to find what it doesn't work from one perspective, but it's difficult for me to understand how to fix what does work.

**Ellie Rofe | 52:58**
Yes? Yeah.

**Demitris | 53:01**
So I feel one piece of these things would be helpful to them. Or this can be a follow-up, but with a couple of suggestions.

**Ellie Rofe | 53:16**
Yeah. So, and I think that's what I had thought of in the report like a priority fixes, like here's what you need to fix and how.

**Demitris | 53:25**
And is the most important? If you have a presentation on Friday, it is Wednesday. Do 123 instead of 567.

**Ellie Rofe | 53:35**
That's nice. I like that because that's real-world presentation in two days, do this, yeah, nice.

**Ray | 53:47**
Robert. Y your way in, sir.

**Robert | 53:53**
What is the. I think that I just need to understand maybe a bit more about where you're trying to head with it. Then it would be because it's already somewhere, and I think, what is it that... Because that's the only part that's maybe not clear to me, like what is it?

**Ellie Rofe | 54:05**
He yeah.

**Robert | 54:12**
Where are you trying to take it next?
Right? Because I see something here that works in front of me.

**Ellie Rofe | 54:18**
So this is in my head. This is called the product of the Pitch Observatory.
People will eventually be able to submit decks for an automated review or submit decks that can get pulled into this system initially. I want to try and get people to give me their decks so that I can add data to the system. I found about 25 decks in line that I can validate your actual decks that have been presented for money.
So it's hard to get big numbers to be able to get meaningful statistics across ranges and things like that. I would like this. If you're talking about two, three years out, the Pitch Observatory is a useful repository that I can potentially monetize or become like a unique piece of expertise and value that I have a data asset basically.
The understanding from this and the methodology I use as I'm analyzing Pitchdeck goes to develop the pitch analysis tool. That is a tool that is specifically... Someone gives me their pitch, and we give them an analysis.
This is how you fix it for their pitch now as it stands for funding. So that becomes more of a service level offer. There's an analysis, research data asset, and then the service level offer. Does that make any clearer?

**Robert | 55:47**
So yeah, I think well, it sounds like it is something then that's very tied into the it's not like, earliest for the time being at least, the it's very tied into the service that you deliver as well.
Like it's part of being on, you know, the rest of the experience, which I think is a good way anyways for it to develop. It doesn't necessarily have to stand on its own individually out there in the world. It's supported by your existing services, which give it, I think, a bit of room to breathe.
But I noticed that when you mentioned it, you were talking about two years out. I was thinking more like two weeks up. What is you.

**Ellie Rofe | 56:28**
Yes.

**Robert | 56:28**
What is the what is your you know.

**Ellie Rofe | 56:30**
So that's the piece I missed talking about the cell part. So, there's the study part, obviously, but then this is the goal. The goal is to create a kind of an endless content mill with this stuff, finding existing patterns, analysis.
I think initially, I'll just put stuff on LinkedIn, but I see that there is a path where I have a YouTube channel where I do proper deconstructions of decks. I see a lot of deck teardowns. They're not very good. They're not very useful to people to understand because they just go, "Here's a few things as Deck did wrong."
So, do proper deconstructions or whatever, and create a YouTube channel. There's a possibility of it being Substack or whatever eventually, but I think initially, I'll do it on LinkedIn. I might do a bit on X because that's where a huge amount of hard tech and frontier tech people types are.
So, it's a combination of study and sell and a little bit of ship involved as well because I can use some of these. I use the pitch analysis tool I've got in Claude at the moment to check if there's anything I've missed when I'm reworking a deck.
So, it hits all parts of the business. Sorry, I've read the paper.

**Robert | 57:45**
And maybe that's something that I'm wondering is just... What would make this something that's just irreplaceable for you, maybe to start as the first person who's... Because you're the first customer of it, and you are the...
That just works for me, even as I've tried to find my own North Star for when I'm trying to develop stuff, like the more I'm trying to solve my own problem and that. And there's...
Yeah. So I'm wondering, like, where does this reach... point for you? Or is it already there?

**Ellie Rofe | 58:17**
It's getting there, but it's not quite... It's really useful. There's a theory when you're writing, they're like, "Just copy the Old Man in the Sea or copy scripts of a Rice you love and you imbue the skills and the things like that."
I'm not quite doing that, but I am looking and seeing different people who've created different decks, and I'm learning different things from them, and I'm seeing what I definitely wouldn't do and stuff. So there is a huge amount of value to it for me now.
I think as I build, I think I need to layer some sort of analysis that is automated on top of this as well as my own because AI is better at analyzing patterns than me. So I think that's possibly the next step, to get it working in terms of the manual stuff, then work out what I can automate, and then work out the level on top of that, not just what I can automate, but where I can extract extra value that me doing it manually won't reach.

**Robert | 59:04**
6ii think just to say that if I were doing this, my intention was to... The reason I'm doing it is because I'm more or less open to the benefits, however they might come in, that they might be in the form of raising reputation or, for example, and so on.
I think the only thing I would perhaps do differently is just maybe just apply it towards something that's timely. For example, the OpenAI dev release from last week, they have apps, which is timely like that.
That is in itself a very hot topic. Is there a way that this could be an OpenAI app? And I don't think actually would be because it already has a lot of the financial stuff. It sounds like they've reinvented anything.
It's already the MCP is there. There's already things that are pretty well fleshed out. I'm thinking that there is a two hours of effort that would all of a sudden take this, put it into somewhere that is in a different paradigm where you're getting when you're posting about this, you're not just posting about it. You're posting about basically the same thing, but you're posting about it in a way that now it speaks to people on a few different other levels.
It's like, "Well, okay. Does it open?" Yes. And I can use it through here, and it's more accessible to them. It's quicker for them to be able to use it. So that's where my mind goes when it comes to this.
I just mentioned that because I think that there's perhaps a one... There are a couple of hours of work in between here and there to get something that's up there and working possibly.

**Ellie Rofe | 01:00:57**
Okay, I haven't actually looked at apps yet there, but I will have a look. Thank you.

**Robert | 01:01:02**
By the way, with that, I'd be more happy if we could always schedule a call and be my pleasure.

**Ellie Rofe | 01:01:09**
This is really helpful, guys. Thank you.

**Ray | 01:01:12**
Super. I appreciate we are past time. Thank you all for going past the hour. We'll do this again next week. I'll talk to you all at the end of the week. Take care. Bye.

