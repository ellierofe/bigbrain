# State Change Mastermind - Dec, 16

# Transcript
**Ray | 00:04**
Hello, Ellie. I don't want to be like a direction to the band.

**Ellie Rofe | 00:07**
Hello, one.

**Ray | 00:14**
Hello, Alice. Thank you. Alice, I think... Okay, all right.

**Ellie Rofe | 00:20**
I like the stark contrast between my festive background and Demetris in this kind of very [Laughter] lexed Rigeman style.

**Ray | 00:31**
[Laughter].

**Ellie Rofe | 00:32**
Or maybe... Vampiric? I'm not sure. [Laughter].

**dimitris@3nuggets.io | 00:34**
Recording in progress.

**Ray | 00:38**
He's meeting us from the void, live from the void. That's actually what the inside of a knowledge graph looks like, so it's all... Yeah, [Laughter].

**Ellie Rofe | 00:49**
[Laughter].

**Robert | 00:56**
I think that could be a funny picture. You could get out of that with a nano banana. If you take a picture of yourself, it's like to put me in the void, like the of the knowledge graph. Just looking somewhere.

**Ray | 01:09**
I'm. I'm actually sort of imagining, like, Demetris as the man holding the. The marionette control.

**Robert | 01:16**
Right? I yeah.

**Ray | 01:17**
I think the marionette control and all the strings coming down into a knowledge graph, but let's go around the horn here. We just can't start with you, sir. What do you know today? Did not know a week ago.

**dimitris@3nuggets.io | 01:40**
Well, it's not about the knowledge. I had an incredible experience meeting in the meetup I ran last Friday. It was incredible in terms of sharing knowledge from the teams in the people in the group, and it was very nice from the fact that very well-experienced professionals joined this session sharing a little bit about their background.
A few hours before this session, I met another guy who runs a business that they developed software creating digital twins for production lines and actual elements, which is very interesting and I want to learn more about it.
I asked already for demo access on his platform. And for this week, I'm putting all my effort into my personal branding work. I work with Ellie very hard. I had a nice exercise for today to work on, which is really interesting. After realizing who your target audience is, it's totally different. Creating the content and talking to this person right before adding those two things close to each other. Everything looks random anymore. This is my core learning from this week, putting from one side the persona and from the other side a way to communicate something valuable to them.

**Robert | 03:29**
That's it.

**Ray | 03:30**
Typical. And if I might just say, like I thought that was the meet up that I got to be quiet for listening to people who are far more expert than I in the area of knowledge graphs shows how like they're definitely, you know, a lot of sell opportunity with the meet ups.
But then, you know, all of a sudden, kind of nowhere. Like an amazing opportunity to just learn from a bunch of smart people who are learning from each other. And the way that you were facilitating that meeting, right? You didn't have to be the guru. You were just, like, calling on people and bringing them into the conversation.
And like when they were, you know, when there was a little friction, like you're sort of maximizing the value from it. I thought that wonderful because it showed you as a convener of knowledge, which is a really place for you to be as professional.
So awesome, man. It was a real privilege to get see you work with that.

**dimitris@3nuggets.io | 04:23**
Appreciate it. Thank you. Great.

**Ray | 04:25**
Cool. Ellie, what do you do today that you do not know? We could go...

**Ellie Rofe | 04:31**
Well, I really enjoyed working with Demetrius and nailing down that person that he's talking to and finding ways to connect with them and stuff. That was really interesting.
I've started working with a client, Maddy, at Lumia. So the advanced materials startup on a deferred basis again, but it's really interesting and it's fascinating work in the...

**Ray | 04:53**
Yes, two.

**Ellie Rofe | 05:05**
She's had two different decks done, and neither of those decks reflects her company and what she's actually doing. They've all just made stuff up, pulled stuff out of thin air to sound good, and then investors are getting into the data room and going, "No, this is real."
So, I had a really interesting conversation with her today. It's a challenge, but I think it's actually unlike some of the previous ones. I think it's one that actually can be overcome. There's a story there that is eminently fundable and imminently fundable if she actually tries to convey what she's doing rather than what she thinks people might want to think she's doing, even though she's not doing it.
So that's really good. I went back to a habit that I first had ages ago with Charlotte. Then, through personal circumstances, she stopped turning up to some of the sessions and I fell away from it.
But I have gone onto up work and hired someone so that every day at 08:00 am, I have a fifteen-minute call with this lovely woman in Poland who just listens to me talk about what I'm going to do that day and what I did the day before.
I'll be as brief as I can say it, but I had a really interesting test with Mark, what's his name? The subtle art of not giving a fuck. Mark Manson. Yes, I tested his purpose AI and it was actually really interesting.
When it came to "When did you last feel like you achieved something?" One of the things I put in was working on events and this guy who's asked me to work on an event with him, and I realized I'm really good at needing external accountability, structure, and a promise to get things actually achieved and over the line.
Then I really thrive on it. So I've set myself a task, which I haven't told you about yet, Ray. Basically, if I am telling her what I'm going to do every day, and if I don't meet 80% of those things across the week, then I have to give 30 pounds to a charity I don't like.
I will be accountable in my sessions on a Friday to you, Ray, about whether I've done it or not. But obviously, she's documenting that.

**Ray | 07:28**
Okay.

**Ellie Rofe | 07:31**
So I'm trying to work on all sorts of different levers to push me through to finish things because I think there are lots of things that are started and drifting and all that kind of thing.
So that feels really good. Momentum building.

**Ray | 07:48**
That's so cool. Yeah, sorry, the thing that's running through my brain is you talk about the accountability part, especially when they're capturing that and recording for you. My goodness. There's a weird AI opportunity there.

**Ellie Rofe | 08:02**
In terms of like s.

**Ray | 08:05**
Well, like, what's the experience of the accountability? Be someone who you can be downloading it to, right? Who's keeping track of this stuff, right? What does that fifteen minute session, you know, look like?
Right. And I'm sure there's an aspect of it, this like, you know, interacting with a person, right? But it's about the timed thing. And I'm remembering like there's something that something used to be Poper called Bere, which was I don't know if any of you remember this. It was a weird photo app.
And the idea behind the photo app was you would get notification. You had take a picture right then, right? You were working for the app. And it worked really well, right? It was a super viral thing where burned itself out because they weren't really making any money at it.
But like the, that was I thought that was a neat idea. Like, how do you incentivize people to want to work for the machine in a way that's going to be good for them? And what you're talking about made me think about how much is about the individual and how much is just about the session. Right?

**Ellie Rofe | 08:58**
Yeah, it's... I did think because each one's recorded, I can listen because I will learn about decision-making as well and thought patterns that influence how I'm planning and stuff like that.

**Ray | 09:12**
Yeah, I think super.

**Ellie Rofe | 09:13**
Yeah. She's very good. I said that sort of thing, and then she said, "So what are you going to do if you hit 80%? How are you going to reward yourself?" And I was like, "No idea." So, yeah, interesting.

**Ray | 09:31**
That's super cool. All right, well, thank you. Sure. Robert, what do you know today that you did not know a week ago? I think today is your hot seat, and we can get into it. How can we be a service to you as a group?

**Robert | 09:44**
Sure. What's true today wasn't true week ago. I have just. Things are, growing. I feel like in the right direction. I have like more demand probably than I did a week ago. I have more messages and so on, coming in and just I the conversations like even just with the existing people, like they sometimes people have suggestions and things like or business propositions and stuff like that, but, I'm, I look at those things as mostly just, distractions, I suppose.
Like I've been around for long enough to. You know. To know a distraction when I hear one. And it's so it's. But it's been going, and, you know, growing since last week relatively. And, I would just say that I've been, experimenting more with, like, with Opus clips and building different stuff all the time. I feel like that's a category in itself, which I, you know, I'm mostly focusing on like the external things like my interactions with people in terms of like what's changed.
But internally, like, there's a constant flow of things that I'm always working on, and I think that probably, drives a lot of the any innovation or that I can come up with because I'm always trying to experiment with something. I just don't know sometimes what the right thing to work on really is.
And that's that sucks because, it because that's like, where, that's where, like, my biggest differentiation comes from. I feel like from that incubation where I just come up. I try to come up with things and I try to make it and it has to.
And I use it to turn the wheel, the business. And the better I could fuck. The more I could make better things, the more I can be more effective with that than the more I can like that's my greatest power. I feel like in a lot of ways, is just that is making things.
And so that. So I try to take it seriously, and I try to. And especially, like, lately in the last week, I've just tried to. To do more things. Like to pick up something and then put it back down. But I just don't really know what the next product to make is in some ways.
So I'm kind of searching for that. And again, I don't take it lightly just because like I don't know, like a product, if it's the right idea or something, it can drive a lot of opportunities and provide like a long lived.
You know, you really live for a while and you're kind of. You might be stuck with that decision for a while to do. You know, in a certain way, it's like, you know, you kind of put yourself somewhere and then you have to. You might live with the decisions that you made a year ago.
So, maybe that actually gets to my pot seat baby question. I think where I'm maybe looking for. I think like some this is hard because I know it's always a loaded question to ask for a feedback on like, what to work on our products and stuff, but because but I but I'll presume that like, in this room that we can, you know, that we'll be, we'll tell each other straight what's going on.
So yeah, exactly. Safpace. But I'm trying to just. I guess so I suppose just pic. Sure. Figure out, like, what's the next thing to work on, and whether it's the right type of problem to solve. What's a good problem to solve?
Because I see something coming in the horizon where I want to be ready for it and I want to move on from Xano to a certain degree, but I'm just not sure how yet. Right? Like, it's like moving an iceberg is just like.
And I know I can do it, obviously, but it's. I'm trying to think of how to do it, like, in a smart way. Like, what is the sharpest way I can do it? What's the. And the thing with me is that II don't seem to have a shortage of ideas.
And that's a dangerous thing sometimes. Just because just I just I'll think of something out of this. This is a great idea. And then, you know, I could spend it easily, like three weeks building something nobody wants. Or I could spend three weeks building some. Sometimes I could spend two days building something people really love.
And usually it comes from conversation. It's like, very not very often. I have found that it comes from, like, just me ruminating about it. It usually comes from, like, external. Something external interacts with me and pops up the idea.
So that being said, I would like to ask what you think of, certain ideas that I have, I suppose, and then maybe if I would and then. But then after I'm trying to get to my doorknob. Question. I'm trying to fast forward through the conversation.
So then I go and I show you guys all that stuff and then. And after all of that, talking about it for half an hour saying, "You guys a bunch of random stuff with MCPS and everything," then my doorknob question becomes, basically, "What should I focus the meetup side and my marketing on?"
Maybe that actually becomes my question more. I'm skipping the presentation part because I'm just going to do is just show you different things I'm building. I'm building an AMC.
I'll try to make an MC platform something quick that lets you build MCP servers, which I think is cool. There's a whole thing behind it. I'd be happy to show you everything, but all it is just a way to... You're selecting the configuration for the MCP server, and it is showing you the files on the other side.
So it's actually showing you it's no-code because you're just typing in the stuff that you want. On the other side, it shows you that it's no-code because you're just typing in the stuff that you want. On the other side, it shows you that it's no-code because you're just typing in the stuff that you want. In the actual code, it shows you that here's what you're affecting in the actual code.
When you type in the description of the tool, this is the part of the code that is affecting... When you type in the name of the tool, this is the part of the code that is affecting in multiple areas like it will show you in that file builder like all the files that are affected. It's inspired actually by the stamp tool and how it's trying to be educational as well as useful to the dashboard part.
But I don't really... I mean, again, I did all of this as a marketing effort, right? All this stuff is our efforts for me to try to figure out what's the sharpest angle to move into the market with, or reposition perhaps just because I feel like I'm not doubling down on my... I feel like I'm not leveraging the per-dos principle where I think that I could be more effective if I focused in on that. Sharpest point.
I'm not really sure where it is. I'm not sure if it's in the MC. I'm not sure if it's in the MCP building or if I'm not sure if it's an agency building, if that makes sense. There's the MCP side where you build the actual MCPS and great, I'm talking about MCPS.
Then there's the other side where it's leveraging the MCPS as a person who is half robot and half human to actually build much more quickly and to make things happen. That wouldn't be part...
The tool makes it possible but I am half of that execution. So I am just trying to see... I don't know, I guess throw out some feelers out there and then... I suppose my question would be what do you think my sharpest point is? Maybe that's my question. Where do you think if you were me, what would be your marketing angle?

**Ray | 19:00**
Okay, well, use the M word. So I'm going to turn my to... So I'm going to ask Li to kick us off.

**Ellie Rofe | 19:05**
Okay, I'm going to be predictable. Your sharpest point will depend on who you are aiming it at. So...

**Robert | 19:16**
Okay, yes, Duma, I like that.

**Ellie Rofe | 19:16**
Who are you aiming at? At.

**Robert | 19:29**
I think well, people who have money, I think is a good... Probably the first quality whoever learning slowly.

**Ellie Rofe | 19:38**
Ye not. Ba.

**Robert | 19:48**
I think, yeah, people who have money.
Gosh, this is a hard question for me to answer. It makes me realize how much more of an engineer I am than a businessman because I'm just so much more focused on solving problems sometimes that the shell of the person...
They're just my experiment, and some people like...

**Ellie Rofe | 20:22**
This is the technology. VERS it's really common.

**Robert | 20:25**
Yeah, and some people, like, being experiments, those are my favorite customers. I guess what I'm aiming for, I mean really to put it in a... Again, I'm just aiming towards people who want to accelerate their development with AI, and they have the money to spend on it, and they have something an asset that already exists in the middle because I hate working on brand new projects. Now, I just don't... I just can't do it anymore.

**Ellie Rofe | 21:04**
YP.

**Robert | 21:05**
I don't think I can... I've just... I do that for myself, or I'll do it for a friend or something, but...
So somebody I trust, but not for someone who I just met randomly on the phone, and they want to talk to me about their crazy idea. So, yeah, I mean, it's... This is a difficult question to answer because I find maybe a lot of my proxy offerings apply to a lot of people, it would seem now and...
They come from different industries and they come from different experiences. Sometimes they have something that's already running, and then I can help them because I'm able to speak to those people.
Then sometimes somebody comes up, and then they don't know anything at all. I can help them because I can explain to that person as well. It seems to be only to my... A little bit to my detriment because it doesn't make me very clear on who is...
Well, I know who's better to help, but the problem is, I suppose I'm trying to figure out what message... How can I market? How can I put a message out there that will perhaps result in me just getting on the phone more with people who have an opportunity that I'm interested in?
I think maybe, so far from... Like when I go into those when I actually get those types of connections. Like they come from the unexpected. Like they come from me hopping into a community call and I just meet somebody and now he's a great business is there.
It's not something that I have enough control over. I almost feel it. It feels like just serendipitous that I might just be meet somebody and that like, you know, and sure, I can keep joining community calls and everything, but I maybe I think I just trying to realign myself on like what I'm looking for, I think and, which I think is your which is to your point, Ellie, about like what who is it? What is it? M yeah. I don't know.
It's a difficult thing to answer. Maybe because I don't think about it very much. I mostly think about the technology side.

**Ellie Rofe | 23:28**
Y so there's multiple facets here.

**Robert | 23:28**
So... I don't know. There's my answer.

**Ellie Rofe | 23:35**
Firstly, if you start marketing to one group or one target as it were, target is important because you have to direct something somewhere.
But it's actually more like trawling fishing in that you might set the net to the holes for a certain size or whatever for a specific fish, but other things come in with it. So you're really defining who you are speaking to now. Who you are speaking to doesn't mean that other people won't then go, "I'm really interested in talking to that person because I'm interested in what they're talking about."
So there's that side of it. There's the side which is, yes, people who earn money. But who do you really like working with? So you've mentioned that you don't want to work on brand-new blank slate projects.
That's the start. Are you talking about people who are fellow technologists, and you're helping them build their practice? As I said, it doesn't have to be either. Or if you look at Ray's business with state change hardest 5%. He attracts a mix of people who are building their own product and people who are tech technologists, developers who are helping other people build.
I think understanding who you're initially targeting is really helpful, at least when you're talking about marketing. Ray actually targeted the hardest 5%, which meant that he got people who were really serious who'd already built something. He filtered for people who'd already built something
because you don't get to the hardest 5% without going through the easiest 95%. That then attracted people who were serious, who were probably quite cerebral, who would work with Ray's way of going into depth and understanding and how he coaches people through these problems.

**Robert | 25:28**
Yeah, I don't know why I feel so foreign.

**Ellie Rofe | 25:28**
So there are multiple ways to filter, and it doesn't just have to be a job title, although it's helpful to understand roughly who you're trying to attract. It can be where they are in the process. It can be what problems people are coming up against time and time again that you can help them with, but you need to find some commonality in who you're trying to attract and talk to so that you can start talking to them.

**Robert | 26:02**
It feels so far away from the my. This is why I'm bringing it up, because it's something that is that I think it's kind of a dog that doesn't bark. In a lot of ways. I don't think about when I write something. I'm not thinking about really.
Like I'm most. I'm not sure if I'm. I'm not sure if it's a strength or weakness to communicate the way that I communicate online. I feel like it's AI feel like it's a strength in the sense of like that it's.
It's different, but I don't know what gez. I'm not sure whether to fall in line or to, like to do. No, falling in line is not good.

**Ray | 26:51**
How about we keep the wheel for you here, Robert, during the conversation course?

**Robert | 26:57**
Please. So, Dimitri.

**Ray | 27:03**
Sorry, Demetris, can we invite you conversation, sir?

**dimitris@3nuggets.io | 27:06**
Yeah, sure. I think I see three core questions from you, Robert. The first one is what is your actual target group? So then how we can communicate and bring them into... Because at the moment, I realize that you have people coming to your door, but I don't feel that you realize why they came and what drives them to your door.
From my perspective, I thought that you didn't translate the fact that they came to your door to the actual reason for getting them into your door. They may end because your brand is totally related to another brand, Xan, and they're looking for support for Xan, and you are highly related with this product. You are one of the most respected consultants in the NCP market. Close to Xan, which is good for your relationship.
But how they came, how they found you, all these kinds of questions. I think... Okay, start. It's the conversation about finding the right target group. It's not the easiest one, I guarantee for that case.
What is the core question you want to answer today? How do you build the next product and how are you going to move on your business or how are you going to build your marketing communicating with your target audience? Not the exact thing. Very close things in my mind.

**Robert | 29:15**
Yeah. To me, I've always associated the two with being very much the same thing in a lot of ways. That whatever it is that I'm building is my marketing and it is the tool I use in order to deliver the service and so on.
Just like that wheel. I think that's probably why it's so hard for me to. I suppose. It's tough. I'm trying to figure it out.

**Ellie Rofe | 29:55**
Tell me to suggest an alternative model if that feels too... There might be a way of leaning into your strengths a bit more and using that as your marketing. It is a bit more random.

**Robert | 29:55**
I don't know. Yeah, please. Of. Courses?

**Ellie Rofe | 30:11**
It's not the easiest way to create a specific pipeline, but it might be the way for you to market, which is just to experiment as much as possible, as fast as possible in public and just keep building what you think is the most interesting thing to build.

**Robert | 30:24**
No.

**Ellie Rofe | 30:28**
Then you essentially de facto end up creating an audience of people who are interested in what the edge cases or the forefront cases are in these technologies. So just keep testing, building. Along the way, you might then find people who say, "I've
connected here because I think this is really interesting, and I want to learn. But I now want you to help me build this, or I want you to build it for me because I can see that you can do it." But it does require a bit of momentum so that you can be pushing something out there more frequently.
There are obviously lots of people creating YouTube channels around this concept of AI in general, maybe in more specific realms, but that is one way where you are just building and doing interesting, unusual things that people can see there's potential.
As you're doing that, you're effectively testing the market and your audience. It is a little bit more peer to peer than peer to money, but it is a way of leaning into that love of building things and creating and testing.
But it would have to be a turnover, I think.

**Robert | 31:52**
Well, I like doing that, obviously, because I think right now that's my main marketing strategy. It is to pretty much talk about things that I find interesting.
I think that, well, maybe this actually gets to my... I think now I think I know my doorknob question, which is going to sound funny because I don't think it's gonna seem like it's not related at all to anything I just mentioned, but now I'm starting to. I just as you're saying like, you know, to do that type of marketing and everything.
And then I just realized, like, where is it? This probably is my biggest strength. That's probably just doing those marketing calls. Like doing the group calls and everything. I think that that's my. I can handle a conversation with a, you know, a gathering of people like I can do that and whatever.
And so I think what I want to do is be able to capture that better. I think. And so my doorknob question becomes, what is my microphone good? Is my. You know, like, actually, like, do I need a new microphone?
Because I can't hear it and it's kind of old, and it's going to sound like a maybe very simplistic question, but is it good? Do I need a new mike? Can. How can I record? All because and it this thing like that period of time is probably my if that's the best part of my marketing, which is there which is talking about random stuff.
And I'm going to take that and then, you know, distribute it out and I work backwards from there. That twenty percent, which I think does bring me 80%. I think I'm not capturing it properly. That's one thing.
And then which leads to not sharing it properly out there because it always just looks like ugly. I find like my quality, my video quality is like it seems to be low pixelated. It just annoys me even just looking at it.
So just speaking about it directly, I almost feel like that's a pebble in my shoe. That is, that if I could. I'm voicing it now, I think and just looking for. And again, it might not seem related, but I actually think that does work. Actually, all the way backwards into what I'm posting back on LinkedIn, which works backwards into my marketing and my message and then everything else and probably my core differentiator, which is just me, you know, just whatever, which is all of our differentiator, just the way we communicate, right?
Like that's going to be unique to each of us. So, yeah, again, sorry for switching questions. Quite a lot, but. But just kind of but going towards something that I feel is genuinely probably my weakest area and which is marketing.
I think that I'm. I think that in general, like, I'm not marketing my everything properly or as best as I could. I'd be more than happy for suggestions in that side. Like even technology. Maybe there's something that I'm not aware of, that would capture things better.
Maybe do something I'm, that I could do better, which is I ask, like, if you were in my shoes, like, what would you do? Maybe you would. Maybe you see something. And then you're just like. You know, forb we just Rob's got to change, I think and you know, or whatever, Rob's got to change. That banner on LinkedIn looks like CO, but Rob's got.
You know, if that ever popped up in your mind. Please. [Laughter] Through free time?

**Ellie Rofe | 35:35**
One thing I would do right now, if you're happy to experiment, is take a screenshot of your picture on the screen and just dump it into Claude and just say, "What can I do?"

**Robert | 35:39**
Yeah.

**Ellie Rofe | 35:48**
I would say color is an element. I don't think video quality is an issue.
I'm not going to be personal, but I can actually just almost see pause on your face. I think your video is pretty high quality.

**Robert | 36:00**
[Laughter] Enhance.

**Ellie Rofe | 36:01**
It's good. Okay, we all have pause.

**Robert | 36:07**
[Laughter] Enhance further. [Laughter].

**Ellie Rofe | 36:11**
Like, think about color, think about the background.
If there are things that are interesting to you, then. And I and literally, Claude, I got it to do it for. A young politician who tried to do a piece to camera in his bedroom. And it looked. I mean, it looked like he was dying because of the lighting.
And it looked like he was like in a grab drab gray shirt. And he's very pale. And, you know, just a couple of changes very quickly. What colors suit me? What is my colorway? You know, that kind of thing. It will make a big difference.

**Robert | 36:44**
Yeah, for sure, so we can have color. I can change my color there [Laughter] pretty good, right? Yeah.

**Ray | 36:58**
I think Li is, you know, spot on in terms of getting that kind of, you know, neutral advice, but like the other thing is you're I've commented before about your background not being perfect. You know, the Reservoir Dogs thing. I'm not sure is doing much for it doesn't communicate to the viewer. The and the color of the wall, I think, has an effect. It could be, because I wonder if it would have that same effect for Li Demetris or myself.
Like, you know, skin tones affect things, right? But the, but there is something a bit want about it, you know? And like the. I think if there are more objects of interest, like I've got a, you know, sort of a grayish wall, I think is not terribly different color than yours behind me.
But the books really set it off. I think they create objects of interest. Of course, they say something about me. I appreciate that part, too. But the but just as Demetris right shelf behind him is speaking to the viewer, so when he's on a call with somebody, they can kind of be looking around him and they're getting, hey, he's reading that thing.
And of course, if they've ever read any of those things, they say, he's a guy who reads that. Yeah, either way, bunch of books. He's reading some books. In fact, he you g the any. Demetris has like an any Duke book sort of in the shelf on the side. You kind of have to squint a little bit to make it out.
And I kind of like it because it gives someone something to hunt for when they're having conversation like services interest that way. But the. I think Ele's. I think Ellie's point about the background is probably where your weak point is right now.
And I got to tell you, it is cheap as held fix. It's a couple of things up on the wall. It is if you don't do other things to it, you can do it, like with a coat of paint. But the things on the wall, if you want to light them, you can, like light strips are really cheap from, like, you know, electronics, you know, messing around store.
And the, and like, this bookcase here, right? I mean, the books cost what they cost, but I had them, right? And the bookcase itself cost me a couple of hundred bucks for like, a really big bookcase. And so like it comes very short compared to the value of your sales.

**Robert | 39:14**
And I've said.

**Ray | 39:15**
For that, like getting this microphone right you've already got and getting the lighting I've got did a lot to improve my rate earlier in the pandemic. I think having this behind me has made the whole thing look much more credible as I've had a bit of a formal office.
So, I don't think it needs to be super complicated what you do in the back, right? But I think if you have something intentional and you spend an hour on it, you'll probably find that it significantly improves.
The reaction and probably improves your confidence as well. Yeah, so, I think that's a really good... I think you're saying, "Hey, there's something you want to do about that."
It's great because it becomes a thing you can do for next week, right? And we can have accountability for it. And I think it looks good. I mean, the Demetrius's a office is really good. His, you know, the.
But the environment that you've got right now, Demetris. I mean, I got a lion no longer in the pit of darkness. I mean, it's sort of it's obviously not your a environment, but looks fine. I really like the Christmas tree, but ideally, I think that your backdrop looks nice.
I've always thought that the way your wallpaper works in the back was really nice. And the. And it sort of says that you are not in a traditional environment, right? That. But you were never going to look like you were one.
But looks deliberate. It looks tasteful, right? That's commun. And especially since you have that visual aspect to what you do, I think it communicates nicely that way, you know? So it doesn't need to be like, you know, overbearing lots of stuff or super expensive whatevers, right? There are YouTube who do lots of fancy things, but I think a lot of people who do the really fancy things do it because they lack taste or self knowledge.
And I think you've got both those things. And so I think you can put up a couple of things and have it make a real difference for you, especially since you have been reading, you have been doing all sorts of stuff.
I think there's stuff that can go back there.

**Robert | 41:06**
Yeah, and yeah, no, sorry, I need to group, so I should go ahead.

**Ray | 41:16**
Sorry, Demetris.

**dimitris@3nuggets.io | 41:19**
Please, may I bring a question? What is the sign you saw Rob that makes you worry about the quality of your video in terms of the background, the microphone, and all of this? Because I watch most of your videos on LinkedIn.

**Robert | 41:38**
Yeah.

**dimitris@3nuggets.io | 41:38**
I find them so educational, insightful, and very sharp in knowledge. Most of them are almost a minute, not that long, so I can engage with them and they can deliver value. I don't see any trouble about the... Of course. A better background with... I didn't see an obstacle at the moment.

**Robert | 42:04**
No, it's actually just... So it's not the videos that... Again, I'm not sure maybe those videos that you saw are actually the ones that I'm criticizing, but criticizing myself over.
It's not the ones that come from Zoom, like where I'm having a conversation with somebody else just like this. I found that when I'm... This is the thing that seems like AI goes and I download it from afterwards.
Maybe that's the problem because I'm storing it on the cloud and then downloading it afterwards. But then I look at it and I'm just like, "This is pixelated." I got that feedback from somebody else afterwards. Which you were right about that point I looked pixelated, but your point of interest... What bothers me about it is that because I have other videos which look good, so I know it's not a problem that can't be solved.
When it comes to the microphone, that's something that's... I'm just curious because, again, I think that it can become... I think just used to how something sounds. I'm not sure if it sounds good. I just can't really tell. Actually, that worries me a little bit, because sometimes, again, I record myself sometimes, and then I go in and I just the studio sound and I'm just listening to it. I'm like, "This just sounds horrible." It sounds like it didn't come from a good mic.
Again, I'm not sure, but just instinctively, it just doesn't sound like when I hear Ray speak, for example, and his microphone just sounds so Krisp and clear. All of you actually like the sound of your microphone. Krisp and clear. Just it when I'm in a script tonight and I'm listening to it back. I'm just listening to myself and I'm listening to the next person speak. I'm looking at the next person's video. It is even crystal clear on the when switchescreens and it was to switch back to my screen I'll pixelate. I'm like, "This is ridiculous."
So again, not a problem necessarily. I know you guys aren't like the Zoom tech support or anything, but I'm just saying in general, that's what to answer the question, that's what triggered it.
I just looked at him like, "This is not looking great."

**dimitris@3nuggets.io | 44:31**
I share advice here. Do you record Zoom calls on the cloud immediately or on your computer? How does it work?

**Robert | 44:41**
Cloud, I've been recording. All right, Claude.

**dimitris@3nuggets.io | 44:44**
It turns to desktops number one. Number two, before you get into the script, I know you have a tele account. Upload the recording right on tele. It is pretty good at fixing everyone's microphone and putting the same quality to everyone. Sure, okay.
Now I'm talking for my headphones. I know that my sound doesn't sound pretty good. But if I do it with tele, you feel like I'm using a professional podcast microphone. It's good. Yeah. So your phones are answered that.

**Robert | 45:27**
Yeah, no, I appreciate that. I'm literally changing my Zoom settings as we speak. So I'm going to...

**dimitris@3nuggets.io | 45:39**
One comment from my side, guys, about the question, "What should be the next product?" Because this is your main question when we entered the conversation.

**Robert | 45:55**
Yeah.

**dimitris@3nuggets.io | 45:59**
I find this question quite interesting from my perspective and the conversation I had with LLM yesterday. What a knowledge graph can solve as a problem. I think that you have them the gold of transcripts. Tons of transcripts from your conversations with clients, from conversations on your meetups, and all of these... I would definitely say, don't make it that sophisticated. Take essays, nice learnings, and a couple of things from those transcripts. Just analyze them. Not so sophisticated important takeout learnings, these kinds of things. Ask Claude to generate them for you, put them in a database. This database can be a Google Sheet. Nothing that sophisticated again.
Then take this thing from 90 days, which is a pretty good time range, no more than 90 days, and fit it again to Claude to think about opportunities. You may have missed what is repeated many times, and you avoided it getting to this conversation. This will not show you what the next product is, but it will show you where you have to put your attention, which is more important than thinking as a product developer.
In the past, this conversation with Ray in one-on-one conversation, and he said, "Getting into engaging conversations with other people, look around, look for whether they interest talk to them, put some content from what you create."
This is very valuable. See how they interact with that. But try to translate what drives this engagement on these posts, for example. Don't compare. Guys, nobody should compare video engagement on LinkedIn with video engagement on YouTube. It's totally irrelevant. Videos on LinkedIn don't perform that well, but they do the work.
So these are things. The more you put outside the... You have a better opportunity to analyze your data. Yeah. You will see what comes to your door, what they're looking for, what they really want.
It's like an investigation, workflow, that kind of thing. After doing these things every single day, try to answer one critical question for Persona. Why they don't go for sleep at night? Who they aren't, who they are.
For example, people who have the money is not the right direction. People who have the money and have this problem and are willing to invest this money is a better direction. More detailed sentences taken out biased people. I had this conversation with another guy here in Greece. He said, "I met three entrepreneurs whose business here in Greece makes millions of euros, and it's all good for them."
Honestly, I'm sorry for this word, and everybody in the room, of course. Sorry because they don't own this money. They have it from EU investment programs, so they're looking for the next EU investment program to put an extra spend in their balance sheet. They are not investors; they just run through programs.
So they wait. They like everything. It doesn't make any sense how much money they have. They don't invest them. That's the question.

**Robert | 50:20**
Yes, they may as well have zero if they don't spend it.

**dimitris@3nuggets.io | 50:23**
Yeah. You may meet someone without money, but his ability to find money to pay you to build something with him, you will get paid again.

**Robert | 50:38**
Very interesting. I appreciate that perspective about people without with without money. I never it's good there's all kinds of people out there, right? And, well.

**dimitris@3nuggets.io | 50:51**
Your service is quite premium. In our service, all of us are not newbies in our markets. So people with zero money in their pocket are not that good sign, definitely. But today I spent the entire morning reading Alice's report from my target audience. It was an incredible analysis. This analysis didn't have something theoretical that had only phrases given by the target audience. What is the problem? Expression? It was quite interesting.
I realized that because my target audience is business consultants. Okay. I found many times on us notes that this is the problem for those people. They get into a bottleneck. They don't know what the next step is they want to avoid and what happens. They look back to their problems. XYZ client spends.

**Robert | 51:56**
My time.
I appreciate that.

**Ray | 52:07**
I particularly appreciate what Bet is doing there because it links us right back to Ellie's opener in this conversation. And the... Because the temptation is to be thinking about what's... I think that what you really need to do is think about who the customer is. Who do you want to be a hero to? Who do you care about and want to make a difference for?
This... But you'll find that a lot of that will follow from there. What's their problem? What problem do you want to solve for them? That they get you into the house. I had a conversation with Andrew Hare, the VP of marketing over at Xano, and I made the suggestion that Xano needs to make better use of its brand because they have a really good brand and they have really good engineering talent for the moment.
They needed to put those things to work where some great products people actually want to buy. They have lots of people who want to buy things from them but it's not quite the right thing. His answer was, "Do you think they should be like a skunk works?"
I said, "Yes, just like a skunk works." He said, "So they should be like locking themselves in a closet building something new." I said, "Absolutely not. That's not what Skunkworks does." Skunkworks was about figuring out what the Air Force really needed, right?
Being a much more spartan organization around that discovery and creation process or being able to build the things that otherwise couldn't get built on the mainstream road.
I think there's something similar here about how you can listen better to understand who those folks are. Something you have today that you did not necessarily have this time last year is you have an archive of all these conversations. I don't know how many.
I mean, if you look back... I know I'm like, "Well over a thousand a year, right?" But I don't know how many conversations you have probably in your Krisp right now, but you think there are clients that are hundreds.

**Robert | 54:01**
Yeah.

**Ray | 54:02**
Ones that you appreciate the most. Yeah. So here are two things about the first. The first is Krisp summarizes the wrong things, right? It summarizes the conversation, but that's not what you want to do. What you want to do is you want to do what GenAI talks about doing, and you want to build a digital twin. You want to understand how they think.
So what were the pains that they expressed? So you take the transcript, the more raw version of that, and you work with that in your preferred tool to extract those insights. Obviously, you can read it for yourself, but that's painful.
So we use AI for it. Then this is the really cool part. Then you take multiples of those conversations and you do that. Then you figure out what's the trend line. What do they have in common? What are their pain points? What are they saying to you? What are they saying to you? You're probably not paying attention to, right?
Because it's not like super germane to whatever technical problem you're solving in hand, but they're saying these things. They're saying all sorts of stuff. One of the best ways to get someone to talk is just to hold your tongue.
Yeah, speak into it like it's a vacuum, right? And that happens all the time, and you've been doing that now for all these hundreds of meetings. The difference between this and maybe your position a year ago is you have a record for it. I'm not saying that's the... Everything was saying going out into the market is, I think, the right thing to do. Everything about Ellie was saying about starting to paint a picture of who those folks are.
But you don't have to start from zero here. You've been talking to these folks, and you can use a combination of your recollection of it and the substantial ability of the AI to repeat this stuff back to a lot of... To be stuff you already know.
But that's the real value of a digital twin approach, right? Like you can simulate... Who is the client that you like? Who are the ones who worked well for you when they worked well for you, right? What do they then turn into? What do they...? No single conversation gives you that answer.
That's why you feed multiple conversations. Or probably do it the way that you would do it if you're actually going through this manually, which is you read a transcript, you summarize it, or you extract out the data points, you read another one, you extract out the data points, and then you're looking at the summaries, or the extracts. I emphasize not summary because the summaries that they do are summaries of topics, not of what you're looking for. You're looking at it from a slightly different angle. Allow the things to do that for you.
That's all agentic. You know that maybe even itself is easy down an interesting area of content. But you have data to work with that allows you... If you want to say you're not that much of a marketer, what you are is a service professional.
You are a technologist, and you can use technology. Plus caring about the fact that you've been caring about and working with these people. Back to your advantage. I think there's a lot that you can do that then puts you in a much rarer position to take advantage of the tactics. Next steps, right? That Ellie was talking about that you just were talking about.
Because I think the theme here is it's the who and the first who is you making you look good on camera. That's... You were alluding to that before. The other who is who's the customer. You've got a lot of data to work with.

**Robert | 57:18**
No, for sure. I appreciate that, thank you. I think that's probably part of what brings my confusion because I do have a lot of data to work with. I get a lot of... You know, I happen to a call this morning, like, for example, like with Scott, and then, like, he'll, you know, I'm just having my morning. I'm thinking about all my other stuff, and I'm working with him, and then he'll start telling me about, like, you know what we should do? We should say, we should open a consulting company.
You know what you and I could do? I was like, thank you. Like, I was just thinking, you're confusing me, Scott, confusing me. Let me do my job, and I don't want to think about, like, what everything that entails.
So, yeah, no, I think, I appreciate it. And that's partly what's going through my mind, like and not that I'm, it just not that I'm not that it's any anything confusing to me about, like, whether or not I want to do that.
It's easy for me to say I don't, but more just confusing in the sense of like, what? How do I even. I just would. I would like it if I was just more clear on what it is that I do want, and I think it is a way for me to get there because then that way when somebody says, hey, here's the idea that I can easily be like, no, that's not what I want, like, right?
Yeah. So I think maybe the best way is to just look into the past a little bit and to leverage that data. Thank you all, by the way. I just I know we're over the hours, so just want to say just thank you. I appreciate it.
I know my hot seat is always confusing, so I appreciate taking the chance. Or, you know, your patience with me.

**Ray | 59:02**
I think we all profited a lot from it. Thank you all. I'll be talking at the end of the week, and we'll do this again Tuesday. Take care. Bye.

