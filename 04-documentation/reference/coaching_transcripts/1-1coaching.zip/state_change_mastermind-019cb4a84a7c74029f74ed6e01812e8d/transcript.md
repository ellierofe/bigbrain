# State Change Mastermind - Mar, 03

# Transcript
**rhdeck | 00:01**
April. But the big thing that changed this year is that we got a little bit left-handed with the weather. But the mountain recently was purchased and poured some capital into it, and the main use of capital was snowmaking.
So that meant that they could open up a little bit earlier and then hopefully they will keep it open a little bit later. So we'll see. The weather has to cooperate though, right? If it stays at 50 degrees Fahrenheit, that's whatever it is like 1012
degrees Celsius. That's not going to... That's something that the snow will be able to stay around at... Makes sense. Yeah, Ellie, I see you again.

**Ellie Rofe | 00:44**
Hello, how is everyone?

**rhdeck | 00:47**
There we go, you audiotape. Initially, I wasn't here yet, and I'm not hearing you now.

**Ellie Rofe | 00:55**
Okay, hello. Okay, this is strange.

**rhdeck | 01:02**
I'm hearing you right now. Could we try? Could you just try getting a sentence out? We'll see if we're okay.

**Ellie Rofe | 01:08**
Yep, can you hear me now or is this sentence patchy?

**rhdeck | 01:13**
Sounds great.

**Ellie Rofe | 01:14**
Okay, fabulous. Maybe it's...

**rhdeck | 01:16**
All right.

**Ellie Rofe | 01:17**
Yeah, maybe I'm leaning back too far.

**rhdeck | 01:20**
Yeah, I don't know, you know, a little bit lean back plus Krisp or something and sort of sound your background noises. Anyway, you sound just fine now. It was just a little bit weird in the beginning.

**Ellie Rofe | 01:31**
Good.

**rhdeck | 01:32**
Okay, let's quickly go around the horn and what is true today that was not true this time a week ago. Just could we start with you, sir?

**calendar-invite@lu.ma | 01:42**
Yeah, sure. It's true, today, guys, that I'm starting to create magnets. For my LinkedIn posts, I'm using the same time for my events. So, I pushed myself into this promotional part on the brain graph.
I have the API available, so everybody now can use this to copy the API keys and create an automation automatically. I'm planning to do immediate integration with platforms like Zapier and make it so I can join the marketplace.
Something interesting I made was during the weekend. I had a long conversation with Claude, helping me to do investigation and get some results about the pricing of my services, including the brain graph as a tool. It
helped me to create my services and packages that will be meaningful and create the offers so I can bring them into a new website. So, I'm working with Claude code to give me suggestions so we can go and create it and bring them up.
The plan for the next few days, hopefully, I'm going to achieve it, is to add the pricing features into Brain Graph because at the moment, it's totally free with Claude because I learned from people like Ellie, who helped me push the massin.
Yeah, and hopefully, next week, I will be able to launch the service and all of these. I'm closing with that, guys. All of this came from a conversation I had with David Arnoux. I don't know if you know him from LinkedIn. He's a guy who used to work on growth. Tried... Is the name of the brand? Mostly, he's on marketing, and we had a conversation about the tool he created because I gave him honest feedback. What doesn't work?
So we joined immediately, and we had an interesting conversation, and he gave me feedback about other people who do the second brain service. He said what I'm doing more and what I'm doing better. So he encouraged me to put my prices up while I was so hesitating to put my prices up.
I told him the actual prices from my test clients. And he said, "No, it's ridiculous. Just go up. Even the other people who are doing empty files and GitHub repositories, they charge six times more. Just go..." So, he encouraged me on that and just applied that.
That's it.

**Robert | 04:50**
Super cool.

**rhdeck | 04:51**
I can't really see how that goes. Robert, can we check in with you, sir?

**Robert | 04:56**
Yeah, for sure. So true to today not true a week ago, you've been doing started work with a new client yesterday in New Zealand, and it's been going very well, actually. Like, he's somebody who stands to benefit quite a lot from, like, his particular stack and his situation. He has a project that he's been working on for like two years, has already put like a hundred thousand dollars into it, and it's on Xano and we web and it's a mess like it doesn't work like he's been doing that for.
So how low is the bar? I mean, like. I mean, like. I mean, it's his. His mind was blown when I showed him just in front of him how we can literally just fix this thing. I don't see any reason why not inside of a week that, like, you can't be up and going and working and like, he was.
I think he was just, most of the time, he's just speechless. Like the. The whole time. And it's been very positive. We're meeting every day this week, including today and tomorrow and the day after, and so far, honestly, it's been a pleasure to work with him, so that's great. Delivered for Mark last weekend. He's very happy.
And then right now, it seems like a good, like relationship in a way because, like, we have an understanding, like we're both we're communicating, like, very clearly with each other. Like, I'm. We're telling. Just communicating about, like, when hours start and when they stop, basically.
And it's like, okay, right now we're there's no hours being accumulated. That's so that means that we're on the same page about like what who that I'm not supposed to be doing anything. And that's allow me to just focus then on the client who I am working with.
And that feels healthier. And I regret. I regret to say that. Like, honestly, I'm not sure how the relationship with Scott is right now. Because he's late to pay his last invoice. And I think it's pretty crappy to honestly to make me hang on like that when, you know.
I mean, he would have me stay up. He would ask me to stay up with him until, like three in the morning doing working sessions. And then. And he was all right with asking with that, but like, if I want to be paid all of a sudden, that's a problem.
Like, I just think it's very disrespectful to be honest. Like I'm. And that's fine like that's all right. It just I just turned it into motivation to just go and work harder and to go do like my strategy.
If anything, this kind of motivates me to market because I want to be bigger than the entire game. I want to be unescapable. Like if you don't pay my invoice, you will never be able to escape me. Because I will never disappear from this industry.
Like I will only become bigger, and you will always see my face and you will see the money you owe me. Like, you know, that's the type of way my brain works. Like I can be. I have a chip on my shoulder when it comes to some of this stuff, so I'll try to turn it into being productive.
But yeah, like, it really bothers me, but I'll try to turn it into. But I guess what we're working on, Ray, like that's some of my motivations. Like I was crushed them then with my success.

**rhdeck | 08:25**
Success gives me the best revenge. Yeah, and I suppose yet another reminder that people are always paying you for what you're going to do for them next, right? Even though it's technically you're being paid in arrears, it's always... If Scott's about to get fired, maybe that's going to be a thing or whatever.
Yeah, we serve the need to... There's always a... Alright, what am I okay with? If the last invoice is not coming in because people should be doing it sometimes, they don't, and they certainly don't do it on time.
That's where things get not so pleasant. I'm sorry that's happened to men.

**Robert | 09:06**
But I part of the game, you know, I think part of the game and I think that that's part of it too. I'm happy that I'm handling it better. It just. Not my first, you know, rodeo with it. And I think I thought about it and I thought, well, if I was looking for stability, then doesn't that's not a business. Businesses don't have stability. I'm looking for growth.
And you have to take it both ways. Like if it's gonna be sometimes, you know, you the risk will end up being that you don't get paid on time. Other times it ends up falling into your favor that you get outsized returns on, you know, for what you put in it.
I think that's the game. So, I'm and I'm happy because I have now things accumulating like I have Mark, and then I have Jordan, and I just keep the wheel turning and then I have these systems that keep poking Scott, you know, with like, you know, automatically he's like, hey, you're late.
Like. But I don't have to deal with that because that's just an email that gets out from the machine and then otherwise. Yeah, you know's not ideal, but like I said, I try to turn it into motivation.
And I know that when I make when I start making my posts and stuff that like. You know, again, I would rather I like to try to. It sounds crazy, but I know it's doable because it's already been it's been in the process.
But to just make it so that like literally that like even the stuff that everybody that they build on is even the it's I want to control it like or, you know, or to be everything that's the best technology, all the best, you know, the latest solutions, anything that's new. I just want to be producing it.
And then and yeah, just be everywhere in their minds unescapable.

**rhdeck | 10:52**
Okay, cool, man, this all has a... You wouldn't like him when he's angry feel to it.

**Robert | 11:01**
Yeah, perfect. Sure, yeah, hundred percent.

**Ellie Rofe | 11:03**
I'm getting more temperament vibes at the moment.

**Robert | 11:07**
Sorry, I didn't catch it.

**Ellie Rofe | 11:09**
I said I'm getting full Old Testament vibes at the moment.

**Robert | 11:12**
[Laughter] You st my fury, my wrath.

**Ellie Rofe | 11:12**
I am a vengeful Dr.

**Robert | 11:18**
My wrath will do swift...

**rhdeck | 11:22**
Jump the stairs. The hands of angry God or, you know, cla to the hands of a of an angry, you know, Robert and this stuff comes and goes, right like, hey, this week he's late in pain for this week.
It's not like the we sort of flow through it. Yeah, okay, I appreciate that story, and Ellie, let's turn to you. Today's your hot seat. How can this group be of maximum service to you today? And what? What's been going on for next week?

**Ellie Rofe | 11:51**
Well, the political party is underway. It's all sorted and money in the bank and off we go on a pretty large project, which I'll lean into it more when... Thank you.
I'll lean into that a bit more when I get to how you guys can help me. What else has been happening? I'm going back to the UK next week and actually at the end of this week, I have a call. A meeting booked. Two meetings booked in London in person with potential leads.
So one, the guy at a US big finance event. The other guy, who's actually part of the SDP but has a chemicals company. If it should survive this week, there's a whole thing with the investors and whether they're going to re up.
So he'll need help raising. And so yeah, it's nice relationships are coming out of that engagement because it's a political party where everyone has... It seems that everyone has businesses who have been entrepreneurs rather than politicians. There's potential coming through, which is quite nice.
Otherwise, I have been rebuilding a light version of Google, which I said I'd give myself until the end of the weekend, and then I couldn't work on it at the weekend at all. So I've said by the time I'm leaving for England on Friday, I will not be working on it any further and just be testing and seeing if it helps me.
What I would love help with today is for the SDP I need to do research and a number of research projects. I've broken them down, and I suspect a huge amount of the initial data gathering and potentially quite a lot of the raw data analysis can be done with AI, in fact, I know it can. Some of it's APIs.
So you can go into the Electoral Commission's API and find out every donor above a certain threshold, who they are, how much money they gave, which party, etc. You can go into Hansard Records, which is like the transcripts of Parliament, and find out what questions are being asked.
So there's a specific parliamentary process for asking a question. You can find out which parties are asking what kinds of questions. It would be really interesting for me to analyze what that looks like compared to the rhetoric on social media or whatever in the media. Then there's a brand side of it where we can scrape the websites, probably using Brave. I don't know, something like that.
Get it to go and look at the key messaging or the policy docs on each party's website. Then I have to do some quantitative stuff. Sorry, qualitative stuff. Like looking at the quality of the brand, the vibe, how well the messaging comes through, and things like that.
Then there's the big analysis piece. So... And partly what I would love to do... Demetrius, this will be part of what I would like to experiment with Brain Graph, and I'm by the way with my own API key rather than just hammering yours. It is a link analysis.
So pushing huge amounts of this data in and looking at what the landscape looks like, across these things, you know what think tanks are involved here, there, and everywhere, etc. So I guess I just thought...
I've got three technical and process as strategic geniuses on the call. I would love to hear if I show you, for example, a list. Shall I share it? Bump, bump, bump... Where are too many things open? As always.
So if you were looking at this right, would you just dump that into an open Claude chat and say, "Go and settle this up," or would you do it yourself? How would you look at starting a project like this? This is a table showing the API automated data sources I could get to.

**Robert | 16:46**
So what's the goal?

**Ellie Rofe | 16:48**
So the goal is... And that is very useful because that's part of the process I've been thinking about for the data scraping. I need to answer a number of questions. So let's go with the initial one, which is competitor analysis. Bump up, bump, right.
So I need to output a competitor analysis that understands multiple dimensions. Some of this is strategic positioning, the narrative of messaging, brand identity policy, who their audience is, who the coalition is like the wider group around each party, where they are active most and where they're most effective on different channels, who their fundraisers are and what they're buying, as it were, etc.
Then the walls bump... Maybe it's her.

**Robert | 17:54**
I'd like to just ask, what's your...? But this is helpful. I'm just I'm wondering like what's your technical goal? Like, what is what are you trying to make true in? Is this something that you want it to be in what experience?

**Ellie Rofe | 18:06**
Great point. I want to be able to say, "Run this research process." So create an app that says, "Run this research process" or run these bits and hand them off to the next thing or whatever. For the Tories, for Labor, for reform, for the S&P for REST store.
So I want that repeatable process. Then the meta goal around that is for me to understand how you guys set up. So one of the things I love about watching YouTube videos about people using or developers doing stuff is it's not even necessarily what they're doing. I just love seeing how they think about it.
So if you were saying, "Right, I need to scrape all this data." Some of it's API, some of it's web search, some of it will be manual. I need to get that data out into a raw format, first of all, as a single source of truth. I need to then start analyzing that data for patterns and surfacing stuff that I might need to go and look for.
How would you start breaking that down? How would you look at that task and start setting up that process?

**Robert | 19:21**
Well, I would try to, I guess I want to know what is my like, what do I have?

**Ellie Rofe | 19:22**
S.

**Robert | 19:29**
What am I starting with? Like if I was just looking at very practically what do I have and like what's my.
And then try to I try to put AI in the driver's seat really of because ultimately this is the amazing part of like what we're doing nowadays is that eventually AI can be pretty much in the driver's seat, I think among almost any context, like for most of it.
So I kind of just tend to want to start with that anyway. So I want to walk it through. Okay, so here's this lives here, this lives there. Let's go through the process. And I guess it just answers the question pretty immediately about, like, well, what do we have access to? Where does it live?
And I mean, for me, I want to start to bring those things together, and then we start to move towards an outcome that, you know, that looks like what do you define success as? Like, you know, so I mean, this is a very convoluted way of putting it, maybe, but I would probably start with opening up cloud code and.
And just, you know, depending on the stack that you're comfortable with. I would get started with establishing some of the ground truths about what you want to do, what you want to do and at least get those things that are not negotiable in there.
Like, what do we need? We need an API key for sure. Like we need certain services to allow the AI to even just be able to solve the problem, to make some progress with it on your behalf, even like or with you at the same time. Some of so some of it just setting up actually just setting up for success for a place where it can where you can try things rapidly to experiment.
But at the same time, I don't think this requires a lot of experimentation because, yeah, because most of it is. It's already there. Like you can see where the information will come from. Like we know it will go to an AI it's not like it's mysterious in terms of how you'll get there.
I think it's mostly just a question of pipeline from the sounds of it of just organizing the pipeline and then it just depends like kind of how you want ultimately, I think a lot of this depends on like how you envision the final solution being delivered to people.
Like is it something that you know is a multi tenant like the more that you start to add like in terms of, where how where you're meeting them, right? And like... Okay, is this like you're the platform and then you're hosting for then they start to add in things that are not necessarily related to the core of which of this rate, which is a different question.
So that's why I asked. Maybe it depends a little bit. It really hugely depends, actually, on what your standard of done is. Where do you draw the line for being done?
Because there are a lot of stages of this where it's already useful and then it can only become more... Yeah, and I think that the question of, "Is it possible?" Is and nowadays is more dangerous than ever because the answer is almost always yes.
So, yeah, it depends on how far you want to go with it. Honestly.

**Ellie Rofe | 22:30**
Well, I'm always ambitious. Everything's the everything project. So, you know, I would love to I'll just create a full picture of the entire UK political landscape, plus obviously any major foreign influence on it.
But, you know, it's like. I have gotten the.

**Robert | 22:48**
That's a good hey, you never know. Like ca, I mean, I'm sure there's a lot of military, you know? That would. That would. Love that idea. Like, yes. You're hired. As soon as I hear that, [Laughter].

**Ellie Rofe | 23:00**
Suddenly at the OD for the rest of my life. Yeah, I'm sure there are people doing this kind of thing, but I... There are certain places. So for media queries, for example, it comes up and says, "Are you?" And sorry, Demetrius, this is your world. Nodes and edges. Then, I was saying, "Look, I can totally get that. I can do certain things. I can do certain searches through X or use skills to check red it senti or whatever."
But then it suddenly comes up with, like, "Okay, there are all these different things." Then it says, "Here's a G Delt project, right?" Which does big query tables? I don't know what any of that is. I could obviously find out.
This is just all the media in the world and what's happening. So I guess, yes, part of it is going to be my own discipline. What am I going to try and wrangle into here? Part of that, I am trying to create discipline around by saying, "What are the questions that I want to answer?"

**Robert | 24:25**
That's the point. Well, yeah, that's so good. Yeah, go ahead.

**calendar-invite@lu.ma | 24:29**
No, please, Robert.

**Robert | 24:33**
I think that, to be honest, I think that this is probably your area, [Laughter] so I'd be more than happy to hear your thoughts because I think that... Yeah, I agree.

**Ellie Rofe | 24:47**
Sorry, I'm trying to find the questions, but anyway, what were you going to say, Demetrius?

**rhdeck | 24:52**
Yeah.

**calendar-invite@lu.ma | 24:53**
I want to say that no matter what the stack we're going to follow, you're going to use it doesn't matter what's going to be the methodology you want to follow to analyze the data. The number one and most important thing is to specify. How do you want to use the final outcome?

**Ellie Rofe | 25:12**
No.

**calendar-invite@lu.ma | 25:13**
Okay, what is the problem you want to solve? From my understanding, what you want to do is build a system that can answer your questions to make it scalable. Upfront is quite challenging. If you are in time pressure, forget about it. Just spend 30 minutes or one hour maximum by giving manually into Claude some samples of your documents and tell it to give you a list of questions that can be covered from these inputs from this list of questions. What's going to happen is it will inspire your imagination about adding questions into the list.
Okay, so, creating the list of questions you want to answer is the first number one step, second step. I would go for creating a skill because if you go with a platform like Brain Graph, what's going to happen is you will not meet your goal. I'm going to lose money on API calls, I guarantee you for that, so there's no reason to go for this.

**Ellie Rofe | 26:41**
Hu.

**calendar-invite@lu.ma | 26:44**
You can stay here on Cloud Desktop and start creating skills that can understand the context you feed and extract it into viable nodes, and from there they can send them into a knowledge graph like Neopherj, which is totally free. Don't look for perfection. A knowledge graph that is 90% good compared to 100% good under time pressure.
It's fine, just go for it.

**Ellie Rofe | 27:25**
Hu.

**calendar-invite@lu.ma | 27:25**
Okay, so I would go with MCP just to send the data through the tab into Neo Ford automatically. For scraping, you can use PayPal tier or similar packages into Claude.
So it's going to run automatically. Just to give you an example. What I did scraping Spotify for artists last week. Created the skill of SOP so the user just says, "Hey, this is my username and my password."
The SOP runs automatically taking the two-factor authentication code logins, getting the data, feeding them to Google Sheet. That's all and trans asynchronously. So I would suggest an approach like that but the most important thing is what is important to you upfront, what is the question you want to have? What will make this analysis valuable? All of this analysis is the strong learning from Mark's conversations, the "Why" every outcome needs to have a "Why" an AI suggests this thing, "Why" this outcome exists, and perform audits of what is missed. These are the kind of questions that follow up to enrich and make it strong. You may hit the limits of the context window on responses.
That's fine, just split the process of the SOP in stages so we'll avoid it. Ten stages where every time we will say, "Okay, move to the next." But it will do the job automatically for you. The last step is how you validate the outcome after three or four inputs into your... Use the cloud here to bring questions.
So you will ask what is... Your question and AI has to use your... Brain to answer that question. If you get a reasonable result for you, that's fine. Your methodology is good. You can go for it. If it's not, just make some improvements. How can you do it? Just ask AI why this information is lost.
So we will see in your analysis step what can be done. I would keep everything in one place into... For the simplicity. If you want to go for a more complete system, okay, then you can talk about other stacks that can join the company and make it more broad.
But from my understanding, you want to have it for your meetings in London, right?

**Ellie Rofe | 30:35**
No. So this is a two to three-week process. The part I'm doing this week mostly is the data gathering process and where I... Research and so the... There's a long-form output that comes from this and that is the stuff that various people in the party... Not the leader necessarily. Although he might... He's a very detail-oriented person.
There will be an overview of all the competitor landscape, the other political parties in this case, and it will show various parameters of those different parties. Then I will be mapping where the SDP fits and where there is a gap analysis of how the SDP fits into this world, where it can create its own shape and its own space because it's a small party that needs to grow how they are.

**Robert | 31:46**
Can I ask you a question?
Sorry, sir, I wanted to ask you a really quick question because it seems to me like this is the service, right? Like this is this. Like. It seems to that this is a very, involved process.
And like obviously you do it very well and like the way that you're doing it, you've been enhancing it with technology and everything. And I'm wondering isn't is this something that is like in itself, you know, is this how it gets delivered basically is like this like in that you were having or are you picturing it more like completely hands off? Is the goal to make it totally hands off that this person who's the leader of the party can just go and get, like, types of reports without you being involved at all.
But at the same time. I see you are. You know, I'm. I'm trying to understand, like where like what the what is the purpose of this? But when I see that right now, you being part of it there's a purpose there, it seems to me at least.

**Ellie Rofe | 32:43**
Yeah, and this goes back to the conversation I had with Ray on Friday, which is that what I'm really trying to do with the vast majority of time with technology is hand off executive function to it. I don't want to be clicking on a thousand websites and going and checking for this PDF and who wrote that PDF and who was the initial bit is so data gathering, organizing the data, the raw data, doing initial quantitative style or structural analysis of that data.

**Robert | 33:03**
Okay, so that so that's the problem then so that's the issue.

**calendar-invite@lu.ma | 33:08**
It was the same.

**Ellie Rofe | 33:21**
The layer that I then bring in is I'm going to then have ten to twelve interviews with people from the party.
So I'm listening to lots of people, and I'm going to be looking at the wider world. As part of that, there are certain things that the AI can't do, like go and look at all the different party websites with the human brain and say this is or isn't effective. I understand branding. This doesn't work or this is who this is trying to appeal to.
Then the bit where I really come in is synthesizing all of that, making sure that there are no gaps in what the SDP understands about itself or the landscape it's working in. Then from there, doing the creative leaps to turn all of that into a fundraising strategy.
So it definitely has to have me in it. But I want to use the... I want to set up this to just run stuff for me.

**calendar-invite@lu.ma | 34:23**
That's very important. The writing of SOPs, the analysis approach, and putting down what the AI's focus is. It can only come from you. There's nobody who can replace that.

**Robert | 34:44**
I would just... In that, if somebody put a gun to my head and said, "This is what you've got to do. You've got to get some research done, and we've got to do this fast."
As a gun to my head, I would probably say, "All right, then let's just spin up an open call and a digital ocean server. I'm going to give it a notion skill, and I'm going to ask it for research."

**Ellie Rofe | 35:03**
He.

**Robert | 35:05**
I'm gonna see how it does.
If it needs more research. I'm gonna give a Perplexity API key and then I'm gonna create a Chron job maybe that runs, you know, whatever x amount of time, whatever the schedule is. And then I'm going to.
But for me, this ends up with like I end up with beautiful notion documents. I know I already know like what I just said there. I end up with research into a beautiful notion document. And that's I think that that's to me, that's how I get it done like.
And I could probably improve it from there, maybe 10% 20 % from there. But then it starts to become diminishing returns. I think after a certain point, I feel like the actual core of what you're trying to solve is somewhere...
Just go do this thing and give it back to me in structured form, and I think you can iterate that on pretty rapidly as long as we were talking about the environment before... Where does it...? How can it succeed if you were to put it on a digital ocean? Open cloud has API keys, has a browser, has all the capability to be able to succeed with the task.
Then, the notion key has the ability to succeed in bringing it back to you. The task itself is done. Now, the packaging and everything, that's something that can be worked on over time.
But just to say that, for focus, on the problem itself. That's how I tackle the problem.

**Ellie Rofe | 36:24**
Yeah. Okay, so that does sound similar to what I've been doing, which is like if.

**Robert | 36:31**
So what's wrong with that?

**Ellie Rofe | 36:35**
It's just so voluminous, this one, and there are so many different things to set up. I just didn't know. I just wanted to see whether there were things I was missing.

**Robert | 36:43**
But, like, how' the how's the experience? Like how what is it? What's true about it.

**calendar-invite@lu.ma | 36:47**
Now.

**Ellie Rofe | 36:49**
That was for a different research project. It was good. It was quite high touch at that point, getting things set up and then checking in and making sure it was all okay.
But I think maybe I need to do a test build with it and see what works or doesn't work once I've set up the... These are the systems I want to check for, I think. I guess the thing. Actually, no.
That's the underlying question. Are you using the concept or is it really true the concept of this being autonomous? Am I using that? Or are there ways to use that so that it goes off and does stuff that maybe I don't even know how to tell it to do?
It's going to be smarter than me in certain areas. Or is it going to go and do exactly what I tell it to do in these ways?

**calendar-invite@lu.ma | 37:45**
You can even if you go with cloud cowork, even if you go with open cloud, you can tell it. But I'm thinking here that for the early steps, you just want to make the steps done in a secure way so we can go and validate the outcome.
So to make it even perfect and more perfect and start working more smartly, you can include the skill for self-learning from what already exists. So what we have to focus on in the new input. So we will drive the analysis.
But this has the risk of changing the direction and losing the direction. So what you want to build is something that can be totally subjective and that it can extract all the information from these documents from the websites from API keys and everything and store them with the same weight into the brain and the digital brain so you can access them.
Every information will have the same impact. You just need the information from there. If the same information is found multiple times, put a counter. How many times we found the same thing, for example? Did he help?

**Ellie Rofe | 39:28**
Yeah, I think so. So you have a self-learning skill, but you give it strict parameters so it doesn't go off-piste.

**calendar-invite@lu.ma | 39:38**
Yeah, for the beginning at least, yes. Maybe later on you can improve it, right?

**rhdeck | 39:44**
I was just sort of thinking the reverse. The. You know, I actually have another project up here where I was sort of getting all up in my own head about it, you know, and like, I've got lots of different steps.
And how do I break this down? How do I think about this? And then I sort of had the insight. I just asked Claude Code to say, well, you know, I just, I turn on my microphone, right? I use back whisper just.
And I just dictated the stuff I was thinking about and the question I asked. I've, you know, I'm not sure it's a magic spell level question, but sort of. But the type thing I'm asking you to do and it seems to respond to the turn of phrases. Help me think about this. How do this, don't not even make a plan. Making a plan puts it more into action mode. Help me think about this.
And then it came up with a plan. I'm like, hey, that seemed like a good plan. Go give it a try. And then starts doing it. And then, you know, it does things wrong, right? So that's not me having to get out of it, but it puts me from being the blockers and trying to come up with like, okay, how do I figure out the right steps to.
It's tried some stuff, and I'm seeing where it's going off, and I can start to have an irative conversation the way I would if I were sending someone out on the project to go work on this. Right? The I read and I have, you know, it's been a big influence on me that, like, AI lives for error messages, right?
So like AI plan and kind of does a plan for me and then kind of gets off the plan. You know, we've all seen that happen. But the thing that makes you kind of extraordinary is the difference. See like a good tool that was built for AI and a bad tool or what work a different ways. What the AI has more success with versus not is one where when it's not having success, it gets feedback right of saying not only this didn't work, but why it's not good.
So it's about having those conversations in the breach seemed to be a sweet spot for being able to then start to self-correct. So we talk about the whole self-learning thing where you need to be.
It's like that's that. That becomes where you are in the conversation. Why do I bring all this up? I bring this all, but for two reasons. First is, you know, taking... In fact, you might even take the Krisp from this, right? Dump that in and say, "Hey, could we turn this into a little bit of a model?"
Now think about this. Give it a chance to go do it and fail. I've asked for plans before, like how to do this, refactor, how to go build this, and it gives me a plan that says this will take six months and then thirty.

**Robert | 42:25**
Yeah.

**Ellie Rofe | 42:26**
For the first three weeks, we'll work through this.

**rhdeck | 42:27**
Because like. Yeah, because it will do all of that, you know, and then you can find out.

**Ellie Rofe | 42:29**
This one step. Yeah.

**rhdeck | 42:36**
Yeah, that wasn't quite right. Then you've lost half an hour, right? But that's half an hour. You made some progress, and you...
So some things were done right and some things might not have been done right, but as opposed to that half hour of just being stuck, I have definitely been able to get... You'll block it up by getting stuck by like, "Well, how do I articulate the right plan?"
Instead, what I've done is give it more right. This is where the voice thing I find to be very helpful. But you write up whatever... But you're not trying to come up with the correct ten words or the document or the big structured document. You're trying to just give it insight into your thinking. It will help create structure.
That's what it does, that it knows how to transform data. Can't make something from nothing. That's your job. That's creative, right? But what it can do is transform that more structure. Then it can take a run at it, and you can be telling it where it bumped itself, right?
Why that was a bump, and then that leads me to do it again and again. Robert, you have that B1, B2, B3 thing you got going, right? And that idea of just doing multiple drafts is something that, as a writer, is a familiar idea.
But then having the feedback of what was it about draft 2 that wasn't quite right? Then allowing it to do draft 3. You don't want it to be efficient. You want it to be... It's okay for it to be wasteful because it's an idea of doing a big project that was only somewhat okay in minutes, not days, weeks.
Then by doing that with rapid duration, you're able to get there. Now, the reason I'm saying this is the reverse of what Dimitris was suggesting because if by starting with the broader structure, not only does the AI get to discover, but you get to discover the parts that really matter, right?
As you are expressing more and more intent because you have more of your arms around this, subsequent versions of this become better. It gets closer to what you really need, and you are working in partnership with it.
So you wind up actually more towards the end, you are giving it more specific instructions, right? Partially because you know how to... Partially because you know what you want. I mean, there's a lot of stuff in here, but how many of these data points really matter? We're going to sort it out, right?
And I would probably look at this and think, "Can I give this to AI and say, 'Give this a go'? Let's start with the research phase on this. Let's go across. Each of the five parties can make each of these things happen. What would be your plan for accomplishing as much as we can in a first round?" Comes up, and you say, "Let's go."

**Ellie Rofe | 45:14**
Uhmm.

**rhdeck | 45:17**
Then, as you sequence, you're becoming more and more informed opinions right about the parks that didn't go right last time, and I find that it's not one-shotting right. It's not like you gave it to the AI and you get to leave it.
Have you heard of the term centaur versus a snipwork? Have any of you heard that term before?

**Ellie Rofe | 45:41**
No.

**rhdeck | 45:42**
Okay, so centaur is the idea of like you have there there's the human part and there's the horsep, right?
And there's like, okay, so what's your job as a human? Your job is to view. What's this job? As a horse is to run. So you know. You allow it to run, your job is to review, right? You're but just because it's running doesn't mean you don't have that job, right? You've just sort of dealt you've separated labor as opposed to cyborg. We're seeing the robot is acting on your behalf, right?
That's to talk about more autonomous and I bring up those two things because there's something called jagged frontier of how AI works and the and some things benefit a lot more from that treating like having a centaur relationship to it and some things benefit more from having a Ciborg.
I think where we get tricked out is like, but wait, if it's gonna be a cyborg, I'm all afraid of it, you know, going and you know, destroying the world or, you know, doing something that's totally wrong when in fact, if you have that okay, I'm dividing up labor, it can work relatively it can work better, right? It just requires that management of you.
You know, as I as I've been listening to this conversation. I've been sort of wondering, like there's a it does feel like you are. You now have a lot of stuff in here that I bet you know, just like I was going through and I went to this literal yesterday.
If you give it permission to go take a run at it, you will have more ideas come out on the other side of that of the many things that went right and the some things that went wrong. And that will be turning the wheel for you.
And put in position to have more opinions. Like what be was talking about. Of what those proper guard rails are and what that proper shape is.

**Ellie Rofe | 47:24**
Yes, okay, so you'd go in code.

**rhdeck | 47:26**
I'd love to have you just give this to Claude code because Claude code...
Well, you've been using Claude code for your semimoogle stuff or what? What have you been using for that?

**Ellie Rofe | 47:40**
Yeah, I mean, I've used loads of different tools, I just wondered, I'm just genuinely wondering which ones you guys would start with, like, is it open Claude? Is it Claude? Code like?
I mean, I know there's. There's similar models underneath, but it's. You know. Does it matterm?

**rhdeck | 47:55**
I'm not sure it to'tly matters at all. Yeah. Genleman do you have thoughts on this?

**calendar-invite@lu.ma | 47:59**
Dimitris, I will go with a cloud desktop app.
Cloud Code because you know, open road is quite good at doing stuff and finding stuff, but what's going to happen? You're going to pay an extra charge for the API key usage, something that you can avoid from this interface because we already have the pro plan, for example, or the max plan, whatever you have.
So you made an already purchase. You put your money in there. And... Okay. You can get the value from that. This is where I would go for it.

**Robert | 48:43**
I agree. I think that overall, it's just literally just increasing the distance between you and what it's... I mean, you have the computer, you have all the stuff in front of you. If we're just talking about...
I could say that there are some processes that benefit from being on a separate machine, and I've experienced that in terms of, for example, I want something to do for eight hours of just dogfooting it, like open the browser, and I don't want my browser to be taken over by that.
It's a bit intensive on the machine, but even in that case, I would try to even figure out a way to do it through my Claude token because there is a way. I would probably even do it just because I don't like it anyway. I just think that there's a risk involved with doing that if you're going to put it on the token, but it's not necessary.
I think you get better performance and you would save money doing it locally anyway, and you'd have more control. If you're talking about just using the browser, I'll just drop a link here for what I think is the best MCP for scale. I would say for browser automation here because I find this actually to be incredible. This is the one I use all the time now.
I will always reach for this one for browsing automation, and I find it... I have it running right now. I can run multiple headless browsers, and I can do multiple tests without even having the browsers open in front of me. With this...
This is... Really good. Yeah. So to say that, with this, you could do... I mean, honestly, using this, especially lately, has made me. Yeah. Think that like a lot of the stuff you don't really need to have like a Mac mini running like that like, or, you know, to have it far away from. You can just you can get the same results on your cloud code subscription locally with, you know, something like this. Better results. Actually, I would say that.
I think probably better. Because you're just. You're there and you're able to see, like, what's going on.

**Ellie Rofe | 51:02**
Okay, fabulous. I think a final question, perhaps, is... So, Demetrius, why were you saying not to use Brain Graph or something like this?

**calendar-invite@lu.ma | 51:16**
Because Brain Graph is designed to run through transcripts and you will find it quite painful creating different prompt analyses for every single case study. Want to have first and second...

**Ellie Rofe | 51:33**
Hu.

**calendar-invite@lu.ma | 51:38**
It expects you to create the document and upload it, which means you run a separate process where you put in your driver or your local machine all the documents and then manually start uploading.
Okay. It supports the multiple upload documents.

**Ellie Rofe | 51:56**
2?

**calendar-invite@lu.ma | 51:56**
But you know this will take you time and you need the speed into validating the approach, figuring out if it works and how it works.

**Ellie Rofe | 52:07**
No.

**calendar-invite@lu.ma | 52:08**
So why not to use the MCP service? Go take the data, create the report, upload it in your Google Drive just for saving them in one place, present them for analysis, whatever it is.
Okay, perfect. Does it work? You chat inside there in one environment.

**Ellie Rofe | 52:27**
Five.

**calendar-invite@lu.ma | 52:28**
Brain Graph is just for transcripts and some PDFs and if you push it with image analysis and graph analysis, which I guess you may find them a lot. Not sure if it will cover the needs of the project. I tell you because I know exactly every single step how it works in that...

**Ellie Rofe | 52:55**
Yeah, no, that's exactly why I was asking to try and understand. That's very helpful. Okay.

**calendar-invite@lu.ma | 53:04**
Of course, during the process, I'm very glad to work together for that. It will be a very interesting case study for me either.
We can speed up the process together. I'm very glad.

**Ellie Rofe | 53:17**
Yeah, okay, that's lovely, that's very kind, thank you. I will once I've got the actual raw data and worked out the analysis stage of that.
Yeah, that'll be fantastic.

**calendar-invite@lu.ma | 53:29**
Yeah, sure.

**Ellie Rofe | 53:31**
Okay, that was incredibly helpful, as I say. Just useful to really understand how you guys approach things and how you think. I know that my thinking is...

**Robert | 53:39**
I was gonna say like, yeah, let's just, if it's helpful, like, I just want to offer the same thing, like, let's just, you know, let's just stop on a call, and I think it'll be really cool, you know, to make a lot happen in an hour.
Like it's just. Especially nowadays becoming quicker and quicker. Like, even if we were to do this three months ago, we wouldn't know nowhere near the amount of progress you could make now in an hour.
Like because of everything.

**Ellie Rofe | 54:02**
No.

**Robert | 54:04**
So yeah, we'll just be happy to bring it to your benefit as... Yeah, no, I actually do it.

**Ellie Rofe | 54:07**
Okay, fabulous, I really appreciate that.

**Robert | 54:11**
Let's just put it on a calendar like that.

**Ellie Rofe | 54:13**
Yeah, okay, that's amazing. How does Thursday work for you guys?

**calendar-invite@lu.ma | 54:24**
Thursday what time?

**Ellie Rofe | 54:26**
Afternoon, I would suspect for... For Robert's time zone.

**Robert | 54:31**
Yeah, whichever. What works for you? Because you're all ahead of me. So, I'm sorry I didn't catch you.

**Ellie Rofe | 54:37**
On Thursday?

**calendar-invite@lu.ma | 54:42**
You...

**rhdeck | 54:43**
The scheduling increment. I think that's a good point. Like Robert, what do you availability on you know your morning there afternoon.

**Robert | 54:52**
Yeah, does. Well, I mean, does this time work like the same time as a meeting? Because I kind of like, I'm. Wait, never mind an hour later because there's a state changed meeting because I go to that first, but like, so maybe I should' before.

**rhdeck | 55:10**
Before it would be more like their afternoon instead of being there.

**Robert | 55:13**
Yeah.

**Ellie Rofe | 55:13**
Yeah, before.

**Robert | 55:14**
Okay. So what's better for you, though? Afternoon or evening?

**Ellie Rofe | 55:18**
That would be great for me so that would be eleven es t is that okay?

**Robert | 55:19**
Okay, sure, yeah, that works for me. We can do that.

**Ellie Rofe | 55:31**
Research how that works for you. Demetrius, fabulous.

**calendar-invite@lu.ma | 55:34**
It works very well.

**Ellie Rofe | 55:38**
Okay, so I will move that, and great. Okay, I'll send an invite in two seconds. Thank you so much. It's exciting.

**rhdeck | 55:48**
Okay, successful hour. Thank you so much for doing this. We'll talk to you in the week. We'll play again this group at the beginning of next week for sure.

**Ellie Rofe | 55:57**
Thank you so much. Everyone.

**Robert | 55:59**
Thank you all.

