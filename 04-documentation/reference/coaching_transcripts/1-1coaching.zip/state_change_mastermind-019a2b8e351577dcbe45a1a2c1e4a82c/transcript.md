# State Change Mastermind - Oct, 28

# Transcript
**Ellie Rofe | 00:06**
Hello, I'm very well, thank you. We have... Yes, I remembered it. I looked at the calendar. I didn't try to turn up at 6:00 am. It's not well, it's nicer in the mornings.

**Ray | 00:07**
Hello. How are you doing? Right? Skiing, chilling. Of course. You guys just had your daylight saving shift, right?

**Ellie Rofe | 00:33**
Yeah.

**Ray | 00:33**
Okay, well, I hear where you're coming from, and hello, Demetrius.

**Ellie Rofe | 00:34**
Yeah. All good. I have to try and remain positive as we head to winter because it is my least favorite time versus...
I know you love it, but I'm like, there... [Laughter] no.

**Robert | 00:54**
Robert, hello.

**Ray | 00:56**
And we could just... If you might just be opening with a Demetrius... I appreciate that you and Li had worked together. You're... I don't know Robert, if you got and saw it, but Demetrius's website is, I think, just so much better, and I think it's telling a story.

**Robert | 01:15**
Have have not gotten a chance. I'm going to look it up right now.

**Demitris | 01:20**
It's at a level that even I cannot believe that I own this site. Yeah, and the truth is that it's a huge walk from Li. She helped me a lot. She actually redesigned the main header and gave the guidance for the rest.
Not only that, we had an incredible conversation giving me some great ideas how to move forward. I thought I completed this step, and I'm planning to do the next step with [Laughter] the next round.
Hopefully, this collaboration is not the crocodile in your time schedule.

**Ellie Rofe | 02:03**
[Laughter] I love the expansion.

**Ray | 02:04**
Very cool. I'm sorry, what did you say, Ellie?

**Ellie Rofe | 02:12**
I said, I like the expansion. I just said to me, I was like, be lazy, just do the, you know, hero and leave it at that. But there's. There's more. I love the early believers. They saw tomorrow first. Nice.

**Ray | 02:30**
Typical. All right, well, let's go around the horn. I think today is Robert's hot seat, and, so with that in mind, let's check in what was true today that was not true when we last met a week ago.
Ellie, can we start with youm?

**Ellie Rofe | 02:49**
So I've had a lot of pitch-heavy pitch work for these clients that were a little bit too early and a little bit less aware of commercial reality and stuff like that.
So it's been some heavy going. I finished, and I said to Ray last Friday, "I have been neglecting sales endlessly." So, I committed to posting on LinkedIn every day. Seven posts between last Friday and by the time I speak with Ray this Friday coming.
I'm hitting every day so far, which is nice. The very first posts I made got me some introductions and potentially a talk somewhere. A bit of a place in Harley Street. Basically, a bit of a life sciences spin-out of Harley Street.
Randomly, I wish you could... Maybe you can, but I haven't worked it out or haven't looked into it. But I got a Calendly booking from someone who has not interacted with anything online or hasn't been tagged or anything, called Madison Maxie.

**Ray | 03:56**
Two two.

**Ellie Rofe | 04:00**
And creates these incredible things. She was Forbes's 30 under 30, doing soft electronics and electronic textiles, which is really interesting. She got the Peter Thiel Foundation award and stuff like that.
So she's really interesting, and I'm slightly nervous about it because she's booked in for next week. If she turns up, I'm slightly nervous about it because she has been asking. About two weeks ago, she asked for recommendations of people who could help her with pitching and presentations. It looks like she might have gone through 17 recommendations already.
But yeah, I'm guessing it's from one of the posts that came out. That's really cool. I've been asked to go and speak at the Crick Institute in London, which is a very prestigious thing. I've been asked to speak to their entrepreneurial group.
It's almost like marketing works if you do. I was just trying not to overthink it too much and just get stuff out there, basically because I was just getting my own head way too much.
It's feeling good. It's feeling free. There's movement happening, and hopefully, I'm clearing some stuff off the decks. With the pitch that I've just finalized in terms of the actual pitch deck, I'm speaking with them tomorrow just to do the final review of that, and then I'm going to pitch them a retainer.
They were a free client to get this pitch done. I've way overdelivered on this because it's been a nightmare. I'm going to say if you want help while you're pitching. He had like 30 versions of his last pitch, and it was bad.
Then you can give me, I don't know, two grand a month for a phone call each week and a turn of the deck or something. I don't know. Or a limited turn of the deck, but that's my plan. So it's good. Things are feeling a bit more energetic, I would say.
I'm going to put it in for December at the earliest because I won't be back in the UK. I'm flying in about ten days.

**Ray | 06:00**
Super, you know, when's the talk at the crick?
Okay, got it, yeah, but there's, yeah, that that's super cool gratuations, all that. Demetrius, can you check in with the sir it was true today. That's not true a week ago.

**Demitris | 06:27**
Many good things are true today. Guys, the first thing is, I have a new website. I couldn't even imagine. We had the second meetup for building digital twins, which was very good. The vibes I had participating in this event were very cool.
Likely MIT is presented and created the content from this video, uploaded it on YouTube, and created the shorts. Already scheduled the shorts for the next couple of weeks and I've done some scheduling improvements for my content during the weekend.
Now I'm starting to schedule my shorts to be published on LinkedIn and YouTube relatively. And yeah, I'm mostly focused on distributing content. I'm learning more about the digital twins and the nodes graph base and mostly around the Neopher.J, which is the main platform I'm using to go and build the thing.
In terms of distributing my content, I have the sense that I'm on the right way, but something I'm missing, but I cannot recognize what it is. But usually what happens is I find what is missing from the experience of publishing by reporting the data.
So I will wait for at least one week to have a review and see the performance. And yeah, that's it. I mostly do study at the moment. No shipping, but study and sales are important.

**Ray | 08:22**
And by the way, I was at the LU and I both were right at the meetup, and it was a banger, that was very much jobople done, sir.

**Robert | 08:34**
Thanks.

**Demitris | 08:35**
Thanks for being good guys.

**Ellie Rofe | 08:36**
Yeah, it's really high quality stuff.

**Ray | 08:41**
And Robert, what is true today that was not true a week ago.
And how can we be of service in helping you have an even better one for sure?

**Robert | 08:52**
True today. That wasn't true a week ago. I finished pretty well with a client that I had started with last week, and then I was aiming to have it done by today, which I actually did manage to accomplish.
It was just an interesting experience because I just felt like it was a good run from starting something from absolute zero to having a project that's fully up and going just like that. If that is maybe an encapsulation of where I can help somebody in that particular situation.
So it felt like a good way to set up or to just exercise that and then to see where I even stand with it. Within that context, I felt like I just did every part of it a little bit better than I had done in the past before.
I found an opportunity to innovate certain things out of it. Another MCP tool in certain things, but without derailing the project itself, actually to the benefit of the project. I wouldn't have been able to honestly finish it if I hadn't come up with a few things that way.
It just gave me the feeling that, by reading the client a bit more, I get a feeling of what value they are getting out of it and then how that ties into... How did it feel for me to deliver that?
Towards the end, I asked myself the question of how much would I charge for this next time if... But in that moment, though, when I'm tired and after I've delivered it, because I think that that's a good time to ask that.
It's very easy to answer that question after, I think, you've delivered the work for somebody. It's hard to answer before. It always seems like it's hard before.
It's like, how much should I charge somebody? It's just think about last time you finished the work, how much did you feel? And I think, yeah, so there was that, and I've been just like a lot of stuff. Xanoscript got updated, not just that, but the metadata API, so I've been trying to keep up with the changes there, to be honest. It feels weird because it's the hardest money I've ever worked for, probably just the measly sums that come from being a Sass founder. I suppose it's not that much like you.
You're doing a lot of work and trying to keep up with this thing for a group of people, and some people even want to play hardball when it comes to how much I charge and they want meetings.
It's funny because for me, I don't even want the money. I would rather do an hour of consulting with somebody and make more than I do in the whole month of the product.
I had some people, I think, play a little bit of hardball with me, and then I would just... I have so many messages coming in that I would just let it slip, and then something would pop up where something has to change in the MCP, and then all of a sudden I get a message.
It's very polite this time about could you please send me that link again? I would like to be your customer. Well, I don't know if I want you to be my customer because I don't know if I... I'd rather spend an hour on the phone with that person.
They're more pleasant than... They don't have to do as much and they pay more. So, good things, I think in general, good problems, in certain ways. Yeah, trying to move towards, I think, a market where there are people who have more money, and I'm trying to really truly set up like. Or get put myself really in where I need to be in the system in order to keep doing... Keep putting out there into the market more of whatever's generating the biggest opportunities for me, which seems to be always generating. Putting out ideas in the form of videos, the calls, like the weekly calls and so on.
I've been trying to set up basically Opus clips and really try to get that going because I think if I look at all of my efforts, that's the one that has brought me the most attention on YouTube.
It's allowed me to build relationships with people. It's allowed me to get feedback from the market. So I want to try to put more energy into just making that call better, take a few lessons from your success, Demetrius, with just being more prepared for the calls and maybe preparing a presentation or something along those lines.
I think if I think that there's a good return on investment there potentially and the energy I put towards that. But what changed in the last week is pretty much more of the same. I had a call actually with Mark Peterson yesterday and today.
But again, though, I do feel that it's the itch to move on to something else. I almost just want to not leave it all behind, but I do want to move on to a different market. I'm kind of... I don't know, I feel like the word "sick of Xano" comes to mind, but not necessarily sick of Xano, maybe sick of the market.
I just feel that... I mean, it would... It's sick of a certain type of project. I like long shots. I hate long shots. Every time it's this story about, I'm gonna make this thing, and it doesn't exist, and we're gonna... It's gonna be tough, but we're gonna make
it. It's like, no, I'd rather talk to a hospital maybe that has a budget. And, you know, I want to do work for a hospital. That's what I want to do. Work for something that's so big that it's pennies to pay me a lot relatively.
Like, what would be a meaningful amount of money rather than being... I think you guys know the feeling when you're just trying to hang in there with the founder and so on.
So, yeah, that's what I'm up to this week relative to last week.

**Ray | 16:16**
Cool. Okay, well, then, turning from the past to the future, how can we be a service team then?

**Robert | 16:25**
How to be of service? I may, maybe I'd like to ask. I feel like I maybe the thing that I could benefit the most from is actually because everybody's out in the market. Everyone here. I think in the last six, seven days, every week we meet and...
But every time we meet, between every time we meet, all of us have been out on the market. I think in a way that's actually very illuminating to each of us. I don't think a lot of people, not everybody, are out there on the market, but everybody on this call is.
So I'm kind of interested. What markets would you think would be interesting for me to check out? Because I'm a little bit blind to that a lot of the time. I follow a lot of my own interests, but at the same time, I can say that I'm a pretty curious person. If Ray, I think that the universe thing is... I feel that something is behind that, that's probably what I'm looking for, but I wanted to see in general.
So along the same lines, I'm always staring at Xano and then you're telling me about Universe. For all I know, as soon as I make that real decision, I could have a whole other business on the other side of that, and I could turn around and just say, "Hey, I wish I did this two months ago."
So, I'm just making sure that I'm not wasting my life totally. And maybe if I can make it choose a new direction as soon as possible then in the spirit of that, what directions do? You all see, perhaps out there, really, because maybe it's something that you saw in the marquees, say that you think is relevant to me or not, or you just see me doing something. You're like, yeah, you know, you would be better off if you would do this instead. I would be more than happy to get whatever feedback or thoughts that are on your mind.
If there is anything related to me. I'm sorry to put everybody on the spot.

**Ray | 18:50**
Okay, let's. Let's go around the horn here. Li. Can we start with you, ma'am?

**Ellie Rofe | 18:58**
So to clarify, the NCP server with Zano, it feels like the type of work you're getting from it is a bit scratchy and a bit sort of hard work for less money, basically.

**Robert | 19:17**
Yeah, but it attracts. Well, so far, I would say just at least it's, it attracts the type of person who wants to reduce costs in a lot of ways, or a person who wants to get rid of things that walk on two legs, basically, right?
So that because that's what Xano kind of lets you do. So yeah, there is like a recurring theme there and which I'm not sure if it's totally. I think partly I think it's tied to the technology in some ways.

**Ellie Rofe | 19:55**
Yeah. Okay. So I can totally see. I mean, I know obviously large projects are built on Zoho, but I can totally see where there's a lot of very small, certainly budget and size projects that are existing there that don't. They either don't do enough for a business, or they're working for a business that is too early or not profitable enough to be a big enough project for you.
I think when we spoke a while ago, the universe stuff sounded most potentially lucrative in that. Part of the reason I loved it is because I don't know where... Partly because I think you had an inn, potentially through your dad.
When we looked at the mid-range existing SAR incumbents, I wondered whether you'd be knocking on doors that already opened months ago versus these more, I guess, legacy technologies where there would be people who don't even know that this can help them, or there'll be people who know that they've got a problem but they're not getting a ton of developers through because they're not in that same ecosystem in the same way.
So, I think it might be that you just... It's a less saturated market potentially. I don't know, but it sounded interesting to me because it seems like a lot of these... It's larger institutions, but some of them are small enough to still be able to turn it around quickly rather than going to HSBC and doing this, which is obviously vast.
This private hospital has this system. I can help them do this, and then I can replicate that with other people once I've done it. So, it sounded really interesting to me in that area. I don't know enough about the stage of the market around MCPS.
I know, broadly speaking, I'm guessing it's still largely early adopters, but it feels like the vast majority of... I think we're looking at FreshBooks or something, or you had something like that up on the screen when we first looked at it. It feels like those places, people are more likely to have developers on board who are doing this or the networks who have already found someone to be looking into this. I could be completely wrong on that.
That's a massive assumption. Whereas the place you were looking at with the universe sounded like it was a potentially fresh market with a big need and potentially a big upside and reasonable budgets for this stuff.
The need because they are locked into these systems. So it's much more rational for them to do an upgrade via this work with you than it is to try and redo the entire thing. I just felt like you could give a big lift for relatively little effort comparatively and for relatively little budget.

**Robert | 22:53**
Yeah.

**Ellie Rofe | 23:02**
So it sounded really interesting to mes.

**Robert | 23:06**
No, yeah, that's actually a good way to frame it. It reminds me of our conversations around it. I would say that, yes, you're right. The way I look at it when it comes to the universe is that I don't really have a way to look at it.
That's the thing. I think that I don't know, really, and maybe I'm... I suppose maybe the only ways to know are to just do conversations with the market. So it's kind of like the chicken and the egg thing.
But, yeah, no, I don't have to answer, so I'm just... If I did, I would so, yeah, thank you.

**Ellie Rofe | 23:50**
Yeah. Try and talk to people about it. I think you'll get so inspired. You have a brain that sees connections and opportunities. As soon as you start talking to people about something and you know the technology really well, and I think you...
I think the other thing is wondering, like, what inspires you? Do you want to be... I think we talked about this. Do you want to be the person who is giving a talk about how you can breathe life into these incumbent systems with the magic of MC/P and AI and stuff like that? That seems like a really interesting place to be. This system is 30-40 years old.
It is older than a lot of the people that use it. It was clunking along. Here's what we did with it to make it bring it into the age of AI without having to radically redeploy a load of different software into an incumbent system.

**Robert | 24:46**
Yeah, no, for sure there are. I think I'm... Yeah, I'm just looking for... I just want to discuss it. I think this helps because this helps put something even in the middle. Even if I put it out there even just in the middle then because otherwise it just exists in my head.
So yeah, this is helping me. Thank you.

**Ray | 25:10**
ID just can bring you into the conversation.

**Demitris | 25:13**
Yeah. For would... If I may, can I ask, what is the current market you are running? You ask for new markets, but my question is what is the current one?

**Robert | 25:37**
The current one? I would say the current one is people more or less focused around Xano-based projects. And I would say maybe more if I was going to actually summarize what the market is in general.
It's for me maybe just people who are looking for faster development processes in general to just go faster in development in ways that are not just born from either hard-won hands-on experience and or further boosted by the tools that I use, right?
So whatever. Whatever way. I think that's usually... I'm not sure if that's really so then when I look at the market, it's just whoever's attracted to that could be sometimes it's a fox or a chicken. It could depend.
But mostly because I'm using Xano a lot and I'm putting out that messaging into the market. I usually who ends up responding to that are people who use Xano, which is fine. In and of itself, it's not an issue that they use Xano.
I think that I'm trying to, I suppose, stay realistic about the idea that there are bigger things out there than Xano. There are probably the companies that would really be able to lift me up in a very dramatic way, like to close a huge deal or to do something that's very meaningful. I feel that might be a company that's not on Xano or something totally different, but I don't know, I'm not really sure.
But yeah, to answer the question of what the current market is, I think it's mostly SBS they're using Xano, usually wanting to clean up something or they want to start a new project from zero.
My promise is I'll do it in like two weeks.

**Demitris | 28:14**
Do we guys, what is the target group for Xano as a company? Pri disappeared here.

**Ray | 28:30**
My goodness.

**Robert | 28:31**
Never seen again.

**Ellie Rofe | 28:32**
That I know. [Laughter] I mean.

**Robert | 28:36**
And nobody knows that one.

**Ray | 28:40**
Yeah, I think. I think they're going to have their agency held tomorrow in the wake of 2.0. But I remember the last time they did one of these agency things. I have a monthly meeting with her BP of marketing, and I ask this question repeatedly. I ask two questions, I think are the unanswered questions. Who is Xano for? What's the job to be done?
There's nothing, there's nothing. There's a lot, I think there. This can be a lesson for us all, okay? Because I don't mean to suggest they are bad people because of that, but it's a super common thing where people are totally afraid of pigeonholing themselves or typecasting, right?
It's for everything, but as a result, there's probably a market. So Robert's point is a point well taken. In your question, you were asking me this, which is exactly the right one, because it helps us form a theory of the market.
Well, you're in Xano. It's actually for this, and therefore it was for this kind of company, and it's just all over the freaking place, and that's very characteristic of early markets, right? You're just trying to find...
Okay, you'll go out in the market. Anybody who's gonna give me a bite, I'll take it. But, yeah, it's very hard to scale past that. You use that to discover who's more likely to bite, and then they give you some trust, and then you're able to build on that.
Xano has not really escaped that. I think part of that was a little bit of the bad luck of just as they were getting hot, the low-code market collapsed all around them. That becomes the bigger problem: I think that being a consultant working with a vendor, you make your money on the first derivative of that company.
So when it grows, you do well, when it grows nonlinearly, you grow. The problem is that Sam wouldn't grow up. It's going to be low double-digit growth for 2025, and by low, I mean like you probably like 25-30%, maybe for the year if they have a banger Q4.
A lot of that's sitting in what's going to happen in Q4, and I think, like I said, the VP of marketing over there is more hopeful than I am about what that number looks like. But leaving aside that projection, there's a bigger problem: what's the marketing, and how can you align yourself with the marketing? Which is the question you're asking, which is totally the right question to ask.
They don't have an answer for it, and that means that... Because they're requiring people to come in with their own theory of how it's going to work. It tends to be very sales-oriented at the high end, which...
Really all sorts of randos are coming in on the enterprise side or coming through because that's where they happen to have their connections. A lot of them, by the way, were Ellie. A very heavy French contingent, a very surprisingly large percentage of Anne's revenues come from France.
But the question you're asking is totally the right one to be asking. It's one that is a theory of mind that you should have. But any vendor you're working with, including late node, anybody else who you'd be working with, and
sometimes the answer is going to be they don't really have a clue in that regard. When that's the case, you should know that, and then you're going to decide, you know what you're about, sitting on top of that, and know that they're not.
That is not a way that you're going to be able to ride, right? It's not pulling you forward in the same way. Li, can I ask for your more marketing professional perspective on that question?
Because I've blabbed a little bit.

**Ellie Rofe | 32:18**
No, as Demetrius was asking questions and Robert was talking, and then you've consolidated it all. I was thinking, I remember speaking with Zano at the low-code, no-code thing. I can't remember who I spoke to. I watched a little bit of the 2.0 release the other night.
Even that, I was like, "Yeah, they've kind of rushed through some stuff. They've shown that it can do some stuff, but I don't know who they're talking to." They even showed the example they showed on that 2.0 release, I was like, "Right, a pet adoption app?"
Who are they talking to? I don't understand. At this point, it just seemed like a cute example to put up there, but it wasn't targeted. As everyone was talking, I was thinking, "Who are you building? What real estate are you building your future on?" Li,
is shaky. The universe, I don't know, but it seems like it's such a long-term incumbent and people are locked into it that it's pretty solid. It might not be sexy, I don't know, but it's pretty solid.

**Robert | 33:28**
That's sexy, not.

**Ellie Rofe | 33:28**
[Laughter].

**Robert | 33:34**
But that's why it's... That's probably why there's money in it because.

**Ellie Rofe | 33:39**
Yes, I saw.

**Robert | 33:40**
Borg.

**Ellie Rofe | 33:43**
I connected with this branding agency who are their website is boring dot industries and they work exclusively with like people in logistics or, you know, they do a bit of biotech and stuff as well.
And it's like, yeah, we don't work with consumer facing brands, we don't work with SARS, we don't work with anything that is considered sex. We work with the boring industries that everyone else neglects.
And, you know, they are doing really well.

**Robert | 34:12**
Yeah, I was... I just wanted to say this because it just pops up to my mind about Zano and disconnects in my head a few times this week.

**Ellie Rofe | 34:13**
It's a really nice turn. I mean, yeah.

**Robert | 34:28**
And just want to say that I feel like I disagree fundamentally with their marketing approach, which is to launch as if they're launching a movie.
To build up to this whole thing two months in advance. I think it's just wrong because movies, when you launch them, they have a huge box office the first week, and then they just go down, and then until they trickle away, and then they show up in the DVD bin, years later.
But it's opposite. I think it's supposed to be that you're supposed to drum it up over time, and then it builds up, and then it becomes huge. I got... I think maybe... Yeah, so then, which, to your point, makes me wonder. It makes me feel...
I think maybe fundamentally, it's this shaky ground because if they don't know how to really, I think, build this whole thing up, then where are we going? I'm aware, and if I'm attached to this thing as well, where is it taking the practice that I'm trying to build?
So yeah, I just maybe that's what I think, maybe that's the best way for me to describe what was not landing well with me about the way that they've approached it as a whole. October 22 and October 22. The world's going to change on October 22nd.
It's like, no, it's not.

**Ellie Rofe | 35:50**
And was like watching QVC as well, because they had scripted it all, so it was really awkward. It was like bad actors. It was.

**Robert | 36:00**
Yeah, it's like and it's like trying to act like a AA big company when I don't think I think that it would be better served by incremental changes very close to the market with the people slowly over time and you feel like that fast feedback loop. I yeah, I don't know, it just I don't. Something feels awful about it to me.
That's the best way for me to encapsulate it.

**Ray | 36:26**
So if I might, I've had to go through some self-therapy. Then I actually used Claude a little bit because I was trying to put together a memo to the CEO over there about a couple of the concerns I had, and then they started owning...
Okay, where I'm coming from on this. I put that into Claude as well, like, "Help me out, remove my psychology from it." It gave me really good advice, which is shocking. Claude gives me good advice.
Yeah, this email doesn't need to go out at all. The email is not about him; it's about you. The thing is, you can't affect them. They've made their decisions, right? So there can be a little bit of commentary about their stuff,
but I think the most interesting part is, can you use it to predict how it's going to affect you, right? Then after that, your decision-making needs to get about what you're going to do. Yeah.
So, I know I've been a sinner in this regard, and I'm owning a bit of my sinning. I had my little cur about my concerns about their direction. But there's nothing to be done about it. They're going to do whatever they're going to do. The only question is, do you think that is a horse you want to ride, right?
That's going to be able to make you money or more a point. How can you ride the horse in such a way that's going to make you money and then redirect your efforts elsewhere? This is where thinking in terms of a portfolio, I think, can be very handy.
Right? There's the famous Bruce Henderson Boston Consulting Group portfolio process matrix about growth on one axis and then cash flow on the other. So, famously, the lower right, which has high cash flow and low growth, is called the cow, right?
Which implies what you do with it. You milk it, and it experiences money for you, and then you have the star in the upper right, which is making you money and growing like gangbusters.
You just keep pouring resources into it because that's awesome. It's creating lots of stock value for you. You have the upper left hand corner, which is sometimes called the question mark, sometimes it's called the DUC. You generally don't know quite what to do with it. Everything in there is speculative because it's sucking up money,
but it's growing, so we're hoping it's going to turn something. This is actually where lost causes live, and then you have the lower left hand corner, which is losing money. It's not growing. It's called the dog,
and what do you do? You take it back and shoot it. So, it's worth asking, of your various leads in mini markets, right? Thinking of them as a portfolio and which way that's going to help drive value, I think, can be useful.
If you're looking at saying, "No, SaaS doesn't seem to be growing that much," great. How does it make money for you? It doesn't make money for you, and it's not growing because it doesn't create equity value.
Well, then that tells you something to do as well, but it tells you that it's not the source of growth, which is where your analysis seems to be landing, and I don't disagree. You might ask,
"Okay, what else is a source of growth because that's what you want to invest in from a sales point of view?" This is where, and if I might,
I think there are two things to be looking for in a market, right? So we're deciding about what something you're going to plot, and I would say it's about base and trend. So base, how big is the affinity for you in that market, right?
These two things don't necessarily correlate, but the universe, for example, has a big base and lots of big companies have some fan for you because of your familiar relationship with the company. You can be putting that to work.
Then what is the trend that you can write on, right? That allows you to take the unsexy thing, the boring company. Well, sorry, boring company, that's Elon Musk's thing, the boring.

**Ellie Rofe | 40:15**
[Laughter] Foreign industries [Laughter].

**Robert | 40:18**
Yeah.

**Ray | 40:21**
But whatever it is that they're doing, and you can add the sexiness to it, right? Because you have the thing that's at this big level up. I think that's where the MCP stuff comes in, right?
I think the MCP for... I mean, you and I have talked about this a little. This is like being an RPA type analogy or robot process automation where you were helping them get more leverage from this asset
in a way that is dramatically more exciting than what they've been doing so far. That's why I like the greenfield stuff. It gets less exciting because I'm going to take an eight-week project and turn it to two weeks. That sounds great in theory, but I'm not sure what this looks like at the end, right?
Yeah, the amazing thing you can do with the MCP stuff is you can take a project and you can deliver it next day because you're taking a lot of stuff out of the mix, right? It's not the whole app.
It's not all the UI stuff. In fact, all the UI stuff is usually what really slows it down, right? So you get to outsource more of the UI to their agents or their chat or whatever. Then, not everyone wants a sexiness, right?
But people who do there's a little more of a premium for that. Yeah, so I look for that combination, right, in terms of thinking about a market. Where do you have the opportunity to have a...
The base, I think, is really what you're talking about, which is what you want to break out of because your base right now in Xano is largely run by entrepreneurs who have greenfield ideas. Yeah, I think even
SMBs that have fires are more interesting than the greenfield ones, right? You gotta head lower than that, like with your collab working deal, but go work for a bigger company, right?
There's certainly more money involved, but usually there's more at stake for them, right? Something that's important, that you can fix, that you can make improve because it's a lever, right?
It's a multiplier. Anyway, I look at your universe stuff, I think it's kind of exciting. I look at the Xano stuff, I think there's a marketing opportunity to be more of the firefighter. You can probably be charging a premium for that.

**Robert | 42:42**
Yeah.

**Ray | 42:43**
And the and there's probably a way to be able to get like the best piece of that business. And then, yeah, you want to look elsewhere. What is your center of gravity? Is it you're the trend guy or you're the base guy?
Then, if you're the base guy, how do you connect trends to create more business? Or if you're the trend guy, how do you connect the trend to more bases to get more business? That's just what's today's right. Obviously, your business can all this goes, but I think that's the way you unlock...
I got to say, I look at this. I do think the MCP stuff is really exciting that way. You've told a couple of stories about how MCP type work was able to get you from this thing takes weeks to this thing takes hours multiple because two weeks to two hours, that's 50 to 1.
Yeah, right. That's the kind of... I want an order of magnitude or better in terms of the kinds of performance improvements that you're able to bring. Is that something people will pay for?

**Robert | 43:43**
It's very interesting. I actually do see sometimes you just do something and it's a little bit of effort and then it has more legs than you expect it to have. I actually experienced that with the VS Zero MCP where I just made this thing. All of a sudden, for example, Mark, maybe one of the driving forces for... We actually have a call next week, and he wants to pay for it, and he knows my rate and everything.
One of the driving forces is like, I gotta have a VS Zero MCP. You gotta tell my team about that VS Zero MCP. I'm like, "Okay, interesting. I like it." So, yeah, I do see where there are little bridges that I can build for people, which then all of a sudden opens up a whole new conversation.
Maybe the same thing applies. I don't know what I don't know, it doesn't only pro... I'm just speculating, but yeah, I think sorry, I was reading warp speed development for the slowest.

**Ray | 44:52**
Yes.

**Robert | 44:53**
Yeah. It's interesting.

**Ellie Rofe | 44:55**
6.

**Ray | 44:55**
I like the term phrase.

**Ellie Rofe | 44:57**
You have a base, which is really slow systems, and you have a special source, which is warp speed development.

**Ray | 44:57**
Yeah.

**Ellie Rofe | 45:04**
Like I think that's kind of... You are ahead of the trend in terms of the speed you can develop at from a lot of people, and you apply that to the most likely base that's there.

**Robert | 45:13**
I yeah, no, I'm putting in.

**Ellie Rofe | 45:16**
That could be really interesting.
Sorry. I didn't mean to ins.

**Robert | 45:22**
I'm I think it's, easier probably to stand out in such a boring market where, most of the incumbents. I mean, not there. There aren't people who are really coming out of school and coming out in droves to learn this technology.
And for me, that just means that there's like some study on the horizon for that, but let me I like it. The it reminds me of the cereal. So the rice crispies, I yeah, I think, I have to get into the market and probably just give it a shot and just lunge into it and took the plunge.

**Ellie Rofe | 46:23**
Can I ask?

**Robert | 46:24**
Yeah, no.

**Ellie Rofe | 46:25**
Sorry, I don't really understand, and this is me being particular. I don't understand what getting into the market means. What does it mean?

**Robert | 46:36**
It means that... Yeah, no. I totally understand. I think for me, my definition of that is probably just the energy that's required to initiate that push and to maintain it consistently. Then, in order
to just keep water and get in water and get it until it grows, I just... So I look at it that way. It's not like a single action, but it's like this constant. So the same way that I might push that to move anything up to a certain level,
I think. But to do it in a way that's sustainable and maybe just pointed in the bright area that it's self-propelling where I've done it in a way that it is in line with my interests and I'm building something at the same time.
So it's like, yeah, it's a bit calculated from my side. I usually try to find some very sharp angle to come in from, and then the rest of the services will be somewhere underneath that umbrella.
But yeah, I did. So I think to me that just looks like assimilating into wherever they live, finding out where they are, and then trying to just make some noise posting about stuff and talking about stuff and then being able to answer emails quickly and get on the phone quickly and just be responsive while at the same time not letting the other parts of the business burn, which is the hard part.

**Ellie Rofe | 48:22**
I sounds really tiring. Could you not just talk to people?

**Robert | 48:29**
I mean, that's probably what it boils down to, I guess, right? Which is what I'm trying to keep it simple in a lot of ways. Which is to let the contender do the work for me in a lot of ways.
I think that's just something I've tried to look at it as, some people message me and they say, "Can you help me with this? Can you help me with that?" Whatever, and I'll just send an invite to be on my calendar.
I'm like, "You know what? If you're on a calendar, then at least I can..." We have our time coming up for this, and then we can talk about it then. Then because we have a call, I'm going to spend... I'm going to be really motivated to spend 20 minutes before the call, reviewing what you actually sent me.
Because otherwise, I don't feel the motivation to do this. Because I know that I don't feel this feeling of being rewarded for it. This is not otherwise, it's not good for a relationship.
Because you feel you don't know if I'm ever going to address this thing. So, yes, it probably cognitively the best way to think about it is just it's a call. So, yeah, I am... It's a good way to get out of my own way maybe to think about it more that way.

**Ellie Rofe | 49:42**
Yeah, I think talking to people who are running universe systems and want to somehow drag them into the 21st century sounds like a lovely way of developing this.

**Ray | 49:58**
The, III little more brass tacks. How to get into the market or how to get those conversations right. I think there... You have an asset there. There's a little bit of you... You're getting into a forum, right? There was a discussion forum for the universe and for its customers. There are a number of events, both in person and virtual, that are advertised on Rocket Software's website. Their annual conference was this past summer.
But this... There's other stuff that's a little near at hand, but that you could be looking into here, but it's going to take effort, right? It takes effort to go and reach out and start to make a dent in that market and to have things that are adding to them.
You wait long enough, there'll be another MCP player out there for it too.

**Robert | 50:59**
Yes, somebody else to lunch.

**Ray | 51:02**
Rather be first if something else will come along, you're not going to be alone the whole time. But like, if you are the first, you get to build compounding advantage that way.

**Robert | 51:12**
Yeah, now I'm becoming scared, which is fine. You know, good to fill the a phmo.

**Ray | 51:19**
Yeah, well, yeah, I would not wish you to feel fear. I wouldn't wish you to feel a little pinch, a little goose, right? To go and, like you say, get into the market, actually have interactions with folks and do those conversations, which will turn into ideas, will turn into content. You can then feedback in the market that will improve your reputation, right? The wheel turn.

**Robert | 51:47**
Yeah.

**Ray | 51:49**
And nothing says you need to be limited to this. I kind of suspect that once you're working in two markets at once, you're going to get a better perspective. That will make it a lot easier to add market number three.

**Robert | 52:02**
I think maybe that's the part that I'm afraid of. Like my brain exploding almost like when I think about adding another... When I think about adding another market, it makes the sides of my head almost feel... I feel pressure at the sides of my head.
But I know I can take it because I feel the pressure right now. So I don't know what the difference is, because I feel anyways, under a lot of... I feel the constant strain of always learning and thinking.
I got more used to it, I suppose. I mean, exercising that muscle.

**Ray | 52:32**
So that'll happen. The other thing that will happen, though, is as you increase the number of markets you... Or put it a different way, as you increase the number of bases, right? Because what you're writing is a trend, you're going to find that you're going to be able to talk smarter and smarter about the trend, right?
It's no longer only in theory, it's going to be about how it actually applies. It's not just how it applied in this one market; it's how you've seen the thread that's running through you now become smarter and more subtle.
This would be true, by the way, if you got a based strategy, right? You being able to talk about and people who are really know their way around the universe. I'm sure they're able to talk about... I don't know.
I've seen this stuff come and go, and this is stuff that's useful, right? That'll be a conversation you're having that you'll have in the assignment of that too.

**Robert | 53:20**
Yeah, truth.

**Ray | 53:23**
But my point is the brain explosion is because you're looking at it as additive, right? You're adding more concerns you have. But in fact, what happened is as you do this more, it will... I mean initially it does grow a bit because you have more detail, but then as you see more of the trend lines, it starts to shape up behind you.

**Robert | 53:45**
Yeah.

**Ray | 53:46**
And continue to grow. It will, the detail of how, for example, Thezano situation works will become far less important than the way you're driving things forward here.

**Robert | 53:57**
Yeah, no, I think this is probably the best thing I should do for a lot of reasons. I think I'm just trying to... There's no other way. If I don't mention it here or talk about it, then it'll just slip away too far down my priority list.
Maybe this is a way for me to just reaffirm that this is a good direction to go in. I guess I'll have to just do it.

**Ray | 54:34**
And the kind of expertise we have at the next MCP summit or AI engineer or what have you, the very next one, but at a time of your convenience that you're the kind of person who's going to be sought in those circumstances because you understand this and you're bringing this into business environments. Lots of people working on high-end tech that aren't working on a business environment. List of devs who will go and talk about their very cool stuff. I was watching the MCB Developer Summit, and it was a combination of people who were relevant to the market and people who were working on some really weird, neat stuff.
You're going to be relevant to the market side, and I gotta say those people are richer.

**Robert | 55:13**
Yeah. I will say one thing, though, which is I thought I found to be interesting. I was apparently on one of their slides at Rocket Software. I was on a slide. It was like, who's posting about Rocket and stuff?
Just like my dad's in those meetings and stuff, so I was like, "Robert, look." It's like, "Isn't that your son?" The funny part was they're totally overestimating how much I'm making as a business because they're taking this information from Salesforce and everything.
They're like, "Here, the people in the markets." So that's another thing that maybe stands out as a clue for the small amount of posts that I've made and efforts that I've put into it that I can end up on a slide. I don't know if I've ever been on a Xano slide. There's no way of knowing, but probably the answer is no.

**Ray | 56:07**
So maybe. Yeah, Xano knows that you're top-line too. Because if you go to the Xano list of Xano consultants, you're on the first page. Snappy is right up there. Now, Unico's at the top because they're the partners right shortly after that's like Codecademy in a couple of hours.
But like you and George Cooper and BCELow, you're way up there, first page. It's worth noting that you were... Just give yourself a couple of points here for... You are a credible person in these markets and you go into other markets. You'll be a credible person if you... That reputation doesn't last forever if it's not maintained, right?
So, but you are... I think you're probably over-maintaining the AZ side. So, there's an opportunity to maintain it over on the... Yeah, and when we talk about the universe, just because you happen to have it, but it's not the only thing.
I think we can be getting you into more.

**Robert | 57:02**
Yeah.

**Ray | 57:03**
I do think the category question you're asking about is a really good one and probably a good lesson for us all, which is one of the reasons I really like doing this FAS remind.

**Robert | 57:12**
Thank you all. I appreciate it. Yeah, I'm going to... Lisa, now it feels more... It is out of my head, so the next step is to book some calls.

**Ray | 57:25**
Sounds awesome. Okay, great, thank you all. It's been a fantastic hour. We'll be beaten up at the end of the week, and we will do this again next week. Ellie, it will be you and Hassi, and we'll all keep the wheel turning.

**Robert | 57:41**
Thank you, guys.

**Ray | 57:42**
Appreciates. Yeah, I'll see you later. Here. Bye.

