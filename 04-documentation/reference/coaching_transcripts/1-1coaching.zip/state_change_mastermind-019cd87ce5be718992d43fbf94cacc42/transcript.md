# State Change Mastermind - Mar, 10

# Transcript
**rhdeck | 00:03**
How's it going, man?

**Robert | 00:05**
Good, how you doing, Ray?

**Ellie Rofe | 00:09**
Hello.

**Robert | 00:09**
So funny, what's funny?

**rhdeck | 00:15**
Just dealing with someone who had booked an hour of consulting with me and then had an o shit moment when they got the bet.

**Robert | 00:28**
I think that's comforting to hear that. Yeah, that it happens to. Happens to the best of us. I guess I'm.

**rhdeck | 00:39**
Remember being the best of us, but the I am yeah, it sort of happened. Okay, fine, I just sort of need to sort of ask him. Okay, well, what can what seems reasonable. And came up with a solution, and he's just going to pay a much smaller bill. 
And, you know, I've learned an important lesson about how people, you know, don't pay well, but we've all seen it before, right? People just often like book and don't pay attention.

**Robert | 01:07**
Yep, that's for sure. Yeah. I'd be. I think maybe the best thing that this. Nice to see your reaction ti it. So you just kind of have to just laugh about it. I think it's just the part of the game inescapable, it would seem.

**rhdeck | 01:29**
Yeah, it's where, you know, keeping the agent short and, you know, closer in reduces the probability that, like, this is gonna have a super huge, you know, impact. You know? Yes, and I was frankly surprised that a company that small was ready to pay my bill. 
Yeah, because. Well, I just assume that it'll be actually. And this by itself might be a useful data point for you all, too. And I've been wondering about this a little bit. So I've gotten a couple pieces of feedback, particularly about the starter program and a change that it's too inexpensive. 
And I think that because he was a starter. And then he just thought, wait, I can book consulting call.

**Robert | 02:09**
He assumed it would be fund. Yeah, he thought it would be, he didn't. So he didn't think it would be bundled. He just assumed that whatever price it would be inexpensive.

**Ellie Rofe | 02:22**
A tenx.

**rhdeck | 02:22**
Yes, or at least that he wrote in his note back to me.

**Ellie Rofe | 02:22**
Is a monthly price.

**rhdeck | 02:25**
You know, he wrote a very pleasant note. You know, and that was all, you know, there there's certainly no ill will going around here, but it's a, you know, a bit of a lesson. 
And I got to use it as an use the conversation as an experiment, because my AI marketing advisor council, I've got like Rory and Seth Godin and a few other people who are all running debates for me. Or at least, you know, their a avatars has written up in an article. 
You know, they've been telling me they need to offer something within state change that would be like, hey, just offer. You know, a consulting call and you're going to find this actually helps with your revenue even without meaningfully changing the amount of time. 
Okay, that's interesting. And so I tried this out and that seemed like. Yeah. Okay. The price point they were suggesting seems to. Seems to work as well, so maybe there's something in there, so I'll be experimenting with that too, in the coming weeks.

**Ellie Rofe | 03:25**
9?

**rhdeck | 03:25**
Anyway. Yeahmit. So we're just telling the story about the. Somebody who had booked me for consulting last week or so and had then got the bill and I had a coronary.

**calendar-invite@lu.ma | 03:39**
Had a cor coronary with this mean.

**rhdeck | 03:42**
Sorry, a heart attack.

**Robert | 03:45**
Yeah.

**rhdeck | 03:47**
That's good to work through. How to help them dig out of that little bit of hole there and. All right, but, yeah, that's what I was truckling about when I came for. All right, well, let let's go around the horn here is Demetrius's hot seat today, so if we could maybe, you know, we'll start with your Robert, then we'll go to U li, and then we'll get into your hot seat. Demetrius, Robert, could you kick off with you sir was Thursday it was not a week ago.

**Robert | 04:16**
Sure. So, I'm happy to say that I sent off for my largest invoice, actually that I've ever sent. And actually, it was. I ended up, Sour Ray. Like after I did, like, you know, we have our reports and everything, and I actually went and I did more calculations and then I was like, well, you know what? 
I have, like, all the data that shows that I was actually working on it this much, which was, you know, more. You know, like, it was, you know, basically just around 7000, for the week of work. So I said, it's great, I'm just going to send it. 
And then he just paid it the next morning immediately. So I was like, okay, that's amazing. He paid it very easily. Next time I met with him, it was yesterday, and he was like, even happier than last time. I'm like, this is interesting. 
So I'm just very happy. I felt huge amount of. I don't know, like psychologically just means a lot for sure. And really, you know, with some of the, you know, the clients, some of the troubles I've had recently with, like, some clients, stuff that I mentioned, you know, like Scott last week and whatever. It just really helps, right? 
Like this is just ultimately, I think as a business like it, I need to be able to have other opportunities lined up and like otherwise I'm just risking I think like one thing just working with Sky is that I can walk away, I suppose if that makes like. 
And that's the strongest negotiating position in business is just being willing to walk away. Because the thing that would make me sick is the idea of having to. Like needing to go back, right? And like, the only way to counteract against has to stay on the market. 
So I think, you know, I'm happy with the bill and everything, but I'm. I'm more happy. I think that I'm able to keep the wheel turning and be able to leverage my you know, my attention like you know, being able to leverage that negotiate, you know, that option I suppose in business, which is to like, you know, move on to the better opportunities. 
So yeah, just update.

**rhdeck | 06:36**
Typer Cool. Ali, could you check in with you?

**Ellie Rofe | 06:39**
Yes, I'm, back in Britain, so it's been busy and, you know, shifting compared to quiet sitting amongst the cows and the birds. But it has been good. And I've had a couple of really useful conversations. 
I've started the SDP interviews and they're continuing apace. And actually, I've, for the first time, really felt the power of. And just had a fantastic call, another fantastic call with Robert and DIMERIS helping me with the knowledge graph stuff and setting things up. 
And I thinks what's really exciting is I feel the power of that combo. So these human interviews and understanding things on that level and, I think my understanding of sort of psychology and messaging and strategy, but then bringing in this whole data layer and how that's going to combine with it and give us, hopefully not, you know, misleading evidence, but stuff that can help really inform the whole project. 
And I think as much as anything. Impress the clients. Make them understand that this is a proper lift. It's not just, we're going talk to some staff. You know, there's a real tangible thing we're trying to do here. 
So I'm just. I'm really excited by all and really appreciative of both Robert and Demetrius for all their work. Trying to drag me up to their level and understand some of this stuff in more detail.

**rhdeck | 08:22**
Super cool and I'm so glad you guys could get that together.

**Ellie Rofe | 08:26**
3.

**rhdeck | 08:27**
And Demetrius, can we check in with the user and how can this group be of great service to you this week? But if we can sort of start with catching us up on, like, what's true today that wasn't true week ago, and then how we can help your next week be e be as good as it can be.

**calendar-invite@lu.ma | 08:45**
Was this true today? That wasn't true. Actually, one thing is that, I'm very happy for I happened is that. Actually, I have to, recognize a couple of opportunities for improvement into the brain graph. 
And was nice because during the weekend, I spent some time to add the payment system. So before I start charging any person, I think it's, more fair to solve these problems and then make it public first. 
And I found some opportunities for adding some extra features. Some ideas came up from a race conversation back on Friday, which was incredible, and that helped me to recognize what is the approach of it. The approach is not to use the service immediately, but the outcome of having this as a digital brand, which can be an automation that receive a summary for a relationship with a person or, a preparation e mail for your next meeting, stuff like that. 
So to cover these needs in the best way, it helped me to recognize what was as a gap. So I can work on that and cover it. And the other thing that was a big win for me was the opportunity to work on an as project. 
And that's the reason here is that, Braingraph has to be my lead magnet. While my actual service is planned to be two packages one sprint package where I am planning to engage with a person so I can deliver as soon as possible the final solution with a digital brain. 
And the other one, it's more complicated solution for those people who want it just engaged. But the target is the first one. And I ear brought me the opportunity to package this service in a real example. 
So I took all the requirements, investigating documents, the conversations we had ideas from Robert in the previous conversation, which was incredible and working. What is this MVP that can give us that tiny thing we need? 
So I cut off all the around staff. I recognized what I have to specify with a client before I get started working. I saw the need of having the data, the work Ali has done and deliver us with your documentary. It was nice step pushing, the process. 
And so I found the frame somehow not a fixed framework, but the approach to close it as an end project and deliver the sprint, which is. Finally, it can be a ripo on a GitHub that you can download. You can use it immediately and start building as soon as possible. I yeah, that was my experience so far. I'm planning to, do the all the updates, add the updates for my website, personal website, and, continue the promotion. Work. 
So that's it so far.

**rhdeck | 12:41**
So how can we have next it's.

**calendar-invite@lu.ma | 12:51**
It's about the question, how can, discuss, a subject for today? I do have something specific. Guys, if you have any specific idea, feel free to bring into the conversation. Otherwise, maybe. I think what would be valuable for me is some brainstorming around what can be vaable for me to develop during the next days since I'm working on my personal services and the brain graph and the combination of those two. Any ideas, things to avoid or things to push? Donate? Quite generic, I know.

**Ellie Rofe | 13:40**
[Laughter].

**rhdeck | 13:42**
I would have you show us, how you're using Braingraph, how you're using it for yourself. I think you might find that is going to both elicit, you know, development. Recommendations. But hey, this stuff is cool. We should be using this in sales. 
It's up to you. But I think if you were to be doing a bit of that demo, you might be able to, you know, get this ball rolling a bit.

**calendar-invite@lu.ma | 14:13**
Yeah, there was a.

**Robert | 14:15**
Right now, I think. I think that's what you mean, right? Like, yeah.

**rhdeck | 14:24**
It's entirely up to you, but like that. I think that kind of thing. But what you'd be doing is you'd be moving the questions to the front people's brains because they would be reacting right to the things that are that you're putting in front of them on the screen.

**calendar-invite@lu.ma | 14:37**
Yeah, so, here's the nice learning. I tried to use it for me and I found it difficult to use it for the following reasons and let me share my screen. And these are findings that helped me to make improvements. 
Okay, so that's my digital brain. After processing. 24 analyzes already have API to process automatically data. But the thing is, that we need some painpoint, some effort from the user who which is right here on the my prompt. 
So user has to specify what they want, what they need and so on. And I think that this is a problem why it was designed back in that time because of different reasons why is a problem because it requires someone to do something extra. 
It's, you know, it's like an obstacle to drink water. Ideally wanted to for a user just get in here and just upload his documents and ideally just fulfill a couple of information for himself so we know what can be important for them and so on. 
And actually have one strict way for every single user collecting their information and storing them into the digital brain. So this is the first thing I want to kill entirely. And this will help me to apply more of the best practices of creating an olds graph. This creates me an obstacle.

**rhdeck | 16:32**
Because of on.

**calendar-invite@lu.ma | 16:37**
API us its when the transcript is processed we need to specify what is the right prompt we want to use to analyze this input. And this requires me to add some filters into my Zapier, which filters cannot be very strict because I cannot think all the conditions for those. 
So I lost a couple of things. Third thing I found that needs strong improvement is the path for embedding what we discussed for a minute in previous conversation with Robert and Nelly. That can improve the chat experience because at the moment the chat doesn't give me the nice results as I would like to have. 
And the third thing to be added, and this is the most needed is the AI agents who can work asynchronously for the user, using the brain and delivering value to the user. Idea came from a conversation with Ray. 
So looking that I count that I cannot use ring. I wouldn't like to use ring graph for this week. But solving these problems where, agents can use the digital brain and help me improve my business every single day is something useful for me either. Even if no payment received from that, it can be a nice tool to have.

**rhdeck | 18:28**
Could you show us how you use it with web hooks and Zapier?

**calendar-invite@lu.ma | 18:57**
So Krisp creates my transcript. First step, a needed step is to clean the brake lines from the import from the input coming from Krisp. And then here is the problem with the prompts. If I have a community conversation, there are different things I want to focus on. 
So I use different, prompt ID if it's a client conversation, it's a different one. And if it's a conversation with Ray, who is doing my personal coaching, I want different things to be tracked. Yeah, there's it. This is a script code. 
And how user can come here. When they create the their API key from here, they can read here the documentation, but actually they don't have to understand it, they just click this button to copy it and they come here into the code, paste it the code and they just fulfill the information in here like API key, file name and so on. This is the fastest way to build the connection with the platform, with the JavaScript and the game. 
But after to be honest, I had planned for this week to start working the integration with Zapier so everybody can find a node like Crispy here. Find the relative thing with Brain Graph. But I recognized what is missing from the central part of the product. 
So I think it's needed to fixed first and then I move on to these things of like Zapier and make and so on.

**rhdeck | 21:03**
Okay. And, is this the main way that this. I mean, this isn't, yeah, so these web hooks are the main are the way that we can get data into brain graph. Is there any way to get data out of Brain Graph through Zapier as well? 
Like. Do you have that like from, you know, for email analysis or anything like that?

**calendar-invite@lu.ma | 21:23**
Getting data out of it? There's nothing yet. Okay? This is the only way to send data in.

**rhdeck | 21:33**
So right now there's only one point of integration in brain graph, which is your web hook URL and the web hook URL that's what you are demonstrating here, right? That's true because web URLS are usually about, your system receiving data as opposed to an API endpoint, which is usually about your system being able to, you know, push, you know, send data to by example. 
Okay, cool. Well, I've got a couple of offs in the back of my head, but I would love to open it before here. Ellie, can we start with you?

**Ellie Rofe | 22:08**
Yes. I think things have changed quite a bit from when we looked at it. So when someone comes in now, they then start creating their own Zapier setup. Is that right in the onboarding process?

**calendar-invite@lu.ma | 22:26**
When they log in? You mean.

**Ellie Rofe | 22:30**
Are they now building their own Zapier, setup?

**calendar-invite@lu.ma | 22:36**
At the moment in the onboarding process? What they have to do is to create a prompt. So by default, every new user comes here, which is not that good because we want them to live in here immediately with a call to Action to upload your document so they can just upload the document. 
That's all.

**Ellie Rofe | 22:58**
Okay, I didn't [Laughter] sorry, I didn't, [Laughter] I've been trained into the French pronunciations of things. [Laughter] What is it? Zapia. [Laughter] Zapia. 
Yeah, okay, sorry.

**rhdeck | 23:19**
Think that's the way us heathens would do it, but I just love the civility you brought to it with, like, Zapier, you know?

**Ellie Rofe | 23:29**
Exactly. So, I mean, I get it. I think because I use a lot, I didn't mind creating the prompts, and I quite like the idea of being able to push something through different iterations of a prompt. But I kind of see where you're going. When do I have to go into Zapia? Zapia? What do I need to. What do I want to do to be setting up Zapier Zapia?

**calendar-invite@lu.ma | 23:55**
You come here two API keys. You create your API key here, you give the name, you generate it, and then you.

**Ellie Rofe | 24:05**
So that's when I want to create custom integrations like I want every time I get a new transcript and Krisp or something, then it automatically adds it to the brain graph or whatever. 
That's so that I can find my own ways of. Of ingesting data automatically.

**calendar-invite@lu.ma | 24:26**
Yeah, y you need this, JavaScript part, which is copied from here.

**Ellie Rofe | 24:26**
Okay.

**calendar-invite@lu.ma | 24:34**
And then you come here on Zapier. And by the way, this can work. Even with NAN or make doesn't matter. And you just create workflow for you that for my case from Christmas comes from here. 
And then we need just JavaScript to deliver the data to execute the API call.

**Ellie Rofe | 24:52**
Yeah, got you. Okay, interesting. So there's less there's going to be less functionality in terms of how you tell it to process the data, but more in terms of how you can get the data in there in space. 
Okay. Interesting. I think it's. I think it's pretty cool. I mean, definitely that automation layer of saying if I presume Krisp is one trigger, but there will be like if I drop a file into Google Drive or something in a folder or whatever, then that can be another trigger or that kind of thing. 
And so people can just start gathering, the source of their brain and just keep adding to it with low friction adding rather than going in and uploading documents and stuff like we've done before. Right? 
Okay, cool. And then once you've done all that, what's the chat like at the moment? 
What is the thing that you were saying?

**calendar-invite@lu.ma | 26:03**
At the moment, yeah, sorry, could you repeat it?

**Ellie Rofe | 26:05**
I don't like working with this? Well, you were saying you don't like working with it. And I understand the prompt is a frustration for you, although I still think early adopters would be quite happy to fiddle around with problems. 
But the. What is it about this that you don't like working with?

**calendar-invite@lu.ma | 26:32**
The first thing is that even with my existed. Krisp charts. I'm not getting into a conversation, so I have the chat it's nice to have, but I'm not using it.

**Ellie Rofe | 26:41**
Okaymm.

**Robert | 26:49**
And what do you mean by that? You why are you not using it?

**calendar-invite@lu.ma | 26:55**
You can have a conversation with the entire graph here, so you can bring questions and get responses based on what is on the graph.

**Robert | 27:06**
And I know, but I'm saying that like you're saying that you have the conversation, you get the transcript in here, you don't want to chat with it. Because of what? Why?

**calendar-invite@lu.ma | 27:16**
E because I don't find it useful at the moment. Yeah, I'm. Or at least I don't have, ideas to bring into the chat. Like, for example, a Ray suggested this idea for recognize, a mental model, for example, or create a mental model that uses this brain for stuff like that.

**Robert | 27:43**
Well, I think that this is here in front of us. I think that this is confusing, like, in the sense of like, I enjoy making these like these knowledge graphs. Like, I mean, in terms of like the visual aspect of it. 
But I think that, at least for me, like the more that I put that aside as part of it and just focus on, like. Okay, fine. Like, it's making this graph and the graph itself, like, probably looking at the shape of it, like, has some kind of utility, but ultimately I'm not going to use it in this form. 
Like, I can't do anything with this. This is just looks pretty to me. I have to. And I think maybe there's something in the sense of like. So what is the experience that you're aiming for that you're trying to ultimately reach? 
And it gets hard to obviously to, you know, it's going to be hard to imagine something that doesn't exist, obviously. But that's the question is like some type of we need some type of clue towards where you're you know or you know, whatever your intuition tells you, your experience tells you that you want to point this towards not this here. 
Because unless there's something that, you see, you can do with this, that I haven't, you know, been able to like to me, you know, I can't navigate this, but that's fine. But what can you use? What do you want to use?

**calendar-invite@lu.ma | 29:08**
Here's the thing. It's different. I question what anybody can do. And different than what I want to do. For example, for me, I find the most useful at the moment, feature which I really visited every single day or every morning actually where everything is processed and completed is the outcome from these three agents, which is quite confusing. The UI here, it's totally understand. 
I have to work on that. But the functionality of it is that there are three different agents. The first one is responsible to recognize business opportunities, the second is responsible to recognize blind spots, and the third one is to recognize content ideas from all of this brain and store them. 
And coming up with that, I find it useful to create an agent who can track my tasks. And actually not the task what I have to do, but the task in terms of what I promised to do till what time. So I can have a reminder automatically saying, hey, you promised Ellie that you're going to deliver this thing here and it's today. How are you doing that? These are the good.

**Robert | 30:32**
So that's a good thing to maybe to. I would say that's actually a really good way to look at it in terms of just like in terms of a practical benefit, right, that you're trying to bring to the world like I mean, in a sense of. 
Okay, something that keeps on top of, you know, reminds you of, like, whatever commitments that you've made. And so what does that start to look like? Okay, and need to email you, does it need to be like this? Probably not, doesn't it? Might not even need to. It just needs to be, you know, less of more of a crown job. 
And so an agent that has access to this brain. In my opinion, like, if we're talking about solving the problem itself, right? Like. I mean, removing, like, everything else from it. I would say that there's. 
I mean, that's the way I've approached it for myself because by me solving that problem, it reveals to me how I'm going to how, you know, what are what is involved in solving this. And if I'm. And in me solving it, I get to be of more benefit to the people around me. 
So there's two birds of one stone. I think, like, if you kind of aim for those, you know, those wins, you're solving the problem in and of itself. But that's just how I look at it.

**calendar-invite@lu.ma | 31:51**
Yeah. It's a good idea that. I was thinking of, integrating with. Agent platforms like, you know, Zapier for the AI agent feature. Mind, something. It's mine with mine studio, the other one I found with great community. 
And so people can have their own agents who use their own brain. And the brain lives in here.

**Robert | 32:30**
Yeah, I mean, like, what's stopping you from going for that? Like, do you think the I mean, nowadays more than anything, it's like we just heard this phrasing last week. It's just a prompt away. So is it.

**calendar-invite@lu.ma | 32:53**
It is, it's, where most of the time is spent is on making decisions while I'm working with Claude Code, for example. I say, okay, we have to work on that. Let's go this way and doing all of this part because I don't want it to go and kill anything. 
And I recognize a couple of things that I don't have great understanding so far. So I have to do my study on that, and that takes some time. And these things pushed me a little bit back. And at the same time, I'm trying to, you know, run events, do the job on social media so I can engage with the audience. 
But the truth is that if I prioritize the product and make this as the story to be shared, which can save me the time and the effort for the second activity at the same time, I can have the progress.

**Robert | 34:01**
Yeah, I mean, I think that there's a lot to being able to solve the little things. I mean, I look at it very simply, like for a lot of this stuff, its just like. I mean, for all the stuff that people canarget, you can to build a huge business and everything and whatever. 
But like, ultimately, can you trust. Can you make a system that sends out one e mail with the proper context and the proper phrasing? And that doesn't make it look like you had a lobotomy. Like, you know, like you the. That you don't have to go four times back and forth like just that, right? 
Like how much to be able to just solve that that's the foundation of everything else. I feel like build on top of it. And there's a lot of things there's a lot of qualities of that solution that apply to the other problems that were that you're trying to solve as well. 
So to me, that's a good area to fol. Like, you know, you start to solve those things and you start to solve. Eventually, before you know it, you've solved everything. M.

**Ellie Rofe | 35:10**
When you're thinking about the end user or talking with the end user? Because I think that I don't think these have to be mutually exclusive. It's just intriguing to me as to whether people are saying, right. 
I think I want to use this for, like, operational stuff. I want it to take my, like, executive function stuff off my plate. Like write an email or keep up to date with my diary or tell me when I've not done something or whatever. Or like there's other ideas you've got here, like generative output, like content ideas and stuff, analysis, brainstorming. Do you have an idea of what people are really looking for from this sort of enriched knowledge that the AI is given? Or is it just all of the above? Which is kind of like I feel like the AI answer, because it can do everything to an extent. 
But what? What do you think people are looking at?

**calendar-invite@lu.ma | 36:13**
Yeah, good. CAD Nice question. I have no, idea to be and I want to be honest, what exactly they're looking for, because I didn't have engaged with many people. The only one I work with. He wanted to build a framework. His own consulting framework and wanted to make it an AI brain. 
So we engaged to do that. Now what I see is that there are a couple of social media consultants, LinkedIn consultants, personal brand consultants and all these things who they talk about second brain, digital brain, showing these fancy images and all these. 
But their promise is, how they use it to create content, how they use it to, contact leads, these kind of things. Everything is around the content communication on social media and sales these area.

**Ellie Rofe | 37:24**
So it's marketing and sales for those guys, which makes sense because the people who are marketing and doing social media will be pushing it in that direction. I'm not. I don't think you need to decide now. I just think it's an interesting thing to have in your brain. 
Like when I think about. Yes, content is a struggle of the a it doesn't have the right context and it doesn't have your turns of phrase, and it's just like, you know, a it's, you know, kept in generic. 
It's really annoying, but when you. But one of the most interesting things for this, you know, if I was playing around with it, is ideas, you know, analysis, self development and things. But that's if it's for maybe solo consultants who are, you know, occasionally having to dig deep and do some reviews and reflect on where they're holding themselves back or whether they're missing opportunities or you know, like you've got here this is very much. Demetrius Reflectiveness of where are the opportunities, where are my blind spots and helped me, you know, with content ideas. 
And so that's where I wonder, because I think a lot of the time when I've heard Ray feedback to you, it's quite operational. How can I integrate this with my email? How can I do something that will connect with another thing so that it can give my brain hands? 
And I think that's an interesting area to interrogate. What? Where do you think it should be? All those things. Or is it leaning one way or other? 
And maybe have I unfairly characterized you, Ray? Because when I hear you talk about it, I think that's. That's what I hear you saying is I think it shouldn't give me hands. 
But is that the case? Or is that just because I've heard little snippets?

**rhdeck | 39:21**
No, I think you're on track, but the I think you think of this as a formula that's the product of three inputs. Okay. So the inputs are number one, the data that's coming in multiplied by the analysis that's in the middle, multiplied by my ability to put it to work right. 
And the. And I think you can find that you're as you go through this, you'll find different pieces. They're all kind of thin right now, but like, there are different pieces of this that you can be making thicker that unlock value and then turn the other parts or one of the other parts into a bottleneck, right? The bottleneck is the thinnest part of the process, and there's always something that's going to be the bottleneck. 
That's probably what you want to be stepping on a regular basis in order to get good multiplicative benefits out of this. So what I'm looking at this I actually think your Zapier stuff was great. Hasn't doesn't seem to have changed that much recently, but like the. 
I think having a Zapier app could be something that really unlocks lot value because theless you tell a story about how the kinds of things that they use today, kinds of no code, things they use today as opposed to copying and pasting a piece of code, you've already got the idea of how to ingest, right? Which is your. Your web hos. You're describing them. 
And then the second is, you know, an API that would be able to query this and put data in context that would allow them to send an e mail or whatever and like. And you could do that through something as straightforward as make or Zapier or of course you can start to open yourself up to all sorts of other places that could be doing connections. 
And you're just talking about having an API, right? Not a very complicated API, right? You have a search API to be able to go get answers based on, you know, a query, which is something that, you know, you're you know, that's a graph rag. Relatively straightforward thing to do, right? 
And then you have on your end, the ability to ingest right, take a document and go get it into the graph. And those are like your connections to the outside world. And the cool thing about those connections, those are connections that your clients can use repeatedly. 
And it takes things like the conversations out of the mix. Right now, you don't need to have things that are on the inside, right? What they have are ways to be gaining data in and pulling data out. And there's a technical term for this, it's called system of record, right? You're creating a system of record for their you know what with previously just their unstructured data. 
And that's what's going into the graph here. And that creates persistent value. And your consulting can be about helping them with each of those three things, right? Getting more data in and you can look at like you were just showing like how you get it from Krisp, that's great. What about emails? 
Totally do that with Zapier, right? That's very straightforward. Zapier app. Hey, when an email comes in, let's filter it to make sure it's actually something reasonable. Maybe you could even use another AI call for that. 
And then let's go send it over to Braingraph. And, you know, you can have other things or like your communications, your activities, whatever. You can show off like by doing it for your personal productivity. You create things are immediately valuable to your customers they would want to buy and that make compelling content. 
And there's a high correlation between things people want to buy and compelling content because you talk about things they want that, they want to watch that, and then they want to have it right, and that. 
So those two things really serve, you know, move the needle for you. And I think if you have more to when you think about your development process, I think if what you had was how can you make that a Zapier native experience? 
That's great. And now you have all of your friends over at like no Code Ops where you can be showing this off to them and then be getting them to, you know, promote that as well because, hey, it's a Zapier thing. The fact becomes a way they can make money through getting things through brain graph, which you would feel pretty good about because that's only making you good that gets you more. 
You know business as well and positions you as a higher level expert. Your rates can go up. All that. All that stuff can be to the good, but either way, it's like you move them closer to something they can buy. 
And then in the middle, as you point out, like it has to be good or has to be reasonable at getting data through. But the wonderful thing about the three step process here is they add to each other. None of them have to be super great for you to make a big difference. You going from having nothing to having something terrible is actually a big improvement, right? Going for having something terrible is something mediocre is a big improvement. 
And of course, going for something mediocre is something great, but like, it's not like you have to get. Let's just have one of these pieces and have that one piece be great. It's like a super great disembodied brain, right? No one's ever going to find out. Or a great disembodied arm. Similarly, he won't be able to do any good, right? 
Like you sort of need the three in order for it to start to create a process of generating value. And then, you know, you can sort of be seeing which of those is sort of the limiting factor at a given point in time. 
So yes, I think your analysis of I was going to say something about hands is right on. But that'd be the broader structure I would look at here, right is like what are the components that makes this valuable to a customer? 
And then how can this be doing its job really well, by providing those connections? And I think you'll find it does that with less stuff in here. Like to Robert's point, like the graph looking a little, you know, daunting. He's totally right. I remember I took the a changed knowledge graph and I showed it to some people are like, I don't even know how to deal with this. 
And they were right. It doesn't help. It's like looking at, you know, my the inside my brain. Fiery. That doesn't help them make a decision, but the data in it does. So like how can you get it to the places where they need to do work? That delivery that both that capture and that delivery that be the things that I think would if you're thinking about like where'd be putting your efforts. 
I think that would create that would be both increasing the value of it in terms of delivery but making, you know, planting the seeds for great content. That would make it more viable as well.

**Ellie Rofe | 45:48**
Yeah. The idea of this is like a content, a context nexus, like a point where you can get context in and then get it out and do all sorts of stuff with it is quite exciting, I would say.

**rhdeck | 46:05**
It's much better if you just when you're referring to the automation platform we call it Zapier.

**Ellie Rofe | 46:10**
[Laughter].

**Robert | 46:11**
AZ I'd just say that like, you know, it depends on what who are you're aiming for to try to attract their attention. Because a lot of people if youre aiming for you know, I'd imagine like that if you're aiming for a very, you know, premium client to ultimately probably just want to you to build it for them anyways like. 
So they're not going to. Just the fact that you're showing this and if you're showing that it works well and if you're able to explain it. I feel that it really communicates to the type of person who would be looking for basically a builder who is able to build it and explain it to them and just be very versatile with whatever that they need, including the other things that are going to pop up for them, right? 
Like just in terms of covering them as a client. So I would just say that there's a. You know, just to add on and just say that there's a lot to solving your own problem. And it doesn't have to ever leave this place. 
I mean, it could just be here and. And, you know, if it needs to leave here, then it would prove itself right by. But putting it into the market first.

**calendar-invite@lu.ma | 47:27**
I am. Great points, guys. I'm thinking exactly how to, approach it to, help the end user get more value without visiting this system. So they visited only once to integrate it with the automation platform. 
And then they move away and the system works for them. They have their agents.

**Robert | 47:56**
No, that's easy for your clients. That's easy for clients. Like, you know, it just takes one session. I mean, like, in a good way. All I'm saying is that, like, somebody should pay you to do that, right? 
Like to set that up for them. I don't know if that's your if you're describing them in terms of the goal for this to offer it like as a free lead magnet. It that's ultimately the experience because, like, what you're describing sounds like to me, like what you'd be offering to somebody who's on a paid engagement.

**calendar-invite@lu.ma | 48:27**
No, this is designed to be like a lid magnet. So then we can go to the paid engagement. And what is right now in my mind is. Okay, so how should I structure it in that way so that it can have a free version and the paid version? 
And I think the best thing is 17. No, 14 days of free trial where you can get all the value from this product. So they can experience with all the value comes out of it. And then they can go to payment instead of having, you know, the free version and the paid version with a couple of features. 
And you know, what do you think about it.

**Ellie Rofe | 49:22**
I think the KING the only key for me is I.

**rhdeck | 49:23**
If I'm sorry Ali thought go ahead.

**Ellie Rofe | 49:32**
It feels like this is either something that's quite rigid in here that has a use case or a few use cases that people put data in and they get like these intelligence nuggets or they have a chat. The slight issue is sometimes with chat is that if it doesn't have all the features that people are used to in open AI or Claude or, you know, people can't then do stuff with the information they get from the chat, then it feels a bit locked in or it becomes open ended. 
Like we were talking about where there's ways in which people can choose their adventure of what they're going to do with it, how they're going to link this up with their world. And I think the biggest question is helping people understand the possibility because I think, you know, between a lack of imagination and lack of understanding of things, people just might not know how this can help them because there's so many opportunities here. 
I think every time one of us looks at this, we all see a different thing we do with it because it's you're talking about the context of a business or you, a company or whatever that that's huge. That's what people have been trying to do for ages is build a knowledge base that they can then do stuff with. 
Sorry, Ray. I cut in, though.

**rhdeck | 50:55**
You did not I thought it was fantastic. The I was actually when we were talking about like the Desire for this to be a lead magnet redress. I was actually thinking about like, you know, conversations we had before about broken funnels, right? 
And the events right. And the question like what's the, you know, where is the break in the funnel as we get to this point, it is not. I think there are a lot of people who try to make piece of software. They think they should have a free trial. 
And then they founder right on the free trial because you wind up with a couple different problems. The first is you have the additional complexity of you trying to make something that's free that still has some limits to it. You have the problem of people needing to figure out how to use it, and they're not using it that well. 
And they sort of sour on it. And like, they're not getting to where you want them to be. You think it's a good deal because they don't have to be paying anything. They think it's ad deal because they're putting in their time. They're not getting what they really want. 
And I think it is fundamentally confusing the question of like, what's the job to be done here? And it's to be, you know, moving them along the trust curve, right? And I think that the it just seems really obvious to me that like, you know, you can have a piece of software that's rougher around the edges, provide people with a limited amount of your time and help them make much bigger progress, right? 
So it's lower cost and higher value all at the same time. And then, you know, what they need is to then just pay for it. And this is one of the reasons I think that, you know, Daton Priestley talks about like, you know, his four product framework. There's free products, there's products for prospects, there's core offerings and there's products for clients, right? 
And this right here has much more the feel of a proper prospects and does have a free product, right? Your free product can be, you know, content. It can be events. There's lots of stuff that looks like that and then like, hey, what's next? What's next is you've got Braingraph. Braingraph is an offer where they can have, you know, this thing, you know where you're going to get them onboarded right in an hour, right? Not a we're going to have a deep conversation about your business, but like, what does the first round of this look like? What does zero to good look like? 
And then you have an additional offer of here's how we go from good to great. And that's like more of an engagement, right? Because they can get something out of just having this at all. And the something you get to compete with nothing, which is a nice. 
That's a great competitive position to be in. And then by the time we were talking about something that might be more money. It's going to be when they've already, you know, built up trust with you. But I think that the you know, the trick is when we do it for free, we're trying to do it for free without the offer of service. 
That's increasing the technical complexity in a way that often doesn't work as well as we might like. You have your reputation that's all tied to something that's free and that people then feel free to complain about. As opposed to, hey, you got this thing, which is software with a service, right? 
And for a reasonable price and like, you know, the. And I suspect reasonable price is, like, betterer than most other things you're looking at right now. You in an hour have them hooked up with their Zapier, right? You're saying, hey, what's their precondition? 
You know, either they need a Zapier account or we're going to hook them up with it. And if they're so cheap, they don't even want to do it. Zapier they want to know how they can do it with web hosts. 
Okay, fine, you can just sort of hand that over to them, right? Like, what does your service look like? Your service looks like. How do we use world class tools for this? They have some other thing they want to do it like with open Clath. Super cool, you're glad to help with that. Now you're working with someone who's more technically inclined anyway. 
So like you're you can be leading in tech cause you have because you'll have the API, right? You have the API both for receiving data, right, and you have an API for querying your data. That's it, that's what you want. 
But that's the API gets me nice and simple, it gets me sitting behind authentication. I can see that working with MCP, I can see that working with Zapier. I can see that working with all sorts of stuff. 
And of course, you know, they can work just with the API and if they're going to do some like open Claude, then like, that's totally fine. And if they're gonna be like, they're business people who came to know you through your, you know your automation, you know, experience and background. Great. Here you got the you got this the Zapier map for it, which you can you know, of course, once you make a Zapier app, you can give it to other people. It could be private just when they won't publish it until it goes through a review process. 
But you know, you get a few people on it you can get then approved and like that. And that gets to be another marketing event and all sorts of, you know, good stuff there. Okay. Why do I bring all that up? 
I've wandered away from your from the question of it being a free product because I think that if the job is to be building trust with you, I would encourage you to keep the service aspect. Be ready to do something that is, you know, short, fast, high trust building and then charge a little bit of money for it. 
And I think a little bit of money can be a much easier sale, you know? And I. And that's the thing. I would be, you know, unafraid of. Like. Hey, this particular packaged offer where you have the beginning, middle and end of it and you're gain the value of, you know, these things that you set up. 
You know, I don't know what that number looks like. I mean, easy. I believing it's like between, I don't know, like a hundred euros or something. And like the for the first one and you just increase the rate as you have more customers, right? 
Because you have more market credibility and then that that's getting new customers, getting people who are using it. Gain you data that coming in and out. And then the technical requirements for you are just a do you have the baseline of ingest processing?

**calendar-invite@lu.ma | 56:36**
E.

**Ellie Rofe | 56:40**
And that could be the free part, like the lead magnet, could be Kickstart, the baby bra, the, you know, the first version of your digital brain. What does that look like? Choose your input, choose your analysis style, choose your output. Here's all the things you can do with it. 
And you get them to start doing the work and seeing the possibility and then like, want to set this up? Book in. It costs X amount for an hour. You're showing them the structure. You're giving them a list of potential inputs, a list of analysis styles or whatever you want to talk about the all the potential outputs they can get. You can even. You can do it with a little chat. 
Like a guided chat, whatever. I don't know. But then they start seeing that you've got them to choose what you're gonna set up on the call.

**rhdeck | 57:31**
And in fact, I was just thinking. LI yeah, I love that idea. And I think the way to ramp it up a step would be to offer workshops or webinars where it's a group setting. But they're setting it up, right? Your concern is you want it to be free, but there's a bigger technical challenge of having it be self service. You can do free without self service by having group settings. 
And that might be a way to get to further reduce your friction, right? And then and that's the key is you're just trying to reduce friction. And I don't even think this needs to be free. I'm not sure it needs to be free for the first customer. I'm not sure, but if it does if you do need if you do choose to make it free for a bit. I'm not sure it even needs to stay free because I think this becomes valuable right away. 
And the fact that's repeatable means it's less expensive for you, which means you can afford to make it an affordable prop for PROSPX. 
Robert, can I get your thoughts on this?

**Robert | 58:45**
Yeah, for sure. I mean, I was just going to say that, you know, for whatever it's worth, that I found if I look back and just see how I, you know, started off with boilerplate and all that stuff, I would put it onto the market and I would just offer to people, I will help you set it up, right? 
Like I would most of the time just like be, go like it was like the beta, right? Whatever that means. But like, I was just helping people get set up and I was having conversations. I was learning about the product at the same time and making it better until eventually people on the call were saying, like, how come you're not charging for this? 
And then I start charging for it. So I would just say that there's something that this will lead to that. I would say, like, you know, by eventually I have found that like, if you're. You become so good at it if you keep doing that all the time with people and this is what you're doing and you're putting yourself on the spot like that. That you're going to figure out ways to optimize this experience to like for them on the phone, you're going to figure out like how can I possibly make this time that I have then like the most value possible. 
And I think for me, that's where. A lot of the things that I make, the tools that I make, like they're kind of optimized for that. Like to try to work on the spot and like for people because of the nature of how trying to engage with them, which is, you know, that we're on the phone and we're trying to set it, set things up together. 
So naturally, like tend to create things that help with that. So yeah, I would just say that like there's a utility behind that, like a behind how those calls will, you know, turn into that.

**calendar-invite@lu.ma | 01:00:35**
Yeah. NI Nice point, guys. Never thought about this approach or thinking.

**Robert | 01:00:46**
Yeah, thanks.

**rhdeck | 01:00:47**
This is. This is marvelous, if I might say that this stuff is looking good. And you're looking at. You're seeing all the seventeen things that are wrong with it. And don't get me wrong, the closer I get to it and looking at my data, I'm sure I would see fifteen things wrong too. 
But that's all to the good, right? That will help if you're doing this for yourself, right? You build this for yourself, it will, you know, more stuff will become apparent to you and you'll be to dial in on things that really matter. 
But this is. I think if you. If you connect these pieces, you know the technical burden for you gets to become less and you're providing more of the stuff that's most viable, which is like the graph and these connections and the deliverer of that value gets to be you and we're selling more you.

**calendar-invite@lu.ma | 01:01:37**
One last question, guys, would you recommend, because I'm thinking for, going live on LinkedIn on YouTube? Would you recommend to go live in sessions where I'm working and adding improvement all of this work with cloud code? Would that be valuable or would be boomerang or useless?

**Robert | 01:02:05**
I think it's worth the try. You know, and like, I it's worth a try, like, really like, probably the downside is nothing. I don't think that you would experience anything negative. I think you have only, you know, positives to gain from it. I can't. 
You know, I don't think it would. I don't think it's, you know, I don't think there's anything that would take you anywhere but forward in some type of way. So to me, just to find out extremely quickly would be goodm.

**Ellie Rofe | 01:02:40**
I think seeing you ingest data and how you understand it or what it can do would be really interesting.

**Robert | 01:02:41**
Okay.

**calendar-invite@lu.ma | 01:02:49**
That's good.

**Ellie Rofe | 01:02:55**
Yeah.

**rhdeck | 01:02:56**
All right, well, you know, and Des there's any way we can be of, you know, assistance between, you know, in the course of the week. There's like stuff you want, you know, mer cer, certainly. I if you have stuff coming up, like on the Zapier front, do you want me to test? I'm very glad to test that for you, too.

**calendar-invite@lu.ma | 01:03:14**
Yeah, thanks. Thank you, guys. It was very helpful.

**rhdeck | 01:03:19**
Like something on the zappie a front.

**Ellie Rofe | 01:03:20**
[Laughter] Sparklingations [Laughter].

**Robert | 01:03:23**
It's like Perrier fancy, yes, like it's like NNN but carbonated.

**rhdeck | 01:03:36**
Nhr I think it's way we say yes, it's good. Everyone, this has been fantastic. Absolutely like it to work with you today and we'll be we'll meet again the end of the week and we'll do this again same time next week. See you. Take care. Thank you.

