# State Change Mastermind - Sep, 02

# Transcript
**Ray | 00:06**
My apologies for being called minutes late today. I feel like my apology because I'm just on the beam apparently.

**Ellie Rofe | 00:15**
I was a feeling.

**Speaker 3 | 00:15**
My apologies are really Ray.

**Ellie Rofe | 00:16**
Delay. And so, my apologies.

**Speaker 3 | 00:20**
Yeah, sorry about that, right, this morning. By the way, was that my morning? They just... I was, but I never woke up so quick as when I realized it's like, "Holy crap, it's real."
Yeah, totally, just completely slipped through.

**Ray | 00:38**
No, yeah, I mean these things happen, man. We actually have a developer group for people making development tools for Xano, and it's Robert, myself, and Miha Toth. We're trying to put things together now.
Actually, this is the crux of the discussion. Robert was about how we can set up demobility. I now have a schedule just so Duo catches you up. I have a meeting scheduled with the VP over at Xano later this week, and I will discuss this as a good marketing avenue for them, which will probably lead to or has potential at least to lead to a meeting to demonstrate what you know more in detail, like how you would help them sell, how Miha Stufff would help themselves for sure.

**Ellie Rofe | 01:35**
So I help.

**Speaker 3 | 01:37**
So I'm looking forward to it because I think some of the actually, since the conversation that we had with Miha, that was huge. It opened up a lot of doors, and just that conversation, seeing the official Zoho STK, it just opened up a lot of great doors.
Yeah, I'm looking forward to it. Maybe I'll just have those as part of what changed last week.

**Ray | 02:03**
Yeah, fair enough. Anyway, I was raising it actually in the poet forum. Just to sort of raise the notion that there is a guarantee momentum to be gotten from putting together these kinds of peer groups as well.
And if I can be helpful with that and more fronts, I'd be absolutely delighted to. That the one that you and I had and I think has shown some profit there. But let's go around the horn here and ask what is true today that was not true a week ago.
We'll go around to Demetrius, and I think it is your hot seat today. We can be figuring out how we can be of greatest service to help you have the best week possible. So, Ellis, if I might start with you, ma'am. What is true today that was not true a week ago?
August.

**Ellie Rofe | 02:46**
[Laughter] I know.

**Ray | 02:47**
You know. Because. Because. It's a new month.

**Ellie Rofe | 02:51**
I thought just this afternoon, all the whole season has just passed like that, and what's true, I got a client, a very low-paying client, but it was nice. Anyway, slightly unexpected. I was actually just trying to speak to her about an initiative she was running and then ended up talking about her company that she's spinning out from the Crick Institute in London and went through and was talking to her about her pitch and gave us some advice.
She was like, "I can't afford your full fees, but I would love to work with you." I was like, "She absolutely... The situation she's in, spinning out, got a bit of funding raising less than a million."
So I talked with Ray's about it on Friday. I did slightly... Just because, not having thought about it beforehand.

**Speaker 4 | 03:43**
Recording in progress.

**Ellie Rofe | 03:51**
I know when we talked about pricing, I said I'd normally go with an idea in my head. I did it way too low.
Because I hadn't ever raised help someone raise less than a million before. So I was like, "But we discussed some strategies, and I've been thinking about how to structure engagements and things along those lines." One of the slight issues is the first stage of the engagement with me can end up throwing things up in the air a bit around their strategy and what they have or haven't got sorted.
That can then lead to a big pause between that and the next stage, et cetera. So it's been good. It's been nice to get a client on, even though it was slightly random and lower value. Things are moving. Obviously, less productive than I'd like to be in the last few days just because we've got a visitor.
So there's lots of cleaning and prepping and driving to airports and all that kind of thing going on. So, yeah, I'm dealing with a 20-year-old who's heartbroken, he's just with his girlfriend, and so it's like it's drama, but it's fine.

**Ray | 04:58**
Goodness. I've got my 11-year-old sons, so I'm dreading the day that particular trim of wheel comes around [Laughter].

**Ellie Rofe | 05:05**
Yeah, it's always fun. It's so important in that age, it's so intense.

**Ray | 05:14**
Both characters.

**Ellie Rofe | 05:15**
Yeah, it does. He's a very sweet boy. He'd hate me saying that. He's a lovely young man. Not a sweet boy. [Laughter].

**Ray | 05:23**
[Laughter] right, Robert, what is true today? That was not true a week ago.

**Speaker 3 | 05:32**
Sure, it's true today. Not true a week ago. I've pretty much revamped or focused my efforts and energy to making the most out of what seems to be the sharpest tip of the spear, which is this offer that involves the MCP tool that I've managed to.
First of all, there's people who are just happy with how it is right now. They're so happy with how it is right now that they've... First of all, for them, it means business opportunities for them because the way that they're using the tool allows them to build another business on top of it because essentially it allows them to hire twenty-year-olds and let them act as senior developers, essentially, because it keeps them on rails.
So that's a great thing as far as providing something that enables somebody else to do something like that. But for him, up until now, which is something I'm trying to change, is that I don't charge for it, which means I don't take it seriously.
So for him, that's problematic because that means he doesn't have any insurance against it. He actually, due to a user error, messed up something like signing up or logging in or something, and he couldn't take it.
He messaged me, emailed me, I saw a message from him. He was just like, "Please, we need to go on the phone, please." That's when he told me he wanted me to charge him. He wanted to pay for this.
Then I was like, "Okay, so this is what this person is describing. I better go for it, right?" Because he's not the only one. He's probably the third or fourth person who's told me this.
So there's that. He has a team, and he has certain things that I'm trying to bring to life in terms of the dashboard, which all ties back into the demo for Xano because those are all things that I think Xano...
There are a few birds that I can hit with one shot by doing that, at the same time, in parallel, which is crazy to me because I haven't actually widely released it yet, but I've managed to make the thing build almost perfectly on Xano.
Build functions, background tests, and endpoints almost flawlessly. Like, it's so good. And it was such a pain in the ass that I know it's going to be... I know it's not going to be easy for anyone else to
replicate that same whatever that app is doing. So I'm going to leverage the MCP Wednesday meeting tomorrow to talk about that. But I'm wanting or putting my energy now towards just focusing on demonstrating that because it's really quite good now.
So that's what I'm doing, trying to... To say that I'm trying to transition to turning that into a paid offering that includes meeting once a week and so on to just make it a no-brainer offer.
I really do think, with the performance of it and the fact that there's no alternative, there's no other tool that does what this tool does. I think I feel pretty confident that there are people who are going to sign up for it and be happy with the offer.
So yeah, that's all true. That's all new from seven days ago.

**Ray | 09:41**
Okay, that's a lot. And it's exciting that you get a new paid offer out of that. I think this is very much a Dame Priestley prop for prospects, as we've talked about before. That then leads into more good stuff.
Okay, that with all that in Demetrius, let me ask, what was true today that was not true a week ago? Then let's get into how we can be of service to you today.

**Speaker 4 | 10:09**
Yeah, what's true today is that I gave... First of all, I completed all the tasks that were on delay since the past week. I'm running on schedule, so it makes me feel better. I see that it affects a lot of my mentality, and now I feel more comfortable moving forward.
I completed my task for changing my website entirely. So I have a new version on Squarespace, and the purpose of this new version is to have a digital showcase for the new Focus, the new targeted service, which is the digital twin thing.
Today I started my first LinkedIn post on the digital twin. I think in the next few days and for the next month, I'm going to invest all my effort in doing this.
So what I would love to ask you guys here is for any piece of advice or any piece of feedback on the new website version that will be very helpful. Any piece of advice and ideas for the next couple of days. What should I do and what should I avoid? What do you think are the best practices
from our experience and what we discussed till now? I'm adding the link for the site on the site.

**Ray | 12:12**
I actually think you put the mastermind link on. No, now I see it. Thank you so much. Yeah.

**Speaker 4 | 12:30**
To be honest, I work by having two very good websites at the same time. The first one is as I really loved how you structure it and how you communicate in your way. I love that it was your own way.
At the same time, I keep CL Ralfson's website because it has huge similarity with Ellis. First of all, they have too many common things. I like that it is very simple. Here's one.

**Ray | 13:28**
Let's, we'll let everyone read for a minute, and then let's get some feedback. We're looking for with just some first pass feedback.

**Speaker 3 | 13:48**
Well, okay, I think low-hanging fruit, just like 20%, that brings 80%. Just make the logos transparent background, you know, on your website just do it. Yeah, please, just those and again, is it does it matter? I'm not sure, but it's easy.
It's one of those things that if you just do that, the transparent just... I'm. I'm not even talking about anything that has to do with, you know, anything that takes more than twenty minutes.
Like, I think that there's there are some things in that category that like of, you know, that will dramatically just, you know, put that behind you essentially, right? And like, you know, yeah, with Canva or something, just I think that we do that for the logos and for the three boxes, let's say one, two, three. Just make them transparent backgrounds.

**Speaker 4 | 14:55**
Yeah.

**Speaker 3 | 14:56**
I would change your footer at the bottom. I just think that the call to action, "book one-on-one session," should instead of being at the bottom, be right underneath where it says "while we build your solution."
Right now, it's all the way up to the bottom. Just to move it up there, but really, again, I'm just saying the stuff that's popping out to me very fast. Your logo when I first looked at the landing page, at least on my screen, it's super tiny. It looks like the size of my phone now, maybe even smaller.
It's really tiny. You can barely see it, so just that type of stuff overall. Honestly, the first thing when I see the website is it's great to see your picture on it. It's actually very endearing to see that and to see your picture, the clone picture, I think is really good.
Again, it endears and it just even with... I think you combine that with just a little bit of cleaning up some things where it says "validate your ideas using your customer data." I think the font for that, the 123rd bullet point, is black. Just the hat, instead of the blue, like the rest of them, things like that.
Really, I think that if you were to make the logo bigger, just tighten up the spacing stuff and those touches. I think that that's where you're 20%, it's going to bring to 80 percent. Everything else is not going you know, I mean not saying that that's completely that's not necessarily there might be more within that twenty percent, but I'm just saying like, you know, that's the type of advice I' trying to give, you know, because this will be something that you that as Ray tells us you will build this again.
So as I have learned.

**Speaker 4 | 17:17**
Thanks. The thing is that I tried to do it with the timer, and to be honest, when I was done, I had a quick review, and most of the things you mentioned, Robert, I couldn't even realize them.
The logo at the top and left, different color on the text, the background on logos. I didn't even realize that it was different. I was looking at the final one, but thanks, these are looking them right now.
It's very helpful. Thanks.

**Speaker 3 | 17:53**
Yeah, of course. You're welcome. I'm just looking at the mobile version. Same thing I would say and I would maybe... I think that there's a saying that there's like 99 cents out of your whole dollar that will be spent. Basically, it will be in the headline, your hero section. I feel like turning your data into a goal of growth. I feel that especially as I'm learning more and more about your offer. I feel like there's another way to communicate this because there's probably even a way to communicate it that even touches into something I would be interested in.
It's just that I don't think that this headline communicates that super clearly. As I come down the page and I see the two pictures of you, I start to get it more. But then, I'm coming up and I see there's something there that is in this hero section that's not really communicating, like, just really super clearly exactly what this is.
I think you do have something that could be expressed really super clearly.

**Speaker 4 | 19:13**
So is it that on the hero section, I have to add some more effort to communicate more clearly, away from the message, right? I.

**Speaker 3 | 19:29**
Yeah, well, I would say that just more clarity. For example, over the weekend, I worked on one of my headlines, and what I came up with was something... It's pretty in my mind. I felt like this is a great
idea. It was the framework for Xano or something along those lines. Then Ray told me a way better headline. He said, "Build Xano ten times faster." That was way better.
That's just it. It's straight to the core of it, built ten times faster, and whatever that is, I think there's something in wording that you could use, which is very straightforward, like, "Create a digital Cora that works while you sleep." I'm not sure if that's something that really catches your attention and gets to the heart of what you want, right?
What is it that I want? I want something that I want my clone to do. I think we... I'm not sure how. There are a lot of ways you could describe it, but I think that there's always... Maybe all of us have eventually had that discussion where we imagined it would be great if I had a clone of myself. I would go to work for me or something like that.
I think maybe if you can just touch on that, maybe that's one way to spin it. I think there's a lot of different angles, but I would try to look for an angle that people can just recognize really quickly. You're like, "Yes, that's what I want.

**Speaker 4 | 21:10**
Yeah. I was working on the... I had similar thoughts, but I didn't have any idea how to improve it, so that's why I bring that here, the database.

**Speaker 3 | 21:25**
Yeah.

**Ray | 21:27**
I think that's great. You know what? Just so we're all looking at it together and to Robert's point of looking at it through a mobile as well, I'm going to share my screen for a second.

**Speaker 4 | 21:44**
Sure.

**Ray | 21:44**
Go and this is something called Responsively. I don't know. For those who haven't used it before, it allows you to look at multiple versions of the website all at the same time. You do the same thing with your website, right?
And be able to see, you know, just your website, you know, across both mobile and Desktop.

**Ellie Rofe | 21:59**
Be? No, Right.

**Ray | 22:03**
And this... You can set up other sizes as well, right? These are somewhat arbitrarily done, and you can goof around with all these,
but the reason I wanted to do it was so that we could be asking design questions as well as copy questions just a little bit more straightforwardly. I want to do this because it keeps us from scrolling, right?
So, what's above the fold? What is the first 30 seconds you're getting from this? Then we can get to the rest of it too, right? But this, I think, helps address what that first experience is someone's going to have when they've clicked through that LinkedIn link or YouTube or whatever to discover you for the first time.
Okay, and I wanted to just put this up so we all had it to look at and so that people can grab that marker if you want to and be marking where you're thinking about this stuff as we move through here.
Then, Demetrius, because this is a more visual session too. I mean, first of all, anybody who wants it can always get a copy of my recording, but Demetrius, because we're going through this stuff, it might have more visuals. That might be more helpful to you as well at the conclusion of the call.
But coming back to this, Ellie, can we turn to you, marketing, and that pitching is your line of country, as it were? What thoughts do you have about how Dietrich can put the next hour to work to improve his first impression?

**Ellie Rofe | 23:37**
I think, Robert, you called it really well. I don't know if you know the phrase, but burying the lead, which is where there's a headline, but it's somewhere two-thirds of the way down in a news story.
There is more specific value and that second section at the moment than in your hero. So, could you have, in terms of grabbing attention, the twin picture? Which is brilliant, by the way, fun, visually interesting and different. Could you have that in the hero instead so that people can immediately see what's going on?
If you're selling a digital twin, the words "digital twin" probably need to be in the hero. Then you need to find a way of tying it to the value it creates. We talked the other week about the difference between a feature and an outcome and a benefit, and you need to find the benefit.
So, build ten times faster in Zano, that's actually an outcome, and it's a brilliant one because it's very tangible. So, outcomes or benefits, things that people can go, "I get what the value of this is immediately."
It's not designed to tell them everything, but it is designed to tell people why they should care and continue looking. Does that make sense? I always ask that.

**Ray | 25:15**
Absolutely. Yeah, I think that's a great point.
I have to say, I do like that composite picture you put together at the bottom. I think it's fun. I think it's all the... Yeah, whatever. There are lots of ways to...
I think if you were just to take the assets on this page and ask about what needs to be lifted up, you probably make tremendous improvements in a very short period of time. That idea of these two pictures of you, the composites. I love the composites.
I think it's just great. I think it helps tell the story and it's you all at the same time.

**Ellie Rofe | 26:03**
It's well, it's really playful and fun, and it looks like someone you want to work with, someone who's... It's great.

**Ray | 26:04**
And then yes, sorry.

**Ellie Rofe | 26:15**
I really like it.

**Ray | 26:18**
I think your question of the whole... If you could clone your expertise, would you still hire... I think that needs to get cleaned up a little bit. But this is where you can get help with wordsmithing, and AI is actually decent at that.
I'm sure the LI can come up with some pretty good words as well. But I think this idea... What's the promise, let's clone it, right? Then I think it's what's the reason? Because you've got a lot of data, right?
Computers can be a multiplier for you, do it as you would, and this means more sales for less cost. That feels... I know I'm muddling together a couple of ideas, and it's not quite the Krisp tag like what I gave to Robert.
I'm still working. I'm still thinking about it. I might pass the ball to the air to see what ideas we have for that, like what's that banger headline? But I think that idea, that image, that idea, digital twin, we put it right at the top.
Then what you have is a clear offer. Let's make a copy of you, right? You have a copy of you in five sessions or whatever. I would throw something out there that you think is probably a little greater than what you need, but, of course, has an error around it.
I think of it as the 80% mark. 80% of engagements, based on what you know today, you think you should be able to do within this number of sessions, right? 20% you can't. Who knows? Maybe you should be wrong about that if you're always going over, then maybe increase the number or whatever, but then...
That is like, "Okay, what's the offer?" I think there's an aspect of the way you deliver that's really attractive. I don't know who this guy is, and it's going to get another one. Those freelancers... No, we're going to do this.
You go from there. There's the "why," the "what," and the how.

**Speaker 3 | 28:38**
And if I.

**Ray | 28:38**
Can walk away from this page where they sense those things? I think Ellis does a good job with us, as you'd expect. I think right now, Snappy is a bit of a hot mess, but that's why you and I were talking about it, right? Robert?
This is a hot mess, too, but, man, it's liquid now, right? In a way, the previous version wasn't, which is exciting, right? Because you can just pop back into Squarespace and go try out some other copy, try out other layouts, or what have you. My first impression when I looked at it was I had some layout concerns about it, right? The use of space looked... somebody who didn't know how to put together a website. Which is true.
It's your first time with Squarespace, right? And this is what you do for a living, so that seemed perfectly reasonable, but... What I realized listening to Ellis was that the real problem is that it doesn't have the words.
It's not worth reading yet, right? Because, to her point, the really good stuff is below the fold, right? You can sort of see down here on the desktop side. We start to get to the good stuff and then it goes away.
So, this stuff that you have down here... some fraction of that when that goes up here. When the image that you have down here goes up here, I think that could be pretty exciting because I think the basics of the structure of the layout... You've got your headline on the left. You have your subhead, the content of the thing on the left.
If you're call to action, you have your image on the right. That seems all perfectly reasonable to me. Then, over here, right, which showed layout considerations. Of all of them, this one actually looks like it's got the best layout, but that's partially because we're just really constrained, right?
Because everything always folds down on mobile. I wouldn't worry about the layout because I think if you have the good content, then it becomes a lot easier to go adjust the layout because you can see that you're polishing. It just keeps on shining more and more. Right now, I wouldn't worry about the layout. If you worry about the layout, it's not solving the right stuff yet.

**Speaker 3 | 30:57**
Yeah.

**Ellie Rofe | 30:57**
A copy of it forms later.

**Ray | 30:57**
Definitely a bad layout would be fine. Yeah, I think it would help. Sol, you... I'm sorry, Ellie. I didn't mean to step on you.

**Ellie Rofe | 31:08**
No, I talked over you. Sorry. I was saying that copy can inform the layout as well. So as you come up with the right words, you might think, actually, this is the visual that needs to go with it, or I can lay it out like this.
So I would always get that copy before worrying too much about the layout and design.

**Speaker 4 | 31:33**
Cool.

**Ray | 31:35**
Ellis, can I impose on you? Can we try out what you think a headline might be here?

**Ellie Rofe | 31:42**
I was just thinking about that. When I talked about the archetypes and I showed you, I think I showed you the guys. The wheel of different archetypes. The reason that place is really useful is if you... The most obvious example of this is if you look at cars right, everyone who's selling a car is selling the same basic thing, something on wheels that should be made to be.
Ford sells cars very differently to Mercedes, which sells cars very differently to Tesla, to Jeep, to all these different kinds of things because they're all appealing to different types of people.
So when I'm thinking about the headline here, the idea of if you can close your expertise, would you hire... That speaks to people who are seeking freedom. That speaks to people who want to be carefree.
They don't... They don't want the mess of hiring people or the expense of hiring people. If you're talking about... I think you mentioned that you gave that, who you are as well, and the types of people you want to work with, you're drawn to that concept of mastery of the ruler and stuff like that, which is a great thing to be thinking of as well.
So then you're looking at not necessarily being free from the needs of hiring people, but how, you know, you work harder than everyone. You are like in... You've got insatiable ambition. No one can ever match you. What if they could get your own twin and have another version of you? Now, that's obviously very thrusting and stuff, but long-winded.
Do you see the difference in the angle there? Do you see that? One of them is saying, "Look for freedom because you don't have to hire people." You can just fly solo or stay very lean, move fast.
One of them is saying, "You are the hero of this story, you are a master, and let's clone you and double the capacity, make it even more powerful, even more driven." So I'm not saying either of those is the right one, but I'm saying you really need to think about exactly who your people are, what they want, what they care about most, and what will tap into the psychology within them to get this. There are many different potential benefits with this, which is why it's both a very useful offer but has a tendency, if you're not careful, to get quite amorphous and just sound like it's a bit of everything in a tin.
So, tethering it directly to things that the people you want to work with really care about is... There you go, Ray. Got it. I almost employ you.

**Ray | 34:33**
It. I was listening to the LA. It's sort that came to my mind. I didn't want to interrupt you, but I didn't want to lose it in my head.

**Ellie Rofe | 34:41**
No, I love it. So that's the kind of way to start thinking about it, I would say. And I think Rays had a pretty good attempt there.

**Speaker 3 | 34:53**
That's true. Like.

**Ray | 34:55**
This is basically your... It's a pithy way of asking the question, right? That you express right above your more playful image, right? It's halfway down the page. Yeah, I can't actually scroll in
the.

**Speaker 3 | 35:16**
I.

**Ray | 35:18**
I don't know. I love a lot of the content you've gotten here. I really don't think you've got new stuff you need to invent, right? Even what I was doing was what Li was doing, ripping off your content. I was ripping off Li, right? It's just the derivative of the derivative.
Then have the best of it. Not to imply that my tag is the best of it, but whatever is the best of it. That speaks to you as well, because it needs to be something you're proud of.
So you'll be sharing with people, and then put that in front of folks. I think it's likely people pass the past this, right? So basically, if they're going past this, then what you know, you're getting into. Yes, basically you have FS and BS, right?
Followed by what the mechanics are, but then what we probably want to have repeatedly in here, book session, not even a book, a one-session, this book, a one-on-one session is asking for consulting. Learn if this is right for you, that's the sales call.
By the way, I don't know if that's actually the right words. I would appreciate Robert and Li stepping in with a better way to express the idea, but you're not looking to get them to commit to money yet, right?
Right now, they've given you 30 seconds, and you're basically asking them to book their events.

**Ellie Rofe | 36:54**
And those words. So I'm going to sound boring because I will always bang on about this, but those words matter. If it's someone who's into Mastery Test, if your business is clone-ready,
yeah, that's a challenge. It throws down a gauntlet. Maybe that's right. Maybe it's not, but it's like the way you and I know this is really difficult, especially as you're doing it in a second language.
So, it's not as easy to just throw stuff out like that, but I think that's where AI can help you brainstorm a bit, especially because you've got that chat, I think from us, where you were looking at these people and what they care about and what they want, and then it will help you look at how the language in the page and...
I'm very happy to have another session and help with this, by the way, because it's fun. It's much easier to do it for other people than it is for yourself as well. So, it's much easier to get someone to help.
But yeah, you're looking at that. So, when further down the page, for example, it says empower your workforce with on-demand. If you try to think about how people would talk about stuff and then work out whether they're going to say, "I want to empower my workforce," or whether they'd be saying, "I want to..." I can't think now, but I want people to... I can't think now, but I want people to get ten times more out of each employee, right? Which sounds quite extractive, but you know what I mean. How are they going to speak about their problems or the things they want rather than the slightly lower, more common language?
As soon as you get up into that register, that higher register, you start losing the emotional connection with people.

**Speaker 4 | 38:42**
This is where I struggle, in general, to find the right words to communicate emotionally in English.

**Ellie Rofe | 38:50**
It's really hard.

**Speaker 4 | 38:54**
Okay. I don't know if it's hard or easy. It's a lack of a vocabulary. Definitely, something I'm trying to cover, being focused on what English people, English speakers are using phrases I like and appreciate. It's because I recognize the impact they have on me.
From the books I read. I read the books only in English. For that reason, the past, seven years.

**Ellie Rofe | 39:29**
I'm not saying it's just hard for you specifically. I'm saying that everyone struggles with this. It is really hard. It's... I mean, before AI, too, but still, the top copywriters get paid millions because it is a hard... It's very technically complex at times.
So, it's just giving hacks to say, right? Let's work out how the AI can help me identify, raise that, like a business owner that I'm trying to target my specific profile because there are obviously millions of business owners around the world, and you're not targeting all of them. How they would phrase their problems, how they might talk about it.
Then, as you connect more with the market, what I've noticed is you are incredibly observant of phrases in a way that I'm not at all. So, you absolutely will then start picking up. When you're talking more and more with your audience, you will start picking up the language they use faster than I suspect I would, because I wouldn't notice it in the same way.
So then you can start pushing it into your copy. So, you create that virtuous cycle again.

**Speaker 4 | 40:40**
Great. I think that this journey up to that point was the homework I needed to do before we go to perfection. We discussed that in our session early. So, I would totally appreciate it if you could help me fine-tune on that and bring them to perfection.
Because, as you know, guys, I want to push as much as I can for the next month, trying to see the results for this service. So, any kind of suggestion, even in a random time, even when you review posts on LinkedIn for me, feel free to reach out with your feedback. Strict and clear feedback. Never mind if it's negative or positive, just it's amazing. It helps a lot.

**Speaker 3 | 41:41**
Super yp just dropping that link. Sorry, Ray.

**Ray | 41:47**
Go further.

**Speaker 3 | 41:49**
I was just gonna say I just dropped in a link because I felt like, for me, even it was helpful to Google it. I found that in the past, I had read things that I prefer to be trying to explore. I'd read if I could find anything about it from McKinsey or something like that because, in this link that I just shared, they just talk about it within the context of... I'm going to assume that they're obviously putting their efforts and their resources towards it.
I think that there's something there that, just to use the word you can copy the copy, right? Which is great about... I've received from Ray in the past. I think I personally found there to be a huge amount of gain from
copying, to be honest. A lot of people won't do that. I think maybe there might be resistance to looking at what other people have done for whatever reason, maybe just the fear of... You might see something that might invalidate you, you might feel... Maybe it will invalidate the idea or anything.
But just to let you know, from what I'm saying, I think that there's even more interesting ways that you could position this that they just become more... They'll just be put right in front of you.
I think just by reading stuff like that, maybe you've already seen it, but I just want to mention that.

**Speaker 4 | 43:21**
Yeah, sure. It's very important. I see that. While I was looking around about this term, the digital twin, trying to learn for myself more, I found a McKinsey website. That block is the one that can communicate absolutely immediately. Every principle, every term, explaining in simple words. I really love how they communicated. These blogs changed entirely my thoughts the way I was looking for McKinsey consultants at all. They're not StreetSE people working on the project. They're doing really good stuff.

**Speaker 3 | 44:12**
Yeah, I'm pretty sure that they hire industry-specific experts. As far as I know, Ray would probably know better than I do, but, yeah, I started like... I remember when Ray and I first started working together, and then he mentioned reading those types of publications because I think that they have them. They release them every three months or so, like every quarter.
I would read it and I would find actually some of the stuff that we'd have in our discussions, which I know that most people were not discussing would be in that publication, and it immediately just jumps out at you when you already are having discussions like this.
As soon as I saw it, I'm like, "Well, I'm like change agents." They would even talk about that concept of change agents and stuff. I'm talking about in January, right?
So they're keeping up. So I would say, yeah, the words you want might actually be there. Some of them at least.

**Speaker 4 | 45:20**
Yeah, this is a really good point, excellent.

**Ray | 45:27**
I are the way we help each other, right? It does not stop at the end of the hour. Demetrius, you know, one, you were inviting us to be sending you thoughts as they occur to us. Let me invite you to be pinging us. "Hey, I updated the site. Can you send me what you're thinking?"
Yeah, and we can, like, record a quick video, right? Or something like, "Hey, this is what I'm seeing right now, this is what I'm thinking right now that you can then be using to get more feedback faster."
I'd absolutely be delighted to do it. And I think that we would... We'd all be on Team Demetrius to help you get this to where you want it and the time frame you want it. So what? We just need the prompt.

**Speaker 4 | 46:19**
Absolutely. Yeah, I'm going to do it, guys, because I need feedback, definitely.

**Ray | 46:26**
And think the one just you having this up is great. The fact that you're sitting in Slack, which means this Canvas is a lot easier for you to manipulate, is great. The mayor... It is correct what you end with, but the fact that you have it now allows you to make changes.
Then, if you're sending me an email a few times a day saying, "Hey, I got something new, can you take a look?" I'll gladly do it, right? I've got whatever else. I have my schedule. I'll get back to you as soon as I can, which not necessarily hypermediates, but I will not mind if you're paying me multiple times a day on it.

**Speaker 4 | 47:01**
So it's appreciated, honestly.

**Speaker 3 | 47:07**
Dude. Yeah, please do. I'm open to I'm very open to. Sorry. Not to mention, I just wanted to just say the same thing, like just to, you know, please just send Ping and, yeah, I'd be more than happy to. Even if you want to hop on a call. Always. Happy to.

**Ray | 47:25**
That I appreciate.

**Ellie Rofe | 47:25**
Just the same, I it be slightly pointless to ping me a few times a day because I will not manage to get back to you.

**Speaker 4 | 47:26**
Guys.

**Ellie Rofe | 47:32**
But if you... I think I'm more than happy to do blocks of time to help you brainstorm as well, live and review whenever you're sending stuff as well.
I'm really happy to do that because I know it's hard. The danger when you're doing copy and you're doing your own website is that you just get locked in circles because it's so difficult to push through on it.

**Speaker 4 | 48:00**
Yeah, definitely, it is challenging.

**Ellie Rofe | 48:05**
But now you've got a great basis. That twin photo is staying with me. I love it. It's brilliant.

**Speaker 4 | 48:11**
Thanks.

**Speaker 3 | 48:14**
Yeah, I would say that, in general, just try to change it often. I think this advice just comes back and forth between all of us.
But obviously, this could be something that... Don't let it suck you in, basically. I think there are things that you could test in your messaging more earlier in the process before somebody arrives here, right?
If you look at your messaging on your social media and you see what is... I think there may be clues that lead towards what would work here as well. Because if you look at it as... Okay, there's a message. There's the social media post, which leads to them clicking here, right?
Then they're going to go up the call with you. But then what is it that's leading more to people leading to coming to hear, right? I think there's a lot of clues that are in your interactions that will probably be the real goal, right?
That really informs what you're trying to put on this page, right? But obviously, it's just connecting the dots between that. I would say that you can find that out by experimenting, right?
By putting different messages out there and then seeing which one really connects. Just maybe approach it as a hedge fund manager or who has these different things that they're trying to test in the portfolio rather than as an artist.
This is me telling myself, there's less of an artist and more of a hedge fund manager or some type of thing like that. So yeah, just saying that. I think that there are other places you could put that messaging that we're talking about out in the market and just get even more immediate.
I mean, they're going to click on it, they're going to comment, or they're not, or it's just going to float away, and that tells you a lot of things.

**Speaker 4 | 50:12**
This is true. That's great, thanks.

**Speaker 3 | 50:20**
Yeah, of course. All right.

**Ray | 50:23**
Okay. Res, is there any way that we can... I mean, we've gone through the website stuff, which I think was your primary topic. Are there other questions that arise from this or that you'd come into the room with that we can be a service with you on before we
finish up our hour here today.

**Speaker 4 | 50:41**
The other question I had totally closed on that one, guys, very quickly because we're on time. We have a conversation with Ray on the chat with your permission right now, Ray, about starting a webinar on this subject. This is an idea I really love
and I really think about it. What makes me feel hesitation moving forward with that is that this subject remains something new for me. I don't feel an expert. Well, everyone can be an expert who knows something and can communicate fluently. The knowledge and so little... Quick guys, what would be your thought about that? Taking a risk on doing this or not? How could I avoid the risk? How could I help myself feel better, more expert.

**Speaker 3 | 51:48**
For myself.

**Ellie Rofe | 51:50**
But you are more expert than the people you're helping, aren't you? If you're doing a webinar saying, "Why are your results with a I suck and how to make it better?" you're giving them the missing piece. They don't really care if they're like Stanford Brain, they just care that you can help them.
So sorry, I'm going quickly now. So I was having a blooged. But that's it. If people can't get AI to work for their business, ways to help them make it work for their business better. Bingo.

**Speaker 3 | 52:30**
In the land of the blind, the one eyed man is king. So you know nobody knows what the hell they're talking about. And even if, you know, just a bit like it's not, you know, then there's something to gain from that.

**Ellie Rofe | 52:45**
As I said, the other day, you are selling $1,500 custom GPTs with some marketing strategy piece in it.

**Speaker 3 | 52:46**
Yeah?

**Ellie Rofe | 52:58**
Just $1,500 for a small piece of someone else's brain. You can definitely get people on the webinar and help them.

**Speaker 3 | 53:08**
And you should do that. I agree with the webinar idea, by the way. Just to say, because Ray told me to do the weekly calls. I think that it's supercharged my efforts.
It's brought more realizations to me. It's pretty much the reason why I feel so confident now in moving ahead with monetizing some of my offers. It just brought so much more clarity, and it's allowed people to just have a very clear way to reach out to me.
Yeah, I just think that it's just only positive things all around. So if that's something that you're worried about doing, then probably you should definitely do it.

**Ray | 53:49**
One more thing. I concur with what Ellis said. You are going to be more expert than the other people in the room, but if you're really lucky, you won't be... That somebody comes in because they're really interested in the topic and they've studied it, and then there's somebody else to be learning from. My goodness. That only works to your advantage because you become the convener of people who are expert, right? You're Robert Oppenheimer, right? You don't need to be... Niels Bohr, you know.
Yes, I just recently saw them close in that movie, but if you can be the person who... The entrepreneur is a bridge, right? A bridge between supply and demand. A bridge between expertise and need for its application. Often, we are supplying our own expertise, but there's a level above that which is supplying the expertise of others and being that connection.
So I look at it and say, "There's no way for you to lose." You could be talking to people who are entirely on the demand side of this, and then they show up, and you are able to help them. You can be talking to people who are interested in bringing their own expertise, in which case you can be facilitating a conversation, and you look good because you are writing on top. You are the convener. You are the chairman of the board of that particular panel.
That's a great place for you to be, and that elevates you as an expert. So, in the most downside situation, nobody shows up. But I'll tell you what, I'll show up for the first
I.

**Speaker 3 | 55:25**
Yeah.

**Ray | 55:25**
I know that I will learn from you because I know that, relative to you, what Ellis said is true. You know a lot that I don't. On this, you've been studying this, you've been working this, and I would be privileged to get to learn from you.
I think the same will be true for anyone else who gets to find out about these beings. So, if you do that, I think there is nothing but an opportunity for you to be able to sell, to be able to show your expertise and the quality of what's like to get to work with you.
Then, if you're really lucky, there's the opportunity to study because you will get to learn the things you didn't previously know.

**Speaker 4 | 55:59**
This is true. So, thanks for helping me think about it differently.

**Ray | 56:06**
Absolutely good. All right, that brings us to the end of our hour, everyone. It was absolute joy to get to work with you today. We'll be emailing, communicating, and we'll be talking at the end of the week as well. Thanks much. See you soon. Thanks.

