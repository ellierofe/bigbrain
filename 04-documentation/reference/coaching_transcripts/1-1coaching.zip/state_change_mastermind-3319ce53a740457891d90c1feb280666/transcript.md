# State Change Mastermind - Jul, 08

# Transcript
**Speaker 2 | 00:04**
Mastermind. And with a one-on-one session with Ray last week about adding the process for sharing videos on a daily basis on the week. So I started the week having one goal to deliver at least two videos with one personal photo or what? This means personal photo is not only a selfie. Let me go one step back. I realized after the conversation that where I was falling, it wasn't packaging how I was packaging myself.
So after long conversations and watching again the conversation with Ellie and Mitch one month ago here in state chains it was mentioned about the packaging problem and I realized that from my statistics we already have over that the most engaging
content comes from what was personal. What was something that nobody can have access to? Even a screenshot on my Zap, the one I built, no one can have access there. It's not my face there, but it's something I built, so I take the advantage of that.
The plan is for the next four weeks to achieve the following goal: three videos a week or two videos a week with one more personal content with a screenshot. Never mind. To help myself with doing the recording under pressure, I realized that it's very nice for me to be under pressure because I'm under pressure and I'm stressed, and when I'm stressed, I make things done.
So I recorded my video just a few minutes before I joined.

**Speaker 3 | 02:02**
Okay, I said.

**Speaker 2 | 02:04**
I have to say everything in the next ten minutes, that's all. I will do the edit right after with another deadline of 30 seconds. Thanks to web editing on those tools, it can be quite sped up.
The premise is not to serve an amazing cinematic video, it's about sharing your story, about how you can solve problems. So I'm very glad about that. I still have no results, but I feel more comfortable dealing with a goal believing in that.
So this is guys from my side.

**Speaker 3 | 02:49**
Very cool. I'm glad for that. And the video you're currently have is kind of a rough form right now.

**Speaker 2 | 02:56**
It's video is just click the button record.

**Speaker 3 | 03:00**
Okay.

**Speaker 2 | 03:01**
It took more than ten minutes talking, saying I have to cut it phrase like that and we're coming back because I can cut it. So normally very cool.

**Speaker 3 | 03:13**
Yeah. And Congress. Susman. We can't wait to... Can't wait to see it on the other side. Elli, what is true today? That was not true a week ago.

**Ellie Rofe | 03:24**
What's true, I have had a couple of really good calls with old contacts, so that's been really nice. Spoke to some people who are introducing me to some founders and some... VC. Well, one founder, one VC, but it's a good start and a financial year in the region.
I've been doing something where I've been trying to find people where I see a post that's really relevant to the world. I'm trying to be in... I've been looking at who's liking the post. And then I've been looking, not like 700 likes, but 20-30 likes and looking through the people and finding near peers.
So people who are informed of PR or designing like posters for science conferences and stuff like that.

**Speaker 3 | 04:05**
M.

**Ellie Rofe | 04:12**
There's quite a few people helping founders on LinkedIn, for example. And I have then been connecting with that group of people and I'm booking in stuff with those because I figured they already know the industry as well, and they're.

**Speaker 3 | 04:16**
Yeah.

**Ellie Rofe | 04:25**
And it's always very useful to have people who like, you know, I can recommend someone who does this, I can recommend blah. So that's been really nice. I've got a couple of calls booked in with people just to chat with them a bit as well and get to know them outside of just LinkedIn.
Then I've just recorded literally just before this. I'd actually planned to edit it before this, which shouldn't take too long because, again, I'm not... I'm doing a rough cut, but I recorded it and somehow corrupted the file.
So I have decided, I know, brilliance. So I quickly recorded it again and it's uploaded into Descript as we speak. I decided one of the big blocks for me is sitting in front of the thing. So I went and just recorded it on my phone outside in the garden, in a ninth round. Which, if I catch sight of it, it calms me down rather than staring at this formal thing. I've done one. I thought, "Talk about what you're feeling." That's what I talked about in different types of pitching fears you feel when you're presenting and talking.
Those are the sorts of things I feel when I'm doing video. Finally, enough not presenting, so I did a kind of metta process and I'm just like Dimitri said, not a ton of editing. It's too long. Fine. I'm just going to get it posted once we're off this call.

**Speaker 3 | 05:50**
Yeah, that's... I was gonna say that's fantastic and yes, very much similar vein.

**Ellie Rofe | 05:52**
So the similar.

**Speaker 3 | 05:59**
Can I ask how long you found yourself... I mean, the video as edited would be whatever it is, but how long do you think you found yourself monologging when you were doing the outside thing.

**Ellie Rofe | 06:09**
Well, I did a few takes because I was trying to... I find I need to ramble through it a few times. I think Robert mentioned going through a couple of times and then finding the natural flow.
So it's probably one of the things you and I discussed was a two-hour experiment. So from start to finish, it's probably taken me about two hours so far and then another 10 minutes editing and writing up the post. There was probably 30 minutes of waffling outside being interrupted by tractors and stuff as well, which was great, but I'll get that for you.

**Speaker 3 | 06:41**
I hear that. Super cool. Thank you for sharing. And, Robert, what was, last week, this... What was true today that was not true last week and then, you know, have this scrupulous service to you.

**Speaker 4 | 06:56**
So what was true today wasn't true last week. I ended up pretty much letting go of my assistant, Charlotte. That was actually a weight off my chest because it was just getting a little bit...
We've talked about this before, but basically, she was somewhere between... She was supposed to do an accountability person for me, but she was leveraging that access to me to be very pushy with receiving with just putting her own personal problems into her business, which reflected in her being so much focused on what was good for her and just viewing me as an opportunity to just collect the biggest invoices she could within the context of our relationship as soon as she could. At a time when I needed help so badly that I think
there's a hope, maybe a bunch of reasons, but let's just say she just wasn't aware of maybe how much that would be, how that would be received by me. The way it was received by me was actually just to be like, "No, thank you." Essentially, that is what was meant, but to be more specific, the way it was manifesting on her side was specifically, she would call me every day on the weekend and message me on Facebook, on WhatsApp, on email on everything.
I was just like, "This is..." And it was always under... This is the part that bothered me that it was under the guys or the geese are guys. But, other... But under one of those, keeping me accountable of saying, "You didn't check your tracker to tracker." This stuff that hasn't... It's not really a reason to call me multiple times on the weekend over an Excel sheet that... And so, the moment I just had the message saying, "Okay, yeah, no thank you, that's enough, basically."
Then that was a bit weird, because then the character dropped immediately after I sent that, and she immediately said, "Verbatim," "Okay, shit."
She said, "Well, this puts me in a tough spot." She immediately just said it, and it dropped away. It wasn't really about the tracker, it wasn't about anything. It's like, "Well, you know..."
I'm saying, "But it's..." It just was not a great feeling. But I think, in a lot of ways, there's a lot of things that tie it together to just what underpinned some of the struggles I've had lately, which is asking for help.
So, in a lot of ways, it frees me up, actually, to find the help that I do need in the business. So that's why it makes me feel free, because it is something that I've let go of, which allows me to fully focus on who is the person and what is the relationship that will replace this.

**Ellie Rofe | 10:06**
So 27 months. So my re should want to place this talk very much and know for some.

**Speaker 4 | 10:11**
Felt very much like breaking it up with somebody. It was a bit weird, but it was a lot easier because I could just do it over text because it's nothing that's not that personal, but
yeah, I cover this with rain, and it was very enlightening, actually. And I do in my heart of hearts, I do feel for her because I was there at that age where she's in her early twenties.
I know that, and she doesn't have the experience yet. It just makes me feel a bit older because I could see that Gray was telling me something very interesting that probably at that stage for people in their early twenties...
I've known her for about eighteen months. Usually, it's about the longest business relationship that a person at that age would have had at that time. It starts to fall apart, and you and I could definitely sense that. I could see that she really had no idea where to go from there.
So that was all for the good. The other thing I've been working on is just making changes around the assets basically on my website so that the wording represents what I'm trying to do nowadays, which is what we actually talked about last time that I was in the host seat.
I didn't manage to get every change that I wanted in there just because I'm so much of... I took this stuff so personally that it takes me so long to make, tweak it, and work on it.
But I did the work, and I actually... I'd like to... I'm going to share my screen, and then probably that's what I'll do for my host, actually. Just show... Then that way... Then I'd just be happy to get everyone's feedback and just whether it's good or bad or whatever the impression is would be very helpful.
That's something that I've definitely worked on. One thing I did was I posted a few videos, actually a number of videos in the last week. I posted one that was more interpretive, I guess you could say, like a piano background, a music one, I don't know.

**Ellie Rofe | 12:31**
My good.

**Speaker 4 | 12:34**
Ray, I know you had a chance to see it.
I think you had a chance. Did you... Did you turn on the sound, by the way? Just to Dickure?

**Speaker 3 | 12:41**
Yeah, no, I heard the sound. I heard... I was actually looking for your voice, but then, yeah, I heard the comic piano music.

**Speaker 4 | 12:47**
You're putting over it. It's the... Yeah, I took a different interpretation of it, but I think that it's something that the reason I put it out there was just because it's interesting, right? It doesn't have to be every video is like that.
But I think that it communicates whatever it communicates that I can and want to make a video like that. So another thing... Jeez. There was a lot actually that happened in the last week. I guess I'll just say that one thing, maybe the most significant thing, probably been last week was the fact that I got to have a real interaction with somebody who more or less resembles or goes in the direction of the business TOS & B that I would like to serve or be somewhere within that universe, let's say.
Universe is actually an interesting word to use because it is literally the name of the technology that they use, which is Universe Database. And when I say Universe Database, I'm talking about the Green Stream.
Like, when they... You go back in what they carved on the walls. In the beginning, there was light, and then there was the green screen. That's how old it is, from the beginning of time, and that's a huge opportunity. There's so much I've just been doing a lot of research into that.
That's another thing that I was doing yesterday. Ray was actually just going... I was putting together content. And after our conversation, I managed to put up another piece of content yesterday.
Actually, I really worked through that content to understand as I was going along at a deeper level the technology behind it and just help me to understand where the players are in the sphere. We're like, okay, so where does robotic process automation sit relative to multi-value, relative to asynchronous, relative to companies that build on top of the multi-value universe?
Just to understand where they are and then to see, to really leverage AI, actually to do very wide research, very fast, which I found to be very helpful with AI is actually just to have it. You can give it access to search engines and send out three agents at once.
It covers a superhuman amount of areas that I would never be able to cover on my own within 10-15 minutes. So that was another thing that happened. I really got a better understanding of that market, and it allowed me to write something for that market.
Then I just noticed that when I made that post, it's still very small. It's something I put out yesterday, and it's a feeler into the market, but I did notice I started to get engagement for people who I wouldn't usually get engagement from. When I look at their profiles, they're talking about enterprise and their background is totally different.
I've never seen this person before. He commented immediately and said, "Yes, MCP could be good for this distance." Maybe that's not the case, but just to say that that's something different than what I usually am used to seeing.
So that's what I'm pushing forward into. With that, maybe I'll just share my screen to show what I'm trying to turn this into words. How I'm trying to turn this into words, and you can see my obsession with aesthetics. My icons, of course, which I tried to make meaningful, but the idea was to focus it on...
I mean, just to say a very quick group. The way I approach my whole website is to essentially just make it like a digital sales letter. I keep it this way on purpose to force myself to keep it clear that the restrictions are on purpose.
But the idea is to say FCP integration specialists for significant business systems. I copied a lot of these words from the words that I had seen or what I had put on LinkedIn, what I had put in conversations, stuff like that. Significant business systems. I took this from Gray, your advice once, but again, maybe it doesn't...
Maybe that's not the best word to put here on this page, maybe not. That's why the reason why I'm sharing my screen. Yeah, just maybe to focus on that there. That's what I've been up to for the last week.

**Speaker 3 | 17:26**
Cool, man. And how can we be... Let's turn from my question to yours. You know what, how can this group be of service to you?

**Speaker 4 | 17:36**
I would just like to get advice, first of all, on, I guess, maybe advice on, does this represent what I just talked about? How could I better represent myself? Maybe to get to the business because that's where I see the big opportunity, which is really the thing in my mind. I'll just say this: I've worked for big companies before. I've worked for large companies before.
It's been a while since I've worked for a large company because I've worked for myself for a while. It changes you to work for yourself for a while. It really changes the way you view value. The way you view spending money and the way you view things.
But I've worked for big companies for the majority of my life before that night. Sitting back at that table with people who work for a company, just seeing it reminded me about how much money they have. I suppose and how differently they carry themselves, they're not... It's just such a different energy compared to working with founders and individuals and those types of people, and it just got me excited.
So, I really do want to get back to that because it just seemed like everything just seemed more stable all of a sudden. When in that conversation, you know, talking with speaking with a company like that, when they have the company credit card, they have a whole different dynamic.
And so, yeah.

**Speaker 3 | 19:11**
Okay, got it. So, the conversations always expand the universe of the potential of what they can really be about. I think the immediate thing you're asking for is essentially a roast slash workhopping of the above-the-fold of your website page.

**Speaker 4 | 19:31**
Yes, and I would... Yes, that's the immediate thing. Then maybe the doorknob would be how do I get to that? How do I get closer? Not necessarily, but get closer to, let's say, if the ultimate goal is to close a deal with one of those companies, right? I don't want to say that anyone has to answer the question of how to get all the way there, but how to take at least a few more steps in that direction.

**Speaker 3 | 19:58**
Okay. Kind it. Can we get, you know, with that idea of focusing on the bigger ticket? Could we get some way in from Ele and Demetris have a first round of thoughts or clarifying questions?

**Ellie Rofe | 20:17**
Do you want to go to tometrice?

**Speaker 3 | 20:22**
[Laughter].

**Ellie Rofe | 20:24**
Would you need to start waling?

**Speaker 4 | 20:25**
Ladies firsters. [Laughter].

**Speaker 2 | 20:28**
I have some thoughts already with a couple of things to ask. So, let me put my questions and let the conversation start. What is the goal for each one of those boxes to sell different value? What's the basic...
So, let me paraphrase it. What is the different value between those three boxes?

**Speaker 4 | 20:57**
So, basically, this box is for more like SMBs. These are for companies that have existing APIs and have something established in the way of an existing business system. So I keep it broad on purpose, but the idea is more or less to take AI mean, and this is really where I'm... There's a lot of ways for me to describe this, but I'd rather describe it in a way that is relevant to...
On the heels of the conversation that I had last week with the actual S&B, which is to extend the life of legacy systems, is more or less what I'm focused on right now. After that conversation, just because if you think about legacy systems, there's so much money in keeping them alive that you can position your value as if it costs $10 million to replace it.
It costs them $20,000 to keep it alive for another ten years or five years. That means that you're still saving them, still close to $10 million or whatever it is, right? But there's a huge amount... I mean, there's a logical calculation that made that.
So, again, there's a lot of ways I can cut this. I could take this and I could say, "Well, okay, if you're a company like Zeno, I built an API and I can bring in AI capabilities into your tool, and that is one way to create value."
But I think maybe the more powerful angle is just what I described, which is actually coming off the conversation with Ray, our conversation to RP and all that stuff. That really opened my eyes to that.
So, I would say when it comes to this, it's somewhere in my mind, at least it's somewhere in that area of legacy systems. Hopefully, that's what I'm thinking about. I think that because I have the interest in learning about stuff in general, I will actually spend my time learning about Kobol and learning... I will do it. I'm not intimidated by it at all.
So maybe that puts me in a unique position to provide something like that. And built-to-own is actually basically what I do right now. This is my bread and butter. In a way, if a lot of people will...
I think the market has proven that this is the easiest thing for me to sell. A lot of people would like me to build for them and to involve them in the process. I've done this a few times now with people quite successfully,
not for insignificant amounts of money. Not for as much as I would want to quite yet or as fast as I would want to yet, but fast enough that the market was happy with it, that they paid their bills, and this is something...
So that's what this is: co-building, getting into the phone with them. We build on Xano. I leverage MCP tools to build faster. I create more tools to build even quicker. They're happy clients.
That's what that is, more or less like what I've always been offering. This is actually another one that's maybe... I don't want to say speculative, but this is just based on what the market science is that the market is giving me, which is that I've had many people ask me about learning how to use the tool itself, like they want to learn how to use the Snappy tool of the MCP, which I'm not sure where that'll go, maybe that...
I mean, I think that for me, my interest is in a few places, but this is interesting enough for me to establish it there as one of my main offers because I think there's something very interesting in the idea of creating a new way for people to build software and to have people express that they want coaching. I can know and in clear terms, they want coaching.
So I figured, if just in my mind... Because I am a very visual person, this is how I even just organize it in my head. And this is how I think about these three offers, you know, like this is okay. Legacy systems co building and then training, coaching them and what?
Well, might as well. Maybe I'll differentiate myself by making the tool itself part of theaching and that's something harder to compare me against other people then. So I'm not just offering coaching. I'm offering coaching with my tool and so on.

**Speaker 3 | 25:36**
Elli, could we bring you into the conversation, Ma'am.

**Ellie Rofe | 25:40**
I the way, I think the icons are beautiful. It's all very clean and lovely.

**Speaker 4 | 25:44**
Thank you.

**Ellie Rofe | 25:47**
What I absolutely loved when you started talking about the customer MCP service piece is you immediately came up with the USP, the positioning, the benefit, all of that stuff.
When I look at this, it's not for me, it's not quite a sales landing page at the moment. It's almost more like a brochure. There are all the things I can do for you, and I would try. I know it's really difficult, and I sense I get this too.
I have this exact same feeling. You're in a transitional stage, so you're trying to go from where you are to where you want to be, and it's difficult to shed stuff and go, "No, I won't have this on there, or I will have this as the foreground."
You enjoy doing lots of different things. So, going, "I'm just going to trim this down to one thing," is all the opportunities last, and everything's like it just starts to feel boring. One note, I fully get it. I would be really tempted to strip the... Or create a version if you don't want to.
If you want to keep this there as an option, create a version where you create a sales thing so it doesn't tell at the top who you are. It says what you do for them. So a sales version for that custom MCP server.

**Speaker 4 | 27:17**
Yeah.

**Ellie Rofe | 27:21**
Don't spend millions replacing legacy systems. Let me, you know, revamp them, isn't the right word, but you actually put it beautifully when you were talking, when you were answering Demetrius's question.
So I won't trample on that, but literally just go boom. Save millions on this with how I can help you extend your legacy systems. That's an incredible value proposition. Shout it from the rooftops at the moment.
They say, "Dress for the job you want." At the moment, you're half-wearing one outfit and half-wearing another.

**Speaker 4 | 27:58**
[Laughter] Yeah.

**Ellie Rofe | 28:00**
So it's like, "Well, which is it?

**Speaker 4 | 28:04**
No, I totally actually, I appreciate that too, because that means that the words are going to... I mean, I'm going to after this part, I'm going to take those words from Krisp then, because I clearly said something back there that's going to
be the words, whatever words. I'm not even going to trample on it. So, because if I try to say it again, I'm probably going to say it wrong, so whatever, I'm going to just grab it from Krisp, and that's great to know.
I think that you're right about that.

**Ellie Rofe | 28:31**
And just to the one other thing is.

**Speaker 4 | 28:32**
I mean, I could. I have to do it one way or the other. I mean, I could look at it as an opportunity funnel in a sense, maybe just versions of the page that speak directly to...
But then, you know, sorry, I'm just thinking out loud. The advice was good, so it just threw me off a bit, which is good, because that's the whole point. Yeah. So no, I thank you.
I have to think about it. I think about how I'm going to make the changes that I have to make because you're right, I can't even start to say what I would do because it disrupts me. So I have to think about how I'd approach it.

**Ellie Rofe | 29:18**
I've been relistening. I've forgotten now. I've been relistening to "Influenced by Robert Sardini", which is brilliant. It's repetitive, but it is brilliant.
If people like you, they're more likely to buy from you. One of the easiest ways to get people to like you is to show your face over and over.

**Speaker 4 | 29:35**
Yeah, yes.

**Ellie Rofe | 29:35**
Yeah, so I get that this is somewhere at the moment. It's somewhere between a company and a personal brand.
In itself, it feels like a weird positioning thing. But I would be tempted. As you're a consultant as well as a creator, I would be tempted to have your face.

**Speaker 4 | 29:58**
Five. My goal is actually one of the things that I view as missing from this page. I totally intend to put my face up here. I just became so obsessed with the icons that...
It's honestly embarrassing how long it took me to make these icons. In itself, I could probably write a whole book about just the amount of iterations. It's insane to get it to this level.
The thing is, my next thing on the list is to put my face somewhere here that still represents it, but yes, for sure, I got to put my face up there. Not just here, but honestly, in the community and other places as well, which is what I fertilized this. I'm missing from those places, too.
Which is... Honestly, I'm amazed that it even grew to have that many people without having my face there, honestly, because I'm amazed that even people joined without even seeing me. [Laughter] So that's...
So maybe, yeah, it'll just get better results once I do make that change.

**Speaker 3 | 31:09**
Yeah, I have to totally concur on the person thing. But you and I have talked about that before, Robert. The... If I might, one thing I'm hearing come through a bit, and then I've been thinking... The first thing I thought when I looked at this was, I don't know what I'm buying. I took actually someone else into your site to go find the MCP because I thought the MCP was it. It was someone actually onboarding a state change, and I want to introduce them to staff. The MCP because they were interested in how they could do stuff better.
I got here, and I had no idea where to go. So I think you, Sppy, I think you know MCP for Zano is a cool side thing. I think it probably deserves this kind of treatment. Yes.
Then I think you have been evolving this page. I might propose that, certainly, for the above the fold part, I would encourage you to start with a blank sheet. In fact, I probably would encourage just using a physical piece of paper and just drawing on it.
I think you might find that gets a lot of clarity. That's what I'm imagining. So you want to have a big rectangle that is the Robert, happy band here, right? Then you have the... Hi, I'm Rob, right?
Then you know, the premise is right that you would... The thing you're selling, the unifying factor across all this is right. These are ideas, the customer MCP, this training. But the thing that LA was really picking out was you and your connection to these ideas.
That's what makes it incredible. You're the person who's worked with a serious company. You're the person who's worked with this new technology, and now you're a bridge between these two things.
All of that is about you. COM, MCP, CMCP service versus training. These are potentially hows of how you might deliver for the client eventually, but they're not the why they're interested and they're not the what of the problem that they're causing them trouble, right? Or even their desire in terms of their anticipated state. There are a number of ways that you can do it, and you can probably be putting those into a letter.
I think that the single thing that you're offering is you, who is credibility, your expertise, and your point of view. Yeah, and I look at it and I think that this has too little, Robert, and too much.
I like the icons. I like that they are your art because I like them because they're your art, you know? But the boxes... I've now seen them a bunch of times, that feels like it's there because that's what you had before.

**Speaker 4 | 33:57**
Yes. Yeah.

**Speaker 3 | 34:00**
Like, do I get more? Robert, the icons give me more. Robert, a picture gives me more. Robert, more. Robert, I think is what I would hope for here because that becomes clear. If I take someone to the site immediately, they get credibility, they get a reward for coming here because it was your ideas, and then they're seeing you. I see what you mean. I see enough for nothing. Elli, Demetris, and I... If you look at the failings of our sites...
I'll tell you, they changed. Plenty of failings as a promotional site above the fold, you get to find out what each of us looks like. Yeah, it connects right back to the person, and I think that's really important for that being able to shorten the distance people need to go across that bridge. Trust.
Yeah.

**Speaker 4 | 34:50**
I think that... I think that there was actually something in there about... I feel like I'm mentally ready to let go of the boxes. Maybe I'm ready to let go of the box. I feel like it's not your fault, like Robin Williams... It's not your fault, but the boxes are not my fault. I just...
But yeah, no, I see, actually somewhere where I can take this design to maybe have... Ultimately, I've realized now how long it's been since I saved the boxes and this type of thing. I realized again, this is hard for me to swim because it's all spinning around in my head.
But essentially, I think I can hit a balance that maybe just takes the best of what is here, which is I don't think it's the boxes anymore. I think it's the clean style is great. I think the icons are actually what I should keep.
I think the boxes can go. The icons can be... This aesthetic goes well with the rest of the page, and I can put my face up there. It just allows me to free up space because right now I have no space to put myself and got...
I'm so stuck on this vision that I, for so long, it's been three years I've had these boxes that I can't... It's hard for me to imagine life without the boxes. So, yes, that was very destabilizing.
Now I have to think about that. I don't have a problem. Probably the best way to do it is to just start throwing stuff on the page. Like you said, get a piece of paper out, pen and pencil out. Just throw my face onto the side of it. Shove the icon somewhere else. It happens quicker than I think. Once I have my... Once I know that that's what I want to do.
So, yeah, the boxes will go. That's the key thing. Get rid of the boxes and put my face up there. Okay, cool.

**Speaker 3 | 36:56**
Should we. Okay, so Robert, you we've sort of done this through the workshhopping, but you mentioned, you know, the door knob, right? The way we elevate the conversation. Yes, maybe we should turn to that for a minute.

**Speaker 4 | 37:08**
Yes. the doorknob conversation. I think the doorknob question was basically how do I... Correct me if I'm wrong, maybe I'm missing my own doorknob question, but I think my... I think the doorknob is essentially how to get in front of the people who would benefit from basically the people who have the money to spend on and seek to benefit from extending their legacy systems because those are people with million-dollar problems.
I'd like to help somebody with a million-dollar problem. I want to help somebody with a ten-million-dollar problem. So, that's what buys a ten-million-dollar house, right? If... So that's... I think, of all the things that I've done, that's kind of...
If it's hard sometimes to see, as things are going along, but I... But I think as long as that seems to be the right direction to go in and I'm thinking about it the right way, if that's a good goal to aim towards...
I think what I'm asking for is my doorknob question would be just how do I move closer to that? How do I get closer to generating more conversations with people? I know I'm not putting this on everybody in the group. I'm just because obviously, it comes down to me finding out the solid answers for that myself, but I think...
Any advice or guidance on the way of getting closer to that objective is what would help me, I think.

**Speaker 3 | 38:50**
Yeah, sure. All right, I well, could we go around the horn on that question of like you know, in the context I of this page just sort of more broadly with this marketing the that move up market that Rob was talking about. Ali, maybe we can start with you this time, then we'll turn to metrice.

**Ellie Rofe | 39:11**
Yes. So, do you know who they are? Like, do you know who you're trying to talk TOS.

**Speaker 4 | 39:20**
I think that I do actually. I mean, in a very... I don't know them as well as I should definitely. Right? Because then that would mean that I have nothing else to learn and that there's no way. There's always... I would definitely know more by next week and a week after.
So, but I would say that at the moment, I do know, more or less. I know certain characteristics about them, like the fact that they use Universe Database as their foundational technology.
I know that they seek to extend the life of their systems because they don't like change and they invest in it. I know that a lot of the companies that use this technology are banks and mortgage lending. A lot of the foundational... A lot of the stuff that is part of our everyday lives, the transactions we do online, a lot of it is based in that technology.
I know who these more or less are. There's not... I know a bit of the history behind it as well. I know that IBM created Universe and then they sold it to Rocket Software and then... So there are a lot of these companies. They are customers of Rocket, they are customers of these other businesses because they need to get these services already, right?
They're already getting these extensions of the life of these systems. They're already paying for it. And the way that they've been getting it has been through... When I say basic, I'm talking about the Universe Database that doesn't even have an API on it, doesn't even have a REST API. So, when we were talking about modernization, this is so funny. I sound like my dad.
This is what my dad sounds like. This is because of what my dad does with the universe and everything. But with the universe, essentially, it's so long. Basically, the modernization opportunity for it was to just add REST APIs on top of it, right?
So that you could just interact with it in a way that we view as very simple. But that was something that in itself was a service to extend the life of the system. So along the same lines, I view MCP as just pushing in the same direction, not necessarily replacing...
There's another part of it, which is robotic process automation, pushing in the same direction. It doesn't necessarily replace all the other techniques, but I see MCP as pushing in that direction, well, okay. It doesn't mean that you have to stop using the technologies that you're using, like the Rocket technologies, and you know, to extend the life of this.
The other thing, maybe this is the most... Maybe this part is actually the most interesting to me. It is a lot of these companies, like Rocket, that don't do application building.
I know this. They don't do that. Because my dad works for Rocket, and he always... He worked for IBM, and so that's why he... One of his things that he just always... It's an interesting thing to do market-based market research on.
But it's true that... Him, as a person who works for Rocket Software, knows for a fact that they don't build applications for their clients, and their clients are not happy with that because they want someone to build it. They don't want to build it themselves. It means they have to go to a third party.
That's the opportunity that's created for those third-party companies to extend the life of the systems. So who are they? I think that there are a few ways for me to find them. I think I know where they float around, the technologies that they use, and what they gravitate towards.
More or less, that's where it is in my mind. I have a rough idea of who they are, and I have no rough idea of where they will be if I wanted to find them.

**Ellie Rofe | 43:49**
Okay. I think if you can articulate that as clearly as possible at some point, just brainstorm it. The prompt I sent out gives you a start with AI as well. In starting to think about who they are.

**Speaker 4 | 44:03**
One.

**Ellie Rofe | 44:03**
And a tweak you can make to that just to get there's three bits of information I used to give it Google, but I think understanding things like the role you're looking for is good. I know it sounds facile because it's not actually the most important thing in terms of connecting with them, but understanding whether you're looking for a COO or an ops manager or.

**Speaker 4 | 44:24**
No, that's true. It's a good thing to mention just to quickly say why I think it's relevant. When I was in that conversation, it was like a microcosm of...
I think it's very interesting because even though it was a short and quick conversation, the CEO was there, his top technical person, you could call his CEO was there. I could sense that difference in attitudes. The CEO, his entire business is resisting change,
so everything he does is about resisting it, keeping things the same in a certain way. For him, AI represents an attack on a lot of these things if it's put in a certain way. He is a person who is hard to get to.
The CTO is a person who is very well aware of the benefits of AI. He is the person who's boots on the ground doing the programming. So I found even in that conversation that I've maintained a connection. After that conversation, the person I've been going back and forth with is actually the CTO who I give access to my repo and I show them my templates and let me show you about how MCP works and all that stuff.

**Ellie Rofe | 45:29**
Yeah.

**Speaker 4 | 45:37**
So yes, totally agree. And I don't think it's silly at all. Because I. I've. I think it's totally right.

**Ellie Rofe | 45:46**
So then, on a practical level, I'd be looking at... If your dad works at the place that sells the software, I don't know what your data laws are there, but is there a way that you can have a list of all the companies that have got this software?
Because then you just go and find the CTOs and then you just connect with them all on LinkedIn for a st.

**Speaker 4 | 46:00**
Five I could definitely that's actually an interesting idea. Yeah, I should definitely go and shake them down a bit. I think, yeah, for sure, he gives... That's still...
I mean that person who we went and met. I mean, why are we there? It is because he gets leads from my father, like... Because he... I mean, his whole business was built on those leads, so he's not shy to say it, so that's actually a really good point. There's opportunity there, yeah, right.

**Ellie Rofe | 46:44**
Get on that ATS train, my friend. My God. I don't... I mean that slightly sarcastically, but use it like.

**Speaker 4 | 46:51**
No, I get it. No, I get it.
Yeah, for sure.

**Ellie Rofe | 46:55**
And if you're... Because the other thing, just on this... Connect with people on LinkedIn, you don't have to cold message them, they just start seeing your content.

**Speaker 4 | 46:56**
No, yeah, that's true.

**Ellie Rofe | 47:03**
But if this is the system you want to be using and focusing on when they arrive at your website, I would. Especially if you want to sell them lots like high-ticket stuff. I don't think they should be seeing a free community. I don't think they should be seeing YouTube newsletters. They definitely shouldn't be seeing the word "free", by the way.
That's an anchoring thing, which is like, no.

**Speaker 4 | 47:27**
Yes.

**Ellie Rofe | 47:27**
But when they arrive there, they're like, "This man is the answer to my problems." He has called out the things that I'm struggling with that I can then do.
Even if that feels like it's shutting the door, it's a base where you go. "This is my path to cash flow." This is my path to build. You can put it on the Robert Bulus.

**Speaker 4 | 47:47**
Yeah, no, you got it right, that was it.

**Ellie Rofe | 47:50**
So sorry if I've pronounced that incorrectly. You can put that on a Robert Bosch UK.com site or whatever and just have it as your consultancy if it feels like it's taking you too far away from all the other things you want to do. I don't know.
But they should be getting there and just seeing that this is what you do and that you are the answer. That's what I'm thinking. So I've taken up quite a lot of the time.

**Speaker 4 | 48:17**
No, I was going to say that I and I totally... I think that if I can become very passionate about anything, that makes me a lot of money, I think. So, you know,
even if it's like paper straws. If paper straws started making me a whole ton of money, you'd bet I would be all about paper straws. I'd be the most passionate guy about it.
So yeah, I think that maybe focusing it down is not a bad idea. Maybe behind that one door there are another thousand doors. As much as I might view it as shutting off, opportunity could actually be what opens things up.

**Ellie Rofe | 48:56**
Yeah, I can do all sorts of crap for people outside of Pitch DEX, but at the moment I can charge 10,000 pounds for a pitch deck. So that's my path to cash flow. Everything else comes off towards... Everything else is like backdoor stuff.
That is the path to cash cashway.

**Speaker 4 | 49:11**
Yeah, the sharpest point of the spear, I guess, right? There are other offers, but the one... Yeah, it's hard. I still find it hard to let go. But yeah, I'm there for for.

**Speaker 3 | 49:29**
Yeah, and I just want to put a hat on. What Elli was just saying at the end there is really important. There's a difference between what people could buy from you versus what you're selling today and what you're selling just as it is. Selling a pitch deck. She's putting out there having a clear pitch deck story that doesn't keep people out of people who like Ali or CLI's content. Wants some other kind of help from calling her and asking for something that is different from that. She probably has to be off with a stick a little bit.
Similarly, you are not going to be prevented from other people helping you. You're going to get reference stuff. You're going to get people who think, "Hey, wait, you really know the Zoho stuff." Guys sort of help me out with that thing.
Great, and the fact that your site doesn't sell doesn't mean you're going to be necessarily all that hurt if anything. You're ahead of it, right? When people say, "Wait, you're moving ahead of that." I'd better get in to hire you for this other business before you sort of have completed.
You know, zooming away from this particular market. So the particular what they see on the ascent, you know. So all of which, by way of saying that, one of the points of conservatism that you might have had about your site and about your marketing, is that this isn't a complete reflection of me.
That's fine. The purpose of marketing is not to be a complete reflection of you. It is to help you sell the thing that you most want to sell now and that you most want. It is leaving information on the table, right? You're not that you're not pushing forward to them, right?
So, they didn't... Your job is not to give the most complete picture of you. It is to help them understand the part of you that you're selling today.

**Speaker 4 | 51:04**
Yeah.

**Speaker 3 | 51:05**
And just from point of view, giving yourself permission and saying, "Wait, well, I still don't want to lose that." No, you do want to lose it from your practice. You probably won't lose it from your home page. You lose it from your primary marketing branding.
But have you?

**Speaker 4 | 51:18**
Yeah, that's actually very helpful as well, because I do sometimes view this as maybe something that has to represent everything that I hold dear to me. But it's really not. And it's hurting me to do so because...
Because, yeah, it just like you said, if somebody is in the position who's making a decision to extend their legacy system and they want to make a decision on that and they're looking for information regarding that. This page is not speaking towards that.
It's not telling that person that I am thinking about their problem and you know, like that. This doesn't speak to them. I'm not sure who to speak towards. It's probably just speaks towards me. It's something for me to think about and work on.

**Speaker 3 | 52:09**
And to be just before we run out of time here. I was hoping to bring you into the conversation as well, because you've been thinking quite a bit about working with different kinds and levels of customers and, of course, levels of your own practice as well.
Like to Ellie's point, being in that transition and dressing for the job you want to have. Based on what you've been hearing so far, what do you have thoughts on? Robert's question, right? Of focusing his efforts more towards the
market he's trying to go to.

**Speaker 2 | 52:39**
Yeah, I think basically what we discussed, guys, in the past three sessions here is the importance of finding the right profile. Understanding it. Ellie made one step further from what she said in the intro. He finds who else Ted to sell them and tracks the way they do it first and then who engaged with them.
So most probably they're right there. It's very important. The second thing that is already mentioned here is about talking about with somehow. What? This is why I understand it is to talk with their language and the language is their pain point. I see for me, I don't do it in a great way,
but the best way to engage with someone who has a problem with their ERP is to use exactly the keywords and the problems. For example, it's for me. It's quite easier to use this example for an e-commerce company who wants to scale up their business in a marketplace. They may have problems with fulfillment and they need the automations in picking their orders. These keywords inside their operations could alarm them and say, "Hey, the Rob is talking my language. He understands that."
So this is where we fail. Sometimes before that, it's important to bring ourselves upfront. I see that talking with video is more hard for us, but easier for them to understand what we're doing and how we do it.
Finally, LinkedIn maybe is not the final step. It's not the only place to find them. They may attend not physical events in your area, they may attend other communities and join. Ali mentioned something. They don't want to see a couple of things like the free. This is really important for someone who is willing to pay a few thousand dollars for a few hours of consulting. They don't care about what free is. Or do you sell for free? They don't care. They care for their job to be done. The challenge for us, for every one of us, is to make down our promise of what we promised them.

**Speaker 4 | 55:37**
Yeah. No, it's really interesting just to even hear the things that you guys are mentioning because it so much reflects the stuff that was coming out of that conversation from those people. It reflects what they were actually saying so closely.
Even for him, the first thing he didn't say was any time that he wants to know. I think the first thing he said when he sat down was, "Is there any money in this?"
As soon as he said that, he just wanted to know, "Is there any money in this business?" Before he even said hello. So at any time that I insinuated that because I was pretty...
I mean, we're sitting there in a Greek restaurant, just talking and just being casual. So I'm just any time they say that, I'm just here to have a conversation and learn. Learning said, "Well, you gotta make money."
He's like, "You gotta make money with it." So he wasn't interested. Like you're saying. At any time, he doesn't want to hear it. It's for free or anything. They actually do want to get down to brass tacks, like how much will this cost?
So, yes, I think to your point, dimeria, I think what you're telling me and what you tell me, Ali, is that it's been reinforcing something that those parts of the conversation. So I'm definitely going to put it in serious consideration and get rid of the word for you.
I think it's hurting me.

**Speaker 3 | 57:10**
Okay, great. I think we're a little bit past time. Robert, thank you for bringing it in. There's a great pairing of questions. I thought I really liked the way that you structured it, that you were thinking about what your doorknob question was, right? That allows us to elevate that earlier in the conversation.
I think that's something we should try using next time, too. So I'll be trying the same. How can we service each other? I'll be asking, "What's our doorknob question?" I decide if we can move that forward, and the more we do that, the better service we are to each other.

**Speaker 4 | 57:43**
Awesome. Thank you very much, all of you. Thank you. I really appreciate it. Thank you.

