# State Change Mastermind - Jul, 08

## Key Points
- In the past week, Speaker_2 aimed to deliver two videos, one of which included personal content to increase engagement. 
- Speaker_2 found it beneficial to create videos under pressure, often recording just before joining meetings and editing afterward. 
- Ellie connected with near peers and founders on LinkedIn, focusing on industry-relevant contacts. 
- Speaker_4 ended the relationship with his assistant, Charlotte, due to misalignment in their professional relationship. 
- Speaker_4 updated his website content to better represent his current business goals and target market. 
- Speaker_4 explored the market for extending legacy systems using Universe Database technology, engaging with potential clients. 
- Ellie suggested that Speaker_4 should create a more focused sales landing page highlighting his value proposition for extending legacy systems. 
- Ellie recommended that Speaker_4 should include his face on his website to build trust and personal connection with his audience. 
- Speaker_4 identified the need to target companies using Universe Database for extending legacy systems, focusing on their CTOs. 
- Ellie advised Speaker_4 to focus his website on high-ticket consulting services, removing any mention of free services to appeal to his target market. 


## Action Items
- **Ellie to edit and post the recently recorded video about pitching fears and presenting** - _Ellie Rofe_
- **Robert to leverage their Rocket Software connections to obtain leads for companies using Universe database**
- **Robert to create a focused sales landing page specifically for legacy system modernization services, removing the current three-box layout**
- **Robert to add personal photo/headshot to website homepage to build trust and credibility**
- **Robert to remove the word "free" from the website to better align with enterprise client positioning**



