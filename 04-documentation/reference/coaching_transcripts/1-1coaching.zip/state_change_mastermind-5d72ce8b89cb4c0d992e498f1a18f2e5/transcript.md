# State Change Mastermind - Aug, 26

# Transcript
**Ray | 00:07**
Hello, Robert.

**Speaker 3 | 00:09**
How are you doing? Right.

**Ellie Rofe | 00:11**
Excuse me.

**Ray | 00:12**
All right, just doing my homeschooling routine. Plus they're rebuilding the front and back porch here in our little.

**Ellie Rofe | 00:22**
I purchas.

**Ray | 00:25**
You live in a rowhouse on a ski mountain, and they're fixing them all as part of... I'm not sure why they're doing it right now.
I get to remember what it was like to live in the city right next to a building that was going up, and the pile drivers that were getting the piles, and that was exciting. But yeah, hopefully they'll be done by tomorrow.

**Ellie Rofe | 00:46**
To get.

**Ray | 00:47**
Thursday.

**Ellie Rofe | 00:48**
Yeah.

**Ray | 00:48**
Friday was all about getting the back porch ripped out, and then Monday, Tuesday, and maybe Wednesday too.
It's all about the front porch.

**Ellie Rofe | 00:57**
It's a beautiful sound.

**Ray | 00:58**
And it is.

**Ellie Rofe | 00:59**
Ey, the music of construction.

**Ray | 01:02**
It is. I wasn't expecting it to really be all that disruptive, and then it was quite disruptive. Just earlier this morning, just going bang and trying to deal with the children.
Actually, there's a little meetup that I run that Robert is in for people building developer tools around Zeno. I just could not hold all the pieces of it together this morning. So, Robert was very thoughtful and the other members were saying that they would be able to do it later in the week first, and then later when I don't have meetings anymore, maybe I can take the laptop and just go somewhere else where I don't need quite the setup.

**Ellie Rofe | 01:31**
Yeah, no, it's ridiculously distracting. Yeah, I think that makes sense.

**Ray | 01:48**
I appreciate you.

**Ellie Rofe | 01:51**
No. Well, we've had. I mean, last summer. Nick was working on the roof for a huge amount of the summer. And the roof is kind of just the roof. The barn is just behind me here.
And it was just like bang, drille, drill, bang, drilled dril, drill, saw soil. And it is after a while, you're starting to kind of twitch with it. God, this is too much. So yeah, I hear you, it's really annoy.

**Speaker 3 | 02:16**
I highly recommend noise canceling earphones to anyone. I would as well. There you go. Actually, they're like it's kind of crazy how I don't know if you've ever used in noise canceling like earbuds.
Like, yeah, like, say then, you know, like they're just like they go space quiet. You it's like a vacuum of silence. So it's yeah, I wouldn't be able to survive otherwise. [Laughter] I'm very confident.

**Ellie Rofe | 02:44**
Yeah, maybe I need those and then just put ambient sound through them. That might be the nice balance because there'll be more construction here. So.

**Speaker 3 | 02:53**
The iPhone has that actually too. It's built in. If it's one of the... So you can listen to your music and have rain behind the music, so it'll overlay over both. It's an interesting feature.

**Ellie Rofe | 03:03**
Wow, yeah, that's really nice. Sadly, I've got an Android.

**Speaker 3 | 03:08**
[Laughter] You probably already had it five years. You probably had that feature five years ago then.

**Ellie Rofe | 03:15**
Possibly. Possibly. I could never go with an iPhone.

**Ray | 03:21**
S go around the horn here. What kind of week has it been? Robert? What is true today that was not true this time?

**Speaker 3 | 03:29**
We go true today, not true this week. Well, basically, I'm building my LinkedIn. I think I'm posting more overall. I'm more in that flow of posting and just trying to... It's still not an easy thing, but I'm pushing through and it's easier to get it done and find the enjoyment in it.
That's partly why I feel myself doing it more often because I actually do feel that drive to do it. It starts to feel like building something to me, and maybe that's where I like to do stuff with software and with these tools because there's that feedback loop of, "Okay, I did something, and now it's here."
I'm building it, and then with social media and those types of actions, I felt more like screaming into the void where you just do something and don't get a lot of feedback, but now it feels like there's a certain type of building that does happen when I take the right actions on LinkedIn and so on, which mostly just involves putting myself more front and center. Then the feedback is stronger, and so then that's just more encouraging. It just feels more like building something, and so then I'm just doing it more often. Other than that,
there's a whole side of emailing people and just trying to get better at it. Then there's the technical side trying to get this Universe demo tool MCP up and available, which is almost done. I have a sales call or a type of call this evening with somebody. Let's say I have a call with John Pritchard from Zeno.
It's funny. I messaged him, and halfway through our exchange, I realized that he doesn't have any idea who I am. And that I just kind of messaged him saying, hey, we should meet, like, and he.
And he just started kind of answering me like a robot. And I wasn't even sure if he was, if it was him or if it was a robot. And I was and I went on. I just thought about it for a while. I didn't even answer for a little while. I just thought about it and I thought, he doesn't know who I am.
And I thought, because he's kind of hesitant a little bit to get on the phone to him. Yeah, basically, I just DA just saw him. Listen, like, Rayck is a mutual friend. I you know, he just thought that like that it would be an enjoyable conversation, like for us to meet and talk.
And then he immediately just gave me his kindly and so we're meeting. But yeah, but just that was like a bit of a shift. I'm like, yeah, this is good because he they again, like Ray, he told me once, they probably have no idea what about, you know, what's going on. People focus on their own stuff and that's it.
You know, just that's mostly what's changed between today and last week. And I got the. The SDK is doing. Had a breakthrough. A bit of a breakthrough yesterday with it actually, because I managed to basically rethink how I was doing it. I kept trying to build these templates to use the SDK Ray. This will make obviously sense to you because I've shown you, like, how it works and everything.
But now I just kind of skip I'm skipping that step and just putting this strain into the hands of the AI and, the results have been interesting. So yeah, that's it. Cha and I didn't have a lot of sleep last night, so, like, I'm barely awake, so that's and I'll just finish on that.

**Ray | 07:53**
Fair enough. Okay, I appreciate that. And retris was true, we go.

**Speaker 4 | 08:03**
Sorry, I think I was guded or you were gued.

**Ray | 08:07**
I beg your pardon? I'm doing the weekend review. What is true today that was not true a week ago.

**Speaker 4 | 08:17**
The greatest truth for me, guys, is that I have too many things around the queue since I'm coming back from a week off doing other kinds of work outside the pharmacy. I mentioned it many times. So today I started doing my homework.
From what we discussed in my previous hot seat and the conversation with Ellie, delivering a couple of things fast, and I'm trying to put everything on a priority list because it is more helpful than I had. I had a huge list of random stuff I had to take care of, which did affect me negatively.
So I prioritized joining and into communities, finding the packing words for my branding, and have the goal to complete this new version of my website by the end of the week and start posting more based on the new packing approach.
Yeah, actually, this is it. I feel just overwhelmed with the stuff on the queue.

**Ray | 09:39**
Okay, fair enough. So, yeah, I hear what you're saying in terms of there being lots of possibilities here.

**Ellie Rofe | 09:43**
From.

**Ray | 09:50**
All right, then, let's turn our attention to Ellie. And was true. It wasn't true a week ago.
I think that can lead us into how we can be helpful in having your next week be one that is not overwhelming with possibilities but rather making the ones that you want to make happen.

**Ellie Rofe | 10:08**
I mentioned to Ray last in our call at the end of last week. What I realized is that whenever I do something new in the business, and this is very much to do with how my brain works, I get very taken up with it very intensively and it takes up way too large a space in my brain.
So I was doing these calls quite a few calls. Pro, I think it works about 14 hours of calls a week. There was a time a while ago that would be nothing, but because I haven't done it for a while, it was suddenly novel, and those 14 hours somehow took up about 28 to 30 hours a month or something. It just expanded in terms of the amount of brain space it took up.
So, it's been a great week. I had some fantastic conversations. I learned an awful lot. I think the more I learn about people and meet people, the more you meet other people, and they introduce you to people.
It's a really nice cycle, a virtual cycle. This leads into what I guess are questions, thoughts, and this is what I really just need to do now.
I know what I'm trying to sell, who I'm selling it to, where I'm selling it, and how I'm doing it. It's just execution. It's just consistency and plugging through with the current strategy I have without reinventing the wheel, adding new things all the time. I think just building consistency and execution.
So, I guess two things. Is that the right assumption? Should I always be strategizing, or is it fine to just try and build a rhythm for a few weeks? Part of the reason I'm thinking that is we have my other half brother coming to visit next week, and then the week after that, I will be flying back to the UK for a couple of weeks, so there's already going to be quite a lot of disturbance and shifting out of a routine.
Anyway, not that I have much of a routine, but at least my home environment. Yeah, I just... I guess there's... Is that the right assumption? Then the second part is the old saying, "You don't rise to the level of your ambitions, you fall to the level of your systems." What are the systems you guys have in place? Dimitrius, you just alluded to having priorities.
I think I might occasionally overengineer systems. I have a huge Notion set up with how to manage projects, tasks, dailies, and all sorts of stuff. But what do you think are the systems that are creating the most value for you in your business or life in general? Is that clear? I'm very sleep-deprived and a little bit anemic.
So I'm like, "Am I making sense or am I just blu?

**Ray | 13:08**
I think these are good questions, right? The question of strategy versus execution is one that we all deal with all the time. Then the more specific question of what are your systems?
I think is an excellent question to ask. So maybe we can start with the things that we know and then follow up with the things that we think. Betrix, maybe we could start with you, sir.
What do you do to the extent that you have them formal or informal? What would you describe as being the systems that you're using today?

**Speaker 4 | 13:46**
Since we have two parts, I mentioned from LA about the consistency. I keep you on track, and the systems. What I do is I try to keep everything as simple as possible, just a list of what I have to do in order to keep everything on track. A user table. It could be your Notion. It doesn't really matter. It could be either your Google Sheet.
It's not about the software, it's about how you use it. At the same time, I track what I do on paper like this. I keep notes. I add the same task from our table into here and back and forth.
Because during the day, I have a couple of things coming on my brain, so I try to have somehow a sync. The thing of having everything in digital is that I can handle it. Drag and drop to a different date, track it, review it, and based on something new like a new Slack message or a new email coming from a contact, I can reprioritize them.
So this is where it helps. Since I charge by time and I count my time, I try to track the time consumed on every task. Because of disruptions, it's not that easy to keep track of everything. But the purpose is not to track everything like having someone with a stopwatch, it's just to have an overview of your workload and where you spend most of the time and review if it was a productive week. I see myself when I change environments since I moved from different homes in the most recent time it destroyed for two to three weeks almost my routine.
So I lost a way of thinking because here I have different disruptions and so on. So it's something we have to keep in track, how we can remain consistent. My greatest advice came from my trainer, running trainer. When we do marathon exercises.
The thing is that in a marathon, we have a curve. When you say, "Tomorrow, I want to go on a marathon," you have to run on a curve of training for four months, 12 weeks minimum, 16 weeks maximum.
So the thing is that you increase the volume of what you have to do very slowly. Very slowly, you know from previously that you were going to remain in this disruptive period for six weeks. Great. It's good to know upfront.
So you can schedule that from the beginning till at least the middle or the 60% of the period. You should increase very slowly the rate of the things you add. Don't expect yourself to be a machine. Expect yourself to take the advantage of the change. New inspiration, new stuff, new conversations coming to the door. Don't close it. These are opportunities, honestly, opportunities I honestly lost in the past because I'm a little bit psycho-pressure. I like pressure myself on that.
So this is wrong. Avoid that. And after the peak of the 60%, start decreasing again the volume. So in that way you will be prepared to come back again. I see this framework work. To me, the thing is that when I'm moving places, I move in purpose to do some other totally different stuff.
So it comes a huge difference. But one year ago till my life was more normality. Let's say I had this in my mind and it was working. And since you're gonna start from a minimum volume, you can see here that which are those things that you have to do by default every single week.
So try to do the first week only those things, nothing extra and the week after one symbol extra and then move forward by increasing slow and slow rate.

**Ellie Rofe | 18:45**
I like that.

**Speaker 4 | 18:45**
Robert.

**Speaker 3 | 18:58**
Sorry about that. I think I don't know if I'm the best person to ask about systems in general. I mean, well, actually, when it comes to... I can see a lot of the stuff I'll create is it's all based systems.
So I'm very much, like, systems minded. But when it comes to my own process, I just feel that I thrive in chaos in a way. And so I would just say that, in a lot of ways, I think that the only systems that I have are just showing up consistently and just staying true to certain principles.
Almost just if every day I can just... If I make sure that whatever it is, that I feel good by the end of the day. Then for the objective to feel good, then the way that I get there is I just in the morning, I do some type of social media outreach.
I know I'm going to do certain things, and by the end of the day, I'm gonna. I'm going to feel good. I'm going to feel like I got something done. Then for me, during the day, it's just about... Because I like what I do is so much...
I feel that it's something that we can control. The way that we go about our day and everything, we get to choose the technology we're with and the things that we do. I try to choose the most interesting ways that I can do anything.
So that includes the way that I try to make everything just somehow enjoyable to me. Now, that comes with the downside of sometimes taking a lot of work to make things enjoyable.
So there are probably easier ways to live your life, again, I get into the chaos of it sometimes, I'm... But that's what I like. I like figuring it out, and I like pushing through that, even if I result with not getting a lot of sleep sometimes.
So because the result is something, for example, right now, I made a very intentional push from, I don't know, probably the beginning of this year, I would say, to try to really work more closely with AI and to have everything I do... I don't like to go and draft emails, I want it.
So what's the more interesting way I can do it? They're like, "I can talk to this AI, and it will listen to me, and it will be interesting." This is exciting. The first part is exciting. It gets all exciting.
If it can be exciting to me in that way, then that means more emails get sent, right? Or it gets me paying attention to that and then massaging everything that I do into something that somehow aligns with my interests.
So it's not exactly... In this, I think it's just a system that actually evolves as I evolve in a lot of ways. Like I and maybe that's the main reason why I even just look at it this way now. It's because I've built a lot of stuff in the past, which I looked at as like, "This is a system, and this is going to be a system for writing content for me, and just a new system."
I never ended up using it. I think it just reminds me of those tests that a lot of the time that I have. I have plenty of exams where the teacher would say that you can bring in a formula sheet.
Then I just go, and I just... It's like microscopic, that's how small I'm writing on that sheet. It's not even legible by the end. It's double-sided. It's like origami. I never end up looking at it when natural tasks come because I've spent so long going so carefully to document all the content on the sheet.
So that's the point. I've noticed that I go and I do these exercises, and I try to build these systems where really the main takeaway is I've just invested more myself, which is all I can do, right?
If I get... That's the only system that I have at the end of the day, it's me. I am the system. I just try to... If I can just walk a bit straighter every day, then the system will continue to hopefully evolve.

**Ellie Rofe | 23:41**
I love the system. It's me. That's great.

**Ray | 23:43**
The system is really good insight. I think a lot of that, we rise and fall to our systems because systems are constraints, right? So, there comes a point where we're being pushed, and what is the... When we are pushed, that's the system that pushes back, right? It
creates the back and forth for it, and we don't have any system or the system is at a very low level. Well, then we can fall to a lower level. I think that's the point of the expression, right? What?
I have... I think these are some really good bits of counsel. I fall back on studies, sales, a lot. In terms of the way that I think about this, what am I not doing enough of? If I find myself grinding or if I find myself blanking, it's like, "Okay, what do I need to switch to?" This gets to your question of strategy versus execution because we are all intellectuals and we're all looking to exercise our brains,
but that doesn't mean that, for example, when we are selling, we necessarily need to be using our brains. Maybe that's the part where we just need to be moving and doing the reps.
But the brain still wants to have activity, so there are two ways of going about it. Are you familiar with Heaton Shaw? He is the founder of... He started a company called Crazy Egg. He went to work. He started another company.
I think he works for Dropbox right now, and he's often on YouTube, and he talks a lot about the founder type considerations. For me, the favorite story he told about Heaton Shaw.
Okay, what happened was like Egg Crazy Egg. They had this company, it was going, it was cruising along, and they were gaining customers, whatever. Then he would have a brilliant idea, and he would run into the room, and he would have his Heaton Shaw.
Then everyone would stop what they're doing and accommodate whatever the big idea was. Because, of course, this would be the big, brilliant thing. He has the energy of a founder, right?
So he's getting everybody aligned behind him. They were doing like, "Wait, why do this?" They did it because he had an idea of how much of this. Just because he was bored with what... For?
I think that can be really distracting. So, I think that has to do with... He had ideas, and those ideas should be fed through study, right? But what he was doing was... People around him were all focused on shipping, and it was being focused back towards shipping, which was disrupting his ability to ship because he was taking that intellectual energy and applying it to the wrong part, at least in my framework of that triangle, right?
So, what I find is that when my constraints are about incentives, if you will, what am I doing? I'm trying to read more, and that is then consuming more of that energy to learn things and get my brain exercised and have that in study, and that means I'm not looking for that to get solved over in a ship.
That keeps me from having the wrong kinds of incentives. On that side, there's study, and then study becomes a thing I can do when I am, frankly, if my brain isn't working quite as...
Well, right, I can go. I can put in a book, and then I'm letting the book carry me along. As I've learned about that, I've learned there's certain things where I need to be very proactive.
That's my first couple of golden hours of the day. So, one thing I do is get up early in order to be able to make room for that. That becomes a system, any constraint, a constraint. Because it's the same by when I get up and, frankly, when my children get up.
Because that is going to end that sort of quiet hour. I have the study part, so I'm not doing the reading then because I know I can do the reading later, and then the... And I have the question of some degree shipping, some degree sales which are you know counter events.
And I learned I just book more meetings. I will take more meetings on spec, partially because I know that me spending an hour in a meeting, talking smart with somebody about something is probably a pretty good use of that time, right?
So the... So it's on my calendar. That's providing more structure that way, even as my calendar looks like chaos because I give it out accountantly. People are able to schedule themselves in, but the way they come in the afternoon, that's then carrying me along, right? Allowing me, much like the book, to be a little bit more reactive but still adding value.
I will remember stuff from the book which is useful and I will have contributed value in meetings as well as having the recording, whatever that turns back into content and all that business. So that's why I've approached structure. I don't have as formal a thing as like the GTD or like the productive flourishing or one of those.
I've read up on them, obviously, because I can name them, but what I found is that a couple of simple things work well for me, and that the constraint, the best constraint I have is the calendar.
Just go to take more meetings because that puts me into the market and just creates a lot of value. Then the thing that the big system, if you will, that I put in play to create value where otherwise it's hard to find is getting up early in the morning. I appreciate it's not for everyone.
You figure out a system that works for you is going to matter. But those are the tricks I use to try to fill out my study. SL CH.

**Ellie Rofe | 29:05**
That's really interesting. I do often get up in the mornings early. It just really varies depending on how insomniac I am at that week, basically. But that's fine. I think it's interesting. The more I listen to you, the more I am the system, which I love because it's a bit like Judge Dredd, but... or it was I am the law.
It's important, I think, for the physical system as much as anything. But I guess the reason I asked and this is probably just a little... Can't think of the word, peccadillo of my brain. Maybe...
So when I'm trying to get healthier through eating and stuff, the best routine I've found is one meal a day. That's because my brain is so instant gratification. If I'm not conscious about things, if I eat two or three meals a day, I won't have vegetables or fruit in any of them because it'll be...
I'll have that the next one, but I can't be bothered at this point because I'm involved in other things and I can't be bothered to think about what I'm eating. I'll just grab something quickly. If I have one meal a day, it will be mostly veg and then other, you know, healthier bits because I'm actually focusing and thinking on it.
But I think my default is if I don't think about what I'm going to do in the day or if I don't give myself some kind of constraints, which are like, do the things you don't like. Which is weird. I love vegetables, but it's just the way my brain is working on instant mode. Then I won't do the thing.
So I haven't posted on LinkedIn because I haven't been thinking about posting on LinkedIn. It's just that it doesn't come into my head if I don't have it in some sort of system. So yeah, it's a really interesting thing working out where the balance is between flowing with energy and thinking about modes of work and stuff and just cracking the whip on.
It's not because I will just be far toasting around, it's because I will have found something that's so interesting that I would just be like, "Great, I'll stay here and play." And I won't bother with posting on LinkedIn because that's a bit like lumpy and miserable.
And it's not even once you get started, but, you know, it feels like that in the anticipation of it. So I think maybe one of the things I need to do because this sounds to me even as I'm talking, this sounds to me like accountability. I need to get back into using Focus Mate, which I used to use to quite good effect, and I think maybe that's a useful thing for me to do.

**Ray | 31:56**
Can you share a little bit about your experience of FocusMate because sometimes I hear people bring it up, and I'm not sure I'd love to hear more about how you found it to be helplemm.

**Ellie Rofe | 32:04**
Yeah. Do you remember chat roulette? But probably very short-lived chat system where you would go online and randomly meet up with someone.
Obviously, very quickly, it was taken over by exhibitionists who would be sitting there naked in front of people. It's a bit like that, except you don't have the exhibitionists. It's slightly more regulated, and you have 45-50-minute sessions, and you get matched with someone who is doing the same thing. You have a couple of minutes at the beginning where you say what you're going to do in that session.
It's just pomodoro with accountability. Then you do that session, and at the end of it, they ask you how you got on, basically. I have used it to a really good effect before, and
I think sometimes when I'm deep in flow, I'll end up canceling sessions because I'm like, "I can't be bothered to speak to someone now." I just want to carry on and carry on doing what I'm doing. And that can become a habit.
I think sometimes there was a rush of people where I was just on. And there were people just having really loud phone conversations and not putting themselves on mute and wanting to chat phrases at the beginning.
But I think that's a case of just curating who your favorites are and who you connect with and stuff. But yeah, it's actually really effective, especially for those. I think you mentioned what's the next hour?
It's... What's the next 50 minutes?

**Ray | 33:45**
Yep, keeps it great. I mean, that seems like a great local one hour at a time, and sometimes that's just the level we need to operate at.
Like you say, it's not always about the grand strategy. Okay, does that help from an assistant's point of view? How else can we help you? Like you say, keep it... I'm not going to use your term, but I think you're trying to keep the wheels on the wagon, right? You're going to have more disruption. You're trying to think about how you can make sure that you are able to keep on getting done what you want to get done. I thought to this point about the moving was... Usefully introduced.
Stress in experience. Of course, I'm hearing the banging, which I hope Krisp is blocking out right now, from the construction just outside. So I definitely have sympathy for all this right now.

**Ellie Rofe | 34:36**
Yeah. No, it is really helpful. I do love the idea. So I definitely have sometimes a bit of a sprint mentality where again, as soon as something's exciting, and this is one of the reasons I was... I guess there's lots and lots of ideas, but there's a difference between a strategy and ideas and a strategy and just intellectual learning, studying, et cetera.
I suppose that's where I think a low novelty rate but high quality rate for a few weeks is no bad thing in terms of a more cyclical rhythm. But am I right in that, or am I just kind of am I missing things if I'm doing that?

**Ray | 35:33**
Well, that's an interesting question. Before we get into other people's feedback, I'd appreciate your own feedback. Do you think you're missing things?

**Ellie Rofe | 35:44**
You could always be missing things. There are always a thousand things you could be doing. That's the joy of marketing.

**Ray | 35:50**
Estimate your intuition. I appreciate that in the universe of infinite possibilities, infinite things are possible, right? Therefore, there are an infinite number of things we could be missing.
But I think we can move from a Newtonian view into a more Aristotelian view of it, right?

**Ellie Rofe | 35:58**
Yeah, okay, that's a good question. Actually, underlying my question is probably when I add too much novelty, especially when there are things that take quite a long time to do.

**Ray | 36:05**
Like, what do we see around us?

**Ellie Rofe | 36:30**
Then I risk not doing everything a little bit. Half asked.
So, it feels like this is an opportunity to consolidate rather than just talk about execution. I've tried lots of different things over the summer, and I've been thinking about lots of different things, and I've, with the help of you guys, narrowed down on a strategy. At least for the next four to six weeks, really?
If not longer. So it feels like this is an opportunity to consolidate rather than keep adding new. If new opportunities come my way through what I'm doing, then that's fantastic. I obviously won't be like, "No, I'm consolidating," but it feels like that is a nice moment. This is a good moment to try and do that.
So yes, that's my answer. I might be missing things, but I don't think that's going to be important.

**Ray | 37:27**
So what do you think is going to be important?

**Ellie Rofe | 37:33**
I think it's working out how to. I feel like a lot of the time I feel like I am playing a bit of chess with my own brain, so I'm chasing it around the board, going, "No, we'll do this." You talk about constraints, you talk about rhythms, you talk about systems, et cetera.
I feel like as soon as I get one, it goes "Ha" and scampers off and does something else. Maybe it's in some sort of rumple stiltsque, kicking its heels up and mapping off. I think maybe the key is to find a way of finding a path to consistency and quality execution in a consistent way, rather than new things like the system I'm building and the way I'm processing data. That's taken longer than planned because I get distracted by other things.
But that's a really important part. I need to get that done to be able to show people, to be able to process with the bit, the organization that's introducing me to VCS, et cetera. So I think it's just consistently executing projects like that and repetitive tasks. Does that make sense?

**Ray | 39:03**
It does. In fact, it makes a lot of sense. Are any of you familiar with the work of Robert Keegan? A classic book's called "How the Way We Talk Affects the Way We Work." He had a follow-up book about a decade later called "Immunity to Change."
I was like the immunity structure as he described it because it's core immunity is not always the same resistance, right? So you're resisting some of these systems, what have you? You're saying, "My brain scampers off and all that business." I think there's an idea in there that there are some things that we need to solve this problem. Are we put in a system to introduce discipline?
But there's a second part, right? This is what his big contribution to the conversation is. He says that there are some problems that you can't solve that way. He calls them problems that we solve, and then there are others, and those are the problems that solve us, right?
We change in response to those. As it has this three-column approach like a worksheet he uses for this where one is what is the really important thing that you're trying to make happen?
The second is what are those behaviors that really move against that, right? And the third is what are your values, right? That you're hearing or the stories you're telling yourself that are then driving that second set of behaviors.
Because it's not that you're doing it because you're a completely self-destructive person. You're doing it because your brain has trained itself that this is actually a good mode of behavior.
It is protecting you from something. That's why, using a humanity framework, right? It's because it's a protective mechanism. I bring this up because I listened to all of us talking about systems and what have you, right? Those systems are immunities, right? We're trying to introduce immunities, and some of them are artificial, but it's very hard to defeat the ones that are sitting inside us.
So, one of the things that he talks about that I think is really useful and the reason I bring it up is that there are some things we just need to do that we say, "Okay, we're going to do this, and then we do it." We talked about how some of these things are New Year's resolutions. You make your New Year's resolution. I'm going to go to the gym every day.
I know Dimitri is going to go to the gym every day, and he's toldly on top of that. But for the rest of us, certainly me, I want to be doing it more. I'm going to lose twenty pounds. I'm going to do these things.
But we say these things and then we have some initial energy, and then it's hard to keep that up. Why? Because there's a reason why we had those other patterns. Others might not be good, but there's a reason for them. We haven't addressed those.
The phenomenon is when we say, "Of course, we should be doing X," but then we don't do X because we treat it as what he calls a technical problem, which is to say something where we apply knowledge and solve it versus an adaptive problem where we...
It's not that we need to change the problem. We need to understand ourselves in order to go from point A to point B. Now, the reason I bring all this stuff up is that when we talk about systems like this, I think there's a great temptation to say, "Wait, there's a good system over there that works for a successful person." Let's go apply that system to me, and then I'll be successful like them.
But the problem isn't that the system doesn't apply to you at work. It's a system that applies to you if you were like them in their psychology, right? It's really more about what is going to be the thing that is going to be compatible with you.
That is not a problem of fixing you right or putting things around you. It's a problem of self-knowledge. That's why it talks about columns because it's a third column.
That's really the discovery, right? The first column is like what your objective is, what you want to make true. The second is the self, you know, if you will, the self-sabotaging behaviors, but like or at least the ones that are pushing against that thing.
Then third is like what are the things you really value that are coming from that? Like the person who wants to be a better leader but never asks for help. Why? Because self-reliance is so important. As a result, every relying on others as a result of very hard to get people to follow that right, so you can see the train following.
But then what do...? They need to understand where that last part comes from, right? Because it's the value change in order for it to bubble up to the behaviors. In order for it to bubble up to whatever everything is, you're looking to adapt.
Anyway, the reason I bring that up is first, there's some science that you can be availing yourself of, and that you're looking at books to be able to adjust that. He takes a very organizational psychology approach to it because this actually applies to whole systems of people in addition to individuals, but definitely applies to individuals. Obviously, psychology.
But as I was listening to all of us, I'm realizing that some of these things we're doing, the systems that will work best are the ones that are a reflection of who we are and what we value. The systems that, like, keep on failing for us are the ones where we're trying to push against who we are and what we value.
The only way to sort of cross that divide is to start by understanding what it is that we really value. That might be the thing that we don't think we should value as much or that we need to be reconsidering.
Well, once you give it a name, it's the first step to getting into the rest of that there. But as I was listening to all of us, I thought that could be a useful exercise, right? Which of these things are reflecting you, right?
They could be reinforced by those values. Which of these things are us trying to push against it? Perhaps trying to treat an adaptive problem as a technical one?

**Ellie Rofe | 44:37**
That's very interesting.

**Speaker 3 | 44:40**
Yeah, and I just looked up as you were saying. I was looking up the book that you're mentioning, and that was very interesting. One of the examples was somebody who might not want to lose weight because the secondary benefit is that he looks bigger, so it's less likely he'll be mugged.
I was thinking, "That could be my dad. Wait a second.

**Ray | 45:06**
It's like the... Actually, just... I'm going to touch on that one for a minute because it sounds silly, but it's deep in the person, right? You might even sound silly to yourself when you say it out loud, but you got to understand those things before we can do the rest.
Anyway, so as you think about those systems, I think the easiest systems to put in place are ones that are actually reflective of you, right? If you enjoy chaos, let's have some chaos. If you don't want to have
chaos, but you enjoy chaos, what we need to do is work on the fact that we enjoy chaos and where that comes from. By the way, that is a fine thing to be working on in this context, too.

**Ellie Rofe | 45:56**
Yp.

**Ray | 46:00**
It's just a... But by stepping back from that, saying, "Okay, we're not trying to fix it in one gos.

**Ellie Rofe | 46:08**
Yeah. Yes. I suppose, if I'm really honest, the nagging fear in me is that the things that I value and love don't lend themselves to a business making pitch decks for biotech.
But that might just be a defense mechanism. So I'll have to think about it more seriously. But it's values around freedom and creativity and things like that. But as I say, I think it is about framing and thinking more deeply about it. Robert, did you say.

**Ray | 46:47**
KEGA and in fact, if Robert, if you have that up, would you mind popping that into the chat so that I can get that? Sure.

**Speaker 3 | 46:57**
Yep, send it now.

**Ellie Rofe | 46:59**
Thank you? Beautiful.

**Ray | 47:06**
But it's actually, it's funny you mentioned that because I've been thinking about his work recently in the context of the organization and being able to explain organizational behavior better than strategy does, right?
Hey, what are the market pressures? But then, like, okay, what's happening internally? It's easy to talk about that as a series of personalities, but you start thinking about it as systems, to our previous point. Bury it as immunities.

**Ellie Rofe | 47:23**
Yeah.

**Ray | 47:35**
It takes a lot of the personal, the personalities, and therefore the hurt feelings or whatever, a bit more out of it because it's... But while not losing resolution on the question of the wise, so I think it could be a useful thing.

**Ellie Rofe | 47:52**
Yeah. I can see how it would be really effective in organizations as well. Absolutely. Because there is a series of beliefs in an organization, a series of underlying values, not the five adjectives they put on a blooming lanyard, but the underlying values that are going on that do determine the function and dysfunction within it.
Yeah, interesting. And I guess that is a part of the point that is important to remember. It is function and dysfunction, not just dysfunction. I think I've done a lot of work on productivity since I started working on bigger projects and to manage people when I was running the film festival and stuff like that.
I think a bit like when I finished an event and everyone else was going, that was amazing. I was just sitting there working through the long list of things that went wrong that would have to go better next time.
I think maybe I have a slight tendency to just see the things that need to be fixed and focus on those to the exclusion of things I know I've mentioned to you before, Ray, and the classic example is when I cook a meal. As soon as we sit down to dinner, my mom used to do this.
I'll be going, "No, I've not put enough salt in. And the herd thing isn't quite right. Sorry. People are going, "This is fine. What's wrong with you? This is lovely." My brother half cooks a meal, and he's tasty. He goes, "My god, that's amazing. I love that."
It's a completely different approach. So, yeah, I think that there is an element there of probably overthinking things to the point where I'm actually, ironically, becoming less productive because I'm over-focusing on certain things as well.
So, yeah, a balancing act.

**Ray | 49:47**
So I think the opportunity you might have, particularly as you get into more of the chaos zone, and I think this is something that would profit all of us to do. I say that, including myself. When we're seeing some of these, what we might be describing, is not the best behavior either, the self-criticism that you're describing or the straining against the system that we might have put in, rather than treating it as a problem to be solved.
I think there's an opportunity for a behavior to be understood right there. There's an old Jim Ron line about how when you're getting frustrated by a problem, the two magic words to apply to it are, "How interesting?" Because it changes the way that you look at it.
Now, instead of being something you're trying to undo or make different or what have you, you're leaning in to understand it more. So, the source we're coming from that completely different, ill-training type mode to the psychology thing. I do find that really does help if I find I'm.

**Ellie Rofe | 50:59**
Yeah.

**Ray | 51:00**
If I'm an instructor or something working on a tech problem and I'm starting to swear at the robot to the point where it says we need to have a discussion about professional communications. The. I will that is an indication to me that maybe I just need to stop being frustrated and not doing anything. It starts to understand more deeply. In my good moments, I do that, in my bad moments, I don't.
Right, we're not all, we're all made of both. But I think if we can start to ask, like, when do we do those things? Then I think we're on the track to starting to understand the whys.
Those whys are what will allow us to start getting on the train to having more of the behaviors that we might wish for.

**Ellie Rofe | 51:43**
I'm beaming as you say that. How interesting, because one of my friends once said that if there was a word cloud for me, interesting and intriguing would be the two biggest words. Because I'm like, "Interesting."
It's so intriguing. So it's a beautiful reframing. I love it. Instead of this, it won't work. Whatever, it's interesting. Or how interesting. [Laughter] So, yeah, I love it.

**Ray | 52:10**
If I might, now we have a discussion like this issue of reframing. Maybe we get a little bit of weigh in from Demetrius and Robert before we lose the hour so that we might have just a couple more ideas for you on that front, right?
So that we can all... Maybe I'll profit from your topic today. Robert, maybe to start you, sir?

**Speaker 3 | 52:36**
I would just say that, for whatever it's worth, this is from just my... Just from somebody who's... I think struggles with a lot of the same things and tries to put a lot of thought into what you're mentioning. That, in a lot of ways, I would say that you just have... The first of all, that the best framework I've found is as a person who's not... Who's looked for a lot of frameworks is actually what Ray's framework, which is a study style, that's by far...
Remind me when I was in elementary school. They used to give you an agenda to every kid right at your desk. And I never use that thing like for every single year. I was just never that type. I couldn't do it. It just wasn't for me, and it was me as a kid, I'm not really into... I don't know how much you control actions. I just was not using it.
So, I'm not really a person who sticks with things easily if you give me something and I'm just going to get bored of it after a while, right? But the studies... So, Skillshare is something that I found I can really put my... Imagine my life in...
It helps me to bring more structure to me, and in a very meaningful way, I can really look at that and I can really see how things are going, broken down into those components.
So, just mentioning that, I would say that just probably don't get under indexed on selling, I would say because it just takes time to turn that wheel back again. So, even if you start, by the time when you need it to be going, then it's going to take another two or three weeks until actually the results from your... Even start coming in at all. It always takes two or three weeks to even get it going again.
So, yeah, and I think that's the other thing I want to mention. Something that I can't remember where I read it, but it was just something that I read once where the person was saying that one of the main competitive advantages that a business has over an individual
is the motivation of the organization that gives it strength. We as individuals where we have ups, we have downs, and that's not great for the business.
So, I would just say that's probably as much as it is hard. And obviously, it's one of the hardest things I think about what we do, which is that you have to do it every day. But that is the hard part, and that is the difference between... That's why those businesses have a huge advantage, and that's a huge skill we can have, which is to just always keep the wheel turning.
So because we have to.

**Ellie Rofe | 55:56**
Yeah, I like it.

**Speaker 3 | 56:00**
Domit just sorry.

**Ellie Rofe | 56:00**
I'm always thinking of how hard.

**Ray | 56:02**
Go please.

**Ellie Rofe | 56:04**
No, I've spoken way too much. I'm fine, I'm just waffling. I'd like to hear Dimitrius.

**Speaker 4 | 56:13**
From my side, what I know is that creative people have a creative brain like you. They don't work in limits, packages. They need the time for freedom. They need some free space to expand their creativity.
So, don't forget that when you compare yourself with someone else and you see how the other people work, like they have a system or they have a task to vis it every time we meet. These kinds of people and their systems, the way they work looks incredible to us.
So, we were thinking that they are successful because of the system, and their success gives credibility to the system. But all of this is wrong, totally wrong. It works for them because of that. It works because they are these people who work with the system.
So, I saw creative people without any system, with no structure, but with passion on what they're doing, like you. And one secret thing: clearing all the time the clouds from their brain. Like they found one North Star for their life.
They got focused on that every single day, every single week. They had good focus on that. So, these creative people have the best system changing every single moment, but they had the goal. So don't try to copy anyone, find your own system. Accept that you are creative. Nothing structure can be inside your creativity. That's your secret.

**Ellie Rofe | 58:15**
Okay, that's a really interesting angle as well. I'm going to have to read through the Krisp thing, but thank you. This has felt like I've asked you to give me therapy as well, but rather than just talk about business stuff.
Yes, I really appreciate it. It's going to be a lot to think about and a huge amount of useful insights.

**Speaker 4 | 58:37**
Fantastic.

**Ellie Rofe | 58:37**
Thank you.

**Ray | 58:39**
Appreciate getting to work with you all today. We'll be talking to you other week and we'll do this again and Dimitri will be your hot seat next week.

**Speaker 4 | 58:47**
Thanks guys. Have a nice week.

