# State Change Mastermind - Nov, 25

# Transcript
**Robert | 00:02**
Finally, I mean, I can't, I don't know. How was it not cold the whole time?

**Ray | 00:10**
Yeah, it's been no heating here. Yeah, I've been running space heaters. Just try to keep the space above freezing so that, you know, jeeze wouldn't have those side effects. I discovered something. I've been, you know, sort of cooking and running the dishwasher. 
But my dishwasher used the hot water line. And there's a thing where, like, if you use cold water, you know, like things congeal, you know, like, you know, fat congeals when it's cold and that kind of thing. 
Well, soap does, too. So if you soap in cold with. That's designed to work in Hot Water. It will clog a pipe. Dope from the dishwasher was clogging the pipe and that caused the dishwasher to stop running because it couldn't drain. Why was it doing this? The solution is relatively straightforward, and you can unclog the drain just by running hot water through it, right? That breaks down the soap because just goes through. 
But, that was a weird thing.

**Ellie Rofe | 00:58**
I didn't think I was weaker.

**Ray | 01:00**
I didn't think I was going to learn this week or, you know, ever. 
Such a the way.

**Robert | 01:07**
The guy's getting better, though.

**Ray | 01:09**
Yeah, it is getting better. It's getting fixed. Today seems to be the day. I'm. I'm hoping today it turns out to be a bit of a turning point. But let's see what kind of turning points we can make for everyone here. 
And by the way, Ellie, it not only is it your hot seat, but you win the mastermind today. You it is just excellent.

**Ellie Rofe | 01:29**
I'm so sorry. She's been poorly, this one, and I'm now poorly. So when she hopped up on me and started getting comfortable. I didn't have the heart to get rid of her [Laughter] because we still have no heating. 
And she's like a little hot water bottle.

**Ray | 01:49**
That is a good point. Small creatures can do that. I remember when my sons would just like you could. You didn't need a spacer. You just put them in an area and, like, just the whole thing became much hotter because craziness.

**Ellie Rofe | 01:59**
[Laughter] Exactly. Small creatures work. Well.

**Ray | 02:07**
All right, let's go around the horn here. Demetrice, can we start with you? What kind of week has it been? What do you know today that you didn't know a week ago?

**Demitris | 02:16**
Yeah, sure. It's a, less, week to me, guys. What I know is that I found my way to keep consistent in terms of posting on a daily basis on social media and it use mostly LinkedIn in YouTube. I started collecting a couple of nice feedback from the analytics. What I can improve, what are the things of opportunities that are coming up? 
And so I'm getting familiar with this approach, and at the same time, I'm working on making a digital twin of Cris Doe, the influencer, the brading strategist. And the logic is to take the transcripts from his videos. I selected videos for me and fit them into cloth and make them the knowledge graph at the end and after that having an agent who can help us help the user to run his branding strategy. In terms of what I have to do a post, when I have to do a post and all these kind of questions. To be honest, I'm not working on that as an actual site project. I'm building that as a story to tell for my upcoming event that I'm planning to do it for the next Friday as a case study to be presented. 
So I'm pushing on completing this think. And at the same time, I'm working on exploring pinna con vector databases where we can store the data. And I'm working on figuring out how the nodes, graphs and vector databases can exist in the same system environment and work together for under the application interface for an end user.

**Ray | 04:28**
Okay, cool. And. Robert. What? What do you know today? He didn't know a week ago.

**Robert | 04:38**
So, I, good news. I'm very close to, getting a pretty good engagement with a client. Close, and, yeah, I mean, I worked with Scott last weekend. He's just very super happy with everything and it all seems to be lining up. 
And he's already cleared it with his, you know, the present decision maker on his side. And he's just overall like super positive and I'm going to meet tomorrow with his you know, with that decision maker. 
But otherwise, you know, Scott is the person the advocate, you know, who's he's already, you know, convinced him. And so tomorrow's like a formality, and I'm gonna we're gonna meet, and it seems like everything will line up, like, even financially. 
It's very, like, close. Very close to what? My skull likes to hagg a little bit, which is okay. He's flexible when it comes to, you know, he understands that at the end of the day, like that I'm, what he's getting to out of it. 
And he understands the my priorities and like. And a line up with his priorities, which is just to go faster. Not to put in as many hours as possible, but to think smart about things and to try to do things as quickly as possible. To leverage things. 
And. So, yeah, that's really the. The good. And. And I just feel good because, yeah, I'm trying to just keep pushing and keep. I think my this is something that's like a little bit, tough to do, I think, but it's like to keep the self esteem high even through when you don't have a lot of evidence. 
Like, you know, you're not getting necessarily the results you want, but you still have to keep yourself esteem very high because. And I think that that's the hardest part, and I'm still trying to push through that. 
But like, I can feel a little bit of. I could see like that. I suppose, you know, validation in terms of coming, right? But just to even get there, I still have to even if it's not coming or if it's not happening at the time, it's. I just. 
Yeah, like that's. I say, like that's maybe the those things that happened over the week, which are great and everything. But, I find that doing still now and even going forward, like the most critical thing for me has been like you got to feel really good about yourself every day if you're going to try to ask for what you believe that you're worth and everything right in the. 
So even if you're not necessarily getting at the moment so, getting there and pushing through and overall very positive but still trying to say, you know, digit, you know, stay aware of what I have to do.

**Ray | 08:14**
No, I think that's, yeah, the awareness is about how you build the bridge between those two things, right? It's like the w when we feel maximum Despair or maximum, ego. Those are both when we were disconnected from reality.

**Robert | 08:33**
Yeah. Yeah.

**Ray | 08:35**
Okay, I appreciate that. Ellie. No, our friend is gonem.

**Ellie Rofe | 08:40**
[Laughter] yeah, I think you're all too manly for her, and she got scared and ran away.

**Robert | 08:49**
2.

**Ray | 08:52**
What kind of week has it been and is your hot seat? How can we be a service to you today?

**Ellie Rofe | 08:57**
It's been an interesting week in that when I look back on it, I realized I ended up in a real, like content generation mill, and I think that has been somewhat, sort of draining, but maybe getting to the point of counterproductive, in that I had to create the landing page for the event and then continue tweaking it. 
So really quite a rapid turnaround on something that was all very sort of experimental and speculative. Then I was updating my website with the idea of evolving the messaging and the branding, but just making sure that as and when people may come through to the event or orspond to stuff, there is somewhere to point them. Then there was building slides for the workshop and the tool that I'm going to use for the workshop. 
And so. And some social posting, which I then I realized over the weekend, I gradually just fell away from because I think I was just managing too many bits of content creation on various levels and my brain started to fry. 
So, it's been okay. I've got some, you know, there's. I think the more I post, the more I get interesting connections happening. And I can see the value, like I can see even repetition and stuff making a difference. Even posts where I just put out, I made a post about how I've always been quite obsessed with things like cults and propaganda and persuasion and ask for book recommendations and that, it's not like, it got me engagement. It just got really interesting, people giving me really interesting ideas. 
And so it's still within the world of what I do, but it's like, an angle on it. And it just gives a little bit of a different approach. So. I do feel like it's. I'm starting to understand more sort of, intellectually, I understand it, obviously, because it's what I do with clients, but personally, viscerally, experientially, I've always struggled with it. 
So, it's been really good. I've got, for example, a call with a VC, an angel investor, next Monday. She got in touch with me and said. I think I mentioned this to you on Friday, Ray. But she got in touch with me and said, I'm so pleased to see someone tackling this space, which I just thought was such a. It really sort of warmed the cockles of my heart because I thought. 
That's a. You know, that's a it suggests that I am somewhat early or somewhat unusual to be tackling this space. So that was great. And so I think what possibly might be really helpful is for me to just share where I've got to in terms of building the landing page and get some is on it and just get me out of the weeds I'm in and get some people to just go, yes, no good bad or whatever because I am lost.

**Robert | 12:23**
Yeah.

**Ellie Rofe | 12:31**
So, where is it? So it's gonna be. I'm building it at the moment. Ope. Not there. Right. Can we all see this?

**Robert | 12:52**
I like your headline, by the way.

**Ellie Rofe | 12:54**
I so I don't know.

**Robert | 12:54**
Just like just to say that I feel. I don't know. You know, I know we're about to get into it and everything, but just to say within the first. Just my first reaction, whatever that's worth, because you never get the first reaction again. 
But it just immediately jumped out of me and it. Yeah, I like it. But I'm sure there's a way to analyze it, maybe even very deeply, but just from a very simple point of view. Like, it just caught my attention, and I think it's very clever.

**Ellie Rofe | 13:22**
Thank you, that's great. This is yeah, I'm not going to actually lead the discussion, so I won't make comments, but that's really helpful. Thank you. Do you want me to just scroll through it and give you the opportunity to have first impressions and then look at things section by section? 
It's not finished, by the way, it's just getting there. Is that the. Yeah, yes, that that's going to be on each section.

**Ray | 13:46**
Yeah. Would you mind scrolling a bit? Or scrolling or whatever the advancement is? I see the 01 over there. That was that' kind of coolmm.

**Ellie Rofe | 13:52**
I'm trying to do a sort of subliminal. This is a bit like a slide deck. So each section is a hundred SV H or minus the header. 
But without it being too rigid. I was going to do, like, a literal slide deck, and I thought, this is just going to be a nightmare. It's, you know, and scrolljacking and all that kind of thing.

**Robert | 14:21**
Okay, I like this part. I would just say that maybe put the stuff on the left over each, like just align it because right now I'm looking to my the left side of the page. I'm looking up and down the right side of the page. I'm looking left and right. I get it, but I just like, you know, it's even now as I'm explaining, it still takes me a little, like bit to it's actually even just the other way, like, you know, exactly.

**Ellie Rofe | 14:51**
I have been wondering, yes, okay, cool, will that read that's what that was.

**Robert | 14:51**
Yeah, this should just be like 123. I think.

**Ellie Rofe | 15:01**
My concern is whether it would actually read like ca. This is like.

**Robert | 15:07**
I think it reads in a sense of like the concept is very good. Like, I like how it's tortilla chips and I like this and in line with. I think. With the rest of the. The.

**Ellie Rofe | 15:18**
One.

**Robert | 15:18**
It's just purely just visually, I think, you know, I. 
But otherwise, I liked the concept quite a bit. I liked how you broaden something that's a bit different it because this is your pitch. I think that like, when somebody visits, they're going to get an idea of you're giving what your ideas will be like towards like even just how them to communicate themselves.

**Ellie Rofe | 15:36**
Yeah.

**Robert | 15:40**
And is this capturing my attention as I'm reading this? Because if it's not, then you know, it has to because they're going to assume that you're going to be able to you be working on with them to capture other people's attention for their work. 
So anyway, just. II like this because it does capture attention. Like the tortilla chips concept.

**Ellie Rofe | 15:58**
Fabulous. Thank you. Okay, so I'll have to rethink the exploded diagram without out and then this is process. So this would be like there'll be visuals, a couple of videos, and an another visual there, and then this is where I've got to basically.

**Ray | 16:20**
Okay.

**Ellie Rofe | 16:23**
So then it would this is like a, you know, choose your adventure. But the goal is that where I when someone clicks there, that will be like what I can offer people the full stack of, prep. And then this one would be you're in the middle of it. Here's a quick and dirty version, which I have got some copy for, but I'm just trying to work out how to put it in there and what pricing to put on and everything like that. So's more copy elsewhere, but this is the content that is actually put into web form so far.

**Ray | 17:11**
Just. Can we bring you to the conversation?

**Robert | 17:14**
Yeah.

**Demitris | 17:18**
I'm so surprised with the final result. I really like the design and the slogans, the text, like the consistency of the colors and how they put everything a clear values. It's quite easy to drag my eyes and my brain into the messages. Regarding the very smart diagram down here. I agree with, Robert. Just for readability reasons only, since you want people to focusction the communication, I would recommend a different way of using exactly the same concept. Exactly the same concept. Definitely. 
It's very smart, very communicative, and definitely, I expect everyone who will be a visitor.

**Robert | 18:20**
?

**Demitris | 18:21**
He will not forget that he found something smart here, something very focused, unique value. So this these are the things that can make you unforgettable. Can you scroll it up to the previous session? I don't know if here would be a good case to add some, I don't know.

**Ray | 18:58**
Some recording. Recording in progress.

**Demitris | 19:02**
Your, existing clients, Asa because you know what? We see people who have the role of the founder right here solving their problem, right? So and your solution is let's have this two, let's talk this altogether, which makes a lot of sense, but I'm thinking if he could put an actual story in an actual phase of Glen. 
I know this is quite high, definitely. If it's not, I think this one works pretty well. And so engaging. To me it's in consistent people looking into your eyes. They are serious. They are taking for actual problems. We see on the right the guy who is a scientist, definitely. We see that the businessman who doesn't care for lawsuits and all this stuff. 
And we see a modern women taker of business, hard work. She never hesitates. She' strong too strong profiles to me. I really like it. And can you scroll down to the poth? I was here for a moment.

**Ellie Rofe | 20:37**
Which one'? Sorry, the.

**Demitris | 20:40**
I like the sharing with the videos. Perfect.

**Ellie Rofe | 20:45**
One.

**Demitris | 20:45**
Again, I think it's the most compelling place here. I really like it that you bost the core values and I hope it's gonna be a video from you talking right?

**Ellie Rofe | 20:58**
Yes. Yeah, me and the tool that I will be using with them.

**Demitris | 21:02**
Love it. This is amazing. I for the four options. Yes, that's going to be incredible because I'm putting myself into that position. They don't know how their experience will be working with you, and that way they can have a taste, which is amazing.

**Ellie Rofe | 21:33**
Four.

**Demitris | 21:33**
I really like it. 
I think this section is very strong. And I would give it an AB test to put it on a higher layer, one section of BO and so on.

**Ellie Rofe | 21:41**
Six.

**Demitris | 21:50**
And just for testing because I think it's very strong.

**Ellie Rofe | 21:53**
Okay.

**Demitris | 21:55**
And this. Only this thing can give you a nice kind of opportunities too. 
And regarding the last step with the past, I think it's pretty smart separating those two users because it identifies exactly their needs so they separate themselves from different, cases. Because the guy who has already prepared to raise money is not the same guy who is just looking around to find his path, right?

**Ellie Rofe | 22:25**
Yeah, exactly. Yes, okay, pampht, that's very kind.

**Demitris | 22:33**
It is brilliant.

**Ellie Rofe | 22:34**
Thank you. Can I ask two questions? When you said actual clients, do you mean use their images here with their words?

**Demitris | 22:50**
If that's okay with them. They will be nice and they role and name of the company because that way we see exactly. You work with Ray, who is founder of State change and she's doing this. It's at the same time, like, combining the review, the problem you solved and the value you delivered.

**Ellie Rofe | 23:15**
Yeah. That's really interesting. I would have to look and see. Part of the reason I haven't is because the. Most of my fundraising testimonials come from very similar looking men. 
And I have, one woman, who isn't ready to give me a testimony yet. She wants to do it once she's raised. Assuming she does. She's quite precious about keeping everything sort of compartmentalized. And a guy and they're not ready. 
So I was I will have testimonials later on, but it is an interesting idea and I think it's a great idea for future because it does make it much more interesting. And these can be like snippets from case studies and things, but I think I just don't quite have the assets yet to do it. I do love the idea, though. 
I'll keep that one in mind. And then?

**Robert | 24:30**
I just want to say that, like, sorry. I just want to say that just my two cents. But, like, for. Like for testimonials. And like, this is something that I. I picked up from Ray, which is to use something that just captures them as you go along and just puts them up on the page as you just go along, like for like. 
And again, I think everybody I'm not, you know, everybody has different opinions on this. But I think what has worked for me has been to use, SNA and to have an email that goes out after I have meetings with people that just says, hey, if you don't mind, here's a quick link, you can let me know what you thought of our meeting.

**Ellie Rofe | 25:13**
Eight one.

**Robert | 25:29**
And then that's it. So I'm not. So that way I'm always getting testimonials here and there, like I'm. It's not something that I'm really out there looking for, but every once in a while I have a really good meeting and then they'll get that opportunity in there and some people will just record a video, just without, you know, me saying anything or asking anything. They just decided to just record a video. 
So I would just say that maybe that's one way to remove that. You know, there's obviously a way to be proactive about it and to say, you know, I want this particular testimonial from this person. 
But I think there's a way to collect testimonials and get them up on this page in a more passive way. Maybe not exactly. That is this like showcase this like, you know, specifically selected ones that you know, there's different types, but just to say that there's a mechanism there that I'm leveraging that I found works quite well for me.

**Ellie Rofe | 26:21**
I love that. Okay, I will. I will look into incorporating that.

**Robert | 26:29**
Like any positive words, right? Like, even though sometimes they throw up like two sentences, three sentences. Okay, like, but they're very but they're voluntary, so they're usually they are usually, you know, very, the self they're self initiated, so they have that motivation, and so they wanted to write something and so usually it comes off as is very genuine and very positive, no matter what it is. 
And yeah, I just think it's good to have a mechanism for people to voluntarily be able to give you that if they want to, especially since we're in this, you know, space of like where we're doing just type of marketing where we're trying to reach out to people. 
And a lot of those interactions might not even end up with being paid necessarily. But there's another way they could probably reward you with a different type of currency which. But they just need the avenue to be able to do that.

**Ellie Rofe | 27:17**
Yeah. Okay. That's really. That's a really good idea because I do have calls where people have, like, they're nowhere near being able to hire me, but they get, you know, breakthroughs or whatever.

**Robert | 27:20**
He asked. 
Yeah, but they just get like this really great like I find it like sometimes I have a really good call with somebody. I know it's not going to be a client ever, but I had just I really helped them out on a real high after meeting me. 
And then after the meeting, they get an email says hey, automatically just says hey, click this link, you can let me know and it just does the work for me automatically and then and you'd be surprised with like who might just decide to just record a video for you, right? 
Like I was surprised, right? Like. And it again takes the pressure something off of my mind.

**Ellie Rofe | 28:04**
Yeah, okay, I love it. Thank you. And another question just briefly here.

**Robert | 28:10**
Course.

**Ellie Rofe | 28:14**
If I moved this over a little bit and had these as little flashing things where people could interact, would that be better where they could just click on something to reveal text rather than having it all laid out? One of my concerns here is that it was so noisy.

**Robert | 28:30**
No, I don't think so.

**Ellie Rofe | 28:35**
I feel like this is quite AAA noisy.

**Robert | 28:35**
It's too w it I don't think it's noisy.

**Ellie Rofe | 28:38**
Busy section.

**Robert | 28:44**
To somebody who who's coming here and they have a pitch deck and they have they're suffering like, you know, I don't personally, I think that that's just the way I feel about like when it comes to people, you know, we want them to if they can't read this, I don't know, like it may it they have to swim halfway, right?

**Ellie Rofe | 28:49**
34.

**Robert | 29:08**
Like swim a little bit and be willing to read and be willing to and again, I think that like that when you're presenting something that speaks to their problem, that they that we can presume that they're interested in reading it and maybe that's a bit of a test too, to see like if so. 
But I don't think that you need to do too much more here to make this enticing to read. I feel like it's not very unreasonable to ask someone to obviously just rearrange a little bit, but just to make it easier to just comprehend does. 
But otherwise I don't think that people need so much more help to get through the material.

**Ellie Rofe | 29:47**
Okay, cool.

**Robert | 29:51**
But that's just my two cents. I don't you know, I there's everybody else might have different.

**Ellie Rofe | 29:53**
Im always worried that people will not read because I don't read sometimes. 
But. Yeah, I'm it's. I'm never sure.

**Robert | 30:06**
Well, and some people won't, but I think that that's maybe a I think how far will they really make it? Like if it's someone who's not willing to read and who's not like, they might, it might be better that you don't end up on a call with them. I'm not sure how if that type of person would how far they would make it through an engagement that requires them to really be involved.

**Ellie Rofe | 30:28**
H4H.

**Robert | 30:30**
From the sounds of it from the sounds of the type of service you provide like where they have a lot of. And I think with even for me like a lot of the services I provide, they we get the best results when the other person is involved in the process. 
And. And so, yeah, I'm just saying, like, you know, there's a whole bunch of unknowns, right? Like about like the what that person might do. But I'm just saying that, there's probably when you're putting things like this on the page, we can presume that, you're speaking directly to if they don't want to read this. 
And it maybe depends, I think, on, like, why. Why is it that they're not reading it? Like is it? And I don't think it's a content. I don't. Right, like if until the data might show, I suppose, but we don't have enough data yet to be able to say right, like on a large enough scale. 
Like is this how many percentage of people are booking a call after this scenario or anything?

**Ellie Rofe | 31:29**
Yeah. We don't have a date.

**Robert | 31:32**
But, yeah, I don't think it's there, like, in terms of. I don't. I mean, I don't think it's there in sense of like looking at it and saying, this is way too long or anything. 
You know? It's not like a ten page PDF or anything.

**Ellie Rofe | 31:41**
No. Okay, call ill. I shall test. I shall see.

**Demitris | 31:53**
One, thing here. Basically, I agree with Robert in all the two points for here in the previous section, he's totally right. Even here. If you make it clickable, you're gonna get them confused because what they are gonna say is that they stink, right? 
And they have to click on the source to see the communication. They have to click on the precision to see the message. But if you transfer this thing in the middle of the page. And let's say that this thing lives here. 
And you have the arrows saying that. Okay. This is the L3. Here is the L2 and down here is the l one somehow. So in the middle of the screen is your view, your core idea, the creative part and around of it is the explanation. 
So they cannot get lost in that as an idea.

**Ellie Rofe | 32:52**
Three.

**Demitris | 32:55**
I'm not Designer, you're better than me, definitely, but I just don't make it clickable.

**Ellie Rofe | 32:57**
Yeah.

**Demitris | 33:00**
Doesn't make any sense. One thing I would think, if it's useful to do, is to put some statistics, giving you extra credibility.

**Ellie Rofe | 33:10**
Hu.

**Demitris | 33:14**
Like, how many piz decks did you run to? Now? How many money did you raise in total? Which means you may have two successful ebitz DES of over two billions huge amount. And nobody cares if it was, failures of XYZ. How many founders you work with, how many different industries, something like that. 
But just a section of statistics maybe, I don't know, give an extra credibility and make it easier for the conversion.

**Ellie Rofe | 33:54**
Yeah, no, you're right, I do need.

**Demitris | 33:55**
Because people think like that. But you know better than how they think.

**Ellie Rofe | 34:00**
I do need some, logos and statistics. Absolutely. Yeah, I'm trying to think. I mean, it's like it's probably about a hundred and thirty million or something.

**Demitris | 34:22**
Well, and I. And remind me if I'm correct. The upcoming Saturday or the other Saturday is the event you have next Friday?

**Ellie Rofe | 34:33**
Next Friday?

**Demitris | 34:38**
Okay, so do you want something for next Friday?

**Ellie Rofe | 34:42**
Yeah. I mean, ideally, I just get this done and out the way by closed business tomorrow.

**Demitris | 34:48**
Yeah, perfect. So just I think the core issue here is the miscommunication of this section because the reasons very clearly mentioned by Robert today.

**Ellie Rofe | 35:00**
Yeah.

**Demitris | 35:03**
And so till Monday to not Monday till the upcoming Friday. Just focus on solving this part and the rest of the things we discuss today are nice to have a sauce on the project on my brain. This. All the things are not stopping you making a conversion. This one may get people confused, but just because we need something and it's ideal habit, it's so nice.

**Ellie Rofe | 35:32**
Yes.

**Demitris | 35:39**
Very well designed. 
So don't lose the opportunity to present it there.

**Ellie Rofe | 35:41**
Yeah, okay, I shall her lu.

**Robert | 35:48**
Yeah, I agree that. I would say that if the next part, like just to put the cony up on the page, and have that version. Like have a version of this that people can visit and be able to see it through to the end and just be able to book a call with you just because. 
And like, I can just set up my website right now. Looks like real horse's ass and that's perfectly fine. Like I have and I'm getting the most, you know, inquiries and I've ever had before even, so it's definitely at the website like not for me like, and people will come to me, but like, you know, you one because I have a number of sites like the are you in San Francisco? 
Because I'll have, like, these templates, like, they'll my addresses are not even correct. You know, like, one guy thinks I'm in Australia and, you know, hey, like, it's not like it's slowing me down. 
So I think what was really slowing me down was my was when I tried to make it, you know, when I was overthinking it too much or just when I didn't have it at least exactly. Days. Abby like, guys, why these people from Australia? I keep booking calls with me. 
And yeah, like so I'd just say that just call it done as soon as you can. It's definitely important. I'd like. I have to. I would probably. You know, I'm going to revisit mine as well, but, yeah, that's good one.

**Ellie Rofe | 37:24**
Well, part of the reason that this turned into like a A yes, as a crock. Part of the reason this turned into a bit more of a design effort is because I had redone it with a version that I thought was quite nice, and someone here saw it and went [Laughter] like, what is this? 
And pointed out to me that it's quite important that someone. As Dimitri said earlier as well that as someone looks at this, they get an idea of the kind of deck I can create for them. So it's a sense of like there's some copy, there's some imagery, there's some design and it's all kind of working together.

**Robert | 38:05**
No.

**Ellie Rofe | 38:10**
I do agree, though. I shouldn't get too much into perfectionist. Hell with it. There are, you know. Pitched extra Loom.

**Robert | 38:20**
I really do think that if you just rearrange this. 
I would even just leave it as layered on the side like one, two, three. Just because I like how it's like actually like the left side of it. 
And you maybe just put the words coming down so that it looks like a layered plate, right? Because if you put it. If you put the food left to right, it doesn't translate layered to me mentally as like.

**Ellie Rofe | 38:38**
That sort of becomes. Here?

**Robert | 38:45**
No, I mean like the way the food is right now up to bottom. 
Like, top to bottom. Just have the words just be aligned. Like communication next to the communication layer of food persuasion next to the beans strategy next to tortillas. And so that way it just it looks like it's layered like one, two, three.

**Ellie Rofe | 39:05**
Yes. Yes?

**Robert | 39:06**
Just because I know before I was saying it left and right, but yeah, but otherwise so. 
But I really think that this. And then. Like that you wouldn't be too far away from just being able to introduce a calmly right out, like right after the section. Like, yeah, you could obviously do more, but just to say you're already making a very positive impression. 
I think by this stage, and you could do more and more.

**Ellie Rofe | 39:32**
Okay.

**Robert | 39:38**
There's just a question of are you going outside of, you know, Perot's principle of like, you know, 20% of your efforts and 80% of. I feel like this is getting pretty close to where most of your like the benefit that you're ever going to get out of it, right, like is going to start limiting it.

**Ellie Rofe | 39:53**
Yeah.

**Robert | 39:57**
Like, maybe, okay, add another video and so on, but you know what I mean? That you're already, communicating the book. I think of what you want by now by here.

**Ellie Rofe | 40:08**
Okay, cool, that's a good wake up call. I shall avoid tinkering into the endless hours. I mean, having fairness got a base now that I've understood the Overall design and stuff that does. Once you get that in place and that's ticking along and you've got an understanding of it, then it does help. Definitely.

**Ray | 40:40**
That was great feedback. And yeah, I think this is looking much better. I would recommend getting rid of the coalpi. I'd the. I get what you're going for in the context of nachos, but actually there's one part of it that actually looks legit unaptizing, I think.

**Ellie Rofe | 40:59**
This. Okay.

**Ray | 41:03**
Yeah, I mean, I get what it's supposed to be, but I think that it falls in the category of like, the art around. It needs to be really good to make clear what it is, right?

**Ellie Rofe | 41:13**
1.

**Ray | 41:15**
That. That sort of looks like food. 
Otherwise. When it looks even just one step away from food, right? Once like a little bit of filter, anything on it looks like, you know.

**Robert | 41:24**
A salt. That's true. I eat burrito bowls quite often, so I. So when I see that, I see beans. But I can understand, like where races coming from, the like, if, you know, and all around the world, like, you know, someone might look at them like, what the hell is that? 
So, maybe just go with the fried rice or something.

**Ray | 41:44**
Or the cheese, you know, I.

**Robert | 41:46**
Cheese. Yeah.

**Ray | 41:47**
Cheese doesn't need to be cheese as well. Like, you know, be on there, like the little pieces of cheese or whatever, but the. And yeah, there are lots of little things you can do across. But I actually really loved on the top, that one thing you got.

**Ellie Rofe | 42:01**
Yes.

**Ray | 42:01**
And the idea that this goes from slide to slide.

**Ellie Rofe | 42:02**
That will be coming through.

**Ray | 42:03**
I think you can have like a little bit, you know, sliders advancer, right? So and you'll go vertically because if you don't want totally click jacket, I get that point. 
But like the idea that we're going from slide to slide and that this is sort of, you know, and which I think is answering some of your questions, right? Like what should this page do? What would you say to a vendor? 
Right now I appreciate. You know, physician heal thyself is like it's a tough game. But I think that would be like the standard like if you feel like. Wait. That. That you know that. That you could hold up one of these as an example to somebody of what you think a slide should be doing. Then we're probably doing it right. 
And like the when you start tinkering with it, you're realizing you're doing the things that wouldn't move the needle relative to what you'd be talking to your clients about. Because it's true, there's a lot of stuff in there like they like this content. 
That's fine, right? Not like you're not the dictator over every possible detail of it, right? There's a bunch of it that's like, needs to be about them. And part of it that's about, you know, the form, right? 
And so, like, when you're in here, there's part that's about you let that go up, right? Because that's coming from inside you. And the part that's about the form, that's, you know, that's those kind of technical things. Which, by the way, you know, I think this group be happy to be sort of, you know, the stand in for Ali like, what would Ali say about this? 
And so would be your external Ali but I think that would be like the perspective I'd have on it.

**Ellie Rofe | 43:25**
Yes.

**Ray | 43:32**
I think when you have that, this site becomes an asset because it's an example of you. And when I think about like, good websites like Robert makes a really good point. 
Like his web, you know first that his website is a little bit of a hot mess. All of ours are. It's fine for it to be hot mess that that's not in principally the problem. But the journey it's been on has been to get closer and closer to like what the market is asking him for.

**Ellie Rofe | 43:53**
He 8.

**Ray | 43:55**
And so actually, I think the most important thing about site is that it's on it's like, you know, fourth iteration in six months because it continues it's dialing in to be more responsive to the market. 
And so this can be a turn for that. And being you being more responsive to like what the market needs and what you're hearing from the market. Then I think it's doing a good job. And then we have it continued to its job, which is we learn from it based on what folks say. 
And then you turn around and it's practically slogan the state changes, you will build this again.

**Ellie Rofe | 44:21**
Yes. Yes. And just assume that one week in every three months is just doing your website until you can buy people to do it for you.

**Ray | 44:36**
Yeah. And? And then even then. You know, I was just talking to someone yesterday who was, what he's doing me was, last week, but he was talking about how he wanted to first do more sales because he needed more sales for his practice, and then he was saying that he wanted to then hire, you know, figure out how to automate it. 
Like. No, this is actually this is the part, like you're a marketer, right? So, like, this piece here is actually your it's the expression of you. So, like, the idea that, like, this is a if this is like one 10th of your time to start iterating on this. This isn't just cell it's all a study.

**Ellie Rofe | 45:09**
Yes, yeah.

**Ray | 45:13**
Yeah. And that then and that. And I think both of those are pretty important things. And people are coming back and they're saying, wait. There's this evolution of Ellie then that's, I think, a positive thing. 
And like where there's high value for you, right?

**Ellie Rofe | 45:29**
No.

**Ray | 45:30**
Like in general, the place you want to automate more, if anything, would be on the shipping side.

**Ellie Rofe | 45:34**
Uhmm.

**Ray | 45:36**
But how can. So that you can do more sale and do more study. 
And that's. And I think that, you know, both those things are getting accomplished here. And I think it's really cool, and I can't wait to see it up on nicelyput dot co.

**Ellie Rofe | 45:46**
Yep. We shall get there. We shall get there very soon.

**Robert | 45:54**
Yeah, but I think it looks good just to say like that. And I definitely appreciate that this might be something that represents maybe something a bit different to the people that you're targeting compared to people that I'm targeting who for me, they're not for me. Yes, on a certain level, they probably want to see like what my. 
Well, I think, you know, there's a good looking website, but most of the time they. But even in a lot of ways, I don't. It depends the type of work that I'm trying to do, right? Like I try to make nice looking Xeno backends because I'm trying to I do more work that relates to that speaks towards when people look at that like, I want have to do the same thing for me. 
And so, I think that this though. So, like, I imagine that even later on, even when, as you said, like, you could pay somebody else to do it. I do think that in this case, I don't know if that would. I feel like those words in that page are best coming from you. 
Like, when I read that page, I can't imagine that somebody else. Like, I knew that you wrote it as soon as I read it, right? Like, I knew it. And that's. I think it's maybe. Like what we're all trying to maybe strive towards. 
And in. Where every especially in a world where you know AI has a very similar voice between you start reading things and you're just reading the same as if the same voices you're always reading but reading your page you can just tell that it obviously, was coming from you. 
So I don't know if that will change later on. This might still be the most. A very valuable thing for you to personally do.

**Ellie Rofe | 47:44**
That is good to hear on two levels. Firstly, some of it is me and some of it is AI that have trained to be me. So we're two marks, which is nice on some level. Yeah.

**Demitris | 48:00**
You know, that's a model. Yeah, to be like you. So it can be a nice assistant for you instead of an uneducated and non trained employee.

**Robert | 48:14**
Which gets you a real marketing maybe, I think, which is something to talk about. Just what you just said right there, right? Which is, you know, well, like training, some something that allows you to be able to accomplish what you just mentioned, right? 
Like so to write in your natural voice and so on. Because it is noticeable when people. I mean, there's I've seen this trend online of, like, people saying, like, how do you get it to output in into your own voice? 
It's not that easy. If it was easy, everybody would already be doing it right. Like, so I think that it in itself, it's an interesting topic to turn on your camera and speak for like 05:10 minutes about and just ship it out there. 
And. And then they just use the website just to book a call with you. But otherwise what they're really that you know that insight and just like the experience that you have with making decide and how you got there and everything. People will see that, I think. 
And then just and imagine it within their own context of like where it applies to that. And you don't have to. So, you know, they' sell themselves. As long as you kind of give them the seed of the idea.

**Ellie Rofe | 49:28**
I can definitely make it relevant to talk to my audience about that. 
And obviously it comes from having built Google and having to try and make that hit tone of voice. So I have the I have that background, that hyper focus for however long it was, of trying to make it do that. 
So it is better. It's still not perfect. It's not easy to do, but yeah. Okay, thank you, that's really helpful.

**Ray | 50:02**
How can be of fair service to you in the closing five minutes we have here? Ali.

**Ellie Rofe | 50:09**
It's a very good question. What else? What else? Do any of you happen to know any startup founders? I guess would be a really good question. Hard tech who might? I've never asked anyone this, but do you happen to know anyone who's building anything, even by proxy?

**Robert | 50:36**
Do I know anyone who's building anything part tech?

**Ellie Rofe | 50:38**
Yeah, hard tech, not software or consumer.

**Robert | 50:46**
So, like, you mean, like a robotics type of thing, like, or.

**Ellie Rofe | 50:48**
They can be robotics, biotech, agriculture, energy, water, inustrial logistics. Which tends to often end up really being robotication.

**Robert | 51:02**
Say, I would just say that in general, I can't say that. Like I would just say that in general, I have noticed that a lot of a number of people who used to work for companies such as like Tesla or, because like, I've worked at Tesla and I know like. 
So I can see that sometimes on my net, like, you know, it was a big company.

**Ellie Rofe | 51:33**
Yes.

**Robert | 51:34**
So it's not like these people are like my friends or anything, but like. But I look in the network and I can see that. Here's this person and now he's working with it's always like something they work with batteries, or he went and I have no idea like it's the I'm not sure like about how what their success RA rate is like or anything. 
But the point is that there is, I think a funnel where like if you look at people's history and you see that they used to work at like I said, actually, I think even I bring up again like Tesla again just because it makes I've seen that they go off and they work and something to do with hear tech afterwards. This is the way you defined it. 
Like, the, you know, personal electric powered helicopter or something like that. Or like the seats, like two people and something small like that. If you see where if you look at where they came from. I feel like you where they previously worked. I feel like you'd be able to find like a whole group of people, that are have moved on from that company and now they are starting their own ventures. 
Like there's because there's a lot of people, like when I worked there, that were very ambitious and like a lot of the time they're thinking about doing their own thing. Like they will want to eventually take a crack at it.

**Ellie Rofe | 52:51**
That's such a good idea.

**Robert | 52:53**
So I would just say that I've notice that.

**Ellie Rofe | 52:54**
Yeah, that's such a great idea. Such for people who have Tesla in their history and founder in their current bio or something. Yeah.

**Robert | 53:06**
Founder co founder founding anything like that. And t and because they really. And like, I'm telling you because, like, I will just go on every once in a while. Like, I'll see that somebody went and he quit and again, I have no idea how it goes, but just en masse. 
And that's just my, like, little slice of it. Like. But a lot of those people will eventually, do something like that because those are the types of people that they are that they. Or, you know, the odds are pretty good that they're going to want to do something like that and that they eventually will give it a shot for sure.

**Ellie Rofe | 53:40**
Yep. Yeah. Fabulous. Thank you.

**Demitris | 53:50**
Ellie, for this question, would that work? A list of companies in collaboration with the VC. Already. And because usually they're to go to the next level, the.

**Ellie Rofe | 54:00**
Yeah. So the VCS, definitely there's lots. So there are ways like crunch base or things like that where you can get, you can understand who's been funded recently or who hasn't been funded for a year or so or whatever like people who are likely to be raising soon. 
And obviously, part of my approach that I'm I think is going to be my real focus in December in the hope that they're not really doing too much in terms of meetings and might just take a punt, but who knows? Is. Is to try and connect more with V Cs and potentially try and get them to fill out a survey like we discussed, but just do a very lightweight thing initially just to see if I can get any response basically because definitely people who are already funded the follow on funding is something that VCS want to help them with.

**Demitris | 54:53**
Three. 
So it would work, but not as an immediate conversion, right? From my understanding.

**Ellie Rofe | 55:10**
It depends. Sometimes. Sometimes a VC will. Just a lot of the time. It's just that you've worked with one of their portfolio companies, and then they like what you did and they introduce you to another one of their portfolio companies. 
And so I'm just a little bit in the, in a gully at the minute between the two things in the people I've worked with so far don't really have VC investors. They either have angel investors or they just spun out of something. 
So they've got no investors yet. And the people I worked with before have sold and disbanded and their investors are either really pissed off or because one of them went under. Or they are. Or I've already been in touch with the ones I know. 
So it's. I'm just in a bit of a sort of hiatus on that, I think, in terms of the referrals.

**Demitris | 56:12**
Okay, yeah, it makes sense. I'm putting on the chat a link from a Greek VC company with a portfolio.

**Ellie Rofe | 56:20**
Right, he.

**Demitris | 56:25**
I know they focus mostly in robotics and army solutions. Anymore. 
So they invested a lot. They founded they help a founder in countrysides to create robotic systems in agribusiness and they had an exit in US yeah, I'm not going to follow the.

**Ellie Rofe | 56:46**
Wow.

**Demitris | 56:52**
The founders of Marathon on limiting because they post a lot and they have investments in other countries like in France and the UK and Dublin and.

**Ellie Rofe | 57:01**
They are quite small as well.

**Demitris | 57:07**
And I think the list of the companies they're looking for the next step from what they say, they try to push the most they can.

**Ellie Rofe | 57:13**
It was a small team, but it looked like a decent fund. Yeah.

**Demitris | 57:21**
Yeah, they feel pretty good at that.

**Ellie Rofe | 57:24**
Fabulous. Great show.

**Ray | 57:26**
All right, ideas are flowing. Let's be maybe emailing around. I thought of a contact as you were asking the question.

**Ellie Rofe | 57:34**
He.

**Ray | 57:34**
Actually, more on the investor side, someone who just recently reached out to me. 
So I just forwarded to you an email I got from him which linked to a slide deck, and I thought maybe if that be you could determine whether or not you'd like me to make a double opt in, which I'd be glad to do. 
And yeah, I think that kind of. Hey, do you know people who maybe aren't producing for your network or could be producing for mine? Is like a really good use of the. The mastermind as well. So I'm so glad that you asked the question. 
And I think that would be a fine question for us to be asking each other on a more regular basis because we're all trying to help each other group.

**Ellie Rofe | 58:07**
Absolutely.

**Ray | 58:09**
Fantastic. Thank you so much, everyone. This has been a great hour, and we will. 
I'll see you all at the end of the week, and we'll do this again next week, and Demetrice will be in the hot seat.

**Ellie Rofe | 58:18**
Thank you. So it's been really.

**Demitris | 58:20**
Yeah.

**Robert | 58:22**
Thank you all. Thank.

**Demitris | 58:23**
You, Guy by.

