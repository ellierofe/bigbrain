# State Change Mastermind - Jul, 29

# Transcript
**Speaker 2 | 00:03**
Hello, Robert, how are you today?

**Speaker 3 | 00:05**
I'm good. I like your background.

**Speaker 2 | 00:09**
Yeah. I'm at a nearby lakeside cottage, which has been in my family for a while. Yeah, we're named because my kids are in camp a little closer to here, and we have to use it during the week.
I have lots of demand on the weekends.
A little bit less during the week, so... Hey, come over.
The kids have less drive time, and... Well, the view has its know?

**Ellie Rofe | 00:35**
[Laughter] Pretty.

**Speaker 3 | 00:37**
Very cool. This is the first time I've seen any change.

**Ellie Rofe | 00:38**
Beautiful there.

**Speaker 3 | 00:41**
Yeah, it's the first time I've seen you anywhere different than your usual setup, so it's a bit.

**Speaker 2 | 00:47**
Yeah, I'll get used to it. I appreciate the lighting and what have you. It's not perfect. Not what I would try to do for most calls, but I hope you'll forgive it a little bit today. That's totally right.
I think we have Demetrius joining us as well, although not yet with a microphone, so we'll get that link kicking going in a minute.
Okay.

**Ellie Rofe | 01:23**
It's like a screen saver. In the background, you can see those clouds moving between the windows.

**Speaker 2 | 01:28**
Yeah, it's not the not that blo.

**Ellie Rofe | 01:32**
Is it pretty cloudy there today.

**Speaker 2 | 01:36**
No, in fact, if anything, it's actually a little still and quite warm, but we are.

**Ellie Rofe | 01:43**
A cloud's swag in his own world.
Hey.

**Speaker 2 | 01:49**
Gus. Okay, now we've got the whole crew together, let's go around the horn. What kind of week has it, what kind of week has it been?
And Robert, maybe we could start with you today, sir. For sure.

**Speaker 3 | 02:08**
So the type of week has been... Well, okay. I would say that overall, it's funny. I think about a week ago that we met, and at one point during the conversation, I had said out loud that...
Then at that point, I was working on the universe database, and I was working on a few tools. I had a thought at some point during our conversation here that essentially creating a middleware would be a good idea for the Zeno tool.
Since I had that, I just couldn't let go of it. So I just couldn't stop working on it since then. It was just like it consumed me a little bit. Now I'll be honest, yesterday I spent the entire day again working on it.
But I'm done, I got it done. I finished it, it works now, and it's very... I've made sweeping improvements, and I'm working on... I was putting together a script because I'm going to make a video about it today.
Overall, that's my biggest real change really since last week. For me, I'm excited because it gives me a few things to really push into the market with that I know nobody else is doing in terms of the technology.
So I'm going to ride now. I have pushed a ball, I guess. For me, that's an analogy that I use for myself. I've pushed this ball up a hill and then I let it roll down the other side.
So that's what I'm going to do with this. I know that I've done probably... There's definitely a few things in there that I've done which are going to be very interesting to people, and it's going to be useful for people.
So yes, essentially, I'm going to be putting that to work for myself now, and that's my. And then. Yeah, so like the... What changed really in the last week if I was to think about it is a lot of studying a ton of studying.
Now, just Tuesday, and I have to really push into the market, and I'm looking forward to it. Okay.

**Speaker 2 | 04:50**
All right, let's keep going around here. I think I land backing you at the end here, Robert. Ellie. Can I check in with you? What kind of week has it been?

**Ellie Rofe | 04:58**
It's been very good. Yeah, I had a pause at the end of last week. I took a couple of days out of the office. I have been quite isolated and working, staring at laptops and things for quite a long time now, two to three years without much of a break.

**Speaker 2 | 05:05**
He.

**Ellie Rofe | 05:15**
And thought this... I'm not feeling very motivated or focused. I went with my other half, who is a renovator, and just went and did something physical to help him out on a job, someone to let him down, and it really radically shifted my mindset and just really helped me. It just refreshed my brain an awful lot. Being away doing physical work, movement, some repetitive stuff, some different problem-solving, and yeah, it was really nice.
Then I came back with renewed energy. I have finally found the right email for a VC I know. I emailed her. She got back to me literally in three minutes, which was really nice to see, and said, "I'm traveling, let's connect in August." I got a conversation with her.

**Speaker 2 | 05:58**
One.

**Ellie Rofe | 06:02**
She's been a really good referral source in the past.
I've got someone else referring me. When a new CEO comes on in September, there's stuff happening, which is lovely. And hey, [Laughter] and I have just... There are two things today that I've really enjoyed.

**Speaker 2 | 06:14**
Hello? Well, let's see it. Yeah.

**Ellie Rofe | 06:25**
Firstly, I have managed to download or extract something like 40,000 records from the SRB to look at the patterns of government funding in hard tech over the past six years.
So prior to the pandemic, during the pandemic, what's happening now? As part of my ongoing access data, extract it, work out how to analyze it, and in the long run, build that into a more tool-like thing.
So I'm just trying to work out how to take that 80 meg CSV and do something useful with it in Gemini, at the moment, which.

**Speaker 2 | 07:06**
Yes. Sure.

**Ellie Rofe | 07:09**
But it's interesting, and it's amazing how much data is actually out there.
Like you were saying, a lot of people just don't do anything with this stuff. But actually, there's probably things that I could be doing with it, and talking about something really interesting. The other thing I've worked out is that I've had this longstanding issue with talking about Pitchdex or marketing, which is that everything is done under NDA.
So when I'm trying to talk to people about before and after, it is not like doing it before and after of a design where you can go, "Here's the website hero before and after, or here's what social media posts look like before and after." I can't show much to.
So I've worked out a way to show what I'm doing with the structure of a deck whilst simultaneously... So basically, I've got AI to take a deck, extract it, churn out the headings of that deck, but for a completely different company so that you can see the original deck and the structure that it did.
But I'm not breaking any NDA, and then I'm just chucking those headings into a PowerPoint and putting color-coded little tabs on those slides, saying this was about the market, this was about the problem, this was about the ask, this was the investment thesis, et cetera.
Then, I'm showing people the before with those color-coded things on so that people can see the structure, and then the after, so that people can see what it looks like when you've got stuff in the right order, the right balance, et cetera.

**Speaker 2 | 08:37**
He.

**Ellie Rofe | 08:38**
And I'm going to experiment with that today. I'm just going to... After this, I'll record something and see if it is translatable still, if it still makes sense, or if it just feels a bit divorced from everything.
But it feels like a useful way to both... I used up and Claude a quick check like a project and I dumped in a deck for the guy I'm talking to or the company I'm talking to on Thursday, and the analysis worked really well. It picked up a lot of the things I'd picked up on that read of the deck, but it's fleshing out stuff and giving visuals of exactly where the problems are, so it's nice. Things are going good.

**Speaker 2 | 09:13**
That's super cool. Yeah, Excellent.

**Ellie Rofe | 09:16**
Thanks.

**Speaker 2 | 09:16**
And Demetrius, how are things growing since we talked last week?

**Speaker 4 | 09:24**
I all nice, very good, I would say. I started getting some feedback from the activities on LinkedIn and on YouTube. I saw some... Basically, I had the first message on my LinkedIn saying, "Hey, I realize that you're doing that."
He got exactly what I'm doing. Which means that the messages were communicated in the right way, which is fine. What an incredible thing. I would say that I saw that using thumbnails makes a huge difference on a video. Very huge.
So I started working on adding thumbnails for the rest of my videos. I was surprised from that. The last thing is that the recording in Prezi works for me. So I think it's, for everyone in here, the best way to experiment and find what works for you guys.
Doing the video is the best suggestion I would say. These thirty minutes before doing this session are quite pressuring on me. So I just have the fluency to say what's going on and then the editing will clean it up.
Immediately, I stopped thinking about how it will look like. And closing, I'm very excited that this current week with LI, we're going to do an accountability session together like those we do with Robert. I'm so excited for that. I'm sure we're going to express each other with what we're doing.
In terms of my shipping stuff, I'm still working on digital twin development. The client approved developing a digital twin for their own client, which is using everything the company knows about the client. Create a clone for this client and use it for experimenting and all of this stuff.
So I'm waiting for them to give me access to all their data, and at the same time, I'm doing my study around the subject, finding the best ways to structure data and how to create an MVP, just to validate that this is the right approach.

**Speaker 2 | 12:08**
Yeah, I hear that. That's super cool, man. I'm very excited for you. We've talked about the digital twin as a line of business broadly across the group before.
I think it's a term that seems to penetrate the business audience more, but it's so ill-formed that it's not like, "Wait, I'm competing against this person's digital twin product." No, it's just a digital twin, just an idea.
That means you can craft it in something that actually doesn't have any direct competition. I really like it for that reason. So cool. I'm very excited for you and all this stuff sounds very exciting.
So that's our lead-up. Let's talk about we're heading into the new week. I think, Robert, this week is your hot seat because I think last week with Beetrice, the week before that was Ellie, and I think that's the rotation we're on.
So I guess I would ask a question: how can this group be of service to you today? As I was pushed back on in office hours earlier today, what's your hardest five percent this week?

**Speaker 3 | 13:09**
All right. I would say my hardest 5% probably is asking for help. I would say I never ask for help from anybody. I have a problem. There'll be... I don't want to necessarily lie down flat and just turn into a therapy session.
But just to say that, I had my own experiences where, just through doing engineering and doing everything, I had situations where I had moved to do my education and everything, and then everybody who I went up there with dropped out of the program within a few months.
So then I was living in a houseful of people who were not doing engineering and who were talking about how much they hated engineering while I was the only person who was still in the program. So that kind of changes you a little bit, and you get used to doing things on your own a little bit, but...
So I guess maybe... I mean, I was just going to say that I would be very happy to join your accountability sessions, just to even get back on that horse because I think that was... I know this is not exactly the question.
I think I'm just jumping straight to a solution. Maybe it's me asking for help. So I think, yeah, just to say that that's something that is probably the hardest part of my week.
Honestly, in a lot of ways, it's just asking for anything. So just to say that, it's something else, and this is... I mean, this is maybe a little bit hard for me to word exactly, but I used to work for a while before I did anything, before I was working in professional technical jobs or anything. I used to work at
a woman's clothing department, actually, for years. All women's clothes and one thing I learned while working there was that it's not what you say, it's how you say it.
I'm just wondering when it comes to this business or for anything, but especially when it comes to the field of online professional services, are there things that you've learned? This is how a better way to say this to introduce your pricing to ask for a testimonial. Are there words or phrases that...
It might seem very... Because to me, those are things that I think are very helpful, like to have frameworks in mind for how to introduce things, especially when...
For example, somebody asks, "What's your rate?" Then, let's say your rate is $700 an hour or $800 an hour. The goal is to keep taking a higher and higher rate. Is there a framework to say what you rate? Is it as simple as just saying, "This is the price"? Is there AI that doesn't want... I don't want to put too many guardrails around it, but I think, you know what I mean?
We're trying to say something to somebody, and we're communicating a whole bunch of things at once. There are many ways to do that. There are infinite ways to do that. I think that for me, I'm trying to really dial in on my communication with people and become
better at transitioning relationships into paid relationships. For example, somebody's on the phone, and they're there, and they're meeting with me for a reason.
Now, they can just go and disappear, and I will never see them again. Or I can come in with a plan and with something in mind that's say, XYZ. I'm looking at a video game type of structure.
How do I get to the situation where I win where everybody wins? Let's say, right? Yeah, good for me.

**Speaker 2 | 17:49**
Okay. You've brought up three things in the course of this. I describe them as... I think since you call the last one the doorknob question, I think we'll tackle it first because it's the most important one, right? You ramped up to it.
But just so we don't lose the thread on them because I think they're all useful and important questions. Number one is closing, converting a relationship into a business transaction, right?
Yeah, which relates to the question of, "What's your rate?" So that's part of that conversation, and I think it's part of the challenging part of communication, right? So I think that we talk about communication, which really is what's waving into is the other one that you were discussing. I think you can get a bigger issue conversation, but communication...
I think that really relates to this question of asking for the business.
Because in both cases, it's about shifting a relationship from one where at least you perceive yourself to be giving, giving to one where there's a give and a take to it, or giving the other person the opportunity to give, which can often be something they really want to do, right?
But either way, there's this question of how you turn it from a seemingly non-economic transaction into an economic one. There are numerous nuances to that. How about we start with the doorknob and we stay focused on it until such time as we maybe want to go to the SRL part,
and we get some thoughts from the group. Does that sound okay as a way to structure things, that starting point?

**Speaker 3 | 19:41**
Absolutely. Okay.

**Speaker 2 | 19:43**
Cool. Demetrius, can we start with you, sir, on this question of closing business, which is, I got to say, not unrelated to part of what you were talking about last week, right? The whole 30-minute meeting
and the ramp-up. Whatever. But what are your thoughts on the question of how you convert from a relationship into something where you two are, where you're doing business and providing value at that different level.

**Speaker 3 | 20:13**
Microphone Demetrius.

**Speaker 4 | 20:19**
Thank you. I think the challenge here is to find the right words. It's important to use the right words, and for me, it's not that easy because English is not my native language. So I try to steal smart phrases and smart words from Ray, from Ellie, from Robert, who... English is your native language.
I see you use very polite phrases to convert the conversation to different paths, which is the path from meeting each other, converting to a closing, and from my experience, what helps is...
First of all, what makes me feel comfortable to use is that I'm not an actor, so I can just use the words that Ali uses in her own tone and the way she uses it. I tried it. That's why I say it's not comfortable for me. It didn't work. It was really not liked, and I wasn't on my recording video.
So it's nice to find key points, experiment with them, and find what will work for us. The second is to think about who you have in front of you. We're human and we create feelings. We feel totally different when we're the four of us in the same room.
It's totally different when we're in one-to-one sessions with Ray, one-to-one with Ali, one-to-one with Robert and so on. So it's the same with the client. How the client is... I mean, I'm getting in the past in a session with a person who was not engaged. I could see that he was looking around, looking at different browser tabs. He gave me a question, I had to give him a response. What's going on? There was a guarantee closing here. Here's there's no engagement. Should we talk about closing?
Okay, let's drop and live the best experience or the last worst experience. But when someone is engaged with us, I try to make his experience, his minutes with me more comfortable, more valuable, more enjoyable.
So closing that, I would close with a call to action. Would you like to schedule a session for next week or for the end of the current week? Doing that, I... If I understood correctly what the problem is, say...
Okay. I have a problem with exactly this thing. Okay, that's good. Would you like to do a session on Friday, make it done, or find the best approach step by step so we can test it? If it's the first time. What I do with pricing policies, I offer a first thirty-minute session for free.
And they may like it. I don't know, but they want to experiment with the one-on-one session because it's not that common either. So they came. I'm closing that I have to be clear to them immediately, without hesitation. "Hey, Ali, I like your job, I like your doing, I like your collaboration right here. I would appreciate giving me a referral. I would appreciate it."
It's clear, I'm asking her to pay the bill, that clear. "Hey, I'm doing that. It's not... Maybe I don't use the right word, ridiculous, but there's no reason to hesitate to be clear and say, "Yeah, of course I'm looking for new clients. I'm looking for referrals."
"Yeah, this is normal? This is something the other side... 100% sure they're doing too. Who's not looking for new clients or for new referrals? Show me one who doesn't want to scale up his business. Most probably you don't, because we tend to talk with people who look like us. One common thing our target audience has is that they want to scale up.
So, most probably they are looking for that too.

**Speaker 3 | 25:08**
True, with owners that are used to talking. Like you're saying, they are business owners most of the time, so they're used to talking money.

**Speaker 2 | 25:15**
Yeah. Alie, could we get your weigh in on this question of that you know, basic closing.

**Ellie Rofe | 25:27**
I mean, it's not something I'm... I don't feel like it's something I'm amazingly experienced at. And I think certainly with the pitch tech work, I am on Easy Street because I'm being introduced to people who need something a lot of the time at the moment.
So, I'm not trying to do a hard sale. I'm not like, "God, I've got to get them before they get off the call and go cold or whatever." I'm talking to them about their pitch, the problems, and I'm asking them quite naturally, "I mean it is obviously sales techniques, but I'm quite naturally asking them where they're struggling to get funding. Where people are, nodding off in the deck or what objections they're hearing or that kind of thing."
So, I've probably already agitated the problem just through natural questions I'm asking them. I've already talked through how things are working. I've been referred. So, I have a little bit of...
We talked about this a bit last week, but I think some of the best advice I heard on this, which really sat well with me anyway, especially because I'm not... I never used to be great about talking about money. It was very much...
In Britain, especially, you're not meant to talk about money. It's trashy, so someone said to me, "When you say it, how do you feel inside?" Like when you say my rate is this or this is how much it costs, do you squirm inside or are you comfortable with that rate?
Closing the gap so that you don't feel uncomfortable with what you're saying is one of the most important things. If you feel uncomfortable with it, you make other people feel uncomfortable with it.
If I'm saying, "Right, it's going to be 10,000 plus 80 for this deck or whatever." If inside I'm going, "All gods, too much," then that will come across. So partly you have to close that gap and actually say, "This is reasonable, this is realistic, whatever," and train yourself.
That kind of happens at each level, you just move up. But you don't have to be perfectly comfortable. There should be a little bit of tension because otherwise, you're probably working in too low a rate.
But that's one of the best things I heard: "Just make sure before you talk to anyone about it that as you say it out loud to yourself or your partner or someone else, the rate feels right for you,
and you can confidently say it to someone else." In terms of words, I mean, the thing is, there are really great books that give lows and loads of techniques, like "Never Split the Difference" by Chris Voss
and "Getting to Yes" by Roger Fisher and William Ury. They give you loads of options. I said, "I think I said to you the other day, I tested out the favor, like doing someone a favor." Then immediately, he offered me something in return.
There are lots and lots of techniques. I would just try one at a time and not try and implement them all at once because you go mad. But something like that. Because I think the biggest part, which I think feeds into what Demetrius was saying, is you have to be yourself. You can't pretend to be like Matthew McConaughey and the Wolf of Wall Street if that's not who you are, and that's going to send you mad as well.
So I think that's a big part of it is finding the persuasion levers that work best for you. So, I'm quite jokey, and most of the CEOs I speak with are quite... They like a joke, and I can be a bit cheeky.
So, by the time I get to the thing, if they react to it, I can joke with them and go, "Girl, was that a bit steep?" Was that more than you were thinking or whatever? Because I can be playful with them.
Because that's where I've got to. Because that's naturally where I see it, but for other people, that would be a horrific thing to do. So, that's what I don't think... I'm no expert on it, but that's how I've found it so far.

**Speaker 3 | 29:28**
I appreciate it.

**Speaker 2 | 29:30**
In terms of your rate when you bring it out, is this something you have previously written down or is this something where you're thinking on it or do you have it? You know, you're making it up on the spot for that particular client? How does that work for you in terms of your preparation in that regard.

**Speaker 3 | 29:50**
Just towards myself.

**Speaker 2 | 29:51**
Actually, I meant to be asking both Ellie and Reg. I would ask you, Rob. I'm sort of part. Part of this question is like how much of this is being done extemporaneously, right? Versus how much of it is, you know, rehearsed or prepared, if you will.
And I was wondering whether Ellie and Demetrius and maybe start with you li then we'll go to Demetrius could sort of speak to that because I think part of it is going to be about like what are we doing in the moment and what are we doing before the momentm.

**Ellie Rofe | 30:16**
I know what I'm going to say beforehand because I've got. I mean, this is like processed, turnkey stuff. So if they want extra stuff, then I'll say my standard rate is this.
I'll give you a quote for the other stuff. Then I go away and think about it. Sometimes I get introduced to a company that is possibly a bit too early to be able to afford me. I have in my back pocket, do I want to give them a discounted rate upfront with a higher thing if they get funding?
That's very much a call on me whether I like working with this person because obviously the likelihood is I might not get that second portion of money.

**Speaker 2 | 30:49**
He.

**Ellie Rofe | 30:58**
So, you know, that's. But it's a sort of back pocket thing.
If you want to negotiate a bit.

**Speaker 2 | 31:06**
Got it. Demetrius.

**Ellie Rofe | 31:08**
I.

**Speaker 2 | 31:08**
How. do you handle that question of what you've prepared versus what you're doing in the moment?

**Speaker 4 | 31:17**
There's not a specific script. I try to just explain to them how I count the time because I apply the charge only for the minutes on the call. So I try to explain that I found myself, for two months, communicating different prices for every new client.
So I wanted to test the price and I found that I wasn't comfortable communicating different prices. I couldn't get who they were, so I wasn't comfortable. So I stopped that and said, "Okay, one fixed price."
I trained and now I say it quite easily, the same number. Then I focus on an explanation of what's going on. I cover what's going to happen if something doesn't work in order to cover the risk they're going to take to join a session with me.
I have a rule. I don't accept any discounts and I don't want to give a discount and not how discounts. A few of them came to me asking, "Hey, would you do another discount for us if we schedule X amount of hours per week or X/month?" and "Do you want me to add a discount on the quality of my service?"
If yes, I'm going to do it. Yeah, totally. Because I know from previously that there is no probability for them to increase the time per week if they want to increase. It means that they want to hire someone to do the tasks.
But the job is to teach them how to do the task by themselves. That's why I can say that phrase. So I kept it like that. It took me time to deal with the price because, in Greek economy, if you say 150$ per hour, everyone says, "What? Yes, what? For a freelancer or for an agency who either his mother doesn't know him?"
Yeah, but for an EY consultant it's 150. Wow, quite cheap. Why? We were in the school together, he is in EY for 6 months now. What does he know more than me about technology? So I pressured myself on that. Competing with the best in the market. EY had in my MBA colleagues who were working for a big force, and they would say that they get paid for ￢ﾂﾬ20 per day, no matter the extra hour they do during the day, and their contract, their big company sells to their client is 150 euros per hour. As a man, no way.
What do they say? Prefer low-code applications and wasn't the case. I'm taking for consultants, not auditing and on taxes and stuff for operations. Prefer local tools and they don't touch the keyboard to build it. Are you serious? I'm going to teach you how to do it by yourself. You don't need an army of developers to do that if you cannot see the value. Thank you. Perfect, and we don't have the best months. I don't want to consume your time. You shouldn't consume my time. Let's move on.

**Speaker 2 | 35:03**
I think that question of value is such a key one that... When you think about people going from being not your customer to almost being your customer to being your customer, right? There's AI that I think only people you can convert with. People who are almost your customer.
Right. So there are some people who have a longer divide. I can often tell those people, in the context of, for example, state change, leaving... People talk for consulting, people talk to state change, and people will talk for state change. They're like, "Yeah, but how many questions am I going to get to ask in these sessions?" They're like, "Okay, this isn't going to go well because they're basically trying to back into some sort of hourly rate."
Most of the time, these people then don't show up and then don't use time and then they just sort of fade away. They're not thinking about the key question. The key question is what are they trying to accomplish? Right? How committed are they to accomplishing the thing that you're looking for help with? I'm sorry.
I have a little fly buzz, and that's number one and number two, how is this going to make the money? So, particularly if you're talking to principals in the company, as you know. So at least some of your businesses... How does this drive value for them?
When you have that with clarity, then it's okay. Well, is that value more than ten times what they would be spending with you? If it is, then you're doing them this massive favor by helping them get a ten to one return on investment. "Hey, I'm giving you access to $100,000 by doing this $10,000 thing," right? In the case of Ali, it's like, "Hey, up $10,000 to improve the odds of converting this significant fund raise, which is the capital and how much excess they get on top of that."
They're that's for... I think I don't know, but I suspect that for Ali, it's a lot of getting them to have an acute sense of how important they are to their fundraisers and how the part of the pitch, right, that Ali is helping with, is important for that fundraiser.
Where those two things are crystal clear or very clear, they're almost a customer at that point, right? And then there's the ask. So it's like just bringing them to the edge I find to be the key cause. Then tipping them over is like there's activation energy to that. Absolutely.
But that's where all those little techniques and Change GenAI stuff and whatever start to batter more. It's like you. Even if the point of the psychological trick is to trick yourself into asking for the business.
I find the bigger challenge is I'm talking to this person, and then they didn't convert and have a little conversation about realizing they weren't that serious about the initiative, right?
It's not just solos that do that. I actually ran into Xano doing this just last month where they were trying to make this sale to a large organization.
They didn't have almost a customer at that point. Part of it was not having qualified. Part of it might have been in the relationship, whatever, but when they asked for the business and the company ghosts, the reason that happened was the company wasn't really that serious about the thing they were talking about to begin with, right?
There was a whole process that you had to go through of getting them serious about it or discovering when they were really serious because when they are serious, they really want to do this.
So they have an emotional connection to it, and if they have an economic connection to it, then they are standing right at the precipice, and the activation energy required to knock them over is very small.
Then you're doing them a favor, right? Because you're helping them execute on the thing that's really important to them, and it's going to make the money. It's not like you're going from being a giver to being a taker, right? You're going from being a giver at this level to being able to give them at this level, and in the meantime, they're paying you a little bit more than that, right?
I think it's just all about the ratios because if you do that, then you will feel good about that because then I mean the ratio overturn obviously was infinite for them before it cost them time, right, to get your counsel right. That was the first half hour.
Then it's their cost of time plus a bit of money. But to get this much value, that's the excess that you can be delivering to them. If you are convinced that that's going to be a good thing for them, then I think that helps a lot too.
That's a bit of what I'm hearing here: it's not just like you use the tricks to trick yourself into doing what's right for them. But I think you should have the confidence that that's the right thing for them. The other thing I'll throw in terms of preparation is I publish my rate schedule.
That way, existing clients and future clients can look it up and say, "Okay, based on their schedule, right?" Which is either the MVP schedule or the MFN schedule, not MVP or the retail schedule. They can see what the rates are.
Maybe it was one thing and it's another. That's why I publish it as a Notion page. As I change the Notion page, the web page goes with it. It keeps changing, but it means that I don't need to make up what the number is. It's just that number.
I will often send it to them in advance or I can give them a link directly on the call or whatever. Then it's like they know that they're not getting some sort of special bad deal.
It's this. Then I have my accelerator program. The point of the accelerator program isn't to give them a discount, it's to reward them for commitment. To commit. The accelerators, we're going to go fast.
If we do the accelerator, we want to do one call. That's fine. I've had people come in, they did the one call and they left fine. But people who are looking to really make this thing go, "Hey, let's do the package."
They're committing to it, and you're making the whole thing happen. And so let's use up all this stuff in a week, right? The time is such a big value piece of this, but that's the approach I've taken, right? To be able to ask for the sale, if you will, is if I can determine that there's a ten to one return on investment here.
I could be conveying that to them like, "Let's make you money." It's like, "Well, no, it's so good to think about." Fine, but that means that they're not convinced that there's actually that kind of return for them.
Probably closing them at that point would be a disaster as well, right? So you're not trying to get them to do something they wouldn't otherwise want to do. You're trying to enable them to do a thing that you know is going to be the best thing for them.
I think when you do that, there's a lot of money to be made, and you don't need to feel like you're doing anything sleazy, right? Because this is the opportunity for them to get a whole lot more value. I was talking to a guy who is in customer success at Microsoft, and he didn't really like the gig because he was being asked to do more sales, and he was being asked to push for particular products.
The thing he didn't like about it was when he... I mean, that's the way they make money in customer success by pushing products. But when he's pushing products, he knows the clients are going to get value from it, and he feels good about it, right?
But what he thought was that the CSMs were really getting value from that. It's just like the order from on high or tied to a bonus or whatever. It's like salespeople might be incentivized by bonuses. I'm incentivized by making my clients have really great value, right?
Have a really great experience working with Microsoft, and want to stick around and the... And have them say at the end, it was because they were working with Damien or whatever. That I would take the same view for any of the professional services we're providing here.
You know, what helps them get the most value, and you don't have some external force saying, "Hey, let's push some particular product." You are pushing your best counsel, and that's why you're doing it. The reason you're doing it is because you believe it's the best value thing.
So there's AI... All these things are easier said than done, but I think there's a little bit of just having confidence that you are not going from being a giver to being a taker, right? You're going from being a giver, a small giver, to being a big giver.
This puts you, and the economic relationship is to enable you to be able to deliver that massive increase in value when you see it, and I think the MCP stuff you can do, wow. There's big value for them, and people will either be convinced of it or they won't be, right? This will create a lot of value for them, and people who aren't convinced
are totally cool. You stay in touch, right? You're working them into becoming almost a customer, but the people who are convinced are almost a customer, and those people you'd be converting to customers.

**Speaker 3 | 43:53**
That was really helpful from everybody. I was hugely appreciative. I think, Ray, what you mentioned at the end, they're actually, especially like with the MCP. Just for me, I appreciate the foundation of how it's just set in logic, how it's like, "Okay, if you're gonna get ten times the value, then obviously it's worth the investment."
Just thinking of it from that point of view, it makes it more clear who's not going to get that ten times the value and so on. But I think it makes me realize a bit that maybe that's why I'm working so much on the MCP is to demonstrate the value because that is what I'm driving towards selling.
So I'm trying to make it really obvious that, "Okay, this is what you're gonna get. Like, at the same time, I'm trying to get better at building them, but... It's practice for me. The other way, I want to really demonstrate that, "Look at what this does." Because there has to be an economic upside. There has to be... It's clear to whoever that you could get something that it's not just necessarily a wrapper on top of your existing APA. It could even be more than that.
It can be a pleasure for people to use, and I don't know any other way to communicate it than for something that's so new on the market because there's so much education that I have to do about it.
Then, that's on the MCP side of things. Maybe just pushing because that's where I'm trying to take to practice. There are other services I could offer, which are more, let's say, the bread and butter services where I'm doing the development for them.
Yes, it's easy for them to see, "Yeah, okay, you built this thing for me and so on." But, yeah, I think the other thing that would probably help me is if I bought a whiteboard and, as you said, because as you were saying, to come into the conversation to know,
"Okay, these are the rates." Even just to... I know I have actually had a piece of paper where I would just have them written down on a piece of paper, but I think it would help to even solidify more than that.
But yeah, not just reiterating a little bit and connecting to the dots for myself.

**Speaker 2 | 46:28**
Yeah. So please, yeah, like, go ahead.

**Speaker 3 | 46:34**
This.

**Ellie Rofe | 46:35**
Have you heard of the value proposition? Canvas, Robert, okay, it's really useful. It's by a strategist, I think, and I can send it to you. Okay, cool, fabulous.

**Speaker 3 | 46:48**
I'm Googling it right now. I found it. Yep.

**Ellie Rofe | 46:53**
It's not to be too prescriptive about it, but I think one of the things that just struck me when you were talking about how you have to explain what you're doing and show...
I mean, I think absolutely being able to demonstrate something that was worth a thousand words, or ten thousand, really. So, I totally get where you're coming from. But it talks about not just game creators, which is what you're talking about.
I'll talk about that in a say, but pain relievers. I think it's really important to think you're not selling them the technology really, you're really selling them the gains they will make and the pains they will no longer have.
One of the things with the pitch tech I always mention. I throw it in casually. I say to them, "Obviously, the other thing is you won't have to spend hours working in PowerPoint because that's the last thing you, as a CEO, should be doing." Now, they hate working in PowerPoint, or they get some designer to do it, but the designer doesn't know what they're doing and doesn't know the story, et cetera.
It's a small thing, but it's a pain reliever. When you're talking to people about this stuff, you're really just saying, "We've got some paracetamol, Tylenol, or whatever we call it in Canada." I don't know, there are so many names. We've got some painkillers for you.
We've got this big, fat, juicy prize that's going to make things much nicer. Some of them because you'll be speaking to some technical people really care about that, but some of them won't. They'll just want to know what they get.
So, don't put too much pressure on yourself. And the other thing I know that I've always felt, which is I think is easier said than done. But there's a book or a TED Talk called "A Thousand Noes." Where someone tried to get a thousand rejections. They went out specifically to say, "I will get that many rejections."
Because once you've got that many rejections, you're getting yeses as well. But it's the flipping of the mentality to think, "If I get a rejection, if someone doesn't want to work with me for some reason, that's fine.
That's just one rejection. I will get amongst many, and I will carry on because it's not personal to you. It's just part of the process." So that was... Sorry, that was my twopence.

**Speaker 3 | 49:14**
I two appreciate that. I just wanted to say really quickly that it made me think, actually, about how much I actually suffer with building TMP and just like that, I've suffered since I decided that I was going to do this in March. It has just been astonishing to me how some work on it and then that has just...
All of that makes when you said pain reliever, it made it very clear to me that I thought, "Well, then, if I could go back in time.

**Ellie Rofe | 49:39**
Argues that [Laughter] very clear that because that I never come back to.

**Speaker 3 | 49:46**
You know, and I could just not have gone. Well, I appreciate the pain.
Maybe my mentality is a bit different, but I could see how somebody else might want to avoid the pain. Because it's very obvious to me that it's not a very straightforward process.

**Ellie Rofe | 50:00**
Exactly. You've done the paying. So they didn't have to.

**Speaker 3 | 50:03**
Yeah, Dimitri, I we're going to say something.

**Speaker 4 | 50:11**
E just saw the link you shared above the nose. I'm a big fan of this, where there is a theory of after the 80%, you will get the grade 20%. Just for inspiration, 30-30 years ago, a guy started a company here in Greece who was looking for funding to start the first can with mass production, with it to do it in the packets and carriage to supermarkets and so on. Back in that time, it wasn't existed. We were purchasing Crocs only for bakeries.
The guy was looking for investors, and he was rejected 19 times. The 20th time, they said, "Yes, go do it." They built the first manufacturer place, and for six months, they failed products. Failed products were with really bad taste and so on. They couldn't work, had a lot of problems, and said, "Okay, the problem was in the PASTRIP. We fixed that." Six months of playing on that, and we did it. Even his clients rejected him,
but with the second round, he achieved to build an empire that scaled up to 40 countries. He sold that business to another company, another group, and now he's CEO in many different companies at the same time. In FMCG, he is a guarantee for bankers, for investors. Philosophy is in the game perfectly.
Yeah, take my money. Everyone was rejecting him, and he said, "I didn't care. I knew that I had something brilliant." He was looking for someone who can see the value. That's why he said the story. He was looking for people who can see the value.

**Speaker 3 | 52:50**
No, if I might go ahead.

**Speaker 2 | 52:53**
Yeah, I appreciate that story, too. Just to tie it together for a second, this goes with the whole asking for help thing. This goes with the conversion thing. This goes with the idea of the thousand nos and the story of the entrepreneur.
I think that the biggest risk we run into is not contacting the market. When I think about study, CLL and ship, different people have different resistance points. But what I usually find is that most people are spending all their time shipping or wishing they were shipping, and then they are not really... When they're shipping a lot, they actually don't win at sales, and that causes them to lose traction in the market and almost never... What you're doing is studying, right?
I think that the position you're getting yourself into is having done a whole bunch of shipping, you're actually way over in the details of hyperbolizing the studying part, but studying doesn't need to be...
But I think there's an opportunity to be leveraging studying into helping with your sales as well. Right. By having an activity that could be in both those categories. This links up because I think right now your idea of working on MCP is working with your face lit by the glow of Visual Studio Code and Dark Mode, right? Rather than being lit by these kinds of rectangles that we have here.
I think there is a wonderful opportunity. I talk about my framework for learning as learn, to experiment, build, and teach. Teach is the part that brings you back into the market, right? There is an opportunity both in terms of content creation, but just in meeting people and talking to people who care about the subject.
If you're talking about the subject they really care about, I would... The thing I did before I started State Change is I created a Meetup which initially had some traction, and then the traction faded a bit, and then really started picking up when I started charging for it.
That was the origin of State Change in middle of 2022. So, as a way of finding, "Hey, what do people really care about?" There's demand out there, and there is quite a lot of MCBC demand, and that demand is not really sitting over in the low-code space. I'm actually kind of shocked at how little traction my piece on Xano plus MCP has gotten because it's primarily being marketed in the Zeno space and not really in the MCP space. I need to turn that around in order to create value. You similarly, there's a lot of demand on the MCP side.
I think there's a lot of opportunity. People want to be hearing more about that. All the things you've learned, right? Your point of "Hey, this could be so much easier if you would show more of that."
I think you would get a lot of play on Easyworth that you can be doing that bit with the accountability sessions where you can turn that into content, but you can do that a little bit more in public, like you can have live streams.
What I would really love to have is for you to have events in Luma, which is the way I started my meetups. "Hey, come join us." We'll talk about MCP, we'll set you up. My mission is to get more people into getting value from CP, and then your big mission is to find those people who work with companies that have their own data, so they want their own bespoke MCP, and then you have the solution for that, and that could be as a particular package that could be compelling, right?
The bigger idea here is just connecting, like this wonderful studying given doing, which I put in the experiment and build categories and moving it back into the teach category because you will learn more about what you think and what the market thinks about it. This will give you more secrets, right?
People who aren't in the media are not going to do anything about it. You can turn that into content that gets you marketing as well and gets you back out there. I think the broader theme here is getting out of your head and out of your laptop and into the world.
There are many ways to do that. And I think the world is very eager for your insights because I think you're talking about something that they care about quite a lot. You discover that every time you talk about it a little bit, like you saw the traction you got when you were talking about over-state change, what have you? Sure.
So I would encourage you to come away from this and say that there is demand. There is a desire to be hearing more from you. There are more ways that you can bring this to market and bring the stuff you've learned to market. Not even just for direct...
Like, "Hey, I've got an offer, and you can go buy it," but just like I'm Robert, I'm talking about the thing you care about. That gets moving towards being almost a customer. You could separate that question then, from turning them from almost a customer into an actual customer.

**Speaker 3 | 57:40**
Yeah. Yeah, and that's actually very exciting to think about, even to think about because, obviously, I know that I can remember the feeling of talking to people, sharing things with people. I've been in my... Just in my head for a while.
Then I could only focus on the things that I don't know, and then I start to just feel like I don't know anything after a while. I spend so much time by myself, and I'm just... I stand back in awe at how little I feel that I actually know until I start to talk, speak with somebody, and then
they start to tell me, "Wow, how did you know all this?" I was like, "True." I guess this is actually even something that I take for granted. But then this would in itself, there's so many things that would just make good talking points, good videos and so on. I like the idea of actually putting... Putting the call out there. Putting. Making it very making that offer to the market in the sense of like let's meet and talk about MCP yeah.

**Speaker 2 | 58:43**
MCP meetup it's even allerative yes.

**Ellie Rofe | 58:47**
[Laughter] They... They.

**Speaker 3 | 58:49**
Like it. Thank you, I appreciate it. it.

**Ellie Rofe | 58:52**
On a... Ma.

**Speaker 2 | 58:54**
Awesome. Yeah, and I'll just say, like, definitely when I use MA for this, by the way, I find it super easy to schedule that way, right? Because you can use Luma. Luma, like, integrates with zoom automatically. You can have the event.
Yeah, you to have people sign up, you get to find out what their emails are. They're not feeling like they're using some sketchy site. They're just, you know, it's all really straightforward. Lots of other people use it too, so it'll be their first time working with that.
And then you can just hold it and it doesn't matter how many people come.

**Speaker 3 | 59:30**
Signing up for Luma right now. Actually.

**Speaker 2 | 59:33**
I Actually... actually signed up for it with my Zoom account because it made it just trivially easy to get those things connected. Because then it's like, "Hey, won't make this Zoom." Yes, push button, boom, done. Schedule a Zoom for you. It sets up the code and it just takes care of all the things.
Then you've got a link and you can be handing out that link on forums. I would totally encourage you to put it up on Stage. You can put it up on any other form that you're working with.
It's free. Hey, we're going to be talking about MCP and Factor for sure. You put it up on Stage, you'll get a bunch of people from Stagechas too. I know I would want to show up for that thing. thing.

**Speaker 3 | 01:00:08**
Appreciate it. And I think actually, this is very nice. I think it actually got me excited to think of it that way. I think maybe that speaks to another way of... It's the way you put it, you know, it spoke to me.
So it's the way you say it, right? I just framed it that way for myself, actually, just makes it very obvious to me that it's something I want to do. If I want to do it, then I'll do it, obviously, as I will. As I've shown in the past, I appreciate it. Thank you.
I've signed up for MA, and I have my orders, so I will do that.

**Speaker 2 | 01:00:49**
Cool. I hope that the three of you know about emails or what have you regarding accountability stuff, et cetera. Because this stuff is all... One of the reasons we're meeting here today is because it's all easier when we don't do it alone. Awesome. Thank you so much. It was great getting to work with you this week.
I'll see you all at the end of the week. We'll do this together next week. Take care. Bye.

**Ellie Rofe | 01:01:14**
Thank you.

**Speaker 2 | 01:01:14**
Have a nice day.

