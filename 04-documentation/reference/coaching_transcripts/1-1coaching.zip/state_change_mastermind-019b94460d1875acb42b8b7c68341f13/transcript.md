# State Change Mastermind - Jan, 06

# Transcript
**dimitris@3nuggets.io | 00:07**
Boom, here we are. Hi.

**Ray | 00:09**
All. I apologize for not having scheduled this all correctly with the Zoom meeting, but this should be on the calendar going forward, so we're just... Okay. Well, it's great to see you all again in the new year.
It's been a couple of weeks since last time we got to meet Ellie. It's good to see you looking healthy. Yes. Okay, [Laughter] let's go around the horn. What is true today that was not true when we last met two weeks ago? We start with you.

**Robert | 00:48**
Robert, sure, true today that wasn't true two weeks ago. A few weeks ago was... I am just more... I think just... This is a hard question, so this is a hard question to answer. I find for myself all the time. In a good way.
I think what's true today that's not true two weeks ago is that I think my relationship with the client has just been getting better. I think it's moving in a positive direction. I think that overall, my mindset has shifted in the last two weeks where I'm becoming more focused on other ways of delivering value that are now more related to sharing skills and documentation and things like that, which enable the tool itself to actually act as if it were me.
Actually, that's something that I did today. Just before this call, I was on the phone with the client. What I did was create a marketplace for Claude code. That way, I put all the skills and I put all that stuff into that marketplace and now the team can just install it and get the updates automatically for that.
It's something that I just... Yeah, trying to pay more attention to in terms of just enabling them and doing less on my side in a good way, and so far I feel that it's led to. I'm still trying. I'm trying to pay attention to it and
just be aware. But it feels like it has qualities to it that represent that to me. It reminds me of my best engagements in the past where I'm not so much doing all the work, but I'm finding out ways in order to enable them to do the work.
So, yeah, just trying to move my mindset there and move my actions towards there as well.

**Ray | 03:15**
Okay, cool. Ellie, where were you true today? That was not true for you a fortnight ago.

**Ellie Rofe | 03:26**
I have just delivered the LLM pitch. So the one for the materials physical AI play. I would say that if this gets funded, which is a big if in this market with this company. But if it does...
This will effectively be my dream client and dream project. So it's been really interesting and really positive, and I've learned a huge amount about the kind of person I want to work with. I'm getting faster at understanding that assimilation of data thing that I mentioned before.
I'm getting more and more clarity the more times I work with clients, especially in this earlier stage stuff. I mean, I say that they're 10 years old as a company, but when it comes to raising and the stuff that needs to be in a row, the ducks that need to be in a row, I'm working out what those ducks are and what I need to ask people about that might be missing. That then causes problems further down the line. Even if I...
I've made assumptions about what will be there and it's not there at times. So that's been really interesting. As part of their go-to-market, one of the big things they would need to do is brand positioning.
I talked to him about that. We did a light touch in the pitch deck, which is always important anyway, and then she was like, "So is that something you can help with? I was thinking, yes, this is exactly the flow I want. [Laughter] Absolutely. I want to work on your deck. I want you to get funded and then I want you to spend some of that money on me doing your brand strategy for you and ongoing my strategy work.
So fingers crossed with that. I'm now out of client work. So it's all about marketing and a big push on the sell and the study, hoping to get some more ships coming my way.

**Ray | 05:31**
All to the I get, and are you feeling better? I appreciate it. Like last week, it was sort of a credit week.

**Ellie Rofe | 05:42**
Yeah, I'm feeling much better. I basically dragged my the going back to England in the flu season is just not good, but I'm I dragged myself through the project. It took a bit longer than I'd like.
And now I'm. I'm sort of. I think today. I feel like I'm still a bit in catch up mode, but I'm still like, you know, I've got the eight am calls with Justina setting my intentions for the day.

**Ray | 06:01**
No.

**Ellie Rofe | 06:08**
I'm back in that rhythm.
And so, yeah, I'm. I'm back. And I'm. Gradually. I'm like. 90%, I'm sure.

**Ray | 06:17**
Sure. I mean, the way that we manage the ailments that all come and go, it's all part of the management of the practice. So I certainly don't mean to be intruding, but the way you go through that training, sort of like what it feels like to be on the other side.
I think it's just useful data for everyone, right? As we all... Wait, now we're hitting it. Now, but wait, I know what this looks like on the other side. I remember what Robert said, I remember what Belly said.
Okay, cool, I appreciate you sharing. And Demetris, it's been a couple weeks and last week was going to be your hot season. So this week is here today and I guess it's say you know what is you know what has been the progress last couple of weeks.
But even more, how can this group be helpful to you to be making your next week and next few weeks, you know, go as good as they possibly can?

**dimitris@3nuggets.io | 07:11**
First of all, happy New Year, guys, everyone. All the best. It's the first working week for me. The previous one was semi-working. The first thing I changed to make it true is my learning and study in this new, still new domain for me.
Because from my conversation with Ray and my personal conversation with Ellie and one conversation with Robert, I realized that a couple of things are cloudy in my brain, so I needed more clarity on knowledge about those things so I could explain those things in terms with more confidence and be more valuable.
What I did so far is I created on Replit with VIB coding that it simply takes the transcript and runs a methodology for analyzing it and creates the knowledge graph for it as an image because this is a nice thing to be visible, and the user can download the markdown of the entire knowledge graph.
So he can use it by himself, and he can chat with this knowledge graph. What is created? The reason I've created this is just to have a tool to run a client into my flow and creating giving them an experience, just to have a taste. Not talking theoretically.
Okay, and I have a question. I got a conversation with Ray last Friday where he suggested to make it as a prefixed offer with suggested engagements and the follow-up. So the steps with fixed price, which makes a lot of sense to me. To be honest, it cannot be
time-fracked, and the questions are coming to me, "How can I make it a valuable package for a consultant? We or the four of us are consultants, right? So just speak from your side of view.
How can I make it a valuable package for them? Give them a nice taste upfront and then help them make improvements. So far, what I did is I can deliver... Sorry. So for what I designed as a service is the following steps.
First step: Engage with the clients to bring them the most questions I can to learn more about their business. Because this is important. Learn more about how they give value and they generate value for their clients, because this is the most important.
Okay, so the first engagement is to get this information from them. Then it's very important for me to create the analysis document, which is the way we want AI to analyze the data they're going to import later on to give instructions to AI on how to do it. I go and create this and this is the first deliverable, but this doesn't make any sense to them. They don't get any impact. ABO this level... The next step is to work with them.
Maybe with my tool, maybe with another version of my tool, and feed a couple of transcripts or emails or whatever they have and start creating their knowledge base following the analysis and so on. Then to let them...

**Ray | 11:31**
Play with it.

**dimitris@3nuggets.io | 11:33**
Ideally, I would love to track their questions. I don't know how important it is because it's very fast to deploy the MCP on their cloud up very fast. But I will lose track of what they are asking. This is where the value is generated for me to make it valuable.
After their feedback, we can go to the third step, which is... Okay, we know what works, we know what doesn't work. Let's go and fix it. I help them fix it and that's all. We reengage after a month to have an overview and see what's going on, or after two weeks. Ideally not one month. Is that much? I'm open to your insights.

**Ray | 12:32**
Ellie, can we start with you? Because I think you... He has activated your brain.

**Ellie Rofe | 12:35**
[Laughter] I'm pondering.

**Ray | 12:36**
You're put in pen to paper.

**Ellie Rofe | 12:40**
Yes. So I think it's a great idea to capture questions. Obviously, you've already identified that, and knowing what people want to ask is half the battle because then you can start talking about it in marketing as well as helping you develop the product itself. I guess it seems to me that the point I'm wondering about... There's lots of interesting stuff going on. The point I'm wondering about is saying, "Here's the thing."
I'll come back to you in a week. What I'm wondering is this is really like a proof of concept, right? So a few transcripts. One, I don't know. I don't know how much juice that will give someone to keep using it.
If I think about how I use Claude projects, I use them quite intensively for a specific purpose. I put the data into it or whatever. So then I just wander away from them because it's task-based.
So what are you envisaging saying to them, "Bring me your hardest task or the thing that AI isn't doing for you at the moment?" We will create this micro knowledge base, like the tip of the spear knowledge base, that will help you show you what it can do on this... That's probably my first question.

**Ray | 14:28**
Right, that was a question. Yeah, go ahead.

**Ellie Rofe | 14:30**
Three, it's understandable.

**dimitris@3nuggets.io | 14:31**
Sorry, I thought it was a rhetorical question. I had to ask my client.

**Ellie Rofe | 14:37**
I do rhetorical a lot. So that's fair.

**dimitris@3nuggets.io | 14:40**
Yeah, so at the moment, I can't feel how an ideal that my ICP would answer this question. But the thing is, they use AI a lot, and from a conversation with Ray, they just want to explore what other opportunities exist. They don't have a clear direction they get into specifically. This is my experience with two people who we were planning to engage with. The first one came very inspired from the graphs as a view, not as an impact and as a usefulness, and the other one was inspired from the thing that he can build a tool that can work like AI that knows what he wants to know, not the general part.
Because he realized the garbage in garbage out very well. So he takes a lot of what is the thing I have to process into the machine. So this is my experience, not very representative from the... My ACP I think, but this is what I understand. This is how I would answer. The AI cannot be very specific.

**Ellie Rofe | 16:24**
I mean, I think the visual is brilliant and I think the promise when you see that, you see the promise of mapping someone's brain, their knowledge and stuff compared to just dumping information.
So I think it is really useful. I'm just trying to think of the... I feel like that's... I might even be asking the wrong question because I think that might just be the process. If someone wants to continue with it, you don't need to give them time with it where they're just wandering off, asking questions of a snapshot of their brain. You're just showing them the process and they can see how it works and how you can map something from it.
Then part of the promise is that the AI basically ends up getting you knowpercharged by having the mapping of the brain rather than just this small part of it. That's the promise of it, right?
That's where it excels over other things is that the knowledge is there and it's connected properly and extractable and in sensible, meaningful ways. I felt like... Absolutely follow up. I would say maximum of a week, because people will play with something, and unless it's integral to their day-to-day, then they will stop thinking about it.
So I would follow up after a maximum of a week. But I just feel like that process and that delivery of it is really the sales process. I suspect people who are really intrigued and who can see it by the end of that process will see it because they'll have had questions. You're asking them, and they'll have seen how you're thinking about it and how the data is getting mapped.

**dimitris@3nuggets.io | 18:13**
Yeah, do you know what I'm thinking? I think of building their knowledge database on their own site immediately. I had the thought of us, my tool, as a front interface for them so I can track their questions and do my scoring behind the scenes.
That's why I need this to do my scoring. Figured out what works, what doesn't work, what makes sense to them, how confident the model is, and performed a couple of statistical findings for the model and verified. Then I went back to them with this report. One week after... Here is how much you use it.

**Ellie Rofe | 19:05**
What did you want?

**dimitris@3nuggets.io | 19:07**
This is the output. I would love you to push it more, for example, because maybe we don't have enough import impact from the feedback, and this is what I'm thinking.
Then after we validate the workflow of the analysis, the next big step is to build the environment of automations to keep this database automatically improved. So when a transcript is done, or when an email is processed or a document is processed, they can have an interface by themselves. They can use my tool.
It's not cost-prohibitive. It doesn't cost me anything. But they can use an API or... Yeah, this is what I'm thinking. This is the view I have at the moment.

**Ellie Rofe | 20:05**
I think it sounds really... It's really powerful. The follow-up that isn't just a follow-up, but it is actually ideas is really interesting.
Not even just "Could you use a bit more..." But here are some questions I think you could ask it. Or here are some things you could try and use it for. Push them to... If they're experimental anyway, that's the people you want to work with. Then give them ideas for experiments, give them permission to play more with it.
Yes, absolutely. If you've got the layer where you are able to track and understand it, then it's incredibly valuable. So it sounds like a brilliant idea to me.

**Ray | 20:43**
Very cool. Let's sort of keep the ideas flowing. Robert, can we bring in the conversation?

**Robert | 20:49**
Sure. And actually, if you don't mind, I would like to ask, if like because I feel like it as you said rate like it kind of shifted a little bit like as. So I'd like to just even Demetris, if you don't mind if I would just ask you again, like, what is your question? As I know what your question is, but I'd like to ask you again, like, what is your question? Vic. Just to see if.
If there's a reframing as we're kind of drifting through this.

**dimitris@3nuggets.io | 21:23**
Okay, avoiding the price part, okay, ignore it. Totally. What would be a nice offer for you as a consultant to say, "Yes," and this kind of engagement without putting the criteria of the price? Okay.

**Robert | 21:49**
It just has to really help me remove pain, probably in my life. Remove headache. Make me very happy, make me very rich. Probably the same things that happen, but whatever it applies to everybody else.
But I mean, just in broad terms.

**dimitris@3nuggets.io | 22:06**
The thing is, how are we going to get engaged over this project? The no, nothing is in like.

**Robert | 22:15**
I got. I just to. The funny thing is that even though I'm. Even though I'm engaged, as soon as you say the word engaged, I think of it more in business. I still think of it more in business. I mean, II think it's a tough question to answer.
Because. To be honest, like, it's. I feel, that like if, let's say you had the cure to cancer, right? And it was like just a pill. You wouldn't have to convince me very much to work with you or how much it would cost or anything.
Like, I would just. Your website could just even say, don't buy for me. And I would still buy it from you know, like if it was literally if it's not. I almost feel like for me, it almost it all it has nothing is just again, that's just my point of view. I'm happy for anybody to.
Like, you know. To. To ha to enlighten me to think of it differently, but, I almost feel like in terms of it's not about you. It's not about, like, anything that I if you have something that anybody really wants.
And like I said, I use that analogy of the of like, a cure to cancer because, like, it's such a bad problem. And if you were to be able to solve it with a pill, it's such an easy solution. And like if it was if you were to just put that offer and even just your website were to be the ugliest website in the world that just said, do not buy for me. I hate all of you. You would still be the most number one website in the world.
Because. Like, because the offer is just so ridiculously good. And I almost kind of feel that way. Like it again. Like I'm, more of reminded like to think of in terms of what you would have to do to get over it.
Like I put it back on what is the problem that's being solved, what is the thing that you're doing and everybody has maybe a different pill, I suppose. Like, whatever. The thing is that that's for them, for me.
If you were asking me what my true pain point would be, it's different. I mean, within this context, maybe something gets very... It's a hard question for me to answer. It's hard for me to come up with a product for a problem that I don't even know if I'm experiencing at the moment.
That's not to say that for somebody else's different circumstances, it could be very different if I don't have that context. If somebody else, for example, has a huge knowledge base of all this information, it's a big mess, and he can't go through it. He has all this paperwork, and everybody's misaligned.
That's a different headache. That might be the guy who wants maybe you have the pill for him, and then you're going to have... Then he's going to really want to work with you because he sees you as having the solution.
But for me, right now, I have to use my imagination to put myself in those shoes. So it's hard for me to answer that question. I have to imagine things that are true about myself that are not true right now.
So yeah, just my two cents.

**Ellie Rofe | 25:36**
I probably can give a more specific pain point answer in terms of... As I don't have the same vast written body or transcribed body of knowledge, so I don't consider myself in that category.
But in terms of the unwritten knowledge in my brain and the frustrations I have with AI, I would want to feel like it can do something for me that Claude projects can't do. As and ChatGPT and various prompting systems and other things that I set up...
So, I'm relatively advanced in terms of prompting AI in terms of how I use it across multiple different systems. It comes back to the same problem I was trying to solve with Google, to be honest, which is the context management.
Every time I use AI, I have to find context, put it into that. You know, it can never quite keep up with the knowledge I need to give me good answers. So you're correcting it all the time. You're having to paste in stuff and find information that's scattered to the breeze in a document here and this project there and that answer from AI, by the way, which is like one of the other things... Huge amounts of information overload coming out of discussions you have with AI even.
So for me, if you say... You might need a couple of guinea pigs early on. But if you're saying AI is really good, you're a power user, you know how to get the most out of it. But there are things that are just exceptionally frustrating eating there.
It never quite knows your business in the way it's always slightly out of date on your business. So when you're discussing strategy with it, maybe don't talk about content creation because that's what everyone's trying to solve.
Maybe it's strategy and brainstorming and knowledge. Like you said, the people coming to you want one of them wants to know what the unknown unknowns are, right? He wants to know what he doesn't know how to look for better ideas.
If that's your kind of user, then saying how you get all the right context into AI or the right information so that it can actually be of use to you. You spend more time learning from yourself than you do correcting the AI like that. That seems to me like a really interesting
unlock feature. I think that's... I totally agree with what Robert is saying in terms of if you have a problem that you can massively unlock, then it's ideal. But you are dealing with an early adopter market.
Early adopters are curious, experimental, and more intrigued to try things out and see what's possible rather than just fix problems. A combination of both. I would says.

**Ray | 28:53**
Li, can I get you to expand a little bit more on what you perceive to be the profile of someone who's more on the left-hand side of the timeline? Early adopter, visionary. Because I was thinking about what you were saying, and I was thinking about some more personality characters for those folks as well.
I'm glad to add on to that, but I want to start maybe a little bit with... All right, let's imagine who this person is. Because I think the more bones we put on, the more opportunity Demetris has to have something that's going to fit them just a little bit better.

**Ellie Rofe | 29:25**
Yeah. So... And Dimitris and I have talked about this a little bit already because it is a fine market in the really early adopters who have lots of money, who are big names, will have already spent lots and lots of money building their own products or their own things in AI, like we mentioned. People like Daniel Priestley or Alex Hormosi or whatever, they're going to have jumped on this as soon as it came out because they spot the opportunity. There is a layer of consultancy where people are building an audience, and they might have five to 10,000 people in their audience. They may have some systems in place. They've used AI, they've got a REA to help them with AI, they've got someone to give them generic AI solutions, they've got a custom GPT they are curious about. They are problem-solving individuals. They want to push at the boundaries of what's possible. Both in terms of their own curiosity but in terms of what it can bring to their business.
I think that's the layer that Dimitris is looking at too early. They don't have the money, and they don't necessarily have the content to put into it to really train it well enough to supply and furnish the information. Too late.
They've probably already jumped on it and found a solution that they might be happy with until this is proven by other people. They're not going to jump from their solution, but as this gets proven, then they might be ready to jump.
So I think you're looking at people who have experimented, who've either done their own experimentation or worked with people who are doing slightly more basic AI work in things like GPTs, projects, or dumping a load of information into digital twin software which just dumps it into a vector database
and doesn't really do much else with it. They're getting low-rent responses. They're not getting the detail they want. That's who I'm thinking about. What were you thinking about, Ray?

**Ray | 31:38**
I was thinking about how early adopters are often quite impatient. They flit from one idea to another to be, you know, solving their problems. They have an intuition that there's this something over here.
But their willingness to, like, really dig into and study is often not that great. The people who are willing to invest more time tend to people who look more like the majority. They have a deep problem. They have confidence this thing is going to solve their problem. They're leaning into it. Whereas early adopters are looking for.
All right, I'm looking to validate my idea sooner. You know, and the and this is one of the reasons why sort of the tripart thing you're talking about can be, I think, more attractive. Early adapters usually have an idea of how the signal is going to solve the problem.
So, like, often we have these conversations like, but what do they really want? What's their underlying business need? They know what their business need is. I think the way I described it to you, Demetris, was that they are chickens who dress up like foxes, right?
Because they are. They're. They're. They're picking up more of the tech and the understanding on their own because of their general belief. There's nobody out there who could just do it for them because they see themselves as being on the edge as a result, as you might think about chicken drips as a fox looking like a ridiculous figure. They're weird. They're often treated as ridiculous figures among their peers, right?
So they tend to be a little ostracized. They're not considered to be the center of gravity. It's one of the reasons why people bag an early adopter and think they validate their product, and then they go to more people, and they're like, "Yeah, everybody."
Because the early adapters are actually not good signals for much later parts of the market, they're good signals for the adjacent parts of the market. You sort of move your way through the timeline.
It's why eventually you get to a chasm problem. Which is what Jeffrey Moor talks about in the same book. But that idea of like, "Okay, what can you do? That's fast, right?"
That's part of what you're talking about a fixed investment, which means that they've got money to throw at it, but now they know how much money they're going to throw at it. I like that aspect of it.
I think that's smart. But they want to see what they want to see in a pretty short period of time, right? So you're... The idea of how you provide them ten times value is to be somewhat based on what they want out of it.
It won't look like what an eventual mid-market client goes want out of it. So the way that you need to solve the problem will be different for those folks probably can be more a little more... I think that's what we... That's probably fine, but because you're in it with them and they're like, "Finally, someone who understands me."
Then you're able to fit in with them, and that will eventually lead to more willingness to pay. And then what you're looking for is what is that first experience of sending that signal, right? That they're able to see hope, right? Yes, you get this thing. Now, of course, that requires having an idea of what they're looking for and being able to then deliver in that short time frame because that is then using their experimentation budget, right? Smartly.
But that's what I meant by ICP, right? Thinking about what that segment looks like. One of the things I really took away from Morrie's book is how weird is a big determinant of those folks, how they are unpopular among their peers, how they're like people you go to a conference and they're the ones who might get a speaking slot because they're saying weird things but are not necessarily the life of the party.
You know, they're not sort of centring gravity with everyone else. So you're looking for what's what's on that edge. One of the reasons I actually think that your meetups are great because your meetups create an opportunity for more people like that to show up.
Each of your meetups had a really eclectic set of people show up, to be sure, but then the opportunity for chickens to show up who look like foxes, and you're not going to walk into a room full of them because they see themselves estranged, right?
So you're looking for who when you walk into the room, where is the wallflower, right? That's going to be the person who's much more likely to be your... In fact, they're probably not wallflowerish, but they're as they walk through, people are moving away from them because they don't want to have the same conversation with the damn knowledge crafts we were having last time they had a conversation with them because it gives buttoning people, or she and the... All of this is like the kind of thing I imagine looking for right in the persona.
Which then leads to the kinds of comments that I thought particularly Li was making very cogently right about what an offer for them can look like and then drives them to more easily get immediate value.
Because they got immediate value, built trust, at least for the next engagement, right? Don't leave anything you want to deliver super huge value for them away, right? Then be at... Then have them come back. Wait. Can we do a little bit more? Yes.
Then can we do even more? That allows you to move from the idea of a "Hey, I've got this idea for a thing that we can do fixed cost that we were sharing the risk." You're putting in some money, and I'm taking care of the overage, right?
Then, well, here's another way that we can do it even better, right? You're doing it collaboratively. So you're not trying to make the MCP that's a simple drop-in for them, and they're just going to use it, and then you get data. In fact, if anything, you want to make sure it's private for them.
I think that'll probably be an important thing because they're afraid of being called out as being weird, but the surreal... But the idea of what they can get for an hour... What can they get for a week?
Then, how does that stage into them being able to really have their dreams come true? That's one of the reasons why having the graph is so cool. Now they have a knowledge graph, they know that intuition is knowledge graphs are good. Great, let's have one for you.
So no matter what else happens, you walk away with this thing. It's something I like about that. There's an artifact to it, right? Then what's the opportunity for you to be learning from that and be building that up? I wonder how much this is about gaining more data collection, right?
How much getting to... I don't know, start using Krisp or something, right? Puts them in a position... There's a whole lot more data, right? So you can be starting with a knowledge graph based on emails and then set them up with Krisp, and then you're coming back to the meetings a week later because they'll have collected something. I don't know what all that looks like, right? I do like the "Hey, what can we do right now?" One hour at the end of the hour, you have something super, then anything after that you're building on top of. Is what feels like the kind of thing that excites an early adopter.

**Ellie Rofe | 38:33**
I think there's a slight difference between an early adopter in business and an early adopter of business ideas as well. They're not that they're exclusive, mutually exclusive.
But there are some people who are very boring and ordinary, whose business really depends on managing an awful lot of... I'm one of the examples I'm thinking of is a partnership. Two women I know who run effectively a kind of... So OEM is a thing that spun out of lots of digital businesses online business manager.
They are people who help. They're a bit like a chief operations officer for a digital lifestyle business. They might do marketing, they might do running webinars for people. There's all sorts of stuff.
I know these women who are very average in terms of their life and everything, but they leapt on AI. I mean, really hoovered it up. And every new example they hoovered up. One of them was the one that pointed me towards a GPT that was being charged at $1,500 just to access the GPT, which was sub-marketing manager thing.
They tested it. They tested a $1,500 GPT because they're so interested in what is potential, because each of their clients is paying them $8,000 to $10,000 a month to manage their information, to push them along.
If there are ways in which even the boring layer on those sorts of business early adopters, the people who have a real interest, I'm interested. I've been trying to use AI to make things better in my business, to gain ground, to make it easier to scale to do those things. They're possibly a bit harder to reach. I don't know, but I think there's like. I agree with Ray. There's a really there's the weird, and then there's like, the deeply boring. The people who have, like, deep functional need.
I mean, they were they weren't boring at all, but their work wasn't like, cutting edge.

**Robert | 40:41**
The deeply bores, the boring runs deep.

**Ellie Rofe | 40:49**
Sorry. I know that's sort of like that. That's probably not very helpful cause it's a completely different avenue.

**Robert | 41:01**
I was just sorry, yeah, you were going to say something. Go ahead.

**dimitris@3nuggets.io | 41:06**
No, please, come on, share your thoughts.

**Robert | 41:09**
I mean, I was. I was just going to say that. As a. Maybe. Just as a bit of perspective that. I think, as you know, I think it's a good idea to try to build, like an ecosystem of stuff, I guess, which is what I try to do, like to try to create things that come through from me.
And those are kind of things that they do take, time, but they really come through just by the more that they interact with the market and the more that they have that exposure to the people who might or might not find them useful, then the more that they mature and become and then eventually do become useful.
And I would say that, like, it's not always about that as well. I think, like, for example, I'm sitting on the phone with a client, and for all the tools that I make and everything. I mean, it's. There are times where I'm just sitting there for, like, an hour and a half, and he's just wants someone listen to his day.
Like, you know, like he wants want someone. And I'm helping him with, like, something that might actually save him, like, two, three days, but doesn't look, it's not something that I can define as like.
Like, I'm gonna go do this big thing. I'm going to just sit there and I'm going to tell him what to click on and I'm going to motivate him to work because I'm good at motivating somebody to work. I can drag him through and I can... So what is that worth?
I'm not sure if I can. That's not something I can open up with and be like, "Hey, we're going to spend a month, and I'm going to tell you what to click on."
You're going to tell me about your day, and believe it or not, you're going to really enjoy it but it's hard that it's something that just happens like... Even today, for example, I'm doing something that if I were to write it down on a piece of paper, it doesn't sound like a very big deal.
But what am I doing? I'm going. I'm setting up an AI marketplace with the Claude code plugin. If I write that on paper, not a big deal, but what does that mean to him? It means that his team is aligned.
The stuff that I'm putting down there is that he trusts it because it came from me and he knows that I'm using those same things and I've battle-tested them and so on. So again, you put it down on paper, it doesn't sound like a big deal and sounds like a weird way maybe to spend an hour and a half but he... That's what he wanted.
That's what you know... It's something that I couldn't even have predicted. The reason why he wants to work with me, I think, is just because I continue to keep bringing more stuff like that. I'm a little bit more ahead of him, not just a little bit. I am considerably more ahead, but that's what my job is and the same thing... I've received that feedback from other people as well where the reason they want to work with me is because I keep up with stuff.
I'll bring up something that is an edge for them in this market, right? Like, they're not so much like the they're grounded, they want grounded solutions. So I wouldn't call them early adopters, really. They're more like people who they're buying in because they see that I can I'm offering them things that work today. They can use it.
And I just and I mentioned these things because I think a lot of that applies probably to the services that you're offering. I would imagine. I think that, like, once you start getting into conversations with people, that the ways that you're helping them and the ways you're helping them streamline, like Ray said, it could be something that's like it's hard to write down and say, like, well, my service is that I'm gonna help you turn on Krisp, I'm gonna help you start tracking your stuff.
And by what? What? Like, you know, it did. But as it actually happens, as the days go by and as the meetings go by, you are actually, you know, removing pebbles from their shoe. Which? Or. Or. Or telling them things that might have taken them.
Maybe they would have taken them years to figure that out or whatever, but it's. But it's different from them experiencing it and, you know, and how it lands on them in the actual experience, I would say.
And that's why it's something that might only be possible to see once it actually interacts with said person. Right? And like, once and then you see what you can help them with, what you can't help them with, and so on.
So, yeah, I would just say that, like, we're just talking about the sharpest point of the spear. But like, when it comes to the actual engagement, everything that you do, like you as a person, are it's. You can help them in so many different ways that you know, it might not be about trying to define exactly what it's going to be because that might be hard.

**Ray | 46:04**
I think I appreciate what Robert is saying. I think part of this is not trying to solve the end, right? Like when we begin with the end in mind, I think that's an important principle.
It's like what's the value you want for the client? But the way that we deliver it has a lot of ways between here and there. I think this offer is not so much about the way it ends. It's about the way it can start.
Right? If someone has an intuition, the knowledge graph will be really good. If someone has a worry, I don't know how to build this darn thing. This seems really complicated. Your core offer is you're going to take this complicated thing, and in an hour, they're going to have one, right? They're not going to have one they're going to use for all time. They're not going to have their last one. They're going to have their first one.
If what you're offering is a relatively fixed investment on their part in terms of time and money, their time, the elapsed time, and their outlay. I think those three things lie to derisk, but that's what you know.
Then the question is, how many people want that? But it doesn't need to be a lot for it to start turning things. That's where Ellie's comments... I encourage you to go back over this. Who are those people? What is that value they're looking for upfront? How will they perceive it to be a ten x value right up front there? Ten x not like a million x, right? A few hundred bucks, it turns it into a few thousand dollars of value.
From their point of view, it can be quite remarkable.

**Robert | 48:03**
I wanted to say, by the way, sorry, just again from my client experience that a way that they were able to connect the dots for that ten x value was just the fact that because I'm showing them techniques that are allowing them to bring more stuff in house. Means that they have they don't have to spend as much on, traditional developers. They don't have to spend as much on like, external software, stuff like that anyway.
So I'm just saying that like they were doing the math for me at some point. So. And I think. And you're in a similar space. Like we're all. We are working with very similar technology.

**Ellie Rofe | 48:39**
You could just once a month in your meetups, just say, "This is for consultants who are really frustrated with AI, who have pushed it to the end of what it can do. We're going to show you how to take it to the next level." You haven't got to the end of AI. There's this whole new level. You think you've done the big boss. You haven't.
Just test the waters, just fish and see because you put up an event like that and make it explicitly for consultants who are trying to work with AI and how to manage their knowledge and context and maybe try and experiment with phrases like context engineering and see who's heard of it. They're going to be people who are fishing around for answers and just see who turns up.
Because if you show them in that hour as a group what the possibility is with a knowledge graph, then I'm sure an awful lot of people would jump on and go, "Well, what's the next step?" For me personally, I've got ideas of how I can use this because I know where my frustrations have been with AI.

**Ray | 49:57**
And I appreciate we've only got five minutes left in the meeting, partially because I started a few minutes lates. How can we put this remaining time to maximum use? For you like I you've got a you've got some ideas for me is from Robert, some so from Ellie.
And I appreciate all this stuff goes in the mix. Sometimes it's like, wait, I'm looking for focusing and then goes out like this, right? So the best, which hopefully, you know brings inspiration, which not for nothing is a big thing you can bring to the client is your energy, your confidence, your joy in this, right?
Because they're like, this looks like so much work. And if you're doing the whole thing with a smile, there's a lot. There's serious value in that part, too. But the. But like, you know, how can we help you be able to bring this in so that you can be making that kind of offer? Or are you in a position, you know, to be making this kind of offer in, say, the coming week?
You know, like a context in which you can be starting to try this set?

**dimitris@3nuggets.io | 50:59**
It's another question I wanted to bring. It's a very short one. What would be a reasonable price to be paid for something like I described and something we discussed today? To be paid for a consultant who is an absolute newbie.
Because I'm not the experienced and I'm not the guru in the market, definitely, and I don't present myself like that in this position. So it's going to be a price for the prospects' experimentation.

**Robert | 51:37**
I don't know about framing yourself that way. I don't know about that because why are you a newbie? You're posting about this stuff every single week. You're thinking about this stuff more than anybody else that I personally know. I don't know. What makes you new?
If someone were to ask me, "Hey, who's new?" I'm not thinking of Demetris, who posts about it every week. Who's been talking about it every week? Who I spoke with on the phone with it last week. I don't know.
To me, I don't feel like we're talking about a new person.

**dimitris@3nuggets.io | 52:15**
I'm quite new because of the time and because of. I'm still learning things, so I don't feel quite confident to answer any kind of everybody's questions only.

**Robert | 52:25**
But the stuff's only been like, out. Who's then how long has this stuff even been out for? Like, you know, like, it's. I again, like, I'm not saying about time. I'm talking more about. I'm not talking about like, a length of time. I'm just talking about. I'm talking about the intensity. More like how much you think about this stuff and how much you're working on this stuff.
Right? Like so that has nothing to do with time. Like MCP only came out like I only started getting interested in March. I probably put in three times the amount of time that like, that most people would even be willing to do.
And so even though the amount of time was equal, maybe for the next person. But, you know, I think goes for you. You're putting in more energy, you're putting more time to thinking about these things, which translates into your understanding more about it.

**dimitris@3nuggets.io | 53:15**
Appreciate it.

**Robert | 53:16**
Well, I mean, I think it's true. Like, I mean, I can't imagine any other way. Like, it's if it's not true for you, then it's not true for me, right? Like, and so, you know, I'm. Yeah, I'm just trying to tell you what I see.

**Ray | 53:34**
If I might... One, Robert's right. There is neither public benefit nor private benefit for you to be talking yourself down in terms of your expertise. You are right that you are a student of the market, and that there is more for you to learn, and that there are people out there who know more than you do. This will be true for your entire life.
I think it's fair to say that you're as the market will reward you for your mastery, and you will apply the principles of study, selling, and shipping right to build both your own internal mastery as well as the market received mastery as well as to ship the delivered mastery.
You will be better at this in three days than you are today. And then again in 80 days. Just keeping going on out from there. But the fact that you're the worst version of this today...
I don't think that deserves at all. Talking yourself down. You are way at the sharp end of the stick of people who are working on this. This will be proven out by the number of people who are coming to your meetings right to talk about this because they're desperate to talk about it, and you're able to convene them. Now, let's separate that from the question you were asking, which is about pricing.
So here's my thinking on the pricing. Underprice it and then raise your prices. AR client gets X. You don't need to make a whole ceremony out of it, right? What is it? I'm just looking for my first client. My first client's going to be, I don't know, 99 euros, right? Radically underprice it, get the gig, blow it, blow the doors off it.
Second one, 199 euros. There's something that says, "Once you've priced it, you have to stay within a band, just keep on raising your prices." This is something that you and I talked about very early on in our process, right? That your pricing does not need to be stable, indeed should not be stable because your practice is not stable, right?
So sauce for the goose is sauce for the gander. Because it applies, like increasing your rate, it applies the way that you can think about a discount for starting, right? You can say, "Well, I can start too low."
Then maybe for your first few clients, you've left a total of 300-500 euros on the table. But that so that you can be climbing that curve, right? You're better off doing that than struggling to get your first client at 300 euros or something and then having trouble getting off that mark, right? What I want to do is get it easy. Get the first one easy, get the second one easy, get the third one.
So if you think about the pricing... I don't really know, but pricing... This looks like it would be a relatively quick thing to do. I would start with that and then do the next one and then do the next one and have... No, but you told me yesterday it would be a hundred.
Yeah, sure, I sold my hundreds, now it's 200, and if their response is that's ridiculous, I'm not buying that. Well, that tells you something about the market, right? But I think what you'll find is that you're probably pretty rapidly underpriced relative to value until you get to the first few.
Because your expertise in this is going to climb. You're going to be better at this and deliver even more value as you move out, right? The ROI is just keep on shifting. You're going to be continually underpriced.
It's going to take more steps as measured new clients for you to actually be catching up to price value. By the time we're having that conversation where you're at a different level of the practice.
So I would be unafraid of underpricing, but they have to pay something. Yeah, if they're not paying or if they... I don't mean if they paid me just one year out. No. That could... They not have to take that seriously either, right? You want them to have skin in the game.
Then make it a crazy, super easy decision for them. Then with your second clients because you had success with the first one. Third client because it's the... Etc. So that's my thinking on the pricing front.
So rather than trying to solve the pricing and what should my first ten clients look like? I would just ask, "What does it take for you to get your first one?" And then just keep on knocking that price up. And enjoy that feeling. And then. And then you've just until you discover right where the market equilibrium is. So that's my purchase pricing overall. And the. And I think the kind of thing that will, like, allow you to be shipping more things sooner rather than, like, banging on a lot more dirt to find someone who's willing to pay the X price. Alie what do you think about that?

**Ellie Rofe | 58:21**
Yes, I think the other part of the engine is social proof. So the more you get people saying this is great and the more you can say people told me this is great, the more likely people are to pay for it.
So you discount to get social proof, testimonials, case studies, video of you working with someone, whatever it might be, examples of what you've done, it just all builds to the proof that allows you to charge more and more.

**dimitris@3nuggets.io | 58:55**
Great.

**Ray | 58:58**
Thank you so much. Those are great questions. Idris... Okay, anything else we can... Any other questions for the very end of the hour before we sign off here today?

**dimitris@3nuggets.io | 59:11**
It was a very grateful conversation, guys. I'm very thankful for that.

**Ray | 59:17**
Super, right?

**Ellie Rofe | 59:18**
Thank.

**Ray | 59:18**
Let's see what we can do to make this happen next week. Take care, y'all.

**dimitris@3nuggets.io | 59:22**
Take care by.

