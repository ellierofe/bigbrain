# State Change Mastermind - Feb, 24

# Transcript
**Robert | 00:03**
To be thinking.

**rhdeck | 00:04**
Yeah, I mean, it's worth I mean, like Lovables out of Sweden, right?

**Robert | 00:08**
Yeah, right. I mean.

**rhdeck | 00:11**
Those northern countries actually produced quite a lot of, you know, significant tech. I mean, Nokia, the phone company that, you know, had its moment, that's a finish company. I mean, yeah, there there's a bit of in Boston. 
And then you go out to, like, you know, Silicon Valley, where the weather is always gorgeous and they're doing really well, so you'd think they would want to be outside all the time, but no, they're so. 
But that geographic deter we were just talking about gred, diamonds, gunstorm and steel. And use that to explain, you know, relative productivity levels and the, and like into the you know, everything was going so well in the Descriptions until we get Silicon Valley. [Laughter].

**Robert | 00:57**
Yeah, it'll makes sense, and I have to go back to the drawing board.

**rhdeck | 01:01**
It's working. Yeah, and there's a broader lesson that simple explanations are almost ever right.

**Robert | 01:07**
Yep, analogies tend to fall apart, I suppose. Metaphors.

**rhdeck | 01:11**
Analogies are like. Move on.

**Robert | 01:15**
Let's get into that.

**rhdeck | 01:17**
Okay, well, let let's go around the horn here. Elliot, can we start with you, ma'am? Was true today. It was true week ago.

**Ellie Rofe | 01:25**
What is true I am I'm on the cusp of I mean my word the process involved but basically on the cusp of signing the political party work, which is really interesting. I've had a couple of queries. Sent the portfolio off. 
So I got a meeting on the large finance house event strategy stuff, which is all moving along quite nicely. And I spent. I mean, I'm sure the three of you would have found it hilarious to watch the level of incompetence and confusion, but I spent a day getting open cla set up and, sorting my life out a bit, and it. 
That's really interesting. That's opened up as I'm sure it does for everyone. A world of possibility. So?

**Demitris | 02:19**
Yeah.

**rhdeck | 02:20**
All different. Yeah, it is. It feels like I'm spending much time tankering with all this tech stuff, but it's and then you start using it's like, wow, hey, this can really do some stuff.

**Ellie Rofe | 02:31**
Yeah, exactly.

**rhdeck | 02:33**
Super cool. Adris. I was true. Today was Cubco.

**Demitris | 02:44**
I'm doing some progress into my work for the content and try to make it more, you know, more engaging. So. And I'm thinking how to create a lead magnets so people can join the conversations, the public conversations. 
And this week I'm going to run two events, one tomorrow and the other one on Friday. More technical about data scraping. It's going to be created right after the session today. And, yeah, I'm. I'm functional how to make convert conversions through the linging.

**rhdeck | 03:25**
Yep, perfect there. And Robert, today is your day sir. So, I mean, what's what was true today that wasn't true week ago? And how can this group be of maximum service to you to have an even bear week?

**Robert | 03:39**
Sure, kind. That's cute.

**Ellie Rofe | 03:44**
Sorry, it's din time.

**Robert | 03:46**
My dogs staring at me from the side. So was true today. Wasn't true week ago. It's a hard question to answer always, but, I find it's true today. It wasn't true a week ago. Probably. I'm doing work for more work for Mark. I'm doing more calls. 
I have a lot of people who are like, I think, you know, like FOMO, I suppose like they want to work with me and like, they're just very comfortable because I'm always. I'm always there and then until I'm not. 
But. But. And I kind of feel that feeling now where I just have, like, a few people who are very much enjoying my presence. And I think if they all knew that the other existed, that there would they would all actually have an issue. 
But in a way because they don't. I don't think any of them really realize how much the other group wants to work with me, and I'm just kind of juggling everybody versus, like, I think a more normal person would have already fallen apart by now, but, like, I'm kind of but I'm juggling all of these things, and so, like, you know, it's just crazy. It just never ends. 
Like, you know, I'm just creating new problems for myself. As basically, put it this way, because, like, it's not like I'm not achieving what I want. I'm achieving it. And it turns out I'm a achieving all the problems that come with it too. 
So, like in the sense of, okay, you make a SaaS tool and somebody great you achieve that well, great. Now you've made this person depend on that tool. And so any moment doesn't work. It means he's gonna reach out to you on your Saturday, on your Sunday, like, you know, and so that's my life is becoming like these new issues, they're like they're not like problems that are like the old problems are problems that exist because of new things. 
Because. And so, yeah, I guess, like, trying to become. I think not trying to. I'm becoming a little bit numb in certain ways to even just certain types of communications because I just know that I just can't react to everything. 
And like, I have to make my judgment calls with certain things, like, for example, like, I have a client. It's all between us. It's between the four of us anyway, so, like, I'll just share your names. 
Like, so and this is where it gets juice. So Scott talking about Scott. So he but anyways, he, but you know, he'll like, hell, like, text me on the weekend and say the MCP's not working and give them troubleshooting. 
It's she just says it's not working, it's broken, it's down. I need your help. Like, you imagine, like, waking up on a Sunday, and that's like the text that you see from somebody that's like, hey, where are you? I need your help. 
And I was like, all right, you know, getting on the phone with him, helping him. But like it, but he doesn't make any effort. I know it's his fault. Like, my point is that, like, I'm getting people throwing stuff over, trying to throw stuff over the fence to me this way. 
And it's just like, you know, starts to drive you a little bit crazy, I suppose. A little bit. But you know what? Turns out then like a day later, I got it magically started working on its own again. I didn't even touch it. Turns out it works again, a miracle. 
So, I mean, like but that's what I mean, like, I knew that, but I have and even though I explain that, I say I still have to spend hours proving that, right? Because otherwise, until it's until it proves itself like it's not something. I can go into his computer and say, hey, here's what your firewall settings look like, and this is what's wrong. 
It's like, because. And then on the other side, you know what I felt like, imagine just whatever the AI is sitting on the other side of that conversation and it's just getting thrown. Stuff is just like. Fix it. I don't care. Fix it. 
Like, you know, you're just getting that type of messaging where and then you say well, you know, technically this is as a good AI would this is impossible because the network connection could not possibly it's not even making it here. 
I have looked at the error logs and then. And on the other side again, this is the part that annoys me that just on the other side, all you get is like, bare minimum in terms of problem solving, right? 
Like you say, to do this, what do you get back? Something very cryptic, like a screenshot of, like a broken of a broken web page or something. You're like, looking at it, you're like, the hell am I supposed to do with this? 
And then. And then again, like I said, if you like, you don't hear anything. I the whole time of stress. I'm thinking about Mark. I'm thinking about all this shit and then I'll get, like, a random text message, like it's working again. I'm like, okay, I guess. I guess I can go to sleep now. 
Like so anyways, all of the stuff, you know, this combined with like that I have mbounds and everything, so I'm pro now I see how I live on a mountain, Ray. Like I'm just going to think I have to go to a mountain two or something somewhere with like well, it was hard to contact me, but anyways, that's what that that's what it's like on nowadays so far at least until I figure out something, but that's was true today that was not true we ago. 
Okay.

**rhdeck | 09:24**
How come this group be of service to you?

**Robert | 09:30**
That's a good question. Just listen to me, bitch, for 46 more minutes. And, I don't know. I think, you know, it would be cool, maybe just like, if. I mean, for me, I first of all, like, the one thing I didn't mention, like I probably my hope behind all of this is to try to remove all of, like, as much busy work as I can and to try to move the stuff over to the technology, and I find it to be just very. 
That's like my driving force. If I didn't love it that much, I would like. I mean, I really hate being cajoled by people. Like, I hate being chased down like it. It drives me nuts. Like, I don't know, I'm allergic to it seems. 
But I'm trying to fight against this so like and a lot of so the. But I am willing to enter this business of it because I like building stuff so much and inventing things. So at the same time, like, I'm trying to figure out, like, how do you make the most of this open cloth thing? 
And I guess because we're all in the same space of where this technology seems to be like the same like through line of you know, it's is relevant to what we're all doing. I feel I'm curious about what is that through line and if there's a way that I can almost draw it out or just to understand your perspectives when it comes to that technology because it's still it's something that I don't have a perspective on yet in terms of like where has the value moved. 
I think maybe that's my main. My main. Question to myself even nowadays. Like, you know, where is the. It's not that good, is it? Like, I mean, I'm using it too. I have the Mac mini set up, and it's like it's not like it's doing any real work. 
It's doing work, but it's like pulling teeth a lot of the time if you want to get it to do. I mean, and there's plenty of problems with it. I want to just, you know, I feel the. I feel like there's an opportunity there, but, I don't think that there's enough time in a day for me to get to like, all people's experiences with it. 
So I'm just wondering if there's anything that like from your perspectives in the market that then I could take that because that's something that directly feeds into just like my most core efforts right now, which is try to, you know, control that technology more and then just be able to offload more to it, which would then reduce my stress. 
And then which would allow me to focus more on the other things and less of the busy work that seems very. I'm pretty good with systems, but it seems like it's it. It gets pretty convoluted pretty quickly when I start to imagine all the different paths and systems that are required in order to control something like that. 
So I've been making progress with it. I guess my question would just be like first question maybe would just be what are you doing with OPENCTH? As much as that's say, yeah, it's a departure from everything else. I kind of said, but it I feel like it, but it does kind of point towards back to where I'm trying to get to.

**rhdeck | 12:53**
Okay, that's a reasonable question, so let me let's turn that to the group. Ellie, what do you do? I mean, and, do you are you currently using open C or anything like it? Right now.

**Demitris | 13:07**
I'm. I'm planning to work on a project this week, so I'm going to have a hands on experience on that. We're talking for open clow, right?

**rhdeck | 13:19**
Yeah, open clock, that's right.

**Robert | 13:20**
Open.

**Demitris | 13:20**
Clock, yeah.

**rhdeck | 13:21**
That's it the autonomous thing. Okay, well, alie you just went through your fire. Your fire and rain to get things set up. What do you, w what did you kick off with it? What do you do with it?

**Ellie Rofe | 13:34**
I'm mostly set still, like establishing the scene, as it were. So there's, you know, making sure it's got the right info from me, adding stuff to the workspace, whatever. But the first thing I set up based on a conversation you and I had, Ray, was, something to. I hate email. 
Right? And similar to you, I'm sure, Robert, there is an element of me where I am. If anything falls off the radar. It's communication. Like that's the first thing to fall off the edge of the table as it gets more and more full. Which is ironic because I love people and I love communication, but it's just like the email, the text, the DMs, you know, there. 
So I decided rather than just managing my email for me, I wanted it to do something so I never had to go into email, never had to get distracted by loads and loads of noise in there. So I've got it doing a scan of my inbox, my clients and my potential partners folders for anything I need to follow up on. 
And I've got it doing a scan of newsletters based on what I'm researching at the moment in the market to float particular newsletters or anything interesting to me. So that's sort of like. And then in my. 
So everything, admin gets already ruled into like an admin folder receipts or whatever, and then it checks that once a week to make sure that there's no this card has expired and none of your services are going to work anymore. 
Kind of thing going on in there. So I have it doing some sort of functional stuff there, but I tried to structure as a like these are the things I needed to actually do. Then I have it starting to help me structure and work on research. 
So it takes stuff from the email and adds it into my notion task management system, which I then go through with my Accountability V every morning. So it's kind of just like helping process things in the background. 
So it's leaving processing memory for me. Then I've got it helping me build. Research in notion so doing searching, scraping, tagging, initial analysis of the quality of sources and things like that I can then work on afterwards.

**Robert | 16:16**
By the way? Can I just ask you, is it a chrome job or is it like that you request it like on Telegram or like, how are you communicating with itm?

**Ellie Rofe | 16:23**
So at the moment, I'm going between. I'm still trying to work out how I want to communicate with this. So I'm going between the gateway kind of command center and Telegram, I'm working with it.

**Robert | 16:37**
Okay, so and you ask it for, like, for example, you want something on notion. You just tell them like, hey, I want this thing on notion. 
And then. And then you just wait and it comes back. And then it. It does a good job in general.

**Ellie Rofe | 16:49**
I have to give it the database I DS like you have to do the admin of access. But then after that, it's doing a really good job. 
So what we've done, for example, is there is a note in notion that has the type of that is the word case study that has that is favored check and that is this like month's research project. So it will check newsletters against that topic for example and that will be Chrome.

**Robert | 17:22**
And how does it know to do that, I'm wondering?

**Ellie Rofe | 17:25**
Yeah.

**Robert | 17:26**
That's a cron job. Okay, so then that chron job tells us specifically, like, here's the instructions for you to go and to check this guard, you know, part of the database, and then you're gonna do this. XYZ.

**Ellie Rofe | 17:36**
Go into my newsletters email folder. Then I'm going to add. So I've put it up with different AIIS as well. Then I'll a research layer where I'll get it to use Grock to search X for stuff. 
So like, I'm. I'm trying to deploy different guys where they're really good.

**Robert | 17:51**
Yeah, how do you.

**Ellie Rofe | 17:53**
Like, if I've got a really huge window, I'm.

**Robert | 17:54**
So. I'm sorry. I'm sorry. Because I'm gonna keep kind of, like, digging a little bit because I'm curious about, like, how did you set up then that grock step with it better, okay, and like, sorry, go ahead.

**Ellie Rofe | 18:04**
I've set it up with a routing thing for the models. So use this model for generic tasks, use this model for thinking tasks, et cetera.

**rhdeck | 18:17**
I was only going to ask Valley, like, how was you said to do that? Do you do that through the convict screen or you just said like in your Telegram chat, hey, use this model for this and use this model for this?

**Ellie Rofe | 18:26**
Yeah, it.

**rhdeck | 18:27**
Yes. 
Okay. Yeah, the conversational configuration.

**Ellie Rofe | 18:30**
Yeah, exactly. I'm trying to use that as much as possible, partly because as soon as I end up delving into those things again, it's just a rabbit hole. Part because I'll then see other conflict things and go, I wonder what that is. I wonder what that is and get distracted from the job at hand. 
So I'm like, yeah, let's take any distraction away from me by me just going, this is what I need you to do. Na often do it.

**Robert | 18:55**
Well, I think that that's actually a very interesting point. Actually, before I just get into that quick question, are you running it on Digital Ocean or we're okay, so it doesn't have a browser.

**Ellie Rofe | 19:03**
Yes.

**Robert | 19:06**
It's not like it's able to, but it's still able to. I suppose like you've just connected all your API keys to it and it's just is doing all this stuff programmatically through the APIs.

**Ellie Rofe | 19:18**
Yeah. So? With Grock, for example, I haven't set this up. So it's going to be a test. But with Grock, for example, I'm like, that's going to be an API call, presumably. And I don't know how well it handles those across its research and accessing X and stuff like that, but I'm going to test that with it. 
If. If I need to give it browser access, I will. But I'm just not technologically smart enough to make sure if I give it my Mac mini that I'm not going to end up completely Destroying my Life. So I thought I'd just keep it restricted at the moment.

**Robert | 19:52**
Very interesting. So you then have it there and it's what about like, for example, email how what's the situation with the email with I'm trying to figure out where the you know, this is not like this is the last problem to solve. 
Like I don't think we've come to that point. So as much as Sam Altman dreams about that day. Like the last question he's ever had to answer. But, like, I. So I'm trying to figure out where this thing falls apart. Basically. 
And. And I think that it's kind of hard to say because there's actually a lot of situations where it holds itself to. It still holds itself together, but, it still doesn't feel like. At least to me when I'm using it still doesn't feel like. 
Well, I haven't. It doesn't feel like I've waved the magic wand yet. To put it that way, I suppose, like, it doesn't feel like I'm able to just say to it, hey, do this, is it's done, perfect, all of it. 
Like I and I'm not sure, like, again, maybe that's just like, it doesn't intentionally, you know, that's just the ideal. I suppose I'm trying to. It's extreme the way I'm trying to paint it that way. 
But that's the point. Just to try to paint like that, the really extreme ideal. And where do you feel the word falls apart? Have you felt it fall apart for you? Or like, do is it just. Is this it?

**Ellie Rofe | 21:31**
I mean, I haven't been using it long enough to really feel it fall apart. A lot of it has just been me. It's been more exploratory than me thinking, it's all going to be magic. 
I have to say. Like it? It's. I work in Microsoft Outlook because I have to have PowerPoint for the Pitch deck, so I can't use all the magical easy access G Mail stuff. Never bothered trying to automate anything without Outlook before and it was sorted in five minutes. That kind of thing for me is pretty like God did that saved me hours of faffing around. Have you looked at Microsoft's documentation? 
It is awful. So I'm like, great, I don't ever have to look at that again.

**rhdeck | 22:09**
Yeah.

**Ellie Rofe | 22:10**
But I think there's a I think part of the issue is that for me and I don't know how much this will resonate because it is from someone who's not technologically sound. 
So last week I was putting together my other half's website, and I spent hours working with Gemini on Antigravity trying to get it sorted. And then I worked out that I could just use a Figgma Tel template, use Claude code in, you know, Visual Studio and the two way relationship.

**Robert | 22:45**
Hey.

**Ellie Rofe | 22:46**
Absolutely. 
I mean, I blitz through it in less than a day. Once I realized that and I think maybe one of the things it needs to do is become the filter that tells you like one of the most powerful things for me is that it seems to have a better grasp of what tools to use for things of what the best process is. 
And it will go out and keep finding that. Whereas. Me. In. In this vast ocean of like thousands and thousands of Git repositories and tools and software pieces and everything, you can end up spending a day completely in the wrong place. 
And this iterates faster on those decisions. I think for me, as someone who isn't as technologically adept, that's really useful. But I mean, I haven't played it enough to work out exactly where it falls apart.

**Robert | 23:47**
Interesting, because it reminds me of, I think like what, Ray, what you were mentioning the other day, which was just the concept of, like, how image generator works. Ask for the image. Get back an image. 
Like not ask for an image and go and draw every pixel with it. And then to like and to be part of the whole construction of the image and to. And, you know, but like, the idea of like, hey, I want this. 
It's done like the next interaction with it is just like, you know, some type of confirmation and, maybe there's something there in terms of just like the I feel like that as you're saying like whatever it is the decision making, the black boxness of it, I think has a certain quality to it. 
Like. For example. Even. Like with. Mark something a project for Mark. And actually that entire project, the front end of at least I've developed it with the open claw with the Mac mini and it has it totally running on. Over there. 
And like, I'll have it going sometimes for like twelve hours or something. Like just doing something, like from the beginning of the day to the end of the day. And, I found that maybe. And this is the thing that. 
Like, I feel that maybe the. The thing that I started with. It just happened to be maybe the thing that it's a strength in some ways because of the fact of like I'm asking it to do something that requires it to have a browser open, to be able to test it and to see and to do QA essentially. 
So I started with that and it did an amazing job with it, an amazing job. Like, I was actually I was amazed. And then I asked to go check my emails, and I did a terrible job. It's, like, you know, because it's just checking the emails. It was trying to type into Google and whatever and like and it just didn't, you know, it doesn't do a great job. 
And then I'm sitting there and I'm thinking. I'm like, wow. What does this mean? Like, you know. So I have to build up all the like. Okay, fine. And then it seems like that I imagine like to do a lot of the things that I want to do. It doesn't need a browser, but for or it doesn't need actually the Macmeni for 95 maybe percent of things. It actually would be better maybe as like a switchboard of AUT of routes that are like, predetermined so that it can just. I imagine just like a whole pathway of routes where just like everything is switching on and off. 
And those are connections that can be made from a to B, you know, very easily, right? Like with logic and protections for all that stuff. But, however, that for what I'm doing with Mark is like, very economically meaningful. 
And I would just say that that's something that I've been trying to to understand more of, like where the value is and that. Because all I can say is that like what Mark like the project for him is very. Is one that if I didn't have the Mac Mini running with the Desktop up there, I would have had to spend so much time dealing with, like personally dogfoting it and personally testing it that it would have drove me insane. 
So anyways, I'm trying to figure it out too, basically, and I'm not sure where some of these. So this is helpful because showed me, like, about how you're using it. Thank you. I appreciate it.

**Ellie Rofe | 27:20**
Just a small thing you mentioned, like I ask for an image, get an image back. That's one thing I can't do with AI because imagery is one of my skills. So when I get an image back, I then take it into Photoshop, edit it, grade it, add a grain, a texture sort of. 
Because, you know, that's like where I look at it and go, no, this isn't quite what I wanted. And I want to be able to go, no, this pixel there, that pixel there. So maybe that's part of the thing, right? 
You know what you're doing. So when you're playing with code or something or it's not doing something properly or like, aha. Well, I would have done that much better. And now I need to do it myself.

**Robert | 28:02**
Fair. That's it's a very interesting point, actually. 
Yeah, no pick for that, actually. So just actually, I want to show just one thing I could before it jump to Demetrius because I think it just would be interesting to see. 
So I'm trying to control this Mac mini more and more like from here. So it's like I figure, well, what if I can see, you know, the screenshot of it at any time, right? Like a live feed of what it's doing. 
So this is actually it open right now. Like I can see. I can capture like a screenshot of it at any time. And so I'm starting to try to build up like the control between from here and there. So I would like if what if because I hated the guy that it comes with. 
And so like, what are all the skills, right? And then, like, okay, fine. So can I want to be able to control the skills from here too. Like, I'm trying to really strengthen the connection so like, I can, you know, can II want to edit this from here, like, so I can edit the scale and it will save over in the Mac mini automatically. 
And this is what I found to be very fascinating was just like, well, like this screenshot thing, for example. It just is. I mean, you can control the whole computer. Like if you were. If you told the AI. 
Like if that you want to control that computer. And you just. And you establish these routes where you can get these. You can just fire off commands to it. You can do anything with it. And just with, like, one click. 
So I found it to be really interesting, like, to see, like, you know, because there's a whole bunch of commands that are built into it. Like, let me pull out all the sessions that I have running with it and see them, and then I can see like, wow, some of them are huge, right? 
Like, it's this is not obvious to me. So anyways, I found this to just to show a little bit from the other side. And maybe this, you know, I'm showing this in case something stands out and someone's like, W hold on. That part's cool or whatever.

**Ellie Rofe | 29:53**
It's all right.

**Robert | 29:54**
But anyways, yeah, we'll see. And then, like, I'm trying to make, a bit of an interaction with this so, like, I can say, okay, I want to dispatch this. Okay, to who get to this person, who is this person. 
Okay, let's confirm this person is like this person Jordan, for example, and then I can. Well, let me brief me before my next meeting with Jordan or whatever. All of this different stuff, it is all the history I have with him and so on. 
And try to take this and then turn it back into like. Well, okay, then. If I want to send him an email, for example, how is it going to send an email? It's going to send it using the skill that's over here, which uses, you know, whichever one is for e mail. Basically. 
I have to go look for it now, but like, but that's a point. You know, at least so far, right? I've gone through like six versions of this since I started already. So.

**Ellie Rofe | 30:54**
I mean, you've created a wizard, a GenAI.

**Robert | 30:54**
Anyways. Yeah.

**Ellie Rofe | 30:57**
Do you know what someone said to me, actually, which I really found funny? They said, I said, when you first start using, like, the IDS, whatever, it's a bit like Fantasia, I think. 
I think maybe Ivan said this at once as well. Where you're just like, DA dah, and everything's happening. It's like. Whoo. And then you realize.

**Robert | 31:14**
With Mickey Mouse, the mobs like I'm going to be the.

**Ellie Rofe | 31:16**
Yeah. Then you realize that nothing really actually is. The magic is surface level, and there's all sorts of nonsense going on underneath. 
And they said they like. Like, they think of it like a GenAI or a leprechorn, where it's something that grants you wishes, but those wishes often have a sting in the tail. Like there's some kind of tricks that are to it. 
But II think that looks incredible.

**Robert | 31:39**
I want to be the richest man in the world, but then you're the only man in the world. There's nobody else on the planet.

**Ellie Rofe | 31:47**
What? You. Looks like magic to me.

**Robert | 31:51**
Thanks. I just. I'm trying to fight through. To where it makes its way. You know, out back into the you know, as output, which is why I have to fight very hard to. 
I mean, it's to your point that, like, it's very easy to kind of just like say, I'm making progress. And like, they're kind of more than ever nowadays because, you know, it's like you can feel like progress. 
But, that's the very hard part for me. And in some ways because I can't consider that to be really success until it makes all the way back out of the computer back to the reality where it turns the wheel for the business and like the distance between to cover that gap, I've exercised that muscle now to where I can cover it like. 
And I can do that, but it's not easy like definitely not easy to. And I think that's maybe where there's a lot of still that hasn't changed really in the market for all the technology, for all the things that have come out. 
It's make it more possible to build software easier than ever. I haven't seen a lot of useful software make its way. Like, I haven't seen this big influx of this big wave of like, whoa, look at all this great software. 
Like, it's just it. I see a lot of, you know, zero to one, but I don't see a lot of, you know, zero to ten. Like, I don't see them actually making. Making its way out into the world really at the same rate as it's being, you know, consummated.

**Ellie Rofe | 33:18**
Yeah, a huge amount of fragmentation and tools being created, but not software businessess.

**Robert | 33:24**
Yeah, sorry, anyways, I'm going off a bit table.

**rhdeck | 33:37**
Sorry. What are you looking for next? RO?

**Robert | 33:40**
Sorry, I apologize. I meant to say that, like, I want to pass it over to Demetrius, because, like, I just was, like letting it go around. So, Demetrius, my apologies. Would be very happy to hear about. 
Because I know you said you weren't working with it yet, but, like, tell me, like what? What do you see out there?

**Demitris | 34:04**
Basically, I'm investigating mostly on, how this tool works, how it makes decisions, find the information, and so on. Before I get into experiment, I do little more traditionally and I spend more time upfront so I have a better understanding what I'm doing. 
Because I know specifically, Claude can do things you may regret and will be quite late. That's why. Had the scarcity for not doing that. But anyway, what I found is the first thing is which are the options where we can use it remain secure, which is either through the open ocean sorry, the digital ocean or through a docker. 
And ran the Docker into our machine. And in that way, we packed it somehow so it doesn't affect the rest of the computer. And the other thing is that.

**Robert | 35:04**
Can I ask you a very quick question. What would it take for it to feel because you said that you were cautious because it didn't feel secure? What would if someone were to just what would it be? What does secure look like for you?

**Demitris | 35:19**
Yeah, so two things. The first thing is if I accidentally, publish something that shouldn't be, published. And what if I accidentally give it permissions to access something that it shouldn't have access? 
And you know, critical information like passwords, API keys and all of these things accessing other platforms been affected. So this is the main thing. And yeah, you know what when I talk with a prospect, the number one question I if it is about security, it's the number one. 
So I have to know how to answer this question and how to deal with this challenge. So for me, based on my experience, it was a critical thing to figure it out. It is.

**Robert | 36:25**
Because maybe.

**Demitris | 36:26**
Like.

**Robert | 36:27**
A lot of people are mentioning that same thing. And I don't fully know what the. I don't even know really how to imagine the ideal situation. Maybe that's what's what perplexes me a little bit. Like, I don't really fully understand. 
Like, I'm picturing it. I was like, okay. So if I want to control it, that just means I'll have my own routes. And then those routes will be in the skle document and in the skille document will be something I can control. 
And like, I just showed like, I know I can see the live feed of it and so on, but I don't know, I don't really know if that, if this is it, like if you know, if that's good enough or like, if that even is a good way to imagine it. 
But anyway, sorry. Yeah, but because it's something that is hard. Hard for me. A picture.

**Demitris | 37:15**
Yeah, basically, I had a request for data scraping. So a couple of months ago, I tried to solve it with the MCP server. The one we run with Ray. A mastermind session together doing it step by step and then ask Claude code to write the code to run exactly these steps. 
It's quite straightforward today after a couple of months. And I was thinking, okay, how could we use this Claude as a solution? And, if I go to present it to the client, the number one question will be for security, because they have to give emails and passwords to login into the platform on the user's behalf. 
And for example, a case study. I started experimenting, bringing questions and having answers. It was building something that can be like a LinkedIn advisor. So it should scrape LinkedIn multiple profiles, collect useful information, scrape my profile to get the engagement, feed it back, realize what's going on, what works, what it doesn't. Let's figure out what do we have to change and move on. 
So all of these actions will require e mail and password, so. And I'm really scared where this information will be saved. And what if this information will accidentally get published without me understanding it?

**Robert | 38:54**
I almost feel this is a very interesting thing because I almost. And like, I feel that, I don't even know. I think some about some of these problems anymore because it almost feels like the solution, for example, might end up being like something very simple and in the sense of like, here's okay, here's a keychain password manager that you just use. 
And then the I AI never knows what your passwords are because they're always like hashed and protected or just like, you know, that's it. Like it would just be mpx. Download this. This is your password manager. Now here is a skill done. 
Like is it possible that the solutions if the solutions all start to boil down to that we're just we're I guess I don't know where to build the product anymore.

**Demitris | 39:47**
It could be a solution. At least it's worth it to be tested.

**Robert | 39:51**
But I mean that like, if that's the case, then it might already be installed on my computer. Like, it might be something I'm already using likely, or, I don't know, I'm not sure. Like, it's an interesting point because, I just, I guess, yeah, I'm trying to figure out what to build. 
And now, okay, this is interesting because I don't want to be what would it almost feels like the value then is moving to just helping people get set up with this stuff more than anything. And it's almost, like coming back to, like, physical, like almost like being like a like I don't want to say like a. I'm gonna use analogy, but like. 
Like a plumber. Like, you know, he's gonna come and like, you know, do something physical. Shop with the Mac Mini, like, set it up in your house and like you get them. Like, it almost feels like this. 
Well, this has become more people based than and than anything. If everything is coming back to, like, to training and then showing how someone uses the Mac, is that where it all comes back to? I'm not really sure. I'm just speaking out loud here.

**Ellie Rofe | 41:03**
It's a good question. The market is shifting radically. There's a lot more IC consultants who are not it consultants who are building tools with their stuff, but they're building tools.

**Robert | 41:06**
Yes.

**Ellie Rofe | 41:16**
If people need to build something that's scale, that is secure, that functions well, then they need you.

**Robert | 41:23**
Like, I know, like the physical part of it might become, you know, because we're always talking about the digital world, but, like, I'm just guess, suppose I maybe just, putting that on the table.

**Ellie Rofe | 41:23**
I.

**Robert | 41:37**
I suppose it's like, is that even is that some way to imagine the future where it's more like, okay, the if we keep moving at this pace and then this keeps becoming better and a lot of the dancers are encapsulated in it, then, okay, what now? 
Like, where what am I doing?

**Ellie Rofe | 41:58**
Yeah, I mean my answer at the moment is you're either having to outthink the machines with expertise that they don't have or insights or creativity or human connection that they don't have ways in which you can be vi a value add there.

**Robert | 42:14**
Well, at the very least, I have to be Cyboard.

**Ellie Rofe | 42:15**
Yes, there's phys.

**Robert | 42:17**
At the very least, like, if that's the future that we live in, then it means that for me to like, I would have to be living at least, I think a in a way that is that I'm augmented by this technology. 
You know, and so that my. Everything I'm doing, at the very least, is. Is benefiting from it. But. Yeah, and then but then the question of the value is something else. Sorry, Ray, cause like I knew you were gonna say something.

**rhdeck | 42:47**
No, well, the conversation sort of has evolved through a few different things, but like the. I thought the point that LA was making about, like, you know, lots of hardware stuff. And the hardware part is sort of like the changing mode of like where people have their where people have responsibilities. 
Like, wait, I'm not the tech person, I am the IT person. I was actually just talking with the former CFO Exael about this, and he was talking about how, like, you know, and you know, going forward, we don't need people like Sean Montgomery to bake software. 
Like, you know, that's pretty true. You know. And like the. And that changes the idea of security, because security is for like, whose job is the security, right? How what, you know, how are you handing off responsibilities or not or taking on more responsibilities? 
That's where security comes in, right? Security used to be like, I've got my guy. My guy takes care of these things for me. And now when you're taking care of yourself, you know if you're responsible for locking your own door and you'll leave the gate open, well, then that's something that's going to happen, right? 
And previously you didn't worry about as much. Although it you still the risk of the other person doing it, right. But it all feels different when it's like, you know, actually in your hands and they don't get to just say, wait, that's a thing. 
And I it kind of gets back to your thing before about talking about, like, the sassy part and like, people calling you up in the middle of the night and saying, hey, this thing isn't working right? They you right now you're that guy, right? That that's a lackey trap that we talked about before, and the. 
But when they become their own lackey, that becomes a security problem, right? And how do you and I think that becomes a way of thinking about that. But the other aspect of it is so that's one aspect like who's who has what job right and how those divisional labor's working out. 
But the other thing I was thinking about was like thinking about like the hardware thing where you were saying, like, hey, is it just about Buil, you know, maintaining Mac minis? And I think there's a certain aspect to that because the infrastructure requirements of working with always on AI are different or just always on agents in general, because the technology is different, right? 
And the use case is different. And that means we need to start considering different things. Like we already had this whole thing of having the meter right on the tokens be a consideration starting, you know, 24 months ago, right? That started becoming a meaningful thing for a bunch of people who are making software. 
And now we have this additional thing of, wait, we actually have to pay for this always on instance. We don't have just, you know, serverless, on demand, metered usage. It's like, no, you're renting an apartment, and that apartment, you're paying for that apartment every month kind of whether you use it or not. Which gets back to your question like, how do you get value out? Et cetera. 
But. The change in the economics, but which comes with a change in maintenance responsibilities because not only do you rent the apartment, you're required to keep it. You know, a certain level of okayness, right? 
And that's kind of what you're that's the additional responsibility. But what's the expression free as a puppy, right? So even when even with it's not costing a whole lot, the additional work and responsibility that's putting on you is like is part of the cost equation. 
But that becomes something you can charge for just like the store does.

**Robert | 45:47**
Yeah. Very interesting. I imagine that. And I don't know why this just came to mind, but like it feels like almost, another pillar of the potential services to offer in this space. Like in terms of. 
Okay. There's this concept of, like, agentic work, and then people's varying degrees of comfort with it and then varying degrees of demands for it, and then all the other stuff that comes in behind it. 
And then the machine that they want to use or whatever. It seems like there's a whole area and there to potentially, specialize in, like behind. Like, if I look at it like, you know, there's. It's like a narrow hole. 
But behind that hole, it opens back up into, you know, into all the other possibility like that that's behind it. So it's like a narrow definition, but behind it, there's all the problems and all the potential that come with it to the varying degrees of maybe, like maybe to me, it might seem like maybe to some people, I suppose. 
And like I said, like to me that there's a simple way of looking at it, like, it's just there. It's Mac Mini to somebody else. It's like they want that version of it, but they want it times a hundred or something, and they want it to be, you know, with all the security and want everything on top of it as well. 
Like. And so that's not out of the box anymore. And this is helpful, actually, because not just C comes back into marketing. So this is now it all comes back full circle for me. Okay. So and then this is this is helpful because it just reminds me that the market is bigger than just this agentic part. Something interesting, actually. 
You know, what's really interesting to me is that. I think that I have a totally different perspective now on the whole rocket situation. On the whole rocket thing. And this kind of brings me back to this as well because like I've as we've been talking about this makes me realize that there are different pillars. 
So like, there's like a genenttic. But then there's like development really like helping people with like develop their projects like, you know, and then that's not you know, Agenta can be like a strategy in that. 
But then there's. But so what I say with Rocket is that actually I think IBM stock has fallen. Like it took a sharp dive when Anthropic announced that it can rewrite Koble, which is what you know, the mainframe, you know, the language is so, the point is that I looked at it before as help that technology last longer. 
I think that there could be action. Opportunity. And help them switch over faster. You know, in quarters instead of years. So I think that there's something there, and I think that the market is already showing signs of recognizing that. 
And it's inevitable. So like if this is because it is possible for sure to rewrite it is. And like, not everyone's going to want to do it. It's going to be a lot of big. There will be work involved, but I've already done a big migration already now it's like I've dealt with this stuff so much. Anyways, I'm just saying that like, I guess speaking out aud but something that I've as I'm trying to like put these connectors together.

**rhdeck | 49:15**
Okay, how can we would be most helpful to you in the five minutes weve got remaining.

**Robert | 49:21**
But.

**rhdeck | 49:24**
Excellent point about the speedboat accelerate fast, turns fast.

**Robert | 49:28**
More fun cruise ship back.

**Ellie Rofe | 49:35**
So what we says big companies like, we can't move. We're no longer agile. We're terrible.

**Robert | 49:41**
Yes, that's why. 
But that's why I embraced the opportunity to I to change as much as I can. I'm trying to keep everything as low level as I can. I suppose, like, maybe in the last five minutes, if I have the. The question that I have is there any problems I can solve for anybody here? 
Probably I on the computer now?

**Ellie Rofe | 50:24**
I mean, what.

**Robert | 50:27**
No, I turned it off from Jag.

**rhdeck | 50:30**
If the. I think that there is. You know, the thing that you open with is like a little bit like reverse door knob. The thing that you opened with the people coming back to you for maintenanceing that. 
That's something I'd pay attention to, right? That's where you get dragging your business. That's where you get, you know, that's where burnout comes from because you're being interrupted with people's crises in ways that are not necessarily super productive. CA sure. Then it comes back. Or maybe you're just sort of they're calling you because they're having a bad day or something. 
So, yeah, there's an aspect of either of you. There are kind of. I think there are two main alternatives. Or I suppose they're actually, yeah, there are a couple of things you can do. One is when you're moving from having done the big transformative thing to getting into maintenance mode. Get on someone else's plate, right? 
So someone else is getting paid to be able to receive that somebody else. So that you're paying may be somebody else's profit. Yeah, right. And in that way, your client's not paying you for that time, right? 
But they will pay for your person. And then that might be quite worth it from a whatever point of view, particularly if the. The other irony is if you're charging them how many hundred dollars an hour. 
And then they're like, but they for the maintenance, saying, I'm not gonna, you know, you don't have an arrangement for how you get paid. They might be willing to pay the lower rate of, I don't know, me high or something, right? In order to get that kind of access and then the. 
And then that that's like money in his pocket, right? In a way that is not necessarily in yours. So some money. And then, like, does it really deprive you of money? I don't know. The second is you could charge for it, right? You could say, well, if you want to reach me on the weekends, it's just this kind of emergency rate. 
And that's what plumber will charge. You know, they. If you decide to on at 10:00 pm, they'll gladly take your call and send you a giant bill. Because that's just how they get paid. Now, I don't think you want to get paid that way, right? 
But that's a, you know, a thing to give some consideration to. And the third is you can put some AI to work where we sort of talk about how to use open CLAU I actually sort of thought it was obvious that open Claude was going to become part of the answer to that question, right? 
Like, wait, a big thing came in. Okay, they're reporting this problem. Maybe I need to go look into it. Says the real.

**Robert | 53:01**
Yes, that's the thing. And that's the thing that is consuming me, to be honest with you, because, like, I'm building this entire, you know, infrastructure, and I'm just doing battle with it every day. 
Like battling this, to, you know, fight through. Yeah, like I said, like to where it's just making its way back into, like, being usable and being truly, like, turning the wheel and, you know, just like, again. I could never ask somebody else to do this. I would never tell. 
Like, honestly, if anyone came to me and said they wanted to do this, I probably I would not recommend it because it's just like, it's so insane to try to do this, but like. But that's what I'm. But that's what I'm doing is just like every single day. 
And if on any day of the week I basically build a new version of it entirely like and get it to a point where I've just, you know, moved to a new thing that I've realized I don't like about it. And so yeah, but all in pursuit of that idea of like of where the magi want to say that if I want this thing has happened. 
You know, maybe that's what pissed me off. Actually, this weekend was like, that's what happened. Like, I got that message from, you know, from Scott. And then my first test was like, okay, fine. Let me see if the open clock can handle it. 
And it wasn't able to you know, I was like and that that's and that was like that kicks off for me. It was like, you know what? This is unacceptable. Like the ideal situation would be like. I ask and I get. Now let's work towards building all the systems for that, yes?

**Ellie Rofe | 54:40**
Can I be so bold as to throw a last minute thought in? Are you trying to solve a human problem with technology? Like you need to say, I don't support this at the weekends and then fix it.

**Robert | 54:50**
For sure. All my problems, yes, but, like, I agree, yes, but that I agree.

**Ellie Rofe | 54:59**
Great. 
But otherwise. Just like. No. Don't. Contact me.

**Robert | 55:05**
And, I don't know if I have anything else other than human problems, so, like, you know, like, I guess that's the only. I agree. I just. 
And that is AI think that for me, I'm just looking to augment myself into like that service provider that then is it not sweat off my back in order to be able to provide a level of service. So I definitely agree that like on and this is maybe like the glasses is half full type of way of looking at for me that like I look at him say yes, this is annoying. This is XYZ, this is all these things. I'm going to use it as motivation to build something that removes his pain, and then that way we're all happy. He'll be happy, I'll be happy, you know? Bank account is happy. Everyone's happy because, you know, that's one way to solve it.

**Ellie Rofe | 55:52**
One.

**Robert | 55:53**
And it's a harder way to solve it. A lot easier for me to say, you know what? Tab you just disappear, but instead, like, you know, then I'm trying to lose the other way on purpose.

**Ellie Rofe | 56:03**
Got you. Yes. You're leaving the stone in your shoe until you can create the stone removal machine that works perfectly.

**Robert | 56:13**
Yeah, I'm purposely. I'm purposely leaving the pain for myself as a motive, as a forcing function to force a innovation out of myself that to solve the problem. 
Like, you know, that's just what I'm doing to myself, so.

**Ellie Rofe | 56:24**
No.

**Robert | 56:32**
Well, thank you, guys. Thank you all for your time. I appreciate it.

**rhdeck | 56:36**
Yeah. Absolutely. Man. It was great to work together today. And we'll be doing this again. Yeah, a week from today. We'll talk in the later.

**Robert | 56:44**
By thank you record.

