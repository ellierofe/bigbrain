# State Change Mastermind - Feb, 10

# Transcript
**Speaker 2 | 00:02**
Hello Robert.

**Speaker 3 | 00:04**
How are you doing? Ray?

**Speaker 2 | 00:05**
All right man, I think I've got a full house now. Yes.

**Ellie Rofe | 00:19**
[Laughter].

**Speaker 2 | 00:21**
Any hellos? My goodness it has us feel it is the 10th of February what is happening?

**Speaker 3 | 00:31**
I know how you feel. I think I know how you feel. I don't even know how I feel.

**Speaker 2 | 00:40**
Well, let's get into it, let's go around the horn, and do we just restart with you, sir?

**Speaker 3 | 00:47**
Yeah.

**Speaker 2 | 00:47**
For sure we Tursday wasn't go. Yeah.

**Speaker 4 | 00:54**
I found my way, guys, being more, yeah, I found my way to solve my main struggles in the big question like, how can I build trust with the audience so I can, attract more people and, into my door so I feel more comfortable doing what I'm doing now. I'm running the process where every single day I add a new edition, and at the end of the day I record myself in a two three minute video and try to post it. This is my approach. I'm planning to organize another event, not technical one, but mostly for salespeople next week, most probably on next Tuesday, in order to, you know. 
So in case I'm collecting a feedback at the moment with real case studies I'm trying to implement and I already have the first test user joining the platform, she's experimenting it, waiting for her feedback, and I have already an engagement, a demo engagement running with a client who wants to build this system for his framework.

**Speaker 2 | 02:21**
Very cool man, that's super cool. SP and Robert, can you check it with you? What kind of week it has been?

**Speaker 3 | 02:32**
It's been actually a pretty good week. I feel like I have more leads than really before, like I have. So I mentioned last week that I was meeting with somebody from Auto Parts, and it was like the e mail was kind of interesting. Turns out the guy is actually seems to be at least pretty important. 
Like he's like the chief AI something. I mean, you make up these titles, right? But like the point is that his email is autoparts.com. So the so he but that was a good conversation and I've followed up with him the systems helping with that. He answers me back very quickly. 
Like, you know, you get a feeling for people after a little while and like. So he's soon as I send him an email and like, he'll just email me back and letting me know like, okay, even if he can't meet the next few days. 
Look, okay, I'm traveling the next few days, and then we're gonna touch base again. So, you know, you can kind of tell when somebody's interested in you or not, right? Like, yeah, get the butterflies in your stomach. 
So, don't let my fiance hear that. And I met with this person who he wanted to use the snappy tool, so I walked him through it yesterday. His name was Brian Chasson or something like that. He's like a five or six year. You're like one of the first users of Xano, apparently. 
So I walked him through it and, I actually. And so that was all good. And then it was kind of towards the end. And then he was it was interesting because he was kind of the whole call, we were just talking about the tool. 
And then, the conversation was kind of like fizzling away. He's like, he has to go do something, and then I have to go. And then I just shared my screen. I'm like, well, let me show you something that I made with it. 
And then I showed him the Galaxy knowledge graph that I made. And as soon as he saw that, he realized that I must be pretty decent with data like it. So then immediately he said, Whoa. He's like, he just said, okay, now do you show me this? He said, I work with Walmart, I work with like these, you know, these companies. I work with a lot of data. He's like, we let's we have to talk again. 
And I so I say, okay, cool. But I think that was interesting because it was like he just communicated in one thing. He's like, okay, this guy made this thing that spins around in 3D space. Like then, you know, he probably can, you know, be at least a decent person to talk to about the other problems he has in his life. 
So, yeah, a couple updates.

**Speaker 2 | 05:11**
That super cool that that's very happy for you both. And today is your hot seat. Ellie. So we are focusing our resources on how we can be most helpful to you. So I guess you know where you come from last week, where are you now? How can we be of maximum service to you today?

**Ellie Rofe | 05:31**
Thank you. So the last week has been interesting, I guess. I'm still waiting for the contracts. I'm not saying that anything is set in stone, but I think I have an engagement with this political party, to help fundraise, which is a really nice random different way of approaching things. In. In. Putting together the proposal. I guess. For that I adapted the grid I normally use for pick startups. 
So the do I get it, do I believe it, do I trust it? Grid with the different categories where we work through and we like map where they are now and we shore up where there are problems, clarify, et cetera. 
I've been trying to find a way to work out and this will come in later because I'm trying to put my portfolio together. I'm trying to work out a way to explain what that does in a way that makes sense. 
But we'll get to that. But that seemed to have a really good impact. And, there is, I think a huge opportunity for them at the moment. And because I'm because they're such a small agile party, there's a huge opportunity for me to do stuff that's totally different. The there is no sense that this will definitely go ahead, but I very excitedly got invited to an interview at a dinner with, Rory Sutherland, randomly, who this party have been courting for a while. He was meant to do a keynote at their last conference, so that was really exciting. 
And I got told that I was. I thought like him, which was possibly the best compliment I've ever had in my life, which is why they wanted me in the room. But we shall see. I'm not holding out on that one because I think that's probably, you know, one of those things that's talked about but won't happen for months if it does. 
But it was really it was nice times. Politicians, hey, they know people. So then I've been I interviewed one of the guys from the SDP, actually, who is building a defense. Startup has worked in all sorts of high end construction stuff. Worked in NGOS and humanitarian work and all sorts. 
So that was really interesting for the Atomic Lounge, for this sort of interview series I'm doing, and it was really. I realized that I have a lot to learn in interviewing, and I talked to Ray about some of that. 
But I think I've got another interview tomorrow with a woman who's she's raising her first fund, but she has been in she's a VC scout and, has been working with startups. She's very in like deep in the biotech stuff. She was co hosting events at the JP Morgan Conference, which is a pretty massive biotech healthcare type event. 
So she'll be really interesting, and I suspect she'll be a bit more polished and a bit tighter in how she responds to things. Part of the reason I struggled with the first interview. He's just very associative, thinking anecdotal, and I was just listening and following along and then suddenly going, shit, I haven't actually brought him to the point. 
So, no, it's really fast. It's very challenging but really fascinating and I need to put forward. I've been struggling and putting this off for ages, but I'm trying to put for put together a portfolio because lots of people in a sales context then ask me if I have a portfolio. 
So a guy I know at UBS, the big bank wants. He wants me to help him with an event. But we have to pitch someone internally to get that through. And he said, can you send me a portfolio? And then someone else who is a biotech consultant, she's very experienced. She's like, I sometimes have decks I need help with. Can you send me a portfolio? 
So I keep ending up with this can you send me a portfolio thing. And so I'm trying to make it modular. It's taken me an unbelievable amount of time, and I'm still not there. So I thought maybe I could sort of talk through some of the thinking of where I've got to. You can look at it and tell me whether there's things that don't make sense or better approaches to it. 
And it's all very draft. It's not done at all, but I think I would just love your help to get a bit unstuck a bit like we did with the website. 
So can you see PowerPoint? Cool. Okay, so, I've been toying back and forth between whether I just. I probably shouldn't leave that on there. Toying back and forth between whether I try and create a blended thing because like, Paul wants help with an event, but he wants help with a design around the event and stuff like that. The SDP want help with fundraising, but they need help with strategy. 
So these things often bleed into each other. And I've been trying to create this sort of amazing modular thing where I could just magically move it all around and it would work for any scenario. And then I it just didn't feel like it was quite working. 
So I came up with this as a different way in.

**Speaker 3 | 11:06**
K.

**Ellie Rofe | 11:19**
If I'm going too fast and let me know. I'm just trying to give you a feel. People would flick through it. 
So then I quickly talk about the process, which I need to finesse, but basically a three step thing like get everything out of their heads. This is really finesse and then amplify it or something. I'm struggling with trying to not sound too like. Deeply consultant speak nonsense. It has to somehow connect with people, but not just sound too flippant. 
And then this is effectively the tool I am using the most at the moment. Because what I've realized is for me to actually be really creative and do the fun stuff and come up with great ideas. I do need to just make sure everything underlying it makes sense. 
And I don't know how to express this very well. What I'm trying to say is that I. So this is the startup version. This is what I did with Maddy. It starts off like this. And then once we've. Once I've understood everything from them, we start looking at all the ones that aren't green, basically, and improving them, making sure that they all make sense, make sure there's no like, issues, and make sure we got the best possible underlying information. We can have for whatever we're creating. 
And then I so I go about doing that, and once I've got that, that's when I then create the value on top of it. That's when I so with Maddy, it was like, right, we've got all this information now. I understand everything. I understand your positioning. 
So we do a category creation thing, which is the fingertips for physical AI. And you know, we sort of leverage it. We turned out to eleven, which is a reference I keep using. But if people have watched Spinal Tap, then it means absolutely nothing to anyone. 
So I'm like, what do I need to do? I realize I'm waffling really bradly.

**Speaker 3 | 13:31**
By tap. That's a funny movie.

**Ellie Rofe | 13:33**
It's brilliant.

**Speaker 3 | 13:34**
Spino Tap's a great movie.

**Ellie Rofe | 13:37**
I love it. And the phrase turned out to eleven is always just stuck in my head. And there are you know, this is like the events version, it's really similar. Do I get it, do I fill it, does it last? 
But it's just slightly different categories that go through. This was the politics version. Really similar, but slightly different categories. Slightly different. Emphasis. There is a brand strategy version, which is I haven't actually put into here, but I don't need all of them in here. 
And then after that, do some case studies and these case studies will move around. I think the case studies might be the thing that switches depending on what we're doing. Like, a you know, before and after stuff, but there'll be ones for an event, for example. 
And, you know, these are just Designy ones, really, which aren't very exciting. These are like brand strategy stuff or whatever. So I guess the thing I'm trying to work out and I haven't even managed to express it very well here, I don't think is how to get into how to make it feel coherent and like it's solving a problem for them and like I am the person who can solve a problem for them, obviously. I need results, testimonials and logos in there so that there's like some, proof as well.

**Speaker 2 | 15:07**
Okay, so you've shown it. Are there particular questions you want to be guiding commentary or the conversation or you looking for top of head reactions or what? How can we put this group to maxim needs for it?

**Ellie Rofe | 15:21**
Let's go with top of head at the minute. Just what comes to mind as you see all this noise that I've created and then like. Or where it begs questions, where you're looking at it going, I don't understand this. It doesn't make sense. 
It's lunatic. And then I'll sort of refine the questions.

**Speaker 2 | 15:47**
Alright you interest I'm gonna pick on you because your microphones are off.

**Speaker 4 | 15:53**
Is it off?

**Speaker 2 | 15:54**
No, it's on that's what I was saying. It was good to any. So this up.

**Speaker 3 | 15:59**
Yeah.

**Speaker 4 | 16:06**
To be honest, I'm thinking e because what I saw so far early in this presentation, there is a nice consistency and flow, so it makes a lot of sense. From my understanding. You wanna make, fine tunings and adjustments for. Based on the purpose of the. Its presentation. Is that right?

**Ellie Rofe | 16:33**
I'm. What I'm wondering is if I can get to the point with the intro section. So just to give a tiny bit more background, when I researched portfolios and then I asked AI to research portfolios, when you do sort of strategic work rather than just design and stuff, they said it's best to show some sort of methodology. 
And I tried looking up various like thought leadership and brand and strategy and stuff. So I'm trying, I think what I'm trying to work out. The first question is can I get away with having the methodology piece up front? 
So explaining what I do and how I do it and then just shuffling in and out case studies that will depending on who I'm talking to and what they need most from me. That's one question. If I can or if I can't? What is the methodology? The intro section? Does it make sense?

**Speaker 4 | 17:32**
Okay, I think that, people, engage with the context that shows their problems, right? You told me that very well, Ali, and this is totally true.

**Ellie Rofe | 17:53**
One.

**Speaker 4 | 17:55**
So, what is which one of those, pages here? Illustrate and communicate the paint points into the portfolio because I understand that. 
Okay, the portfolio shows your, stars, but, shouldn't include the paint points you sold.

**Ellie Rofe | 18:33**
It possibly it probably should. I don't. I don't know how to do that for so many different audiences. This is a problem. I keep coming up against.

**Speaker 4 | 18:44**
Think you have a variety of audience and this is true, but each one of them, they want mostly to see how you handle the how you understand and recognize the pain point they may have. Because in your consulting work, that is the core value. You join the conversation, and from the conversation you are responsible to understand what is my pinpoint and that what is the thing I cannot see. This is what you did to me. With, for example, for branding part and communication part. With photo leadership strategy. Correct me if I'm wrong. You helped me to recognize what I wasn't able to say. 
Okay? And that was a huge win for me. Now, I would expect to see somehow how you think, how you handle this paintpoint and lead me there. I understand how challenging that can be, because if it's hidden from me, it's just easy to recognize it in words on the paper. 
But the symptoms I had. And if these help you. If you remember, I wasn't good. I felt the packaging part. I was creating content that had no sense, no consistency. I had something and I have thankfully something useful, but I cannot communicate well, so everybody who's looking at that's it, who's this fucking asshole? And after the conversation, we had a conversion, we converted that. Say, okay, look, there is a template, there is a packaging. You have to get into here, set up your values. These are the principles and 123, four steps and go. This is what we did, and I'm sharing my experience now for the political party. 
Maybe they're looking for something else. I understand that they care mostly about how you get the trend of voters behavior, how you understand what is important for the voters. Potential voters? Maybe. I don't know.

**Ellie Rofe | 21:14**
There's. I mean, they're still wling with a similar thing, which is that they're not able to connect and communicate with consistency. 
So they're not having the impact they should be having. They have a great product, but they're not having the impact they need to. So it's a similar under I mean, that's the thing, the underlying thing is always quite similar. 
But then I guess when it comes to UB sorry, I don't mean to talk too much in this, but when it comes to UBS, I'm trying to think they are. I mean, this is an event they've already run. They've been told it was better than Davos. 
But then they. This guy wants to work with me. And he just wants to bring me in. And I think it seems to me the best way for me to get work at the moment is I just have a champion. Someone who, like, really likes how I think or what I do, and then I have to try and translate that for someone else. 
So it's. That's where it's a struggle for me. Maybe it's because it's the third party thing, but yes. Sorry. Demetrius. Carry on. Because that's, it is really helpful.

**Speaker 4 | 22:29**
You know what? Sometimes we overthink a couple of things? The more, requesting people like the big company you mentioned, they may want to see something so simple that you cannot think about it. Very simple thing. 
Maybe a list of questions that can let them recognize what is the situation at the moment. Maybe this is part of your portfolio because you help people to think with themselves whats going on, how we communicate. 
So don't hesitate to bring a list of questions they have to think about, helping them to make a decision. Because I guess from a couple of cases, you're not the one in the room. Maybe another elite will send her portfolio there. 
So we have a competitor. How do you help them to make this decision? Or a one page exercise? Three questions, four questions whether it works. I don't know how helpful my thoughts can be, honestly. E but I see your hidden value. 
From my experience, I couldn't see it before I engaged with you.

**Ellie Rofe | 24:08**
I think that's my problem.

**Speaker 4 | 24:09**
I couldn't see the level.

**Ellie Rofe | 24:11**
Yeah, that's really interesting, asking questions. I mean, the grid is in effect, just a series of questions, but it's a bit hidden beneath, like process noise and stuff. Now, rather than just being like, here's the questions I'd ask you.

**Speaker 4 | 24:34**
That's good win.

**Ellie Rofe | 24:38**
Yes. No, it's very helpful, Demetrius. Incredibly helpful.

**Speaker 4 | 24:42**
Thanks.

**Speaker 2 | 24:46**
Okay, we bring Robert to the conversation.

**Speaker 3 | 24:52**
You're just by Mike. Yeah, sorry, I was gonna ask, like, what is the, way that this is going to be delivered to somebody? Is this going to be. I just wanted to know a little bit about what is the job of this.

**Ellie Rofe | 25:04**
Yeah, it'll be. Unfortunately, I don't want put it through a web site because it'll be not completely confidential, but not completely public. Things in there.

**Speaker 3 | 25:15**
But like, what's the job of it, though? Like, what is this? You know, who is this really going to and what is the is it supposed to convince them about things that maybe are supposed to be communicated necessarily through a conversation like because when even when you said portfolio and again like this just me asking because I don't know, maybe there's industry standards or something like that.

**Ellie Rofe | 25:21**
Six.

**Speaker 3 | 25:36**
But when I think of portfolio, I almost expect to just see I open it up and I just see previous work like I don't necessarily expect for, you know, for it to convince me, there with the portfolio, I think. 
But that's again just by, experience and like view of like what portfolio is maybe there something different there. But I do think that in general, it would. I don't know if you're served very well. I don't know if it's an advantage to be putting that information in there, you know, about how exactly you're going to do it. I feel like part of the value is that you're going to be in the room and you're going to figure it out. 
You know, with them, I think that the unknown is the valuable part. But anyways, that's just what some stuff that comes to mind. I just because it surprised me a little bit when you put it up onto screen. It wasn't. I was thinking that you were just going to show previous work, but then it starts to go and like it reads like a like as persuade. 
Like it's trying to persuade them to. To make a decision or something.

**Ellie Rofe | 26:51**
Yeah, it's a good question. So there's and this was part of the research when I looked up the best portfolios and I kept looking around at all of them. There's another version. There's another ill just show you this example. This is more branding. 
But actually let me not worry about showing you an example for the minute. So this is partly the reason that Paul wants this is because he wants me to work on this project with him. This is the guy UBS and he has to sell something internally. 
And what everyone reaches for is have you got a portfolio? I had the same question from the SDP and I only really got around it because I had the ear of Alister and he was more influential or he had more power there in the SDP than Paul does at UBS to make this decision and it's just the go to that everyone asks for. Have you got a portfolio? 
And part of my concern with just sending them examples of work is that because I'm not a branding agency, the output is almost secondary to the underlying work that goes on because I end up doing work on the strategy.

**Speaker 3 | 27:57**
Hu.

**Ellie Rofe | 28:20**
People like seeing visual stuff. I can't just talk to them about what I did and have like this is the problem. This was the problem. 
I have to show them something. Visual and design is part of what I do, so that's fine. But then I end up in this quandary of like, how do I explain to them that I'm not just a Slide Designer. Because if I just show them examples of slides. 
That's what they're going to think. That I just. Design slides.

**Speaker 3 | 28:46**
Can I just say that maybe, again, I look at it as when I think of anytime that just is for me, but like whenever I've put in a portfolio or something. To me, the exercise was just gathering previous work and maybe in this case, just expanded to gathering testimonials. 
And just to me, it's a documentation exercise. Like, if somebody asked me for that, then, that's. That's the stuff that I'm reaching towards. And I'm putting it together. And. And honestly, I can only just say that I've never again I've I don't. 
And there's lots of stuff that I've submitted things for. And I think, yeah, usually I would the Only Time that I've really put in something that's going to describe like, my Intention behind it. And like what I want is if they've expressly said that, hey, we want you to sell yourself right now or to provide this report or to, you know, or fill up this application and submit it along with those things that are. 
But if somebody asked me for portfolio, yeah, to me, it's just like I'm grabbing stuff. It's already there. Together. And. And then. And then I'm just handing it to them and that even and that seems to have been, consistent. 
So I'm I guess I'm wondering is what is the industry standard for you like, you know, is this something because you said you were looking online, is it is that accurate too even like. Or is that just people moving towards the average? 
Like, what would, like maybe. You always ask that question, but, you know, is there another way to answer it?

**Ellie Rofe | 30:29**
Well, I can show you two examples of portfolios that seemed. And look, the other thing is, it's very difficult to get an example of a portfolio where you know what work it's got. This is a brand company. They basically have their entire process and it's almost like a website. 
It's in a Figma presentation thing. So then they go into their featured work at the end, which is beautiful. It's a design Studio. So that's the design side, but heavy on that. And then Evelyn, this was one. I don't actually, I didn't.

**Speaker 2 | 31:15**
You say. That's shaing your screen anymore?

**Ellie Rofe | 31:18**
Pardon? 
Yeah, I'm just getting to a different presentation.

**Speaker 2 | 31:22**
Yesm.

**Ellie Rofe | 31:22**
This so this is one this is the leadership. So they don't have anything. This is like the other side of me where I do have output in terms of design and stuff. These guys don't so much. 
I mean, they do have output in terms of blogs and stuff. And this is like all text. Nicely designed. Some analogy. But they go through their IP basically of how they work and how they charge and stuff. 
So that's a Creds deck like similar sort of thing, but not quite the same. And I guess that is the question. Like everyone. I think part of the reason I've struggled with this is because everyone wants something slightly different because the. 
And I was trying to like, just get something where I'm like, well, what's the underlying thing I do. But maybe I just need to have a repository of slides and I just try and cobble something together quickly every time someone asks me for something, rather than trying to engineer something that people don't need because it's just easier for me. 
Maybe that's the answer. Ray is nodding. Going. Yes. Stop. Doing that.

**Speaker 2 | 32:46**
The there as I was looking through this, the, it seemed like you have a design aspect, right? Because you're a skilled Designer, and like the back part of it where you're just showing lots and lots of images. Hey, look, these are pretty, right? 
And they're just looking like can you do pretty images? You can you have those images in the back. I'm not sure that's particularly differentiating and certainly not take it to high, you know, high rate work. The front is where that part is, and that's where you can make them smarter. 
And the front is what needs Ellie. You know, like the I'm looking at that. I'm thinking there's, like you talked about the your three big questions. Those are varied in the presentation, right? There's like the big picture of you from the website, but I'm not sure I care. 
I mean, having a picture of you, nice, but, like, it's not taking me right. Like, I've got three questions for you. Three questions are what, then drive the rest of it right, do I get it? What do I get it? Do I care and do I trust it? 
Right? And like everything else, like a derivative of that, and it's like, hey. And that's how I use the three questions for the diagnostic remark. This I use the three questions for the interviews, right? How do we get we have a three step process for getting the answers to these three questions, right? To understand the thing behind those three questions so we can then drive to those and then you have your three set process and whatever like there are lots of three engineer but the you know you providing that kind of clarity would show that you can do for yourself what you want to do for them. 
Otherwise it's that COB's children have no shoes.

**Ellie Rofe | 34:41**
Yes, but this is always my issue. This why I hate marketing. For me. But not for other people.

**Speaker 2 | 34:48**
But I don't think it. But I think it seems like it's a very solvable problem, right? Because you putting that kind of clarity on the front. And if it then looks rich, then they will say, wait, that's what I want. I want that kind of clarity. 
Because simultaneously, you're talking about your own quest for clarity and you're demonstrating that you know how to show clarity to someone else.

**Ellie Rofe | 35:13**
One.

**Speaker 2 | 35:13**
I think that's kind of what this document needs to be in the general case for it to be successful or otherwise. 
If you're not going to go down that road, I think you might be better off chopping off the first seven or eight slides. This gets like, you know. But Tori's point about like, you know, there's lots of value in those first slides, but if you're not going to go down that road, if it just sort of gets confused because you're showing off your barefoot children, then that's where Robert's point about the job to be done comes in. 
And then you just kind of want to show the pretty things in the back. I don't think that markets want to be right. But then it's like, that part is just doing its job well, right? Lots of pictures. What are they doing? They're flipping through the pictures. They're doing two things, they're probably flipping. I was actually very helpful. I'm only looking at half sized screen right now. 
So all of the small text I wasn't reading at all in your headlines.

**Ellie Rofe | 36:02**
Yes.

**Speaker 2 | 36:04**
I'm kind of doing what I imagine like an executive doing, they're flipping through this, they're looking at the headlines or, hey, that kind of looks like a nice picture, right? 
And getting a positive impression from that. But that's what they're going to do.

**Ellie Rofe | 36:16**
H.

**Speaker 2 | 36:17**
What are they going to remember from you? And the I think there's it kind of wanders around a bit. There's a little too much. I got to read all twelve of those boxes in order to be able again, what's going on? 
But if you can say there are three questions you need to answer. This is my process for answering those questions. If you do that, you can produce this. Yeah. So maybe you're reshuffling that story a bit, but it seems like there's a wonderfully clear story that's in here that needs to get covered. And that's why I say it needs Ellie, right? Because this is you applying to yourself, and I appreciate that's the hardest thing in the world. I do it too, right?

**Ellie Rofe | 36:58**
Yeah, that's the thing.

**Speaker 4 | 36:59**
And, sir.

**Ellie Rofe | 37:00**
This is my attempt at making it clear and it's still not clear after a week. So this is where I really struggle with it.

**Speaker 2 | 37:08**
Well, could you just pick up the slides for a second?

**Ellie Rofe | 37:14**
It's the most frustrating thing. Being able to do it for other people and then being the worst at it for yourself. 
It's like.

**Speaker 2 | 37:23**
Well, that that's kind of where the mastermind comes in, because I'm not sure the three of us are going to be the best of being would be the best of being able to do this if we were just coming in and advising you on it by itself. What we can do though, and this is what the mastermind group becomes useful for, is we can reflect you, right? The what would Ali be saying to us right now? 
And then feed that back to you like this whole, you know, where it says portfolio. I'm not sure even you need to announce the word portfolio, you know? L yeah, what is it? You're. You're talking about. You say. 
You know three questions matter, right? And then I'd immediately get in next slide, what are the questions? Which doesn't mean the headline doesn't need to be what are the questions? It should just be show the questions. What would you say they should do in a presentation, right? 
And the press and I think otherwise, if you could just sort of flick through the next few slides.

**Ellie Rofe | 38:22**
One?

**Speaker 2 | 38:23**
No, that that's getting ahead of it. The these things are sort of in brown here. This is the best part, right? These are the questions, and I think that you're like, hey, you need to answer. 
You know, a good presentation answers these three questions. So to do that part one, we need to get clarity on those questions. Here's the three part process. The interview, right? The deep dive fight, which is the clarifying part, right? 
And then the turn up to eleven. The point of the turn up to eleven is that the guy was a fraud. So I'm I'd just be a little cautious about how closely you're connecting that particular scene.

**Ellie Rofe | 39:07**
Yes.

**Speaker 2 | 39:11**
But the, but I do think you're saying it, but it's, simplify, multiply, right, is what you're trying to get at here, right? Get the clarity and then you can be distributing it. 
And I think there's a lot to that if you're going to go for more spinal type references. Totally into in into the rest of it. But there's but anyway, the this is really good, right? Because then you can show how this feeds into more examples of diagnostics. 
And now having all this stuff here towards a map out whatever the diagnostic saying these are your three questions on the left. You can even have this before anything gets developed. You start putting that on a separate page. 
And then example with the three big questions. Cause it's repeating. And like, because I'm seeing those three questions coming through, right? That's you telling that story. And partially, it's important to be saying these questions matter because now you're the person with the right questions. 
And partially, it's to be reinforcing that like you know how to tell this kind of story, right? We expect that like you if you're selling expertise in this, then you should be able to demonstrate it for yourself.

**Ellie Rofe | 40:23**
Yeah, I know.

**Speaker 2 | 40:23**
I remember being, yeah, that we hate it.

**Ellie Rofe | 40:24**
That's why I hasted. Yeah.

**Speaker 2 | 40:29**
But I think you've got like this motif here of the three questions that is so powerful and like, right now, how far I'm in, I'm on slide nine. Slide nine right before I've gotten to them.

**Ellie Rofe | 40:44**
Yeah.

**Speaker 2 | 40:45**
And I would love to have like the title of it be, you know, the three questions you need to know, right? 
Because then that that's drawing them out. Of course it's a portfolio document, but you didn't waste real estate with that, right?

**Ellie Rofe | 40:55**
H.

**Speaker 2 | 40:59**
Let's get him. And she'd be asking and then here's what you're asking and then here's how you answer it, right? You have both the diagnostic, and then you get to start showing. 
And then, you know, the diagnostic, which is. And basically you have three phases. Phase one is the interview process. Phase 2 is the diagnostic, which breaks it down, right? And then phase three is multiplication, turn to 11, whatever, and that's where you get to show. 
And when you do that, you can get this right. It's not just having an eye, it's about telling the story that matters. But then you're showing that you have an eye, which is, you know, very useful because they were that that's probably what they thought you were coming in. 
And that means you get to cross off the table stakes thing while having set stage for the thing that's really extraordinary and about you.

**Ellie Rofe | 41:47**
Yeah. Okay, so I literally just have the three questions. This is all you need to ask. Does that. Does that make sense? When people don't know what I'm talking about.

**Speaker 3 | 42:09**
I think it does make sense. Actually. I think that would. I actually agree. I think it could be a strong presentation just to, like, open up. Like, I've got three questions for you. Like it's a good way to start something like Steve Jobs would say when he walks on the stage. 
It's like something in the air. One, just say that and then don't say anything for like 30 seconds.

**Ellie Rofe | 42:27**
MI think read saying get rid of it.

**Speaker 4 | 42:32**
But. Robert. You mentioned something previously. The word portfolio means I want to see your case studies. And from the first page, it creates some expectations. Wouldn't that have any, you know, frustration for the next pages if the word portfolio remains? I'm. I'm just curious because. No, English is not my native language.

**Speaker 3 | 43:05**
Which is? Remove it, I guess.

**Ellie Rofe | 43:09**
Ray's suggestion was just get rid of it and just have basically three whoop sorry on a three cracks.

**Speaker 2 | 43:23**
Three quacks of a duck.

**Speaker 4 | 43:27**
Okay, I didn't get that for removing the word.

**Ellie Rofe | 43:27**
Just completely get rid of it. Basically.

**Speaker 4 | 43:35**
That's a good point.

**Ellie Rofe | 43:45**
Sorry. I've caught the time. I'm afraid it's pain. Okay, so three questions and then, do I need to slightly tweak this? They do slightly change, and I'm trying to work out because it is a sort of replicable thing, but, I'm trying to work out how I sort of I'm getting that, but yeah, how they're universal, basically. 
Okay, yes, so it's something like do I get it, do I believe it, does it last, does it survive the day like. But yeah, I'll work out.

**Speaker 3 | 44:31**
What were three questions at the. At the beginning, sir? Like what would be the three questions that you would ask?

**Ellie Rofe | 44:37**
Well, this is the thing. So it depends. It's slightly different if it's a presentation like a fundraising pitch deck or if it's a, brand or if it's a an event or if it's politics.

**Speaker 3 | 44:50**
No.

**Ellie Rofe | 44:50**
Fundraising is slightly different to startup fundraising in terms of what you're asking, but it's similar it's really similar.

**Speaker 3 | 44:57**
Like moment is there just an example? I actually have no idea what would I see, because I can't really.

**Ellie Rofe | 45:02**
Yeah. So here yeah, sorry, yeah, be big.

**Speaker 3 | 45:05**
Okay, see.

**Speaker 2 | 45:07**
I see.

**Speaker 3 | 45:08**
Is it yeah, okay.

**Ellie Rofe | 45:13**
So the goal is really a comprehension, an easy repitch. Like do you have the information in there that people can understand and repitch it? And ironically, believe it or not, I have tried to apply this to the portfolio, and I haven't managed to do it either. 
I've even tried to use my own diagnostic tool and not managed to get it done.

**Speaker 2 | 45:36**
Isn't this semivered maybe.

**Speaker 3 | 45:39**
Sorry. I was just only going to say that like, maybe this is something that's reflected in the conversations you've had with these people in the past. And they could pull out the structure from there. That was just what I was gonna say.

**Ellie Rofe | 45:53**
Yeah. When I when it. When it's going to people I've had conversations with? I think so. Yeah.

**Speaker 3 | 45:58**
That mean? But. I mean, like even if you do the actual delivery of the service with people, I imagine I think. Can you correct me if I'm wrong? But do you get to these topics and start to discuss these things in particular? 
So then I find that for me, when I'm live on the call and I have usually you're going to get my best performance like of whatever it is that I'm trying to get out is going to be right there, you know, with the. Especially if it's with a client and you know, certain recordings and certain times where, yeah, it just comes up better than others. 
And if it's more recent, I think it could sometimes be very useful for some fla.

**Speaker 2 | 46:35**
Desk.

**Ellie Rofe | 46:37**
Got you. Y yes, a little bit. Yeah, I do talk about it, but, it's again, it's just slightly different depending on who I'm talking to, but I can definitely listen. I explained it to someone last week, so I can definitely listen back to that call and see how I expressed it. 
Yeah, that's a lovely idea. Sorry, Ray, you were circkling something.

**Speaker 2 | 47:03**
That'sol well circling. So. So we were talking about the three questions, which I think if you know what you want to say, these are three questions your investors asking, right? It's ant these are three questions your sponsors your attendees are asking right in the. 
And like you really start to, you know, dial it in based on what it is. But you know, you care about that and that she is relatively easy fix to make sort of identifying who those people are, right?

**Ellie Rofe | 47:29**
2?

**Speaker 2 | 47:30**
But remember, it's not your question because it sounds very challenging when what's coming for you, but it's exactly what the investors are thinking about, right?

**Ellie Rofe | 47:36**
Yes.

**Speaker 2 | 47:37**
So your investors are asking, do I get it? Do I believe it? Do I trust them, right? 
And it's going to be all right. So what you want to do is be able to help them with those questions. And there are two jobs that you have and this is actually this is was getting at over here, right? This thing you put into itals you actually a number of times out loud because it's such an important idea that people need to get it on the first pass and they need to be incentive to re pitch it. When you're talking to an investor, you not only want them to say, yeah, I get it, I'm with you, right? 
But they need to go have this thing they can just say back to the next person and this needs to be they need to want to and it needs to be easy, right? That is the job of the deck. Your deck can have a hundred slides, but it needs to be something where they can just say an elevator ride to the next person. Or in the cut. Not even in the length of an elevator ride. 
But like during an elevator ride, this needs to be something that' easy, top of mind, appealing purple cow stuff, right?

**Ellie Rofe | 48:39**
Yes.

**Speaker 2 | 48:43**
It needs to be remarkable. And that is and that that's where the comprehension comes in because the comprehension gives the opportunity to be planting it deeply enough that they can then rept it such a good idea. 
I mean, I know I'm sort of restating an idea that you already have, but I think it's just such a good one. And it's one that I would have you put front there. Like, these are three questions that matter. Your job in a presentation is instant comprehension and easy reitching. Let's talk about how we make that happen. 
And now I was like, you know, if they have bought in to the idea that these questions matter and if they bought in to your idea of comprehension and easy retch, then you got them. They're in the shoot, you know, at that point, if you think about it like that's the, you know, those first two things, are you satisfying. Do I get it?

**Ellie Rofe | 49:48**
No.

**Speaker 2 | 49:48**
They're asking, do I get it relative to you? 
And I think that's, you know, the these questions and this pattern. Great. Got it. And then do I believe it? And that becomes. And the clarity of you putting it right to the front probably is where they get the instant comprehension, right? 
Because get it and believe really need to come at the same time if they're going to be successful. I like yeah idea. Let me see if I buy it. No, because really what's happening is number three. The thing that you build with, that you can never build instantly, that only build with time is trust. You can have magic words. Magic words can be the things that, like, get you to the, you know, get believe the thesis. 
But do I trust you with it? Trust always takes time. So now it's like. What's. You know, your. Your job. In the first three seconds, you gotta get these first two and then you gotta everything else is just about, you know, through re signaling. Those is to build that trust. 
And then that's what you're doing with the rest of the presentation, right? This is where you show this is my process. This is where you show this is being a picture of you. This is where you show, you know, the results or the, you know, beautiful things you've made in the past, because that's all about the, you know, door number three. Build a building trust.

**Ellie Rofe | 51:03**
Two.

**Speaker 2 | 51:03**
Anyway, I wanted to be thinking about that because one, it gives a structure for your presentation for yourself. But. But the thing that sort of, you know, it feels like these two ideas in here are like the biggest ideas you've got in this deck, and they're really appealing and powerful. Ideas that have come across as you've spoken, and if they're primed for them because they have seen them at the front of your presentation, I think they might, you know, it might help you with that instant comprehension and then easy repitch because that it instantly comprehend and they have to instantly reptch.

**Ellie Rofe | 51:34**
Three.

**Speaker 2 | 51:38**
That itself is a repitchable idea, right? 
It's a meme. You're planting this. This idea of virus in their head. Seth.

**Ellie Rofe | 51:52**
Yes. Okay, I think I get it now. I think I see the way forward, and hopefully I don't have to spend significantly more time on this portfolio.

**Speaker 3 | 52:03**
I was going to ask, is this basically a sales ladder structure essentially because it would just kind of help to think about it if it is, then.

**Ellie Rofe | 52:03**
But that is really helpful.

**Speaker 3 | 52:14**
Then to me, the first thing that comes to mind is that because as Ray was describing it, that it just it started to make sense. 
Like. Yeah. Like then you would either their buy in. Like you would need to state some type of something at the beginning that it would seem that just really, you know, describes their problem and their pain. It would seem like it should be very much focused on just something that's going to really just, you know, twist a knife a little bit on whatever it is, right? 
And like this, that depends. Like, I've. I've heard some good ones. I've heard one that I remember was if you don't have a constant source of leads, then you don't have a business, you have a hobby or some. Some ideas are kind of like stick it and just something to a little spiky, I suppose. 
And so that's anyways, just kind of pointing it out. Maybe there's something there.

**Ellie Rofe | 53:04**
I think that might. Yeah, I think it'll slightly depend on the audience, but yeah, absolutely.

**Speaker 3 | 53:08**
It depends. Yeah, it depends.

**Speaker 2 | 53:10**
Yeah.

**Ellie Rofe | 53:14**
But Demetrius raised that, so I there's some sort of issue with there not being some understanding of a problem in here, but I'll work out how that fits with the get it, believe it. Three questions up the front, definitely. God. 
Sorry, I've just noticed my laptop is about to die. It's on 1%. I didn't realize.

**Speaker 2 | 53:38**
Well, I think that it's timing really cannot be that much better. We've gotten to the end of our hour. LI thank you for sharing that. I hope that we were helpful for you. But I think you you know, inspired all. All of us to be. 
You know, you think about our own marketing. Today.

**Ellie Rofe | 53:57**
On it, really. It was really helpful. Sorry, I say I'm grumpy with it, I'm grumpy with the portfolio, but I'll get there and I really appreciate this feedback. I'm looking forward to the Krisp thing and going through it all. Thank you, Guy. See you.

**Speaker 2 | 54:13**
I go recording.

