# State Change Mastermind - Aug, 12

# Transcript
**Ellie Rofe | 00:09**
Hello?

**Ray | 00:11**
Helloly, how are you this afternoon?

**Ellie Rofe | 00:13**
I'm all right. I am snuggling in the corner of the room in the dark with the blinds shut and fans on. We got another heat wave.

**Ray | 00:20**
It is that kind of day. We're going to get to the high eighties Fahrenheit today here in Vermont. So similarly, I have blinds shut and the fan going on up above me, which hopefully Krisp blocks it out from a noise point of view.

**Ellie Rofe | 00:39**
Yes, same. We're in the old we call it a "canicule" in French, a little heat wave. So it's about 105 degrees today, but it's not too bad inside, but I just have the curtains closed to stop that sun coming and warming up our air.

**Speaker 3 | 00:49**
Okay.

**Ray | 00:57**
Yeah, I hear that. I'm just trying to get your, you know, environment to a temperature where your brain can operate.

**Ellie Rofe | 01:04**
Yes, exactly.

**Ray | 01:05**
I think it's okay. Well, let's kind of go around the horn here and ele perhaps we can start with you. What kind of week has it been.

**Ellie Rofe | 01:16**
It's been good, broadly. I had the keeping momentum up with staff, but then I had a call yesterday with the VC, which was interesting. I tried to talk to her about the report and a couple of other bits, and she was just like...
I mean, she's French, Swiss French. She's very matter of fact as well. Which was like, "You just use your network. You don't need to do this, just use your network, okay?" Right, but she was very helpful. She's going to introduce me to all of her partners. She works at one of the biggest biotech funds.
A couple of other people and a couple of her founders for two deals that she's got going on at the moment. So, she probably is proving herself right there. [Laughter] I think the next stage is definitely heading once the conference season kicks up, heading off to some conferences in the UK and Cambridge in particular.
Then I thought what I might do. I have noticed a pattern with a lot of the consultants that I see in this space and I've connected with on LinkedIn, where they're all talking to each other on LinkedIn.
So, I thought what I might try and do is just connect with all of them and say, "Are you actually getting work via LinkedIn or are you getting credibility by having this? Where are you with it?"
Just try and connect with them and work out how I should be focusing my efforts there. there.

**Ray | 02:50**
Yeah that's.

**Ellie Rofe | 02:52**
So that's... it was really interesting. It was a bit like thought at first, but then I thought, "No, let's just go." She's one person for a start, but let's just go and actually start speaking to some people and seeing what the reality is for them as consultants.
Because she's not a consultant.

**Ray | 03:06**
Is consultant. she? She is a national investor, you mean? Okay, super cool.

**Ellie Rofe | 03:07**
Yeah.

**Ray | 03:12**
That's cool. an excellent point about just using the network. We just had a marketing mastermind back on Monday in state change, and there are some people talking about content and using AI to produce content. I was looking at the resulting emails. I would never open any of those emails.
The reason is that basically the only thing that would cause me to open an email from somebody who I don't know is referencing someone I do at the top, which I thought was...
Yeah, what am I trying to say? The user network thing. Okay, you know that one's turning in my brain. Robert, what's true today that was not true a week ago.

**Speaker 4 | 03:56**
And my picture is up on my website, and that is... So that's definitely not true a week ago, wasn't true even two days ago. So that's... Yeah, just been overall just not even redesigned. It basically just made a new website entirely, so that's live, and it's not perfect, but it's there for iteration.
Your advice, actually, was very good, Ray, which was basically just to do it badly, and then you can have an opportunity to do it well from there. And that's it. Something else that I put up on the site, which I think looks quite good, is a link straight to the work to the calls on Wednesdays.
Luma has a very nice embed feature, so it just shows the whole calendar very nicely on the page. Below that, there's a link that says... That just leads to... AI guess you could say... No, I was just saying if you can't make it to a workshop, then here's a link to book a private session.
I don't know, this was something the AI came up with, and I saw it. I'm like, "That's actually a good idea.

**Ray | 05:33**
Yeah.

**Speaker 4 | 05:33**
I like, it's actually not bad. Like, it kind of surprised me, like usually not so good.

**Ray | 05:40**
The AI came up with this, is this the thing still running on... whatfa.

**Speaker 4 | 05:45**
No, this is on Versal. I don't know how you pronounce it.

**Ray | 05:50**
Okay, yeah, you sort of by code your way onto it. Okay, very cool. Yeah, that is neat stuff, man. Thank you so much for sharing that, and Dietrich, what kind of week has been? And then we'll turn to your hot seat. How can we service you today?

**Speaker 3 | 06:09**
It's not that interesting, so far. I feel more distracted from the pharmacy staff because we are at the point where the last week we've done some reconstruction activities, and tonight I'm traveling to the city for the next two days to do the rest of the staff. In the weekend, I'm going to be there doing this job.
So I see it's for this week and maybe the week that follows. I may be distracted doing that. So I just started TED to keep my momentum around learning stuff and doing some content so I can keep my way on that.
And yeah, that's it. Almost, for me from my side. And as about the subject for today's conversation, guys, I spent the two past weekends watching the Calibrals course about building branding and personal branding, which again, is about how to structure your content and how you find the right way doing the content.
It's not about the branding strategy at all. So I'm in the 50% of this course. Today, I joined a webinar from, I forgot his name. I guess it's Brian. The guy who sent an email at the end of the previous week or, yeah, last week with a guy who is a sales consultant. A successful one.
And you, Ray, then posted on LinkedIn, with his format, the framework for the conversations, if you remember. Don't remember his name. Okay, I watched all of this and I realized that none of those two guys explained how we can pack our personal stories.
Well, they say, "Hey, go and use your personal stories and pack them into content and just put them in the market." But the thing is, how can we pack those past stories talking to our own ICP? And the other thing is how can we find the niche?
So these two questions, I think I want to cover this week. Yes, that's it, right? Because I feel like I'm doing things like, with not actual results. Results on the turnover. I see results on engagement. I see results on other KPIs, but I have a need to see results on turnover.
So I want to see what I'm doing wrong, if there is any suggestion to make improvements and all of these kind of thoughts.

**Speaker 4 | 09:37**
Okay.

**Ray | 09:40**
Alright, should we, just get into it? Maybe you want to show a little bit more. So we can... You're asking what if the question is phrased in the form of what am I doing wrong? Maybe you want to share a little bit what you are doing?

**Speaker 3 | 09:52**
Yeah. What I've been doing the past few weeks. I guess it's the five weeks now I'm trying to post one video on LinkedIn that is posted on YouTube and two other posts with personal content, screenshot or personal thought or an image, totally personal. I find that screenshots perform the best than the video or random images, so this is one thing. I had some messages, but not that many.
In terms of the KPIs of my videos, there is no one who watched one video for 80% of the length. So most of the people started watching it and on the 20-30 seconds they drop, which is totally fine. I know that I'm not doing it the right way with the video and I don't want to waste many viewers, but the thing is that how can we make them conversions because that's the end goal.

**Ray | 11:13**
Okay, if we open up the... Let's open up the four of your thoughts on this. Maybe it might be helpful if you were to put up on the screen. Maybe an example of one of those videos. Yeah, but before we talk about, like, you will roasting the video itself, like, maybe we can talk about.

**Speaker 4 | 11:32**
Like.

**Ray | 11:32**
What, Ellie, what you and Robert have found to be working for you. Not just in terms of engagement. I think there's a question like what's the actual metric and then what's the real metric here? The real metric is going to be how it correlates with eventual sales conversations, right?
Because that's how we get to the next step in the funnel. What have you been finding in that regard or have found in the past? Robert, you've got a deeper history in this than I think most others because you and I have been working together.
I think the longest of the three Yals. What have you found?

**Speaker 4 | 12:11**
So I think that if we look at it just as a series of just parts that you're trying to tweak each individual thing, then I don't think I feel that you can control your messaging in order to elicit the reaction that you do want to get right.
There's going to be a response that you want from people. I think that the way to get it is the only thing you can control is your own. Whatever you're putting out there and creating.
So in that sense, maybe the question is what is the message that you're putting out there? Because there's no other reason. I think that the buyers don't exist other than the fact that whatever would be raising them to the surface is just not being put out there, right?
If I do that, if that makes sense, I'm hopefully trying to get it to come across. I think there's a lot of different ways that you can point your message. It's not an easy thing to do, but I can't. I just see it as something that has to change in the inputs for something else to change in the outputm.

**Speaker 3 | 13:49**
To do that, parking of the message. I found that it's from my side. At least there's the need to find what is my niche. And all the two guys in here in our conversations and everywhere. The niche, the deeper niche pace back because you're an expert.
And I find myself that I am an average. I don't see me having specialization, a deeper specialization in the domain. And so I'm struggling how to find that niche because I haven't experienced a low level in multiple different domains, different industries, different infrastructure of businesses from different clients and nothing that's super specific.

**Speaker 4 | 14:45**
So why can't you be just an automation expert? Or likewise, like you mean, tied to a tool? Is that what you mean? Like it has to be Airtable or something along those lines because I think that you could just be like a broad category expert.
And there's a lot of value in that.

**Speaker 3 | 15:09**
In a way, there is an expert for a tool, but not an expert in the industry. I think because we're totally comparable. Let's say you are in Xano, an expert in Xano, right? You've built an MCP on Xano better than the Xano MCP.
So you know how exactly it works. But definitely, there is another Xano consultant who is good. I feel those tools are the way to do the job. The specialty in the industry is how we understand the business of our client and how do we approach our solutions.
For example, I counted all of my mistakes till now. Ray taught me something interesting a few weeks ago. I got an engagement with a client building them the AI transcript analysis workflow, and Ray suggested booking a series of meetings with them and doing daily reviews.
I lost that because they changed the approach. They weren't... And finally, we're not in that much in touch. They left for summer vacations and so on. And I feel like, okay, wouldn't that be better to have a pre-fixed workflow so it could be guaranteed for me that I can handle them in max 5 sessions?
For example, in that case, there is the voice from Ray that's coming up. And I see that for this kind of job, we talk about the innovation that we cannot guarantee the time, but they need it, or at least if you have a better understanding of the industry, I can be better. I feel...
Again, how can I find my niche? That's the pain point, I think, or am I wrong? What do you think, Guys.

**Ray | 17:17**
I'd like to invite Ellie to the conversation. I mean, you asked a question at the end, and we can be touching on that. Ellie, I'd like to keep the door open to what we were originally asking, like your take on using video and the issue of marketing to be speaking to your audience.

**Ellie Rofe | 17:38**
On a personal level, I've not personally broken out beyond the great network stuff because I've been inconsistent with content in the past, and I'm really early in the days now.
There is a big question of whether, for example, my target market is finding people where they are and if my target market is on LinkedIn, are they scrolling enough? Are they seeing my stuff, et cetera?
That's a whole separate question, really. Well, it feeds into it, I think. I think when you're talking about niching, and I know that is... That's what everyone's obsessed with. I do understand why you need a clear message.
If the videos could have all sorts of amazing content in them, but if people don't know why they should care about it, if it's not really completely tied to them, then they're not going to click play on it.
So I do understand the niche question, and I think they are somewhat related. So I guess the first question I'd ask you is, there are a number of ways into niching, and it can be difficult because it can feel like the old decide comes from the same root as suicide and homicide and things like that. It means to kill off an option, right? You're going to have to kill off something to choose one thing.
So it can feel quite difficult, but I guess one of the things I would ask. This isn't the only thing, because people put way too much pressure on this, but what? What do you actually love in your work? What type of engagement really does light you ups?

**Speaker 3 | 19:32**
That's a nice question because I can give you an answer. Why? The engagements I liked the most were those engagements where, first of all, we had a nice mess with the client. Secondly, we had a deeper conversation about their internal operations so I could give them better suggestions to the point. Instead of they came to me and asked for a standard workflow and for me to go and build.
Those were the client engagements that felt successful, and they shared the feedback with me. They said that we enjoy what we have on our hands, we like it, and we do progress with that. So when I have this feeling in my collaboration with a client, it's about the feeling, not what I'm building. I may build something of even a paint.
If they like it, I get the reward back, and this is what I enjoy.

**Ellie Rofe | 20:46**
And you say a good fit, I'm trying not to put words in your mouth, but I'm happy to give you ideas as well if you want them. When you say a good fit, what do you mean? You said... When? We're a good fit.

**Speaker 3 | 21:00**
Nice. We have a good fit in terms of how do we match personalities? I'm a little bit funny. I'm more open, more talkative, and more engaged. So if the other side doesn't talk, you know it's about the personality. Actually, it's not their industry.

**Ellie Rofe | 21:22**
Yeah, got you.

**Speaker 3 | 21:24**
Totally.

**Ellie Rofe | 21:27**
And I think industry might be a red herring. There's two other things, if you don't mind me constantly asking because this is obviously something I've done with people.

**Speaker 3 | 21:37**
Be assur. Absolutely.

**Ellie Rofe | 21:42**
One of them is, I think when you said the technology itself doesn't matter. You've studied business, haven't you?
Business is a big passion of yours and you're really interested in it. I think part of your niche is not the technology at all. Your niche will be...
This won't be exactly the way to put it, but like an operations expert or someone who is obsessed. Maybe part of your thing is not just talking about the operations you've done, that the operations changes you've made, but the results. It gets the job done that you get of making this process smoother so the business can go faster. Making this process cheaper. Or making this process more profitable. The whole point is where you fit in with the business, not the technology you're doing.
I think maybe if you're doing personal stuff, you talk about the things you love about business or the things that inspire you, the reason that you love doing it. But if you're talking about benefits to them, you don't just talk about the flow, you talk about how it enhances the business profitability or the operation.
I think that's what I mean. You actually... I think you're underselling one of your biggest advantages, which is that you are not a tech expert. You are a business expert who uses tech to get people to where they need to be with the business.

**Speaker 3 | 23:31**
I like this phrase for generating slogan.

**Ellie Rofe | 23:36**
Yeah, it's a differentiation. It's not complete differentiation yet, but it's a good start in terms of trying to identify where you're really bringing benefits. Another way...
If you don't mind me sharing a screen quickly, this can sometimes be useful. So, I'm about to show you something. It was designed by a brand strategy tutor of mine. So, cue us to him. This is a way that, when you're doing Brian's strategy for a larger company, you would define their voice based on who their customer is.
So, for example, Disney is the magician's voice. It's all about magic and the possibility and all that kind of thing. Dove soap is the innocent, right? It's clean, pure, safe, et cetera. That doesn't matter for this purpose. When you look at these people, when you see these one-word things and these kinds of archetypes here, which two or three are you most drawn to personally as the people that you would like to work with? Just go with your gut instinct.
First of all.

**Speaker 3 | 24:56**
Yeah, I think a creator innovation.

**Ray | 25:10**
Control.

**Speaker 3 | 25:11**
Ruler.
I would say mastery the hero.

**Ellie Rofe | 25:25**
Okay, the reason I ask this is because those three in particular, you don't have to have you don't have to sort of go with all three, but those three in particular, when you're talking about stuff, I mean that absolutely feeds in to what we were saying about the business side of things. You give people control so that they can get power.
So that they can get their business to succeed. Their business can become this kind of ruler archetype. Whatever. You do things really well to achieve mastery. You won't be able to be the hero of their business. I'm not saying this stuff has to be in your marketing. I'm saying when you're thinking about the kinds of people you want to work with, it sounds like you want to work with very ambitious companies who are obsessed with mastery or leaders who are obsessed with getting results. They're not just ticking over, they're not just trying to extract a bit more margin. They're people who are trying to leverage bigger returns on stuff.
So, whether that fits you into a specific industry or whether that fits into the person that you are trying to reach within companies and how that frames the way you talk about the work you do is I mean, this is a way of nicheing. You can start thinking about it like, who do you want to be talking to? Does this make sense? Or is this feeling a bit woolly and
unfocused?

**Speaker 3 | 27:01**
It's it makes sense. I think I have to read more about this framework to have a better understanding. For other profiles here, and how the combination effect.

**Ellie Rofe | 27:18**
Yeah, I mean, you can choose one or two. Maybe we can do a proper session on this rather than me just trying to throw it in as a side thing now, because it is quite an involved thing to discuss and explore.
But I think what I'm trying to say is that nicheing doesn't have to just be an industry. It doesn't just have to be a tool.

**Speaker 3 | 27:37**
He.

**Ellie Rofe | 27:39**
You can niche to a certain need. So, for example, I... This is always a really good example. I was working with a woman who did organizational home organization stuff, right?
A lot of her stuff was talking about... To be honest, it sounded derogatory because I think it was on some level internally for her. She was talking about people being a hot mess and things being terrible and things being all crazy.
She was working with people who were probably nearer, like outlaws or just wanting to be explorers. They were all free. They were all chaos. When I actually talked to her about this, she was over here. She was in mastery, and she wanted to talk to people who wanted perfection in their lives, and she wanted to take them from my home's nice to my home is perfect.
So she was talking to completely the wrong people. It came across in her marketing, it came across in her brand that there was this massive mismatch between what she was doing. I'm not saying you're that extreme or anything. I'm saying that you just have to know who you want to talk to. Who, actually?
Because when you're a consultant, there are so many different people you can talk to. So, who do you want to talk to? How do you want to talk to them? But we can do a proper session rather than, and if you want, we can do a round table session with the group as separate to this mastermind because I don't want to hijack this entire session, but it's a useful way of trying to think about niching. What do I love doing? What am I good at? How can I be different from other people? Who do I actually really love talking TOS?

**Speaker 3 | 29:24**
Yeah, that was super helpful. I'm already having some thoughts, and I think as a nice idea, bringing that on a marketing session, like a webinar, reviewing this framework, it seems so interesting.

**Ray | 29:47**
Very cool. Yes, the question... Understanding that the type of person you want to reach out to makes me think about the two big questions I ask on the marketing side: one, who do you want to be a hero to?
I know that's already using up one of the items in your chart, but who do you want to be a hero to? That's the game, the personal type that you're talking about. Second, what do you want them to become?
Right. So, what is the change that you have succeeded in the world if you have made this change happen to them.

**Speaker 3 | 30:20**
Right?

**Ray | 30:21**
And those, you start to understand who it is. You won't be talking to where you know you're talking to a segment of people who have something in common. Industry is often an easy one, but as Ellie points out, it's definitely not the only one. There.
And I think about it, like, three types of vendors that way. I think of a customer in need and a solution as being the three things that define a market intersection. You can have affinity based on your segment or your demographic.
That's the customer part. You can have affinity based on having come set needs and a set of problems. For example, a sales professional often has similar problems. They're sales professionals. They go and work in different industries, but their job is always sales.
Then you have a solution, which is given their affinity usually to doing things a certain way. This gets to the kind of work that they do or that they haven't found for it. Robert, you're thinking like working with Universe right in Rocket Software, right?
So people who are in that Rocket Software zone, these are all people who have affinity based on a given solution that they might be using for different needs and for different whatever. Then, within there, probably come up with a separate question like how you are affecting them or would be speaking to the people who are at that given intersection anyway. I bring all this stuff up partially because I think you... There's a question of who you want to be speaking to. Who does it get you up in the morning to speak to that you want to help them? You need to like them.
If you don't like them, you're just doing it because you have to do this. The way you were describing the content felt very mechanical to me. I think I'm putting up one thing that is a screenshot and one thing that is a video and one thing that is a personal note.
I get where that comes from. We all make plans, and the plans eventually start reading fairly mechanically, right? But like, what is it that you are excited about so that your energy about that topic is projecting through?
And the reason I like the personal stuff I talk about using video and using personal whatever is to... So that idea of you as an attractive persona, right, can be getting into the market. But it needs to be attractive to them.
For the thing they care about. For them. So I think of three things. What is... There's the attractive you talking about the subject that they care about with something they can buy, right?
I think that there's a tricky bit here where we get stuck on one or the other of these. Then there's a thing that you want them to buy that you wish they would buy, and then there's a thing that they are ready to buy.
This is where Priestley becomes really useful because that video, the one that you put up on, say, change... We talked about last week because of the idea of first starting with what their pain is and having that be the thing that you're marketing to. How can you talk more about that?
That's one of the reasons why we're talking about the whole survey thing with Ali, right? It's to get greater clarity on the bigger picture of that pain that you then fit into. But the other key thing about it is that the thing that they're going to buy from you first isn't the thing they're going to buy from you last, right? He talks about free product, proper prospects, core product, and then proper clients, right?
The drink... I want someone to go buy a $20,000 engagement from me. That's very hard to get them due on day one, right? So how...? What is it they can more easily buy from you on day one that will get them value and returns on the experience you've had with you so far? Vaynerchuk has the jab, right hook, idea that basically you put out three pieces of content that are about that thing of you being attractive and about the subject you care about.
Then number four, if you're doing that with a... By the way, I do this right that way, not every piece of content is a sales pitch. I was just talking to Unico about this. They're an Indian agency that advises.
I was talking to them about how their idea is that we need to make a case study, that's thirsty sales content. What you need is thought leadership material, right? Go out there and be the people who are talking about subjects that their clients care about.
That's going to put them in a position where a follow-up piece is going to then be... We do this. By the way, people are smart. They know that if you're talking about the subjects, probably because you do it professionally too.
But I think that part of this is just regaining the gaze on what you find to be helpful, right? What is it that you want to do for these POG people? You've learned a lot about how to do this content right. You actually, I think, do it better than most people do.
Then it needs to be aimed right at the right people that you care about. When I say the right people, I just feel like, who do you really want to help and what kind of problems do you want to help them with?
Not for nothing, I think you do video well enough that you talking about doing video is actually a pretty good topic.

**Speaker 3 | 35:30**
I don't know if it's a good topic for most of the contacts I have so far. Yeah, it's a good topic for most of the contacts I have so far. Are people from a stage-age community? Would they talk about it because I try to inspire people. Robert, Ellie, and other guys too, in doing that because we shouldn't see that difficult stuff, but for the audience I want to serve and I want to charge. I don't know if I know how to do a video concept that would be interesting.
First and second, not engaged video cannot teach them how to make a video. [Laughter].

**Ray | 36:21**
Well, sure, this does put you on the spot to be doing things well, but I would posit that you do that. There's a little bit of impostor syndrome sneaking into this conversation here, right? There's a useful thing of like, "Hey, what can I do better?" How can I, Rose? How can I do things?
There's a little bit of the feeling that comes into this. I want to be attentive to how people are feeling, but I'm not going to agree that you are an impostor.
Right. I'm going to tell you that you do video better than most, and you do, and your focus on how to help people with business. Yeah, you got those two things together. You got like... Wait, what did the business people want to help want to do? They want to increase their income. How can they increase their income?
Think of it as a business person, what's the big thing that's missing? What are you finding to be most effective? What's missing out there that they could be doing more of that they're not taking care of today?
So, you've done this thing of talking to customers, right? There's the customer service aspect of it, there's how to get more customers at the beginning. There's a... You've learned a bunch of lessons and have been helpful to people inside State Change. Leave aside the fact that they're selling technical services where there are people who are not selling technical stuff, who are selling real estate, right, which you have now a better idea of how to do perhaps than most.
I guess what I'm trying to get to here is you're developing areas of expertise where you are not only using X to CL Y but you could potentially use X to sell Y, and that might be a much shorter ridge, and have people that care about that issue. Now, if you don't do X well, no one's going to want to buy it from you. I take your point.
But if you do X well, and I'm positing that actually, you do it better than the most... There's juice in there, at least to consider and less to consider. I'm not trying to say I think you should be selling video consulting services, per se. I'm trying to get you to think a little more broadly.
Right? Who's the audience? What problems do they have? As opposed to... What I want to do is build AI agents, right? That would be like a solution of Andy, right? But now this creates the bigger thing of now you've got to find the people who actually want to buy that particular product from you as opposed to people who you like and who have that certain sense of pain. What is the look at looked at more broadly? What do they need that can then more easily become your product for prospects anyway? That's why I was hearing what I was thinking about that, trying to get off the mechanical part into who these people are, what do they really need?
Then, being a little more expansive in your idea of how you can be adding value because you have skills today on multiple dimensions. You weren't doing AI agents when we first met, but you weren't doing video when we first met.
Just looking at what that broader spectrum is that will be able to create value for them as well, that moves the needle on their income in a shorter period of time because you put those two things together, and now it's making the money in a shorter time frame, which reduces risk.
That's a far more viable proposition, and not for nothing, you mentioned Adam earlier on as a client you really liked. Are you on Codementor now?

**Speaker 3 | 39:56**
E theoretically, yes, in practice, no. Because his manager is on summer leave, he had two weeks off.

**Ray | 40:08**
What does that have to do with anything? I asked if you're a code mentor on the site.

**Speaker 3 | 40:12**
Could you bet it?

**Ray | 40:13**
Sorry, code mentor. Where I first met Adam, are you yet?

**Speaker 3 | 40:19**
No I'm not there because they are more technical.

**Ray | 40:25**
And yet you met him there?

**Speaker 3 | 40:28**
No, Adam was a referral. I was referred to Adam by you.

**Ray | 40:35**
Where and where did I meet him?

**Speaker 3 | 40:38**
In there, but because you are an expert.

**Ray | 40:43**
Yeah, but the fact that I have whatever expertise I have doesn't mean there's not an opportunity for you. This is all what I mean by imposter syndrome, right? You're taking things off the board because of assumptions you're making about yourself and your relative skill level.
I would encourage you to... I think this is a little bit like the psychology that was passed through the original content part, getting you into LinkedIn, getting you doing the kind of things you're doing where you are now at the end of the spear on that. Similarly, I think if you go into these others, you'll find, but there are a whole bunch of people who really know what they're doing in there.
Yeah, but you can go in there and you can make a big difference. At the very least, you'll be able to see what's going on in there and be able to pluck out the atoms of the world. Because the problem wasn't that Adam couldn't find a technically good person. The problem was that he was. He was surrounded by, like, you know, frauds from South Asia or whatever who are promising that you could do something for them and then not being able to meet that promise, and you are able to come and meet some promises.
So anyway, I'll say this by way of saying that I particularly, if it's a kind of live work that you're looking for, that becomes an interesting situation. Just thinking a little more expansively about those situations to say, "Wait, I found something."
Where they tend to swim over here, give them that pond. This will all just make it easier for you to go find more of these people who you like working with. Okay? Anyway, that's what I had to say about the audience and the nature of the fans there.

**Speaker 3 | 42:19**
Okay, yeah, I'm sorry.

**Ellie Rofe | 42:23**
Don't know what you're going to say.

**Speaker 3 | 42:26**
No. I just... Agree. I have to think about it.

**Ellie Rofe | 42:31**
It of the things I don't want to... There's always talk of algorithms and stuff, but one of the things I have noticed more and the consensus across multiple different things seems to be that LinkedIn has changed its algorithm.
There are two things to that. Firstly, not that LinkedIn is still a good prospect, but what seems to be happening is that whatever content you put out is being really highly signaled by LinkedIn to give you a very tight group of people who want to see that content.
So I think there is a question of getting really clear on who you want to be putting content in front of, because content that's interesting for other tech people, for example, might not be content that your clients care about, and so it might not get in front of them on LinkedIn.
So being really intentional about who you are talking to seems to be more and more important on LinkedIn. But to back up Ray's point, trying to find direct points of leverage with the people rather than outbound LinkedIn, let's try and build and get engagement and get reach and build my network. Trying to find areas where you can directly find people who have the problem and talk to them. There is probably a faster route than LinkedIn at the moment.
That's something I've been thinking on and off about. It's partly why the VC's comments to me landed on OpenAI. We probably do have to try. Physically for me, there aren't that many remote meetups.
But physically for me, I do have to just go and be at conferences where people are. I do have to talk to people. I do have to try and get in touch with people directly. But for you guys, when you've got specific things you help with that are digital and remote and there are communities based around those things, getting there and leveraging those...
Really then, on LinkedIn, hyperfocusing on the people that you want to be talking to, their problems, the stuff they need to be seeing, that might be a nuanced strategy that gives you focus rather than this feeling of "I've just got to keep generating content about what I'm doing on some."
It might feel a bit vague, especially if you are quite... You hold yourself to very high account. You are a high performer and interested in mastery. I think maybe some of this disconnect is because you're not feeling like it.
It's you. I just feel like it might feel a bit vague. Which is why you're searching for this positioning piece. I don't know if that makes sense.

**Speaker 3 | 45:43**
Yeah, absolutely. I see the power of joining communities. I feel like because the communities I found so far are built on Discord and Slack. They have thousands of people, and the post thread is getting crazy too, messy, so it's quite hard for me to track conversations, follow subjects, and engage with subjects. All of this was quite challenging for me, so I dropped it quite early.
So, yeah. But I know that if you are specific, place it works. I do something similar with the Zappier community and the office hours. Once a week, it's going fine, but not that much engagement yet.

**Ellie Rofe | 46:28**
What? about instead of going in there as a consumer or as a peer? What about people who've built a community? Who want people to come in and give talks? Who want partners? Who wants someone to come in and help in some way.

**Speaker 3 | 47:01**
But the community manager is off, which totally matters. I had a presentation last Friday to another community where the engagement wasn't that much.

**Ellie Rofe | 47:16**
Hu.

**Speaker 3 | 47:17**
I don't know why, but by default, not too many people are joining.
But it was fine if I presented to three people and had some feedback and so on with five people who are right there consuming my thoughts.

**Ellie Rofe | 47:27**
No.

**Speaker 3 | 47:32**
I didn't have.

**Ellie Rofe | 47:32**
What about rather than tools-based or tech-based communities, what about business communities or entrepreneurial communities where you go into a larger community as someone who says, "We can do X. We can show you how to do Y. Come to me if you want."
I'm not sure of that formula, but the people that you need to talk to aren't necessarily people self-serving on Zapier. People that you need to talk to, people who are trying to take their business.
This is always another question: take their business from naught to one? Are they startups or are they taking their business from one to a thousand? Like, who were you speaking to and can you speak to them?
Because the owners of these groups need content. Anyone running a community needs content, and they would be struggling to get content sometimes.

**Ray | 48:28**
Yes.

**Ellie Rofe | 48:33**
Now, I would go in there, talk to them, and start getting in touch with them, but find the niche. I wouldn't necessarily go in and talk about AI agents because they might have had a load of that stuff by now, but just go in there and talk to them about operational changes or something.
But what I'm saying is you're looking for people who aren't self-serving already potentially, and you're looking for people who sit in that group. You're talking about the people you want to work with who are really smart, energized businesses. They have some operations in place to improve. They're not people who are just building a business from nothing to one. Probably, this is where really identifying and being clear about people can help you work out who those ideal partnerships are.

**Speaker 3 | 49:26**
Yeah, that's a good idea. One of the communities I gave the presentation, they said they are in the domain of entrepreneurship, business, and tech at the same moment. But their community is haltic.

**Ellie Rofe | 49:49**
He but.

**Speaker 3 | 49:49**
They have tons of channels to talk about different subjects. It's quite well done.
Well, I can't follow a conversation. I joined many conversations for networking presentations and stuff like that, and I felt it was chaotic. I didn't feel comfortable doing that. Okay, I have to find a way to do that.

**Ellie Rofe | 50:15**
I think just talk. It's a bit like pitching for a podcast appearance. It's not joining the group and trying to hawk your wares in Discord, which I can't understand how anyone uses it. I can't stand it.
It was chaos, but it's not about that. It's saying, "I want to come on your podcast to talk about this, but instead of a podcast, I want to come into your community and talk to you about this." That sort of pitch...
Because then you are the expert, you're giving the talk as the expert. I know that might feel uncomfortable at the moment, but if you're lining it up with the business side, not just the tech side in terms of how you approach things, then you've got an angle.
As I said, I'm happy to brainstorm stuff separately because I feel like I've talked way too much in this hot seat, but I am happy to just brainstorm stuff separately around positioning and who you can be talking to.
This is the point. This is the power of positioning that comes from identifying exactly who you're talking to. Once you've got that, you know who you're going out to specifically. Are you talking to people who are dealing with startups, or are you talking to people who are dealing with dentists who are growing their business or so many different options?

**Speaker 3 | 51:36**
Makes sense, yeah. Be the positioning matters most important.

**Ray | 51:44**
The filtering can matter too. I was thinking about the kinds of communities you're talking about. These are big free communities. They're heavily polluted with vendors because every vendor just goes to every free community, and then you have a whole bunch of foxes, right? An addition to not that and her many chickens.
One of the reasons I put up a dynamite circle and Exit 5 is that they are entrepreneur communities and Exit 5 is a marketing community for directors marketing and higher. Actually, it's based on Exit 5, which is here in Vermont.
Both of those are paid communities, but inexpensive paid communities. They are very much not technical. I was really surprised by DC, "Wait, there are entreo communities, aren't they about technologists?" Yes, it's apparent there's more to the world than technology.
Finding those people who can be handy as well, just so you can find someone to speak to, is different in this regard. They're not already technically inclined. Here you are with some interesting ideas.
I think you have a lot to say. You put up some really compelling things. I think I keep on seeing you're getting closer to putting up things that are really quite innovative on the tech side. I think they are, the visual aspects are getting you a broader appreciation on their side.
I think the position in question is really good because when I think about what's going to be easiest for you to turn to, I suspect customer need and solution need is the most obvious one for you to go to the most obvious axis, right?
So what is the need axis that you can be helping people with? When I think about the need axis, there are basically three things you can do to improve a business, right? You can cut costs, you can cut risk, and you can increase revenues.
Increasing revenues is the most obvious win, and it gets you the most senior attention. So if you're working with small companies dominated by the senior because seniors are the only ones making any decisions. Therefore, what they really want is increasing revenue.
So when you talk to entrepreneurs, you really want to be increasing revenues. Now we're going down the road of you helping people with that. Then what are the tools you have in your toolbox for that?
That's what you've been doing with Adam. That's interesting in that regard. This becomes the agentic whatever, not about decreasing their costs, but about increasing their revenues. If you can be talking about that, I think you'll be on a short list because most people who work with tech, particularly automation tech, keep falling back to it, and it's so much more efficient. So, how are you going to increase my income?
I think not everyone talks in those terms because it's not so much welcome and polite society, right? But that's what they buy. Yeah, when I think about it, hey, what have I been buying recently in terms of tools or whatever?
It's all things that are towards increasing my income as well. They might have an indirect path to that, but that's clearly the path that's on. I'm not trying to decrease my cost per se. I'm spending to increase my income.
Yeah.

**Speaker 3 | 55:08**
And that's the challenge because I do... As you all, guys, we're spending in that purpose in that direction, we want to see the return on this investment definitely.

**Ray | 55:23**
Right How to spend a little bit to get a lot, right? You want those returns to be good. So, one of the reasons I was brought up in those two communities is that they both are double-digit monthly expenses. They're not triple digits, not super expensive.
It's not like joining a golf club.

**Speaker 3 | 55:40**
Right?

**Ray | 55:41**
Yeah, and they're certainly not the expenses like going to a conference where the ticket for the conference might even be free, but it's going to cost you over a thousand because you've got to travel and whatever else, right?
So, there are these other opportunities along the way that are available to you. But this is not to get you to think about spending more money, but just how to talk to customers in a less polluted environment.
Now, especially now that you've created more content and the way you create content is interesting, you've got lots of interesting stuff to talk about. Let's just get you talking about it to more people who matter.

**Ellie Rofe | 56:16**
You don't necessarily even have to join the community; you can just contact the person who runs it. I swear to God, everyone who sets up a community,
and there are tens of thousands of them. Some of them have a hundred members, some of them have 10,000. Whatever it might be, every single person who sets up a community needs people to come and talk in it.
It will vary as to who they want and why they want them, but not everybody has to be from within. Not every one of those will expect you to be a member of the community, so you know that I know that there are communities for training dentists to run their practice.
I know that there are communities for mums who are homeschooling. There are communities all around, and this is what I mean about positioning. You might not want to talk to those people, but if you work it out, the ones you want, then you will soon find that there are hundreds of communities that you could go and talk to, and you don't even have to necessarily join them.
Because those people, when they bring people into those communities, they promise them that there'll be two talks a month on this and there'll be this happening, one expert speaker and blah.
So, they have given themselves an SLA that they have to commit to, and then they're trying to find people who can come in and talk to them about stuff.

**Speaker 3 | 57:46**
That is very useful. I'm sorry, sports.

**Ray | 57:49**
I was just going to say that like state changes. I mean, if you spend more time with state change, you can find it very unusual as communities go in terms of its engagement per member, it's really kind of off the charts. N co is pretty engaged.
I think both of those are a statement of the level of involvement of their leaders in the form of myself, Stchan, Claudia, N co, and then you go to a bunch of other communities, and nothing's happening, but they're paid communities. Paid communities are good for this, right? Where somebody who's paying a ticket for this content is trying to bring people in who will be participating.
I think you're going to find that when we look at paid communities versus looking at the unpaid ones, they get different results. One final thought, just quick thought as it relates to this. I appreciate we're out of time.
To Ellie's point, looking for these communities, circle explore, there is a circle discover, one of those. So the circles communities of software that I use, they've been hitting me up a little bit, like, "Hey, you should go put yourself up on Circle Discover, which I don't really care to do."
But there are a bunch of other communities that do and that have, I think, a very much profile of what Ellie's talking about here. The fact that they're putting themselves up in that community makes them much more findable by you and create some interesting opportunities for that kind of speaking engagement stuff that you can be doing on a win basis.

**Speaker 3 | 59:14**
Yeah. Thanks, guys. That was very helpful, Honestly.

**Ray | 59:22**
Fantastic. All right, everyone. This is the NP hour. I was absolutely delighted to work with you today, and I'll see you all at the end of the week. We'll do this again next week.

**Speaker 3 | 59:32**
Bye. guys.

