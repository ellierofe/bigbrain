# State Change Mastermind - Dec, 23

# Transcript
**Ellie Rofe | 00:03**
[Laughter] Hello Ray, how are you?

**Ray | 00:05**
Good afternoon, Ellie, I am all right.

**Ellie Rofe | 00:09**
[Laughter] Good in Hertfordshire, one of the chs hello very well you yeah, same it does.

**Ray | 00:11**
Do we find you in London today or in England?

**Demitris | 00:24**
How are you pretty? Well, nice new look.

**Ray | 00:34**
It looks different.

**Ellie Rofe | 00:35**
No, I'm in. I'm in. I'm in Britain. I'm in Hertfordshire. But you're somewhere new. 
Yeah.

**Demitris | 00:44**
Okay, yeah, that's true.

**Ellie Rofe | 00:44**
You're back at Family five?

**Ray | 00:52**
Dimitri, for some reason, you're coming through kind of blurry right now. Is that about your connection or is that the camera thing or what?

**Demitris | 01:01**
The camera, I guess.

**Ray | 01:03**
Yeah, the camera seems to focus. Now we're getting somewhere. I like it's a technique to make the other person think they're going blind. Wait, maybe I need chairpin classes. [Laughter].

**Demitris | 01:16**
Usually I did before I joined, but because it was a little bit late, I click joined immediately.

**Ray | 01:27**
All right, well, we should get Robert here in just a minute, and we'll get going. We'll go around the Hornet and we'll do the hot seat. Can I ask like, are you all now where you want to be for the holiday? Assuming that you both observe and we're absorbed basic means is a family thing or whatever like this. I appreciate there's people who treat this different ways.

**Ellie Rofe | 01:53**
Yes. Yes, Thursday morning.

**Ray | 01:56**
Yeah, I will have a long drive ahead of me on Thursday morning.

**Ellie Rofe | 02:01**
You're traveling on Christmas Day itself. Where are you headed? To?

**Ray | 02:08**
Headed down to Boston, which is a major city about 200 miles south of me, and that's where I've got two sisters.

**Ellie Rofe | 02:10**
One. One.

**Ray | 02:17**
My MoM and my brother flew into town with his family. So it's going to be we're going to be four out of five in terms of us siblings being in the same place.

**Ellie Rofe | 02:24**
That's impressive.

**Demitris | 02:30**
Very gath.

**Ray | 02:32**
It will be. Yeah, it's [Laughter] gonna be a day, [Laughter].

**Robert | 02:41**
Ray. Ray, you have. Wait, sorry, I forgot I turned on this space bar thing, and now I have it on, so I was just kind of sorry. I was gonna. Ray, say, Ray, you have three sisters or two.

**Ray | 02:54**
I have three sisters and one brother.

**Robert | 02:57**
Okay.

**Ray | 02:58**
My sister. I have two sisters who are physicians. One's a lawyer. And my brother, until recently worked for De MIT, and he went to join another one of the Reflection AI, which, you know, shortly after he joined.

**Ellie Rofe | 03:05**
Very nice.

**Ray | 03:14**
They raised $2 billion. 
So I'm not saying he's a two billion dollar guy, but, you know, [Laughter] they have him pretty close to each other. [Laughter].

**Robert | 03:25**
Very cool.

**Ray | 03:27**
As I tell my wife, you know, she weared the dumb one, the let's go around the horn. What kind of week has it been? Betrice, can we start with the user what kind of what was true today that was not true a week ago?

**Demitris | 03:43**
Many things I would say. The first thing is, I found a nice way working my communication with a nice work we've done with AE last week was incredible. I've already started working. I found something. I was not that good. 
So it's an opportunity for me to make some improvements myself, which is brilliant. And I found somehow a nice way to give a taste to someone who gets into a conversation with me on Zoho. How best knowledge base can work. 
So not something that's sophisticated. I just create the nodes from the nodes space into CSVS and send these as an output back and with directions how to use them. So they just get into their chatbd, upload the files and they can start performing questions. Based on this conversation, I found it not that useful, but it's a nice experiment for them to have a little taste of what kind of problems and what kind of information they can have from that. 
And I'm going to work with a consultant who is a a client for experimentation to build a knowledge base for his consulting service and for a community he's running and I'm a member of building the community's knowledge base in one place. 
So in terms of the knowledge, I pushed myself this two weeks to improve my knowledge around the knowledge basis, learning new methodologies and reading some scientific articles and record myself the most I can.

**Robert | 05:43**
TYP Cool.

**Ray | 05:45**
Okay, good. I appreciate that day. And, Robert, what was true today vers a week ago.

**Robert | 05:55**
So what's true today is I had a positive discussion with my client to just get on the same page about invoices and stuff. And it was positive. I felt like it was there was always I think a good. I feel like money discussions are a good way to put things into perspective a lot of the time for both sides. 
And there's always a way to. Like there's always a benefit to it. Like, even if you feel like you're working a lot and you've kind of overworked. And there's a way to work less than going forward to make up for how much you've already done. 
Like you. But if you don't say anything, then you're going to continue to go red line all the way through, right? Like. And so I think that, like, just having that money discussion was good just because it kind of like, reaffirms or reframes the value, I suppose, and just reminds me like, okay. 
Like, I'm getting a little comfort here, like the kid, but this person is, you know, like before they get too comfortable. So that was like a muscle that I was exercising, and, that felt good. It's off of my mind. It feels like I can focus now, actually on the things that matter more, which is maybe where my motivation to do to catch up on those things that comes from. 
And then otherwise, it's been a lot of working for my trying to make stuff. Although I found myself with, like my computer on with like three different IDS going at the same time. I have. I'm developing a lot of things at the same time. Some kind of just trying to build more agentically. 
And it is a holidays, so, but at the same time, I'm pretty. Nothing, you know, lucky, I suppose. Like, nothing really changes too much for me, so I'm still chugging away here a little bit less from the outside, just more inside stuff. Just because of the nature of the holidays. Everybody is pulling back into their caves. 
So I you know, and there's not that much external interaction as much as there would be.

**Ray | 08:25**
I think fair and certainly that's something I'm finding as well, right? Like meetings are dropping off through the end of the week. It's a shocking like. I actually just. TED to have an office hours for SE change this morning and I got ghosted. 
I think people are like they're like my hardest five percent now is like trying to take care of the last two shopping days for Christmas or something. Like that's just right. [Laughter] But I'll take it. I hear what you're saying. Okaylie, so can we do a check in? 
Like what is true? Say that was not perhaps true this time last week, and then let's get into your hot seat. How can this group be of service to you?

**Ellie Rofe | 09:09**
What's true today. I have had two lovely engagements over the last week, one with Demetrius, which was really interesting and pushed me into more creative writing communication realms, which I haven't done for a while, so it just felt very, delightful to be there and obviously delightful to work with Demetrius. 
And I think, actually working on those hooks with you, Demetrius, helped me think about them too. We realized that was a very cultural thing for Demetrius in terms of hooks that sound too salesy, and to sort of, save 15 hours every second by doing XY and Z, you know, and so, like, we worked on some really interesting hooks that were still hooks, but were quite philosophical. 
And so I'm starting to build stuff with that too. So it's really interesting. And then the other one was with Maddy at Lumia. So they're a textiles materials advanced materials company. And it has been it's been really interesting and very challenging in the. 
And I think this is one of my questions about ingesting. I know I asked about research before, but whether you have ways of ingesting and managing information. Because I have had to very quickly get up to speed on physical AI as a market. All the different verticals within physical AI IE Humanoid robots, cobots. 
You know, excuse me, gloves, vehicles, agriculture. MI just trying to understand that and then within that, try to understand specific markets that would be right for tactile sensors. So I've had to understand tactile sensors themselves and how they differ from other sensors. 
And within tactile sensors, understand the difference between optical and gel and printed and like, lots of different sort of mechanical engineering type stuff. Not in depth. I'm not, you know, trying to learn it all. 
But understand the pros and cons and the relative value and. And that's whilst doing analysis and trying to help with, for example, market projections and revenue projections and potential market capture and things like that. 
So it's a huge amount of work in a relatively sort of short space of time. And I one of the things I found and I don't know if anyone else finds this, I have found that AI can be like not just drinking from a fire hydrant, but actually setting up a number of fire hydrants. 
And then trying to drink from them all at once. Like, there's so much information, there's so much stuff coming out of it, and I can end up sort of even lost within the AI itself. So yeah, any ideas on ingesting, managing, categorizing or how to structure? That sort of thing would be great. 
I think I'm sort of feeling my way through it and getting there and getting a bit faster. And I obviously have my sort of strategy map across which gives me some areas of some ways to categorize things and make sure that I'm covering the things I need to cover. 
So that's one of the things. And the other thing is, I spoke with Ray on Friday about how I feel like I start a lot of stuff and then not. I'm not finishing it. So partly, I've asked Ray to help me. You know, just give some sort of deadline stuff going on. 
So like do one day where I just trying and deliver something. But I guess I could if we're in that sort of vibe and it's quite a nice way to wind down to the holidays. I could show or talk about some of the stuff I've started to build and get some ideas from the builders on, you know, where to go or how to close things off. The underlying problem is that I try and make everything the everything project. 
So I was saying to Ray, I like I have something which is a deck repository. And then I'm like, well, I'll show analysis of these decks to show how I would look at them. And then I'm like, well, that, you know, then people should just be able to submit their stuff for an assessment. 
And then I'm like, well, if they're submitting their stuff and they're getting stuff there, then maybe it should be a tool that can help them develop the deck. And suddenly it's just like this. The everything project, it's instead of just actually shipping one thing. Excuse me, sorry, got some water. Unfortunately, this is I was on a plane yesterday and this is just inevitable thing.

**Ray | 14:13**
You get a little water there. Elie.

**Ellie Rofe | 14:24**
There was a woman next to me who was very kindly masked but hacking away. 
So I think unfortunately that mask did suiteafe c yes. I don't know if that's clear at all. Right? And the other bit of news, which I think is an interesting point. I had someone who I worked with ing like 20 years ago, and we kept in touch in various ways, and he wants me to help him with a kind of novel, sponsor. 
It's not novel. It's actually much more common in the US sponsored private equity. So instead of raising a fund, they find deals and then raise for individual deals. And he wants to help me with the deck by the 2nd of January. 
So I'm sort of wondering how to pitch that because the narrative is a mess. He's trying to pitch to four different people at once. And so but he just really Wants it designed up. So I'm like, how do I pitch that? 
And then he did the usual maybe I could pay you half now and half when the deal's done. So that's. I'm. I'm intrigued by that. But I'm thinking if he wants me to work over the holidays and I just have to put a higher price tag on it and know like, maybe you could pay me some of that once the deal goes through because that could be a long deal as well.

**Ray | 15:46**
M. Great. All these funds do have a quality. Okay, so where do you want to start? You've gone through a few different things that and they are all potential topics. 
And I think Roberts Northstar trying to figure out what his door knob question is what's the most important one. So you have working theory and then you go, wait, maybe that's not quite it, but like, okay, what? How is it we can have the maximum impact for?

**Ellie Rofe | 16:12**
Well, it's a good question.

**Ray | 16:12**
You?

**Ellie Rofe | 16:13**
I think they're all useful, but maybe having maybe it's how to finish off some of these projects so that I can get something done before the new year turns.

**Ray | 16:28**
Sure.

**Ellie Rofe | 16:29**
Excuse me?

**Ray | 16:33**
How about you want to share a bit of the in progress? Give them something to sink their teeth into.

**Ellie Rofe | 16:36**
Yes, let's do that. So, I think this is probably a sha sorry, my brain is getting a little foggy. 
Okay, so, I don't know if we can see the piton a tree.

**Robert | 17:09**
Okay, that's cool.

**Ellie Rofe | 17:11**
Excuse me. 
So, this was. This is a sort of database. And then you'll see how things may have become the everything project. So if we click there and they'll be everything's busted because it's been it's like a Frankenstein. Now, if we clicked there was like three different measurements of the actual strategy, the flow of the narrative and the communication. Design really. 
And then my take and stuff. And then we had a few full analysis of it, which I realized was just way too much information. I mean, partly this is the AI that has created like a sort of overly wordy analysis, but just a lot of information and a lot of different stuff going on here, including slide by slide analyzes. 
So then.

**Robert | 18:09**
Not to do that, by the way. It's a necessarily bad thing, like depending on who's reading it, I think I'm just saying. Anyways, I feel like cause you're send us a lot of information. I feel like that's relative. 
Like, you know, for a lot of information for. For what? Like, some topics require a lot of information to get the point across.

**Ellie Rofe | 18:27**
Well, that's a really good question. And I think that is what I have struggled with in the what's interesting to me in terms of what I do on a project and what's interesting to people who just are founders creating decks. 
So this bear in mind, this is just my analysis of I mean, this isn't actually a public one, but my analysis of publicly fund publicly available PITCHDEXS that have got funding already. Then this feels like too much. 
But I could be wrong. Maybe it's something that people would like to browse and find interesting. And then I then had the idea that actually, this is the sort of, you know, in depth assessment that someone would like of their pitch deck. 
And then I thought maybe this is too much like drinking through fire if you're just trying to get something out the door, because there's just too much information. Even if this was a bit shorter, there's so much information there. 
So then I shifted that and then I think, what's it under?

**Demitris | 19:39**
Did you build it with cloud code?

**Ellie Rofe | 19:40**
Yeah.

**Demitris | 19:47**
It's brilliant.

**Ellie Rofe | 19:47**
Thank you, very kind. I did some of the original design in Gemini AI Studio Gemini 3, which is much better in UX.

**Demitris | 19:59**
How?

**Ray | 19:59**
Okay, let's talk about the four, but let's get some feedback, clarifying questions.

**Ellie Rofe | 20:01**
So then I created something that was a bit, simpler. So again, strategy. 
And then this overview, which is that gap map that I talk about a lot, which is kind of like I think I need that to become core IP that and the deck flow analysis that people like. So it was a little bit less intense basically than the other one and a bit more visual, and then had this action plan. 
And this obviously has much more to do with someone uploading their deck because there's an action plan. Do you see how I mean, this is obviously, as I say, it's Frankenstein because I TED to do multiple different things now, and there's versions I think have just been lost to the flow of time as well. 
But do you see how I keep trying to make it the everything project. And I feel like I'm landing in between. Everything.

**Ray | 21:13**
What have you, Robert have really heard too much for you yet? Can we get your wayhe?

**Robert | 21:20**
Sure. I think that to me it doesn't. I feel like when you look at this, you're going to see something different than what that than what any of us see. Maybe you'll see the things that you want to be. 
And so for me, I don't see a Frankenstein. I just see a page, just information on it, and it looks like a good looking page, and I could imagine that it's useful to people. Maybe not. Not to me, because I'm in a very different vertical. 
And so but it's not hard for me to imagine when I'm looking at this of all the people that I've spoken to and all the different things that they're interested in that this not even the idea that they have that it's apparent to me that they're that people are attracted to the information like this. 
I think that they're attracted to look to learning how you did something like this as well, and from a whole bunch of different angles. I feel that I've seen you put together now, presentations like this like a number of times and in different with using different technologies and it's. 
And you've been just becoming better and better at it. I almost feel that there's just to against spitballing here, but it feels like there's a. It's just not that hard. At least there's a way for me to imagine that there would be perhaps interest in people just learning your approach to. 
Well, because you could teach someone how to do this as well. Like I think because there's a number of services maybe that you offer and it seems like there's a service, obviously, that's very like involved where you are personally working with them. 
And maybe, you know, as we've discussed before, there's like products for prospects and there's projects that get people going with you. I feel, you know. And just a quick question really to answer. I'm just probing and just to see if it resonates with you. 
But if there's a way that you could teach somebody how to do this for themselves or to at least some type of dimension of it, right like that would make sense with your perspective on the market. But you know, I'm sure there's I feel like there's aspects of this that could you could get them to take on and allow you to leverage some of that to your benefit. You're going to, you know, you. You're not going to get all the credit by the end. Ray has told me this a while ago and stuck with me. Which is like you can set them up and you might not get all the credit by the end, but they're going to grow and you'll get part of the credit. You'll get a good meaningful amount of it. 
But yeah, and I've just found interesting experiences with that, too, with putting stuff in people's hands and just seeing where they run with it. So, yeah, I'm just saying maybe it's a different way to look at this, because I see now you're putting this stuff together. 
And again, like I've now everybody knows how to put something like this together. I do but and in general, even when I the more I speak to people like regular people and like my friends and everything, if I show them what if I showed them this, there's no way they would never know how to make something like this. 
So I would just say that, you know, maybe there's another way to look at it.

**Ellie Rofe | 24:45**
So talk about. I mean, I have thought about, doing sort of internal stuff for people that I've worked on that I've worked with on PITCHDEX. Like, when I think about all the stuff that I have, had to learn about Lumia. Maddy has then sent me after I sent her like, analysis across twelve different strategy areas. She then sent me another like four or five different presentations and documents and stuff that have more data on Lumia in it. 
And, then I think, well, if they need to grow and they're working with external contractors, they basically need what Moogle was meant to be, which is like your strategy in one place. And maybe that's like a if I can show that I can build stuff like this, then that's the next step. 
And maybe that's the step where I work with Demetrius on Knowledge bas with them or something, but have something where they can actually have their own company and I'm showing them how either how to build or building it for them. 
But showing people what I've built or how I've built this puts me in that category of like someone who can manipulate these tools. Or.

**Robert | 26:16**
Well, yeah, I was gonna say those are all tools, like, and I just view them as tools. A point back to the interesting part, which is you that you are the one who is you. I just feel like there's, a little bit. 
And again, I could be. I could be wrong, but I'm just going to. Just what comes to mind for me is just feels like a little bit of overemphasis, necessarily on the tool when you are the one who brings. This isn't very useful, I think, to anybody without you being in the picture. I can't. Yes, it is useful to a certain degree, but it runs out of steam pretty quickly until you are there to take it to the next stage or explain where it came from. Or like, without you being part of the context just doesn't allow somebody to run for very long with it. I feel, which is fine, right? Same thing even with Snappy, right? 
Like people can't use it unless they really. And they can use it. Like they can' free to use it, but they can't use it. Really properly until they really engage with me quite a bit. So I would just say that, you can let your digital products benefit from that. They don't have to they can't really stand up on their own. These are things that are just demonstrations of the fact that you're just very interested in this topic in this space, and you're just trying to show off a little bit and show this is what you can do. 
And you think about this a lot and then you put it out there into the world and you let it do its work in that way. And then. And then it kind of if it. If it earns it. It earns more of your, you know, your attention and more of your energy. Then it benefits from that, and it becomes something that perhaps can stand on its own as you kind of take the scaffolding away from it. 
And. But in the meantime, between here and there, I feel like this is something that more than anything, just stands as a demonstration or proof that of multiple things of the fact that this is obviously it involves AI and it involves like the new development tech techniques. It demonstrates that you have experience in this field and everything. 
And those are all the things I think to put onto the market. I just feel like you might not you might be missing out on some of those benefits. By if you only set that target of if you only define success as like for this in turning the wheel of your business within the you know within the frame of that it has to be a product does XYZ and somebody that that's the only way that it can succeed. I feel that there's a lot of ways this can work for you. 
You know, even just now, the fact whatever you and you know, whatever you showed right now is already, you know, makes somebody. If somebody were to see this, it would. It would. It would be more. It's not something that every that you're, let's say competition or peers. Not everybody has this, right, so it's a bit of show on top.

**Ellie Rofe | 29:23**
Yes, it's a really good point. I'm overemphasizing. Delivering something rather than just shipping. The. The process, the ideas, the thinking into the.

**Robert | 29:39**
Kicking out the door or even just, I like, yeah, I would say just make it. Just they can do move it to the left. Move the vide to the left of the curve. 
Like, just make it instead of putting it out into the distance of. Like one day this will be this thing that. How can it just do something for you today? Because who knows what's going to happen? And like, you know, it's farther we look into the future, more unpredictable.

**Ellie Rofe | 30:07**
Yes.

**Robert | 30:08**
It becomes what we just know about today.

**Ellie Rofe | 30:09**
Yes, it's a very good point. Okay. I like it. Thank you.

**Robert | 30:20**
Sure.

**Ray | 30:22**
So, Ellie, there's some really interesting stuff in here. Like I look at this and think you create a little after yourself, that you should be just cutting some screenshots and put.

**Ellie Rofe | 30:32**
M.

**Ray | 30:36**
The purpose of the app is to one, educate people on how to think about this stuff, and to be promoting yourself as someone who's an expert in this field. Images do that just as well, right? 
It's like, I want them to be able to go and surf through the observatory. That's a fine higher level, but like, the, you know, when you look at this, like. Wait. But I've still got this, you know, local host thing at the top, and my login's not set up and whatever. 
Like but everything interesting is like between here and here, you know, give them that the images can be really a remarkable improvement. The and this, I think tells a great story because it's about bullets, right? 
It is actually far more consumable that you've done a good job here of, like, creating something that is that someone can look at and they can absorb and they can say, that's cool. And you know what else? I want more. 
You know what I really want to see? I want to see this all the way down to here because I want them to see this and have it be outside and have the answer to do I get it. Be outside the frame and then you know, and that becomes something you can ship today. 
Like, look at this. This looks so cool. How could I get it from here to there? Command shift 4. You know, I think it I think it's under indexed. Can you show us one of the more texty parts too? Because I want to just make a different kind of point.

**Ellie Rofe | 32:05**
E at 1 sec.

**Ray | 32:10**
It was the previous thing you're showing us like the jury, right?

**Ellie Rofe | 32:11**
Yp.

**Ray | 32:19**
So I actually took a screenshot of that top thing from the jury's verdict. Wrote of Chechy ts had made me an inographic. I will the both nano banana and the new GPT.

**Ellie Rofe | 32:34**
Yes.

**Ray | 32:35**
You know, a 1.5 image model are very cool. Now I'm not trying to say they're BL end all, but it becomes a way to take a wall of text and turn it into something that's organized more visually for super tiny work on your part.

**Ellie Rofe | 32:51**
M.

**Ray | 32:55**
And you can just sort of take these existing subscriptions you have which cost like, very little. And if you don't have a Gemini subscription, you pop over to AI Studio like you. None of this seems to be more than pennies, right? 
And the. And just be able to see what it creates.

**Ellie Rofe | 33:10**
No. No.

**Ray | 33:11**
And I dropped this in ChatGPT on my part, and I looked at it like, okay, how much what would I think about that? Like, I don't. I don't know how much you would like it, but the, and there there's, I suppose, you know, good reason to think that it's. 
You know what I'll do? Just with your permission, I'm just going to share it very quickly, just so you can see what I am seeing. And I don't know what's trying to show you right now, because. Boy, that didn't work at all. 
So let me try our screen instead, because this is just a tech demo, I guess. And you know, so I can take this, right, so I can open this image hopefully, you cr c which has lead jurors verdict and all that. I'm trying to get to open up a bigger screen and it's not cooperating with me and I hope you'll forgive me for that, but yeah, so like the.

**Ellie Rofe | 34:01**
No, I aving in.

**Ray | 34:08**
And I'm glad to send you copied it, but like you can just get this off. All I did actually, I would I just use Shoter to go, you know, o cr write the text right off the screen and then just threw it in here just to see what it'll be like. 
And I think this combined with a little bit more of your style sense because you can edit this say, hey, okay, here's my here's a key sale, my sales sheet get to do against that.

**Ellie Rofe | 34:27**
One.

**Ray | 34:30**
You might find that in just like a minute or two, you have something that takes what was previously quality but hard to consume right into something that, like, changes it up.

**Ellie Rofe | 34:35**
M.

**Ray | 34:41**
Like, part of this has to do with, like, being different kinds of learners, right? This actually research question you were asking before, like, how do you get all this like all this text? How do I think through it all? 
And the answer is we've got other senses we work with, and there are at least there there's, you know, reading learning, right, textual learning, there's visual learning, there's auditory learning, there's experiential learning, of course, and some of these are easier to just implement than others, right? 
And experiential learning is a whole different thing, so let's not worry about that too much. But being able to turn that into an audio program is relatively straightforward. Being and certainly being able to turn it and like you can use like even like notebook LM right? Does that job really well. Pull the audio move on. 
But this here is eminently shareable. You know, like once you get its esthetic out of the way, right? It becomes more of your esthetic. I think it could be, you know, super cool and something you could be talking about, like just different ways of learning stuff.

**Ellie Rofe | 35:38**
I love the idea that it's not just putting everything into the same boxes.

**Ray | 35:42**
Yeah.

**Ellie Rofe | 35:47**
Like the categories that has chosen for that summary are unique to that deck. 
So you're. You're creating something that's almost like, not bespoke artwork, but, you know, like AAAA gift for someone where, like, this is mine. This is about me. And I want the next version of this to just be something I would put up on the wall. 
Like, not quite, but, you know, it adds a certain sense of just a small sense of joy to it, rather than just here some predefined boxes that we've put some text into.

**Ray | 36:31**
Robert, you were about to say.

**Robert | 36:34**
I was just going to say. I just. I was just tossing in the word commissioned because he said. Like you were saying bespooked or customized. Those saying maybe it to make it feel like if it was commissioned for them.

**Ellie Rofe | 36:40**
Exactly, yeah. Commissioned. And that's the promise of AO, right? When I was building Moogle, I kept thinking like hyper personalization, that's the thing that I was trying to create hyper personalization for people. 
And if you can do that via not just like the content, but the structure of the output, then that's pretty cold.

**Ray | 37:08**
Yeah, I totally think that. You know, I was thinking about the word personalization, because I think about this in terms of mass customization. Right? And, you know, in B school, they talked about the difference. 
And engineering school too. They talk about the difference between custom and customization, right? Custom is when it's built just for you. Bespoke suit, right? Customization is when you offer a whole bunch of options and when you multiply the number of options across you there. There's so many different options. Why not something that's going to be more unique for you? The latter words only. 
Okay, right, we've all seen that, right? That's it's a heavy reporte. And the I think part of the real promise of AI is that everybody can get their own you can have a be that like the image you create or asset or whatever for that person is not the same as this person. 
And but the but because of that, that's where the verbosity becomes a challenge, right? Because when you're writing 2000 words for everybody and that becomes the way they all get different stuff. Man, I gotta get through 2000 words. What am I doing here? I don't have that kind of attention span. I want to go flick through my Tiktoks and the. 
And how can you help them get the essence of it but still be accustomed to them? And I think that you just showing some of the stuff can be super cool. You know, I think people get tied up in the idea of code being the thing that their clients are going to directly interact with, when in fact, code is the thing that's helping you interact with your clients. 
And I think some of the ideas. You're getting in here. And appreciate ideas. Like. There are more ideas but you about the I mean you the thing I did I like just taking the thing pacing in the chat. PT now you've got an image. Now you can go ship it and find out what the market thinks. 
That's a few minutes. And if you if that's all you did like the next hour, that might be the most productive sales hour you have today. And then you can do more, you know, get to sort of get the momentum going for that. 
But I think being thinking, I mean, the tech in the AI world, they call it being multimodal. But things about learning styles, right? And just being able to accommodate more of those and saying there's more than one right way to skin this and then allowing us to do different ones and not worrying about what the perfect one is. 
I mean, I don't know. We appreciate that's a hard part, right? But that's where speed comes in. Like if you say, God, get done in ten minutes and you're got to get done in 10 minutes, you sort of other concerns push.

**Ellie Rofe | 39:36**
Nine.

**Ray | 39:36**
But yeah, you can take this thing and make it smaller and you've created something big, you're like, but wait, I want to ship the big thing because it's a big thing. It was a big effort for me. And yet people will get an order of magnitude more value from 10% of it. 
And the 10%. That's most you is gonna be the biggest. The part they get the most value out of a different way. The 10% or 50% that Robert could have done will not be a source of competitive advantage for you, right? 
So like that which has insight to it and sort of it's insight it's visual, it's out there. Your kind of expertise is a great fit for content marketing because the content's delivery as well.

**Ellie Rofe | 40:19**
Yp, absolutely. And I do think that, trying to ship it all as a nightmare anyway, like, just why give myself more potential points of failure without testing things? You know? 
Because I'm not a coder. I can push it to do certain things. So just get out there and test the concepts and the thinking and. Yeah, okay.

**Ray | 40:52**
And the code was there to help you develop the test and thinking it's done its job. We thank it for its service.

**Ellie Rofe | 40:59**
Yeah, exactly.

**Ray | 41:03**
But the next part. I mean, you can like find wait, I could automate all of these and get images for all of these. You can totally go down that road, but you don't need a start there. Get a couple things out. 
I think you will. I would be absolutely delighted to see. I would love to see you commenting on, you know, these things and being able to use infographics to your advantage, being able to use audio to your advantage, and even talking about how you're doing that right, because that's something that your potential clients will actually be excited about. 
Because part of their Problem is I'm putting people to snoozes because it takes me 45 minutes to talk about my complicated idea. Tools allow me to do better. And both in terms of, you know, the concision rate you get with, you know, the visual, but because it can be tailored to the individual. I some were just doing that earlier today. 
Like they were. They were like. There's this one thing in you know, trigonometric substitution in calculus that they were like we' stuck on. So we just asked the AI and that was an unlock. So being able to give so being able to use code to be able to give them just the part that they care about. 
I mean, I'm not saying do all these things at the same time. And I don't appreciate that. That sort of starts to gets down a road that can be slowing. But, yeah, I think if you have code and you use it for content, that seems like a speed to unlock and seems to be exciting to the people in the room.

**Ellie Rofe | 42:28**
Y okay, thank you. Very helpful.

**Ray | 42:38**
Do we just can get you to weigh in a little bit on this? I we've got a little bit less than average of you, partially because I'm monologged.

**Demitris | 42:46**
No worries. Basically, I agree totally with what Robert and Ray mentioned. I see. You know, when we build stuff, we think for how to make it perfect, even perfect without asking the final users. So we just imagine how would that be perfect without wearing the shoes, right? This is normal. Everybody does it. Cool. The thing is. What is the purpose we want to achieve? Building that. What was your initial goal when get started working on this?

**Ellie Rofe | 43:24**
The initial goal with the deck observatory or the pitch observatory was, to have a data asset that I could talk about content, so to analyze things, see patterns, et cetera. That was the initial one. 
And then it gradually shifted to it could be a lead magnet. Then it was. Then it slightly got derailed because of the workshop. So I was trying to build something that would help people within the workshop a bit, like I'd done with Claude projects, but I didn't want to give away on my prompts basically like that was. 
So I was trying to create something that was hidden but usable, and then it became like, a tool. And then it became the everything project. So initially, data asset.

**Demitris | 44:17**
Yeah, it makes sense. But now with the format it has right now. Okay. What is. The promise that it can give to your potential clients? 
And what do you want to deliver to them?

**Ellie Rofe | 44:35**
I mean, part of me wonders whether II talk about building this. But actually the promise at the moment. And this is where I get stuck and this is where I start going down a alonger road is. You can put your deck in and get really high fidelity analysis of the underlying strategy, the narrative itself and design slide by slide to understand where the weaknesses are and the key. 
Like eighty twenty fixes you can make. So I had that, and then in a different version, I was like, well, if someone's in the middle of a race, then this as a lead magnet tool is like kryptonite because it's just going to overcook things. There's too much information. 
So then I need a gate that asks whether they're currently raising, whether they're preparing to raise. And so I started building that. And then it would give them different things. So if they're currently raising, it would give them much less information, much less analysis and just give them like. Here's a quick overview of what's going on here. The strengths and the weaknesses. 
And these are the key things that you need to fix that aren't clear. And then if they're preparing toise, it gives them the other version, this the sort of one you see now. So I think this is where I end up in a little bit of confusion is that the purpose shifts. 
And then I think, overthink the details of it and the endg user and what they're going to experience.

**Demitris | 46:33**
Okay, you know what? I think you're in a pretty good point right now. I don't see any strong need to make it perfect to any direction, right? You're in the position that the interface and the results we see it builds the credibility for you, for the values of a professional, how professional you are, how well structured you are. It gives you strong credibility on the way you work, right?

**Ellie Rofe | 47:08**
9.

**Demitris | 47:11**
It makes you look total. The absolute professional. You bring SKPIS. You calculate numbers. You can explain how these numbers are calculated, which makes you showing them that you understand how it really works. You just didn't prompt it, and you get it. You worked a lot on that. 
And I think. I think these images can build them, security for them to trust you. And for people who are in rush or for people who are not in rush. They're looking for someone who they can trust. And the reason you bring them. The KPIs you have the suggestion where they can improve it. It makes a lot of sense. 
So I would definitely say yeah, use it even as images and give it to them and get the feedback from them. The real value comes from the actual text and the KPIs and the suggestions they have to do in order to go from 75% to 98% and increase the probability to raise the money. 
That's their journey. The journey of success is this one. So you show them how to do it. Now the next step is to engage with you to do it and go further right from the process of developing it. The only thing that is interesting to be shared as a content, not only the results, is the way you thought when you were creating your prompts, the way you calculate those KPIs, and the reason you valuate a couple of KPIs in that way because this shows your experience on that. They don't have it. 
And yeah, you know, and what I will say is connected with the other thing you mentioned at the beginning of the session for, building many things. And finally, you don't have final ones. Everyone in our in service as service providers, we have two basic things. We were working every single day. Those we have to deliver, which are the shipping part and those things which are for things we want to deliver or we expect to make us sales and all of these things. For the first category, it's quite strict. Prost camps give you requirements. You have to deliver this thing. 
That's all they guide us. Now for the other case where you have to build something for yourself and use it randomly, you don't have the requirements, you have to set them and you negotiate with yourself. Do I have to make it better or no? I would say bring only one day full day work in one thing.

**Ellie Rofe | 50:24**
One?

**Demitris | 50:29**
Get whatever you can get in after working days. No matter if it's a lower fidelity than you expected, save it and go and use it. 
Maybe it works as a lead magnet, maybe it will not. The reason lead magnets. I think the reason lead magnes work is because they firstly show something and they have a conduct call to action.

**Ellie Rofe | 50:50**
One three.

**Demitris | 50:56**
So we have those things you were done we do they were not engaged because of designing the way to operate. They will engage because of the way it analyzes the data. I think.

**Ellie Rofe | 51:12**
Okay. Yes, I'm overthinking of missing the value basically massively, right?

**Demitris | 51:24**
Yeah, and set the limit for one day work on that if it didn't. And during the day, say, okay, a couple of milestones one, two, three things, they have to be done. Forget about it. This will have to be done. Don't go for lands.

**Ellie Rofe | 51:42**
H yeah, yes.

**Demitris | 51:43**
This will have to be done. 
And for the rest. Okay? Zero facts.

**Ellie Rofe | 51:52**
I think the other danger is it's actually just quite fun to play with these things. So you have to give yourself a bit of, structure. Because otherwise it'll just be like.

**Robert | 51:59**
No.

**Ellie Rofe | 52:01**
What else can I make it do? 
It's like.

**Robert | 52:07**
I would Sorry. I just wanted to throw in my two cents just to say that, like, I feel that there's a lot of focus on trying to demonstrate that you can solve that. You know that. And like this is the answer, you're just presenting this is the answer. 
But and I think just in the past, whenever you've presented this topic and in general, I think that just there's a lot of potential than just being Able to describe the Problem very the more that you can if you can describe the Problem very well, they'll just assume you have the answer.

**Ellie Rofe | 52:44**
He.

**Robert | 52:48**
So I would just say that right like from this because this could never end like where you're just trying to in a way that like, you know, you're giving them the answer. And it really, if you do a very good job, it just means that they won't need to work with you necessarily. Or like they can maybe put it off, which, you know, it's not totally true for every person, right? 
Like you've raised reputation in the market through doing these things. But. But I would say that there's. I just think that you just you can really turn the screw on somebody and make them feel compelled to take action on things through other ways that I've just heard. You describe this topic and this whole thing where you just take it from the angle of like, this is what's happening to you, this is how you feel, and this is, you know, nobody's listening to you, nobody gets your idea. 
And like, you know, just to all that stuff. Because at the same time, I remember we had our call and I and, you know, a few months ago, and I felt those ways, I was like, well, it's a continuous journey, I suppose, right? 
And, like. So I would just say that. Like and people in those feelings like when they're when they really want somebody to listen. I think that those words and like just you being able to explain to them what is going on with them. 
It's. Dar just come back. Yes, she gets it like she's, you know, without you having to say what the next steps are, really, because they'll just presume, you know.

**Ellie Rofe | 54:19**
That's a really good point. Yeah, it's the sort of thing I would tell people where they my brand strategy client. So thank you for being in a great mirror.

**Robert | 54:36**
Yeah, and I think. Sorry. Right, go ahead.

**Ray | 54:39**
No, I was wanting to say that like, I'm the best part, I think of what this group can do is sort of reflect the best part of you back to you. I actually think that if I just might like. I think that relates to this issue of, like, playing with the stuff. 
All right. And I think the question we want to ask when we are doing our building right is that building should be studying right. It's not shipping, not getting paid for it right? It's not selling. You're not talking to the market. You're sitting in a room by yourself, right? 
So. Therefore, if it's not a and not B, then it's either a waste of time or a study. Right. So, and I think there's a good chance of it being tinkering, and tinkering is not studying, and there's a little bit of like, hey, could I be more like Robert? No, he'd be more like Ellie. Wherever it's making you better. Just like what Robert was doing like the best part of the counsel you get from like you know, Demetris from Robert and maybe a little bit from me is that reflection, right of you like the parts are getting you to be more you and getting you to have better insight. 
Like, I have learned something today, and I've learned something technical. I mean, if it's technical, then it should be about the domain that you care about, right? That is about your special powers. 
If you do that, I think that means this is like in the experiment quadrant right of the learning experiment will teach, you know, learning framework. But the. But if it is not, it was like, hey, that's kind of cool. I guess I can build some new thing now. It runs significant risk of becoming tinkering, right? There's a little bit of enabling technology, but the thing is, the tech isn't that hard to work with, right? 
So as we spend more time on it, but it really gets into the tinkering phase, it's kind of cool to make that stuff, you know, glow or whatever, but like, how do we get to be more you? And when we do that. That was a really good insight. 
And now we just need the other half of. Let's take that good insight. That higher version of li put it into some markets. We're turning the wheel on it right from steady in to sell. And the and I bring it up because it gives, maybe just a little bit of a small voice in the back of your head as you're playing with the technology. You could be asking, wait, is this tinkering or is this am I learning something new that's really important? 
And then because you're thinking about what that important thing is, that's giving you the tool to be able to express it to the market, which gives you a tool to sell hopeful and all with the goal of trying to loosen it up. 
But a lot of what you've shown here today, you know, I would love just to see screenshots of that going into the market.

**Ellie Rofe | 57:16**
One.

**Ray | 57:17**
I think this will become sell tools for you with not days work, not our minutes of work because you've already done the work. It looks. I don't mean to speak for Robert Demetris. I appreciate your say, but I think your stuff looks really cool.

**Ellie Rofe | 57:30**
Okay, thank you, I shall do so excuse me.

**Ray | 57:30**
And I think it should be in the world.

**Ellie Rofe | 57:35**
Yes, okay, yeah, it'll be fine, it doesn't feel too awful at this point.

**Ray | 57:40**
And recover cold or whatever terrible plague youle on the airplane.

**Ellie Rofe | 57:45**
I think it's gonna be all right. I had Best Dash because I've actually got a call with Maddy now. 
But thank you so much, everyone. I really appreciate that. And have a very Merry Christmas. Or Happy holidays. Or however you may celebrate. Thank you.

**Ray | 58:01**
Thank you all. Happy Christmas. Tick care. Bye.

