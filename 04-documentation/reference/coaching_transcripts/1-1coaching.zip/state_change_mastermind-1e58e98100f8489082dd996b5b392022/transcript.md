# State Change Mastermind - Sep, 16

# Transcript
**Robert | 00:01**
If I didn't do it, then do what I got to do.

**Ellie Rofe | 00:01**
If I didn't do it, then.

**Robert | 00:04**
So I'll still put it out and everything. Hello, Ali. And all things considered, it's... I still have to have the discipline to be able to just still do what I got to do because every day it matters, and we got to just put two feet down and get it done.
It's a late day, so go get it done, whatever it takes. I'm trying to do it better and see if I make a small change. Will it change other things? Can I do it an hour earlier? What happens then? Is the video better? Are the people around me reacting better?
And so on, just making that change and just being aware, I suppose, of those small things and just how downstream it affects the rest of the day and what it does. What does that day look like when I come to the end of the day, and I'm like, "Okay, that was a good one"?
I pulled it off good today versus a day where I might have pulled it off, but it really was... I didn't make it look easy. It was just not the most efficient way to do it.
So, yeah, trying to be more aware, I think, is maybe my... What I've... I don't know if that's new knowledge, but we're trying to be more aware, and that has led to new knowledge in the last week.

**Ray | 01:27**
Fair enough, Ellie. I didn't want to be causing too much traffic on your phone, but I hope you were able, in a safe and totally non-frantic way, to make your way back. I appreciate the...
Yeah, the vicissitudes of... This was the channel train, right? This was the express train between London and Paris.

**Ellie Rofe | 01:53**
No. I was in Hertfordshire, just north of London. I was getting the tubes and the train back from London. There were some delays and then there was traffic because of the delays on the train, we had a bit of a rush hour in the province and the suburbs as well.
So it was like just knocked it off on every step. Sorry about that.

**Ray | 02:15**
Yeah, I know. I hear that. I hope it was a good meeting.

**Ellie Rofe | 02:22**
Yes, it was interesting. It was with this one was with a political party. I had tried to meet with someone else in biotech beforehand, but we had to cancel. They had to cancel.
So, this was with the political party, which was interesting and being introduced to the chairman of the party. I have met him once who has a lot more. He's an entrepreneur. He has a lot more connections.
There's another guy who's an entrepreneur. So they want me to help that. I kind of ended up doing a bit of brand strategy for a political party, potentially. But we have to do some discussions about payment.
So we'll see how that goes.

**Ray | 03:05**
Yeah, I hear that. Politics is one of those weird things. There was, "Hey, want to have some success?" Then, you associate yourself with that success. It's hard. It depends on the reputation of the party.
I think about that a little bit.

**Ellie Rofe | 03:17**
Yes.

**Ray | 03:18**
Because. today, in the morning and office hours, these big interesting technical questions turned out to be someone who's making basically a pornography app. This was not evident until we brought up the tables of like.

**Ellie Rofe | 03:27**
[Laughter] God.

**Ray | 03:33**
Okay, yeah, we need to not be a review of the data. Let's go back to the code for a second.

**Robert | 03:40**
Interesting, there's money in that, probably.

**Ellie Rofe | 03:42**
[Laughter] I mean, 30 40% of traffic on the internet.

**Robert | 03:44**
[Laughter].

**Ray | 03:53**
Is it that low? [Laughter].

**Robert | 03:58**
It's like that movie, Her. If you've seen the movie with Scarlett Johansson in Phoenix, Her, yeah, basically, it was before the AI boom.

**Ellie Rofe | 04:02**
Haven't seen it, but I know the idea.

**Robert | 04:08**
Like was around 2010, and it was just the idea of a companion, a companion on your phone.
It was like in the movie, Scarlett Johansson's voice. At that time, it was like you were watching, I can't imagine every day that this is not really realistic that it would have and understand everything if...
But we're already there, so yeah, no.

**Ellie Rofe | 04:30**
Samelman's favorite film, which is bizarre because it's.

**Ray | 04:31**
I crazy [Laughter] goodness.

**Ellie Rofe | 04:36**
It's not really meant to be a favorite film, but it is his favorite film. So there we go. Twan ended up in controversy by putting Scarlett Johansson's voice on as the GPT voice mission.

**Ray | 04:44**
Okay.

**Ellie Rofe | 04:52**
Anyway, sorry, I digress.

**Ray | 04:54**
No, all fine this time. It's really mainly for you. I appreciate you kind of coming in a little bit late and maybe a little bit hot and heavy on it. We did a little bit around the horn talking about the things we learned in the course of last week, and you can catch up with that. I'm glad to send you a copy of the first part of the Mastermind for that.

**Ellie Rofe | 05:12**
Thank you.

**Ray | 05:13**
But for you, it's really what do you know today that you didn't know last week? And how can this group be of service to you? To help you have a better next one, three.

**Ellie Rofe | 05:23**
There's been a few bits and pieces, really. I think it's all been around touch points with you guys because it's been a fractured wink again between being a bit poorly and being away from home and outside of what passes for a routine for me.
So, it's been really good to check in. Robert's been organizing the coworking sessions rather than accountability. I obviously chatted with you at one point about someone who wanted to talk to me about brand strategy.
Then, on one of the coworking sessions with Robert, I bunged all of our coaching calls into a Claude project and just started asking it, "What am I missing? What's not working? Where am I getting things wrong?"
I won't go into all the ins and outs of it, but we eventually got to this point where I realized, I think I spoke with you, Ray, about doing the pitch deck analysis tool directly to people as a kind of test. Can you be happy to send your pitch?
I'll send you the feedback, happy to hop on a call and give you a free chat about what it means. As a test of the tool, test the appetite and then potentially get paid work from it.
I was thinking of that as a bank raid as I was saying, and I know that's a very mercenary way of putting it, but it just makes me laugh. A way of just working on a direct... Let's see if I can actually get interest here.
What was really interesting is over the course of this chat, I realized or I was told and I suddenly realized, that's a really good idea. This isn't just... Can I just get some pitch deck work? Is something where I could be testing different industries, different people, and seeing where, as you mentioned about strategy, where this is the way in to other work where there is a demand, where there is a market who is interested in it.
So, I think there are a couple of questions, but they're quite pragmatic, if that's okay. Is there just a brainstorming thing? Because what I thought was especially as I'm a bit more moored at the moment and because when I work with people, I do marketing experiments with them.
So, I wondered if you guys could help me brainstorm the marketing experiment around this and give me some ideas. I'm terrible at setting goals. For example, I think there's a question here around Ray Dalio. Is it Ray Dalio?
I think it is... Tell me where I'm going to die so I don't go there. How will this fail? Where am I going to make things wrong? Just any ideas people have for the best tactical approach to this.
So, yeah, if that's a bit open, I can give more specifics, but that's where I'm thinking.

**Ray | 08:50**
Yeah, that's a reality. I think it's a Charlie Munger thing, right?

**Ellie Rofe | 08:53**
I think we might be talking among them now.

**Ray | 08:53**
I Okay, then there's Robert right there with Launer.

**Ellie Rofe | 08:58**
Brill. Thank you. For some reason, I get those two mixed up, and I have no idea why. I guess
both are fonts of wisdom in their own way.

**Ray | 09:07**
They are and they're very both they're both very methodical thinkers. And so, like, there's a lot of overlap between like, the, you know, old Charlie's Almanac, which is like a collection of his writing sayings, and Ray Dalio's Principles, which is sort of his big tone.

**Ellie Rofe | 09:21**
Yes.

**Ray | 09:23**
And both of them are kind of designed to be kind of quotable thers, you know, Almana type things.

**Ellie Rofe | 09:29**
Yes, exactly.

**Ray | 09:33**
Okay, well, let me... So we could put some bones on the question here, like what is it that... How is it that this group can be of service on that question of giving you that kind of definition so you can be making definitions so you can be making decisions.

**Ellie Rofe | 09:49**
Yeah. Tactically, I'm thinking of just sending LinkedIn emails with pictures attached of the type of report they'll get so they get an immediate visual. It's got the little block bit, it's got a SWAT analysis, it's got some key recommendations.
It's blurred out because it's got actual content from a pitch deep analysis. I figured that actually helps because it shows I understand privacy. A little form, just saying the suggestion.
This is where I end up sometimes ending up in the weeds with things. The suggestion was to search for posts that are talking about pitching and fundraising and then just get in touch with people who were talking about this.
I'm unsure if that's the right way or if I just try and connect with people and message them once we've connected or what we do. Then I'm thinking, I just say, "I'm testing this tool. I'd love to put your pitch into it and you let me know whether the feedback seems useful or not."
We can do that on a call or you can just reply. One of the things is tactics. Is that the way I try and hold email? Is there some other fancy way of doing stuff? The other thing is, I always talk about setting metrics.
So, how many people should I try and approach with one method or one approach? At what point should I test something different? If there's just ideas and brainstorming here to help me triangulate at least where we are with that, I know the ultimate goal is to test the tool and see if it works, to test where there's appetite in the market and hopefully get an engagement from it.
So, I know the objective. It's just working out how I can test that, how I can put in place a thing to push through, to make sure I review it and whether I'm thinking enough about things. If there are any blind spots in what I'm talking about.

**Ray | 12:06**
Okay, let's open up for Robert. Do you have thoughts here?

**Robert | 12:15**
I guess what is the risk of just not just going for it? You know, I would just send it to the.

**Ellie Rofe | 12:28**
The risk is if I start doing it, if I don't put goals and targets in place, then I will just go. The temptation will be too soon, probably, for me to just go, "This isn't working, I'll do something else or pardon.

**Robert | 12:43**
Or maybe it is working.

**Ellie Rofe | 12:49**
Yeah, but if it doesn't after the first ten or so, what parameters do I give myself? I think, yeah.

**Ray | 12:59**
Okay, so the parameters and the target both become key considerations. Do you want us to get your thoughts for a second? We'll just keep the wheel turning around.

**Demitris | 13:09**
Yeah, Ellie, the thing is that for what you described, I see the risk of putting too much work upfront for free without the guarantee of having a payment process. So this is the risk from the business side,
and to decrease that risk is to know more about the person we have from the other side. Maybe there are connections, or if you don't get value from that specific person, you may get value from another person from their network.
The thing is, how can you end up in the first conversation with an offer that they can feel totally stupid to say no? So, if you give this free approach upfront with the presentation and your super useful consulting, how can you close the conversation without having to follow up emails and so on? This is not in-person stuff. You have to be prepared for that. End call, end question.
What should that be? So they can feel stupid to say no or feel... They can convert or at least make something and do something, take an action, even give you a review, something like that.
So I feel like you may need some cases to use them as stories about the question, "How many people can you do it for free?" which is one of your concerns. I would say that many you need in order to cover the blind stuff and create useful content for you.
Maybe three are totally fine. The thing is, how can you get the maximum from that? Minimum input, minimum effort. So if you achieve that from three people from three cases, you can get more. But this is totally theoretical.
It's quite hard to decide how to do it. If it may help, I had a conversation with Daniel Presley. If you remember, I got the pitching with them. It took two and a half hours. And the nice thing is that they tried to sell the full webinar session. They offered a subscription model for paying for a certain amount of months in monthly payments.
They tried. They pushed me a lot at the end of the conversation for making the transaction with a guarantee of money back. All right, the way they pushed me was by offering something I can access after the call. So after the call,
they offered a value. I didn't value the value, so I dropped and I got my money back. That's fine. We'll continue our lives.
But this is my experience from that. And I think that I can even translate it to my brain as a strategy. But I think a person like you can find that way, and the conversation can start from there.

**Ellie Rofe | 17:04**
Okay, so I get them on the call. Have to say, my sales stuff is quite lazy because once people start talking about their pitch deck, they generally start saying to me at the end, "How can you help me?"
Because I don't want to be doing it. But I think it is an interesting point that you make about... So to give parameters, it takes about a minute to do the analysis because all I do is chuck a PDF into Claude and then it stuff out.

**Demitris | 17:36**
One.

**Ellie Rofe | 17:40**
That's that first bit. Obviously, I might just be able to share the project link because it just does it as a markdown like HTML. I'll consider that. There are... It might be that it's too focused on biotech.
So, there'll be times when I need to change the project prompt to focus on a different industry or to be smarter. That was a bit longer averaging out. I'd say each one will take about half an hour, and then I'd be offering half an hour if they want to talk about it live as well.
Yes, I guess what I'm saying is, have I pinged them free stuff over in response? They'd have to upload their PDF, reform. I ping them free stuff back in response with the analysis, and then if they come on a call with me, you're saying that I should have something after that, like, "Let's deliver some value, give them an option even if they haven't taken up the call." Give them an option after the call, just to keep nudging them. Is that what I'm understanding?

**Demitris | 18:49**
Somehow yes, I'm brains summering right now.

**Ellie Rofe | 18:52**
You didn't yet know I left it.

**Demitris | 18:54**
May I ask you, did you try to package your services like create packages with X number of sessions, this amount of time we meet every X number of days, and after days you get this result? Something like that.

**Ellie Rofe | 19:10**
I had. I have a process. So it would be like we do a messaging workshop, then get the investment, then we develop a skeleton deck, then we create your deck itself.

**Demitris | 19:17**
One.

**Ellie Rofe | 19:22**
So it's like a three-step process really?

**Demitris | 19:26**
All right, so I think why not to present the analysis process from what's happening or keep this analysis at the end? Firstly, start presenting yourself and present the workflow because at the end you want to put a goal in this workflow. Put the point into there, right?
So you get started with the analysis where they get the personalized experimentation and then you can conclude with your thoughts about, "Here is how it would work for you.

**Ellie Rofe | 20:12**
Yeah. And send them the transcript, right? That's the reason to send them the thing after the call, right? If they're on a call, I send that after the call and go, "This is how the process, my process, could work for you to get the deck up to scratch, Basically.

**Demitris | 20:28**
Yeah. The transcript would be useful. But to be honest, I never get a notification from TLDV. The one I use for transcripts that somebody opened the video, only me, I do it.
This is a true transcription for you? Yeah, and think like that.

**Ellie Rofe | 20:51**
Nine.

**Demitris | 20:53**
And do you know about their position before we get into those calls.

**Ellie Rofe | 21:00**
If anyone takes up a call, I will know. I will know a decent amount about them because I've had their pitch deck, and I'll be able to research who they are a bit and look at their website, if they've got one, look at their social profiles, et cetera.

**Demitris | 21:08**
2.

**Ellie Rofe | 21:18**
Depending how high profile the CEO is or founder or whoever is putting that pitch up in front of me as to how much I will know about them.
But, you know that I'll be able to have a decent idea. And actually, part of the joy of those calls is finding out where the gap is between their pitch deck and who the business is. That's
part of what I end up doing on the call.

**Ray | 21:51**
Through the discovery process. That's cool. I like this idea. I might propose Bo from a measurement point of view, which was one of your additional questions. I think what you want to do is measure your inputs, right? To make sure that you are staying with it.
A win is getting 20 people, right, based on whatever your qualification is. The 20 of these things to go out, right? Because that's the first rep you need to build out. Just how do you do this in a way that goes out that's going to be not completely soul-destroying for you, right?
The first one's gonna feel like crapping pineapple. We want to get to the point where it's easy and fun. That's not where it starts, but that's an important place for it to go because the idea of doing Merking experiments in general is going to be important for the success of your practice.

**Ellie Rofe | 22:41**
He.

**Ray | 22:42**
So the. So. So I think that would be the metric I would look at to begin with. Is just an end of them getting out. The second thing is, I think in order for these to be accepted by people, there needs to be a certain amount of no like trust, right? You offer a great service, you know, to people who have never heard from you before, and they won't buy it because they think that this sounds like a scam, right? Or that it sounds like kind of what maybe it is, which is a lightly disguised sales pitch.

**Ellie Rofe | 23:08**
4.

**Ray | 23:09**
So I think there are probably a couple of things. There are one to three things you need to do. The first is probably you need to make the promise, not a sales pitch, just say, "We'll do this, we'll get this.

**Ellie Rofe | 23:17**
Uhmhm.

**Ray | 23:20**
Look, I'm trying to figure out how this tool works. I have this expertise, so tools aren't that valuable? I'll try to give you the benefit of the expertise, but this is not a sales pitch where I'm just trying to figure this stuff out.

**Ellie Rofe | 23:30**
Yeah. Yeah.

**Ray | 23:31**
And second is the question of who trusts you, and be willing to accept this. Maybe they're not ready to spend $10,000 with you, but they would accept. They would say, "Hey, this is a little bit of free LA. That sounds awesome." Your initial customers, people who are almost already your customers,
right? So the temptation for these... I'm going to go to a whole bunch of completely blind LinkedIn DMs, people I've never met before, third-degree whatevers. Then that way, they don't really affect me because they're all the way over there.
I think that's a crafty way of doing things. I would rather be that you're doing people care who you would like it if they were to be responding to you. That you have some degree of caring, and that's going to be the people who almost already know.
So, who's in your network, right? That's more founderish, like, "Hey, I'm looking to do this." Maybe people have already raised money successfully. What's going on? What do you want? What you wanted is to get more reps and
get more experience, get more data into this. Treating this as much as a study as a cell, I think, is useful. The other thing that will happen is if you give it to those people, they're like, "This sorts make them remember what's great about working with you and makes them potentially want to work with you or for work, whatever."
That's how that sort of turns the wheel, I think. So, my strong recommendation is that those first twenty are about your network. They're not about utter strangers. In fact, the utter strangers... What I would do towards the end. I'm not a big fan of using cold email. I'm a big fan of using email, but I'm a big fan because it's warm. People who you've talked to who know you are like, "Hey, I talk..."
Yeah, we both know Ray. We both know whatever. The fact that when I get those invites in LinkedIn, it's a cold message from someone who I've never heard before. Then they say, "Hey, we both know X now." Sometimes, it's pretty loose.
If I go ask X about you, are they going to have any idea who you are? But if you play that in a more real way, I think there's lots of opportunity, and the fact that the technology gives you that pivot access to it.
I think there's a lot to be said for that. So, who are those twenty? I think the twenty people who you know right or are friends with, and then the third is going to be talking to people who have the pain.
One of the neat things is if once you say, "Well, it's not exactly about biotech," you could say, "Make a slightly more cold offer to people who are more in your domain, for example, biotech CEOs." You could say, "Hey, I'm doing the same about biotech.
I have this expertise around the field, blah, and this... If you are stuck in your pitch deck, this can be useful to do it. If you're not stuck in this pitch deck, I'd love to be able to see it. I keep them confidential, and I'm looking to run them through this tool to learn better how to analyze this stuff right so that instead of you having to go pay $20,000 or something, you can just get this and I'm not going to charge you for it. I'm not going to sell you anything. I'm just trying to make this thing better.
I'm trying to work with people in the field. But then, like you say, you can go to people who are, especially if it's by pitch deck people who are raising money. You go to other fields, and you can go to...
Then, what becomes your angle here? Your angle becomes application season, right? For accelerators, TinySeed actually just went through one. You just missed the boat on that. There's a White Combinator application season, et cetera, that you can be using to say, "Okay, send me your pitch deck, and I'll get you some insight."
Now you're able to connect with those things. So, who do you know? Who do you know who knows somebody who has that kind of thing? Then you'd be putting it onto your website as well, right? Because it's an offer. Do you have a thing? We're testing this out, and for you, it's not really... It's not cannibalizing your leads because it's not going that way anyway.
So you get more of that out there, and you get that kind of permission if you put that up. I would gladly repeat the offer over on the state change as well, because for people who are looking to raise money, of which there's an appetite for that on state that.

**Ellie Rofe | 27:27**
415.

**Ray | 27:42**
There's some degree of knowing who you are. They certainly know who I am, so they can do that referral-based thing.
I think there's just that... It becomes, "Hey, and what other techniques do I use? I use the friends who go repost. That would be right. Maybe it's Demetrius. Maybe it's whoever else that might be where people are like, "Sure, Ellie."
Then, in the course of that, you've gotten other people to post. Ellie is smart and worth doing business with, right? That's building your social proof slyly alongside building out the tool.

**Ellie Rofe | 28:11**
Yes.

**Ray | 28:13**
Those are more tactical things.
I think the consideration is to think of it as a series of concentric circles that you're going out in the likelihood that somebody who doesn't know you from Adam and is just a CEO of something that's going to pay attention to this and not just say, "Wait, I got 20 pieces of spam this week, and this is one of them."
On the basis of just knowing who you are versus those who, ideally, the messaging would start with the reason they care in the first half dozen words, but with either who they know right?

**Ellie Rofe | 28:44**
One.

**Ray | 28:48**
Or the immediate thing they would care about like which is fundraising time or accelerator or whatever that would be sort of you know, give them attention, right?
And that you're using the season or this connection to learn. Don't appreciate that, I think. Or the people who want to appreciate it will appreciate it. And the other people will just throw it away.

**Ellie Rofe | 29:11**
Yeah, okay, lovely. I love the concentric circles. That makes sense. As you're talking, I think the beauty of opening it up outside just biotech means that I start making connections with people who are in the broader scope of business as well.
So that's nice. I can immediately think of a few people I can work with who are still in finance but work in equity research. And there's people who are spinning out stuff out of equity research.
But the nature of equity research is they have seventeen different industries that they're covering, and so there's all these people spinning stuff out in different industries. So, cool, I like it.
So yeah, and I so the main metric is, the actual processing of analyses rather than the number of outreach and stuff like that. Because I think that's a nice way of doing it, because that gives me a tangible, concrete thing rather than just like, I've sent X requests, the... Yeah.

**Ray | 30:16**
Yeah, start with the things that you can control, right? Leadings and leading ES, our activity indicators. And eventually that becomes a Vandy metric. But it's not a Vandy metric at the beginning, it's just... You know, the kick in the butt metric I have.

**Ellie Rofe | 30:30**
Okay, nice.

**Ray | 30:32**
How many outreaches have you done? Haven't done any outreaches. This fits.

**Ellie Rofe | 30:40**
Yes, okay, that's very helpful. Sorry, I came in very late with a sort of franticness. I had quite a lot of coffee today, which I don't normally have,
but this has been really helpful to just tidy up the approach to this, because it's exactly the kind of thing that will turn into a quagmire in my brain if I'm not careful.

**Ray | 31:06**
Yes, and I think that the... I use the analogy of the Tarpet with Robert and our call on Saturday. The thing about Tarpet is like you. The more progress you make, the more stuck you get.

**Ellie Rofe | 31:17**
Yes.

**Ray | 31:18**
And I can sort of hear the wait. I'm sort of stuck where I am in the moment. What you want to be unstuck is moving, be feeling like... If you're feeling like it's weighing you down, that's of course what this group can be for, right? To sort of provide that kind of perspective and
hopefully re-energize you. If it is, if you're feeling it as a slog, there are enough other tactics available to you that the ones that not only we think would be good on their own merits but are good because they're good for you, right?
That you're good at them. That, if I might, is the most important thing to be learning early on, right? Is that which is going to be sustainable for you?

**Ellie Rofe | 31:58**
Yeah, absolutely. I felt quite more... I feel more excited about talking about this just because there is... I think Robert talks about this a lot. The way that you create something that is tangible when you're building your tools and products, it feels more substantial to talk about than stuff that feels like you're just pulling wisps of smoke out of the air.
So it's just being able to go, "This is what it looks like. This is what the analysis looks like for a generic company." I'd love to see what it looks like for your nice.

**Ray | 32:35**
Yeah. I think it's awesome. I think if you're not getting replies, then it's worth it to be asking, "What are the other techniques that we can be bringing to bear on it?"
Because I have an easy time imagining demand for it. If the offer can just be derisked. The risk here is not that you're going to charge me or that you're going to give away my secret information, both of which, presumably, I managed just through the document itself.

**Ellie Rofe | 33:01**
Two yes.

**Ray | 33:02**
No, it's basically the risk of talking to you, right?
And that this is a really useful thing. This is where like a little bit of social proof of asking friends to be reposting it with a comment of Ele's great. She's not selling, she's learning, you know?
And then. That. That way their networks are saying, wait, that sounds like a good thing then, because the best way to sell is to say, I'm not selling to legit be not selling right to your point.

**Ellie Rofe | 33:22**
Yeah [Laughter] yes.

**Ray | 33:31**
Like you are saying, "Here's X, and then you're giving them X and X is immediately valuable to them," well, then you've just built your reputation on them.

**Ellie Rofe | 33:41**
Yeah, okay, perfect. I might have a post up on LinkedIn saying, "I'm not selling, I'm just learning," which is infinitely more valuable. Please look at this.

**Ray | 33:53**
I would be... Yes, that's cool. I'm looking forward to seeing that, and I'd be glad to give the external validation on that part, too.

**Ellie Rofe | 34:02**
Thank you.

**Ray | 34:04**
All right. Is there any other way we can... A service to you and a couple of minutes we've got left here, Earli.

**Ellie Rofe | 34:07**
No, I think that's fabulous. That all makes lots of sense, and I apologize for missing the earlier stuff. I hope you guys have had a good week in the day or so between times when I've spoken to you last.

**Ray | 34:24**
And I quickly ask, are you all set up to do academyil do stuff this or meet as a group this week as well?

**Robert | 34:33**
I was just about to say. I can send out the invite right now for the same time tomorrow if that works for both of you, not the same time as right now. I mean, the same time as when we met last time, Demetrius, if that that.

**Ellie Rofe | 34:46**
That works for me.

**Ray | 34:50**
Works works for you.

**Demitris | 34:50**
It was like today's time. Because for today it didn't work.

**Robert | 34:54**
Like two hours... Sorry, yes, like today's time, the one that we didn't do today.

**Demitris | 35:00**
Yeah it works for me.

**Robert | 35:03**
Okay, I will send it out sent. Okay, the sent so we're good.

**Ray | 35:10**
Super cool. All right, you all have a wonderful week.

**Ellie Rofe | 35:11**
One.

**Ray | 35:14**
We'll do this again in seven days' time. I'll see you all at the end of the week for sure.

**Ellie Rofe | 35:18**
Thank you.

**Demitris | 35:19**
Bye.

