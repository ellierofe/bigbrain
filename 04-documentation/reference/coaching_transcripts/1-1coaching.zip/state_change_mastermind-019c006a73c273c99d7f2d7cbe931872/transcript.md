# State Change Mastermind - Jan, 27

# Transcript
**dimitris@3nuggets.io | 00:01**
About what can we do and what other people are doing with the new technology like agents with VIPE coding a little bit step away from the Zapier ecosystem, which is good. OJ aily.

**Ellie Rofe | 00:20**
Hello? Sorry. I'm a few minutes lates.

**dimitris@3nuggets.io | 00:28**
Well.

**Ray | 00:28**
And you are not the last to join. I mean, will the Roberts still not with us? Yeah. Dreamus was actually just sort of sharing what he was doing at a rees at the meetu over at Nucode ops earlier today where he is you know, what one is doing is sort of reengaging right with these communities and doing events with these other communities where he can.

**Ellie Rofe | 00:41**
Co.

**Ray | 00:47**
I'm sure we'll talk more about them in Hot Seat. 
But he was sort of sharing what he was what he was learning, what he was seeing, right as he was sort of, you know, doing that reengagement today and that he got to which I think we should not underestimate like what when you were talking about that, Beatrice, just the opportunity to sort of demonstrate what we're doing, right?

**Ellie Rofe | 00:58**
Nice. That sounds very good.

**Ray | 01:12**
Hey, free shot. People haven't seen you in a while. They're interested in what you're doing. You can just show it.

**dimitris@3nuggets.io | 01:17**
Yeah, to be honest, I don't for that reason. But the thing is, Discord for me and the other folks didn't like our cameras and microphones, so I was pretty off. I tried to engage with from the chat and was quite disappointed. 
So when I realized that okay, let's step away. [Laughter] I tried close my Chrome, open it again, but we had the same issue so it was fa maybe next week. The interesting thing is that. You know, I'm a member for almost three years in this community, and I saw many people joining and disappearing. 
And we had a discussion with that with Ray, and I think it's worthy to mention here. Ali in the past we had a conversation with Ray saying look, these people from the first year dropped now have second round and then the third round follows and I would say I validate that interesting people joined one year ago early on 2025, middle 2025 and so on. Nobody was there. This is true which means they joined, they took something and they moved away. They stopped receiving value from my understanding. 
And this is what how I used to feel a few months ago. So okay, it's about time management. Where to join if I cannot engage that month back in the time, it was quite hard to me to engage. Take the microphone and start speaking. I had to feel like there wasn't enough room. Not for any specific reason. 
And this is my feeling, my thoughts. Today I felt it was more interesting, more open, more calm conversation. But yeah, that's it, you know?

**Ellie Rofe | 03:41**
Yeah, that's really interesting. So this is aper. Is it?

**dimitris@3nuggets.io | 03:46**
Yeah, that's it.

**Ellie Rofe | 03:48**
Five?

**Ray | 03:50**
The previously independent thing, they had the idea, which I think was a good idea of they had a product they wanted to do and they made this community to sort of build reputation for that product. Now. 
But the trick is the community worked well, but the products, they never got dialed in and the. And so what wound up happening is they sold the company. What really happened was they gave a couple of the people in the company jobs and everyone else got tossed. 
But one of the people who got a job was the manager of this community, who sort of kept the community going initially. Still, as an independent community and actually as an independent community. I mean, you can tell me if you agree with us or disagree with Demetrius, but my impression it was a very make heavy community that like most people, there were make people, partially because of the differential in cost. 
And then it sort of switched to becoming much more of a Zapier community, which actually sort of shows the influence of the community manager able to sort of make that turn relatively easily to get, you know, basically get these big consultants, turn them into Zapier consultants, get more Zapier consultants in. 
And then that becomes like the new center of gravity of it. And it's, you know, it just becomes Zapier's new community marketing initiative, right? The one that they haven't killed. They. They bought Makerpd several years ago. 
And then, you know, killed it.

**dimitris@3nuggets.io | 05:18**
Well, it was like the most recently conversations that those I joined. It was mostly conversation about building with Zapier, nothing else. When I received a couple of messages like I it would be better to not post stuff from make a competitor of Zapier, which makes sense somehow, but we used to do that. 
And the logic is not about the tool, it's about the logic behind the skins. So I felt somehow okay now it's not an automation community place, it's mostly a Zapier thing.

**Ray | 06:04**
Right? Yeah, I think that's right. I think it is more obviously a marketing tool marketing arm for Zapier and the, you know, I think was built on a premise that was never true, which was this idea of the so called no code operator, the idea that this was going to be like a job Description and more people would be doing this. 
But that, you know, never really came to pass like heavily the group is represented by people who are, you know, the consultants, right, who are doing this for people. And so it's more like your business is defined by that, but not like you are a, you know, low level white collar worker, you know, whose job it is to be, you know, using these tools. 
But, you know, all of that's a little bit speculation about somebody else's thing, although useful for thinking about, like, hey, how these communities relate and like that's, you know, especially communities have such a big deal for Demetrius, which we'll get to. I don't know where Robert is. I sent him a note asking after him, sort of to see if he sort of stuck on a call or something. 
But for now, let's get into it a little bit. Ellie, would you mind? You know, we could check in with you and like what was true for you today. That was not true for you a week ago. And then we'll turn to Demetrius for the same question and get into his hot seats. We can be of maximum service to him.

**Ellie Rofe | 07:17**
Yeah. What was true today, I've got an interview linedup tomorrow which is good with I don't know if I mentioned him before, he is one of the s MP's SDP's candidate so political party candidate who is their energy and industry spokesperson. 
I've mentioned him to you, Ray. He is he's done huge housing developments from like the Docklands Light railway and Canary Wharf in London through to the Dubai World Trade Center through to like 25,000 houses for Muslim refugees in Bosnia in 92. 
So that's a really interesting experience. And he's now st up a ammunition company in Coventry in the UK, which is like trying to roll back a century. Coventry was the site of huge amounts of munitions building both in World War one and World War two and has since become completely industrialized. 
So fascinating man to talk to from all sorts of angles in my, like, money knowledge power complex. And I had a chat with him about he wants me to be involved with the strategy, fundraising and brand. They're just trying to get through some details. Admin politics, ironically. 
And so we shall see. Other than that, I've done a huge amount of work with Nick over the last few days. He's hurt his knee and I have been working with him Thursday, Friday and yesterday and doing recovering over the weekend myself because I'm not fit enough to do that much physical work whilst so FAS so I was a bit crashed out on Saturday. 
So there's not been a huge amount of like day to day execution progress, but there has been various other things happening to that keeps pushing me along. And one of the things I'm going to do with invites is I think I might I'm going to start talking about founders who have raised in the last year who are doing like, Star Trek level stuff like there's a company that's doing printing retinal, sort of layers in microgravity. I don't even understand what that means yet, but it sounds incredible. 
So I'm going to start talking about those people on LinkedIn, like the people who are building the future and the people who are building like, you know, the aglets. The little bit that goes on the end of a shoe lace to stop it fraying. The people who are building that kind of level of infrastructure. 
But much higher tech as well. So like big secty projects, other things that have been funded in the last twelve months. And then I think I'm going to invite those founders because if they're funded twelve months or more ago, sorry, at least twelve months ago, they have a story about the fundraising, what's happened since, and they're probably going to bed raising again soon. 
So I'm thinking, try and connect with those people, ask them to talk to them. I learn about them. Maybe I get a connection that has some business for me. But either way, I'm talking to people. I'm. I'm building my network.

**Ray | 10:32**
Okay, cool. And, yeah, especially when you sort of talk about, like, the nick thing. I think it's worth remembering that sometimes the most important work is like just a couple hours in the course of the week, and like a lot of the rest of what we do is sort of that search for, like that stuff that really matters. There is a little bit of wait, I'm doing this sort of thing and this sort of really concentrates the mind on the part that that's most important. 
So congratulations. Gain the interview too. And the politics thing is super interesting. And, you know, ammunition and Coventry, that's. I by the way, you had a line about what do you call it? Knowledge, money and power. You've used that line before. I find it very compelling. 
So as you think about like your content player, the branding for that, I sort of just, you know, throw that in the pot of, you know, there's a that's a cool turn of phrase in there for making people who are working in hard tech feel more, feel like they're working on a more sexy thing.

**Ellie Rofe | 11:39**
Yeah. It's the absolute core of it. It's a three body problem. But yeah. It's. It's the core of it. [Laughter].

**Ray | 11:47**
Super cool. All right, Beatrice, let's turn to user. How what kind of week has been? It was true today. It was on a true week ago. And how can we be a service to you?

**dimitris@3nuggets.io | 11:59**
What's true today? First of all, I'm done with the onboarding app last Friday, so I made started thinking not thinking acting into kind of launch where the main idea of this loans campaign was inspired from Ray in one one conversation we had about instead of inviting people immediately. Hey, Ali, would you like to check my app? E let just bring questions into this audience. 
So what I did was getting to reit and started putting questions. And I'm planning to organize a private conversation with salespeople, mentors and so on so we can engage together and see what is their main concern, which are their challenges and all these things. There's no rush for me to do it this week or the other week I had another goal to engage with at least five people testing the app. 
But I realized that I need to engage with them not by checking my app. But, learning from them, get to know them, get into conversation with them. So having an interaction with them. So even into my LinkedIn contact requests, I send a message like, hey, nice to be connected. We'd like to say more about yourself, so we will be simple connections on LinkedIn. Let's get started. I'm not selling, you're not selling. We're all professionals, so this is my approach and this is what I try to do. 
I know on LinkedIn it's quite straightforward to build conversations, but in to red it's quite easier. And I'm focusing on that too. And I'm trying to engage with people on LinkedIn content, not my content, but the other people content. 
That's the first main thing. I had the event the technical one event last Friday, which was pretty good. We had nice feedback. People texted me back after the emails. Thank you, we're learning. I sent to those people who joined the conversation personallys, like with the problem they mentioned, what is my suggestion? How they can get started and a couple of videos they can watch and do a quick beginning in the learning path. 
Yeah, that's it so far. The thing I would like to bring in this conversation today's if it's possible for you guys to have a demo today on this process. Not about the onboarding app as an app, because again, you have to keep in your mind that this is not an application. I'm trying to make passive income, at least at the moment. 
It's just for onboarding people and showing them how they can create a viable knowledge base quite fast. So if you don't mind, we'd like to start with an account in this link.

**Ray | 15:36**
Yeah, sure, this is, by the way, a great use of the.

**Ellie Rofe | 15:37**
Love it.

**dimitris@3nuggets.io | 15:49**
Are you talking? I think it was. I am like.

**Ray | 15:52**
Can you' hear me?

**dimitris@3nuggets.io | 15:53**
Yes, now. Yeah. Okay.

**Ray | 16:02**
I was just saying that asking us to be trying out your thing live is a perfectly good use. Even asking one or the other of us to be just sharing our screen as we're doing it is you know that that's how we can be if that's how we can be helpful today. Let's just do it and get into it.

**dimitris@3nuggets.io | 16:18**
You know? So I had the first demo conversation with a friend of mine for a community where we get into deeper discussion about what happens behind the skins. Because you had the interest to learn about that. He's hired from Zapier for the AI department, so he wanted to know more about THEI and all the graphs and all this stuff. 
But for my on boarding call I estimated 30 minutes where user can sign up. And the first step is for me as an admin behind I can see this user. Now I can see Ellie and Ray. Before you upload your transcripts, we have to talk about your business a little bit so we can specify what is important for you. 
So in that way, I can adjust the analysis prompt so the AI will get, you know, which are the parts of your transcripts it has to focus on, right? For the case of simplicity, I've already prepared a prompt for a Ray and a separate one for Ellie and a separate for Robert. 
And as an admint, I have first to assign these prompts on you. So what I'm going to do before you get active on this process, I will make the assignments.

**Ray | 18:13**
So the assignments help me out with how can we be helpful next? Or are you doing a thing right now?

**dimitris@3nuggets.io | 18:19**
Just a minute.

**Ray | 18:21**
Okay.

**dimitris@3nuggets.io | 18:22**
Ellie is ready to run the process. And in a minute Ray will be okay.

**Ellie Rofe | 18:34**
So do I just refresh that page. Because I had a message telling me that I needed you to assign some prompts.

**dimitris@3nuggets.io | 18:40**
Yes, you have to refresh it. 
So this is a nice bug to know for improving it. E but the everything about u UX is a really secondary priority. The core goal was to complete the upload and the deeper experience the old moment for person, this is what they focused on. 
So after that, what you can do as a user is to upload the transcript. You can select anything just to let you know. For Ray, the prompt specifies that Ray is a technical guy who she's doing business consulting parts, so it knows where to focus on. 
And for Ali knows that you're doing PITZ tech consulting. You are a communication consultant too. You have great experience in this stuff and you have your own application helping people to review their PITZ deck and make improvements. Targeted ones, right? 
So you can use transcripts from there for the data privacy to let you know you can upload them. The data will be saved at the moment in the database of this application. But when you click Delete button, everything is deleted immediately, so feel free to test whatever you want. Now behind the scans, the user can uses his personal graph database. 
So the data will not be saved in the application, but on his application and his graph database. Which means that after doing the work from this interface, he keeps the work on his system and he can go and improve it. He can go and work on that. At the moment you don't have any OVERJ account, but if you have it, feel free to add your credentials so the work will be transferred in this graph database. 
But again, when you click delete, you will lose the data from this database too.

**Ellie Rofe | 20:53**
Okay, I got a five point error from Claude when I tried to upload.

**dimitris@3nuggets.io | 21:00**
Could you repeat it?

**Ray | 21:02**
Sorry.

**Ellie Rofe | 21:03**
I got a 500 error from Claude when I tried to upload API message. Internal server error.

**Ray | 21:13**
For what's worth, I just uploaded us. I just actually uploaded last week's Mastermind. Transcript out of Krisp, which is like 50k, I guess, is 49000 characters. And so far as has extractings. I haven't gotten an error yet, but I'll let you know if something happens.

**dimitris@3nuggets.io | 21:32**
? Yeah, Ali, did you try to upload text fileed?

**Ellie Rofe | 21:36**
Are 51000 characters.

**dimitris@3nuggets.io | 21:40**
Is it a texty file?

**Ray | 21:42**
I'm sorry, the file we need the file with the copy paste thing.

**Ellie Rofe | 21:42**
Tech. I just copiednested.

**Ray | 21:46**
Yeah, that's what I did too.

**dimitris@3nuggets.io | 21:48**
That's it. Yeah, it's about uploading the txt file. Sorry, nice point.

**Ellie Rofe | 21:54**
Okay, yeah, I did it again and it says it's working or it's extracting, so it's got past whatever the initial error was, or it's yeah, it still work going, but it's saying it's extracting, but I can export as well.

**Ray | 21:54**
I did okay, not for nothing, I did copy paste and right now it says step extracting, so.

**dimitris@3nuggets.io | 22:11**
So any in your end does work or no.

**Ellie Rofe | 22:18**
I'll prepare it just in case.

**dimitris@3nuggets.io | 22:21**
Great. So the extract process takes ten minutes or maybe a little bit more. So while it runs, I have the opportunity to explain people what it is doing and how it actually works for me. I didn't bring it as a delay. There is there are tons of actions happening in the backend and that's the core value for my service, my understanding of machines bringing into this up so we can go from there. What's happening. We get the transcript. We upload it on Claude or I'm using Claude for analyzing the data with the prompt. 
Okay. And then we send the prompt to analyze the entire transcript. We get the list of nodes and edges, which is the actual analysis about concepts and relationships between these concepts. Right? Then there is a second step feeding this output back to Claude for validation and enrichment. 
So we have more context on every single output we get from there. For relationships, we have better Descriptions. For nodes, we have deeper understanding about what they're doing in this conversation. The next step is to call the Neopher J, which is the graph database behind the Scres, and check if this information already exist or not. 
If they don't exist. We just have to create them. But if they exist, we have to query them and see what already exists. And instead of overwriting this data, just append the information the knowledge we know about this object. 
So for example, if Ray already exists in my knowledge base and it had a change in mention into the conversation, we don't want to delete the past things, we just append the information for him in that way. 
And before we complete the input into the NEOPHERD at this moment what the process is doing is vectorizing the information and it sends theector data into the graph database. What means vectorizing? It takes the text and converts it to numbers. 
Because Massan can understand way better. What does it mean? A serial sequence of numbers instead of the text. So we help the machine to save the data in a way that you can understand it. Now. After that, we complete the saving. 
So if you upload your second and your third transcript, just be patient it will take ten minutes. But this is what's going to happen to avoid duplicates and overrides. Then you will see the graph being created in front of you. You can check the output, what it looks like and so on, but I can guarantee you that this thing is totally useless for you. 
It's just to say, Wow, this is what I build. Yeah, that's cool. The thing is how the machine can use it, right? So the easiest way to validate the input and the process is to get into a conversation with your data. 
So we have a chat button to chat specifically with your brain from my brain page on the top and left menu. So from there you start performing questions in there, which, by the way, the conversation is not sequent like it doesn't remember what did you ask before? For the next message, you just give a question and you get your response into this thread. 
And when you are ready. Guys, i'm very glad to get into that point to see your experience. And what do you think about?

**Ray | 26:45**
Well, for me, it says it's still analyzing documents, says it takes 05:10 minutes.

**dimitris@3nuggets.io | 26:50**
Yeah, it will.

**Ray | 26:53**
Star totally obviates me. Why? It wants me to keep the window open, though.

**dimitris@3nuggets.io | 26:58**
We have to keep the window open.

**Ray | 27:01**
And why is that?

**dimitris@3nuggets.io | 27:08**
Not sure. The why? Vibe coding said if user closes, most probably we're gonna continue the process because the upload of the document was completed, but I tried two times closing the window and the process was broken. I don't know what happened?

**Ray | 27:32**
Okay, all right. I mean, minor UX thing like asking someone to hold open a tab for ten minutes is significantly increases the chance that it's gonna go sideways on them because they're less likely to hold it open. 
And furthermore, if I just background it, the likelihood that the browser itself murders the tab from a processing point of view in effort to manage memory. I don't know if you've seen that. When you go back after to another tab, it's like, hey, the tab refreshed and I sort of went back to it. Why did do that? Does that because, you know, it's trying to preserve memory for the tabs are actually active.

**dimitris@3nuggets.io | 28:06**
Okay.

**Ray | 28:07**
This is where the ideals streach me. I should upload it and then forget about it. What's happening is you have like in one process or something. In fact, I kind of suspect what's happening is you're using server side events to hold open the process. 
And like it was kind of streaming the result back. And that's the reason why it can last as long as it does otherwise. If you're just doing a regular process, a browser wouldn't let it happen from one /6 seconds. 
But by using SSCS, which is kind of what how things drip in like maybe in ChatGPT, you it will hold open the pipe longer, right? And that's one reason you probably need to hold open the tab is that if you're doing this in the context of a process that is having that long term open connection, if the browser kills the connection, that often kills the server side process, right? 
That's probably the experience you're having before. So the you know, and this becomes like something you can give to AI and maybe off this transcript or something, but like you probably want it to not use server side events or streaming, you want it instead to do the upload and then to asynchronously continue the transcript and maybe email the user later when it's done. 
It's going to take more than a couple of minutes. You don't want the user to be in a have to be staring at a point of view. Yeah, the fact that keep on getting information like now it is enriching 69 nodees. That makes me think it's very likely that it's using that streaming approach. 
That's the reason why you're it's saying, please hold open the page from an actual functionality point of view. I mean, I appreciate that's the way the tech works, but it doesn't make sense in terms of, like, where it adds value for the user, right? 
So like, when I'm completing a purchase, I often get the, please hold open this window, don't close it, because, you know, we don't want to duplicate. Like you go away plane tickets or something. You've seen that kind of thing before because it's talking to the slow system in the back. I get that that's required. 
I will tolerate it for that, right? You don't have to do that here, though. And that's a big source of error for them, too. But you don't have to have that source of error. So that because I mean, I just sort of stick in the back, you know, the opportunity to say I want to fire off a transcript, right? I got transcript, let's do another, right? 
So if I can. In these first. Right now. I fire off a transcript and you're asking me to sit around for 5 to ten minutes? I can't go, chap. I can't do other things. I can't give you more transcripts. What I really want to do is. I gave you a transcript and you're like, I'll get to work on it. You got another one? 
Yeah, sure, here's another one. There are prizes if you could give me five, can we do three more? Yeah.

**Ellie Rofe | 31:02**
Are you thinking business?

**Ray | 31:02**
Because you. You profit if they do it. I'm sorry. Go ahead, Ali.

**Ellie Rofe | 31:06**
No, sorry. So are you thinking of this as you one on boarding people or as a because I agree with Ray on that. If it's self serve, I mean, I agree with it anyway, just because, having played around with open connections and stuff when I was building Google, it was an absolute nightmare. 
Like, wherever possible and avoiding them. But. No, I was just wondering if your goal was because you. You were talking to us about how the tech was working, and I wasn't sure that was part of how you're on boarding people when you're talking to them whilst the process is happening behind the scenes, or whether that's just you talking to us too, as part of the mastermind telling us what's happening.

**dimitris@3nuggets.io | 32:00**
It is what I'm. I'm planning to explain to everybody in the onboarding process.

**Ellie Rofe | 32:06**
Okay, I would. You've got 5 or 10 minutes, which is quite a long time, and there's quite a lot of tense, dense technical information there. I'd be really tempted at that point to just start asking them about their business and just let them talk to you. 
And then you give them a chance to just start. As soon as they start explaining their business to you and talking to you, they will start feeling more connected to you then here, because a lot of that stuff will just go way over people's heads, a lot of technical stuff, not everyone's, but a lot of people. 
And so, like, I have got a D HD so please forgive me, but. And partly because I know some of it already, but I did start drifting off a little bit, and I try to be. You're explaining it beautifully. It's just, you know, self involved, human. 
So I would be really tempted to just as soon as that's going just go fantastic. That's in its way. I'd love to hear a bit more about your business and just, you know, tell me how it got started, tell me where you are now, that kind of thing. 
And. And just let them start talking to you because then you're building rapport with them rather than talking to them about what you're doing. If you do talk to them about what you're doing, I would bring it up a level and make it just a bit more like there's magic under the surface here. 
But here's the basic steps of what's happening.

**dimitris@3nuggets.io | 33:37**
Good point. Yeah.

**Ellie Rofe | 33:39**
Slightly trod over raise points. I wasn't sure what the situation was. And then I ran into my point. But. I hope that's useful.

**dimitris@3nuggets.io | 33:49**
That's why I wanted to bring this app today, to have a feedback on the entire Wordflow and the entire experience from the conversation. It's not about the app experience, it's about how I have to behave perform. Let's say having that and the background doing the explanations. The thing is we have to start for with the business conversation first so I can adjust the prompt to make it more specialized.

**Ellie Rofe | 34:23**
Got you.

**dimitris@3nuggets.io | 34:29**
The thing is, it can work with a default prompt so we can get immediately a basic output. 
And I can explain them during the conversation that I want to know more for your business so I can make it the adjustment so we can have more reasonable results so we can go and test again. I hear the experience about why we are still remain here looking this bar loading so slowly and so on it makes a lot of sense. 
So I think this has some space for improvement. The first thing is the goal for this conversation is to explain them that. Okay, what's the next step for you after blonding list? Because this is just to have a taste, right? The next thing is to go and prepare the recipe for yourself. Go and cook so we can go and cook with you together into one weekak engagement.

**Ellie Rofe | 35:32**
Hey.

**dimitris@3nuggets.io | 35:40**
The entire thing. 
And in my brain, I split it into in three phases. First phase is to demo. After having a demo in this app, let's go with the MCP tools which is quite easy to be established. Let's get on the chat with Claude and start working with your neopherj to feed data and bring questions. Get the questions, see what's going on, delete information, reprocess them again and validate the actual prompt with me. Then we can go to the MVP version, which is okay, I've validated this part. Let's think. What would be the actual use case you want to apply? Do you want to build a chat bot for your customers? Do you want to have it as a knowledge base to share feedback after a conversation? What exactly do you want to build? Let's specify it. 
And the third step, we build all the mechanisms around of this environment to keep this thing up to date. So emails, transcripts coming in, okay? Fit them back, fit them inside and help them assent to grow the brain. 
That's the service I have on my brain. And ideally this can be done in one week. From a feedback I have so far, nobody has thought about doing it in a week. So this is the surprising thing. So they ideally they can complete the engagement in two calendar weeks, but actually it can be three to four conversations with me, including some acing work from my side like the technical part and so on. 
Because the last step, it depends. It cannot be predicted for me.

**Ray | 37:44**
Cool. Where do they see the notes that they that would relate to the conversation you're having about the stuff so far? Or is it just being straight recorded from like you're just pulling it off? Krisp from the meeting.

**dimitris@3nuggets.io | 37:59**
Sorry, can you repeat that? Ray? I didn't hear it.

**Ray | 38:02**
Yeah, sure, yeah, the as I was thinking about this as an onboarding tool, right? As a trust building tool, right? I'm watching it. You know, it's going around using pace of transcript TXT building a knowledge graph. 
Okay, fine. The. By the way, I think there's a quick win here in like replacing PASA transcript TXT with you know, some indication of the title of what it was a transcript of. You can probably like very quickly like use a cheap model, right to take the document in and get whatever the title is for it, you know, or a reasonable title. 
I think that might be something that builds a little trust. Anyway, leaving that aside, the, you talk about the brain. The brain is the, like you say, the chat and the graph. You have my transcripts, the things that I'm uploading, but there's like, what is the, you know, what are the fruits of the conversation I'm having with you right now, right? 
Like, how's that turn into notes or what have you? So the thing I'm trying to sort of describe, though, is you right now are I'm not sure whether you're just sort of taking notes that are going to be put into the brain or whether you are sort of allowing Krisp to do the job, like you're sort of transcribing it as you go. 
But, like, where would I? You know, I think as a client, you might win. Cheap. Easy trust by sharing what that looks like, right? Because right now they can see, of course they can see they're uploading and transcripts, but that's all them sending stuff to you, right? 
And then there's the brain, which is the final result, but there's just a what does you know? What has Demetrius learned about me in the course of this conversation? So like if you're taking notes where I was going to Krisp or what have you, having some way for me to be building trust in the thing that I'm looking at, which you can probably give them for very cheap to free for you because you already have that data, you're using it in order to build out the rest. Does that make sense?

**dimitris@3nuggets.io | 39:57**
Yeah. You mean to use the conversation transcript to bring the, to send them back? No, Genges, right?

**Ray | 40:04**
Well, no, that's what you're going to do is create the nodes and edges, right? I guess what I'm getting at is you have the car. I'm sort of asking how you right now, how you're putting the meeting to work, right? 
Yeah, we talk about onboarding. Part of onboarding is they're sending up transcripts or documents or whatever, right? Part of onboarding is a conversation they're having with you, right? And then you're using that conversation to create basically the schema or the ontology, right? That you're going to then, you know, apply the data to turn into a graph. 
Yeah. So the. I guess what I was going with that was is there a way to give them greater confidence in like what you are seeing about their business based on the conversation? Because right now I can see my transcripts as well. See the one I hope it's not, but if it. 
By the way, if I'm looking at pace of transcript TXT, can I leave the screen, can I go to another one or.

**dimitris@3nuggets.io | 40:58**
Yeah. Okay.

**Ray | 41:01**
So I have an analysis history which is currently syncing. By the way. I would think that I should expect to see that look being in there and syncing just after I upload the first time. Right, upload, done, upload. 
It's syncing. Let's do another. And, it seems like a great place, by the way. The and well, I don't know what else's history as well, so be quiet about that upload transcript. Yeah, that's where I send transcripts. 
And then we have the my brain, which is the graph which is actually starting to come together, right? I've already got some stuff in there that's so cool, man. But what I was going for was, I guess a. 
Maybe it's not super important, but I'm sort of thinking, what can you be sharing with them early in the process to build more trust? Early? And that's why I was thinking about like the results of the not you got from Krisp or what have you as being something you'd be feeding back to them that might be immediately useful insight because as you were and trust building because as you reflecting back to them how much you're paying attention to their stuff, right? In a way that's more familiar to them. Text as opposed to the graph, which could be reflecting that understanding, but it's weird because it's the graph.

**dimitris@3nuggets.io | 42:13**
Yeah. So to use the current conversation, for building the trust, I think we have to complete the conversation with the client. So if we are on the chat with them, we have to complete it first, right? 
Okay. And then what I do is I convert it into, nodes and edges saved into empty file, which is more readable and understandable from the AI and I tell them, hey, this is your empty file. Just upload it on your chat, your favorite chat and just get into a conversation from that th this is what they do. 
Okay, at the moment.

**Ray | 43:04**
Yeah, sure, and of course, appreciates very early days, right? Yeah, okay, cool. How? How else? Sen be a service to you on the, on looking at Suno. It's very cool, by the way. I'm asking questions because I'm leaning into it because it's yeah, it's just fascinating, you know? I'm looking at this graph, I'm thinking, you know, there's a whole bunch of stuff that is quote, people talk about themselves, quote, not enemies. Some of this stuff actually doesn't have any edges to it, so these nodes are just sort of floating around. 
But, you know, whatever. And then like, I kind of say, like I look at my brain, I think there there's if I might, my big piece of UI feedback is every of these pages, like, especially when I'm looking at my brain or whatever. Have them upload another transcript, have them say this cool, I want more, I get more. Another transcript.

**dimitris@3nuggets.io | 44:05**
Okay. Important improvements. Because if they engage with the app, hopefully they will want to build their own. That's the ideal path. Well.

**Ray | 44:18**
This is their graph.

**dimitris@3nuggets.io | 44:21**
Yes, it is.

**Ray | 44:23**
Okay, so what do you say, build their own. What is the thing you're inspiring them to do?

**dimitris@3nuggets.io | 44:27**
To build something outside from this environment because they don't feel it. This environment, their own stuff. They usually want to build their own knowledge base in their own system, their own applications.

**Ray | 44:42**
Okay, that's a good point. So then there's a but I look at this like I don't want to go build my own. I want to use this. Maybe I want to use this. I want to control this. So my first instinct is actually not that I want to go do more work, but rather I want what's next. 
So how can I plug this into my email replies?

**dimitris@3nuggets.io | 45:04**
We can connect it well.

**Ray | 45:06**
Right? But that's but I'm sort of acting as a customer like that is that's the kind of question that's coming into my head. How can I make this richer? How can I make this more useful? And then how can I. 
And then what can I do with it? Which is great, because that's making them lean into doing more work with you, right? So there's a little bit of, you know, there's a chat, there's a summary, there's upload a transcript, and then there's, like, I want to do something else. 
And actually, I kind of wonder whether, like, the, you know, the chat or whatever you do with it, you might want to put in a. Hey, we can't do that yet, but you should talk to Demetrius. Here's a scheduling. 
Like.

**dimitris@3nuggets.io | 45:50**
Ali, is your site completed? Because I saw a freaked the reaction.

**Ellie Rofe | 45:55**
Yeah. No, it's great. I just you know, seeing a brain like STARTART forming.

**dimitris@3nuggets.io | 46:01**
Can you both guys get into the chat and bringer any kind of question? The thing that some nodes are not related is an alarming that something needs improvement. 
And a couple of things in the prompt have some space for extra optimization. So there's an opportunity to explain a couple of things. Look, this is what we can do and I can help you doing a deeper. 
But each node has very deep. Description. So if it is scanned correctly, it can be used in into bring as a response the right thing. What I want you to see in this is how the response comes back to you and the details in the toggle, which you can click on that because this is what makes the reasonable result what it has and it shows you the statistics and the explanation, what information it used to give you this answer so you can validate that. 
Okay, the work for uploading the transcript was good or not. What do you think about this feature? Your feedback, honest and strict feedback.

**Ray | 47:37**
I was just trying to a couple of things here, yeah.

**Ellie Rofe | 47:42**
Because I know we're coming towards the end of the call before I get feedback on that. I would say when you're when you are on boarding, someone just try to focus the when you're talking about this tool at the moment, it's a bit feature heavy because you've built it so you understand all the different things it's doing. 
But try and talk to them about the benefits. So instead of explaining how it all works, explain what they can do with it. If you don't need to ask them about their business whilst the thing is building. Ask them about what they can' do with other systems or what answers they're struggling to get. 
Because then you start seeding ideas in their brain. But like. But try. And because, like, whenever I use a tool, I'm like, what can I do with it? And raised going, can I connect it to e mail? Can I do it with this? What can I have? What can I do with it? 
So I think trying to give them a vision, inspiration for how this can integrate and be part of their World is actually possibly far more valuable than explaining to them the entire process of what's going on behind the scenes. 
I think that that's where there's like, wonder and, you know, fascination. If they're really techy and they want to know that, then absolutely, like, dig deep. But if it's just volunteering stuff, first I would ask more than volunteer. 
And second, I would definitely like to try and be pushing benefits and outcomes.

**Ray | 49:19**
So I'll listen to that and like yeah, because there's enough tech here, there's enough cool and wow here that people just we'll jump to the next thing, particularly if you make it e and I actually think that the easier you make it for them to contribute data, the faster the rest this whole thing creates value for them. I can see a world in which what this is doing is allowing you to. I can see Zap your integration story here.

**dimitris@3nuggets.io | 49:52**
Yeah, definitely it can work.

**Ray | 49:55**
The. In fact, I think that would be a super cool thing for you to do from a content creation point of view is like, you have your brain here, right? And then they can be, you know, you can just sort of upload a couple of things. Hey, look at the cool of this. Now you can go back over to Zapier. Let's have it automatically at things, right? 
That's making as your, you know, Zapier app is what it's called, right? And because it's all first party, you have a three nuggets app, right? They'll prove it because it's a real thing. And then you can have, you know, turn around and be able to use it to, like, generate replies when email comes in. You can be feeding that into a prompt that's going into your you know, three nuggets, right? 
And that comes out with whatever. This starts to answer the question what can I do with it? Right? And the and it puts you in a position to be able to do more with it without you having to expand the profile of what's in the UX here. 
Because I gotta tell you, my hands do things. My brain tells my hands to do things right. So you can give it hands by having the hands be elsewhere. That gives you leverage. And back in territory you know very well, which is you know all these automation platforms because the thing that's missing from the automation platforms is the brain. 
So now and that that's what you were bringing in here. So. Like, the whole. Well, what am I going to do with this? Well, let me show you. Like, let's use Zapier for a second, right? And we'll, you know, have an email comes in from Zapier. You'll just do this, right? You don't need to give this thing any special privilege, access to your emails or do any weird setup stuff, right? You get to use nice big company thing. 
It's relatively cheap. And then here's the magic of it creating either drafts of email replies or actual email replies. And all this can be sort of dialed in specifically to your business, right? Was it the center of it, this graft? The brain? 
And you're and what? What's this thing really about? Is that about them being able to track what's in their brain? That makes this all very compelling, you know? And now what you're doing is has a stone soup quality to it where like their willingness to pay for the brain. Who knows? That sort of goes up and down. 
I think over time it goes up, right? That you might be, but right now it makes you're a Cybork, right? And you are using some technology, but you will then be able to charge for your services to do all the bespoke stuff that's on top of this. 
Because like you say, this is about onboarding. This is about getting them to contribute the first set of data to get that first wow moment. And when they're asking you, well, what can I do with it? So let's talk about what you can do with it, you know, which is not about like using their app more you're not trying to sell them on an app. You're saying this is a brain that works with what are you used for automation? Do you use anything for automation day? 
Yeah, I use Zapier. Let me show how you do in Zapier. I use make, here's how you do it. Make, I use an a and you can show that then you know you already have that expertise and credibility, right? I want this thing to, you know, be able to augment what I'm doing in air table. No problem. 
I know that like the back of my hand. And now you're getting leveragem. So, like, what does that service part look like? And this gets to Ellie's question of, you know, what's the. What's the. Where's the business value? Where's utility? 
And that's gonna be connecting the brain, which is inside my skull and is completely useless. It has no effect on the world except by virtue of my hands, right? Because it's controlling my hands. And like so you can then connect it to whatever the hands are that they want to be using. 
And similarly, the hands are useless if you don't have the brain. And like, you're providing that missing hook, that missing link. You're able to say, well, and you're providing additional intelligence in the form of a conversation that you're having, which is basically how you form the ontology. 
And then you're just seing it. The more emails they get, what can they do with every single e mail they get? It gets fed into the graph, every conversation they gets fed into the graph, and then. But what? What utility is a graph? It can draft email replies, it can send them alerts. When there's something that's, you know, going sideways, there's like you get to, you know, you can use it like Claude boot type approach, right? 
That's got a new names now it's called like Bolt bot or something. But the idea, though, is that the information the graph is where the value is that because that brainge what gives leverage on the rest. 
But it's not enough by itself. And so they are therefore not in a position where they feel like they need to pay for the brain. I mean, you can eventually, I think, pay to charge for the brain, but you can be charging right now for the connection of the brain to the end as a. 
And probably that just continue to provide more and more value to them because the hands are both collecting sensory data which enhances the brain and it will have an effect on the world, which makes the brain's knowledge MATTERMMMMM. This is super cool.

**dimitris@3nuggets.io | 55:08**
Then.

**Ellie Rofe | 55:09**
It's really good as a small tiny logistical question before the call, are you giving them ideas of what transcripts they need to have ready?

**dimitris@3nuggets.io | 55:22**
That's a good point. I have. I have to do it.

**Ellie Rofe | 55:24**
Yeah, it can beful. When I was on boarding people into Google, we had to put examples of their copying. 
And sometimes if you weren't careful, like 1015 minutes of the call could be then just fffing around with files, trying to find something. I'ming and ring. I would give them potential categories. Right? I put in a call which was me in a pitch, right? I was pitching to someone. 
If I want to find three different pictures. Not everyone's got Krisp ready to pop up on their Desktop. And get those transcripts ready. But if I want to find three different ones. Because one one call is just one version of me in one conversation. I'm like, well, if I can at light racing, if I can add a few different ones and triangulate between them, then I can ask better questions. Some people might want understand about their coaching style. Some people might want to think customer service or podcasts or whatever else it might be. You could say like find a cluster of transcripts around these things. 
But Ray and I both have Krisp, so we can go up, open the tray, get the meetings, you know, grab a text, but just heads up. Not everyone will read it, but I think it just helps you smooth people in so that they can be focusing on the cluster and within that cluster. Then it's like, what can I do with this? 
And that might be different. It might be that, you know, some people just want to be able to talk with their brain more or ask really smart questions, and some people want to be able to hook it up to everything and get it to run their life for them.

**dimitris@3nuggets.io | 56:48**
That's good. I had this thought for the interview with Prakash and I thought to use the Zoho YouTube videos to transcribe them and said, look, this is a transfer from this video, let's see how it works. 
And ran the case in front of him following the same logic. Because I had that into my mind. Something they have to prepare and has to be in the exterior text.

**Ray | 57:16**
Yeah, although I love the idea of you having done that ahead of time. Like you taking not just one group videos, you take all of them, right? You just dump them in. Yeah, you do the transcripting, you dump them in. They'll be like a few hours of work for the computer to do it, but, you know, pretty cheap as these things go. 
I think that you know that way you get to show him a result, right? And potentially get to tell him something he doesn't already know.

**Ellie Rofe | 57:47**
Yeah.

**Ray | 57:47**
Yeah, that's the real key people understand the meeting. Yeah, don't understand is how ten meetings connect.

**dimitris@3nuggets.io | 57:56**
Yeah. How nice you going.

**Ray | 57:59**
How's 50? You know, YouTube connector or what have you, right? That that's going to be where you get to show them and people love it when you tell them something they don't already know, right? That's you being a value add. 
That's the wow moment. That's usually the first wow moment.

**dimitris@3nuggets.io | 58:14**
Perfect love it very good point get it. Thank you really may.

**Ray | 58:19**
Very much I appreciate work with you.

**Ellie Rofe | 58:21**
3 go.

**Ray | 58:22**
We will hope it all get to me together again next week.

**dimitris@3nuggets.io | 58:25**
Great thank you thank.

