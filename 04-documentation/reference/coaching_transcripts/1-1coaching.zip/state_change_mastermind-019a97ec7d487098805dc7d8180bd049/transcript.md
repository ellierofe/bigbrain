# State Change Mastermind - Nov, 18

# Transcript
**Robert | 00:01**
But still out. Wow, like how I know it must be cold over there too, because over here it's gone, you know, definitely chilly.

**Ray | 00:10**
Yeah, there's snow outside. Even the point where it looks like my first snowboarding opportunity will be this coming weekend. All of that is good. The temperature in our little condo is not perfect
right now. My office got space here going on and all that allows me to be at a reasonable temp, but when I go out into the main area, it's 50 degrees Fahrenheit. I can't do that in my head or for grade.

**Robert | 00:40**
Yeah, I'm glad we're going the other way. I know I'm a Celsius [Laughter].

**Ray | 00:48**
All right, well, everybody is here. Let's go around the horn. What kind of week has been? What do you know today that you did not know a week ago? Ellie, can we start with Ma'am?

**Ellie Rofe | 00:59**
Sure it has. It's been a fragmented week again. So I was back at home, I was traveling to visit people.

**Ray | 01:06**
Recording in progress.

**Ellie Rofe | 01:10**
That's right, I was traveling variously to visit people. The major achievement of the last week is getting the landing page ready for the event we're running. I'm actually just now trying to finish the first LinkedIn post I've done
to start publicizing it, but from now on it's a daily thing until December 5th. It was good, and it's been really interesting working with Natasha on it, and we're finding really useful ways.
I know last time I said that it was finding the balance on the copy was difficult. I think we're actually really getting to that now and understanding how things work. So I'm excited for it. I'm hoping we get some sign ups, but yeah, other than that, it's exciting.
And we shifted the I don't know if I mentioned the strategy, but we shifted it to a paid event that's like 497 euros for half a day. And I was like, Interesting. But then I was thinking we're looking at seed and Series a raises.
And it is five hours plus a community plus two office hours plus, you know, a SL clinic. If it if it's too cheap, it's just going to look ridiculous. So we shall see whether this is a gateway offer or whether people are like O no waymte.

**Ray | 02:39**
That's super cool, super excited to see how well that goes. A deris... How come what was true today that was not true a week ago.

**Demitris | 02:55**
The truth is that I had two engagements. Very interesting ones. The first one is with an existing client who came back to me. He's a business consultant, building tech staff and trying to sell to big companies, traders, sailing companies and stuff like that.
It was very interesting because he came to me very anxious for his NA and workflow. I never thought of that again, but I was able to handle that and guide him because totally the same thing, the same recipe, the same logic behind the skins. Today, wait, to complete the entire Holland and ran successfully a couple of cases for him so he can go and demo.
He was so excited. I joined that as a win. The other engagement was not a paid one, but it's a person I met here in the local area. I joined a startup event last week. We met right there and then after that we had a coffee where we met and he... With a lawyer background.
He creates a huge logic of prompts and the prompts. The logic of the prompts. He won't automate the workflow that from just three simple inputs it can generate an x number of limiting posts. So this is his workflow.
So we started working together and the promise was that I can record a couple of videos, I can take all this concept of the core building of where we're doing together. He actually invited me to be a co-founder on a startup kind of thing.
I regret it, of course.

**Robert | 04:58**
Because [Laughter] there are.

**Demitris | 05:01**
Tons of alarms. We discussed them many times. And here is a nice other win. It was a conversation I had almost one year ago with Ray, but what would be an approach? Doing a product instead of NVP, showing a demo and that event. IG, Gus, everyone, even people who are entrepreneurs, even founders, even investors. They said if you don't have a product, don't come to talk to me.
But the thing is, who is the person we want to talk to? Is it a client or an investor? If it's a client, just bring the final value. So I tasted my approach during the sessions over the past year, and I was able to handle that from the first moment.
Say okay, now, thank you. I can get that from the point of making content, and that's fine, thanks. So I expect tomorrow we can complete it so he can go and demonstrate it.

**Ray | 06:08**
Super cool. And that that's sort of cool funding the, you know, where the value is in that, cool be. So, Robert, what can we get better for you and how can we be of service to you? Because I think today is your hot seat.

**Robert | 06:24**
Yeah, and I completely forgot that today was my hot seat until this moment. So. But I think I can come up with something. And the last week, what's different between the last seven days? I had some really good conversations with the market.
I have had conversations with two people, two people who definitely... One person actually emailed me today asking for payment details. And the only thing is I'm trying to actually... I'm pretty happy because I steered this person more towards a coaching direction very heavily because it's a very non-technical person who I can't build it for at all, right?
But somebody who maybe can put together their efforts, maybe to learn the skills in order to develop it alongside technology. But yeah, I'm trying to make different offers for different parts of the market, which I'm trying to serve in different ways.
So I'm happy because between both of those people, they were just very different offers that I'm putting down in front of them, and they both seem to be interested. It's just that one will take longer than the other because of the value of one versus the value of the other.
That's interesting, and I'm realizing now how I'm trying to manage the two paces of that and even the different ways of delivering all this different stuff. I'm like a vending machine, basically, but with a lot of different options and a restaurant, right?
Trying to just offer all these different things. Yeah. So I got an encouraging email from a person who I thought was maybe a credit risk recently, but it seems like we smoothed over. There was nothing even really to smooth over.
It's just like he was just... It's like somebody was just disappeared for a little bit, but then reappeared, and now I'm trying to just be friendly but annoying.
Just annoying, but so friendly, and that's why I'm happy for FreshBooks, maybe because it just keeps pinging them, and the machine just keeps beside me. It's just fresh books that just keep saying, "Hey, reminder."
It just keeps getting bombarded. So anyways, yeah, that's what happened in the last seven days, more or less.

**Ray | 09:34**
Right? Well, I'm glad that the collection risk guy is back in the picture because that means needs cash flow, and cash flow is good. Yeah, how can we be of service to you today? Or put it differently, what is it that we can do for you?
Here's what I think about the leverage point, right? What is the hard part as you look at your week or your next couple of weeks ahead.

**Robert | 10:10**
I think maybe the hard part is... It's a good question. I think maybe the hard part is just... But I'm just more... Maybe I'm just curious. I'm more curious about two things. First, if everybody wouldn't mind sharing something about who they listened to,
I think it would be really interesting because I've been listening to more people lately and I'm just wondering who you listen to because, usually, when there's a lot, there's a lot that you like. I was putting a podcast on for some of these people, and I'll just listen to ten hours of them talking, and it feels like you get every idea they've ever had if you can listen to them for ten hours. Then, you're free to do other things.
So, yeah, if there's any recommendation for a person that you found to be someone who can have ten hours of content and so on, usually that's somebody who has probably a lot of good ideas.
So I'd like to get those recommendations and something else I think that's on my mind is just the idea of what you guys do if there is anything that you guys do to try to keep things short and sharp, maybe what are your thoughts on that or strategies on that if you're doing that?
So yeah, two questions, I suppose.

**Ray | 12:02**
Okay, sure, we take them. Maybe one at a time. You want to pick the one you want to tackle first, and then we can... Then when you're satisfied with that, we can turn to the second one.

**Robert | 12:09**
Sure. I think the first... We'll just do them in the same order.

**Ray | 12:14**
Okay, so the question is, from the point of view of listening, who do you know, listen to? Which is a podcast, media author, that kind of thing, right?

**Robert | 12:27**
Yeah, I was thinking, like, those thought leaders, mostly WI. I was thinking, yeah.

**Ray | 12:35**
All right, well, then let's ask that question. Ellie, can I pose it to you?

**Ellie Rofe | 12:41**
I can. I haven't got a huge amount of help at the moment. I haven't been listening to an awful lot of business podcasts over the past eight years or so. Probably...
I have listened to lots of different people, some of whom I think were a bit more mass market, maybe a bit more junk played in content. Now I look back, but yeah, I don't listen to a huge amount of business podcasts. I listen to all sorts of podcasts, but the business ones, for some reason, I find awful to listen to. I can watch things on YouTube. There are people who I think are really expert, but a lot of it is quite heavy marketing stuff, so I don't know if it's relevant.
There's a guy who runs a Facebook group called "Nothing Held Back." His name is Alan Saltanic, and some of his.

**Robert | 13:43**
I'm friends with that guy on Facebook.

**Ellie Rofe | 13:45**
Are you.

**Robert | 13:46**
That's so funny. Yeah, because that's actually really interesting. Yeah, he has some pretty good stuff. I've actually... One of the few people who... I genuinely thought
this guy's pretty knowledgeable.

**Ellie Rofe | 13:58**
He is not, he's like one of the... He's very... He's kind of deep technical copywriting, but he actually... There are some people in that who are really like the people I think of that treat customers like ATM machines, they're just like, "How can you get money?

**Robert | 13:58**
He's not a very well-known person. It's kind of funny, he's not that well-known in the grand scheme of things. Interesting.

**Ellie Rofe | 14:24**
Churn money.
But he just actually has an interesting philosophy. He has some really interesting insights into. It can be small techniques or it can be overarching. Thinking about copy. But it can be too deep sometimes if you're just trying to get stuff done, like you're not trying to turn a million pound page.
So he's really good.

**Robert | 14:45**
He knows why somebody wants to go on a diet. He knows the deep thing. The psychology of what it is that person thinks about when they get up in the morning. What do you have to write for that?

**Ellie Rofe | 14:55**
I think financial services, but, I could be wrong, but yes, loads of people in that group are in the supplements game, in the diet game. Like, there's, you know, health, wealth, and. My God. My brain's just gone. Health, wealth and status, I guess.
But yes, yeah, exactly that's it.

**Robert | 15:17**
Yeah, in relationships, I think. Yeah.

**Ellie Rofe | 15:25**
And he's that kind of person, I think, finding the equivalent of that in whatever vertical you're looking in is really useful. Some of the broader spectrum stuff can be really useful.
But that'.

**Robert | 15:41**
So sales content in a way, because I do find that's actually helpful because I think maybe that's where I'm at.
Maybe that's my doorknob question, actually, in some way, is that actually like what are your sales strategies? Maybe that's what I'm trying to drive at because I've noticed that the more I listen to content about sales, the more my actions start to align with doing more sales-related actions. I just start to look at my offers and structure them more in that way.
Like you mentioned, Al Stonic. Like, I think what one thing is, he talks about the history of the video sales letter and the different... But sales letters in general, and those strategies work maybe.
Yeah, I think that's maybe where I'm lacking. I think I was having that thing that's really easy to buy at the end of this thing that just explains and breaks it down and tries to make it compelling and say, "Hey, this is what you should buy."
This is how much it costs, and this is how much you know, when you put it all together, and here's the value, and here's what you're getting, and all that stuff. I guess people do that because it works.
But I don't know much about... I think I know how to do that, but do I actually now? Probably not.

**Ellie Rofe | 17:03**
And is where I'm working at, right? This landing page took me a while this week. I did the copy and the design, but I worked through the copy with Natasha. Which is helpful. Having a second party to play with ideas with you
and see where your blind spots are. I think the place where he's useful is finding areas where it's so easy to spin your wheels on this stuff. Actually, one of the ideas I've used to great effect this week is the Todd Brown thing, which is a sales page angle.
It's four dynamics that you can have through a sales page. Is this novel and groundbreaking, or is it safe and trusted, or is it going to save you time? Whatever, and find the angle that you're going to push through that smells pain so that it remains consistent. You're telling someone something. The reason to understand these things is mostly for me because it saves you time.
When you're crafting something, like we worked out when we were talking to founders. A big thing we're going to talk about is you can spend five months trying to do your raise, or you can spend five hours in a room with us working it out in advance and then be able to focus more on your company. Now, that time-saving opportunity cost angle is we're going to test that out as a big part of our sales. I'm not being very eloquent with this, sorry,
but basically, I think you can end up too deep in the weeds. They'll be like, "This is the one word this year that's making a difference on a sales page." Or, "Here's the one thing you must do." It's too much. We're at too early a stage in our business to be trying to finesse copy on a sales page to the point that we are increasing conversion rates by two percent. What we need to be doing is just getting stuff out there and then seeing what happens in response to it and then using some of those techniques, the improvement techniques.
So yeah, I guess it's like, what are the baseline techniques you need to get something out there? What other than the improvement techniques can you use to finesse it, improve it, or know when you outsource it to guess.

**Robert | 19:23**
Well, or maybe I think that it seems like the conversations would turn back into the content on the landing page anyway. So, it's like you just have whatever conversations you have, and if you manage to obviously call somebody, you end up pretty much... If you can have a tight feedback loop on just updating your copy based on that,
maybe that's the way or one of the ways.

**Ellie Rofe | 19:49**
Well, and with that, I'd probably say the same as I say about feedback from when I talk to families about feedback from pitching. Don't necessarily change it after every call, but change. Have a review up every five and see what the signal is across those things and whether there's some really consistent themes or some really beautiful language that someone's used that's very evocative or makes sense, and then feed that back in.

**Robert | 20:11**
Yeah, you're cause it's easy to overreact.

**Ellie Rofe | 20:13**
But yeah, absolutely those cos.

**Robert | 20:16**
That's true, because it's very easy, actually, to overreact the other way, like tweak and so on. But to your last point. By the way,
I've always found it impossible to outsource, for me at least, for something like that, because I just think that it's just... Yeah, like it, but it's just difficult, right? I don't know, I've just haven't found that to really work for me, but yeah, thank you, that's actually very helpful. Cool.

**Ray | 20:50**
Diatrice, could I bring you to the party? Who do you know? Thought leaders or just the folks that you are listening to today, using whatever medium? I think that Robert's family consumes it through his ears, right?
So that could be lots of ways to get things into your ears. What have you got? Who have you got? Are there particular names sticking up to you?

**Demitris | 21:16**
Yeah, actually, the way I select people is by who is talking for the things I'm not good at. Because I want to take them there and know how somehow, I recognize that I'm good in a couple of things during the week. I'm getting better because of the nature of my work, but in a couple of things I'm not that good.
For example, in content, in social media, in communication, in marketing and sales, this kind of area, right? During the week, there is no default workflow to create a process to getting better. So I do podcasts. I listen to podcasts every morning and I read books in that domain.
So I prefer to listen to people who I think I would love to drink a coffee or a beer with them. I tried in the past with many people. For example, there is a nice podcast about growth hacking by the author of this book, an incredible book.
But truth be told, I couldn't listen to him for more than 20 minutes. We just didn't have a match. Incredible conversations, incredible ideas, but I couldn't follow. I like Alex Hormozi, but I cannot listen to his podcast. I like Gary Vee, but I cannot listen to his podcast. They're just like multi-tasking guns, they just throw too many things. I cannot save anything.
So who I'm listening to, I really enjoy E. Rory Sutherland. Not only for his ideas, but for the way he thinks when he generates these ideas and the way he uses the language. Language is Sutherland.

**Robert | 23:23**
By the way. Sorry as well.

**Ray | 23:25**
Yeah.

**Demitris | 23:28**
Even when he swears, you know, he uses bad words. Nobody can tell him that he's impolite.

**Ellie Rofe | 23:35**
[Laughter].

**Demitris | 23:37**
It's incredible. And I like his style. I like his way of thinking. The other guy I'm listening to is Chris Do, a more strict person, more professional, with too many things and a different way.
But he's very very capable, and he shares very nice ideas. One idea at a time and at the moment. I transcribed a couple of videos from Chris Do and TED to create an AI ontology, a twin of him, to use him on my side doing some content because I really like the way he thinks. And I stopped at those two guys. People I would love to have coffee with. They are pretty enough as a company in the morning. And one last tip: I listened to one episode for the entire week, which means every single day, I replay.
Yeah, it's not because I'm stupid. It's because we're listening while we're doing something else. I'm doing some work on that house or doing any kind of things, and I want to feel like, okay, I get everything from this podcast. I don't want to just make it a list. I want to get the most out of these things.
Every time I focus on something else, that's pretty cools.

**Robert | 25:16**
I actually appreciate those suggestions. Yeah, Chris, though, I think I always noticed his content for him being one of the people who really heavily encouraged pricing at a very... Trying to essentially position creative work at a premium rate, right?
Just the challenge. I think that for him, he's trying to sell something, and I think that really gets challenged by the prospects a lot, right? Which is like, how much are they going to pay for a logo? Or what is a logo worth?
So I think that probably helps, especially maybe for those industries if it works for that, then I think because that might be a tougher thing to sell, even if a person might consider it that way, compared to whatever a person has to sell in the market.
So I think that it's different, right? Now we have AI and everything. So even his brand has kind of shifted, I feel, from who he's even trying to give advice to on what the expectations are from the market.
But anyways, yeah, thank you for that. I appreciate those suggestions. Check it out, yeah.

**Ray | 26:39**
Those are some good ones. I actually really... I'm thinking about the Chris Doe thing because when you compare that with Sutherland, right? Sutherland wrote a book, and Sutherland does the traditional speaking circuit. Actually,
there's a little bit of Rory where, once you've heard a couple of his talks, you kind of know the pattern. At this point, it's super worthwhile to hear, but I'm not sure you need to hear it 50 times.
I started knowing that because my boys are very taken with Rory Sutherland. I got them. Alchemy. They really like it. Then they start looking at the T-Rex. But the T-Rex is becoming comfort food.
You know, it's the same stuff, and there's some benefit to that. This is something that was talking about the idea of, if you hear the same ideas pounded back into your head, that's pretty valuable.
I was thinking about that in terms of... That's why I find books to be a great way to get things into my ear because books keep on repeating the idea. It's often a thing that was originally a good article, and then they buff it up into a book.
Well, because it's basically the original idea plus a bunch of case studies, plus you can restate it at the end. So you're hearing the idea mashed into your brain a few different times. I actually think that the way you're approaching it makes a heck of a lot of sense. I'm not a huge fan of the podcast format. I find it to be super low discipline.
I say that as someone who does a weekly livestream podcast with you. Which I find to be a really interesting conversation. There are some other people who seem to like to listen to it, and that's nice.
But the what I really look for are people who have organized their ideas and then are presenting them back to me. I find short form, long form, for that or gain that kind of concentration.
The short form, if you haven't done it already, TED talks are great. TED talks because they're a great way to pull ideas out and to be exposed to a lot of speakers and thinkers. You might not have thought about it yet.
So I found that to be a neat way to get... I think TED talk length is pretty much ideal. I think most conferences that do a 60-minute talk, the talks are too long. There's a sweet spot in terms of being able to really communicate an idea and put bones on it.
That is the 15-minute TED talk that works really well. So, as a density of getting ideas, I found that to be really helpful. The only podcast I've listened to consistently over the last few years is the Built to Sell podcast by John Warrilow, where he's just interviewing somebody who has sold their business.
For me, the useful part is, "Okay, what's the common thread? What's their story?" Their story is always a little interesting. Those people who are really passionate about their business, sometimes with somebody who was selling, like, cannabis products, boy, they just sound like a drug dealer from the beginning.
They succeeded, right? They sold their business, they made their money, and they get to move on. So, what do they do? What does the business require in order for it to be getting to that state where they're selling? What makes an acquirer? What gets them a good multiple? There are so many where the business is sold for... We got a 20 million dollar outcome on a business that was doing $10 million a year in sales. Clearly, they were just tired and had to lay down their burdens. Or someone who really built a rocket ship, and someone else sold it to someone else who was going to grab onto it and keep on going up with that rocket ship or what have you.
Anyway, I found that to be really useful because it keeps idea-oriented on what builds equity value. That's the only podcast I look at because it takes that guest format.
Then, I'm just looking for good books. The author, if you haven't been listening to him so far, is the marketing author that you know. I have an easy time recommending him. Seth Godin
is an author in a way that is unmatched by other marketing experts but is matched by some of the sales experts you've talked about before, like Ryan and Ziglar and what have you. He's really taken to audio media. He even has one of his books as audio only. I forget which one it's called.
It's like "Step Up" or something. He likes to read his stuff, so you get to hear Mr. Gor's voice, but both his talks and his books, I found, to be superior content and ideas that just make a lot of sense.
What's a "Purple Cow"? It seems like such a weird idea until he explains it, and it seems like the most normal thing in the world. What's a "Meatball Sunday"? These terms and phrases then become pretty helpful.
So, I found it to be pretty useful for just thinking about that. That'd be the person I might recommend you to. I guess that's the podcast I might recommend you to and the forum I might recommend you to in terms of trolling for people who have ideas worth listening to.

**Robert | 31:56**
Thank you. I took and have them all open up in my tabs now, so I'm going to check it out for sure.

**Ray | 32:10**
Can I quickly ask Demetrius? You were recommending CRO. Is there a particular podcast, a book, a series, or what have you that you recommend to get the best out of them from Chris.

**Demitris | 32:27**
Though, yeah, I would recommend his YouTube channel and the podcast. Okay, he takes in nice interviews, talking to people who have achieved something on LinkedIn, on social media, or anywhere, and they get into this conversation.
I like the output of the conversations. These are incredible, and I like his monologue videos because I would love to record similar videos too. He talks with fluency because he knows what he wants to say, not because he has written the stuff.
It's super clear that. And I like that, and I agree with his principles he mentions, regarding books. He didn't write any book. He recommends many times multiple books, but most of them are mentioned too many times in our Masterminds.
So yeah, I think just start listening to him. By the way, the recommendations from Ray I used to listen to those two, Seth Godin and together with the built with E, really incredibly, but very long. I didn't get into that one. The one was quite long to me, and I found those guys a bit more engaging somehow, but I really recommend them too.

**Robert | 34:18**
And I suppose the other question that I had was just about keeping things short and sharp and maybe just your thinking around anything that I could pick up in terms of your thoughts on sales, right?
Because I think that that's something that changes pretty quickly when you're in the market. As much as I think all of us are trying to be consistently as you... If that is something that you think about a lot, I'd just be...
Yeah, happy to pick your brains on if there's something that stands out to you as a mechanism or a way to look at your current engagements or the engagements that you want to have and think, "Okay, I'm trying to put it into this box where it takes two months." Do you not think of things that way? Are you trying to close different types of deals?
I think I'm trying to get my mindset, I think more into the sales side of things in general, where I'm not as well versed. So it's hard for me to even put together just a question about it.
So yeah, and Ellie, I think probably you would have the most experience when it comes to... I think so. I would say definitely more experienced than I do. So, yeah, I just want to put that question out there, and I'm happy to go back and forth on it.
If it's still too foggy.

**Ellie Rofe | 36:21**
Yes, I mean, it's a great question. In the sales, I think, it's something that evolves from my personal experience and that of stuff I've seen with clients as well, the wider marketing world. It does evolve as you get to know your offers more and your audience more, and you get to understand...
I think you get burned as well. That's just part of the learning process, right? You get some terrible clients and you work out within your world what a good or bad client is and how to spot the signs early on.
That's a lot of the evolution for me at the moment. I'm trying to work out how to get the right people in the door in the first place, how my marketing and efforts there can be the first filter of it all.
So that and who I'm targeting and approaching. Having worked with some very early-stage companies, I've worked out that keeping it short and sharp was very difficult. It's just that there probably isn't enough juice to squeeze in those companies to make it worthwhile to have a very long-drawn-out engagement.
So then I'm thinking, right, so we shift the marketing, and so the marketing for the event is about people raising for a seed. So, people who have funding who've already raised, who aren't completely naive to it.
I'm then trying to attract people. I'm redoing my website a bit. So, I'm trying to attract people who are further along the line, and then I have ways of nurturing people who are earlier, potentially, tools and AI things that I can have for people who are earlier, either to self-serve or to have a very low-cost, short, sharp diagnosis engagement or something.
That's in my last post. That's kind of where I was working with you guys towards the end, finding a way to give people a win within a week of working with me, but figuring out how much is still to come with
their work. How much strategy? Because in what I do, everything depends on how clear their strategy is. I can cope with someone who doesn't have a brand, and I can cope with someone who's a bit scattered, that kind of thing.
But if there are big chunks, if there are any gaps missing in their strategy, and they don't know what they are yet, then that drags something out for ages. So, for me, that's really been the process of trying to work out, and Ray and I discussed in my one-on-one, how to make sure I've got products to meet people where they are.
For example, the woman who has e-materials, advanced materials, she is already in the process. She already had a vendor to do the deck. Is there a way I can offer her something that gets her a win, that gets her into my ecosystem, my world? We build trust together with it within that point.
Then, is there a way I can get people earlier in the process? That's what the events are really trying to do so that they can come on potentially for a full engagement. It's all more streamlined.
I'm not trying to rescue the one mid-flow of the fundraise. So, I think for me, sales have never massively been into scripts and things like that. I think naturally, when I think, I have a natural rhythm when I talk to people because I just want to know where they are in the process, and that naturally gets to what their problems are.
That naturally leads to how I can help. I do a little bit of strategic brainstorming or diagnosis with them on the call so they can see what I can do. And then we get to how I can help them, etc.
But I don't go massively into scripts or structures, and I probably need to refine some of that. But my biggest thing really with sales is I think it's understanding the intersection of your audience, your offers, and the wider marketplace.
So the competition, effectively. Then just the more you understand that, the more you get to refine things and tailor things.

**Robert | 40:58**
And sounds like, having the ability to dynamically put together offers, I suppose, and which is something that I think takes practice or time or a lot of energy, at the very least, to do.

**Ellie Rofe | 41:18**
Yeah. I think that's AI. I think that's a choice as well. Do you want to do that or do you want to just say, "This is what I do"? My instinct answer to that question and I've had it hammered into me over the last five, ten years is that you just have offers, and people pick them up.
The concept of the VP Day went massively viral in the business community because it was like, "I define everything. I deliver something in a day, and then I walk away, and I can flex my entire business based on what I want to do."
I do think that's really valuable. But I think that especially when you're starting out, there is a value in flexing a bit and trying to understand what you can offer and experimenting a bit.
Unfortunately, for me, definitely, it's more intensive. It's more time-intensive. You have to think about what you're offering someone. So, with that, Maddy woman, for example, I had to think, "You have to run a SWAT analysis or an offer very rapidly to go."
Right, what are the things I can offer them? What are the strengths? What are the things that might not be addressed in this so that I don't overpromise what we're going to achieve? And where are the risks for me?
Like the threats? What are the threats? For this, someone else is doing her deck, so I can't promise her leads of staff and then find out that the deck is an absolute mess and it would take me 20 hours to try and fix it.
For example, is this a way that I can open a door to get into more? So you're that way. That's my way of thinking about bringing together an offer as quickly as possible.
But it is for me, it's quite time-intensive at the moment. I spent probably 90 minutes to two hours after the call in two sessions, one immediately after brainstorming and then one in the morning refining, pulling together a proposal for her.
So it's not streamlined by any means for me, but it's just... I feel like at the moment, maybe this is too servile, but at the moment, I'm just putting in the yards, just putting in the reps and trying to work out how the offers are going to work, how you can tailor things to people to make it work properly.
So yeah, that's where I am. But I think, longer term, you get to what I guess Priestly would call the perfect repeatable week. Or, Russell, what's his face, would call your offer ladder. You get to a point where you work out these things,
and you have structure, and you can have all the infrastructure around them as well. Thank you. Russell Branson, Pleasure.

**Robert | 44:12**
Yeah, makes sense. Thank you.

**Ray | 44:18**
We just quick on you, sir.

**Demitris | 44:21**
Yeah. Robert, do you face challenges with time to get things done fast? Because on the statement of delivering FAS, sharp and fast, it's about the speed, right? Yeah, what usually causes the bottlenecks.

**Robert | 44:59**
The that's a good question. I would say probably Vloneck would be rediscovering. Discovering. Sometimes, like the Trojan horse that is in the app, I suppose sometimes, there's an app in the app, and you're drawing.
Because a lot of the time, people don't really know what they actually want at the beginning. It's sometimes... Yeah, you usually discover after a couple of discussions with them what it actually needs to be.
I don't... Yeah, so I would say probably in general, maybe it could just classify it as rework usually slows things down. Any time you have to go backwards, it's usually going to be something that slows things down, and so it's almost like if you just had a perfect blueprint at the beginning, it would make everything very straightforward. You could just go and build exactly what needs to be built, but the blueprint is coming from a person, and that person is only going to tell you whatever you're going to draw out of them.
Sometimes it takes something existing in front of them to even elicit a realization in them or some type of the journey itself of having gone through this and then having them. Now they're paying for it and them having thought about it now from a different lens and after the conversations you've had and after they've had the nights they've had to sleep on it.
Then they want... So, yeah, that's what I... Maybe that's why, and that's what you're delivering. I think part of that is as well, me being adaptable. So yeah, that leads to things slowing down, but I'm not sure if that's a bottleneck or if that's just part of the service.

**Demitris | 47:04**
Yeah, I would be surprised if anybody says they don't face this challenge. It's quite common for someone to get on the call asking for something, finally meeting something else. They realized from the conversation with a good consultant that they need something else.
Goes on here I see the opportunity to use this time on your own for your own good purpose, good reason, which is to explain them. What is the discussion about? I had this experience back on Saturday. We joined the call with the good example I mentioned at the beginning of the call and during the first 45 minutes we were working on a workflow where I was thinking that this workflow was doing something else than the thing that actually does because there was miscommunication.
Totally. The guy was so stressed, so painful. He had only one hour to explain to me what it has to do and all of this. So yeah, but it was actually an hour of my time that has to be paid. So when we realized that, I explained to him.
Okay, we found out what's going on and this is part of the work to figure out why your previous workflow didn't work. So it's totally clear, it has to be charged. For example, if this time is charged, that's good for you, even if it's not valuable time. At least it's not costing time right now from my perspective. I see that every early engagement has these things.
It's about how you know. It's to know us better with a client. To learn them how they communicate, what their problem is, what their next goal is, where they want to go, and all of these things. I think we need some time on that.
But after that, we'll take the flow, right? So that's it. Regarding the time, another way is by pushing you, the client, more than he pushes you. So when he says, "I want to make it done on Friday," okay, let's do it on Wednesday. Let's do it on Wednesday.
Yeah. Come on. Why? If he is actually so busy for that, maybe he's not so serious about that. A good sign not to spend more time with them. Because when someone says, "We have a lot of work to do." Why are you here? You said, "Okay, how?"
Yeah, maybe there and there because it's not at the top of the priorities, but they want to solve it. That's good, but it's somehow in the middle of the conversation. So my response to you was mostly about how you can manage the time you feel you're losing. Instead of losing it, hope that it was useful.

**Robert | 50:40**
No, for sure, it is useful. And I appreciate the perspective of challenging the client. I think that probably there's a whole client dynamics discussion to be had.

**Demitris | 50:53**
Potentially challenge them that don't overpromise them. There is a very tiny line between those two. [Laughter].

**Robert | 51:04**
Yeah.

**Ellie Rofe | 51:07**
Are there any patterns in what you get by the time? Is it that they've worked out a certain level of user story understanding or something? By the time you get to a good product that they actually want, what is there? What's the missing piece that they don't understand when they come to you?

**Robert | 51:29**
Good point for me.
What's the missing piece? When they come to me? The missing piece is they want to go faster, and they just... That's usually the missing piece. What in some way or another, they want. They're using Xano or whatever they're doing, and they just don't know. They see... They don't know what to do with Visual Studio or what to do. They just like...
And they just want someone to just be like, "Hey, okay, download this, install this, do this, go here." This works, do this, type this. As a simple way, I suppose that if you take all those people, that's basically what they want.

**Ellie Rofe | 52:20**
[Laughter].

**Robert | 52:21**
Put that on the landing page.
I will point and click, $300 an hour.

**Ellie Rofe | 52:33**
Got you. So the process of working out what they need is the engagement, Basically.

**Robert | 52:42**
In real time while building the thing they need or whatever. It depends a lot of time, but basically, just being a really good group member.
You had a closed loop. It's just like being AI. Think of me, it's like being in a group, and you just try to be... There's always a person in a group who tries to do the most work,
and I'm just trying to be the group member who just does the most work. Then that's it, right? Everybody usually appreciates that person on the Leisure.

**Ellie Rofe | 53:28**
Got you.

**Ray | 53:31**
I think that is a point of self-identification that's worth revisiting because how you see yourself and therefore how you mark yourself as that person... I think both there are some ways to be taking advantage of that and some ways to be...
Yeah, that creates some risk for you, that might not be totally necessary. So that's... Yeah, I would encourage you. When you're doing the replay on this, just take a note that you said that about yourself because I think it's something that's worth meditating on. I'm not trying to say it's necessarily a wrong thing.

**Robert | 54:06**
But it is.

**Ray | 54:08**
A distinctive thing. And I think when I think about like what's been revealing in the course of this session. I think and the value of the door knob question as being revealing about the person that line I would I think it's definitely worth some degree of metation.

**Robert | 54:23**
It's my rosebud. My whole life is based on that. Everything.

**Ray | 54:34**
Slide man. All about the slide. Okay, I think that brings us to the end of our hour. Robert, do you get what you were looking for out of this segment?

**Robert | 54:43**
I was for sure. Thank you.

**Ray | 54:47**
Thank you all. This is fantastic. We'll talk at the end of the week, and we'll do this again next week. Just so I'm putting it out there so that nobody's forgetting Ellie, it will be your hot seat this coming Tuesday.

**Ellie Rofe | 54:56**
Yeah, okay, fabulous. Thank you.

**Ray | 54:59**
Alright?

**Demitris | 55:00**
So that would be my week.

