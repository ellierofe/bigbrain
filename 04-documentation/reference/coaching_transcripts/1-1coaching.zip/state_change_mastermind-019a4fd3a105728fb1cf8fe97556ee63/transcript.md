# State Change Mastermind - Nov, 04

# Transcript
**Robert | 00:04**
I'm just trying to send out, actually, to see if I could start a long-running process in the background.

**Ray | 00:12**
Okay.

**Robert | 00:13**
But David just got that going. I'm just... I'm sure you saw a message, but it works. The thing we discussed yesterday, it actually works. It works ridiculously well, actually. So go ahead. Yeah, I'm putting together something in Canva to really get the point across.
Sorry, I guess this is what changed in the last seven days, but just to say. This is a way to get it across that here's a number of tools before and after because that's actually...
Yeah, just to say that we'll catch up about it. I'm sure. I'm going to be tagging you in the post, of course, but I think it would be really cool to get your input, obviously, because it works really well.
It's kind of mind-blowing, actually. So, yeah. Thank you. I'm looking forward to to.

**Ray | 01:20**
Yeah, we're... Robert and I had a discussion about applying a layered tooling approach to MCC, which is an unusual thing that I thought might be a fit for Snappy. Well, we'll, it certainly gets to use a lot fewer tokens.

**Robert | 01:37**
That's something.

**Ray | 01:40**
Okay, cool. Okay, so, Robert, I'm going to kick off with you again, sir, because I'm glad you're excited about the token thing. I want to just check in on where you are in the practice, right?
Where you are with some particularly the sales stuff that was subject to conversation in our mastermind last week, for sure.

**Robert | 02:01**
So it's actually going well. I'm trying to get just more clients. Obviously, I had a call today with Mark's team and Mark. And so it made me feel that I do have leverage with some of these tools, especially with this Honest.
The upgrade made it turn more into a stronger asset in my mind because now it's something that I can more easily recommend with this adjustment to it, and it becomes again something good to be in my orbit, a benefit of being in my orbit. Basically, I think that's the main thing. If Mark, which I actually do see it coming into the future where we basically continue to do more work, and he'll pay for consulting calls and so on.
One of the benefits for him is that his team gets to use the tool. So it's maybe not necessarily charging, "Hey, you don't have to pay the monthly fee." It's just, "Here's access to the tool." It's implied.
Yeah, so which is interesting and seems to just click as a good way to close our business. Yeah, so I'm not sure if it's something I could put up on a page where you could either pay me $50 a month or you just do anything with me within 30 days, and then you can just keep getting access to stuff. I don't know if that's basically the offer in one way or the other.
But yeah, I think it's... But that's something I noticed from today. So it's interesting to me. It's something I'm trying to leverage more, and yeah, other than that, I'm trying to get more calls on my calendar. I'm pretty light this week with the amount of calls,
so I'm hoping that's why I'm putting the effort really into this infographic so that I can drive traffic to both offers, which is to the MCP actually as a subscription, which isn't my main focus, but it does surprise me how many... People actually will cancel. There's been a number of people who've canceled,
but for every person who's canceled, there's another person who signs up. So I'm balanced in how I feel about it. I get the "Someone canceled it," and I get the "Someone signed up." I just end up feeling neutral about it, but then...
I noticed that the people who drop off are people who would engage with me a lot about it. They would talk with me a lot about it, and they would just cancel it surprisingly.
Then the people who stay on, I've never even met them. They're just mysterious, like someone I've never even recognized. I don't recognize the email or the name. It's just somebody who signed up and never reaches out.
There are a number of people like that, I think, who just like to buy things, basically. I've noticed that the boilerplate... There were people who would just buy the boilerplate and they would never reach out.
So that's why, maybe, just to wrap it up, the main thing is it's just good to me to have something just easy to buy because some people just like to buy.

**Ray | 05:44**
Yeah, I think that's a reasonable point. It's worth noting that the product prospects is not just a lead magnet for the next thing; it can be its own moneymaker, right? That's the whole idea behind the tripler theory. Super cool.
Okay, let me just squel check with the user. What is true today that was not true a week ago.

**Demitris | 06:06**
It's true that I'm investing more in study. Second week continuing, I'm learning more, but again, in the digital twins.

**Ray | 06:15**
So we just beg your pardon, your sound is not coming through that well. Are you using the right microphone? Maybe you turned off your camera in the process, which is fine, but I just.

**Demitris | 06:28**
Sorry, I see I'm using the right microphone. We use bone. Okay?

**Ray | 06:33**
I wasn't coming across very well. So, like, you're actually... Yeah, with these microphones, the pickup from the sound is proportional to the square of your distance from the microphone.

**Demitris | 06:48**
No.

**Ray | 06:48**
Now you sound much better, right? So anyway, I've got mine in an arm so I can lean back and do pretty much what you were doing, which is to be able to still talk like that. But I find that's necessary in order to get the good sound quality.
Anyway, I didn't mean to interrupt you. I apologize for that. Thank you for all of it, and you can continue.

**Demitris | 07:06**
Thanks for mentioning. So, it is the second week where I focus mostly on doing my studies. I focus in two basic domains. One is the professional one about digital twins. Yes, where I'm looking mostly for actual case studies. I can go and build my thoughts to get data from Kris Dou, a branding consultant, well-known for his opinions and business consulting, and create a case for him.
But today, while we started working on those data, I realized that maybe there is a tiny conflict in terms of privacy or the usage of his content, even if I don't use it for commercial reasons. I hesitated to do it upfront, but I kept the data to do it internally for me.
I had a conversation with my girlfriend, who is in the pharmacy business, and we found a real case study on retail where Digits have a feed. So tomorrow I'll start working on this case study and record myself to create my next video, which is about all of these handling for case studies. The other side for my studies is about how I can be consistent with the content, stuff like that, doing the homework, doing the right investigation and so on. Realized that I didn't use to do something I call homework, which is search into the platforms for what I'm doing. What other guys put on the platforms, how they put it, how many people they talk about it.
It's fantastic. The thing that there are many videos on YouTube talking about digital twins with engagement like 10 views, 20 views, many of them. And from big brands like IBM or other big great companies, they have just thousands of views, which is again, not the right balance for the brand equity, right?
So I realize that I see that. This is maybe a sign that I may have to go and look at other platforms for engagements. But social media will work in building the credibility we will see. I'm running this experiment for the end of the month.

**Ray | 09:49**
You make a good point in terms of the number of views. I suppose the other question is, what intent is sitting behind them? Because that's where I find it. YouTube really rewards more specific content for the things that you care about, right?
Otherwise, the very high view counts correlate with people who have subscribed, usually to a popular channel. Yeah, and they show up more in the browse, right? Hey, you just want to watch a video, press play. There are people who do that. I don't do that with YouTube, but there are a lot of people who do and like that can really drive up the view counts. All of which are by the way of saying, don't be fooled too much by very high view counts.
You know, some of my most probable videos have like hundreds on them after they've already done a lot for me in that period. And they didn't start with hundreds. They started with, like you say, double digits or single digits, but that's super cool, man.
Ellie, today is your hot seat. Can we check in, sort of catch up on the week? What's true today? That wasn't true a week ago. Then, how can we as a group be of service to help your next week go even better.

**Ellie Rofe | 10:54**
Sure, it has been a sort of busy week with God. I've really got all my thoughts together. More than this, I normally do before my heart sleeps, but for some reason, it's chaotic. So, I had a negative experience with a client that I have done work for free. This is probably something I'll bring to the group as a question, but that wasn't great, and I'll go into that a bit more.
I'm working on a workshop idea with someone, a woman who helps people with investor outreach, alignment, identifying your investors, building a list of investors you're going to target, and stuff.
So, VCs suggested a workshop, a joint workshop, and actually, it's shaping up to be really interesting. I'm really excited about that. That's going to happen at the beginning of December. So, I'm going to talk more about the strategic underpinnings of a pitch, the business strategy really, and making sure that people have that in place because that's the thing that defines the entire pitch. She's going to talk about the strategic approach to investor outreach.
So, that's one workshop. The next workshop, and then the final workshop, we will be helping people build a plan for raising in 2026, and we will push them into what Ray, hopefully, defined more as a Q&A forum rather than a community.
Because I wanted it to be temporary, I don't want to be locked into a community forever. So, if it's great, we can just say it's so good, we're leaving it open, but a temporary community, a couple of office hours in there. Ray has suggested this because it's fantastic for content, so it's an amazing marketing asset to come out of it as well.
She and I will do a joint offer off the back of the workshops. If people want to carry on working with us, they're welcome to work with us individually if one of us offers something that they don't need the other one for.
So, that's been really good, and it worked out some really nice ways of thinking about it. And I'm probably going to do my entire session via AI as I've done it within state change. I think what I might need to do is I don't want to give these prompts away because they're part of my report and analysis. I might just try and spin up a little tool that people can use live on the thing.
I'll see. I'll have a think about that. I'm not sure, but a way that I can just use the prompts without people actually being able to see them. Then so that's going really well, and it's really nice. We've had good discussions as well about the logistics and the underpinning legal or business agreement behind it to make sure that we're dotting all the i's and crossing the t's.
So that feels really good. I have a sales call tomorrow that I am trying not to be too excited about because this woman has been shopping around for someone for a couple of weeks, but she is doing some really cool stuff with materials.
AI-enabled e-textiles. So flexible electronics that can give robotics a very fine touch so that they can do fine tasks and things like that. It's really interesting. Her pitch deck now isn't very good. Her branding isn't very good, it doesn't show who she is, and she is incredible. She was like Forbes 30 Under 30.
So I'm very excited about that, but I'm just aware that it's not a dead set or anything. I have been reworking my website because I've worked out some better messaging, I think having worked with a couple of people, having spent more time on LinkedIn, I haven't touched it since I set it up in June or something, so it's time to have a look.
So I've been reworking that, and I really like that. I got seven pieces of content out having done nothing. I got seven pieces of content out from the Friday before last, the Saturday before last to last Friday, and off that I got two sales calls, an offer to speak, although that's still being defined. A place in Harley Street, and it's going really well.
I think one of the things I'm struggling with now is that I did that with the idea that I would just get up and start writing about stuff without thinking about it. Maybe it's actually as I speak, maybe it's just that I used to do morning pages beforehand as I talk about this.
But I had been wondering whether I just need to brainstorm some content pillars. So something where I just pick from a bucket each day about what I'm going to talk about because I felt like I just go, that again, if I'm...
But I'm trying to just my goal was not to have any pressure on it or any strategy or any thinking, literally just get posts out, and just build the muscle movement, really. Then after a while, look and see what's doing best out of all of it.
So I think that's it for the update. I think, yeah, that'll do.

**Ray | 16:33**
Cool. Then, let's turn it to the hot seat question. How can we be of greatest service to you.

**Ellie Rofe | 16:40**
There's two or three things, I guess. So this is just to give a brief rundown, I won't go into all of it because I think the thing that's most interesting is not the petty emotionality behind it, which is obviously there, but how you can take really interesting learnings from it.
So this is a company I have done. It was meant to be a three-week project as a favor to a member of their board to show what I could do. Because they've been struggling with raising, and it turns out the reason they've been struggling with raising is because they didn't have any underlying strategy. Now, working with them has helped me understand this, as has working with another early-stage company. It helped me really start refining the first stage of my process because I've put it into ten categories of business information or commercial strategy. They have to have it before the pitch deck can really... Or they have to at least know they don't have it before the pitch deck can be created.
I spent a few months working through that with them, and when I spent another month building the story in the pitch deck and trying to get information from them, doing insane amounts of research for them.
Because they hadn't done some of the foundational stuff, and this guy wasn't getting to it. I wanted to get this pitch deck done. I delivered it last Wednesday, and we were meant to be discussing it on a call, but he couldn't get me off the call fast enough. He was just like, "Just send me the slides. Just send me the slides."
I sent him the slides with a detail that I won't go into, but basically, I was trying to document that I had added quite a lot of information to this deck that wasn't there before. Key information and strategy to the business.
I didn't hear anything back from him at all. He's delivered that to the investor whom I spoke with last night, who said it was really great. I made it very clear because I think he got the impression I'd just done some design work for them. I made it very clear that I had worked with them for a number of months on their strategy, and I wouldn't be doing that again.
So, I guess one of the questions is: have I now done this work? Despite him saying that he was going to give me some money, which I think is completely off the table. Despite him praising my work to the investor, I haven't even received a thank you, and I would like a testimonial for all the work that we've done. Is it worth bothering? That's my question. Or do I just leave him?
Because I think he has... I think there's some ego going on here, and I think we've spent so long trying to address strategy things that he doesn't have an answer to. I think maybe he's not feeling a bit under the cosh, rained down upon, and is just avoiding it. Do I bother asking for a testimonial, or do I just get rid of any stress around it and just learn about it?
Then that's question one, question two in terms of research. I have been using a process where I use Clayd and put it on a research thing, and I try to very clearly define a research project and then take the information it spits out, print it out, read it, and then work out where there's potential issues with the research and then go and do my own manual research. I don't know if anyone here is doing research work at all or has any suggestions on how to do this better, but because I'm not a scientist, I'm not a specialist,
I will always have some sort of research to do, and I'm pretty good at getting up to speed quite fast, but if there's any tips and tricks, I had to do seven different research projects for this deck and then work through all the different papers.
To be honest, the biggest framework here is I think this is the final question. I think what I might need to do is just have the first stage of my process be we do an analysis, a messaging workshop, a strategic workshop, whatever.
I go through the ten areas of your strategy that we need to put in the deck, and at the end of that, you get a summary of those. Where there are problems that we need to address, I probably won't call problems, but something like it.
I think part of my work is heading off this need, but question two is, are there better ways for me to research? Question three is, does that seem like a good way in? Like that entry, it's not a complete entry level. That would be the self-assessment report.
But that entry level is a product where I just go by the end of this. We'll know what you need to do for your pitch deck and where we shore up, and then I can scope the next part of it. Does that seem reasonable? Are those three questions clear?

**Demitris | 22:03**
The last 111 clarification qu question for clarification. You're worried if the tool presentation is the as a product is the right approach.

**Ellie Rofe | 22:22**
So there's a self-service version of that tool where they just send their deck to me, and I send them a report back. That moment would just be free, but eventually, it will attract a cost.

**Ray | 22:29**
He.

**Ellie Rofe | 22:33**
It's just while I get enough decks in and refine the tool a bit. But the first stage of the work. So, I used to structure the pitch deck. I thought I could structure it based on having worked with maybe later-stage founders. I thought I could structure it as...
Maybe just having worked on a slightly less intense level with people, I thought I could structure it where week one was just a discovery. So, I understood everything about the business. Then week two was shaping that into a narrative.
And week three was putting that into a deck. What I've discovered is that week one might well be me understanding everything about the business. But then weeks two to twelve are like the founder having to go and work out from the CSO what...
You know what IP they have in their thing that they can patent or talking to the board about a change of direction. So, I want to have a sealed-off part of the thing where it's step one, we do this process. If you're ready to build your pitch deck right now, we build it.
If you're not, then you've got the roadmap to just shore up. It's like an investor readiness assessment. Really? I just don't know if that's a little bit defensive. When you're selling to people, you're like, "Hey, get your business marked, and then I'll tell you whether you're ready to raise or not."
It's like... For people who are like, "I've got six months of cash flow, I've got six months of runway, or the market's a me, something I need to raise now, or I've got an investor I need to talk to." It just seems like it might be a bit aggressive. I don't know.

**Ray | 24:30**
Okay, in what order do we like to tech at least in the order you give them. Or do you want to... As you think about it, do you think another one? You want to make sure it goes to the top of the heap.

**Ellie Rofe | 24:37**
Whatever sparks anyone's fancy. I think.

**Ray | 24:43**
All right, Demetrice, you can pick one.

**Demitris | 24:51**
Yeah, let's start from the order mentioned from Ali, regarding the guy who ghosted. We will not pay. I think. He will not come back except if he feels that he needs you. At the moment he gets the value, so you don't owe him anything, so he has no reason to come back.
I think the approach from Ray talked to me a few months ago that people pay us because they want to reengage with us. It's totally true. This is what I see. However, I see a very nice opportunity since this was a very long engagement. Instead of putting yourself in the thoughts of what you lost, let's get on what you won. You've had an incredible long time journey with a lot of findings in the domain findings for the collaboration engagements.
I think here is an incredible opportunity for making it content for sure. I see your content apply in two sides. The first is about the deck preparation for the pitch deck side, and the second is business strategy for investors because you talk to founders and you speak the founders' language.
So, both sides of the same journey, I think, will be incredible and very interesting. This is what I would do, definitely.

**Ellie Rofe | 26:40**
Great. Thank you.

**Ray | 26:44**
Robert, can we get your take on this testimonial question?

**Robert | 26:48**
For sure on a testimonial. I would say that, yeah. I mean, I think I would agree with Dimitrius that just the nature of people... Unless this is AI, that is to say, there are clients, there are great clients, and there are people out there who will even make it an easy relationship, and that they will be the ones who offer to you.
Okay. I want to give you a testimonial. I would like... Then there's... I think... But there are all kinds of different philosophies in life, and so this just might be a person who doesn't have that. We don't know. We don't know anything that's going on.
I mean, at least I don't know what's going on in this person's life or anything like that. I would just say that. Yeah, probably just if you withdraw your presence, that if he... If there's nothing else for you to gain from it, then if he needs you again, then that would be the best time to leverage any type of negotiating power you might have at that point.
Then, when it comes to asking for a testimonial, I think I would, in general, just want to ask a time when things are at a high point. I'm speaking from my own experience. I've never had a time when I asked for a testimonial and I felt like I wasn't going to get it, and then I actually got it. It never... Actually, I ended up being about it every time. I was like, "I don't think I'm going to get it. I never get it.
If it always seems like it's very initiated by the other side when it comes to those things.

**Ellie Rofe | 28:22**
Used to be the sort of thing he probably would trot out at this point. No, yeah.

**Robert | 28:26**
Yeah, and exactly. So I just go by that. That... What seems likely to me, but yeah, that is to say that I mean, he might need you again, and that that's not something that is... Only your business and everything, but I would just say that maybe that's not something that's that hard to imagine.
When that time comes, then you have something that you can do. Otherwise, I feel that it's more likely if you handle this again... Everybody has different approaches to this, but I think if you handle the more gracefully, you handle this part, which is just part of client coverage and everything that the more likely that they'll... That might come back around and make something out of the situation financially.

**Ellie Rofe | 29:34**
Okay, nice, that helps.

**Ray | 29:37**
9, if I might just sort of throw in the investor is the one who you did impress, right?

**Ellie Rofe | 29:39**
Thank you, guys.
Yes.

**Ray | 29:49**
So, I think they point you one way. They're more likely to be... If not the source for a testimonial, then the source for referrals, like who in here was happy, right?
Then the question was, "How can you better monitor happiness?

**Ellie Rofe | 30:08**
Yeah.

**Ray | 30:09**
But think that's basically right. I mean, no need to... But by the way, I would still send a... It was a pleasure to do business with you note, right? That way, when they look at what was the last correspondence I had with them, it's you being 100% gracious.
I think that... That's how you smooth the path to being able to deal with every DT. Yeah, right.

**Ellie Rofe | 30:33**
Yeah, okay, yes, I think it is purely a values thing that's driving it up in me now, and it's not strategically smart to even bother
with anything else. It's just me going, "How bloody rude!" [Laughter] So I just need to get over that. Just carry on.

**Ray | 30:56**
So the American South is the more genteel part of that society, and it has just wonderful euphemisms. These are people who are unfailingly polite, and they're even...
So, when they are just nipping you right in the stomach, it does show the path. Instead of saying "F word U", they say "Bless your heart". [Laughter] All this by way of saying that I get what you're saying in terms of how you're feeling about it, but graciousness doesn't need to go with forgiveness necessarily, right?

**Ellie Rofe | 31:39**
No, yeah, I have warring angels and devils in me.

**Ray | 31:40**
It's just good manners.

**Ellie Rofe | 31:46**
I have, you know, very British middle class, let's kill people with kindness and euphemisms. And then I have, like, the slightly more Cockney Essex. Let's have a rumble.
And so [Laughter] more e myistic one. [Laughter] Yeah, absolutely.

**Ray | 32:04**
Okay? Does that give you enough to work on your first issue?

**Ellie Rofe | 32:07**
It's really helpful. Thank you.

**Ray | 32:09**
Okay, then, research and the idea of the external review product, Robert. Who would you like to take first?

**Robert | 32:22**
I would, let's say research. I mean, I think, sorry, could, if you don't mind. Ali do you mind? Just like. To just reencapsulate it in. In like ohi time you need.

**Ellie Rofe | 32:40**
Might might just be a curiosity that isn't really applicable, so I totally understand, but for this, for example, I needed to research. Let's take one example, the HAP VAT market. So, hospital-acquired pneumonia and ventilator-acquired pneumonia.
You need to do research into the size of that market, the geographies involved, the incumbents, that is a relatively simple research project. Some are more complex, like licensing deals or reimbursement rates for a diagnostic in oncology or whatever.
So, there are these slightly arcane questions that, without access to amazing industry-level tools, which I just won't have and normally very expensive to have if I wanted all of them. It's just whether there are any suggestions that might speed up the workflow or ways in which you research.
But I do totally understand if this is just like... This is just not something that comes across people's desks normally. It's like having to research arcane facts about some industry.

**Robert | 33:57**
Well, I think it is an interesting question. I think that in general, are we talking about stuff that's peer-reviewed research that's going to be in some type of internal database where it's not necessarily even publicly available, like a library type of access because it has to be available somewhere. I'm presuming...
Right. Online journals or something like that.

**Ellie Rofe | 34:20**
Yes. So, some of it is peer-reviewed stuff. There will be, for example, when you're looking at the current drugs that are used in hospital-acquired pneumonia, for example, some of that will be peer-reviewed studies on the effectiveness of drugs or the emergence of antibiotic resistance through certain target pathways.
So, we try to drug this pathway, and that's gradually, the antibiotics are gradually developing resistance to it. There's that side of it, and there's just the commercial side of it, which is the numbers. How big is the market? How many billions are spent each year worldwide, and what's the split across the globe?
But the seven major markets in farmers. So there's multiple layers to it really, who are the incumbents, who's coming through that kind of thing.

**Robert | 35:19**
And so just to ask, like where is that information available from the.

**Ellie Rofe | 35:26**
This is the question.

**Robert | 35:27**
Okay, well.

**Ellie Rofe | 35:28**
Like, of it is in-house, some of it is industry news articles, some of it is you get certain levels and certain amounts of research from research organizations, consultancies, that kind of thing. Who published stuff? Some of it is just interpretation.
I mean, I think sometimes the answer is that it's the companies that should be doing this or should be paying an expert to model these things out, but it was just... Yeah, it's a good question, it's all over the place.

**Robert | 36:02**
I general, if it's all over the place, I would probably say that the first thing I would turn to would be something along the lines of Perplexity. Especially since they have been in the news lately for overstepping boundaries, which is then probably you're going to get some stuff that you want out of the tool, right?
Being a user of the tool. Yeah, it's a yes, go overstep. So I think that would be a good step forward. I would probably, if it's very broad and very huge, and it's probably a good use case for AI to throw the kitchen sink at it, just to everything just... I would launch multiple subagents to just do an inhuman amount of research with just Perplexity and then just keep throwing stuff out until maybe it burrows into some corner that I think, from the sound of it,
this might just benefit from that. To just have a library for what is good in this case to just go out there and find a bunch of stuff. Use MCP tool perplexity. MCP would probably get you there.

**Ellie Rofe | 37:21**
Fabulous, yeah, I don't know why I hadn't tried it. Perplexity again, I haven't tried it for months, actually. Yeah.

**Robert | 37:31**
I was trying to look actually for wedding venues not too long ago, and then I was just behind on that, and I just said, "I'm just going to use perplexity, and it just goes and finds them, it finds everything."
So, yeah.

**Ellie Rofe | 37:46**
Okay, I'll have a look. Thank you.

**Ray | 37:49**
Here, are you interested in bringing in this conversation?

**Demitris | 37:53**
Yeah. Ali. For the things you want to start the research and find your own results. Who is this professional who, if he sees a report from this research, he will not go to bed at night without reading it?

**Ellie Rofe | 38:21**
Is in the stuff that I'm finding.

**Demitris | 38:25**
Yes. A report from this staff.

**Ellie Rofe | 38:33**
So, it slightly depends on which angle. So, for an understanding of current medicines in use authorized or approved, you would be looking at potentially clinicians, although most of them would probably understand by now. Clinicians, other researchers, microbiologists, et cetera. For the commercial side of things, you're probably looking at consultants.
Maybe equity analysts. Although, not all of the companies involved will necessarily be public. Although I guess by the time they get to approval, most of them are analysts, maybe.

**Robert | 39:29**
So? Uhmm.

**Demitris | 39:32**
And which are the sources they trust the most?

**Ellie Rofe | 39:37**
That's a very good question. So, the doctors don't tend to read a thousand journal papers. Some of them will keep in touch with it, but a lot of them just get... I think they just get conferences and in continuing professional education type things. It depends how specialist they are. Obviously, an oncologist will be at the forefront and will be looking at the papers and getting all the research and going to all the things a GP not so much so that would vary.
Then the commercial side of it, equity analysts are generally talking to the people involved. So they tend to have inroads into all these companies. They're doing direct analysis. They will look at all sorts of research tools that I guess they would have access to in house. A lot of them, there's obviously there are the journalistic things like biotech. BioTech, EU or fierce pharma and biotech.
But yeah, there's lots of different places. I think it's scattered because I'm not just going, I just need to do a bit of scientific research.

**Demitris | 41:07**
Yeah.

**Ellie Rofe | 41:13**
It's lots of commercial research. And some of the commercial research is kind of it's more inferential than it is specific.
So, yeah.

**Demitris | 41:28**
The reason I'm asking that is that at least for the medical domain, there are some organizations and institutes in Europe. Like the European Medicines Organization, general. Yeah. They bring a big database for the findings of the researches, which is the more clinical side of you in terms of the commercial side. Sometimes there are references or we can see the updates on every drug because they have a full folder for every drug in the market. How it goes.
There are tons of drugs every year that are in the market for ten years or 20 years, and they have new findings, so they go back and cancel them.

**Ellie Rofe | 42:18**
Yeah.

**Demitris | 42:24**
So I'm thinking that I would use AI again to do the job and focus on these kinds of resources.
I think a conversation with a clinical expert or clinical guy would bring you specific resources maybe to look at very specifically, maybe. And you know, people who work in medical companies, drug manufacturers and so on.
I think you can find them on LinkedIn. Just to bring them this question, [Laughter].

**Ellie Rofe | 43:13**
Yes. Sorry, I've just had a hungry cat get in the way. Yes, and I think that, I'm just going to get all over the place all the way. Come on. I think that is. I think that's a really interesting one.
Maybe I need to think about that if there are... If I'm working with other industries, then think about the analogs in those other industries of what are the central organizations? Where can I find people I could just talk to? Rather than the thing because that's what would be an interesting way to do it.
If I can find people to talk to fast enough. Definitely, conversations are always good, aren't they? Actually, making connections.

**Robert | 44:01**
Yeah, I would just add that, like you mentioned before, that you were posting and you generated conversations and you generated things.

**Ellie Rofe | 44:02**
Yes. Okay, cool.
No.

**Robert | 44:15**
So I would just say keep doing more of what's working right because you're doing something that generated something. I'm presuming that was more of that... That would be good than then sometimes you might just have an answer right there, like to just maybe do more of that thing.

**Ellie Rofe | 44:34**
Yes. Okay.

**Ray | 44:37**
You a lot of wisdom in that, Robert. I was thinking about that when Ellie was talking about her weekend review, right? You're talking about the writing efforts and the idea.
By the way, do morning pages and then go into writing a post. It worked for me exceedingly well. It really gets ramped up because often what's happening is I'm using the morning pages for work on workshop the idea.
Then by the time I come out with, "Okay, now I've got some momentum here," then maybe I'm even rewriting some of the ideas I had as I get into the post, right? And that's making it even lower friction.
But with that in mind, the other technique I found for getting a lot of ideas is to take everything you've written for the past six months and pour it into a document.
It is amazing what you find out. I actually said stuff like that. "Hey, that was a good turn of phrase." "That was a good idea." Now you find all this stuff that's here or there and yon in your writing. We have the additional tool, of course, being able to put it through AI to say, "Hey, what's the consistent theme wise in there that you can use to suss out ideas."
But the reason I bring all that up is to buttress Robert's comment and maybe give you a tool that might be more useful, which is to go back and ask what research you've been doing, what questions you've been asking, and what has been producing well for you, right? Human reinforcement learning.
Because that's an asset, right? Your techniques to be able to get up to speed on hard topics. You could never understand the stuff that we're talking about, but you can get up to speed in a pretty impressive way. Where you will be, if they just want to nitpick you, they'll nitpick you, right?
But in terms of someone who's not from the field, you being one of the more intelligent people they've ever talked to is going to be... I bet that's just a question of research skill, right? Then being able to apply that knowledge by being quick on your feet. You're certainly the latter, and I've seen you do wonderful research. I'm expecting that both those things would work really well for you. You've been doing it in pharma, but I bet you could probably play just about anywhere.
Then that would be immediately differentiating because, "Hey, you work with hard tech, you don't do this with SaaS, right?" You're not coming in and being part of that same grind set, BSing, whatever you are. We work with these hard technologies.
Then that separates you from the path.

**Ellie Rofe | 47:14**
Yeah.

**Ray | 47:16**
And you might consider using tools that give you better control over that kind of history and technique. I mean, Notebook with LM is wonderful stuff. Probably the best thing on the Google side. If you haven't used it before, it's really impressive.
There's deep research, although deep research is, frankly, not nearly as used by the perplexity and Google and chat GPT as it used to be because I think, partially, because you can get a lot, eighty-twenty, relatively quickly.
So then what's your insight about that? Then that becomes part of your toolbox that you know how to get up to speed on the stuff very quickly. The other thing I've thrown in is you were talking about the commercial side of it, and I think that's a worthy thing because you're talking generally to people who are scientists, right?
So your value-add in your research is what you're talking about in the question three about the external research. I don't know whether that comes together as being a fixed product for some of the incomplete value proposition reasons you described. I'm not sure what I do with that when it's done, how does it make the money right?

**Ellie Rofe | 48:29**
Yeah.

**Ray | 48:29**
But it is, I think, an asset that you have. An asset isn't the same thing as a product, right? It's an asset that you have that puts a multiplier on the value you're able to provide, and it's an asset that you can be talking about in terms of your own value proposition. A
proper proposition here that you know you have an approach to being able to do the research to get up to speed quickly. But more importantly, you're not trying to research so you can become another scientist in their life.
They're stable, right? You're researching so you can understand the commercial aspects to connect it to the market because that's part of it that they haven't done.

**Ellie Rofe | 48:57**
Yeah. Yes. Yeah.

**Ray | 49:01**
And the part where you're bridging between your VCs, your team, your product, and your market, right? You can talk about your product till the cows come home, right?
That's the scientific part of it. But how's it? Hush. The market. That's what you're bringing to the table. They're thinking, "Well, nobody could possibly understand what we're doing, and therefore, there's no market."
So why do we ever have this conversation? That bridge is exactly what separates things that get funded from things that don't.

**Ellie Rofe | 49:31**
Yeah.

**Ray | 49:32**
And the external aspect to your research and therefore to your insight and that which then, of course, is driving the material that you create or that you help them create.
Anyway, I look at that. I guess I'm kicking off door number three here. And think that the external research project isn't so much a separate offer. It's a unique mechanism, right? To use a marketing term that you're bringing to bear in order to meet the market promise.
Because it is, you know, it's one of the tools you use, right? In order to get them from, you know, nerds with a good idea or good idea, good technology, good patents, real assets. And turn that in. And turn that into a.
You know, the bones of a marketable business for which they can then sell stock.

**Ellie Rofe | 50:35**
Yes.
So the sorry, what were you gonna say?

**Ray | 50:44**
Anyway. Not at all? Please?

**Ellie Rofe | 50:49**
Well, I was gonna say the so the first that sort of first filter project wasn't. I mean, it's partly about research, but it's partly about preventing me being in a situation where I have to do that much research because a founder hasn't. Or at least if I'm going to have to do that much research.
It's priced in through a scoping project. But it is almost that actually, maybe that is an opportunity to show them. In that first week, I do an intake, you know, discovery, whatever messaging works or whatever you want to call it. I look through those different areas. I go back to them at the end of the week, having done some research like this, having filled in some of the blanks they haven't so far and got myself up to speed very quickly on their industry, their, you know, their tag, et cetera, and then say, right, these are the bits that I've. These are the blanks I've filled in with this research so I can demonstrate that I've done that. This is what we'd need to do to get everything up to speed by the time we're turning this into a narrative. A you series of persuasive arguments, et cetera.
And so this is the scope for the next stage. So it's showing willing rather than just going. Computer says no, you have none of this in place, go away. It's like saying, yeah, okay, I can bring some value right up front here.
And then. And then it's contextualized for the rest of it as well.

**Ray | 52:34**
This smells to me more like the thing you do to prove your value. The thing that make it short and sharp, right? Doesn't the, you know, your front loading a valuable, you know, set of insight? They're feeling smarter. They're feeling better about this. I'm not sure that I buy that as his own thing, right? I do think it's a you do that, you bring that to them and then you say, okay, now it's MBG you know, go no go time, right?
If you're if this all sucks army now.

**Ellie Rofe | 53:09**
So the free product is a week of work for them, right?

**Ray | 53:13**
I don't think it's free. That's what I was saying. I don't think it works as a free product because it's too much of a commitment on your part, right?

**Ellie Rofe | 53:19**
No. Yeah, this was.

**Ray | 53:24**
And all.

**Ellie Rofe | 53:25**
Yeah.

**Ray | 53:27**
Yeah, and then too much equipment on theirs. What I was imagining...
So, the what I'm thinking of is that this is just because it's more like being able to structure the engagement, right?

**Ellie Rofe | 53:37**
Yes, that's what I was thinking. So, I would have an experience every.

**Ray | 53:40**
That. the what I do in the first week is a super deep dive, research.
We have these two meetings where I'm probably asking you a couple of clarifying questions, but getting really... Climbing up this particular ladder here where my focus is on the way it meets the market, right? You've got technology. I'm building up on the frontier of that technology and then the way the technology is touching the market.
Then that way we were bringing complementary sets of knowledge to the phase that comes after that.

**Ellie Rofe | 54:16**
Yes.

**Ray | 54:16**
Because you do that relatively quickly and because you can be giving them things they don't know.
It's a way to be pressing them quickly in the conversation, as opposed to... All right, well, I guess I've got my marching orders. I'm going to go produce a next round of presentation, and I'll see you in a couple of weeks. This is a way.

**Ellie Rofe | 54:32**
Yeah, I think.

**Ray | 54:33**
Way to turn the wheel faster, to build more trust faster.
It's a way you can say, "I have a process. My process. Week one looks like this.
At the end of week one, we have a check-in. If at the end of that week one you're saying, "This is you know that you don't feel like I can understand your domain and this isn't working, you can tear up the bill and we won't meet again.

**Ellie Rofe | 54:57**
Okay.

**Ray | 54:58**
That's what I was saying. M BG thing as opposed to being a, you know, part of the.

**Ellie Rofe | 55:00**
Yeah.

**Ray | 55:03**
And to the extent you're describing it to have bones on the structure, right? Rather than having a separate offer they could buy without doing more because it doesn't really make sense by itself.

**Ellie Rofe | 55:18**
No, but my point is less that I'm singing like I'm auditioning at that point. My point is almost that I'm auditioning them because I am confident that I can get up to speed and add value. What I'm less confident in is that they have thought enough about their strategy that we don't suddenly then need a two-month break while they go and rework stuff or we have to check in like it.

**Ray | 55:32**
2.

**Ellie Rofe | 55:44**
I don't know how that's the problem with it. I don't know how to frame it where I can...
It's a discovery phase. It's the scope. I have to scope. Because what I'm finding is the amount of work people need is so radically different depending on where they are.

**Ray | 56:01**
Yes.

**Ellie Rofe | 56:03**
And this is my way of assessing where they are, giving them some value, showing them the strategy that I can see
so far. But it's how to frame it so that it doesn't sound like I'm just like, "I'll test you", or that I'm going to be tested, and then I'm just not going to charge for it. Like it? It's a mutual thing.
I think, but I'm not sure.

**Ray | 56:27**
That's a good point. I think part of what makes it very challenging is you're doing that first part, and there's what you learn about their actual status of understanding in the market, which will tell you how much more work there is to do.
Can I just ask, have you recently run into a founder who's hiring someone of your line who has a good strategy? Isn't the answer always their best cases.

**Ellie Rofe | 56:57**
So I've worked with some founders who have incredible strategy, and they just don't know how to talk about it, or they don't, or some of the best ones are just like, "I shouldn't be doing this. This is an expert's job."
I have a business to run. So, there are founders who do know it and who do care, but they're just generally a bit further along in a Series B or crossover or something. But some early founders are more up on it.
But I think it's Series A maybe seed, but yes, a lot of them are. I think a lot of them, even if they know what they're meant to be doing, are avoiding answering certain difficult questions.
That becomes more of a coaching process. So, as much as anything, I guess it's almost like me checking how grounded in reality the founder is so that I then know how much work I'm going to have to do versus it's a difference between... I'm marshaling.
Sorry. I realized we're going over. It's a difference between me saying I'm marshaling your thoughts into a narrative or I am actually filling in all the big gaps in your thoughts through coaching and research and strategizing.
That's the difference in the projects. I would say.

**Ray | 58:13**
Got it. Okay, we are going a little bit over, so I'm going to ask Robert and Beatrice for six seconds each on this topic, and then I'm going to be... I'll certainly be college cheating on it after our meeting, too.
If I come up with ideas before Friday, I'll say something.

**Ellie Rofe | 58:31**
Fabulous. Thank you.

**Ray | 58:34**
Robert, can we start with you, sir? Then we'll go to you, Demetrice.

**Robert | 58:37**
Sure, I would say that. I just can't imagine why you can't charge for... I mean, yes, I agree. It is a pain. All that stuff in the sense of the things that you're describing about how you have to get up to speed and all those things just seem like more reasons why you have to charge for it.
I think it turns the tables a little bit in the sense that that's the only thing that will really make them take it seriously. I think the money plays a part in that.
It's doing them a favor, too, because it causes them to take it more seriously. My quick thoughts on that are that the best opportunity to charge... Again, this can really depend, I suppose, on how a person develops their practice.
More likely, it would be at the beginning when there are so many questions on the table, and that's when you have the leverage to... They really want something and they need something to happen, and nothing's happened yet.
For good reason, because you're... That's when a lot of the work will happen at the very beginning. So yeah, I would just say that there's something that could really work to your advantage by maybe just reframing how you look at the value that you're really providing there in the beginning and what it...
I think somebody would have... I don't think we have to negotiate against ourselves. Right, like it? I can't. I don't think we would expect anybody to give us that for free, right? If you were ever in a situation where you were looking for someone to provide a service for you, you would, I think, be looking to compensate that. You would expect that person to hand you an invoice for it.
I think it works the other way around. So, yeah.

**Ellie Rofe | 01:00:46**
Yes. Absolutely. Thank you.

**Demitris | 01:00:52**
Do we just... I agree totally. Robert, I see. Basically, I know that from my experience too, that the longer the time to complete the engagement is, the worse the quality is for both sides. So, I would think about how this lifetime can be minimized so that they can take upfront some core piece of value.
Upfront means very close to the day of payment, and of course, it has to be paid and has to be expensive. If it is a very low price, nobody values that price. It's like $60 a month and so on.

**Ellie Rofe | 01:01:37**
Y.

**Demitris | 01:01:42**
These are good enough for repeating payments for services we know we pay and we're going to use it for X amount of time.
But this kind of service has a deadline, right? You get what you're looking for and then it's over. So, it has to be paid upfront in a huge amount, maybe four digits.

**Ellie Rofe | 01:02:07**
Yeah. Absolutely. Yeah.

**Demitris | 01:02:11**
Yeah, don't be afraid of doing that. Do your research in this domain like you're doing very well. Research for other cases, find the right process, and minimize the times.
That's all for me. I would test. I would test it for at least three 90 days, and if it doesn't work perfectly, just change the workflow and continue on that.

**Ellie Rofe | 01:02:37**
Okay, I.

**Demitris | 01:02:39**
The workflow change is not the service.

**Ellie Rofe | 01:02:43**
Okay, fab this.

**Ray | 01:02:47**
Right?

**Ellie Rofe | 01:02:47**
Thank you for that.

**Ray | 01:02:47**
We certainly covered a lot in the course of the AR. Thank you for bringing those. We'll all be talking at the end of the week. We'll do this again a week from today, and Demetrice, it will be you on the seat, right.

**Demitris | 01:02:59**
Good for.

**Ray | 01:03:00**
Take care once, guys.

**Demitris | 01:03:01**
Have a nice day.

