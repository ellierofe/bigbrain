# State Change Mastermind - Jan, 20

# Transcript
**Demitris | 00:01**
It was a few hours ago what?

**Ellie Rofe | 00:01**
It was f.

**Ray | 00:05**
Yes, it was a few hours ago.

**Demitris | 00:07**
Yeah, I'm sorry.

**Ray | 00:10**
Yes, yeah.

**Demitris | 00:12**
It worked. I think it worked very normally. After fifteen minutes, it started working, it was great. Now I'm running my tests so I can start my campaign tomorrow, and I can be prepared for the office hours I'm going to run on the upcoming Friday.

**Ray | 00:35**
Super. Yeah, the and please do post out the fact that you're doing, you know, office hours up on date change as well.

**Demitris | 00:43**
Let's do it right after the session. That's good.

**Ray | 00:47**
All right, well.

**Robert | 00:50**
The can' hear anything.

**Ray | 00:52**
Can you not hear me at all, Robert? Do you hear my coming through okay for you? We seem to have a conversation a second ago. Okay? Yeah, can you hear Mer?

**Ellie Rofe | 01:02**
Yes, I can indeed.

**Ray | 01:11**
Just can't... I can't hear me.

**Robert | 01:13**
I can hear you now.

**Ray | 01:14**
Okay, there we go. All right, so...

**Robert | 01:18**
Last, by the way, I was going to say it's literally has my computer hostage.

**Ray | 01:26**
Yeah, do that. Okay, cool. Well, let's go around the horn here. What is it that was true today that was not true a week ago? Do we just quickly start with you, sir?

**Demitris | 01:38**
Yeah, for sure. The first thing is that I'm almost done launching the app. The thing I... Everyone's brain in these conversations for the past month, it's up and running. I'm finding right now a couple of bugs and I'm correcting them. It works very nice. I had, based on what we talked last week, guys, I figured out how to manage the channels of communication. I realized that LinkedIn and YouTube are not enough. They are for credibility, but they are not for getting in touch with people.
So I decided to get into Reit Conversations, which is quite... It's more interactive and more immediate. But it's a little bit painful for me because it cannot be automated. I have to be... I have to push my brain right there and read what the other guy says, what his pain is, and engage with them.
So it's a somewhat discouraging thing, which means that I just transfer the task during the day, [Laughter] but I have to do it and I really like it. I'm running a new event the upcoming Friday where we're going to talk about Noah's graphs and the query. How we can get in the query and if it to complete the bags I have in the app. I'm planning to run a campaign to attract more people.
Based on this campaign, what I'm going to do is I'm going to invite five people. Maximum five people. The target is to have them converted till the next week so we can have five successful engagements. Most probably, I'm going to do it for free for them, for those people.
That's the open call so I can have those case studies, you know, for content stories to share and so on. That's the goal, that's why I'm doing... I'm giving a deadline until the next week.

**Ray | 04:08**
Okay, cool. Yeah, a thing that occurred to me is the, you know, one of the reasons why, you know, you might be finding red to more successful in connection is that it's all about human to human, which is part of the reason why it doesn't lend itself to automation.
Yeah, I think it's sort of a, you know. Yeah, the consequence of it. Robert, can we check in with you, sir? Was true today, it was not true. We could go for you.

**Robert | 04:36**
Sure, I have a haircut. That's true. Those are true last week, it's true today. And, overall, I spoke with Perksh within last week, which we talked about. Last week was actually a very positive conversation. I pretty much I took everything that you all told me and just went into the conversation, and it was very positive. I just. I actually think that. It just puts you back into it. To just being focused on trying to gather my energy to push back into the market once again with something that is what generates those conversations in the first place.
So my focus really isn't even on the energy, even on that conversation itself, because to be honest, I don't think it'll lead to likely will not lead to anything. Might lead to like a few short term opportunities, but I don't think that that's like my end goal is not to they go. I finally I reached this island, and I'm gonna and this is and like now Zen is gonna do anything for me.
It's like that's not the way life works. I don't usually, so anyways, I think it just puts me back in like that spot of searching for aarching. But. But at the same time, like, taking action on how I could just be generating those actions. Taking action on generating on being able to generate those actions which generates the results.
Like trying to engineer my life into a series of, you know, to reduce the friction in you know, in outputting those things and taking my part, which is like the ideas and all those things and doing my part and so that's what I've been doing since yesterday. I built like a kind of like a cockpit for my life, pretty much.
And like it's, you know, and that's just a hard thing to do. It's very you have to research within your soul to make something like that. So, yeah, there's a whole bunch of stuff, but I'm trying... So that's what I'm doing at the moment. All of it is in pursuit of really ultimately trying to market more, sell more, and build systems that ultimately affect not just me but the people in my orbit as well.

**Ray | 07:26**
Okay, cool. And, Nelly, I might ask, like, where has last week, gotten you? And we, of course, did our little, you know, main checking thing. I got to sort of see some of the cool things that you've been doing here.
But you know, really the floor scores. You know what? What? What takes you today? And how can we help get you to tomorrow.

**Robert | 07:49**
To next week?

**Ellie Rofe | 07:51**
Well, it's... I feel like lots of paths that have been all over the place are starting to coalesce a bit more clearly in my brain, which is good. It doesn't mean there's any less work to do, but it does mean that the work is going in a clearer direction and bringing together things that otherwise have my attention split and make me feel a bit chaotic at times.
So I've... Ray and I have talked a little bit about it before, but the idea of... Especially hard tech venture capital and startups living in this overlap of money obviously not just VC, not just the capital that they raise, but the wider markets and macroeconomics and stuff that's happening. What happens when interest rates start going up?
Software investment isn't as attractive, investment is hard to come by, etc. Power as in policy and regulation and things like that on a governmental level, but then geopolitical stuff like what's happening with us and China, etc.
Europe going, "We might need to wake up and all this kind of thing." Then obviously knowledge being the key part of it, how innovation pushes forward, how it solves problems for some of the governments and the money, how it needs to give something back to them.
But they can provide the knowledge of the way to expand. I've explained that really badly, but I was talking with Ray on Friday about how I would like to... There's AI... I don't know if anyone knows. There's a guy called Michael Simmons who used to talk an awful lot about mental models, which was really interesting stuff.
He has this concept of a winner takes all, which isn't a bad mental model for the modern attention era, which is you have to try and create an impact to make an impact. There's a really long tail of people who are not really getting any attention whatsoever. I don't think it's directly applicable to consulting as much as it is being a content creator.
One of the ideas he has is a blockbuster article once a month or so. It's really deeply researched. That really has a unique hook and an angle on it that other people aren't talking about. So I was talking to Ray about how I'd like to do that.
Ray came up with the brilliant idea of how my research for that shouldn't just be on a computer, it should be talking to people. Talking to those people should be done on camera.
So interviews, and that's really struck me as a really great way to try and connect with people. I've been brainstorming who in my network would be useful. So that's one of my questions in a moment is interviews.
Then the other thing I've done is I've been trying to work out how to build content faster, but still make it high quality. So I realized I needed to do it in stages, really, and I created... I'm still going to refine them as I go on, but I've created some template holding content pillars.
So the topics or the angles I'm going to take on pitch raising, fundraising for hard tech, and then brainstorming loads of ideas within those things, which actually I just haven't done for ages. And I used to be a writer, and I used to create
and... Actually, it's so lovely just to play with ideas rather than just sit in front of a blank thing going, "I've just got to write something linked in now, and I want to go and curl up in a ball and cry because it's so mind-numbing at times."
So that's really been nice. Then doing a vomit draft, which I love. It's what we used to call it in screenwriting, where you literally just vomit everything onto a page and no slowing down a bit like morning pages, and then coming back to things afterwards to refine and then working out what the graphics and stuff are going to be.
So that's been really nice. Then the other side of things is I've worked out finely of all these ideas I was doing. I've built the pitch deck assessment tool with Ray's help yesterday. Forced it over the line.
So I'm just starting to market that now and see what attention I can get for it. I'm just going to have to be a bit experimental and play around with it, but hopefully, I can get some eyeballs on it and get some people testing it and trying it out and start using that as a lead magnet.
So it's like a... It just tells founders what their pitch deck is actually saying because most of them don't know, and then they get loads of advice on the narrative and the design and the story. But this is like what investment case you're putting to investors where these twelve strategic categories, which are strong, which are weak, which don't even exist in the deck, should they, shouldn't they?
These are the questions or concerns. It's likely to spark investors as it stands now. So I just thought, I'll try and make it do a very simple job, which is just to reflect back at people what they're saying, rather than especially because AI now does an awful lot of reading like first passes.
So my thinking here is someone reading a pitch deck, a human reading a pitch deck might get carried away by the story, might get quite inspired by something, might particularly have a founder. They know them. Or they've met them. Or they might... Like a particular industry vertical or whatever, and they might overlook stuff.
But an AI is an unemotional thing, however much it pretends to be emotional. So it might give a pass. It might hallucinate, it might do all sorts of things, but you have to have it quite robust and quite unimpeachable to make sure that the AI doesn't suddenly go, "This is rubbish because things are implicit rather than explicit," etc.
So that's been really interesting, and I'm pleased it's out there. I like it's pushing me to do a general expansion of what I'm marketing without me doing what I used to do, which is like I must plan a 17-page website and then spend three months not doing it.
So it's really nice. Then the... I think my question is obviously, I'm going to be doing interviews. I have done some onstage interviews because I used to run the film festival. I've never done really video interviews.
I guess the first question would be what characteristics you prefer in an interviewer you think make a good interviewer? What sort of characteristics, techniques, and approach make a good interviewer?
If you were preparing to start doing interviews, what would you be doing? Whether that's on the research side, whether that's on tech and prep and setup like that, what would you be doing?

**Ray | 15:38**
Okay, well, let's open up. Demetris, both you and Robert have been doing pretty successful. You know, meetups that turned to podcast that are, you know, that largely about you interviewing or helping people. Could we, what you know, if you were starting from where Elli is today, what would you wish you had done that you perhaps didn't begin with?

**Demitris | 16:08**
Can I start? And Robert, but by the way you were muted.

**Robert | 16:15**
I know, I was just... I saw you take a breath, and I was like, "I heard your breath."

**Demitris | 16:24**
So the main question is, how should Ellie be prepared for those interviews in order to achieve to become a great interviewer?
From my point of view and just bringing my experience from podcasts. I really like listening to podcasts. I listen to them a lot. Well, I listen to most of them from Roy Sutherland and Krisp, and just a few of them, and not too many different people I like. I can compare the different interviewers to the same person, right?
I can see from Krisp when Krisp is an interviewer to another guy, so I think what makes the final output great is that the interviewer achieves to inspire the guests, inspires him to start speaking about the topic he wants to speak. When the guest starts speaking fluently and fast,
it's the sign that he enjoys it, that he realized that he's on the subject he follows, that he enjoys it now. It's about the personality. If you take, for example, Roy Sutherland, you can ask him, "What's your name?"
He can stop talking after an hour, right? So he's not a good example. Bringing examples from Krisp, though, I realized that what he's doing is that he's doing follow-up questions. He has just a couple of questions to bring into the conversation.
He doesn't care if he doesn't bring everyone. Every one of those questions, he just says, "Okay, I want to know from you one, two, three things."

**Ray | 18:39**
Things.

**Demitris | 18:40**
All right? Get started talking, and you talk. He doesn't hesitate to interrupt the guest, saying, "Hey, I didn't get that. Could you elaborate more? Could you give us an example?" Which makes it better for us to understand what the point of the guest is and makes the final output more specific and viable.
So insightful. So answering the question. I would say just do some preparation about the questions, but not about how to mention the question. What is the outlook you want to achieve? Engage into the conversation so we can bring the follow-up questions like, "Hey, why are you saying that? Where do you think this works?"
I know this example too. What would you say? These kinds of things I think improve engagement. My favorite podcast is a Greek one. There are two incredible guys from a tech company. They started the podcast talking about anything else except tech.
Yeah, two friends opening their camera and just talking about... They don't talk about politics, definitely this is red-flagged, but they're talking about their domain and how things are changing. They talk a lot about marketing, about management situations. They may get into a conversation about their point of view about the fight between AI companies. OpenAI did this. Anthropic came back with this and why we think it's going to happen and so on. Sometimes they're getting so technical.
But at the end, what we see is that we see two good people, two good friends talking to each other about the subject like they're talking, they're enjoying their coffee, and so enjoyable, so fluent, so...
So nice to be listened to.

**Ellie Rofe | 20:57**
Okay, yeah, absolutely.

**Demitris | 20:58**
I don't know.

**Ray | 20:59**
I helped.

**Ellie Rofe | 21:03**
I think what I'm understanding is that it's more about showing an interest and asking follow-up questions to make sure you actually get something useful out of people rather than just letting them say something and then just moving on to another question completely and trying to make it feel more... Not intimate necessarily, but more relaxed and vibrant rather than all stuffy and stuff.

**Demitris | 21:37**
Yeah, you know what? If you just bring questions, it's going to be like an interviewer at BBC. They just throw the question and they wait for you to make a mistake.

**Ellie Rofe | 21:46**
H.

**Demitris | 21:53**
They... This is how they work, these kinds of interviews.
But you are not there for that. You are not there for criticism. You are there for engaging and so you can show your audience how good your conversation and your relationship is with your guest. You're not enemies. You're very good friends. You have talked many other times. You spend some fun, which is nice.

**Robert | 22:27**
Cool.

**Ellie Rofe | 22:27**
Okay. What? You...

**Ray | 22:30**
Robert, could you bring you to the conversation, sir?

**Robert | 22:33**
Sure. I think, well, is it still the same question? First of all, like, just before. Like, would you right, like would you readjust it before I kind of jump into it because I feel like in general, I would probably say a lot of the same things, like just to put it in 15 seconds generally, just I find that, you know, people are interested or people like to talk about themselves. Usually you don't have to say very much to get somebody going. I find that sometimes the best, people I go along with, you know, I would go to another country or something.
And then, like, where nobody speaks English now. To speak their language, and we would get along so well. Like, you know, after being together for six weeks, we never understood each other. And they just. We all love each other.
Like, you know, because. Because we. Just because the very little they don't need to know anything about me. They're just not really truly they're not interested. They're the they just want this, you know, a person is sit there and like, smiles and whatever.
And then and that's and I think some of that is true for conversations like I had a conversation last week with Mark, I don't think I said more than maybe thirty words is the whole conversation.
And you wouldn't believe how much he was on a roll. Demetris, you remember from last week? I think I did the MCP Wednesday, so I don't think it. Yeah, when it comes to interviewing, when it comes to those types of things, I think, in general, make them look good is what I try to do. I try to make them look good. I throw them softballs. I don't say very much, and I just ask leading questions.
That's the short version, I suppose. So I'd like to ask you, though. What were your thoughts?

**Ellie Rofe | 24:31**
Well, that's a really good question. Because one of the things I wonder is how much I should just ask leading questions and let people roll out and how much I should push back occasionally probe.
I mean, clarification obviously is slightly different, but disagree, etc. Or whether my role is just to listen.

**Robert | 24:58**
I would just listen. It depends, like. But I think that the goods the. I think maybe going back to, like, what you mentioned at the very beginning, you were talking about how, you said somebody's name. Michael Simmons I think.
And you're talking about like a compounding advantage, but like this is I think but this is more like network development and like deepening of your relationships for consulting. I just I don't think.
Yeah, I mean, you would know your industry, obviously, right? And like, what you mean by probing questions, I suppose. But I would just say that, like, seems like the goal is network building, relationship building and so on. I feel yeah, that like you would that to me, I would just look at it as a good conversation.
But maybe there's something else that maybe there's a specific outcome to you're looking for like that's relevant to your market and like what you're trying to build. But to me, like when I'm thinking about like as a consultant, I'm just trying to build up like again from my perspective, just like positive relationships, positive interactions with people and so on.

**Ellie Rofe | 26:12**
I think there's definitely a role. I mean, a huge part of my work with founders is listening. I have to ask the right questions to get them to express things about their company that maybe are a bit hidden to them.
So I think that it's definitely not a bad thing to reflect that.

**Robert | 26:33**
No.

**Ellie Rofe | 26:34**
I think it depends. Like so. One of the people, for example, would be a guy who is a politician or he stood as he didn't win, but he stood as a candidate in the last UK general election.
He is like an industry and energy spokesperson, and he's a businessman who's setting up an ammunition manufacturing innovation that means ammunition can be manufactured in the UK.
So I guess the question is... I actually think the answer is I won't know enough about these things to really push back on them. That's not the role. The role is to clarify, I think it is for me to learn from them, at least initially. Who knows how it might develop if it continues?
But yeah, I can't push back on him talking about defense and immun. He might be talking out this bum about it, but I wouldn't know at this point.

**Robert | 27:34**
Yes.

**Ellie Rofe | 27:34**
So I think it's more clarification and seeking to understand.

**Demitris | 27:42**
May I ask how you are going to use those videos from those conversations?

**Ellie Rofe | 27:50**
Well, I'll. I'll probably bung them up on in full on YouTube, maybe edited, depending. Like and then use clips of them to jump off and talk about stuff elsewhere.

**Demitris | 28:07**
Would you like to connect this content output with those people? So by tagging them and mentioning them, that's perfect. So I think that this is a nice opportunity for them to be connected with their voters because they're politicians, right?

**Ellie Rofe | 28:25**
Some of them will be... I want to talk to an economist who writes for the Times. I want to talk to a politician. I want to talk to a VC.
There are various anyone who's in that intersection of money, knowledge, and power.

**Ray | 28:36**
No.

**Demitris | 28:42**
And I guess most of them are working very hard on their personal branding, no matter if they have a personal advisor, no matter if they use LinkedIn or not, right?

**Ellie Rofe | 28:53**
Yes. Some of them will be, yes. I think, to be honest, I think an awful lot more of these people will be on X than they will be on LinkedIn.

**Demitris | 29:03**
Yeah, it makes sense. They found their channel. Why not? To ask your audience for questions, right?

**Ellie Rofe | 29:19**
M5.

**Demitris | 29:20**
So you can engage with your own audience, showing your audience. "Hey, guys, I'm talking with the prime minister," just as an example. Or with this VC guy, "What would you like to ask?"
Even from the questions, you can be inspired for the questions to bring to the conversation. Or you can realize how people from your audience think about this guy. Now, a friend of mine suggested something. He watched some of my short videos and he recommended pushing them on TikTok because on TikTok, the average user is 35. It's not 16, which means these people are mostly our target audience on average. They're 30 to 40, maybe 50.
So why not to join Instagram Reels to get the 40-50 age and TikTok for 30-40 and everywhere else in there? So you can engage in those channels by yourself, get feedback, and set what other people are saying about the people you're going to have as a guest, look at what's going on in the comments, and so on, to be inspired for the conversation. Bring the questions, remain polite, bring some funny stuff so you can have the opportunity to create some funny context.
The series part will be important for you. Yeah, since your goal is to learn, great. I would say don't forget to go with the follow-ups. If you learn, your audience will learn too.

**Ellie Rofe | 31:20**
Yeah, okay. I really like it. I love asking the audience. I've always stayed away from TikTok because for the same reason, I've always stayed away from heroin.
So I don't like it slightly, but I do understand that it might be really useful.

**Demitris | 31:32**
I'm with you.

**Ellie Rofe | 31:40**
So I'll think about that because I do think short porn videos can be a very quick way to create at least engagement and not engagement attraction level content and start bringing people in.

**Ray | 31:54**
For top of funnels. Yeah. Yeah, the thing about doing your homework first is it gives you the confidence to go into the calm mind. And when you go in mind, you're able to ask simple questions. You're able to let them talk. When you go in unprepared, you're thinking about the saying the whole time. You're racing, trying to keep up, figure out what's the next thing you're going to say.
And as a result, you're not really listening, right? You're trying to keep up, and you are. And then that's that all kind of, you know, show. So I think. Yeah. How do we get you to that, you know, sort of calms in place where you can be the, you know, the canvas right onto which they're, you know, painting their picture of the world, and that'll be easier with a bit of preparation. It'll be easier with whatever sort of helps you be in a good, you know, headspace, you know, for that, and then the way I think about the whole challenging thing, right? As opposed to well, did you just her with them run over you and filibuster?
I have found that the most effective interviews for getting the good quote or the good idea out are the ones are actually more softball, right?

**Ellie Rofe | 33:15**
Hu.

**Ray | 33:16**
It's not like... Be ready to disagree. It's where you think they're getting into the spicy cake. Get them to go deeper, prepare their first couple of minutes.

**Ellie Rofe | 33:24**
M.

**Ray | 33:28**
Get them to go deeper. Now they're thinking. Now they're sharing things that might not have been shared elsewhere.
So I finally... When people give a talk at a conference, they can stand up for 60 minutes, blah. But the best part is going to be the 10 minutes. In the end, that's Q&A because they go about a third of the questions will be good, and of those, the rest will be some combination of comments aren't really questions, but the good questions that make a person think because they don't have it prepared.

**Ellie Rofe | 33:44**
Yeah.
Yes.

**Ray | 34:01**
And those moments, those are the keys. Which then brings you back to the clip, right? Yeah, sure, you did the 30-minute interview, but it's going to be about those three minutes that are found over the course of it that are where something spiky or interesting got set. I have to say, OpenAI is getting really good at finding those too, right?
So it's not like you do it like... But have I created the viral moment? They'll start to recognize it when you see it, but the... But that's... And you being able to pull that out of those people, that's you being bigger than the game, right?

**Ellie Rofe | 34:30**
H.

**Ray | 34:31**
You're a convener, and I think that's a wonderful position for you to be in. So it's not like you're going on here to show that you're smart. The fact that you've got this person in the room that you're saying you're a person who belongs in a room or on a podcast with that person and anything else just about like helping them look good and get more out of them than someone else does.

**Ellie Rofe | 34:45**
Yes.

**Ray | 34:54**
I think when you put those ideas together, you'll find that being a bit more prepared but being calm. Let's do it. Do more before, let's do less during, and get them to do more, and the more of them they get, that last 5% that you get from them, that's what makes for the remarkable content.
I've listened to a number of podcasts where it's like... Okay, so person's giving their same spiel, and they're getting some rope to get the spiel. Okay, then they just inhaled. Can you get them to go deep on that? No, the softball is... Let's talk about the next topic, right?
Because I've got my agenda, I'm going to get through my agenda. I'm trying to keep up or whatever. It's like, "Wait, that was interesting. Let's dig in on that a bit. I find every conversation I do, whether it's in public or in private, when I have that moment of giving that of saying, "Let's focus on that thing and get them to talk about just for a few more minutes." Those will be the most valuable 3 minutes of the hour and potentially of the day.

**Ellie Rofe | 35:54**
Yes, and that does reflect a lot on how I work with founders, to be honest. The bit where they pause or they go, "I just went off on a tangent," and I'm like, "I'm just going to push you back down that road and further along it because that's where the goals are."
I think there are little doors they haven't opened in their brain. That's just like, "Shut that door and let everything behind it just gather dust."

**Ray | 36:18**
Yes.

**Ellie Rofe | 36:21**
And then you go, no, let's open that one. And then it's, like, all comes tumbling out and.
But, yeah, okay, that's interesting. A follow up question. What? How would you pitch for the interviews? I'm going to leave it open, and then I can refine it if we need to refine it.

**Ray | 36:48**
Okay, Detris, what do you think you've been thinking about this pitching question?

**Demitris | 36:55**
Not sure I understood the question. What do you mean to pitch the interviews bring the question?

**Ellie Rofe | 37:01**
Invite people.

**Demitris | 37:02**
Sorry.

**Ellie Rofe | 37:03**
How would you go about inviting people? So it's tempting and interesting for them.

**Demitris | 37:09**
Okay. Are you in contact with them or not?

**Ellie Rofe | 37:19**
The first... What I was thinking in these terms was the first five plus people I interview should be people I know. Then it will be like, "I've done these interviews. Would you like to be interviewed by me?"

**Demitris | 37:41**
Lovely, perfect. That's very good. One idea that comes to my mind is to have it as your personal closing of the interview, asking the guest to suggest two other guests. Which one would you like me to do?
You can send a DM, for example, "Hey, Ray, I had an interview with Robert, by the way. It's here. He wants you and Gemini to be the next interview. Book the session like... You know, book the session with me. It makes it funny for your audience."
So who is the guy Robert will recommend? For example, I'm really curious.

**Ellie Rofe | 38:30**
YP.

**Demitris | 38:31**
At the end. You have the release in your hand. Someone gave the recommendation. He can make the connection for you, breaking the ice easier for you, which is the horrible thing at the moment.
I think that's how it would get started if you have to do the cold outreach. I wouldn't say do it very cold. Just do a warmup by engaging with them on social media, getting into the conversation, putting comments on the posts. Try to be connected with them. Send them a DM like, "Hey, I like what you're doing. Pretty good. That you know, start warming up because if it's totally out-of-the-blue, they feel like one more guy flirting me. Let's avoid... How to work."

**Ellie Rofe | 39:38**
Yeah, but what about the first group? What about the people I know because they're not all like mates?
So the Economist, for example, was someone I used to work with at a firm, and I worked relatively closely with him, but it's not like he's thinking about me at any point in the intervening five years.

**Demitris | 39:47**
One.
Okay, I thought people who are in your close and recent environment are perfect, nice.

**Ellie Rofe | 40:02**
Some of them, but not all of them.

**Demitris | 40:06**
What about a very good email like, "Hey Mr. Johnson, I'm early. We had worked back in that time. I'm doing this, and the purpose is to show up one to three things from this interview.
I would love to have you in there, I would say in this 123, to bring something valuable for them. So they're going to have a reason to join. They are economists, and they had a paper announcement very recently. When not to make a relationship with that as an example?

**Ellie Rofe | 40:46**
Yeah, okay, so linked back to something that they are promoting, if possible. Okay, would you just say it's an interview, or would you call it sorry?

**Ray | 40:56**
Robert, no, please go ahead.

**Ellie Rofe | 41:02**
Would you just say it's an interview? Or would you try and dress it up as a podcast or something? Or a vidcast? Would you just keep it casual?

**Demitris | 41:11**
Podcast and vidcast. I count them as the name, the medium. I would say get the recording and use it as you want it. If you distribute it as a podcast on Spotify and on YouTube and as a vidcast on YouTube and any other platform, you just distribute the same thing in multiple channels. I would say just do it. I so just call it an interview right from the beginning maybe. I don't know, people engage more with the word at least doing the podcast. Let's join.
It's more cool now nowadays instead of the word interview. But you will figure it out. But at the end, I would totally recommend distributing it to all the channels. What is important I would say is to test and validate your stock. Don't get on Zoom,
for example. Find a platform that would be very helpful and useful for you to do the recording if it is on video recording like this one. So you can have separate recordings for its screen, its camera, and so on. There is a service. I don't have it at the moment on my brain, but I can find it. I can send it to you.
It's pretty good, even Krisp from him I found it. He's using it for his interviews. It splits the screen so you can have the screen from LinkedIn and the screen from the other guy and create your sorts separately, which is more powerful. Just be prepared how you're going to test it. Getting to a test interview with someone of your friends. Get the recording, process it, and then figure it out if it works or not.

**Ellie Rofe | 43:11**
Okay. Okay.

**Ray | 43:16**
Robert, can we bring you in?

**Robert | 43:18**
Sure. I'm well, I just think that, like, is this really a technical issue? Is there really a technical issue?
Because we're kind of talking about, like, you know, the platform and the distribution and everything. I just feel like we'd know all that stuff, but I just.
I think maybe it seems like for you that the what we're really talking about, though, is like, why did these interviews matter? Like, what's the perspective? Like, what's the tone? They're looking for. I don't mean to derail or anything. I'm just saying that, like. That.
Like, you know, I just think that there's something maybe to the underlying thing. It might be something to do with, like, the vision or the tone that you that you're looking for. Like, I think that, you know, obviously about how to set up and, like, to do the interview.
Like, we're recording everything and that's fine and like. But I think that there is maybe you could. And I'm poking a little bit, but like, to see if that's true, that like to make sure that we're doing right by you.
That is there something there is there like is it more like the emotional, like energy to do the interview and like and to feel like the why behind it or is it really like the is it with the technical parts?

**Ellie Rofe | 44:43**
I think it's how I so I think it's how I position it when I'm pitching something to someone. Is it just...? I'd like to interview on your camera because I'm doing some research around this topic and just leave it breezy and just say, obviously, I'm doing research around this topic. I'd like to interview on camera with the idea that I will use some of that in marketing. Or is it...? I guess it's how it's packaged.
Does it matter how it's packaged at this stage? Do I just try and get people in? What is going to be most enticing to people? So, Simon the guy, the economist, right? He's a lovely man. He's busy. He's on Bloomberg a lot. He's writing for the Times. He's a chief economist at an equity house.
So how do I make it enticing to him to say I've got very little else to show you beyond some stuff I've been producing and some interesting, potentially interesting ideas around this stuff? I would love to take up 30 minutes of your time when you're a really busy person. What is the positioning there to SE to help push him into... Yes, that sounds interesting. Yes, that sounds like I can give someone I used to work with 30 minutes of my time.
That's my question. I don't know, like a podcast's a bit played out. Or is it...? Does it feel like it's something better if it's packaged or something? Or is it just...? I'm doing research on this.
It's almost an academic exercise. You are a person that I trust as an expert. Come along and... I'm just putting out ideas, but there are other options. It's not like one of those two things necessarily.

**Robert | 46:37**
Yeah, no, I just think that... So it's a question about positioning, I suppose, right? Credibility. I think probably you have it the right way that you're just asking for a conversation to share with them, right? As a leader in a space and you know that you're giving them a space to be able to do that.
Maybe you're wondering, is it a concern? Because you feel like you don't have a big platform and that you're trying to make them feel like, "Well, why is it worth it for them?" But I think that... That's interesting.

**Ellie Rofe | 47:22**
Because it's not just time. Every time these people speak in public, there is risk for them because they... You have a public persona.

**Robert | 47:27**
Yeah, okay, yeah, sorry, I'm just, I'm thinking cause that that's interesting.

**Ellie Rofe | 47:30**
A lot of them? Not all of them.

**Ray | 47:44**
So I think your point about research for podcasts is a point well taken. Have you seen the Hard Tech podcast?

**Ellie Rofe | 47:54**
No.

**Ray | 47:55**
Okay, well, with the actually Art Tech podcast, and I gotta tell you, like over on LinkedIn, the actual their page is called Glassboard.

**Ellie Rofe | 47:55**
The Hard Attaeck broadcast.

**Ray | 48:08**
That's where they do the Hard hear tech POD podcast. And they've got, I gotta tell you, 93 subscribers.

**Ellie Rofe | 48:16**
Yeah.

**Ray | 48:19**
Their most recent podcast from yesterday has one view from two weeks ago. It's got fourteen views. The thing is that hard topics are hard to get people to pay attention to.

**Ellie Rofe | 48:36**
Yeah.

**Ray | 48:36**
And I think that's that that's your appeal, right? Like people aren't talking about this, right? So it's not like you're competing with, you know, Darkish Patel, right or you know, or even with Bloomberg.
Like I think when you talk about like your economist friend right, like these are hard topics and they deserve time, right?

**Ellie Rofe | 48:53**
Yeah.

**Ray | 48:59**
To talk not just about the facts, but what are the ideas? Your big connection is how this relates to investment, right?
So you're going to talk to people in politics, and you're going to bring them back to finance. You're gonna talk to the Economist. Sort of, which sort of a great way even to sort of kick it off, right? Like. How does this.
You know. How. How do these industries that we might sort of collectively call hard tech, you know, around what defense and heavy manufacturing and advanced materials and robotics? And how does that relate to finance and fundraising because that's the zone that you want to be in.
But it's really interesting people like talking about like hearing and reading about money. The things the I fact I think of anything like these hard tech podcasts get stuck on. We're going to go talk about the tech or company building or whatever.
And like you can you can't have an angle, whatever that angle is. But I think the other half of it is if you go look at the clips of this economist friend of yours, which you should have done, right? That. That counts as a research trip prior to.
You know. Ask him like, look, you know, on average, you know, when you're on Bloomberg, you're on there for forty five seconds. We're asking you the question today. Let's talk about the issues that matter, right?
And so like what are you offering the you know, the you want to learn and you want to make this a forum where like he and hopefully others can talk about these issues in depth. And your idea of a follow up isn't to be, you know, challenging, but to be deepening.
And I think that goes along nicely with the idea of hard tech, right? There's there there's nothing easy about hear tech.

**Ellie Rofe | 50:35**
Yeah.

**Ray | 50:36**
And nothing quick about it. And the and you can just sort of take that seriously and if they trust in your character enough that you take that seriously at the beginning.
And if you can, you know, redeem that promise, you know, through the experience, then that becomes the basis of what you'll have for what's next. Yes, sure, they are busy people, absolutely. But I'm not sure any of these people are being listened to at that level of a 30-minute conversation, certainly.

**Ellie Rofe | 51:06**
Yeah, that's a good point. I guess what I watch...

**Ray | 51:07**
No.

**Ellie Rofe | 51:13**
So like, in my head, there's a version of this where I just start doing interviews and see how it goes.
And in my head, there's another version where it's opinionated. Like I have. There's part of me that thinks that we're sort of almost in AAA rehash, the 50 s like there's this shift where there's a combination of fear and optimism happening and that sense of starry eyed innovation at the same time as that sense of like, things shifting, the world moving in ways that we hadn't expected.
And so I don't know whether I give them a big idea like are we in, you know, is it the Atomic Lounge? And it's kind of like retro futurist and I'm packaging it or something or is it. We are just having an interview. There's no packaging and I'm just chatting to about these big ideas around this like triangle of mine. Does it matter? At this stage?
That's kind of my question.

**Ray | 52:27**
I feel like the latter is more authentic. It's you in France. I think when we talk about technical setup, I think the technical setup is going to be more you. The words sound more you-like.
I think probably it's better to have a microphone because right now, you're coming across very sharp.

**Ellie Rofe | 52:41**
Who am I?

**Ray | 52:44**
That which is kind of a classic thing when you're like dealing with a microphone that has gain turned up in order to be a little bit further away from you where it serve the nice you know National Public radio or BBC vibe which is sort of has your. Your why their faces in those things is because the game is based on the square of the distance right before between you.

**Ellie Rofe | 53:01**
Yes, that was just sitting over the other side of the deck. Is that any better, or is that still pretty ropy?

**Ray | 53:07**
It's still has some sharp edges to it, but that's something this group can be of service on, right?

**Ellie Rofe | 53:09**
Right. Yeah.

**Ray | 53:13**
In terms of gain that value, I think a bit of light so that you come across more as a person and more separated from the background as opposed to right now where you do look a little bit like part of the wallpaper.

**Ellie Rofe | 53:23**
[Laughter] Yes, I've got the ChatGPT, what's delightfully called the "Piss filter" where it's yellow. Every image, it is yellow.

**Ray | 53:38**
But like I mean, that's.

**Ellie Rofe | 53:39**
Yeah.

**Ray | 53:40**
I mean, I think. I think there are a couple of small things that sort of allow more Elli to come through, right?
But I don't think they're very. There's a lot to it. I don't think you need to have sort of like a weird set or anything. When I think about, like, the differenti or something that other people have done, they just sort of, you know, they. They dress for the occasion like they know they're gonna be on camera, and then they focus on asking interesting questions. I'm not talking about, like, you know, the bro nanosphere, you know, type.
You know, barstool sports, whatever. But like, you know, again, I think about, you know, people like Patel, like people who are taking ideas, you know, more seriously, or Lex Friedman, right? You know, neither of whom I listen to all that much, but like, you sort of get a vibe, which is not that they have a particular set or anything weird like that, it's just a they're taking the person across from them seriously, and I know that you will, right?
And that's. And if you're taking them seriously, and you've conveyed through a couple of these subtle AV QES, right? But even more so, just through your attention to your guest, I think you'll make the guests look good. They'll have a good feeling about it. They'll be more willing to say, "Yeah, that was a good experience." You'll get more out of them, which would be good for your viewers.
Then, as I say, it's after that, it's like being able to clip and get stuff out there and have the distribution. But I think I... As you know, I love the idea of you being out there and...

**Ellie Rofe | 55:02**
Okay.

**Ray | 55:09**
And getting for these people and like this. This podcast. I just want to exist.

**Ellie Rofe | 55:14**
Yes. Okay, I'm going to keep it breezy, not overthink the positioning stuff, and push on through.

**Ray | 55:22**
Awesome.

**Ellie Rofe | 55:23**
Just get some of the...

**Ray | 55:23**
Do you have an idea when you want to do your first one?

**Ellie Rofe | 55:27**
I mean, as soon as I can get someone, I'm going to ask Alister tomorrow.
I think he's a really good first guest at the politician-businessman.

**Robert | 55:35**
No.

**Ellie Rofe | 55:37**
I'm most likely to say yes at this point. Simon, I'll invite tomorrow, and then I'll just try and work out who in the sphere is a really good person for it in terms of positioning. Do any of you have any suggestions or contacts that would be interesting in this world?

**Robert | 56:01**
I was just going to say that it would actually be helpful. I think after all, the discussion would actually be... Who are you looking for? I think because that would be... Because I think it's still even just a bit. I'm thinking about the people I know, and on the other side, I actually don't have a strong, fully hundred percent idea of what I'm matching against for the criteria.

**Ellie Rofe | 56:28**
So people who are building in hard tech, so atoms, not bits, so real-world stuff, and anyone who sits in any of those corners of the power triangle could be politicians.

**Robert | 56:34**
Okay, no, it's good to know.

**Ellie Rofe | 56:45**
You know, generally it's going to be something around policy politicians, civil servants, people who have, commentators, and the economist kind of sits across power and money because he talks about how politics he's a macro economist, so he talks about how politics affects money, markets and things. Then the money is basically VCS people who are LPS people that the, people who give VCS money. People in that kind of understanding, people who understand the flow of markets, money.
And then the knowledge is generally going to be the founders who are creating something, but it might be academics and the wider sphere of commentary, I guess, like really top commentary. The commentators are useful because they tend to have built a brand because they're a commentator. They're someone who's who whose role is sort of being known for talking about something.
So they're really interesting.

**Robert | 57:49**
So I think really high-quality people, I suppose, right? Because 95% of the people who have BAT would be not accomplishing the...
I mean, those are the top percentages I think of... So just to think about for me even just like basically the highest performers in a way or people who have really achieved something where they're sitting on some type of situation or they're in some type of situation where they're really making something happen and they're raising funds.
But what's interesting, I suppose to me, is where I'm imagining two people right now, and they're both very different. One is a politician, and the other one's an inventor. Or like, some type of.
You know, that. That's what's in my head. And is that what you're looking for? Is it? Are they both the same to you, like equal to you in terms of opportunity?

**Ellie Rofe | 58:44**
Yeah, if they have an understanding of the forces at play in trying to get ideas from here into the physical world through money, knowledge, and power, then...

**Robert | 58:57**
Okay, that's interesting.

**Ellie Rofe | 59:01**
Yeah, absolutely. So I would love it if... I think probably if Maddy raises just because of the timing and everything, it would be really interesting to speak to Maddy and understand how, for example, shifts into robotics happened in her business or what it means to be a scientist who's trying to run a company and trying to keep up with these things or how money shifts. The founder experience is important, especially for a technologist, someone working in atoms rather than just a technologist. I don't mean that, but...
So yeah, that's really interesting to me. A macroeconomist being able to say, "Well, the tariffs are doing this deeper than just there's going to be some reshoring or the politician saying, 'Well, the reason this policy hasn't been done is because of this and that.
Actually, this is how we have to make it happen to unleash this.'" So yeah, there's lots of angles around this thing because it's growing, there's more money going into it, and understanding what's happening within that landscape is useful to me. It would be useful to founders. It will be useful to VCs who haven't got into that yet.
There are loads of ways, hopefully, that these things could be useful.

**Ray | 01:00:24**
Cool. We're going to need to leave it there.
This has been a conversation. We're all rooting... If there we can be doing more or less... Just continue it over email, and we'll meet up again. This place is the same next week.

**Ellie Rofe | 01:00:38**
Great. Thank you very much.

**Robert | 01:00:39**
Sure.

**Ellie Rofe | 01:00:39**
Thats really helpful.

