# State Change Mastermind - Oct, 21

# Transcript
**Ray | 00:00**
Yes, hello, happy Tuesday, the 21st to you all. It's Tuesday. My favorite. "What do you call a special thing?" I call it a Tuesday thing that happens every day. All right, or at least 111 days and seven.
Okay, well, let's all check in here. What kind of week has it been? I think today, Demetrius, you are the primary hot seat. Ellie, you were very generous last week. If there's any way that we can be of assistance to you, of course, we will endeavor to do so.
Maybe Ellie, we can kick off with you, ma'am. What kind of week has it been? What is true today? That was not true when we all got up a week ago.

**Ellie Rofe | 01:01**
What is true? I have had another thorny pitch deck to work on. So, I've just been reworking copy for my website and social plans to just shift away from anyone who is that early in the process and just try to focus. Series A+ because it is exceptionally frustrating.
I can get people to self-select a bit and filter using the analysis tool and some sort of stuff around that. That's a longer-term process to worry about, but for the moment, I just need to focus on getting people who have thought about what money they want from investors and how they're going to spend it to get towards a company rather than how I think what I'm seeing a lot of is how can I get people to give me money so I can keep doing science that I like?
So, it's a bit frustrating at times. Otherwise, I've been doing the pitch deck thing. I think I'm having to just accept that it is a slightly flawed process in that these pitch decks are... I don't know the story of them in detail behind the scenes, so I can only guess what investors might have thought of certain things. I'm just analyzing it based on my understanding.
But I'm accepting that and moving on because don't let perfect be the enemy of good. There's lots to learn.

**Ray | 02:35**
Y.

**Ellie Rofe | 02:36**
There's still lots to progress with. So I think that's really the main things for this week.
I obviously had a very last-minute client on Friday who had a very short engagement with, but was very lovely. That was Demetris, and it was really nice. It was great to work with him on a little bit of strategy and audience analysis and a very light-touch refresh of his brand.
So, yeah, that was lovely.

**Ray | 03:11**
Wonderful. It was true today. That was not true this week ago.

**Robert | 03:17**
I have a new client, so that's good. So, I'm what's true today is I'm just doing work for them and trying to do it better than every time. Try to do it better and keep my focus on really actually ending the engagement as soon as I can. It seems like a great opportunity for that where it's fresh. They are wanting this thing. We just started literally yesterday.
So, I'm trying to do as much as humanly possible to think of trying to deliver on this promise of moving so quickly, so fast, that it basically justifies, well, I think I could even charge more, to be honest, but that's one thing that made me realize.
But I think that they're a bit surprised. Even when I'm explaining to them, "Yeah, sure, we'll get this done by a week, and then they already think about the developers they're going to fire."
I don't think that anybody... I don't think that other people are making the same promise, right? So they are more like really, what else can we do in a week? Type of attitude about it. Which is all fine, basically was a good way for me to exercise the system and the methodology under that pressure yesterday. I was just able to go remarkably far and have a whole bunch of the backend already built and curl tested and verified and so on.
The system, the tools themselves, they work well to propel in that direction, and that's mostly what's new. I mean, sometimes I just feel so dumb sometimes. That's just why I feel... Sometimes I just feel like I can't... Sometimes just the obvious stuff is what's killing me. I feel like I'm just too much of a builder more than a businessman at times, but...
If I could just wrangle both, if I could just be more of a businessman than a builder, I might be able to get out of my own way a little bit. I need AI... I need a manager or something.
Maybe I would love to just go in and negotiate on my behalf, just take... No, you gotta talk to Ray. Ray will tell you, I honestly think it to my for the better or for worse. I'm still in the process of creating these things and just trying to fold it into the delivery process itself and just trying to make it better at the same time, not trying to put so many obstacles in my own way.

**Ray | 07:02**
Got it, the sports agent approach, yeah. Jeremy McGuire. Yeah, okay, cool, and Demetrius, can we check in? How is your week? What was true today was not true a week ago. How can we be of maximum service to you?

**Demitris | 07:23**
Basically, I had a very nice week so far, even from the past week. I spent two weeks spinning around myself for the branding stuff and updating my website, and thankfully, it gave me huge impact and guidance in doing that.
Ele created a template of design, which is where I struggled most. The conversation with A about the branding and the audience understanding was so helpful to me in understanding and finding some techniques to improve my audience and grow my audience. She gave a nice idea and it's noteworthy to hear, but doing outreach to people without trying to sell them anything but just bringing them a question, then this question can inspire their interest. Then we can get into the conversation.
Because the purpose is not to try to sell them anything. It's just trying to connect with them and have a conversation. I think this is a very smart idea. I was invited from an existing client to block five hours of work. I gave a quote for that.
I remember we had this conversation here and in one-on-one sessions with Ray. So, I gave him a price for that block of ours. I put in the discount with the rule. He has to pay upfront, and he has the time limitation to work with me for one month. So, this is for the main new what is new for me in terms of knowledge. I pushed myself a lot in understanding the NEO for Jira platform and the capabilities it has. I spent most of my time so far doing updates and work to be prepared for the upcoming meetup on Friday.
The goal is to go and do the updates for the website and on my social appearances. Yeah, this is a quick description of my week. I feel excited. One of the questions I would love for you guys to discuss today is that it comes from the past week from Li and from my side. I didn't get exactly. I then understood the solution we discussed for Ellie. Li came to the room with an idea of creating a product or not, right?
And how she can use it to make a business. This is a very smart topic. I'm thinking about that too. Like should I go and create a sample or a platform or whatever it is? To be honest, because we talked to them for just a few minutes, I didn't get exactly the knowledge and the path of thoughts you had.
Because usually, this conversation on the brainstorming is what helps me. If you don't mind, and if you don't think this is a repeating topic, I would appreciate discussing it again because I feel like I lost it.
Sorry.

**Ellie Rofe | 11:17**
As in what the Pitch Observatory is about.

**Demitris | 11:22**
Yeah. As a product. Because I like the idea of bringing a product into the market.

**Ellie Rofe | 11:29**
That came about as an idea. So I took Mitch's idea of having a round table. I had been discussing strategy in terms of who to target, who to try and get money out of. Whether I should try and go and work with agencies and put together a portfolio. Whether I should be trying to double down on this or the other.
I had loads of ideas. So I've been talking in a Claude chat, and I realized the Claude chat was getting a bit stale anyway. So I took Mitch's idea and I said, can you give me six names of people?
Six might be too many. Although they did all have really useful views on some level. The AI pretending to be them. It spat out six names of people who I said would be experts and have experience in helping people with this, and they can discuss it.
So then I got it to create an artifact from the The strategy we'd discussed so far where we've got to and I gave a new Claude the rundown of the different people. It had got like... God, my brain's just gone. Was the positioning expert? Ray, yes, and it had all sorts of great people there. I can find the list, but I think different people will be useful for different things anyway. They were talking about positioning, they were talking about messaging, they were talking about testing messaging, they were talking about content creation, all from their different strategies. One of them was a pricing expert for services. One of them was a consulting business expert.
This discussion went on, and they all came up with... You're doing basically Rolls-Royce work for very cheap prices. You must do this, and you must be trying to come forward with loads and loads of high-end approaches to things.
I said, "The problem is there's a credibility gap because the last time I helped people raise was a few years ago. The people I've been with over the summer have been very early, or they've fallen away from raising or they haven't raised yet."
So, this came up actually again, he keeps getting mentioned, and he randomly came up in the Claude thing as a Daniel Priestley idea, but around Fishkin's idea. So, Daniel Priestley's view in the AI chat was, "I am thinking about credibility in the wrong way. I can get credibility through research and expertise."
Then, Ran Fishkin was saying that you can have a data asset, and a data asset is brand equity in itself. This chat then basically continued with the idea that as I start analyzing each pitch, I can start talking about it online, so it gives you content to start talking about. As I keep creating and analyzing more and more Pitch DEX, I'm creating a data asset that has proprietary knowledge in it that other people haven't got because I am creating that knowledge asset, and that in itself becomes a signal of expertise. It becomes something that helps bridge that credibility gap while I'm waiting for people to be able to raise while I'm waiting to get clients in, etc., not waiting to get clients.
But, it helps you bridge that gap, basically. The more I do it, then it starts becoming a piece of IP I can turn it into the deck analysis thing. I can turn that deck analysis into products. Longer term. This is not all at once, but longer term, that deck analysis could be cut. Something I take into an incubator or an accelerator and say, "Let's do this for all of your portfolio companies and the ones that are most in need." Most promising, whichever way you want to look at it. We do a bulk process for them or whatever, but you could send it to VCs. You could help develop something with VCs that helps them quickly analyze PITCHDEX.
Based on these different criteria I've given them and different scoring systems I'm creating and things like that. The goal was for me to create something that helps me talk with authority about something around PITCHDEX without relying on stuff that's four or five years old or stuff that's a bit inconclusive at the moment or stuff that feels a bit airy-fairy. It ties it to something real. I start building a data asset. That data asset becomes brand equity and a longer-term thing. Does that make sense?

**Ray | 16:51**
It does. Okay, do you just how sorry I answered that question, but really the real the person who needs to be answering that is you in terms of whether this is helping you make progress on your thinking about this topic.

**Demitris | 17:09**
Yeah, Li, you just said that. The entire idea came from recognizing that you get when you work on a pitch and you review them, you create a piece of context that you can use in purpose, and you realize that the purpose you want to use it for is to build authority. This is what I understand, right?
So my question is, is it a strategic thought to build the product for that reason? Because the question that ignited me last week was, "Should I make it a product?" Like Daniel Priestley, for example, he offers something for free to collect leads and then tries to convert them into actual clients.
So, in a clearer way, my question is, should we create these kinds of products as lead attractors? Because the authority will count through that, right?

**Ellie Rofe | 18:36**
Yeah, for me, there are two parts to this process. There's the research project, which isn't strictly a product but does become a data asset.
That data asset longer term could become a product because it could become a searchable thing where people could get comparative pitch decks to work off, for example. But for the moment, that research project is more to do with me generating insights and reports and content that then positions me as an expert.
So, it's a bit more of a positioning exercise where I do something that other people aren't doing and stand out a bit while generating a sense of authority. I'm talking about things from a qualitative and quantitative point of view. I'm not just saying things over and over again, which I was getting a bit stuck on, and one of the reasons I struggled with LinkedIn was the product side of it, the report, the tool that people could use to analyze or I could use to analyze people's pitch decks.
So, the thing to remember about this is what Ray has been telling me to do all summer in many ways. It went through different iterations of the VC survey or the database, the data analysis, the report analysis, and industry trends.
Those were really useful, but I came up against some sticking points that were making them hard to implement and felt like they were just not quite aligned with the right positioning for me.
So, this isn't so much that it's something new; it's just that we happened upon this based on the fact that I'd already created the pitch deck tool to try and talk about structure. So it's... Some of it...
It's a bit of a happy accident. I think there is a possibility of creating a product as AI... It's obviously a sort of lead magnet concept, a freebie, or an ethical bribe, whatever you want to call it. There's part of me that thinks we could probably sit here and brainstorm it and strategize it. There's part of me that thinks it might need to be emergent.
And I'm not sure. As you're having these conversations, as you're talking more and more with people, maybe it's something that emerges from those discussions and makes sense rather than something that's forced from top to bottom. I don't know, though.

**Ray | 21:22**
So what do you think? Would you be risky?

**Demitris | 21:28**
We just heard the only opinion I was ready to ask you guys, you and Rob, what do you think about that? Because I have in my brain that Robert created the MCP server as a case study. But he runs a community, so he has something, an environment to deploy ideas, test ideas, and use them as a lead magnet. Even people from his own community get into big clients like a big contractor and so on.
This is somehow close to the idea of productizing a lead magnet.

**Ray | 22:17**
Hey, Robert thinks we can group you on the conversation. You just got tagged.

**Robert | 22:21**
Yeah, for sure. I would say that, I don't get big clients for my community. My community is full of a bunch of freeloaders who like to kick the tire and get free stuff off of me. Okay, they give me some good feedback here and there.
But really, I think my community is the same as everyone else's community here, which is LinkedIn and YouTube. So I just want to say that maybe from that, the purpose of the community, in a lot of ways, is to maybe just create a perception of, "Look, he has a community."
I do genuinely care about it, but it is something I have been running since 2022, and I've had it free consistently since then. And I can tell you very transparently, it's not something that turns the wheel for me.
However, the tools do turn the wheel for me. It's just not that they are... It's not that, it's just it's not tied to really the community at all. I wouldn't even say that the main people who even use it come out of the community. I would say that they come from LinkedIn and so on.
So that's one thing, but really that I think... So I just want to clarify, just to make it clear that my opinion about the community part is actually I think that they're great as long as you're just willing to just grow it without putting any pressure on it to monetize it.
I think then it's... Because it's so difficult to monetize that it can or such a specific goal that it can work out for a lot of people. But I wouldn't say that that's like a criteria or something that's required to grow a business. I don't or, you know, and so on.
However, when it comes to the tool, the concept of that, I think that's a great idea, obviously, because it's one of the main things that I do, which is try to create something and then go into the market with it, in whatever minimum form that I can take it out into the market with.
I would say if there's maybe any thing that I could put my finger on and say that this is maybe like the flywheel that leads towards it being a success or whatever drives it for me, it's just involving it in my own delivery of my services.
So having it be something that I used and then something I sell. I start to take steps forward. It becomes self-fulfilling. So my service becomes quicker, my product becomes better.
I have something. The product becomes better means I can sell it individually. The product becomes better, I can sell it individually. Raises reputation means people start to use a tool, the tool itself is using my delivery. It means
there's more demand for my delivery. My delivery gets better. It makes a tool better. This, slowly, man starts to walk, and leaves his cave. So I'm like that drawing where the cave man slowly stands up, and that's what I think looks like, right?
For the MCP tool, it's looking that way. I can see that even through the previous stuff that I've made, the boilerplate stuff. Same thing. The boilerplate was something that I used at the time, and I used it quite a lot, and there was demand for it.
That's where the technology was, and that's where the type of solutions people were interested in at the time. So, same thing, though, I was using it in my delivery, I made it better, and so on.
So, yeah, maybe just want to highlight that I think product development is a little bit chaotic, but I found there's a bit of something that works there.
I think that's what I'm doing, at least from what it seems like to me. [Laughter] Okay, hope for your cell phone, but just let me now.

**Ellie Rofe | 26:47**
8I think some of it is sorry, go for what I was gonna... I think some of it comes from audience-specific stuff as well as what you're trying to get to.

**Robert | 26:51**
It is.

**Ray | 26:54**
In the B. Please, I would love to try that.

**Ellie Rofe | 27:07**
So school communities, free school communities are really great, as far as I can tell.
If you want to sell a course, you sell a certain amount on the front, and then people who are struggling to implement the small amount you've given them have given them the what, but you haven't given them the how. Then they get pushed into a paid course, right?
So that's quite common. There's a guy I've found on YouTube who is doing stuff about developing, vibe coding and how to structure things and basically as a product developer, properly planning it all and implementing agents and all that kind of thing.
If you look at his free course or his free group, it's full of people going, "When are you just going to do a private course?" So we can just go through this step by step with you, because I want more than YouTube videos now.
So that works really nicely. There are so many different types, and there are all sorts of different lead magnets, so there are things you could do. I once had a little quiz assessment when I was helping people do presentations, and it was called the IDEA Olympics, which was like, "Do you actually have an idea for a signature talk?"
There were different events in the Olympics. How original is it? How much have you worked on it? And there's a version of this where you could do, "Is your business ready for a digital twin?"
So you're creating this little assessment thing where people can learn about what a digital twin is and understand. You're getting people to again, self-select in or out of it based on how much actual expertise or information they have in the business, et cetera. I just think it's that they're normally quite a lot of work to set up and maintain, not necessarily maintain with a tool.
So it seems to me like the next step after you've done the talking with people and understanding more about what your target audience is and what they want from a digital twin and do they want to be in a community? Are they looking at tools online or are they getting referrals and recommendations or whatever it might be like that's understood what their process is.
Because it seems to me like Robert is getting a lot of or more clients from recommendations because the profile of the people that Robert's working with are probably not people seeking out too many lead generation funnels online or being pulled into them.

**Demitris | 29:51**
They are in a very good place.

**Ray | 29:55**
Then you can draw out a bit of a matrix, right, of what are the objectives, knowledge, reputation, cash flow, right? Against different ways you might manifest your expertise, right?
What can they do for you in each of those manifestations? I usually think of five, which are code, content, community consulting, and capital. The idea is... How are you going to apply in each of those? That might make sense for you. Let's leave capital aside for one second.
That's basically investment, as you might imagine. That's investing in the right hands of companies, but then you have... Okay, so what is the opportunity for you to create code? Code is basically what Robert did with the MCP server, right?
That's an attractive thing to look at because it's code. It's cool, but that's not the only way to be creating things that are going to be useful. It's worth noting that, for all the effort that Robert put into it, and for all that he is charging for it, its primary value is as a reputation generator.
It's putting him out in the world to create reputation for him. So, when you think about it, across knowledge, reputation, wealth, was it really done for him? It definitely had a study about act, right? It allowed him the development of his expertise that we think will be helpful in the next turn of the wheel.
It is currently creating a lot of reputation for him and producing a piddling amount of cash flow, right? It contrasts with his consulting, which creates a little bit of reputation. But because it's private, it's not a lot of reputation, right?
It does produce more cash flow, and it tends to be more exploitative in terms of what he knows because he's talking to people who don't know as much as you do, right? You can start to apply that, "Hey, what are your ideas that fit in each of these different kinds of manifestations?"
So, you know what Li is doing, right? He's creating content, right? Our proposal. Right. What you have is a data asset. That data asset, which can then be turned into other things, right?
But it is creating knowledge that you have that other people don't have because you have an insight perspective on the market. It allows you to create reputation because that's where you can distribute it, and it doesn't make any money at all, right?
So, it's worth asking which of these can make you money, and I've discovered that capital is definitely the main way you can make money or you at least gamble. You can make money with content.
This is the point about selling courses, right? Courses are content themselves. Uni is something that we've alluded to a little bit before, right? Certainly, state change falls into the category of building a community and being able to sell that community. You can think about how state change falls at an intersection of a few different parts of this where it has aspects of each of these, and then their job to be done has aspects. As you get to more complicated offerings, you start to think about how they fit across the spectrum.
Nothing is sitting in just one box where the fifteen boxes are basically the five Cs plus the knowledge and reputation. I think that would be the way I would look at this, right? Which of these can be good combinations for you of producing the thing you need, right? Which is knowledge, reputation, and wealth.
I think that right now, it might be said that what you need is some of this moving you up in the actual expertise on digital tweeting, right? Because it's like, "Hey, it's an idea, and you're glomming on to it, but you're building up your expertise on it."
It's probably true that most people don't understand either, right? But you're studying like Dickens to get real expertise. There's the reputation aspect. How do you put yourself in the world that's going to be very bad?
Then, of course, you want things that are going to produce cash flow because we like to have cash flow, but usually, those things don't produce all at the same time. So, when I think about the different kinds of things you could do, I'm looking for the manifestation across the five seas.
That is lower cost for you and high value to the market that allows you to be getting more value today. Then, as you do that, different things have the right ratios for you right on the going forward basis.
So, the thing that is right for you today might not be the right thing to do tomorrow. Today, it might be content or today might be community, maybe the event, right? That is the highest value thing for you to be doing. The question is, how can you do that twice as much? How can you saturate the market on that one?
Then, from that insight, be able to generate content. Which then gives you enough insight to be able to generate code that actually creates value, et cetera. Or maybe it goes straight into code.
Maybe what you learn is, through these conversations, that there's a combination of you understanding how to do this and the market has a distinct need. It's time for you to make an MC server now or something, right? Or something that's going to help the market and then further position you. Or maybe having those meanings goes directly into consulting, and the consulting is what gives you the notions for how to do the rest, right?
But we keep on thinking about how to turn that wheel. That's why I think about it in terms of the job to be done here, right? I think about those matrices. And then there's yet another dimension sitting on top of that. Again, we're... I'm going to bring it, Mr. Priestley.
Because the four types of products. Right. The free product, the proper prospects, the core offering, and the proper clients, where it becomes very tempting to talk about things that are going to create AR because that's always exciting.
That's why people like SaaS is because it's a theory. It's money while you sleep. But that only really works as a prop for clients, right? Because you have to have a lot of trust in order for them to be letting that sit with you.
So what's the attractor, right? What helps you get that wheel spinning faster and faster? This is where, when I think about your stuff, I think your events are great. I'd love to see... I want to see your events. I want to see some more of your events. I want to see the events into content.
I think Robert showed where the value can be, and the bit of podcast experiment I've done over the course of the summer. I think the amount of attention it brings is really remarkable.
Then what else can you do that is really high value on the content point of view, right? How can you redouble that? Is there an opportunity on the code side? But you know what I have found? The easiest way to get started with the content is by talking to people.
The most direct way to have talking to people turn the content is by doing it in public. That's why the meetups are such a useful way of going about that. What I feel to be strongest there, and what I love about Ellie's stuff, is that she's generating and curating a whole knowledge set that gives her something to talk about, right?
That's useful to the market without requiring a lot of the market. The market doesn't have to have a whole lot of trust in her or have to have a whole lot of investment in her to be able to get profit from what Ellie's been doing.
That means it can do the job of actually building trusted Ellie just like the events you're doing with Robert, just like the... I'm hoping that the digital twin stuff can be doing for you. Anyway,
I think that in terms of this intersect rate of types of assets and the jobs to be done.

**Demitris | 37:28**
Yeah, so what I'm understanding, Guy, is that the core pro is doing this as a side product just to connect with the people who have the interest and having the push to create a conversation with them.
So, we can show the authority on the subject, our knowledge on the subject, how we manage the things, which are the struggles and all these grades, which makes a lot of sense. The reason I had this question seriously is that I was thinking that I need a real case study to start working on instead of just converting my own transcripts with without a specific professional direction.
I thought to talk with my colleagues who are in the running club and start doing digital twins for each athlete who wants to engage in the program. A doctor and a running coach are involved because they like it.
We are planning to build it. I said, "I will bring the tech aside. We will bring our data inside this and we will see how it goes." I, to be honest, this is what I was looking for: a real case study to explore the hidden aspects before I face them to a paid project.
Because the paid project has the pressure of the time. Right? I wouldn't like to be in this position. So, yeah, I think I have to go on this and use it as this journey to generate content to make to capitalize on the say.

**Ray | 39:31**
Right. I yes, I think that if you... For me, I find creating more content is the way to play a bit easier. This kind of gets a little bit to Robert Singer, like, "Hey, it's so much fun. More fun to build."
It is fun to build, and I've done a couple of builds, actually, are in that free profit market category. I put them up on State Change or whatever, and I'll
put them up on YouTube as well to get a little bit more bang for that buck. But I would say the important thing about those MCPS is that I'm not talking about State Change MCPS. That's a lot there, there's more work, it's a heavier weight thing, but these little ones I did. The emphasis being on them being little, just a good return on investment. I learned I created, I can contribute that increased his reputation, but for each one, it was less than an hour, right?
So make sure that you're not... This is where, especially... [Laughter] I love Mitch, but one of the things I find challenging is that he will get into how the things that need to be created need to have XY and Z criteria, right?
When you set yourself up that it has to have a whole bunch of things to it, it creates so much friction. That's going to be a huge piece of work. Then you're not getting any of that done, right?
So, what's the little thing that you can do? To sort of get that wheel turning? On average, I find content to be easier than code. But if you're not finding that to be the case because you use MCPS and everything else, that's totally fine. The question is the return on investment.
The way I think about return on investment is, just sort of hard to do. So with great precision's, like what is obviously an easy experiment fitting into the one-two paradigm.
And that I have a reasonable belief, is to be interesting. Then I think there's probably more of those than you can do. That sort of makes it possible for you to be in a position of sifting, to figure out what you think would be good within that rather than just trying to come up with an idea at all.

**Demitris | 41:36**
Yeah, good points here.

**Robert | 41:42**
Got it.

**Ray | 41:43**
But I just might say that if you were thinking about what you could do next, right? That would improve your reputation, particularly on these lines. I swear. I think the biggest thing is to get yourself to a weekly cadence with these meetings of some kind.
I think, Robert, stuff I think is... If there is enough demand for this in the market, you'll get some folks showing up. I'm not saying it's going to be every meeting could be a banger, certainly that it wasn't even the case for Robert's thing, right?
But I think you get more of that. I think you are a compelling personality, and I think with whoever's in the room, that becomes the easiest way to create content. If you there's another easier way, go for it. I'm not trying to be preventing you from doing the thing that's easiest, but my intuition is that that's the way to play it easy.
Then if you have that on a weekly basis and using some combination of that and Opus to turn one video into ten, there's an opportunity for you.

**Demitris | 42:50**
From this point. Can we move the next question? Guys, we're doing this to create content, and the content will be the way to generate leads, improve our reputation, share our knowledge and so on. Is there any hidden secret we have to know when we publish our content so we can make it more converting, so we can increase the probability of people converting?
Because, for example, what is.

**Ray | 43:29**
The goal?

**Demitris | 43:30**
Not only to show who we are, but to attract people to our calendar. Right? And this, I think, is a common question for all of us in this room, isn't it?

**Ray | 43:45**
Okay. Let's kick off with you?

**Ellie Rofe | 43:49**
Sure. I think there's a tactical piece and a strategic piece in my head for this, and I'm not saying I'm good at doing them because I get two in my head as well, but a lot of it comes down to again, what we spoke about the other day, which is I guess... Yes, thought leadership content is important, but when you're writing thought leadership content or when you're doing stuff, try to write it to connect with the people you're trying to become to have as your clients, rather than trying to write it as something that impresses people about you.
Because I think there is a tendency, especially if we suffer with imposter syndrome and stuff like that, to try and write things that just demonstrate us. I know I've just talked about demonstrating expertise and authority and things, but with the actual conduct, the substance rather than the tone or whatever or the focus.
I think that that's the biggest part of it is connecting with people in a way that they think this person knows what I need and understands my struggles and has answers for me. That's one of the best ways of getting people to convert.

**Ray | 45:08**
I had.

**Ellie Rofe | 45:10**
The other thing is just asking them to...
So actually not in every post, but actually having a CTA, a call to action in posts, giving people that direct "Do this now" because it's astonishing how valuable we can be when we're in flow and we're thinking, "God, I do need this help." Now I will press that button, I will try and connect with them. There's lots of tactical stuff.
Honestly, I listened to... So to see a thousand LinkedIn experts, and they've all got their views on the algorithm changing and this, that and the other. And I listened to a really interesting piece about someone who does analysis across multiple posts of the top 1% of LinkedIn creators, working out what is working, what isn't working.
They obviously do their own... It's the content accelerated program. I'm never sure how much you focus on those tactics versus how much they tie you up in knots. How much do you worry about...
So they were saying video has very low reach. So you're not going to get loads of people, you're not going to get loads of impressions.

**Ray | 46:24**
[Laughter].

**Ellie Rofe | 46:24**
And you need impressions, you need people seeing your stuff.
But video obviously helps people see who you are, so it is an important part of it. Carousels get the highest engagement rates. You want people to be trying to save your stuff. So educational stuff's really helpful.
But I don't know sometimes whether that just ends up tying you in knots. I think that the key thing for me is to make sure you're talking to someone, not just other people, other technologists, not just demonstrating your own.
Here's the things I know. But how it applies to the people trying to help. Then ask them to do something. That's... I don't know. I'm not great with social media.

**Ray | 47:10**
What do you think?

**Robert | 47:16**
I think it's probably just... It's tough to say, but I think it's somewhere in between, probably crossing at least two things that are unique to you. Then, in the right way, which is only really the way to figure that out, is just to put it on the market and to see if it resonates and then to almost treat it like a hedge fund manager where you're looking at the results and you're just trying to see what worked, what didn't work.
Okay, I said this. I put this picture, I said these words. Someone liked it more, someone liked it less. This worked. This didn't work. And you start to look back and you start to try to connect the dots.
I think that for some, when we look at the outside, we might see people posting and it might seem like they're just posting, and it's working. I think that to a certain degree, especially if they're seeing success with it,
they're investing the least their thoughts and their energy into trying to figure that out to put their finger on the pulse of what is working for them. I think that again, it depends on each person.
The good thing is that for everybody, there's a different cross that you can put between your interests and the other topic that you want to talk about, right? There's maybe Joe Rogan, for example. He talks about a whole bunch of people, but it always has this underlying thing where he will bring his own personality into the conversation, where, whatever, somebody wants to agree with him or disagree with him.
It's not like I'm not saying I'm a huge fan of him or anything, but just the point is that he will talk about weed, aliens, guns, and whatever, and then mix it in with his other opinions, and then you start to get an interesting discussion out of it. Or at least you get a polarization out of it towards who wants to watch him and who doesn't.
Maybe there's something there as well. In terms of what are we putting out there and how much of it, how much of ourselves is in it, and then how much you know, and then how you mix it into the content that you're trying to create something that's something that I don't think I've even scratched at really the even the surface of that myself.
But I think that's what I see in people who are doing really well on social media, where they have a bit of themselves and their own interests, and they've mixed it up, and then you can't really copy that.
Somebody else is not going to really be able to come in and say, "I'm going to talk about weed, guns, and aliens." And then it's not going to be the same thing because he chooses that topic and whatever, right?
So, yeah, just some of my thoughts.

**Demitris | 50:12**
Yeah, thanks. Very good points too.

**Ray | 50:16**
Yeah, that's a really good point about authenticity, right? Who are you? Make sure that you're putting that out there. We were talking about marketing gurus before I go to bring Seth Godin to the party.
I think what you're looking for is a purple cow, right? What you want is to be different, be remarkable, be the thing that is valuable to others. That is, eat, that can be remarked upon, right? A lot of that comes from authenticity, right? It can be you seeing something that's valuable, you being excited about a subject. I tend to like you make work about it. Hey, this is why digital twins are important. What you really do is speak to people who already think digital twins are important.
You're becoming remarkable to those people because you're saying the same thing that they are. They're like, "This guy gets it right." People who don't think digital twins are important, you're not going to speak to them, right?
If you want to speak to them, you speak to them about things they do care about, which is not about digital twins, but about something digital can affect, but actually is core to their business.
So, how do you speak to the people that you want to be based on where they are today and with that kind of signaling that they will find remarkable? Right? Based on again, where they are.
The number of people who do that is actually not that large. There's a whole lot of... I'm going to make a slopp or I'm doing engagement bait or whatever. There's a lot of that stuff out there. You don't need to look like any of that. Fact. I wouldn't wish you to look like any of that. Instead, it's, how can you be you talking about a subject that you genuinely believe to be valuable and that is connected to what they believe to be valuable? When you have that confidence, there's power.
I think you've been seeing the first sparks of that right as you've been getting into the digital twin stuff. The exact way that looks comes in, not totally clear. But that's why there's still a good deal of study to this, right? You're still figuring this part out.
But I'd say that's where Robert was with the MC stuff right at a point previous. It's all about climbing that learning curve. You were asking, how to make it convert? The way to make it convert is to make it remarkable to say, "This is the person this person understands about one, the issue I care about, and two, the issue I have to do something about today." A combination of credibility, importance, and urgency. When you have those three things, they will buy if they get it. This is important, but it's not an important thing right now.
You know, you're talking about what kind of flowers to plant. That's not the thing to sell in November. know?

**Demitris | 53:05**
Yeah.

**Ray | 53:08**
And like selling fir trees to be put up inside people's homes is not a thing to sell in July. You figure out, there's... Of course, those are silly examples, right?
When you're talking about business, it's not nearly that obvious. But that's why you want to dial into this. What is it that they're going to need to do now? We're heading towards the end of the year. What is the end-of-year aspect of this or the closing of the books? Is there something that's related to the Christmas calendar that matters? For retailers, that's a big deal, right?
And whatever, I'm just sort of spinning ideas off top there, but like, why is it you right, why is it important to them and why is important now? And if you. When you connect those three things. That's the purple cow. They not only remark that. They not only remark upon, but they then knock on your door and say, hey, there's something I need to do, something about.

**Robert | 54:09**
Great. I would just say that. Sorry, I was just going to say that. All of this reminds me a little bit of a video I saw a while ago. You've probably heard of the brand Steve Madden. They make shoes, maybe. So, they're pretty popular.
They have this. The guy himself, I guess Steve, sits in the back, and they have this. Okay, basically, I remember seeing this video where, essentially, they want to create a shoe, and what they do is they say, [Laughter] Yeah, I think so. They want to
make a shoe. Then, what they have is people in the back. They want to go, and they literally make one shoe, a pair of shoes, and that's it, right? They try to make it as fast as possible.
They're sitting in the back, I believe, of their most popular store. So, what they do is they just go out and put their shoe on the shelf and they just sit in the back with the cameras and just want to see if anybody even picks it up or even looks at it.
Then, if they don't, then they don't make any more of that shoe. But if they do, they just got... Because to them, fashion is a trend, it's always moving, and it's hard to say.
So, this is a way for them, without overinvesting time and energy, to go and make literally one pair of shoes and just... They actually do this where they'll go and put it just go and they'll sit and they'll just watch and see. Did anybody even pick it up? Did anybody even look at it or buy it?
And so I always think about that when it comes to sometimes maybe what are we aiming for in terms of what is the quickest turnaround? Time to find out if something's going to work or not to get that validation from the market.
That's one way that Steve Madden does it and 28.

**Ray | 56:00**
That's a really good point about what you can do. Yeah, looking for ways to be able to turn it quickly and then be able to observe it. I think that is a very worthy lesson.
However, do not go public the way that Steve Madden did. That was just a terrible story.

**Robert | 56:20**
Yeah.

**Ray | 56:21**
Featured in the movie Wolf of Wall Street, which tells you probably all I need to know about it. Okay, I think that brings us to the end of our hour here. Just that gives you a little bit to work with.

**Ellie Rofe | 56:33**
Do you mind if I share just one quick thought? Just to tie it together a few things, which is why I've just suddenly thrown that in the chat. If you're helping your running club, and running is a massive part, and you're an athlete and health and stuff, start doing that as quickly as possible. Start talking about it.
Then maybe your target market when you're doing this is sports coaches. Maybe it's PTS, maybe it's health coaches who want to create their digital twin. But start talking about it because it's absolutely you.
It's authentic to you. It could be a really interesting thing. Lots of people are talking about digital twins in terms of business, but health is really interesting.

**Ray | 57:14**
That's a really good point.

**Demitris | 57:16**
Yeah, really good one.

**Ray | 57:19**
All right, thank you all, thanks. It's been fantastic.

**Ellie Rofe | 57:20**
Okay.

**Ray | 57:22**
We will be doing this again. I'll talk to you in the week. We'll do this in a week. Take care. Bye.

