# State Change Mastermind - Feb, 17

# Transcript
**Robert Boulos | 00:03**
Hello, Heyda.

**rhdeck | 00:05**
No.
How is your Tuesday so far? Sir.

**Robert Boulos | 00:17**
It's good. I feel like I have some stomach issues, but otherwise I feel okay.

**rhdeck | 00:25**
Sorry.

**Robert Boulos | 00:25**
Yeah, I just feel a bit under the weather a bit with the... Yeah, the sing problems, but otherwise I'm doing good. How about you? How's your Tuesday going?

**rhdeck | 00:39**
I unfortunately do not have stomach issues. I just came in from a quick run on the mountain.

**Robert Boulos | 00:45**
Nice.

**rhdeck | 00:45**
It is actually a little busy today because this is a school vacation week, so it becomes a popular day for people to go take a few days and take their kids skiing. I remember when I was playing squash. One of the guys I played with, he talked about going on ski vacations.
He said that what you need to do is you need to go take a ski vacation. Then you need to put the kids in lessons. The purpose of the lessons is not to educate the kids. It is so that you and your spouse can go have some time for yourselves.

**Robert Boulos | 01:12**
Can ski, yeah, the Bunny I'll.

**rhdeck | 01:16**
Send them with somebody who will take care of them.

**Robert Boulos | 01:16**
Send them to the bunny hill.

**rhdeck | 01:20**
They'll have a good time, you go hit the bar or whatever.

**Robert Boulos | 01:24**
Yeah, and they'll be tired after too, like they'll be like, dis discombobulated and tired.

**rhdeck | 01:30**
Yeah.

**Robert Boulos | 01:36**
How are you doing, Dimitrius?

**dimitris | 01:38**
Then. Well, guys. How are you?

**Robert Boulos | 01:42**
Good, doing all right. Alright, just getting through Tuesday is... That's how I feel.

**dimitris | 01:50**
It's early in the morning for you.

**Robert Boulos | 01:52**
Not at meals, it's just noon, but like, no, yeah, just lot. There's a lot to do, there's always lots to do, there's.
So, yeah, I guess we're just waiting for Ali.

**rhdeck | 02:08**
Or just by frowly.

**Robert Boulos | 02:09**
Cool.

**rhdeck | 02:12**
Let me check my email to see if, like, something occurred. Which, you know. Check and see if she's not waiting around. Okay. All right, I just sent her a reminder with the with LA we'll give another couple of a couple of minutes here, and do just. Of course, it's your, think today.
And if LA does not come, then what we have is the potentially weird situation where last week you got L last hot seat, you got Ellie in this hot seat, you get robbed.

**dimitris | 03:08**
Yeah. No. That's true. That's where they felt initially.

**Robert Boulos | 03:10**
Yeah, that's part of our plan.

**rhdeck | 03:15**
It's all part of the plan, you know.

**Robert Boulos | 03:17**
Yeah, exactly.

**rhdeck | 03:22**
A quick zoom note, Robert, just while we're waiting here. Dimitrius, I saw that you had added your avatar right to your zoom, which I thought was smart, like the image, right, that goes next to where it says your name, Krisp.

**Robert Boulos | 03:38**
True.

**rhdeck | 03:39**
And I was wondering whether you might profit from that as well. Now, I know I sort of I have mine, which is from when I did a kind what?

**Robert Boulos | 03:49**
Yeah, I like yours at the studio. I think you should keep it, by the way, at this point.

**rhdeck | 03:52**
Thank you. Yeah. I just did that from a photo. And that was... I thought it was cute and I put it in there. I really should probably fix that.
But the...

**Robert Boulos | 04:03**
It's only aged like fine wine. It's. I find I think that you should keep it. Like, at this point, it's like, I don't know, it's sits the brand.
You know, some people have a big beard, like you told me once. I feel like that picture is, you know, getting some of those qualities. At least for me.

**rhdeck | 04:25**
Okay, well, you know, all good the other thing I find I'm wonder if it's like the pish cri Dorian Gray, right? It's sort of it. It stays the same age as I keep on, you know, going.

**Robert Boulos | 04:33**
Yeah, exactly.

**rhdeck | 04:34**
Going... But the other thing I was... I know Robert just in terms of zoom stuff is that Beatrice and Ellie have her name with her full name next to them. I actually find it to be pretty helpful.

**Robert Boulos | 04:46**
Yes.

**rhdeck | 04:48**
And, yeah, it doesn't need to be Robert versus. It's questions like how you want to be addressed is the first part right, and the second is like making clear who it is. Because, you know, that way when you're doing a meeting with a bunch of clients or whatever, it's like, hey, there's Robert, there's your avatar, there's your whatever.
And it sort of looks like you're, yeah, right.

**Robert Boulos | 05:08**
Real person for sure. Actually, I'm trying to. Yeah. No, Im gonna try to change it.

**rhdeck | 05:14**
We're trying to fool them into thinking you're a real person because we all know you're actually just a robot.

**Robert Boulos | 05:17**
Yeah. The real Roberts are actually doing the dishes upstairs.

**rhdeck | 05:23**
[Laughter] Not so good, Ellie, it's good. Can I ask how you're doing today?

**Speaker 4 | 05:31**
Yes, sorry, I'm a bit late. I got a call just as I was about to come on from one at the SDP trying to finalize some details to get this project kicked off.

**rhdeck | 05:43**
Fantastic. Well...

**Speaker 4 | 05:44**
Yeah.

**rhdeck | 05:45**
We'd be glad to take a back seat to money around here. That is that that's a big part of all. Okay, well, congratulations on that. And maybe we can just sort of go around home. Maybe we can start with u li. What is true today? That was not true when we met a week ago.

**Speaker 4 | 06:01**
Yes, I mean very little. Because I had a bit of a week slightly marred by not just illness. I injured my back on the roof early in the week.

**Robert Boulos | 06:17**
One.

**Speaker 4 | 06:17**
I tried to do fasting and insanity later in the weekend. I just basically... Was a bit of a physical wreck and thus a mental wreck on many levels.
But the SDP thing is progressing. I did get progress on the portfolio and finally worked out the structure. I sent a draft to Paul, who said he's going to give me some feedback because he's the one sending it on internally, so that's good.
So, yeah, there's a bit of motion, but it's been a little bit of a nothing we make. I mean, there have been good things happening, but in terms of my energy and what I feel like I've got done, it feels like it's been a bit of a nothing week.

**rhdeck | 06:59**
I hear that not for nothing, but in another meeting I was in just yesterday there was a comment about how the person had their business and they felt like they hadn't been able to work on the business
in the last two weeks. And this was the best two weeks the business ever had. Maybe there's a lesson there.

**Speaker 4 | 07:18**
Stop.

**rhdeck | 07:20**
Okay, well, let's keep going around. Robert was true today. Was not true for you a week ago.

**Robert Boulos | 07:27**
I would say I'm trying to. Okay. So treated it out a week ago mostly just further developments on. I would say maybe I would just categorize it as the internal tools for the business.
And like I suppose like if tech technology and all those things are competitive advantages then than investment in you know, in a time of energy into developing those things to be like of a more AI powered agency.
So, yeah, and it's been good. So like, I've been able to fold it into the conversations as well, which has been, then to the benefit of those conversations, I have been actually started, this like pretty much officially working with Mark Peterson.

**rhdeck | 08:26**
Okay.

**Robert Boulos | 08:27**
Yeah.

**rhdeck | 08:27**
Very cool.

**Robert Boulos | 08:28**
And we'll see how it goes. But, it's been. I mean, you know, it's been positive. Like, I'm going to meet with him and his team tomorrow. We actually already met today and yesterday, and so I was able to, like, get some good information out of him and just kind of figure out, like, where it would be like a good area to help him with.
But like, overall, I'm just, like, looking and I'm just trying to just see what's, like, the biggest opportunity that I can create. Because I'm to be honest, I look at everything and I'm just like, okay, this is good.
Like, you know, it's fine, but, I'm sure, like, I'm already, I don't know, I'm getting restless. Like, I just, you know, I'm just kind of like. Okay, what? Whatever kind of like in the best in a way like I you know what I mean?
So, yeah, yes.

**rhdeck | 09:24**
I do. I'm trying to remember who it is, who talks about, like, you know, go find the next bigger check. You know, like there're there's current and then there's like what's sort of the level up. And sometimes we're trying for the first check and sometimes we're, like, looking at what's the thing going up.
So I hear what you're talking about. That's a super cool place to be.

**Robert Boulos | 09:42**
Yeah.

**rhdeck | 09:44**
And Beatrice, can we check in with you? What is more true this week? And how can this. How can we put the resources of this group at your disposal to help you have an even better one?

**dimitris | 10:00**
What's true today? Yeah, I've completed most of the final edits into the service. Tomorrow will have a demo live event, and I started a series of Mastermind sessions every Wednesday. People can have access from the interface of the app so they can click one button and join these Zoom sessions. Today I split the day. Half of it was doing my work, my homework for the communication where I struggle a lot.
This is what I would like to talk about. The other thing I'm doing currently is trying to improve the UI of the interfaces because they look pretty old and quite horrible. I know that behind the scenes, they work, but the look and feel make sense for people when they look at it.
So I'm going to try to improve them. By the way, I used the Cloud Code Desktop and some skills to redesign, and it goes pretty well. It doesn't go very well to me. The thing is, how can we communicate with a professional who has these skills when we don't know the language? This is... Where is the gap between human and the machine?
I had the same difficulty talking to Claude with those skills to do the redesign like I'm talking with someone who had to do it as a person. You know... I don't know whether your language... Don't ask me about design styles, what it means, and all these kinds of words.
So I did it in an opposite way. I said, "Okay, take a full scan of the pages, recognize what is important, and feel free to make it look good and nice." I don't know what's going to be the final example. The night is long.
I will soon let you know. By the way, all the database is fully cleaned. So every user... You're going to receive an email invitation tomorrow morning. So you can get into that and you can test it because new features are added to the chat. Three agents are taking care of finding useful information for you for end users.
So I would say this is quite true for the side of communication. I came with the question, "Guys, how can we create content easily?" Or in other words, "How can we create effective content easily?"
I'm still talking about the text, not the video. Even if it's horrible to start talking to nobody, you can deal with that. It's like a Loom. You don't have to look at the screen, and it runs, it flows.
But the text is the thing I have to work on. Let me specify what I mean by easy and effective. First, how? What is the framework someone can follow to not spend time? That means easy to me and effective communication into the market like he's talking, right? Putting his face out to the market.
Here's an interesting example I posted on stage. There was a report from a company analyzing 6,000 LinkedIn profiles looking for common things, what works and what doesn't work, and so on, and they gave a very good report. This is the lead magnet for them, so someone can sign up for their platform that can use their platform to generate content for them today. Use the platform.
The result was horrible. It was horrible because it had no thoughts, no input for me to give my personal side of view and who I am, what I'm doing, and how I'm talking. They were creating copy-pasted outputs. While the challenge is how you can talk like nobody else so you can be recognizable, but you can have the engagement.
Maybe it's a little bit philosophical. I don't know. I don't want to bother you, I don't want to burn out. You just... I think content is a common subject for conversation.

**rhdeck | 15:48**
Right? Well, let's open this one up. Ellie, you have the mic. You don't have Mudon. So can we start with...?

**Speaker 4 | 15:55**
Yeah, absolutely. So it is such an interesting challenge. Funnily enough, I have been reconsidering producing a very light version of Google for myself, because I get frustrated with what I'm... I'm pretty good with AI, but I get frustrated with the lack of context and how much effort I have to put in to try and get something that doesn't sound like AI. I will say the model is so important. I don't think ChatGPT could do anything but sound like ChatGPT.
It is incapable of picking up inflection or anything. It's like an amalgam of red it and other internet text into a very generic voice. But Claude 4.6 is better. It's still not ideal, but better. Gemini can be really good, really strong with voice, and it...
It was one of the early ones to really pick up on voice and be able to sound much more human. So I think when I was creating Google, there were the ways I looked at it. There is the context that you need to put into it. What does the model need to understand about your business?
So the audience, their problems, their desires, etc. Your offer and what you do, who you are, and that kind of thing. Then you have the tone of voice layer, and I have a structure I had for that which was effectively a kind of elevation of the God, is it Nielsen four dimensions of tone of voice where it's like, "God, I wrote these things and played around with this for so long, and I can't even remember them. Respectful or irreverent.
It's four different spectrums. Serious or humorous, formal or informal. Calm or enthusiastic, and that it's really for you. I UX text. But it's a good start, and then you can add some other stuff onto it.
So you have what the AI needs to know about your business, which is the context. Then you have the tone of voice, which is how it should shape the output. Then you need the brief for what the output itself is.
So you need to have some very strict parameters for AI to understand. Within that brief, you need to be able to say to it, "When you're creating a LinkedIn post in text, these are the important things, these are the books. Create. These are the most effective hooks to create."
So it's managing all those different dimensions and putting them into AI, and I have to say I haven't got some amazing, useful solution for you directly because I have really found it a pain in the
butt. But I AI am considering trying to just do a fast, quick build for my own personal use of a kind of moogle setup because I have all the structure I was using to help me do it because I find content incredibly painful.
So I would say that's some of it. I think it's much harder for you, as we discussed, because you're doing it in a second language, and the language you're then writing in is not just a different language but it is a different thought structure.
So you have to adapt two steps. Not just vocabulary, but the associative frameworks and patterns of thinking that are evident in Greek are very different when you're trying to shift them into a LinkedIn hook for an Anglo audience.
But, yeah, that's my initial pass at that one.

**dimitris | 20:15**
What is interesting is, every time I put myself in a high pressure of time and say, "Okay, go and put anything outside very fast right now. So I'll be myself. I do it at the time that works for me.
Finally, this receives higher engagement than the one where I work for three or four hours for 300 words, putting all AI together, looking around for all the best practices and all the things.
Here's the thing I can't realize. What is the pattern that makes the output work so I can make it a framework, so I can adapt it?

**Speaker 4 | 21:06**
If that's where you get success, then I suspect the framework is a tricky one because it's authenticity. If you're going fast, then people will recognize something in that feels artificial by the time it's gone through four hours of working in AI, so it's something that's difficult because it's a gut feeling that people have, and I haven't done a huge amount of research.
I know some people have been trying to look into it, but even when you take away certain grammatical devices that AR uses, like "it's not X, it's Y," etc., a lot of people can... Not everyone, by all means.
Look at some posts on Twitter that have huge amounts of likes and people telling them they're an amazing writer. It's very obviously ChatGPT. Fine, [Laughter] but there is... Certainly for anyone who's a relatively sophisticated reader or spends a lot of time reading content, they can tell even on a gut feeling that something is AI, so you can't manage AI to get everything right. What I tend to find with AI is that let it give you the structure if you're really struggling, then draft posts and just read them and put them away for a bit, then go back to them.
So it might be that there's a multi-stage editing process. If you go back to something with fresh eyes, you might be able to look and go, "That bit doesn't sound like me. I'd never say that." Or something like that.
So they... What we used to call it the drawer. Edit, I think we used to call it or something where you'd put something in a drawer for a few days, and by the time you come back to it, it's basically editing itself because you've got fresh eyes on it.

**dimitris | 22:59**
Yeah. Yeah. I know this feeling. [Laughter].

**rhdeck | 23:05**
Super cool. We'll bring you into a mix.

**Robert Boulos | 23:12**
Well, I would just say that I think a lot of it is just practice. I think that you have... It's hard for me to remember, but if I try to force myself to remember our first interaction,
and if we were to pull up those videos, I'm 99% sure that there would be a noticeable difference between how we were communicating a year ago versus today. I think maybe this is just a part of it is that I... Because even for myself, you just start to eventually become aware of how you are communicating.
Then you're in that gap between... You're just aware of how it could be better. But you're not necessarily... But you're in that frustration zone. It's not... You don't have the capability yet to perform at that level that you want to.
I think this is how you start to close that gap right into where you want to be. At least for me, that's how I found it to be that I would notice something, and then it would bother me. Energy flows towards it, and maybe it starts to change the behavior a little bit, right?
It's hard to do, but I think... I mean, it's a non-answer in a way, but I don't know, because I don't have AI. If we're talking about writing in general, I think that's a very hard thing for me to describe in terms of how you actually write.
Well, to be honest, because I find it to be just... I suppose, just it. I maybe I'll just. I would say that I think essay structure has always served me well. Maybe I would say that like, I have always found essay structure to be, you know, something that makes a lot of sense. Just like, open up with a thesis, like, and then, you know, three paragraphs, each one, like, is, you know, supporting your point.
And then, you know, in a conclude conclusion, like in general, those. I think that type of structure works quite well for even videos and for other things like that and otherwise, though, like in terms of creating content, I would say just like, yeah, good models for sure.
Like they make obviously a difference, but probably like, for me, I find the best stuff just comes when I mostly just record myself and then use the AI to clean it up and then that's it. Like, I find that usually the big waste of time is when I'm.
I mean, I don't. I don't know if I've ever actually really come away with a. If I from a good experience with this, if I started off with asking the AI, like, well, what should I write about today? And then I start to get into that rabbit hole with it.
You know, like it can really. Like, you know, time can really fly by. And I'll have nothing by the end. And versus if I just start to talk and I just say, okay, this is what I'm thinking right now, and then this is what I, you know, I've been doing this. Been doing this. Or, I don't know, like.
But I usually can think of something to say, and then. And then I'll if I speak for long enough, I'll eventually come to a point. So I that's how I got my writing done, though. Nowadays, and it's not too different from the before times of AI is just that I record myself a lot more and I'm speaking out loud a lot more now. Just like. Versus just mostly before I just to keep it on my head and just kind of like. Thank in silence and now I'm just like now I'm just talking out loud all the time.
Yeah, exactly. Pocking you know you does anybody remember like this episode of Twilight Zone where there was it was somebody goes to the future and they have all these he like everybody has an implant makes them super knowledgeable. Or is it just by.
Okay, I remember watching that and I was thinking, I'm like, wow, that would be crazy if that exists, and pretty much it does now. So anyways, I'm gonna try to find it. Yeah, but that would be my two cents.

**rhdeck | 27:16**
Man, I hear that. The one of my favorite expressions is that the best way to make a small fortune is to start with a large one, and you can make a larger fortune often just by talking.
You talk about recording, but can you just get more words out of yourself? I find talking is a shortcut to this, right? It keeps me... If I'm writing, I can get stuck on this thing, but if I'm just talking, I will repeat myself. I won't say all great things,
but then I can say, "Go, pick out the good turns of phrase." The key is then picking out my turns of phrase, and that makes it sound less like AI, not totally perfect. Often, I'm trying to put it into a structure that has a little bit of AI sound to it, and frankly, I have a lot of ticks in the way I speak that sound more like AI. It's not just an X, it's Y. My God, that sounds like me, which is... Yeah, you're absolutely right.
So the... But I think speaking can help a lot. One thing you might try doing with AI is turning it from a creator of content to an asker of questions. The reason for this is to get you to talk more, right? That creates more of that big pile.
But it's actually one of the reasons why creating content's easier when you're in conversation with somebody, right? Because you have somebody else actually asking questions and drawing things from you.
So if you can do it through conversation, all the better. That's one thing that's great for this script stuff, right? But you can do that with AI by asking it to be in the role of an interviewer, and I've actually found that to be helpful.
I was doing that to help out someone with their strategic position piece. I was trying to figure out what I think about this. So I got the AI basically to ask me questions about what I think about this. Or I'm using previous questions to build on that.
Okay, go deeper about that. Whatever, right? Or acting like an investigative journalist and using that to pull more out of me. Then each time I would ask a question, I would just hit my function button.
That's why I've got my Mac Whisper tied to and talk press it again. It cleans it up, gives it back to the AI and then did that several cycles, right? I'm not going to pretend that it was instantaneous, but the key is AI is not creating the content. It's really not creating the ideas. Those are your ideas. What AI can do is package the content and that's a whole small fortune made from a large one.
So how can you get more of your ideas out of your brain and into a place where the machine can work with them for a lower cost? For me, it is the sound of my own voice, right? I find voice really helps with that.
I'm using Mac Whisper, which is a tool that Robert put me onto that I found to be super helpful. I think Robert's using something else, usually using Whisperfone now or something.

**Robert Boulos | 30:19**
Yeah, I'm using Super Whisper now, but it doesn't replace... I mean, Krisp. Yeah, one-time payment and keeps updating it.

**rhdeck | 30:30**
Right. It's all local, and I can use it anywhere. I don't need to worry about my continuity, blah. But that's all detailed. The point is, how can you just get more ideas right out in the zone of the AI?
So the AI is not in a position of creating content. I'm not saying, "Hey, go come up with words or whatever," I'm saying, "Here are my words, sift out the good ones." I repeated myself four times. Maybe you want to pick one of those, right? You don't need to repeat yourself too.
What's the good stuff? Let's pull that out. Then a package that... So it can be used for someone else. Then the AI is doing what it does well, which is data transformation, what it does not do. Where I think things go off the rails... You're asking it to create one other idea as it regards...
Because I thought Robert would make a good point about how far we've come. Your library of older content. One of the best pieces of writing advice I've ever gotten. I don't know if you've heard this one too. Ellie is... When you're stuck writing, go collect everything you've written for the last year.
Emails, posts, whatever, put into a document. The exercise of doing that can actually surface a lot of ideas. Like, "Hey, that was a good idea that I only ever said to one person." There's something else. Here's the other gag. By pulling that stuff together, it's all like context for AI, and once again, you're in a position of having to pull out the good stuff, right? Which is you as opposed to asking it to create anyway.
So that's the thinking I have. If you give AI, "Okay, go create some good articles for me," I'll create whatever articles it can create. But that, well, one, there's a quality problem, but two, it's not you, right? The whole point of all this posting stuff is authenticity, and authenticity is about sharing you with the world, that you are someone worth talking to. They don't care about talking to AI. They can talk to Claude for a lot less money than it costs to talk to you, so...
But you do have good ideas. You do have stuff that's worth seeing. You've said a lot of good stuff, including really useful stuff to me that has produced a lot of value for me. I think if you turn around and share that with more people, they will get better too, and they will then see you as someone who is a source of that value, which is not for nothing. True, right?
It's just a question of being able to connect that and to package it and distribute it. The job of the networks is to distribute it, and then the AI can be used to package it. But you don't need to create content that way, right? The creation process that you've probably already done... Let's just get that out of your brain, right?
That's where the "AI" part can come in or out of that corpus of stuff that you already have. I'm not saying that's the solution for every single problem, but I think it can really help.

**dimitris | 33:31**
Yeah, it can definitely help in finding the ideas where, at this point, I feel pretty good. I'm at the level where I can increase the list, the pool of ideas, the concepts. Where I struggle is when I have to make the final shipping. A struggle in the hook. Which is the most important... I'm struggling in connecting the rest. Last Friday, Ray gave a nice suggestion like, "Write it first as a draft and just ask AI what the core value is in this context because I don't have consistency."
So finding the core points, ask AI to just move it to the top and do the job as a good point. Any other idea close to that in terms of writing? Because even if I do videos, for example, where I feel more comfortable and more than writing text, I need some text to follow.
So I struggle at this point.

**rhdeck | 34:57**
Why do we have text to follow?

**dimitris | 35:02**
It can be... Alone. You have something to write when you post a video.

**rhdeck | 35:13**
Okay, I don't know what I what I'm flipping through like on the LinkedIn app, the videos it shows me doesn't it doesn't show any text going on with posts just in terms of more important is we'll try to get at.

**dimitris | 35:30**
This is true, but what about on laptop on our desktop devices?

**rhdeck | 35:41**
That's a good point. I think the regular feed just shows videos plus content together. I think that's totally correct. I'm looking at a couple of these. I'm just. I'm just flipping through my LinkedIn right now. Just sort of looking at theat.
And some of them have some text, but like, this one here has like ten words and go straight to the VIB just by way of like it. It doesn't all have to have lots and lots of text. As I'm working at.

**Robert Boulos | 36:17**
Yeah, like, I would wonder if maybe, you know, like we're we are our own harshest critic. Are you over criticizing yourself when it comes to this?
Maybe because I. I've never really. You. You. It's never set out to me that this was like a you know, to me you're produced, you're putting out content and it's getting better, and I would say that there's a glass half full, you know, you know that if you keep just doing this that it will continue to get better.
You know, likey.

**dimitris | 36:55**
Yeah, this is true. What is discouraging is not the over criticizing. It is that I put too much effort and consume too much time without getting results.

**Robert Boulos | 37:13**
But are you feel like. Are you actually not getting results? Like that's the part of like you feel.

**dimitris | 37:18**
Yeah.

**Robert Boulos | 37:21**
You know, I think like Dan Sullivan talks about the gap in the game. So, you know, what's the you're looking at the gap, but like, what's the gain, right? Of like how of how far you've come.

**dimitris | 37:36**
Well, I don't. I don't have, people interacting, adding a comment, getting into a conversation.

**Robert Boulos | 37:44**
Okay, so then what's that so then what's the so what's the like, you know, so before that.

**dimitris | 37:46**
And nothing from all of this?

**Robert Boulos | 37:52**
So what are you writing about them, right? Like if you were to take it a step back before that point, right?
Because it's never. I think that you can look at it, like very pragmatically and that it is not anything personal or like you could always just break it down. It's like, what are the topics that you're writing about?
Right? And rather than put it on that like this is necessarily like a something like, they don't that you're writing skill. Maybe there's nothing wrong with it at all. Or maybe the, you know, just putting it forward that perhaps it could be the topics and other patterns, right in like in what is it that you write about, right?

**rhdeck | 38:33**
No.

**Robert Boulos | 38:37**
And which ones have more success, which ones have less this s like some type of data, right like, you know, because we're talking about like well, how the market is responding essentially, right? And are they looking for great writing or are they looking for topics that resonate like.
And how much does the quality of the writing really impact that, right? When it comes to what the job of it is to do. Which is to generate calls, I presume.
Just some sense like.

**rhdeck | 39:14**
Yeah.

**Robert Boulos | 39:15**
I mean. You know. I'm just... I don't know. [Laughter].

**dimitris | 39:23**
Made good points.

**Speaker 4 | 39:28**
Yeah, I guess it's the question of what... There are multiple questions in this. Firstly, just to contextualize, LinkedIn is significantly harder than it was even a year ago or two years ago. So I don't...
It's going to be difficult to expect massive leaps and bounds in LinkedIn unless you really hit clickbait to try and drag up follow accounts, but even then, what it's trying to do... This might be an interesting thing to understand. I noticed my feed radically shift when I started talking specifically about hard tech and pitch decks and stuff. Actually, the algorithm is pretty good. People are getting angry with it because it's got more refined.
So they can't use a trawler net. You have to use a fishing line. That's why people are getting really angry about it. But my feed became people who were trying to fundraise, people who were talking about fundraising, and people who were building companies, and about 90% of the other stuff got filtered out. All my mates who I've known for years but have done something that's completely irrelevant to me or whatever.
I started getting random likes from people I don't know and haven't connected with before. Now, when I'm talking about stuff that lots of people are already talking about, pitch decks, raising, etc.
I think where some of your issues might be here, which is completely external, and there are ways to think about it. You are talking about a brand-new idea. There's not a ton of people using... In terms of keywords that the AI is using in the algorithm to try and push you in front of people or to push people in front of you.
It's not got the same breadth of content to base itself on. So I don't know whether there are ways to talk about it. That strip it back to something that other people might be talking about so that you and it's a bit... It's maybe a bit short. But maybe there are some ideas we can brainstorm around that in terms of how you can talk about this stuff in ways that people might already be using those terms.
So it puts you in front of them because it knows that this person is really interested in understanding how to do X with Y or whatever. I don't know. I think that's part of it, but just accepting that LinkedIn is much harder.
So are you filtering for likes and engagement, or are you filtering for people connecting with you? What are you measuring? Because there's an old saw that basically the vast majority of people who end up getting in touch with you on places like LinkedIn have never liked a single post, and they don't know they haven't commented on anything.
People who comment all the time don't buy from you. I mean, this is not one-on-one, but so there's a question of, I think sometimes, where the signal is and where that signal is being pushed.
Don't necessarily worry too much about engagement. Worry about whether people are connecting with you and you're building relationships with peers as well as clients.

**dimitris | 42:59**
An interesting point.

**rhdeck | 43:06**
Yeah, there's something here too, like I was thinking about like, you know, if the standard is replies, then you are looking for more text because people reply. That's text to things they're reading. People don'tly to videos, right?
So like, there's a bit of and part of this is sort of matching the media, but how comfortable are you with that? Right? So there's a little bit of, you know, I kind of wonder whether it's just sort of are we circling the right thing and it hadn't really occurred to me until now this might be a thing is are is your yeah, are you trying right now to get people to engage right?
And by. By engaging, what you really mean is replying, which means that you want them to use text to express themselves back to you, right? When you expressed before, you're not totally comfortable with expressing yourself in the written form. I was just wondering if this is playing... Are we just going round here just so that we can not play to your strengths?

**Robert Boulos | 44:29**
Vi video. I think there's, you know, there's something really to be said about like. I mean, for me, I'm very comfortable with writing, but it's hard to get a video out of me.
I mean, but hey, like, but my writing will. You know, my video is getting is catching up writing as my writing is ahead of it. I don't think you maybe use your strength and let your writing catch up.

**rhdeck | 45:00**
Just to, you know, thinking about think about what we were just saying and I'm sorry, I don't mean to be dominating, but the, this is why you meet up matters because you know the way they will respond is in kind, right?
If what you're doing, if what you have is a video and your video is worth watch and your video is promoting your meetup is another way of interacting with you on video. Live voice, right? It's sort of that becomes the next step as opposed to them applying to you like to right, that's like with like from a medium point of view becomes another good reason for you just to have more frequent meetups. The.
But I'm sure as I think about, like, what's the medium you want to communicate on, right? That puts your best self forward. And like, where is it that we're sort of, you know, trying to figure out how to shove a square peg into a round hole with all different media that we work better or worse on, you know, and like, if you understand what your alignment is, then you can be playing to those strengths, right? I don't...
Then I think if we say, "Wait, we're trying to do more on LinkedIn." But LinkedIn as a text media or a LinkedIn revise are necessarily text then that's not the nature of the engagement that's going to play to your strengths. The meetup feels like it's in the right direction, but it's an idea that's only just started, you know, noodling around.
So it's not super well developed yet. There will be smart stuff there.

**dimitris | 46:42**
Yeah, that's a good idea. What other options are there to attract more people? If live events, content, and LinkedIn, is there anything else that comes to your mind that I could use?

**Speaker 4 | 47:09**
You're talking about marketing channels. That's how I think of it. I mean, there are broadly social media marketing channels. Knowing where you thrive and which platform your people are on helps you choose if LinkedIn isn't right for you because it is broadly a text image to an extent based medium.
But it doesn't promote videos that much. As far as every analysis, the algorithm can show if your majority content is video, then put it on LinkedIn, but that's best to be a secondary platform.
So... YouTube, TikTok, X, I know that it's... There are parts of it there are a hell hole, but there's lots and lots of discussions happening by experts. So it's finding the right people.
Videos work well on all those places. Obviously YouTube, obviously TikTok, which is primarily videos, and I think you'd be surprised how many people are on there. It's like the niche audience. I think there was one of the biggest content creators on the... Not the biggest on TikTok, but she just did Excel videos on TikTok and became huge.
So it's not just like funny dances and stuff. So there are the social media platforms, then there's obviously if you have a mailing list, you can do email marketing if people have said that they'll be marketed to you by you.
So you can keep... That's really about keeping at the forefront of people's minds, reminding them that you're there. It is written again. You can obviously link out to videos, but you need to write the subject heading, etc.
Events in person or online events. But, yeah, there's... Let me see if I can find something. I'll let someone else talk for a minute.

**rhdeck | 49:17**
Robert E, we bring you back to the conversation.

**Robert Boulos | 49:20**
Sure. Where would what would be of, you know, what's on your mind, Dimitri? Like, just to be able to respond. Maybe to what you're thinking right now.

**dimitris | 49:40**
Well, I'm thinking of finding a list of things I have to focus on and things I have to do every day for the next one to week so I can attract people for the service.

**Robert Boulos | 49:58**
You want, like, a plan.

**dimitris | 49:58**
And one of the.

**Robert Boulos | 49:59**
Like AI... I think it's good to make a plan, like...

**dimitris | 50:00**
Yeah.

**Robert Boulos | 50:01**
I mean, like a strategy, I suppose, something repeatable that you want to do for...
I feel like you're the person who would be... Tough... If I was to think of a person who would know exactly what to do for that, I would probably reach out to you because I think that you know that to me, you have described those things to me in the past before in very clear ways.
So you've... I've been trying to pick up and try to implement those things to this day. So what would you tell yourself?

**dimitris | 50:51**
Well, I think where I see is I want to fight this magic recipe of the things that can guarantee me that it's going to work because I get disappointed so early when I don't see engagement. I don't see people coming up.
You know what? It's three months now where I'm trying to make a business in a new service, totally new one. I struggle to communicate it because it's quite technical. I see other people communicating it very effectively.

**Robert Boulos | 51:26**
What are you trying to communicate? What is it that you trying to what is it that you're trying to communicate? You're saying you see other people communicating it. Like, I'm just wondering what? That it is he.

**dimitris | 51:37**
Well, I saw one guy who is a LinkedIn consultant, and he's doing live events, and he plays a lot with video. What he's doing is he builds a knowledge base graph. He shows the visual, but he doesn't explain to you how he gets into that point. You just see it, which is fancy and so nice and it's attractive.
So the medium attracts you, and he explains to you how to do a couple of steps using some text documents. He shares the files like, "Here are the things. Here are my list of prompts. Go upload them into the cloud, and do the similar job, and you're going to have it."
But he doesn't explain to you how you can build a graph that can be there for you and so on. Even from that point, only the IMS in his existence speaking very fast because he talks very fast, giving him credibility, and he solves the problem that many people have with personal branding on LinkedIn. Many people have it.

**Speaker 4 | 52:52**
Just to push back a little bit there. He is a LinkedIn expert.

**rhdeck | 52:57**
Yeah.

**Speaker 4 | 52:58**
If that is your benchmark, that's really hard. His whole life is using that platform to make his own business and get other people's businesses. So learn from him.

**Robert Boulos | 53:15**
Marketing to marketers. Like all the way down.

**Speaker 4 | 53:19**
Yeah, exactly. Biops. Like it's, that's a very high benchmark to have.
That's like me going out and starting to skate and then going, why can't I win another pick gold? It's like you're tough on yourself there, but learn from him and see whether there are things that you like in the way he does it and then copy it in your way.

**dimitris | 53:49**
I'm already copying him.

**Robert Boulos | 53:50**
[Laughter].

**Speaker 4 | 53:53**
Does it work?

**dimitris | 53:56**
He's very good at that. I copied many ideas, concepts, even the redesign is copied from him.

**Speaker 4 | 54:05**
Okay, be careful.

**Robert Boulos | 54:07**
Six.

**rhdeck | 54:10**
If there's a good fraction of this of what do people want to learn about and hear about, and are you delivering that to them? Nobody wants your content. Yeah, nobody wants to spend time on it, right? What they want are solutions to their problems.
If you are either entertaining it on TikTok or educational on the subjects that they care about, if you are helping them make progress, then they get value and they reward you through building up trust, engagement, turning things there.
If you go take a look at your YouTube, even in your shorts, there's a significant tail off, right? A few things get a lot of views, and a whole bunch of them get very few. The thing is that the ones that get a lot of views have issues in common, right? The things that they care about.
The part of what you're doing by throwing more spaghetti against the wall is you're discovering what things people care about more or less. But if you want people to be responding more, you probably need to be focusing on those things that they care about the most. This gets to Ellie's point about this guy who's helping with the marketing, right? You want to wear linked with marketing. They're coming to the person, he's giving them useful content, or they at least believe it to be useful content.
They believe they're making progress through consuming that. And you've got some of that too. So like, when you're asking, like, how do you make content? I think there's a little bit of like you're separating it from what you're set, separating the how you're writing from what you're writing or how you're creating it from what you're creating.
Like, what do the people care about? How can you deliver that value to them? And like, we actually think braingraph is a wonderful story. I think if you talk about that in a clear way, there's a lot of benefit to be had with that. Hey, here's how to do the same really fast. You were talking about Neo 4J with Claude. That was a good story.
I think that kind of how to for knowledge grass has a lot of value to it. I wouldn't want to be have you get stuck in the cul de sac, right? But in the discovery processes, what else is like that? What else has those qualities right that you can use to extend your reach into other people who might not care about that particular technology?
But wait, what they really want to do is solve this problem. How can you help them solve it? Right? And like, where they believe they can be making that progress for free. But really, what they're doing is they're. They're building more trust with you. Which then can lead to other stuff.
But I mean, when I look at your content, the differentiator. I don't think it's so much about the quality of how well you're writing or what have you. I think it's what you're writing about. And there's. And it might be worth just sort of doing that review. Or isn't hard to do it yourself. Give it to AI to do that review for you, right? That we get more neutral assessment. And you might find that there are some trend lines in there of these things correlate with that higher level of engagement.
So we've talked some about like how did about the how to get more ideas how do you how to get more words better how you know what platforms do use and. And all those are good things, but encourage you to check in on the "whats."
Because I think you've got some good "wets," you've planted some good hooks, you've caught some fish, right? You haven't caught custom anything big enough that you can land it in the boat yet.
But we won't... You won't be able to follow up on that stuff because they built a little bit of trust in you. Then what's their opportunity to go build more, get higher returns on that?
I think you've seen some of that. Your data is going to give you some of those hints and directions are like, "Hey, this stuff doesn't seem to produce as much as this stuff, even if you think this stuff is more useful."
It might be that you find stuff that doesn't have as many views but does have a hard correlation with sales. But I think that's a round two thing, right? That's where you have sales.
Then there's a difference between the things that lead to sales versus things that are just leading to attention. Right now you're looking for either at this point.

**dimitris | 58:13**
Very good point, that one. I don't speak for the problems. Today my homework was to write down the problems as we did early together before Christmas. I did it manually and it took me one hour to list 30 problems specifically from my investigation and already my experience talking with people.
So I have exactly those cases. Right after I said, "Okay, if someone asked me randomly on the street this question, how I will give him an answer." In that way, I try to transfer my voice of tone into this text. I use words like, "Bro, I'm sorry, no." These kinds of things are written there.
Yeah, I think that's a good point. Now the thing is, how can you use all the incredible suggestions from this conversation and this homework for the next step to start making viable content which talks about the problem and the solution? Problem-solution that's only this, not service, not things, nothing. Great points. Thank you guys, super appreciate it.

**rhdeck | 59:33**
All right, I think that takes us to the end of the hour. It was awesome to work with you all. We will do this again next week from today.

**dimitris | 59:42**
Thank you. Mi.

**Robert Boulos | 59:43**
See you all. Bye-bye.

