# State Change Mastermind - Feb, 17

## Action Items



## Key Points
- Ellie reported progress on her SDP project, including finalizing details and receiving a call to kick off the project, though she had a challenging week due to back injury and illness. 
- Portfolio structure was finalized and a draft was sent to Paul for feedback before internal submission, representing significant progress on Ellie's business development. 
- Internal AI-powered tools and technology development continued as Robert's focus for creating competitive advantages in his agency business. 
- Robert began officially working with Mark Peterson and his team, meeting multiple times this week to identify opportunities and areas where he can provide the most value. 
- Dimitris completed final edits to his service and scheduled a demo live event for tomorrow, while also starting weekly Wednesday Mastermind sessions accessible through his app interface. 
- Database cleanup was completed by Dimitris, with email invitations to be sent tomorrow morning to users for testing new features including three AI agents for finding useful information. 
- Content creation challenges were discussed extensively, with Dimitris struggling to create effective written content despite having good ideas and concepts. 
- AI content creation strategies were shared, including using Claude 4.6 and Gemini for better voice recognition, establishing proper context about business and audience, and defining clear tone of voice parameters. 
- Recording oneself speaking and using AI to clean up the content was recommended as a more effective approach than starting with AI-generated content from scratch. 
- Voice-to-text tools like Mac Whisper and Super Whisper were discussed as solutions for converting spoken ideas into written content that AI can then help structure and refine. 
- LinkedIn algorithm changes have made content distribution more challenging, requiring more targeted and niche-specific content rather than broad appeal posts. 
- Video content and live events were suggested as better alternatives to written content for Dimitris, playing to his strengths in verbal communication rather than struggling with text-based LinkedIn posts. 
- Content performance analysis was recommended to identify which topics generate higher engagement, focusing on what audiences actually care about rather than what the creator thinks is most important. 
- Focus on problems rather than service features was identified as the key missing element in Dimitris's content strategy, with homework assigned to list 30 specific problems from customer research. 



