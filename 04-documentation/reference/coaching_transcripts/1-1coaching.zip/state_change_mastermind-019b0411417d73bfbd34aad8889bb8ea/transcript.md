# State Change Mastermind - Dec, 09

# Transcript
**Ray | 00:00**
I wanted to switch over to Google Meet and I had to like SWIT and my browser wasn't set up for Google Meet, and that means my browser wasn't set to be doing the recording at all. So I'm. Okay, got me start it and like I'm on DA early Access. 
And so even though I previously set up DA to be able to do like restream, I think it just blew up. Had to go installed again and it was a little bit embarrassing in the first few minutes. Do your AV checks ahead of time. 
That's the lesson for today. Hello, Ellie. Today it is a gorgeous day outside, a gorgeous cold day.

**Ellie Rofe | 00:32**
Hello. Good afternoon. I am very well. Thank you. And you.

**Ray | 00:41**
But my mountains is now open and snow like huge mountains of snow outside because of the snowmaking they're pushing hard.

**Ellie Rofe | 00:45**
The snowmaking happened.

**Ray | 00:53**
They're gonna open the whole of the mountain by this coming weekend.

**Ellie Rofe | 00:56**
Wow, it snow making does sound like it's elves or pixies or something that does it.

**Ray | 00:58**
I.

**Ellie Rofe | 01:02**
The snow breaking has happened. Ya.

**Ray | 01:06**
Yeah, well, my boys are excited. I mean, the whales of snow out there are very fun for them to go sledding on and sort of means that more trails are going to be open and just having a good time. They were super excited because a favorite trail of theirs just opened up today. 
So there's, you know, there's magic in the air. It's a Christmas miracle.

**Ellie Rofe | 01:26**
Good to hear [Laughter].

**Ray | 01:31**
I thank you so much, everyone, for, you know, for the commodation from before, from last week, and, yeah, let's get into things here. Ellie, can we start with you? Ma'am? What kind of week has it been? Was true today. That was not true. When? We met. Two weeks ago.

**Ellie Rofe | 01:52**
What's true today. The event didn't happen. As I say that like can say there's like a AA parent game show where they call it the Event and it's an apocalyptic thing that's happened. 
So it's like the event didn't happen. And that's good. Were learning from it, had to defer from doing. We were going to do a live like recording of it anyway. Had to defer that from last week. So we're gonna try and do that this Friday. Just a session or something. 
You know, like a condensed version of it, just so we've actually delivered something and it didn't just dissipate and fizzle into nothing. Then reconvene and work out whether we try and run it again in January or whether we try and just do something slightly different. 
I think Natasha is doing some kind of twelve week coaching program. I think it might just be too much that she's trying to sell at the moment if we do another thing. And yeah, that was interesting. I heard back from the materials. The Advanced Materials founder got the new version of the deck from her to test the AI tool with, which was instructive in that the AI tool didn't come out with stuff that was very useful. 
But that really helped me. Thinking about it in terms of. I was about to directly send something to a founder. And thinking about the sensitivities, especially mid rays, and not just like damming a deck, but just giving false confidence in a deck because it hadn't identified certain things. 
So I'm restructuring how it analyzes things. And I've had it on this sort of scoring system across different areas. And I think it was too compartmentalized. And actually, you just I'm going to try and strip it back to simplicity and say what are the questions that investors will ask, what's missing? What are the gaps and threads of pull out and just see if that gives it more of a direction. 
So that's been interesting. But now we're doing a deferred payment very short dent on that to try and work through the strategic gaps that are going on.

**Ray | 04:04**
Two.

**Ellie Rofe | 04:10**
I thought I haven't got clients. We can get it done before Christmas. Hopefully after that, she can push through and get some funding. 
But I think it's strategic questions that she needs to answer, so we'll see.

**Ray | 04:23**
Super cool. I appreciate it. Brief. Robert was true today that was not true two weeks ago.

**Robert | 04:31**
Two weeks ago, that, wow, it was true to today not true two weeks ago. I am trying to reach further with the Snappy tool is becoming more popular. I have more people who are initiating from their side and coming up with their ideas. 
And now they want to talk about it within the context of, hey, I have this idea. And I can see that the tool work and I and they're convinced enough that it will work well enough that they want to have a conversation in the context of can you help us validate this idea? 
And then we want to build it with the tool. Like they can see from their side that there is a way to they want to get to through this tool as a vehicle. So that's a great thing. It's like kind of. I mean, that that's. 
I think in itself, like some type of, stage of adoption, you know, where people start to take it out of my hands and then they really run with it. I've are a few people who have done that, but, more like namely Luke. 
But this is more I think they are well they are, I think better entrepreneurs than Luke. And so it's more interesting great to see when you put it into their hands, like, where do they want to go with it and so on. 
And yeah, and I've just been doing, more calls. Like, I've thought a lot of people who really want, coaching and they want, like, group coaching and all that type of stuff. And I'm, I'll be honest, like, I don't feel a huge drive to organize like a two hundred dollars a month group. 
Like, I don't know why. I just it doesn't get me super excited to do it. I would almost more rather that they drop in and I just use the footage to, build up reputation. I just don't feel like there's a, it's Hard to describe. 
It's a mixture between of the feeling of like type of people who show up for $200 a month, thing like that. They usually don't want to move very quickly. They have, a lot sometimes they have, like, usually an underlying money challenge or something like that. 
So I'm always very hesitant, which because I'm so hesitant, it only makes those that group of people want me to do it more because I'm so avoidant about it. So they're just trying their best to nail me down. 
And now, can you do the group coaching? Can you? And I was just like, I don't know. Like, I guess I could, but I don't know how I might get bored of this in, like in a week. So anyways, I think it's all these are all, I think, good problems. 
So yeah, and yeah, that's what's happening. Basically. I think it's just. That's mostly what's changed in the last two weeks. Just a bit of more in every category. And trying to be very careful about, like, what I you know what I really say yes to. Just keeping in mind how, you know, what is the real potential of this. 
And if I say yes to this, just my energy is infinite, right? It's finite. So and that's really what I'm trying to protect, it's just how much energy do I have throughout the day? It's. And these are especially people who what they want to call for two hundred dollars a month or something. 
I mean, they're they ask a lot of questions for like it's during that for you know, it might as well be private coaching because of my commitment to it and. And how badly they need help. So anyway, that's it.

**Ray | 08:45**
Cool that that's a series of really useful, interesting observations. Okay. Demetris. Sir, I am grateful to all three of you. But I'm mostly grateful to you because I know it was gonna be a hot seat last week. 
And you were very gracious in letting me, you know, beg off last week. And so today, a lonely nation turns its eyes to you. How can what kind of fortnight has it been? And more importantly, you know, I get that that's just the warmmo too. How can we be of maximum assistance to you to help you know, get a running start to the month of December?

**dimitris@3nuggets.io | 09:28**
Thanks, guys. We happened those two weeks. I ran one, community event, one more. It was the fourth one. It had a nice engagement on conversations during the call. It created very thoughtful ideas to me. I came up from these conversation with, some concerns from people. Mets. 
And the other guy put a couple of concerns about my methodology creating the knowledge graph. So I'm planning to test those approaches and make a comparison between those the results. And started engaging with people in the same domain experts who are working in building nodes graphs and nodes bases. Digital twins more using LinkedIn. On that, I just first engaged with their post and then I send them a LinkedIn request with a personal note and then I try to start the conversation. These are not called call, these are not, reach. I'm not reaching out them to make them our clients, just to expand my network in this domain. 
And I really find their content pretty interesting. The upcoming Friday I'm running office hours event where everybody is invited to join and put any kind of question, ideas, thoughts around the staff of Digital Twins and Knowledge base. 
And, something important to me today. I had a very grateful conversation. Long one. Where? With LA. Who just used her knife and opened my brain. Finding a couple of things about, we call it branding, but we mostly talk about who is my persona. She helped me a lot. Finding the personas, how I should talk to them and what I should bring to them as a message, which was very insightful. 
And we move forward next week on this approach. And I am in the position where after the yesterday's conversation with Robert and Ray into Margan mastermind and started thinking about the product of my for my services. 
And this is something I took with earlier today, and she brought me an idea that. Okay, it doesn't have to be a product like a subscription based, system. I thought about a page where someone can upload a couple of transcripts and create knowledge base for them and they can go and test it. 
And Kli brought the idea that into this process I have to be engaged to. And this is true. I like that So I think at the moment and all after all this thing today, which was insightful, I would bring this conversation. How what do you think, guys as the best approach to go and develop this, thing with me into this engagement? Do you have any ideas things to avoid ways to communicate? I would love to run for a couple of test users and record it. Ideally, I'm pretty open for all your suggestions.

**Ray | 13:26**
Okay, all right, Robert, could we start with you? Do you have thoughts clarifying questions you might want to ask?

**Robert | 13:33**
I was just trying to click as a clarifying question, like, just to put it in and in a nutshell, like you're wondering about, like, what is a good? We just put together a presentation. I don't want to finish your words necessarily for you, but, if you don't mind those likes, you know, encapsulating it that way.

**Ray | 13:53**
Yeah.

**dimitris@3nuggets.io | 13:54**
I'm we talked yesterday about the Digital Twin thing and how. And you gave me a nice idea to create a product where people can test it as an experience. Because it's quite challenging to explain to someone what is digital twin and how it can be useful for their business so it's worth it to be an investment for their business. 
And from the conversation, I thought about, okay, why not to have a place where they can go and upload the transcripts? Because the digital twins will use transcripts. And from there I ran the analysis to create their knowledge base. Ray recommended yesterday give them the knowledge graph as a graph because it is viewable, it's understandable, it can make some impressions. 
And after that, let them test it so I can take the output, give it to them and say, okay, now we can give it the test. And I when I start using it, I have to think how to guide them in using it. Okay, definitely. We're just brainstorming now. 
And my question is how could this thing be developed? Not from the technical staff as an experience as a the user journey is where I'm struggling.

**Robert | 15:24**
The user journey. This is tough because, like, it's kind of hard to it's a tough one because there's so many different ways. I think it kind of depends on, like, what they how are they consuming it. I feel like some part of it comes from your experience of the like, what's the starting point of the process itself? 
I mean, I can think it's a lot of the time, like, if I think about like, what does that user experience look like? It's very closely tied to the design of the technology and everything and like maybe just even just working backwards from like what they need ultimately. 
Like, I'm happy to brain I'm happy I'm I probably have a I'm over I'm probably over through the ASIC to brainstorm like potential solutions. So, like, I could easily very much jump into it, but I want to just be sure that, you know, that it's useful. 
So I guess. I suppose maybe what comes to mind for me is, are you looking for are you. Are you looking for. Basically. Like. What angle to even get into it from or do you already have that or are you already fixed on a particular angle? 
And like the first, you know, few steps that you've put together. I just I'm kind of trying to get an idea of, like, what are you committed to in your mind, of, like, how you've already picture it.

**dimitris@3nuggets.io | 16:57**
Yeah. Web. Okay, so let me put two questions. How can I make a quick demo and what I want to achieve with this goal? Okay. To build a quick demo, I need a couple of information for their business, their scope, what they want to achieve for building this mental model. 
So I need the conversation with them to put those questions with them and use the input, and then I need their objects of transcripts to be processed and analyzed in order to cover their own goal. Discussed in the previous states. This is what they need and the purpose is. After the process, they will have a way to first view the output with visualizations and second test it. This can be a chatting experience, it doesn't matter about the stock, but I'm talking about the experience. Should it be a chat, an experience, or, could it be something else? 
So, you know.

**Robert | 18:14**
I just think, yeah, I would say. And this is again, like, I don't know how powerful this will necessarily be. I'm probably. And this is again, like it's kind of dangerous to ask me this question because I think that I'm going to end up maybe just even trying to amuse myself with all the stuff that I think about because there's stuff that I am interested in, but that's not necessarily what your customers are interested in. So's that Asterix that comes with it. 
But that being said, I would say if you're asking me, like, what's if I was in your shoes, like, how would I approach that market? And like, if I was wanting to capture that person's interest and try to put together something for them, it would. I would probably try to position myself in general as like a rag expert. Basically that would be the real problem that I'm solving and I would be working on solutions that because there's a lot there's very deep well that you can go into when it comes to reg not just even in technology stuff, but there's so many other things that it connects to. 
And even I find myself very interested in this topic as well. Like I have found myself coming back to it and looking at the technology behind it and like. And it's really not a lot of it is like once you've you know, it's reassuring in a lot of ways because the technology itself is like it's the fundamentals don't change. 
I have found. And so I would look towards something to solve a problem in that area in a very convenient way. What does that look like? Maybe that looks like a very disposable vector graph of sorts, like to put together. 
Okay, here's like a repo of information. What can we do with maintaining memory across different conversations? Can it be seamless between different conversations? Is there a way that I could, you know, provide a three step, you know, process? 
And again, for me, I think that this would capture my attion if something were put in front of me that said, hey, like if you just upload your information here to this X repository. I think of, like, the entity from, like, Mission Impossible. I don't know if you've seen the latest one or something, but like, the entity. 
And I just think about how this like you could probably talk to the entity from different places and it would just continue the conversation perfectly from wherever you had that initial conversation from. 
So I mean, to me, that sounds like I like to pick up stuff that you know and aim for things that are going to be a little bit interesting to lease discuss and maybe a little bit challenging on how to. In terms of getting there but maybe not too challenging, but. 
So I don't know. That's where my mind goes to in terms of like, it kind of. I feel like it lines up with some of the amount of stuff you mentioned about, like, digital twin and things like that, because, I mean, I think a twin at the end of the day is going to be based on memory. 
And if I'm trying to speak to a person. Like if I speak to Ray right now and we're having this conversation here. And if I went and I picked up then if I picked up the phone and I called up, ran another phone. 
If we would continue speaking, he would be aware that we're having a conversation in two different places. I suppose what I mean and I kind of think about, like, is that what a digital twin? Is there something there? Is there something seamless that can be brought to life, right? Is that something that makes people say, wow, is it useful, is it not, is it something that can be put to a demo? 
So again, I'm dangerous when I start to go about, like, you know, some of my the things that I think about sometimes. Maybe it's too big of a problem. Maybe it's useless problem. I'm not sure, but just as long as we're talking about ideas, that's some stuff that comes to mind.

**dimitris@3nuggets.io | 21:59**
Thanks. You gave a really good point here. It help me to understand that I should go one step back and think about w which are the questions, the things I have to put into the conversation with them to build something that will be that useful. They will want just to improve it to make it even more useful to them, so. Which means they can convert.

**Robert | 22:25**
Yeah, like, something really cool is, at the very least, is what I find to be, something that drives conversation. And it's. You know, I don't want to get too long winded with it, but happy to talk about it more if you want to talk about it from like a technical point of view, because I've explored some of this stuff too.

**dimitris@3nuggets.io | 22:50**
Hmmmmm.

**Ray | 22:51**
Thanks. For. Surely what thought do you have?

**Ellie Rofe | 23:03**
I might. We were a little way into our call like quite a way into our call when we talked about this. So I may not have been as clear. In the feedback. I think my question about the product is if it's a bit early to be building a sort of demo, for a couple of reasons. 1II do slightly worry about how you're going to show enough value with a few transcripts that people will see a material difference to having a Project Claude or, something that is, you know, similar. I can absolutely see if they can see a knowledge graph, but I don't know if that will translate to people going, I know how this is going to solve my business problems. I wonder whether that is something you build after you've delivered five to six digital twins and you know, where people are getting stuck, what they really love, what feels really exciting, what use cases they're using it for. We discussed earlier, like there were some really interesting ideas you had around, you know, making yourself a better consultant using this as like a perpetual education engine for you and your business. This kind of like compounding level of value that happens because you're capturing so much insight from your work. You do with quiet clients from transcripts, from content, from everything. 
And if you have some really interesting early you know, case studies where people are taking it and pushing it to edge cases and doing really interesting stuff with it, then I think a it will be much easier to talk about the value anyway because you'll have living use cases. You'll have examples of what people have done with it in a sort of tangible business way, rather than what is a digital twin in a sort of technological sense. 
But I just it feels and I say this just because I am, well, not even a fellow traveler. I am a previous ahead of you traveler in spending hours into something that's a demo that as I then made contact more with the market was a lot of it was just wrong because I hadn't been in contact enough with the people that were really gonna be using it.

**dimitris@3nuggets.io | 25:47**
Totally clear that from the conversation I call the word I use the word product. Well, actually, the purposes build a lead magnet where they can have an experience of testing the final approach. 
Because this is it.

**Ellie Rofe | 26:08**
Okay.

**dimitris@3nuggets.io | 26:08**
To create the experience.

**Ray | 26:09**
Yeah.

**Ellie Rofe | 26:10**
I think what might be really a slightly like a lighter lift upfront and something that might be more marketing. E is an a self serve assessment and it depends how reverse psychology you want to be or otherwise you could have. Is your how much time could you free up by having a digital twin? 
And talk about how much time they spend in client calls, how much time they spend on dealing with customer queries, et cetera. That's the sort of pragmatic one. Or you could have. How is your business clever enough for a digital twin? 
And have it so that it's like do you have enough IP knowledge methodology, you know, the ontology basically to create an ontology of a digital twin. And it sort of filters out people who aren't really ready for you, but people who are clever enough will be like, wow, what could I do with this? 
And I think maybe that's an earlier stage version of a lead magnet where. And again, it depends on the framing, but that might be an earlier stage version of it, so that you don't have to do the big lift of trying to build something, especially when you don't quite know the use cases yet. 
And, you know, it's not clear that you'll be able to deliver responses from the AI based on it. That would actually go, I get it now. Because there's not enough context, maybe, for there to be a big enough difference.

**Ray | 27:44**
One.

**Ellie Rofe | 27:46**
I don't know, I might just be giving too much of a sort of marketing brain answer. 
And there are some really much cleverer technological areas there that I don't understand. Excuse me, sorrym.

**Ray | 28:05**
Well, could we turn that back to you then, Robert, what you're seeing on the technology side of opportunities what as talking about or.

**Robert | 28:12**
Yeah, I think that. Yeah. No, I was just going to say that I think, like, in general, a lot of the stuff is, you know, people. It will ultimately, I think, come back to boring problems or like, problems that we don't. We just look at them and they just look like we don't necessarily expect that what we're working on will maybe apply to it. 
It's not like our intention, but we're just trying to. I mean, for me at least, I try to show something that's, worth talking about and just shows that I have. I'm really deep into AI and that I can get stuff done that's interesting and that people haven't, you know, been able to do before. 
And then a lot of the time, they will come and present something that, you know, they'll put down in front of me. And it's not exactly the same shape as what I'm working on a lot of the time, but I can look at it from different angles that pick it up and like, look at it. 
And then if I don't want it, I can put it back across the table at them. And then they can. And then. And then they can look at it, and then they can put it back to me. And then, you know, we can figure out if this is something we can work together on, like, for example, I'm working on like all this stuff with, like, you know, on Xano and like, AI development. 
And I'm thinking of it in one way, like, I want to build stuff. And then somebody will come and then they'll say, well, we want you to refactor our whole messy Zeno database. And then I just think, well, okay, well, you know, I'll look at it, and then I'll figure out, like, I think I could probably do that. 
And then it's not what I had meant, you know, intended. It's not what I really aimed for. But it revealed itself that, you know, the real value was not. Well, there is value, but in different areas. But the one that we're people right now putting up their hands for is the people who have a messy spaces and then they want to help with that's, you know, something. 
And it actually points towards the fact that they have something that already exists, which is, you know, a good quality to have in a prospect. So those. I just think that the market will reveal itself. 
It's hard for me to say what exactly that would be in the case of what you're speaking, but. I mean, like, for example, if you were just talking about digital twins, it means we can presume that you would be knowledgeable about Reg and everything like that. 
And maybe somebody would come and they have problem that's somewhere in that area where they want to discuss. Well, I have the system, and I have all these files and everything's a mess, and I wanted. I need to use rag systems. 
And you're good with the digital twin stuff. Doesn't that use rag? You know, like, can you help me? I think that's maybe that's where opportunities start to look like. And I think again, like it just maybe. 
So the message to put it out there in order to just bring up those types of conversations is just the fact that you work with Reg and Digital Twins in general and just keep demonstrating that in as many ways as possible. 
And if you can demonstrate that with lead magnet, the great. If you can demonstrate that with, you know, in any way, you can demonstrate that in a convincing way to build trust is. I think. I think is positive. 
But like what does that look like in terms of, you know, how does it manifest itself in terms of like as a job. And I think that's mostly the market to generate that. I would just say that from everything you're discussing, it seems like again that there is, you know, an underlying like there's digital twins. 
And then there's reg there's I feel like there is more that you could more ways you could attack this topic, and make it relevant to the real problems that are out there so that those people who are that are in AI, that are not even in that are aware of AI, they can recognize it in your post. 
So they can see that you are working on something that even if it's not exactly a digital twin. But they can. But they hear certain words and they see certain angles that. That they can connect the dots themselves and put you in their mind as a solution to their problem. 
Like figure, like, put it on them to figure out where you fit. But yeah, just some.

**dimitris@3nuggets.io | 32:33**
Thoughtsm good point.

**Ray | 32:40**
There are a couple of things I just want to highlight from what Robert just said, which I thought was some really insightful stuff. One is this idea of people who have stuff, right? And people who have assets because people who have stuff are able to pay for tough. People who don't have stuff are often not able to pay for tough. 
And I think everyone in this room has experienced the phenomenon of working with these people who have, you know, these glorious Greenfield ideas. And no money, right? And if you're in the professional services business, you want to provide good professional services, but you can only do it for people who can afford to pay you. 
So the one of the neat things about like the whole knowledge graph thing and the way you've been approaching, you know, these bits, right, is this idea of like what do you have that's useful for people who have assets, right? To be able to get better value out of those assets as opposed to people who are completely Greenfield, right? 
Like, I want to go build an app. Delightful. But zero to one. One of the neat things about like the work that you've been doing is that it's analysis is getting value out of an information asset that a company might have or that a person might have, and that means that they have something that they know is a value and you're helping them realize that value. 
And I think there's a lot to that. The second thing I wanted to raise from what Robert was just talking about is that Digital Twin isn't a product, it's a theme. Right? And so it forms sort of a zone around which sort of some connective storytelling tissue for, like you covering a number of different topics that can be useful to people. 
And the knowledge graph stuff, something you've hit now a few times in these meetings, I think there's some uptake for it certainly isn't. It's a thing that's hard, right? And it's one aspect of this DT stuff. You might ask, what are other aspects? 
Right? Not to suggest that you need to be abandoning the knowledge graph stuff. I think there's definitely some juice in there, right? But as you think about the theme, what are the other pieces? When we think about like digital twin technology that matter that you might want to then have a me of about or whatever to be gaging where the appetite is right because that will help you get a feel for where there's stronger pull in the market as well as your own comfort for delivery. 
And I think when I hear about, like, building a product, the thing I think is most useful for product, as I've sort of said before about like, snappy, is that products are, you know, initially just study, right? They don't make you money. 
So that means the job to be done is study like. So like, how does it create value for you in a study context, and then later it can be helpful for you in a cell context, which is kind of the way he's using Stappy now, right? Me and is helpful to him in his shipping right because he's developed something tool for himself, which I think from nature work you're doing is sort of potentially really interesting. Road are those two ideas, you know that the idea of like, you know, one of the, you know, people who have things right? 
And what aspects of your offer are going to be appealing to people who have stuff versus people who don't have stuff? Because then you're talking to the right people. People can actually afford to hire you and you want to be talking about their problems like, hey, here's how you can create this thing from scratch. Delightful. Is that people who are. Who are going to be. 
You know who you're excited to? Is that the lake? You wants women, right? And the second is this idea of just being a little more thematic about it, which just gives you permission to sort of move around. 
Because in each of these meetings I've been in, you have covered a number of different technologies and ideas, and you don't have to cover all them every time. It's not like the whole of it has to be the meeting, right? You can be picking one or another that you find to be of greater interest and then be using that to gage where the market appetite is. 
It's one of the reasons I encourage having more frequent meetups is because it gives you more bites of the apple in a shorter period of time to find that. You know what like Alex Smos talks about, right? The hungry crowd, right? 
And like to be at the place where we crowd is that really sort of that market moment. And it seems like the knowledge graph has some, you know, bite to it, right? And is a nice quality of being hard, being visible, being applicable. 
But, you know, I would. I think it's just like one thing. So like can we compare that with something else too? And that's I think where Robert coming in of like adding these other things are sort of under the theme, right? You don't get to have. You don't have to go, like, rename the whole thing or to be able to take advantage of that. Just say, what's what else is in the zone? 
Yeah. And actually, I kind of like the idea like you're building insofar as it's helpful for the first fifteen minutes of your meetup, right? Trying to build a product. Then they would just be able to buy and go cross supply themselves. 
Because if you demoed it right? Hey, I built this for myself. Or built this, you know, to show you how to do X. It's sure it sets you up for the logical next step of that. Sounds great. Can I get that? 
And that's a statement from the hungry crowd, of which some will be looking to pay. Lots of people show up at the hungry crowd. They're like, I like a hot dog and I don't want to pay any money, right? 
And some people won't pay, like, a little bit of money, but some. And that's the idea, like, you don't have a big enough hungry crowd that some are really starving, right? And those people who like hire Robert and hire you. 
I think when you sort of step back and look at like your you know, the spectrum of customers, there are lots of people who are like, you know, there are lots of freeloaders in the world. That's the way it is. Lots of people who have interests and sort of notd along and a few people who jump up and say, I absolutely need this. You show me the way. Can you take me there?

**Robert | 38:44**
Yeah, I think it's. Sorry, I was just gonna say. I think it's helpful to be like just again, like solve it for yourself. And it's good to just use the meetings as AI have to say that like I think when I really think back to the first meetings that I was holding, that the thought that was coming into my mind is how good it was for product feedback and for knowing. 
And forget all those signs like Product market fit. Because at that time, it wasn't like the snappy tool had issues. There was a lot of stuff that I had actually rapidly done to the tool that only started once the meeting started happening. 
And it's just like if probably if I was able to look back and look at the graph of like, you know, how much did it evolve before I started doing those meetings and after I think it rapidly reoriented itself and moved straight towards what would be useful for people. 
So it's kind of. I think that for me, I would just say that like if anything like if I'm feeling like I don't know what to develop or I don't know what problem to solve. I think that the job of the meetings this is there for to provide information for me to read between the lines and see in tests in real time. 
Like, what is it that would resonate with people because they're there right in front of you? And like, I think on a certain. And at least for me, I found that, actually, this was something. I would say that like, probably some of the biggest breakthroughs that I had was moments where I would kind of actually it's soundly counterintuitive, but moments where I would give up and I would just totally give up on doing it a certain way, and I would just say, I am not doing it this way anymore. I'm going to just literally just do with the way Ray told me to do it, and I'm just going to give it a hundred percent chance. 
Honestly, now I'm gonna raise. Saying like, raise is like, you know, I'm not joking like some of I can say, like probably there was three pivotal points in the development of the product that directly came from Ray's advice. 
Like, you know, saying, okay, just use Claude Flare. And that immediately took me from being stuck on something to just letting go and saying, I don't know anything about CLAU for I don't know anything about it, but I know I've been doing this thing for two weeks and this thing is kind of mysterious. Within a day, I had my problem solved. 
If I had. You know. Just because of that advice and then raise advice to, you know, again from during a meeting, somebody during the meeting had. We were discussing trust and everything. He didn't say it exactly, but. 
But reading between the lines Ray had mentioned should probably focus on trust. I then did focus on the trust. And that came in the form of the technology to work backwards towards that was that, you know, was developing ways for the tool to be protected. Just in terms of like not anything to do with AI like or anything to but just in terms of like, OAT protection and that type of stuff. 
Like just to keep it in the same workspace. It's it has nothing to do with AI, but it ends up being one of the when I have the calls, my most recent calls with people who are really big business owners, that's the one that's the first thing they want to talk about is the security of it. In that moment, I'm just thinking, thank God I listened to Ray, because otherwise I'd be sitting here with no answer to this question at all. 
And like, I'm so happy when he starts talking about security. It's like, how can I trust this thing? I'm like, wow, my friend. Like, you know, let me just take you on this tour here of this thing, of this exact thing that I made that, you know, addresses and. 
And to say that, like, where did this come from? It came from really. You know, for all the ruminating that I did and trying to figure out, like, what am I going to build? And all this stuff, it came from listening more than anything and just. 
And you know, and then and just being willing to just change direction and give something a shot. And yeah, I would just say that. So a lot of the time, like anything that I've done with the product really came from. 
And I would add just one more thing that a lot of people have advice. It probably good to choose who you listen to advice from to. I would just say that I would bring up Ray. Because. Ray. You have to choose people who you trust, right? 
And like, a lot of people will give me advice, and then a lot of advice is really craped. And so you'd have to just choose, like, who do you trust? Who would you trust when it comes to, like, giving maybe product advice? 
And again, you know, you. There's a different answer, maybe for every person, but for me, recognizing that has been only to my benefit. And I feel like I've made better product since. 
Yeah.

**dimitris@3nuggets.io | 44:02**
I understand how critical it is to select the right people to talk with, drink coffee and ask for suggestions and all this thing. Now, from the terms, we're at the same time as a folk. I'm looking for chickens. I appreciate the suggestions from you guys. These are very thoughtful. The thing is, how can I apply these things to make something that is attractive for a chicken? 
Because ideally, the end users should be chickens, which is a prospect.

**Robert | 44:52**
Yeah, I mean, if it were me, I would. And I wanted to show this to somebody again. Like again probably take for granted the fact that I already know Xano and everything, but I would build up something the Shareable and Zeno. 
I think I've already done that before with Rag too. And then I would just, you know, say, hey, here's this thing. It's on Xano. It's shareable. And like, you know, I would look for that version of it. It looks like for you, what is this shareable thing? For me with this, like with the snappy tool for example. This is one of the reasons why I made it was so that I can build up demos really quickly. 
So whatever that looks like for you. But I would just say that for me, I would. I would put together a demo, something shareable that helps people's problems, and even if they don't use it just at least demonstrates I can put together something like that. 
And then I would put it onto the market. And then the question is like, okay, so what does that look like in terms of something? A shareable version of it? I bring up Xana because they you can make snippets and has a local platform. 
Maybe there's a version of it you could build. Air table or something. But you know, and then go that the answer to that might be on the Internet maybe just, you know, Google. And let's just look up and see, like, is there other versions? 
Like how can you package something like this and, you know, how can you dissect it? Can you make it very clear exactly how it works and all those things thats I would get very scrappy with it and. And, yeah, kind of put a gun to my own head, basically. 
And just like then say, like, I'm like, you know, one, one way or another. I'm putting something out here. And. And I don't know how yet exactly, but I'm going to just, like, you know, search like a rat until I find it.

**Ray | 46:45**
Kli op you into the conversation.

**Ellie Rofe | 46:53**
I think it always just comes back for me to just speaking like just working with the user with the people that you need to deliver to. Is there any. You mentioned a sports club a while back, your athletics club, I think, and potentially doing a project with them did that. Did that progress any further at all?

**dimitris@3nuggets.io | 47:18**
No, it doesn't actually make any progress. And the reason for that is that because we live in different cities and there's not enough engagement with technology from all members to join and run it and build it.

**Ellie Rofe | 47:35**
One.

**dimitris@3nuggets.io | 47:38**
And the expectations from the coach I started talking about it are not clear and not in the same direction. And I didn't meet him two months now in person to discuss it. And we all time say. Okay. When you come back in the city. Let's schedule an appointment. 
And, you know, a reschedule.

**Ellie Rofe | 48:01**
Yeah, okay.

**dimitris@3nuggets.io | 48:01**
To reschedule.

**Ellie Rofe | 48:04**
I'm just wondering if there is a way you can bill with an with a client. I just think for me delivering something answers so many more questions than the sort of more speculative stuff which is obviously really crucial. I'm not denying that because it's studying it. You learn from that as well. 
But I just find my learn rate goes up massively as soon as I start delivering something.

**dimitris@3nuggets.io | 48:35**
You know what? Let's look on what I already have. I have the cris do, nose graph. How can I, put it in use? For me is a question I have to answer.

**Robert | 48:54**
I think that could I just posit something that how can other people use it good, right?

**Ellie Rofe | 49:01**
You just sent it to Krista.

**Robert | 49:03**
How can I use it like, that's what I'm just wondering. Sorry, Jim. TB I just want to say, like it's not so much about how you. 
But how can I like, how can other people use it? Right. Because if you're wondering about how you can use it, you're just wondering how can you use it to turn the wheel for your business. But really the. 
And like that's all downstream I think of how can if I can use it then if other people can use it, then your the business the wheel for your business will turn. But yeah. And so I would just really stay ruthlessly focused on. 
I mean, at least for me, like on just what is really going to make somebody die to use this, like I. And it's a tough thing to and for. But. Hey, you know what? What else can we really aim for? I'm not really sure there.

**Ray | 49:50**
There's something very interesting there, in fact. I agree. Some might treat that as half as Robert having half volunteered for the, you know, the experiment. How does Robert make use of Cro's knowledge graph? 
But Ellie, I think you had different angle that you were about to talk about that. I think it's if I think you're grown more thing ground think it sounds pretty cool.

**Ellie Rofe | 50:09**
I just thought how you sent it to Cris Doe himself. Have you said I'm a big fan of yours? And I made this because he's like a he likes innovation, he likes new things, and he likes his own content, you know, he does. 
So he could be really receptive. I'm happy to test it, by the way, as well.

**Robert | 50:37**
Yeah. Or hey, how cris brain there's I was just to say that like I've seen these posts now, but like Alex Formosi, for example, where people would say it costs $90000 an hour to speak to Alex Formosi. It. 
And then that's the first line of the post, right? And it's like, Whoa, it costs ninety thousand dollars an hour. You can talk to him for free if you talk to my digital, you know, here's a digital twin link and so on. 
So that's what something that is usable. There is a hook there as well. You could probably take that and apply it to a whole bunch of people in different areas, you know, to reach that entire crowd of people to follow this person. 
So it goes. Gives you a license to actually go into. To even talk about these people into in a soft marketing angle, I would say which is education like, you know the idea of sharing.

**Ray | 51:27**
Yeah, you don't want to necessarily go around sending people the knowledge graph. But I think having a meeting where, like, he's where Robert's putting it into use. I think that's like event based stuff feels a combination of legit, right? You're not eating into Cro's, you know, gig. 
It's showing off your good stuff. People get to learn both the branding marketing stuff from DOE as well as the being' see the graph action for you. I've seen that. I think that whole thing could be really compelling content and. 
And put you in exactly the right position of being the expert, right? You're the conveyor of all this. And like, hey, if this is cool, wouldn't you have to have one for you, right? Like that becomes where the big value is being able to have that, you know, that second brain going on. 
I think there's a lot to that. I love the idea of saying it to Doe. I love the because I thought that's where I thought you were going early and the and getting Doe to comment on it. But you can just him making a YouTube videos saying, yeah, you know, this weird guy from Greece sent me this, you know, made a knowledge graph of my stuff from YouTube, and it's so cool. 
You know, he might decide that he wants to post it or something. Or do something with you. He might decide make a little bit of content. He might do nothing at all. Your worst case scenario is nowhere. 
I mean, I suppose your worst case scenario, he send you a seasoned cease letter, but that that's really not terrible either. You know, you can say, hey, Chris, a letter or actually his lurks letter.

**Robert | 52:54**
Any content exactly. You can't lose. Really? What? That.

**Ellie Rofe | 52:58**
No good that it threatened him. It was so good of Cris Day. You could actually you could genuinely, [Laughter] you could actually do that with a number of people who might not have.

**Ray | 53:05**
That'sing.

**Ellie Rofe | 53:13**
Like Alex Homosi has a ton of super fans, so he's like. 
And I totally agree with you, Robert. Like they are cashing in on his reputation, his fandom. But there won't be a level of creator that doesn't have a ton of super fans and is still really self promotional and would be very flattered by it. 
And it would give them some content to create to talk about how someone did that for them. Like if someone said, I love your content so much that I made this that, you know, just to try and get more expertise out you. Just to try and be able to talk to you because I can't afford you. I'd be like, Wow, that's. 
I mean, you know, some people won't be flattered.

**Robert | 54:00**
Yeah, and I would just say that that's probably something that I don't think of things that way, like I should probably think more things that way of like. So, yeah, just just saying that like I feel that, like Rain Kli probably, yeah, just touched on something that I probably underestimate how much that could help if it paid off, right? 
So you know, you already have everything. Who knows, right? Like if you were to take a chance like that, I feel like it's I don't I feel like it's loaded dice. I feel like that you have a higher probability of it working out. 
It's not totally random. It's like you are actually stacking the odds on in your favor for something like that to work out. You know, it's not the same as if it's not just like a random event. It's like you have a higher. You are crafting something that he is likely to or has a higher probability to respond to because of the nature of what you're building.

**dimitris@3nuggets.io | 55:03**
Very interesting approach to this. To be honest, guys, I would. I really hesitate to talk about this. Concept and idea in public because I'm really scared of, you know, cris those, reaction the negative reaction like, hey, I will send you my lawyer and I'm going to, you know, all of these things.

**Robert | 55:30**
Are gonna that's never. I mean, I feel like this just reminds me of, like, what Ray told said once. Like that both of these things cannot be true at once. That you're afraid, like that he's not going to answer. 
And that he might send you that. You know, he might send you a cease and Desist. Both of those things can't be true at once. So I feel like if he ends up sending you a cease and Desist, that's amazing. 
Like. That's like a post. I would like put that on your LinkedIn banner. Like that cease and Desist like that's how good I am making twins so literally they're suing me to make me stop.

**Ellie Rofe | 56:04**
Yeah.

**Robert | 56:04**
So I would pray for that Seaeason Desist personally [Laughter] honestly.

**Ellie Rofe | 56:10**
[Laughter].

**Ray | 56:13**
And there's aspect of this and you know what doe would understand, right? That, you know, to market yourself requires some elbows. You know, you gotta go get noticed and the if the big fear is. No, I might get notice that that's an indication that it's a good thing. 
You know, and I'm not saying you do all the possible things to get nose, because, you know, obviously there are things that they're necessarily self Destructive, but things are just edgy. And if you want to be at the edge of technology, then, you know, you need to, you know, send up the signals, right? 
And it's a little bit more of a you know, you're it's a more intensive audience, which makes them more likely to buy real things, but that smaller, more intensive audience than for a response to intensity. 
So how can you be giving some of that? When you think about, like, the books behind you, right? You think about, like, what Annie Duke did, right, in poker. You think about, like, what? I forget the guy, the unreasonable hospitality guy, right? 
Like the way he approached things. You think what Roy Sutherland does right over Dolaby. You know, these are people who have, like, you know, controversial ideas and they put them out there and they share them in controversial ways to get attention. 
And I think that that's kind of what you're looking for here. That's the cell part is gang some gain some attention. I think you've got some really good material. You know, let's let let's get out there. 
And don't lose the plot. They may have just been distracting you, but don't lose the plot. On the fact that Ellie and Rob had kind of volunteered for the, you know, how to get more value from the cris do thing. 
Because I think that, you know, the question like, how do I make it digital print? How do I make a knowledge graph? What do I do with a knowledge graph? Once I have one? You can, you know, instead of being just you talking about because you're a little bit stuck inside the building mindset of it, right? Bring other people who are smart, inarticulate and friendly to you to do it. 
And nobody cares that you already know these people from their contexts. They will assume that anybody you bring in is a plant, right? So, you know, have a good time with your friends. Yeah.

**dimitris@3nuggets.io | 58:22**
Good very good conversation, guys. Really appreciate it, honestly.

**Ray | 58:30**
Tic thank you all so much. We'll be talking in the end of the week. And we will do this again next week. Thank you all. Bye. Bye. Thank.

