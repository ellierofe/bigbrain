# Ellie and Ray Zoom - Jan, 09

# Transcript
**Ray | 00:08**
Nelly, I'm so sorry about yesterday afternoon.

**Ellie Rofe | 00:11**
Don't worry. I did it last Friday. These things happen.

**Ray | 00:18**
Yeah, my... Was so sweet. He said, "Daddy, I think you should take a nap after I said, "Okay, well, I've got another call. Okay, Tom, where'd my phone go?" Well, it was buzzing. Daddy didn't want to wake you up. [Laughter] It was...

**Ellie Rofe | 00:35**
I like it. He's taking care of your health, first and foremost.

**Ray | 00:41**
It was very sweet because my wife took my other son on a five-mile skating loop. She's from North Dakota, which is cold and flat here in the US and the...
So she grew up skating because hockey is their big sport there. She's gotten both my sons into skating as well, but one of them more than the other. He was looking for that big loop where he could just rip it open.
He did, and he had a really good time, and I was with my other boy, and we were going to go skiing together. He said, "Well, how about... Did you take them out first and went right through your call?"

**Ellie Rofe | 01:14**
[Laughter] Yes, me too.

**Ray | 01:14**
So. Anyway. I'm. I'm glad we get talked today. So. So it's been a few weeks.

**Ellie Rofe | 01:28**
Yes, [Laughter] between everything, I'm all right.

**Ray | 01:31**
Yeah. How are you? Done?

**Ellie Rofe | 01:36**
Yeah, I'm, wow, my I'm motoring. Generally, today has been, just a bit frustrating. But actually, broadly speaking. I think having got Maddie's deck over the line through illness, like, it was just a it was a really good project, but in a sort of grimy, situation, which was annoying. I then I started speaking with Justina again every morning, which is really helping.

**Ray | 02:09**
17.

**Ellie Rofe | 02:13**
And it's fascinating to watch the. So the other day, I can't remember...
I was going to do the website and LinkedIn, set up a template for carousels, and write seven posts and do the website. I said to her, "I've put way too many tasks on here, but I'm just going to do an experiment because this is what I always used to do, but I never tracked what I was doing."

**Ray | 02:38**
He.

**Ellie Rofe | 02:41**
I just did it and then had this never-ending line of tasks.
It was fascinating psychologically. My brain was just going for half the morning, and I ended up working till 04:00 am to try and get things done before the next call with Justina. I was like, "Okay."
It is interesting to focus the mind to say, "Wow, I've taken on too much, and I have to get this done and kick in that deadline spirit, but to learn how some creative or marketing tasks just take a bit of time."
To realize how much I need to be realistic about what I can do in a day to keep the wheel turning and keep momentum going. So it's not mind-blowing stuff, but it is useful. It's an experiential understanding of what I knew intellectually.
Then it means that I have pushed the website live. It's not perfect, but it's better than it was. I have pushed out content on LinkedIn that isn't perfect, but it's getting better than it was.
It's just a case of constantly pushing through and experimenting, just trying to be there in the market, talking to people, and trying to have an opinion. I think one of the things that are interesting for me is I feel like I go through highs and lows of, "Do I have anything interesting to say at all?"
Sometimes, having this... What is the point of saying this? And at that slightly almost nihilistic teenager level, thing about it. I think some of that does come from imposter syndrome, and some of it comes from just being slightly novelty-seeking and realizing that I have to just repeat messages a bit.
But I'm still broadly finding that positive, and trying to keep momentum there. As I said, I'm going to try. I think quality is really key on LinkedIn at the moment. It's people are talking about the algorithm and stuff, but I think if you're producing something that can stand out and be differentiated by the fact that it's clearly not AI and that it has a point of view and that there is something useful in it, then it should stand out a bit.
I think I do need to... So I have the experience yesterday with the pitch assessment tool was really interesting. I have been thinking about this. There's been an underlying question in my brain as I've been doing this pitch repository assessment thing, which is what is the point of nihilism of doing analysis of pitch decks that got funded when you don't know the overall story of that process because the pitch is just such a small part of it?
Expansio really crystallized that for me. Which was like, "Expansio, sorry, I might have just added that too, recently, if you'd have seen in the thing."

**Ray | 06:10**
Good. Help me out.

**Ellie Rofe | 06:16**
So I put a deck through for Expansio, which is basically contact lenses that do what a smartphone does, and it is... The tool returned...

**Ray | 06:17**
Okay.

**Ellie Rofe | 06:34**
This is not investable. Which is hilarious, because I not. I told it not to do stuff like that, but it was like, this is not investable.
And, because there was no it was all hot air. There was no proof of concept. There was no clarity on how they were going to overcome the massive scientific hurdles to it as well as the regulatory hurdles of putting electronics on people's eyes. [Laughter]
Yeah, but it was out of Dubai.

**Ray | 07:03**
Details.

**Ellie Rofe | 07:09**
It's one of the top five optics teams in the world. It's people with experience. They got sovereign wealth funds in Asia to invest in it. And that seed deck raised $40 million and their Series A raised $250 million last summer.
So the not investable thing is... I guess what was interesting to me is what I'm trying to achieve. Because the deep dive analysis of a deck that's raised money is a bit pointless because the deck itself is just part of the story.
Then I think if I can get enough decks into it that there is cohort-level trends and information like Carter would do for funding or something, then I think that's an interesting point of view.
I know DocuSign does that a bit, but it's more... And things... But as it stands, this crystallized what I've been thinking. Yes, I can absolutely adjust the prompts to consider that this is a moonshot, and moonshots get funded in different ways for different reasons, and the vast majority of funding that goes into companies...
But what am I actually trying to achieve here in terms of how this helps me? Now, I don't think... I think there is something there. I just can't quite put my finger on what it is, even if it's just that lesson.
I think the beauty of having pushed through yesterday and not faffing around... This is the meta lesson. I need to find out these things sooner, faster, rather than trying to perfect things.
Yeah, I don't know. It's been an interesting process. I'm tactically... Yes, I think it's useful to talk about this. And maybe it's useful not so much for the picture repository as a data asset now, but as something I can keep building to become something very useful and talk about in terms of people just getting decks in there and understanding the story of those decks.
I think one of the more interesting things is a robustness analysis of decks that are yet to raise. I think that is probably where the bigger value is. It's not saying, "Is this investable or not?"
It's saying, "VCS uses AI to read decks." AI is a blunt tool. So this 200, and this thing that's raised $290,000,000. AI tools could well have said no, so off to it because they're blunt tools.
So is your deck because it stands robust enough to get through what the VCS AI is going to do and in this funding environment in hard tech? I think that's possibly more of an interesting leverage point than just having talked about the repository as it stands and that just being a very incomplete and slightly useless set of data at the moment or one-eyed at least.

**Ray | 10:11**
2.
No.

**Ellie Rofe | 10:25**
So that was really interesting, I think. And it sort of brought me back around to the idea that I do. And it's going to be cold outreach at first, but I do just need to start talking with VCS and try and get connections and try and build into them somehow so that I can start getting to that side of the table, getting inside or information on that side of the table.
And connections and. And, you know, potential deal flow.

**Ray | 10:55**
I think that the observatory is fine for you to share, but it's more valuable if it shows that you're paying attention to the market, right? You collect these things because this is how you work on your expertise. That establishing you as an expert is far more interesting.
Then the analysis, the AI analysis it does on it. I think you observing that naive AI. I think the story you just told me is a delightful story about your expertise because it's about how the AI said X, but you know really why.
This is why things are a little more subtle, and we should be thoughtful about that. Of course, you don't need to say it. But that's the reason to hire you, right? Your expertise is at that level of salty because you should totally throw this into ChatGPT, but don't take it at face value. Let me tell you a story. I threw this thing into ChatGPT. It said it's not investable. They raised $40 billion, the most recently raised, nine figures, and blah.
That's I think that like you're saying, what's the value of the repository? I mean, it's not something you're going to be... Maybe it's something you can directly sell, but it's mostly just a signal, right? That you are paying attention and that you are serious about this in a market full of people who are faffing around, right to use your term. The and like you, you come at this with intelligence, like your point about robustness.
I think that's a really good point. There's a... When you think about this, you have to think about how it's going to get through the AI filter on the BC side. But the thing you said at the beginning, I think is so important, which is that quality will out.
The same thing is true. Sure, you can go shitpost your way into a couple of viral things on any of the social networks, but if you want to be building trusting relationships with people who actually do business with you, quality is the way to do it.
That's always been your focus. I always thought that yours was really good, and the. And like, you we talked about how that just gets reflected in the deck, right? But then what does quality mean?
Right? And quality means being able to be a bridge between your deep technical or domain insight and the VC's financial insight. And like that's that that's the bridge that you need to cross in order to be able to raise money.
And you know, that's that that's the quality that we need to do, which is not like, you know, built in intrinsics. It's not the same thing. Being good fundraiser is not the same thing as being good operator.
And, like, you and like, the fact that you're taking that bridge building seriously, I think is. I don't know, I when I look at, like. I know I st the note like to all three of you, but like, I think the three of you are in, like, really exciting big markets where you can be essential to those markets.
And like. Brian Halligan, he's the former CEO at HubSpot. And how spot's sort of it's a significant Boston technology story, right? And Boston, I think, used to be maybe the number two city for technology.
And it's just not anymore. And it's get it? It took even more of a body blow as a result of, you know, the stuff of the Trump administration and like because a lot of it based on the universities are pumping out stuff, right?
And Silicon Valley kind of flipped it on its head that sure, it has Stanford has Cal, but the big thing it had was money, right? And eventually and but people were coming from Boston. In fact, a lot of the first white Combinary people came from Boston. Combinary used to be both in San Francisco and in Boston and.
And the Boston cohorts with some of our big early success stories, but now it's really more about the money. And then, you know, New York is doing really well because of the money. Not because... But Boston is always more academic.
But the reason I bring it up is that in the discourse around Boston and technology, it's like, "Okay, we're not going to do it with SaaSs, we're going to do it with tech." There's something called the engine over at MIT, which is a hard tech accelerator, and it's just in the discourse a lot right now in my hometown.
So the reason I bring it up is that there's a recognition that there's going to be a lot of business there.

**Ellie Rofe | 15:25**
Yeah.

**Ray | 15:26**
I will not just... Went belly up, right? They got sold for pieces.
What does robotics look like?
Well, it doesn't look like just making vacuum cleaners anymore. It looks like the hard stuff.

**Ellie Rofe | 15:39**
Yeah. [Laughter] This is true.

**Ray | 15:40**
There's some part, and the part that's like if you can just do something that's repeatable manufacturing, it's going to be sent to where repeat manufacturing is cheap.
So what's important what's going to be the hard tech. I think that your idea of expanding from bio to hard like what you're doing with the material science makes so much sense. I think you can be in a wonderful position.
I think your focus on quality is just the right way to do it. Just a question. I just need to keep on shipping that and working with people who don't ghost you at the end of the day.

**Ellie Rofe | 16:14**
Well, it's why I think I need to talk more with VCs wherever I can and somehow build cleaner relationships with them. Because it's funny, like Dina, the biotech VC, said to me,
"Well, what needs to go on a pitch tech? You can do a good job. It's fine. But yeah, I do, and I don't. I'm speaking with Maddy after this call because it's the first week of going out with this pitch deck, and I'm like, "Well, I know."
I think we've derisked that. Derisking is as much as it's possible to do with the choices that she has made at times. So I think we've derisked it. I think we've explained the opportunity.
I think we've made it seem exciting and deeply sensible all at once, which is unless you are at that moonshot level, you need it to be that. But I don't know, because I'm not talking with VCs.
I've had some... Maddy has kept feedback. I have filtered feedback from other people I've worked with, but it's all secondary, it's all a bit loose, and it's all filtered through the eyes of founders who are very subjective about these things, so they're not going to be seeing exactly what I would see or someone with less emotion would see patterns.
So that's where I think it's better. The deck that we sent her. Well, I know it's much better than the deck she had done previously, which would just fluff complete nonsense and have no grounding.
So I know it's better than that. It was beautiful and it was a story told reasonably well. But I don't know what the VCs are really looking for because I'm not in touch with them.

**Ray | 18:08**
Hey.

**Ellie Rofe | 18:09**
That's where I think that's a core weakness of mine at the moment.
I think it's sometimes where I struggle with posting because I feel like, "Am I saying something that's genuinely true, or is this an assumption of mine that I am then putting out as advice?" That's another thing where I'm like, "I want to be careful, not for my own reputation as much as what I'm going to do for other people."
Again, you're right, quality is an obsession. I see so many people talk about working on pitch decks, and they just talk about narrative. In fact, someone got very angry with me the other day because his whole business is about storytelling and narrative. He's a journalist.
And I said, I have an issue with the obsession with narrative in pitch deck in that it pushes people into, you know, fluff and flimflam fluff, flimflam, fla. And you know, but that's a huge preoccupation for a lot of people is just talking about narrative without talking about any of the underlying mechanisms.
So I think on some levels, I am a step ahead, but it's because I'm taking a sort of logical approach rather than an insider approach. And that's where I think that's the next evolution for me for sure.

**Ray | 19:30**
Well, yeah, you use the former to bootstrap into the latter, right? Wait. You seem to be a smart, rational person. And then you bring more data into it because you're talking to more people who then want to be having conversations with you about it.
And I think the whole narrative thing, I kind of. I, you know, I think people hear a narrative and they think, what we need to do is, like, put more polish on this. And basically they see narrative as flimflammery, right? Which, of course, is part of the reason why you're probably your interlocutor got upset because of the implication that narrative is conflammry when that good narrative is about connecting the why to the how to the what.
Right? And the and it's only when these connections get made, you know, in a, you know, logical and factually grounded way that like. Now, we've built this bridge, right between, you know, supply and demand and the and I even think you talking about, you know, what constitutes quality.

**Ellie Rofe | 20:28**
Yeah.

**Ray | 20:35**
What constitutes quality narrative, right? Narrative can be flimflammery, or it could be grounded and thoughtful and logical, and you need both.

**Ellie Rofe | 20:47**
H.

**Ray | 20:48**
The problem is you have, on the one hand, people who are good writers, and they are at their best writing when they're not grounded by facts. And you have other people who have a whole lot of facts, but don't quite understand how these things can fit together to communicate with people who aren't as well versed as they are.
This is a hard thing. The thing that separates funded from not funded is those that can have both because the VCS will sniff out the BS, but they can't necessarily put together the journey on their own.

**Ellie Rofe | 21:17**
Yes, exactly. That's the balance because you tell a scientific founder or a technical founder, you need narrative, people need to know your vision, and they immediately just start talking about the promise of everything.
But it is just completely ungrounded. So we're solving a 10 trillion problem, a $10 trillion problem in we're going to solve anti-bio, antimicrobial resistance. It's like, "Well, you're not because you haven't thought about anything to do with IP strategy, and you're talking about selling a platform that doesn't exist because you've got no IP around the platform, and it's one person in your team that's doing this work."
So it's a huge key person risk and all this kind of thing. That's what I mean about narrative. People push people to talk about narrative, sell your vision, and sell your big Y, and it gets completely untethered from reality because the operator strategy needs to be there, underlying it. You can't be saying, "Hockey stick graph is the classic."
Well, maybe there is a hockey stick. Some people do grow in hockey stick shape. Absolutely. But you have to show how you can't just say this and then just like... Because it might sound lovely in a narrative, but it doesn't mean anything.
It's completely untethered from reality. Even in science fiction, things have to have a world that makes sense. You have to world-build, and that world has to have internal logic. If you tell people just to do narrative, they get confused, and they immediately start thinking, "I have to make
everything sound big and exciting and glamorous and sexy or huge and ambitious." It's just not real a lot of the time.

**Ray | 23:27**
Have you ever read any of Roger Martin's work like "Making Great Choices"?

**Ellie Rofe | 23:32**
No.

**Ray | 23:33**
He's a be school professor from Canada. And I've read more of this ov lately. And the and one of his big things, they're making great choices is part of this is about integrated thinking, right?

**Ellie Rofe | 23:49**
Yeah.

**Ray | 23:49**
And which is what I was sort of getting into it is the idea of like, instead of. There's a tradeoff, right between the flim flammy of narrative versus the true substance of talking about the real science. I there no's a, the he talks about like with his business. Apparently one of the businesses said instead of making pros and cons, you make a pros and pros, right? What's good about each of these ideas so that you can synthesize them, right?

**Ellie Rofe | 24:14**
Yes.

**Ray | 24:15**
And like, getting the best of both worlds. And I think there's a bit of like what we're talking about in here is the opportunity is basically that, you know, zero sum or alternative thinking, you know, puts in position saying, well, this is really good or this is really inflammy or this is totally inscrutable or whatever.

**Ellie Rofe | 24:27**
H.

**Ray | 24:35**
And says saying, no, there there's a not. I dislike the word balance because balance applies.

**Ellie Rofe | 24:43**
Yeah.

**Ray | 24:45**
You're compromising both and getting half of each, right? But instead, there is an elevated form of both, right?

**Ellie Rofe | 24:53**
Well, yeah, yes, well, that is effectively what the naturals are.

**Ray | 24:53**
Where it's more substantive and better narrative all the same time.
That's what you offer.

**Ellie Rofe | 25:03**
You know, it's not that these things are either all they're all part of the same dish, but they all play a different role in the dish and you have to have them all there, otherwise it's rank and then aetising and, you know, it just doesn't work.
And that's kind of where that analogy springs. But maybe I should just test that analogy in January and see how it lands. If it doesn't land, then I'll find another way to talk about it. But yes, it's not either/or. My problem is that people start talking about Narrative and think about design without having the big strategy and data and information bit properly.

**Ray | 25:37**
No, yeah, like the story you told me about the fluffy thing that you worked on for Billy, what was her name?

**Ellie Rofe | 25:49**
Which one?

**Ray | 25:50**
Mattie for Betty. The. You told me about how, like, the previous slide deck was, like.
Right. And you're like, how do you bring these things together, right? And that you don't have. I love this idea that you don't have to choose, right?

**Ellie Rofe | 26:06**
Yeah, yes.

**Ray | 26:07**
Therefore, working with you is choosing greatness. It is saying you're doing both of these things and...
Then what you're talking about because that's what quality is... You're not choosing between the science and the narrative. But saying that you're using one to boost the other, and that is... You're not proposing that's easy.
That's why you have a business. But it is the unlock. Then you can be describing to people how to give away your secrets in terms of how you do it. They're like, "That sounds like a great idea."
I've no idea how to do that myself. Can you help me? I love that in particular because it's not just making a death. Not like you have to be the best designer in the world, right? Or even have them believe that you're the best storyteller in the world. You're the person who can bring it together.
That's what you're pitching as being super high value. That's probably the most interesting word for you. Anyway.

**Ellie Rofe | 27:00**
Yeah. No, it really is. Yes, I think that's possibly the angle of it all for me to founders. I haven't yet worked out the angle for me to VCS, but I'll just have to...
I'll have to try and error that a bit as well.

**Ray | 27:18**
Could I think that like what you'll find that there's a theme that sort of is right. And then the variations are going to be what's, you know, more specific to one market or another.
And then that again, that will mean that you are, you know, compounding as you go across, right? Because one variation is, you know, contributing to the theme, which then helps out another variation and all that, you know, good bit.
Yeah. Because it's like, you know, just how. How to put more. You into itm?

**Ellie Rofe | 27:44**
Yeah, one thing that does appear is very early days because I've only just done a few posts. But one thing that does appear to get traction on some level is the idea that hard tech is just different.
So I wonder if going to just trying to connect with hard tech VCS and just saying, "This is what I do. This is why I do it."

**Ray | 28:12**
2.

**Ellie Rofe | 28:13**
It's different. You need better stories, but you need better detail coming to you. You need grounded, derisked ideas being put in front of you or your portfolio companies when they're doing follow-on, need to be pulling together things that are much more solid and still have great narrative but just have such strong underpinnings as well.
That's what I do, and that's what I love doing. I just find some way to make that useful to them because I think it is a differentiator. I am... Again, I don't know. It's just... I bought a red Volvo. I see red Volvos everywhere or even the algorithm sees that I care about red Volvos and is pushing them in front of me.
But I am seeing more and more people say because of everything coalescing into AI, and people have been building health apps. ChatGPT Health is probably going to destroy a significant number of software companies that were building something like that.
It's hard to retain ground in that world. Whereas I think people are going, "But hang on, the physical world, there's loads of shit we could do there, we need to do there." By the way, wars hotting up, defense is massive.
We don't want to have everything manufactured in China, so we need to make it cheaper here. Robotics is going mad. It's just... I think hard tech is at the crux of geopolitical and macro environments in a different way.

**Ray | 29:50**
Great. That's content too, by the way, that I think is a great thesis.

**Ellie Rofe | 29:56**
Yeah. Yes, very possibly. So that's where I can... I think it's a bit of a wedge for me to be talking about that and differentiating by just saying, "I do that." There are a few other pitch designers, strategists, whatever they call themselves, and the vast majority of them are in Salesforce and do a bit of stuff in other places.
The vast majority of them all they're in specifically biotech. But I'm like, "Everything is merging anyway. There's going to be things that are..." So, for example, what's it? I can't remember his name now, it's just gone from my brain.
But a robotics expert has just posted magnetic slime robots. So, they can move as one, and they can go into a body and retrieve objects, for example. Now they probably won't be able to because it's toxic.
So you have to be like they're going to have to work on that. But that is robotics and it's biotech. Like it's both... There are these categories that are false. Things are combining.

**Ray | 31:11**
Yeah, that's are you crisping this whole thing because this is some good stuff. You're just sort of, you know, adating on here like the like, go. Pull this out. I think.
I think these are all great ideas. I think these are all these position you with the kind of expertise that you can be, you know, in and like and sort of bringing back to the beginning of the conversation.
I think it sort of shows. Okay. What's the job to be done for your decks, right? It's like, okay, well, based on this insight, what are these decks doing? Like, sure, this one got funded, but. Or this one didn't get funded, right?
But you can sort of see how there's, like, you know, bones in here, right? Like and does this give you insight? Does this tell you anything? I'm not sure. Like you have a robot this where it's churning out interesting insights about all these guys.
And but the. Because, like you say, maybe most of them aren't interesting. Or the insights or the robots insights are just wrong. But they're feeding your brain.
And that's.

**Ellie Rofe | 32:15**
It's not even a tear down. It's just like... I think one of the things I've been thinking about as well is I did wonder whether it's a bit populist, but the idea of which is fine. Everyone talks about the lessons from film, and they all talk about save the cat and the hero's journey and all this crap. I actually think there are far more interesting lessons, and one of them is... When I was working at the film festival, someone said, "Don't..."
I think I told you I sat up a film festival years ago when I was at uni and don't...

**Ray | 32:47**
Come to me.

**Ellie Rofe | 32:50**
What worked for Spielberg will not work for you. What worked five years ago will not work for you. The landscape changes.
By the way, what worked for Spielberg was not the story everyone tells about him just lying his way onto the Universal lot and pretending to be an executive and making connections.

**Ray | 32:59**
2.

**Ellie Rofe | 33:10**
It was that the studio at that time was actively looking for young directors via short films.
He had one, and yes, he did do that, but that's not why he got through. So there's this constant... There's this constant survivorship bias type thing as well, right? Where it's just like this happened.
Therefore, this is what everyone should do. I could be wrong about this. So this is where I need to be in touch more with VCS. I feel like GenAI raising an eye-watering amount last year did not set a benchmark.
I think it probably made everything harder for anyone else to do that because those big deals shift the market in a certain way. Then people are like, "Well, what are we going to do? Just keep getting bigger like... Can someone actually do this? Is it possible to really challenge that? There just becomes the market constantly shifts."
To look back at a deck that raised money in 2021 or people still show Airbnb Dex, and it's like, "What relevance has that got to raising hard tech in 2026 and none beyond some basic fundamentals that stay the same across time?" You have to just let people know what they're getting for it.
But the process, the strategies, and the demands change constantly anyway. Yes, that's where I can see it happening externally. But being internal to it would be much more authoritative and much less intensive.
Work-intensive as well.

**Ray | 34:53**
Well, right, but you use the former to get into the latter, and I certainly appreciate what you're saying, although probably what happens is it increases the work because you are now trying to satisfy both sides, right?
From the position of your superior information, you can't get away with the stuff you were getting away with before. Partially because your own intellectual integrity won't allow you to...
Because you're like, "No, that's not really true because I know about this." So now you need to... You'll just keep raising the game, which is awesome. Then, as you do that, it gets you more reputation and blah. One thing I really like about the storytelling, particularly the grounded storytelling and where quality comes from, is that it'll be interesting for... It's good for founders because they're raising VCs. It's good for VCs because they help them better bet founders.
But they need to remember there's a third party in all this, which I talked about little before. How does the Hard Tech Fund raise from the LPS? They're a little bit on the back foot because they need to raise for an LP who understands what the hell they're talking about.
So how did they do that? Their own story is going to matter quite a lot for that. Probably... It's like, "Well, we already have people who invest." Sure, which is effectively increasing their cost of capital because it's a smaller set of people they can raise from because they need to actually have this level of understanding.
But if you can help them communicate, then the baseline understanding people need... I once used a line with you folks over at Xano. I said that your correct customer is quantitative but not technical, right?
Right now, you require them to be technical to really take advantage of this. Then you have this ambition of talking to non-technical people. Right? But the problem is that ambition is to an audience that's not going to be able to use your stuff. People who are using your stuff is this more limited audience. There's this bigger set of people who are quantitative and not technical that you could... That is... The multiply the size of your market. Now they never really went down that road.
So take that for what it will be. But the idea of how you can decrease by a couple of steps the requirements for someone to get it. This is what you're already doing with the biotech people, right? People who already have a really good understanding of what this person is trying to do.
You talk to... We're talking to people for cancer research, and you're talking to someone who happens to be an oncologist. That's in the right domain. They understand the stuff. Okay, you can be speaking to them, and they might say, "Yes, I get it."
Well, let's do something. But you've increased your cost of capital because you talk to five other DCs, and they have no idea what you're talking about.

**Ellie Rofe | 37:27**
Yeah.

**Ray | 37:29**
So the first one gets to call the show and be able to set the price, and the same thing is true for the LPS perhaps to a more significant point of view, because LPS who specialize in this stuff, you have a few high net worth individuals who are expert enough to be able to evaluate it, but most of them can't. Hard tech isn't one thing.

**Ellie Rofe | 37:53**
No. Each ecosystem, and that's part of my study plan, is understanding each ecosystem in more depth. So like defense is obviously radically different from biotech, which is radically different from robotics, to deep tech, to all sorts of things. They are all different ecosystems, and the thing they have in common is they're capital-intensive, they're high risk, and they have long time lines.
So you get a certain type of VC that is tending towards those things, the ones who want frontier tech, and they want the big moonshot things, or they just want to be doing hard stuff like Lux is a great example of that.
You get VCs who've come from software and are crossing over more because they are seeing that things are shifting. But the actual conveying of those markets and understanding the mechanisms of those markets is... I think other than where there is already a really big ecosystem like biotech is a little bit light. I'm really hopeful. I'm hopefully doing some work for the SDP and one of their candidates, who's the guy I was in touch with first with them is doing artillery shells.
I know it's defense in the UK, which is nonexistent, but it would at least give me an insight into the defense market on how it works. It's going to be tough to get your hands on a deck by Anderil, but at least I can try and start understanding a little bit about how those things move, the sensitivities, and stuff.

**Ray | 39:33**
Yeah, right, and yeah, the but, you know, it's like about the same sets of quality insights, what have you that are going on. This all seems very cool.
Okay, so, you know, how can we be helpful to you to be able to accomplish the kind of goals we have of, you know, shipping things in the course of the next week, which was sort of something you were talking about, obviously you're having a conversation at the end the hour. You're using that resource, which is great. You used half resource with me. The but like, how can I be a service to you on that?
Because I think you've got these. You've got a bunch of wonderful ideas are all stirring around in your head that you've been sharing with me. Hopefully you pull out. How can I help you get more of these into the world?
So the world can know about your, you know, about your thoughtfulness, about your intelligence. And that puts you in a better position to be able to get more of the kind of business that you know will reward you.

**Ellie Rofe | 40:36**
It's a really good question. I think a sticking point is...
I think I can see when I look back at stuff that I wrote two months ago where the floors are or where it's missing connections or whatever.

**Ray | 40:58**
Two.

**Ellie Rofe | 41:03**
I spend time using AI to try and preempt that.
Like we. You know, when I used to do editorial work in investment banks, you knew that as soon as you pressed send, you'd see an error because your brain shifts into a different gear. I'm trying to use the AI to do that for me, but I don't know what... Do you just use...?

**Ray | 41:15**
No.

**Ellie Rofe | 41:23**
Because the other thing is the market apart from the odd bit of engagement I'm getting, it's not the market is broad enough yet for me to understand signals from it. So how would you like it when we're talking about these insights I've had in this call?
I will take them away, and I will start trying to write things up, and then I try to make everything pitch. I will probably end up doing something useful, but I might end up feeling uncomfortable with some ideas or whatever and not sending them out.
So do you have any mechanisms or recommendations for how to get better at really identifying the key insights? Or is that just something that has to happen over iteration?

**Ray | 42:16**
I think that a good fraction of this is you need to ship more stuff. That's not so good.

**Ellie Rofe | 42:22**
Uhh.

**Ray | 42:23**
You know, I actually put together a new. I've been doing some work using AI'D build.
You know, mental models for state change based on, like, you know, the various sessions and all of this content stuff. I then had it turn take each of the ment maels and like, you know, turn into a song from Pseudo.
So one I was listening to earlier this morning as part of the playlist is called the Weight of the Pots. Right, which is based on the parable of the pots, right?

**Ellie Rofe | 42:50**
Yes.

**Ray | 42:50**
The way they make the best pot is by making more pots.
So, and I think that this requires shipping more. When you look back and you say, "Well, two months ago, that wasn't nearly as good." Well, anything you do today is going to bear what you're doing two months ago.
So let's ship those things and partially see you can be getting feedback from the market. I'm not proposing shipping slop, right? I am proposing you're shipping more ideas into the market. Then they're going to say, "This seems good, but there aren't enough feet on the bones of that."
Okay, well, let's dive into that, right? What ideas, what concepts, what topics are really getting attention? To your point about quality comes from having an idea that's worth sharing, right?
Then you come better at the sharing, but you want to find out but the problem with tinkering with it is what it becomes tinkering because you are editing the presentation of the idea rather than putting the idea in the market.
This could be where the VA helps, right?

**Ellie Rofe | 43:56**
M.

**Ray | 43:56**
What's the V? As? Job. All right, let's look at these things. What do they think? You know, and you know she's not going to be, you know, the world's best judge of whether this is, like, what the VCS are going to want.
But she can look at it and says, hey, this seems kind of smart. Let's do it. And I'm glad to help with that, too. If you're saying, hey, what do you think about this? And you know, but to, you know, just get somebody else's perspective, which then and then you are on the call pushing that send button or schedule button, you know, if you're buffering it or whatever.
And then. And then you're just moving on and then allow the market to tell you what it thinks about those ideas.

**Ellie Rofe | 44:37**
H.

**Ray | 44:37**
I found that to be super superhellful. I ship more ideas and then I take a look at okay, what's getting more views, what's getting more you know, whatever's.
And the. And that will tell me where the market seems to be linking up to an idea. Okay. Well, let's explore it a little bit more and let's see what it has to say to us. I think that's how you do quality.
Because if we're saying, "I would rather present more good ideas badly," people will... The people who you want to work with will cotton into that. The flimflam artists want to tell bad ideas. Well, not... They're looking specifically for bad ideas, but they're going to care much more about the presentation.
So, the people who want to go hire those folks want to go hire these folks. They're not going to hire you. So what is the piece of the market you can go for that's going to be well, let's talk about the ideas of it.
Then you give yourself the opportunity to do the... To make more of those pots, right? Then from that be able to find out which of the pots are good. Not because you've decided they're good, but the's telling you they're good.

**Ellie Rofe | 45:49**
M.

**Ray | 45:50**
I appreciate this. It can get hung up on the question, "Where's the line between slop and something shippable?" But, I think a lot of it is, "Is there a good idea in there?" If there's a good idea in there, there's probably worshiping.

**Ellie Rofe | 46:08**
Yeah, it's not that I think I'm better than I was in the past. This is what the problem is that I... You're right. I just need to keep moving. It's that when I look back, I can see what was unclear. Whereas when I'm in the moment...
I guess that's the thing, it's basically building ideas in public. It's saying, "Okay, that was unclear." Rather than worrying about things being unclear when I send them, I just then revise them and make them clearer and revise them and make them clearer based on what people are saying. This doesn't make sense.
So it was. It was. I mean, I say that guy was angry with me. It made me laugh because he was basically telling me to just agree with him. But it. It made me realize that, you know, there was a refinement to be made here.
You know, I did thank him. I said, thanks for pushing me on this. Because there's a refinement to be made. So that's, you know, that's just a thing to keep pushing through, I guess, is like not worrying endlessly about whether everything is perfectly clear and just keeping on trying to get the gist out.

**Ray | 47:17**
Yeah, and I think that you have so many good ideas, and it is a privilege for me to listen to those good ideas. You make me smarter in the course of these conversations.
I think you have an opportunity to make the broader market smarter as well. This idea of making these connections is really trading in ideas. I think much more that is trading in design or polish or presentation or what have you...

**Ellie Rofe | 47:50**
HY.

**Ray | 47:51**
You sort of saw that like with the most recent Maddie thing. Very polished and nothing inside, right? You put substance in that in the connection between the substance and the polish, that's that that's where you are like, wait, somebody else wants to do very design stuff. Great give you business because I'm that that's.
And you of course I know you can do that stuff yourself, but like that's. But by positioning yourself as the idea as that bridge builder, I think you are in a very good place. And when I read like some of the stories like what you're talking about like with this political party or what have you, it's like, okay, well, what's good in there is actually connecting their ideas to the market, right? What's what is the potential of being, you know, the knock on a lot cli communicators, right? They're. They're shy up a dird like.
And. And I do think that there's a reasonable thing in here of. Do you think your services would be useful for a bullshit company?

**Ellie Rofe | 48:59**
No, but that's actually... This is the only reason that I am looking at the SDP is their problem is actually the same problem that scientific companies or scientific founders have. They are policy-obsessed nerds who are incredibly principled and have really great ideas. They have just been so principled, they refused to put them into the market in a way that is digestible to anyone who isn't a policy wonk.

**Ray | 49:24**
2.

**Ellie Rofe | 49:32**
So I see a parallel in terms of what they need. It isn't someone to turn them into reform or MAGA or whatever other movement, it's to turn them into something that is differentiated but still connects.
That's... I think it's a really interesting thing. I do think it has to be obviously has to be paid and there has to be a chance of more pay and recognition because I do think there is a little bit of a boys club element there if I'm not careful, and they will relegate me as the brand girl if you're not careful.
So I'm positioning it and saying that I will be introduced to people or referred as their strategic advisor on comms or something or pitching or fundraising. But I think the actual mechanism that I'm talking about is the same. They have deep ideas. This 70-page paper on energy is thrilling if you care about energy production.
It is absolutely not thrilling to the people who have been avoiding putting their heating on this winter, but it still impacts those people. So how do you connect these things? Rather than just being the party that everyone else steals policies off, which is what they are at the moment.
So there's an interesting motion there. I'll be intrigued to see if it happens. I think if I can help them, then I'm closer to a greater seat of power. So it's not a massive risk for me.

**Ray | 51:06**
Yes, well, right there are opportunities, so right now you're in a position just saying yes a lot.

**Ellie Rofe | 51:07**
I'm not giving up.
Like a 50 grand contract to do some work for them. So.

**Ray | 51:17**
But the thing the point I was trying to make about, like, the whole, you know, slop company wouldn't be able to hire you is that, you know, you're about the substance, right?
And the. And I think that's like, okay, well, if you're substance, then we should talk. And if you're kind of sloppy, well, then you're not gonna want to talk to me. That's fine. And like, I think that it all sort of feeds back in the right way in terms of the engagement you get is going to be the right kind of engagement because it's going to be, you know, for that particular, you know, set.
And it's like what you discover is like, hey, there's sort of no there, then there's no there. I think there's a thing to be said of like, this kind of gets back to your imposor syndrome from the beginning.

**Ellie Rofe | 51:55**
Yeah.

**Ray | 52:00**
But a lot of companies have impostor syndrome, they don't think that they're there, that they're not sure that this is really valuable because they don't know how to connect, right? That's the reason why they do things like when they're asked for their vision and they start talking in really high-end terms because they have no DE in their business because they don't see how they can connect their business right to something meaningful.
But the great businesses can make that connection. I keep on talking to businesses, and I'm so partly I'm saying that myself, but partially, I'm thinking about your copy.

**Ellie Rofe | 52:33**
3.

**Ray | 52:34**
The who I can see that connection, but sometimes they don't see that connection for themselves, and they're certainly not delivering that connection to the world, and that's a fixable problem.

**Ellie Rofe | 52:47**
Yeah. And it's just given me an idea for another sort of post. Which is why I could never have done a pitch deck for WeWork because...

**Ray | 52:58**
I love that I could never have done a pitch deck where we work. That is a great that's a super hook.

**Ellie Rofe | 53:06**
Yeah, I'd have annoyed the shit out of them. They'd have sacked me because I'd have kept asking "No, but why? How? What?"

**Ray | 53:14**
Right? I think you can even own that. Not because I have superior insider knowledge that I know better or whatever, because this is just my process. My process would not allow me to...

**Ellie Rofe | 53:25**
Yeah.

**Ray | 53:27**
And I think that's a process worth repeating. I love it. Okay. I hope that some of this, you know, I you know, a lot of this feels like it's sort of been an ideation session for, like, you know, really good content for you.

**Ellie Rofe | 53:42**
Yeah, I would love it if it's okay with your diary, to have another sprint day next week.

**Ray | 53:43**
How can I be most helpful to you in the coming week?

**Ellie Rofe | 53:51**
That would be great. I think it's really healthy.

**Ray | 53:54**
But book it up. And you know, we can. INCLUDEDE in the Description do not take NAP. And, yeah, I'd be absolutely delighted to be a service on that front.

**Ellie Rofe | 54:06**
Yeah, I think that would be fantastic. If you see stuff, I'm not... Although I have imposter syndrome at times and all that sort of thing.
If you see something I've written, I will... I'm happily receive feedback that there's something that doesn't work in it, or there's an opportunity missed or something. Because if you happen to see something I've posted and you're like, "This is good."
Then that just helps me do it better next time.

**Ray | 54:34**
I hear that. I'll be even more excited by just seeing more come out, right?

**Ellie Rofe | 54:38**
Yeah.

**Ray | 54:39**
Because the idea with this... That idea of focus that we were just discussing...
So I'm glad to give that kind of feedback. I just would not want to be part of... What is anything that's slowing you down in terms of being able to put these really good ideas you have into the market?

**Ellie Rofe | 54:52**
No, well, and I'm not asking. I wouldn't want you to have to put too much time into it either, because I know good feedback can be hard, but the point I would just... I just want to grab it and then just collect and collect as I suggest founders do.

**Ray | 55:09**
Good. Alright. This has been absolutely delightful. I'll see you on Tuesday.

**Ellie Rofe | 55:15**
Very helpful. Thank you. See you then. Cheers.

