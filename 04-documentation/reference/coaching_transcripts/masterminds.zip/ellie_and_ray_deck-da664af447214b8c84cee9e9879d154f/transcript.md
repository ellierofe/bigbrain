# Ellie and Ray Deck - Sep, 29

# Transcript
**Ellie Rofe | 00:05**
Hello, how are you?

**ray@statechange.ai | 00:07**
I am well this afternoon, Elle, how are you? How was the day in France?

**Ellie Rofe | 00:15**
How is the day here today?

**ray@statechange.ai | 00:17**
Yes, well, I'm just saying specifically in the beautiful countryside of France as you are right now.

**Ellie Rofe | 00:24**
Yeah, well, it's actually we've got sunshine for the first time since I've been back, so it's lovely. The cows are mooing, the sun is shining, it's good.

**ray@statechange.ai | 00:32**
Okay.

**Ellie Rofe | 00:32**
Yeah.

**ray@statechange.ai | 00:33**
Do they mean French? Is that my question.

**Ellie Rofe | 00:36**
Now, what's French?
Because they have different words. So dogs go "woof" in the UK, but they go... It's actually like my surname here. They sort of go "rough" here or something. And frogs say something different as well, but I can't remember what cows say. Probably not. Moo.

**ray@statechange.ai | 00:54**
That is just weird. [Laughter] Okay, well, of course, I read your report, and I think there's a key thing in the middle of all this, which is that the business is, as before, it is now. The business was not Google. The business is not you doing slides.

**Ellie Rofe | 00:56**
[Laughter] Very rad. [Laughter] Yes.

**ray@statechange.ai | 01:24**
The business is about you and your expertise being applied and in a market that creates growth, joint value at the same time.
If that is something that is best done at this phase through you being salaried, then let's... I would wish that for you. If that's best done through being a contractor, then I wish that for you.
If that thing's best done through more productization, then that's what should be done. But all those are just means to the end. All of it is by way of saying that I appreciate the frustration. I certainly appreciate the stress that you are feeling right now. While I lost my father a quarter century ago, and my mother is still alive, my uncle, who's probably the closest father figure I've had for the second half of my life, is probably in the last ten days of his. These things happen, and I well... It's just by way of having a little bit of sympathy for the stresses that you're going through, right?

**Ellie Rofe | 02:20**
Sorry.

**ray@statechange.ai | 02:29**
It's not parent, but it is certainly not pleasant or easy and can be a little bit distorting. The key is just to try to make good small decisions while you're in the stress period so that you're not locking yourself out of the good big decisions that might come after.
But I guess with all that in mind, what? How can we put you in a position so that we can be helping you feel less poor? I had AI have a run with Demetrius along these lines a few months ago. Where he...
His business was not producing, part of it was seasonal, but part of it was in terms of underlying causes, but certainly he was feeling the pinch. He's about to get married. There are all sorts of stuff going on.
Robert did a pretty good job of being up his practice in the late spring, which is required a little bit of rebuild as well. The reason I'm bringing these two things up is not so much to betray conferences, but just to say that the ups and downs happen.
I appreciate people getting in the room when they're talking about their immediate stuff, but everyone's got more stuff that's going on under the current.

**Ellie Rofe | 03:54**
Five?

**ray@statechange.ai | 03:55**
But I guess with all that in mind, how can we be putting, you know, how can we be applying you right in these coming few weeks? Let's just keep a short time horizon on it.
That is going to help you move towards a better cash flow situation. Because I think that's a necessary precondition to being in a good equity situation. If that means, "Hey, I don't want to be doing the same work," that's fine, right?
But, if you will permit it, I would wish to be a part of your path to the success that you wish to have.

**Ellie Rofe | 04:34**
Yeah, absolutely. I was actually feeling fine, and then you mentioned Mum, and I've something gone on a bit. Ignore that because that is...
I know it's the business is mean, but that is a preoccupation rather than the important thing. Now, what's the deal? I think, I honestly don't know. I think for me, what I'm trying to do at the moment is...
I've reached out to an old presentation like recruitment consultant who does... who might have ad hoc work for me. I'm talking to agencies in France. I'm going to try and reach out to comms agencies in the UK, especially ones that do biotech who do investor decks and see if they need any overflow work.
I think one of the things I have been slightly struggling with is... And I know I'm not special in this. I'm just unraveling compounded problems like living in France, whilst it is lovely in the countryside today, it is very difficult, especially when I'm not being able to get back both to see family but to network effectively.
There isn't the same market, certainly not locally. I was discussing this with my partner. There's probably a reason more people come here to retire than they do to build businesses. You know, it's not exactly a thriving metropolis.
So, part of me is like, "Do I just cut the Gordian knot on all of that and just say to Nick, I'm going to go back home for a few months and try and get work where I can go most things that people need, a hybrid?" Or I need to be in London on some level if I...
If I'm looking at a position in France, I can't speak the language well enough to hold a full-time job, but maybe there are companies here who could give me overflow work. It's just a series of these things. Even with the place here, we're going into winter, we can't get GAs because you have to buy a large chunk of GAs upfront.
So then we're trying to work out how to manage heating the house over winter now. That in itself is then subject to other things around, like the very expensive electricity.
Anyway, it's just unfortunately, as we all know, and as I haven't personally experienced on this scale before, but I obviously do know my mom grew up in absolute poverty. So I'm not unaware of it. Put it that way. I just haven't ever experienced it personally.
It's quite expensive being poor, so you have to try and work out ways to improve things. At the moment, I'm trying to find where there's overflow work. I'm speaking to someone tomorrow who does investor relations with biotech companies, and she doesn't do presentations.
So she might have some pitch design work, and actually, getting slides done for me, which is fine. I keep... I think part of the question is the viability of the market. I've been working with an AI on her pitch deck.
As soon as I started, I've been working on the wider story, and then as soon as I started looking at the actual numbers in her narrative, really deeply, I realized they're all just enough. A enough bullshit.
She doesn't understand enough about it. I've been torn on how much I just go away and do that research myself and try and come back with actual figures versus try and educate her on it. Again, it's that thing we've discussed multiple times. Now, if you want to be associated with someone who's going to win, she's not going to win by making claims like 97%, which is a new one she introduced. 97% of clinical trials failed because of these biomarkers, which isn't true. 97% of clinical trials don't fail for a start.
So it's like she's very early. Which is where people have suggested I move to because there's actually some investment happening even though it's lower investment.

**ray@statechange.ai | 09:29**
He.

**Ellie Rofe | 09:36**
But then it's like, "Am I working with people at that stage?

**ray@statechange.ai | 09:36**
No.

**Ellie Rofe | 09:45**
Am I then starting to work with people who are so inexperienced they need extra work, but they've got less money to pay for the extra work? And so it's a bit like the brand strategy dichotomy again. Working with people who aren't earning enough money to be able to pay you.
So I think partly, I just need to try and get some money coming in just so that I can get the car fixed again because otherwise I'm pretty stranded here and I can't move anywhere or do anything. I need to get a car fixed and I need to get some money coming in to the point of a baseline where I can. Even if it's 1500 a month, which gives me space to breathe, to then be able to do stuff.
At this point, I don't know whether the fastest way to do that is. I know we've talked about the network and stuff a lot of times, but I genuinely just don't think I have a very strong network and I don't have time. Now, in terms of making money, to build up a massive network like that, it takes time and it's not going to happen overnight and they're not going to all suddenly start giving loads of work immediately again.
This is a catch-22 of needing a couple of recent examples of Pitchdex I've worked on. But the three people I've worked for, one of them has had to... He's come back and he's decided to go down the antibiotic route.
But that's just recently. Now I need to redo his whole pitch deck. It's going to be a while till he gets funding. He might even need to wait for the fundraising proportion until next year after he's applied to grants because it's a different funding structure for antibiotics. The other guy I spoke with, someone who works there, he's basically just gone and done a really dodgy deal with a Chinese company and is ignoring loads of other options and has disappeared.
Then there's an aid who's very well connected and works at the Crick. It's great, but it's a huge amount of investment to try and get this pitch deck over the line. Because I can't rebrand her branding, it's appalling. I'm working within that style,
but that doesn't give me a big flagship thing. It might hopefully within the next three months give me a result, but it doesn't give me a flagship. Here's a pitch deck I designed. So, I think maybe trying to contact people and say if you need any overflow work, trying to contact, unfortunately, the people I worked with in investment banks and stuff, almost all of that's been outsourced to India now, so it's very difficult. Everyone went off and did loads of different stuff.
So yeah, I think that. Then the other thing I'm thinking is just trying to apply for things on Upwork, which isn't ideal because it will be low rates, but it will be better than nothing. It'd be better if you cut the bum.
I know that compared to the vast majority of people there, I'm not going to work for the same rates as someone in Pakistan or India does. So, I'm going to have to because it's literally ridiculous.
But that at least gets me to a group of people who are willing to put some money into this stuff and then try and get some cash flow in and then see if any of those turn into anything better. There seem to be quite a lot of people in the Middle East who need to pitch their deck and raise funding at the moment.
So, we'll see where they are. I think just hammering it really at the moment. Then it's cold approaches, which I've been avoiding, but I think that might be all that's left, really. It's just a ton of cold approaches.
Maybe revive some of the other cold approach ideas about VCs, founders, and stuff.

**ray@statechange.ai | 13:40**
Yep, Okay. When I think about it, there are two parts to this, right? One is building equity, and the other is building cash flow. A lot of the conversations we've had have been about the building equity part.
I'll tell you, that's where I thought we were being led. I'm perfectly happy to have the cash flow conversation because I certainly hear what you're saying. We make poor decisions when we're feeling poor.

**Ellie Rofe | 14:11**
Yes. That is my other concern.

**ray@statechange.ai | 14:14**
The and there's a rationality to that. We've become short-term focused, right?
It's a little bit more fighter-flight. I think Upwork is a perfectly viable thing to be doing. I got the... I appreciate your card just broke down. The things I think about when I think about cash flow, right? You think about timing for it.
So one is to drop the pride as it relates to rape, go get more wins, get some cash indoor games, some cash indoors. How can you always increase your rate? I did work on what was it, Codementor, right back in 2020, rebuilding my practice, and I started at a low rate, and then I just basically made it. I was raising my rate every week and being diligent about getting reviews and whatnot. The gigs on Code Mentor are micro-gigs, right? There's something like, "Hey, help somebody with an hour or a couple of hours."
I think actually, those are really good for a combination of cash and getting the equity of it. The person in Pakistan is not willing to do that right.
Initially, you're not going to be able to charge the rate that those other folks are over and above. But that's initially right. The idea is that if you go in, you're not stuck with that rate for all time. You're not even stuck upward for all time. We're looking for those to get the wheel turning and getting some cash in the door can be super useful.

**Ellie Rofe | 15:45**
But.

**ray@statechange.ai | 15:52**
You want and that this then gets you the wins.

**Ellie Rofe | 15:55**
Yeah.

**ray@statechange.ai | 15:55**
It's hard there be some shitty people.

**Ellie Rofe | 15:56**
I was thinking of a
balance. People are working for ten dollars an hour. That is, to me, seems like I'm going to be finding clients for that rather than fifteen dollars an hour, which is where you find the people who are willing to pay for something.
Maybe I'm wrong and I should just go and do the grunt work. It's fine doing the grunt work, but I'm still trying to balance. Yes, I need money in. But where is it that I'm creating a massive opportunity cost?
If I just go in and work at $10 an hour, that's then going to be $8 an hour. That then is like, even if I work 50 hours a week at that, I am not getting in enough money.

**ray@statechange.ai | 16:42**
Yeah, but the way of looking at that is to see it as a rate that you're now being employed at. The correct way of looking at it is to say, "I'm going to do a five-hour job that I'm going to make a crazy small amount of money for."
But the end result, that five-dollar job, is that I'm going to have that small amount of money, and I'm going to have the win and the review. The review is the key to it.

**Ellie Rofe | 17:08**
One.

**ray@statechange.ai | 17:08**
And more small gigs allows you to build up those reviews. The reason why you are in a disadvantaged position to get the $50 an hour gig is because you will be alongside a bunch of people who have 50 reviews, right?

**Ellie Rofe | 17:20**
Got it.

**ray@statechange.ai | 17:20**
So you need to go in and underprice and crazy over deliver in a series of short.

**Ellie Rofe | 17:23**
M.

**ray@statechange.ai | 17:27**
I why we're talking about the short and sharp stuff. That allows you to be making the reputation quickly, right?
So you get cash flow and equity at the same time. If what you're doing is you're holding out for two weeks to go find the $50 thing, what you've missed is two weeks of opportunity to be building up those reviews.
That was a big lesson I took away: I could get multiple reviews per week. I think in the course of... I think I did Codementor for something like seven months and got around 300 reviews.
That was not NES, that was not working 50 hours a week. I started at a lower rate and ended at $400 an hour. I sort of bailed from there to go do higher-order work.
I'm saying that it can climb, right?

**Ellie Rofe | 18:15**
Yeah.

**ray@statechange.ai | 18:15**
And is going to be judging you for being at $20 today when you're at $10 tomorrow.

**Ellie Rofe | 18:15**
Yeah.

**ray@statechange.ai | 18:20**
Being at $40 today when you're at $20 yesterday, it's just going to be... Hey, this is my rate.
And look at all these great reviews I have, and look, I know it could be somewhat. It's a little more tricky. Particularly for a woman, but by putting your own face and name up there, it makes clear that they're not hiring a Pakistani.
That is something that a number of people are going to care about.

**Ellie Rofe | 18:43**
Yeah.

**ray@statechange.ai | 18:44**
And the. And that, you know, allows you to gather more of that upwork is useful if it is fast, if you're putting stuff up there and nothing's really happening, then you're just, you know, it's more wheel spinning, right?

**Ellie Rofe | 19:01**
Y yeah.

**ray@statechange.ai | 19:01**
So how can you go in there and be able to get engagements in a short period of time there, then getting you that combination of joy, growth, and cash flow, right? If when it starts to do that, it won't be enough money when it starts...
But what we're trying to do is just start the flywheel, and the flywheel is always hard to terminal. It's not moving yet.

**Ellie Rofe | 19:25**
Yup. No, I get the logic now. That makes more sense. Cool.

**ray@statechange.ai | 19:31**
So I think there's lots of opportunity there. I have encouraged people who have products to go and do consulting because it's a way to get paid. It gets cash flow. The shocking thing is if you are getting paid, you're building equity because those are women are now people who trust you. Those are now thinking good things are being said about you, giving you knowledge. You're going to say, "Hey, I didn't engage like this." Whatever.
You're going to find, as I have in the past, you're going to find yourself citing the thing that you did when you were at this rate right for another at this rate. And they're going to think that you're a genius for having worked on that thing before, and that they didn't pay off. [Laughter] But that's just what turns into right, that's how that knowledge rotation works.
Well, the thing compounds, but you do it initially. The terrible thing about a compounding chart is that it's so annoyingly low at the start. So what I find is when you are at the super low, you want to figure out if things are additive, right?

**Ellie Rofe | 20:27**
Yeah. Hu.

**ray@statechange.ai | 20:33**
And you're more on the curve, you want to do things that are multiplicative. So what's additive here? Get more work.

**Ellie Rofe | 20:40**
Yeah.

**ray@statechange.ai | 20:41**
And to Upwork can be useful. Being willing to work out of band can be useful.
I have said before to other would-be entrepreneurs who are having a struggle, have you considered driving an Uber? I say, it doesn't move your business forward directly, but it keeps you engaged, it's making you money, and it's preventing poverty.
Particularly, hey, when the rest of it's not going like summer, and nobody's answering the phone. Great. What can you do to make money in the meantime? Right? To be putting something in.

**Ellie Rofe | 21:15**
Yeah.

**ray@statechange.ai | 21:18**
I think you're going to find that there's going to be a correlation between this time of year and the time of year that a lot of what you've been doing in the third quarter has been in the third quarter, right? Now as people are coming back, getting more serious, and as we head into October, there's going to be a correlation between just the timing and you getting more work that's necessarily... Say that the work you're originally going for was going to go by Gangbusters at that point.
But I think you are a little bit on a confluence low of discovering that your network wasn't what you thought it was. You know, going out, trying a bunch of things not... And basically taking swings and having missed...
Everybody being out of town right now, we're going to have people who are in town who are looking for business.

**Ellie Rofe | 22:01**
Yeah. Yeah.

**ray@statechange.ai | 22:05**
And now you have the new insight of how to make yourself easier to buy.
The thing I would encourage as you go down the Upwork and the salaried road is to look at it from a short-term lens. Cash flow is about short-term, and equity is about long-term.
So, wait, you need cash flow? Great, let's get you cash flow. But let's not make Upwork into a ten-year contract, right? I'm saying... King... I mean, go get a salary job. That's fine with a mental model of...
All right, well, I'm going to be revisiting what I want to be doing in the next six months.

**Ellie Rofe | 22:42**
Yeah, it's incredibly rare that I've had a permanent job that's any longer than a year anyway, because it's not my vibe, so it's literally just... Can I... Ideally, a contract, a remote contract. Bingo.
Let me get those hours. I can work extra hours. I can do stuff on my own business. That's fine, but just get some money from me. Preference would be to be working on gigs rather than a contract. Uncertainty rather than permanent work.

**ray@statechange.ai | 23:17**
Two.

**Ellie Rofe | 23:18**
But it's just what is or isn't realistic. So I think that's where I need to hit multiple fronts and see where there's some sort of give to get some money. So I really appreciate the idea about Upwork because I was thinking about it in terms of time versus the actual income.
But like you say, just boosting things quickly and saying, "Right, let's get this done." And building is definitely something that can be done.

**ray@statechange.ai | 23:45**
And will be easier to sell as well. People put things up on NoBook and they're not sure. I think what one of the biggest things you're going to compete with on Upwork or any other freelancer platform is the client deciding not to do it at all.

**Ellie Rofe | 23:59**
Yes, yeah.

**ray@statechange.ai | 24:01**
So this was not just freelancing. I was just having this conversation with the CEO, Zeno, and he still doesn't understand that he thinks his competitors are super basic. You go talk to these companies, and then what happens? They decide not to move forward with the initiative, and that's why you don't make the sale, right?
It's not... They decide to go buy something else. You need to help them, help convince them, help them see that this is the initiative, something they should follow through with, and then they will buy your software in order to go follow through with the initiative they already want to do.
But that's their initiative. That's not our stuff. Yeah, that's all true anyway, but that becomes something you can be helping with. I think they'll be able to see the difference between here and there. You can be generous, offering... "Hey, we can do a free 20-minute call, and if it doesn't work out for you, we'll just call it, whatever."
These people are going to get absolutely insane levels of value from you, but you don't mind, in fact, if they would. A trick that I did in CodeVentor that you might find useful in network is if you get them the console and they have what they need. Ask, "Can I just bill you $5, and then you can put up a review for me?

**Ellie Rofe | 25:25**
Yeah.

**ray@statechange.ai | 25:28**
No, not a lot of people...
I mean, whatever people are going to do, whatever they're going to do. But I found that to be super. That's gotten me a few more of those reviews because I'm like, "I don't want to be charging you for something you don't need."
Yeah. The reputation part is what really turns the wheel for me. You want.

**Ellie Rofe | 25:51**
No's. I totally get what you're saying. It makes perfect sense. Now I have been thinking about it wrong. I think that is a feature at the moment. In my thinking, it's slightly panicked.
So that's really helpful because it's stepping back. I love it. I always say when I was working with people on brand strategy, and we were talking about objections, competitors, and things, I was like, "You do realize that the biggest competitor is doing nothing?"
That's always the biggest competitor. So.

**ray@statechange.ai | 26:26**
Yep.

**Ellie Rofe | 26:26**
Yeah. That's definitely important.

**ray@statechange.ai | 26:28**
And there's more to the world than just upwork. I would check contra, which has a little bit more, you know, heat under it.

**Ellie Rofe | 26:31**
Yeah?

**ray@statechange.ai | 26:37**
And, you know, frankly, I don't really know who else is out there that's, you know, in that, you know, that sort of, you know, gig marketplace, you know, type thing.
But it's a way to get it moving.

**Ellie Rofe | 26:51**
Well, you mentioned GoodMinds. It was interesting because I think there are a ton of startup mental places.

**ray@statechange.ai | 26:52**
Ummm.

**Ellie Rofe | 27:00**
And people want to talk about their pitch even if I differentiate from all the money-making pitch IR specialists who are investment bankers and stuff, I just say... Talked to about your design. Talk to me about the technicalities of it all. Talk to me about that kind of thing. Then I can at least see if there's anything up there that can... I can help people with.

**ray@statechange.ai | 27:28**
Yeah, that's pretty useful as well.

**Ellie Rofe | 27:33**
Mental.

**ray@statechange.ai | 27:34**
If I may, there's another elephant in the room that is worth checking in on, and that is your location. We alluded a bit to how expensive it is to live in as beautiful as it is there.
By the way, it does give the impression right now of just being beautiful. I think it does. When I do the calls from here, you give the impression of being more well-to-do than... When do the calls from, say, London? Guys, this looks like... [Laughter] It looks like this.
Well, if you're here, you must be able to afford to live here, you know? That's actually a good look from the point of view of Rectangles. The reason to want to be in London or to be elsewhere in the UK is simply to be on the ground, right?
You were finding that to be pretty useful before. I would propose that being in the UK will be worse for Rectangles' work and will be better for things you need to be doing in person.
It might be worth finding out where the market is. The market has been shifting. Everybody in the world is going back to their corners. SW does feel like there's going to be another major war in the next 20 years, right?
If the next ten... I've read showers, you know, rise and fall. You know what?

**Ellie Rofe | 29:01**
AL right.

**ray@statechange.ai | 29:01**
Whatever here. It is quite scary how things seem to be running in parallel. But the but leaving aside the potential for violence, it does mean that sort of, you know, nations are kind of running back to their corners. They're going back to being a little bit more local. The whole remote thing is tougher than it was, say, this time last year.
So, the... and I appreciate you going back and forth for the sake of your mother anyway, but it might be worth figuring out whether you would be better off locating somewhere that is affordable but on the island.

**Ellie Rofe | 29:43**
Yeah, I mean that in itself. So, this house, there is no mortgage, there is no rent. So, as much as there are lots of expenses to pay to make it the place we need it to be longer term, the housing in the UK is stratospheric.
So, there is that, that immediately shifts things to something like $1,500 a month for a place to live plus bills on top of that.

**ray@statechange.ai | 30:02**
2I absolutely hear that. The real question is going to be whether income swamps right?

**Ellie Rofe | 30:15**
And that's just something that we don't that's an expense we don't have here.
So it's like a it's not a trivial difference. Put it that way.

**ray@statechange.ai | 30:28**
Because the 1500 per month.

**Ellie Rofe | 30:29**
Yeah.

**ray@statechange.ai | 30:30**
But are you talking about in terms of income?
If the income is something more like $8,800 to $10,000 a month, that's a different can of tuna, as it the.

**Ellie Rofe | 30:43**
I think what I in terms of when there's enough cash flow. I think what I suspect will be a more affordable and probably lifestyle relationship saving hybrid would be one week a month in the UK. I'm trying to do face to face meetings, trying to, you know, do all that sort of stuff. Then. Or two long weekends or however it works out, which gives me more contact time with my family and help out there, and then gives me a chance to, you know, still be here. This isn't just a house here. This is my other half's legacy from his mom as well, so it's a complex thing.

**ray@statechange.ai | 31:30**
Got it, which is why you have the outright ownership situation that you do, right? It's been paid for tradition.

**Ellie Rofe | 31:32**
Yeah, yes, exactly.

**ray@statechange.ai | 31:39**
All right, now, here's my out-of-the-box idea.

**Ellie Rofe | 31:40**
Yeah.

**ray@statechange.ai | 31:44**
I'm not sure London's the place you spend a week, month, I think.
Dubai might be.

**Ellie Rofe | 31:52**
Interesting. That is out of the box, but that is where lots of people are.

**ray@statechange.ai | 31:57**
Where's the market, right? You're not crazy far away from it, so I would encourage you to just be thinking. Yes, think a little bit more outside the box. If you can afford to go miles, whatever.
But where's the money? You can think of it in terms of how do I protect my expenses? They can think about it in terms of where is my income going to come from, where are my relationships? Am I building out where there's money, there are a lot of investments, and there's a lot of money sloshing around in the... I think of the UAE as being a strong point of that in a way that's more stable than Saudi Arabia. It is highly wealthy between Dubai and Abu Dhabi, and
I've been talking to an Indian agency, right? The shocking thing is that the flight from Mumbai to Dubai is only 2.5 hours. It's a real lesson in geography.

**Ellie Rofe | 33:03**
Yeah.

**ray@statechange.ai | 33:06**
And the just the where there's ax nest.

**Ellie Rofe | 33:11**
Slave labor. From. To build it.

**ray@statechange.ai | 33:13**
I'm sorry, what?

**Ellie Rofe | 33:14**
That'.

**ray@statechange.ai | 33:14**
Yes, yeah, no, I get it. And there was a little bit of con and part of our conversation was about the racism, right? That's sort of running through that particular relationship as well.
But that doesn't really apply in terms of like, you know, you get the person with the Brit who lives in France, coming to Dubai. You've all. So, a friend of mine in college, he was a AAA, a very nice New York, very Jewish individual.

**Ellie Rofe | 33:38**
Yes.

**ray@statechange.ai | 33:51**
He was a Chinese major at Yale.
He told me that if his first plan for his career didn't work out, he would go to China and become the famous rapper. Because he spoke Chinese, he could rap in Chinese. And the Chinese associate America with rap, and they associate people who look like you and me with America.
So even though it's very much part of the African American culture, it was this very strange thing.

**Ellie Rofe | 34:15**
No.

**ray@statechange.ai | 34:21**
But I guess what I'm trying to get at is people will look at you and they will make different assumptions as you get more out of band, right?

**Ellie Rofe | 34:27**
Yesed.

**ray@statechange.ai | 34:27**
And you have the opportunity to be deciding what you want those assumptions to be. Just like my friend who looked nothing like a rapper, right? Would be able to pull off looking at a rapper because it was out of band because of course, he had the advantage of speaking the language, what have you.
But But.

**Ellie Rofe | 34:43**
No, I had a scrawny ginger friend who I met at Cambridge, studying physics, and he went out to Japan to work on quantum security and ended up becoming a model in Japan.

**ray@statechange.ai | 34:43**
But I just say we think about.

**Ellie Rofe | 35:03**
[Laughter] That was giving. [Laughter] He was never going to be a model in the UK, but he became a model in Japan.
So, yeah, I do understand what you see. I think, when you talk about things being different for women, I have been intrigued as to what that means in terms of me talking with people from the UAE, Saudi Arabia.
I know a lot of men who've gone to Dubai. I know a lot of women who've gone there to run a business. They already run there because of the tax breaks and stuff. I will be fascinated. In fact, I should probably look into it because I'm sure I wouldn't be the first woman to go there to try and create a business in and around that place. I just find it a little bit intimidating as a woman.

**ray@statechange.ai | 35:57**
I totally hear that. Not for nothing, just the very thing you described gives me an idea.
I guess what I'm trying to do is give you some ideas for things you can be looking into. Obviously, I wanted to tell you about Kwork, right, because it's another newer marketplace.
It's one, actually, that a bunch of high-end consultants really despise because the vendors are now pointing their clients to just, "Hey, go work with a Kwork person." Because the idea is that drives down costs, right?
So, I look at Upwork, I look at Kwork, these are all opportunities making short-term cash flow and increasing reputation, right? Let's turn that wheel fast. The idea of, "Let's go get you some work." I kind of regret not having thought of it before for you, right? I
think I had a misapprehension of what things were looking like in terms of the slide work. So, I certainly apologize for that because I have advised other people, "Hey, you're trying to break into this bigger industry. What can we do to be getting some wins on the board?
And these kind of like, you know, you mentor on the technical side, the mentor cruise, it's a little bit more relationship oriented, but can get you some people. Contra upwork freelancer. These are all, perfectly good ways to go in, because nothing says you need to stay there.
And you can potentially take a client with you know, and sort of take it off platform, at which point they'll kick you off the platform.

**Ellie Rofe | 37:32**
Yeah. Yeah.

**ray@statechange.ai | 37:34**
In fact, I got kicked off of Codementor for recommending someone to Demetris. As CM said, "Wait, you just recommended somebody off the platform where you're out now, which is too bad because I've been there for quite a while.

**Ellie Rofe | 37:45**
Right?

**ray@statechange.ai | 37:48**
But the.

**Ellie Rofe | 37:48**
Yeah.

**ray@statechange.ai | 37:49**
But those small things can help get the turning thinking more outside the box of like, where are these other opportunities you're looking at from the point of view of...
Well, it's here or it's the UK because it's near at hand where your thing was previously. I get it's where your MOO is now, but that's going to be how long it is, right? So, as we think about the turn of the wheel a little bit more, we ask, where is the money for you?
The money may well be in the UK, that's great if it is, right, but it might be somewhere else. Just thinking a little bit more expansively about it can be to your advantage. If you think, "Well, I'm going to spend one week away from where you are, right? What's going to be the biggest revenue generator for you?" You were mentioning women going to the UAE and having whatever challenges they do. Is there an organization, could you be of service particularly to women who are right?

**Ellie Rofe | 38:45**
I was just wondering if you were talking.

**ray@statechange.ai | 38:52**
Like talking who are otherwise? Hey, I can't get good work from these men in this highly sexist society. Can you be putting strength against weakness there? I don't know. That would be a way to get some more inside there. That could be about Pitchdeck, it could just be about brand strategy. It could be about design work.
I think one of the biggest things is how can you more closely be in the line of money, right? The pitch deck was an appealing story because, "Hey, the pitch deck leads to fundraising, and that's obvious." Line of money.
If the IR thing is not working out as line money, credit, and really capital markets are seizing up, what else is right that links your talents with the line of money? That can be the conversation I'd be delighted to have with you in
future weeks.

**Ellie Rofe | 39:46**
Yeah.

**ray@statechange.ai | 39:47**
As you get more feel of what's out there.

**Ellie Rofe | 39:52**
I think it's something I had been thinking about, and I hadn't consciously thought about turning away from Europe, the US, that kind of thing.
But at the moment, yes, Europe is as much... I love it here. Europe is slightly delusional and sclerotic, and I don't know how it's going to pull out of that. It's in a little bit of a nose dive economically.
As you say, potentially, in terms of peace as well, there's all sorts of stuff that's going on. So, yeah, it is an interesting thing. The money is elsewhere at the moment. Broadly, there is obviously money, but it's in much smaller pockets.
Yeah, I think it's consolidating. I've noticed a couple of people have said to me, "There are these big comms agencies, and they're putting together this whole package now for startups." And I think this is part of that move to consolidation that's happening across the board in lots of different places, certainly in the UK and the EU. It's... Yeah, like you, I either go, "Right, I'm going to specialize right at the spin-out stage and precede and see the seed money and then find ways that other people can pay me because these companies can't..."
That feels like scratching at the edges and trying to find some corner, but like you say, going somewhere where there is a lot of money flowing around and saying that's where I can do something for people is a more interesting prospect.
So I should get some research done on that.

**ray@statechange.ai | 41:44**
Yeah, the term I've heard before is fast-moving right?

**Ellie Rofe | 41:44**
Definitely.

**ray@statechange.ai | 41:48**
Where is the fast-moving water? Do you want me next to the fast-moving water? If you are next to the lazy stream, that can be a very pleasant place to be.
You get to focus on your own meaning, whatever. But it's there. There's not much water that's flowing through it. I had a conversation with another CEO about how he said, "We're just trying to fix the hole in our bucket.

**Ellie Rofe | 42:11**
Yeah.

**ray@statechange.ai | 42:12**
And problem was that the problem was not that their bucket had a hole. It may or may not have had a hole, but the problem was they weren't actually dipping in any water because the water wasn't going to dry out very fast.

**Ellie Rofe | 42:20**
Yeah.

**ray@statechange.ai | 42:21**
They.
It has a "Who moved my cheese?" aspect to it where it's like the markets change, right? The place where you're previously finding money is the place where you will find money tomorrow. You sort of need to be adaptable to that. You are right now in a position where you are very aware and being very adaptable, which is fantastic.
So, I would not want to... I hate the feelings that are going along with it, but the fact of adaptability is to your advantage. Let's just put that to work for you. Where's the fast-moving water you were talking about?
You could be seed, you could be whatever. You don't decide those things in advance, right? You say, "Wait, I see there's a big market opportunity.

**Ellie Rofe | 43:02**
No.

**ray@statechange.ai | 43:05**
There are people who have technical insights. They have a way of doing things that's never been done before.
Then they go and do that. That's a lot of invention-based businesses, but most of us do market insights. This is where the fast-moving water is, and it's fast-moving water that I know how to access. I can sell that.
That is, I think, just a little bit of... You're discovering that right now, right? You are in a moment right now, which, for all of its negative inside aspects, makes you more receptive to listening to the market saying, "Hey, there's something here I can actually take advantage of." That good bit is what I want to hang on to.

**Ellie Rofe | 43:52**
Yeah.

**ray@statechange.ai | 43:52**
Right? Then try to remove the other parts that make you feel worse and the two are worse. To remove the poverty and try to remove the sad, but keep the... Let's be receptive to finding that out.
We find that out by getting into the market. That's why you... Hey, go try some stuff in Contrado. Go small. Your job is to win gigs, not to post, not to sort of be in there, but to...
All right, what do I need to do to win this business?

**Ellie Rofe | 44:27**
Yeah. Yeah?

**ray@statechange.ai | 44:27**
Okay? do it completely derisking it with you and then through that, starting to get a better idea of. Okay, this is where you think the market is.

**Ellie Rofe | 44:40**
Yeah.

**ray@statechange.ai | 44:41**
I just want to throw one more thing in there, just one final and then I'll shut up.

**Ellie Rofe | 44:48**
No, this is very helpful.

**ray@statechange.ai | 44:48**
Your use of AI, right? The Claude project stuff you've been working on has lots of potential, right?
To be something that can win you gigs, right?
Allow you to deliver more value with less time, increasing your effective rate, right? Because when people are looking at rates, the biggest thing they're concerned about is how long this is going to take. I found that if you can make the promise we will solve this by the end of this call, you can charge more than... I'm going to work on this all day, every day for the next five days, and it'll be something by the end of the week.

**Ellie Rofe | 45:33**
Yeah.

**ray@statechange.ai | 45:36**
And your use of tools can allow you to go much quicker and create a lot of credibility that goes along with that. Anyway, I just wanted to plant that seed of how we can help this thing go faster. Initially, you're not going to be able to charge more for it because you don't have any credibility in the market yet.
But as you go along, I think you'll find that... Wait, I can just bring this thing out. How about I help you with that? Then the client feels great because they only paid, like, twenty dollars for two hours at your time.
They got this amazing level of value. The next person pays two hundred dollars for it, and they feel great because they've got an amazing level of value, et cetera.

**Ellie Rofe | 46:16**
Yes, I have been trying to work that out as well. It is a really good point because I've even realized how AI was being used to do research, for example, and it was bad, very bad.
Just taking ChatGPT's first assumptions about something and just running with them. Which is why she was not just hallucinating but stuff that was... It hadn't hallucinated. It was based on poor first principles and then had extrapolated worse and worse numbers from that point.
And so it's been interesting to me. I realized I probably do use AI far more expertly than most people who are using it currently.

**ray@statechange.ai | 47:03**
Yeah.

**Ellie Rofe | 47:06**
And it feels like that is such a noisy space that I was not keen on using it.
But actually, I think like you say, it has to be part of it. It is something I do better than most people and it is something that brings genuine value when I do it. So just have to leverage it now in games and stuff and then see if there's anything I can turn into something more.

**ray@statechange.ai | 47:36**
Well, and what you're gonna find is the things that are super obvious and simple for you are gonna be magic to others.

**Ellie Rofe | 47:43**
Yeah. Yeah.

**ray@statechange.ai | 47:46**
And will help with the whole weight. I'm like when I'm spending all my time doing this work, no, it's me like what?
But why are they hiring me for this? I can just do this in 45 minutes. Fantastic. Do it in 45 minutes. And then later that will turn into the offers. All this supported minutes.

**Ellie Rofe | 48:05**
Yeah, okay, do that.

**ray@statechange.ai | 48:10**
And none of this should keep you from being open to, like, a salary position which probably gets you more cash flow faster. And I want you to do whatever you would wish to do
with our relationship here. But from where I sit, I would say two things. The first is what you are doing in terms of salaried work for 2020-2026. I would not consider it to be any part of a claim for the stuff that we're doing. My delight would be to continue to work with you, to have you both involved in the mastermind, and to have you involved in the one-on-one wherever you feel most comfortable.
Because my North Star is your success, and I'm just really interested in helping you get to where you want to be on your journey. But it's all... Every week...
It is up to you what you want to be doing, and if what you want to be doing is not having to look at me, that is fine. But if it is something that you can tolerate, I would put it to work to improve your arc and smooth your bath.

**Ellie Rofe | 49:49**
Yeah, I really appreciate that. I think I probably feel a sense of guilt, which impacts things. Whenever anyone is nice to me when I'm feeling down, it makes me cry, so sorry. [Laughter] That's just a very... I don't know, Irish or British thing. [Laughter] It's a default reaction in there.
It's not really... [Laughter] Very deep. No, this is helpful. I mean, it is helpful. You are AAA, a font of huge amounts of knowledge and a touchstone as well, and all sorts of other things.
So it's great for me. I just feel guilty that you are putting all this time in and nothing is coming of it for you. That's where my only reluctance to continuing ever comes froms.

**ray@statechange.ai | 50:55**
We'll talk about all that stuff after we've made you wealthy.
In the meantime, it's certainly my delight to continue to be part of your journey.
Okay, I've offered a few ideas. I've offered a couple of more practical, immediate things. What can we do to put our nose towards how to make this week go better for you, because cash flow is about the short term, not about the long term? We talked about a couple of things that are arcing up and some things that go into what October looks like.
That's where you might be looking at geographies, right? There are some things that just say, "What does this week look like?" There's still one more day this week that is in September. What's your game plan for how to be hitting up these marketplaces to be saying that you're ending the week and making some moneym.

**Ellie Rofe | 52:01**
So, I have been putting together the projects, testimonials, whatever you want to call them, and they vary by marketplace. I've got a suite of things that people can see, and I've been putting the profiles up in place.
Based on this, what I need to do now is just start trying to hook in some jobs at a low rate. So, I have a target.

**ray@statechange.ai | 52:29**
Two.

**Ellie Rofe | 52:30**
I don't know what the reality is in these marketplaces. That's
why I'm terrible at setting targets in general as well. But can I get 20 hours of work this week or something out of applying for a certain number of jobs? There is a slight constraint in that. I don't know what it's like in all the other places, but Upwork, for example, you have to buy credits to be able to apply to things.
So, there's a limitation there on how many credits I can buy, which isn't ideal, but that's the plan. So, I think the next hour looks like me going and checking out some of these other marketplaces.
Maybe the hour after that is me putting together a list of the ones I am going to set up profiles on, and they'll be probably in two parts, one where it's mentorship and one where it's just execution, and then after that, it's just hammering applications or proposals for gigs. I do need to finish off the research into Annie's figures and get her deck done this week. Chase up that payment to clear those Veight payments.
Then, I've followed up with AJ to see if I can get that deck done at least. But I think that to me seems like the focus this week is seeing what I can get from Upwork or seeing if I can get some stuff happening there.
So the wheel is turning.

**ray@statechange.ai | 54:17**
So one more thought as it relates to the upper thing cheating. Are there people in your network? Actually, I might even think of Robert, who needs not a tiny amount of help.
Doing to a student needs some help, but he's actually not working with B or other people who... I'm glad to put up your stuff and say change as well. The cheating part is they have hired you to Upwork, right? Eat the rake.
It's not that much money, right? You're looking to do work, you're looking to add your portfolio, but you're looking to get the review. Nothing wrong with that. So, as you look, "Hey, how can we get the work from Upwork?" You might find there are people in your more immediate vicinity who are like, "Wait, you want to do that for that price?" Now, I appreciate you don't necessarily want to be tarnishing your brand, but your friends won't treat it that way.
Wait, I get a little bit of Ellie for this kind of price, and we're helping her move the show. Inviting people to be part of the solution to help you can be helping your reputation with them as well, inspiring them to do things with you, right?
It's a little bit of a gift on your part that you're willing to do this work for this relatively low price. It could be a fixed-bid thing. It doesn't need to look like per hour or whatever.
But then they get the review right because they've done it. The pro... Basically, the tax of the 20% rate or whatever it is that upwards is going to take is in the basically what we're doing to be able to get the review from these people that shows up on the network and has a different kind of credibility.

**Ellie Rofe | 56:03**
Uhmhmm.

**ray@statechange.ai | 56:04**
So you might consider what that would look like. So as you go into these gigs, one thing you'll find is what kind of work you're willing to do. I think you'll probably find you're willing to do more for less.
That's how you get the wheel turning. But then it's, "Wait, who already trusts me?" Trust me, who might be able to do that.

**Ellie Rofe | 56:22**
M.

**ray@statechange.ai | 56:22**
And you're not even trying to avoid the upward tax. You want the upward tax because it gets you the reviews that make you more credible in there.
Then that can help the wheel turn. There are other people who... This is not... I'm not inventing this idea. Right, but it could potentially be, I think, quite a helpful thing for you.

**Ellie Rofe | 56:45**
Okay, I will have a think of who I can approach for those things.

**ray@statechange.ai | 56:50**
Yeah. If you have any questions about the Upwork stuff or if this way it can be helpful on that, immediately this week, just send me. I would love to have my hope, and I think it's achievable hope, that this week we get you doing some work.

**Ellie Rofe | 57:14**
Yeah, okay, I will get going.

**ray@statechange.ai | 57:16**
Awesome.

**Ellie Rofe | 57:17**
Okay, thanks, Jes.

**ray@statechange.ai | 57:17**
Great.
I'll talk to you later.

