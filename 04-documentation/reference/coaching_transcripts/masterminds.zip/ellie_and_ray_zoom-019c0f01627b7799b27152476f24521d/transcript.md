# Ellie and Ray Zoom - Jan, 30

# Transcript
**Ray | 00:07**
Hey, Alie, hey, you. I am okay. How are you feeling physically after a week of heart labor?

**Ellie Rofe | 00:17**
Well, not just the labor, but the fasting and women's stuff.

**Ray | 00:22**
Yes, wonderful, a combination.

**Ellie Rofe | 00:24**
And so I've finished the hard labor, and I've just started the insanity workout. So that'. It's good. I'm pushing myself.

**Ray | 00:37**
So, you know, so I read the report, and appreciate we didn't get to meet would not meet last week because that's sure what happened.

**Ellie Rofe | 00:44**
Yes.

**Ray | 00:46**
Yeah, so, you know, and I appreciate a little bit on off so like, what's going on with you and how can we be most helpful to you as we head into February, which it is about to be.

**Ellie Rofe | 00:59**
I know. It's a good question. I think I was actually planning to think about this properly and prepare for this meeting, and then I did insanity and almost threw up and then crashed out from us, so I'm slightly ex tempo at the moment. 
Sorry about this.

**Ray | 01:15**
Yes.

**Ellie Rofe | 01:18**
I think, I guess. I guess a question I keep coming round to is like, people keep asking me for help with things that aren't pitched X like the SDP wants. I mean, there is some fundraising stuff going on there and stuff.

**Ray | 01:44**
Yeah.

**Ellie Rofe | 01:46**
And I just wonder whether I should be trying something else or if it's all just the same deal, which is that if I try something else and people will start asking me for help with PITCHDEX like that, there's just a. There's just a sort of because I have a very a somewhat varied background. 
It's not like I spent ten years at Barclays and then, you know, did something else for five years or whatever. It's like I've done all sorts of stuff. I've done lots of contracts in companies. I've done lots of different things. Freelancing. 
You know, and chop and change. So maybe that's just the nature of things. But I keep looking and thinking, well, should I try brand strategy? Because it's fun and like, people seem to like it. And the pitch like the. The world of capital is topsy turvy. 
But things being topsy turvy, I'm, you know, I'm. I'm interested in how all these things link in. But am I just in a place where capital is accumulating upwards and the pool of, like, support the pool of work available for people who support people in this world is going to get more and more narrowed? Or do I just need to just get to be the best person to support people in this world? I hope this makes sense. As I say, I haven't prepared. Clearly. I'm just sort of riffing a little.

**Ray | 03:10**
Well, right. I mean, there's a bit of going to the market and finding out what they want to buy from you. If you go into the market, they say, I want to buy XI want to sell Y and say, I want to buy XI want to sell Y. There's gonna you're not gonna sell a lot of Y, you know? 
So there you're not going and this is what you would tell a client, right? It's like when they're telling you what they want to buy from you, why are you not giving it to them?

**Ellie Rofe | 03:40**
Yeah.

**Ray | 03:40**
And the fact that you the fact that I get they want to do the Y work, but, like, it's a. 
But, you know, I my read on. The reason you want to do the white work is because it's work that you've done before, that you're credible on that you like there. There's money in it, right? It was a dismayed sense story. 
And if as you dig into it, you're discovering. Wait, what makes sense in 2046 is that same. It made sense when you were, you know, last to the pool and like 2023 or something. Then, you know, just you we adjust to the context. 
And, you know, there's a bigger problem of. Wait, people don't want to buy anything from me. That's different, right?

**Ellie Rofe | 04:18**
H1H.

**Ray | 04:20**
But if you're like, but they want to buy the wrong things from me, like, that's that that's not a bad place to be. It creates income, but. 
And more importantly, it creates reputation, right? And as you increase your reputation, you're in a stronger position to tell people what they should buy. So like the like they keep coming you for brand strategy. I gotta tell you, brand strategy is a great stepping stone to other things. Relate to how do you communicate value propositions. 
And that's really what you're doing when you're talking about, you know, your, the pitch deck. And the other thing is like the pitch deck story like, you know. Mark Pearson, you know, referred a person who works paychecks to me. 
I think I refer that I shared that person with you too. Like, yeah, they seem like they're Designer, they seem to they make nice looking pitch decks. Great. Now you have. You've got this competition out there. Why are you. 
You know, there's a bit of how do you take business away from that person or how do you profit when that person gets business right? One is to be their competitor. A second one is to be their complementer. 
And what your Maddie story is a great story about being a complimenter and the and then there's a question, like, what did they want to pay for? But like that's. But what you gave her was strategic advice. 
And if you will, it was Brand' Strategy for the Investor.

**Ellie Rofe | 05:49**
Yeah. It's all completely in the same wheelhouse, which is making the implicit, explicit, making sense of chaos and wrapping it up in communication. 
That's basically it.

**Ray | 06:03**
Yeah, well, right.

**Ellie Rofe | 06:03**
Narrative of communication and messaging. BLOCK.

**Ray | 06:07**
And of course, communication is a lot, right? We once we start Describing, we can start to describe Things. Such that a lot of the World Starts to Fit inside the Warehouse. 
And, like, what we want to do is sort of then figure out. Okay, well, maybe it's a lot of the world for a specific set of people or whatever. Like, how does it then narrow to be something you can actually, you know, wrap your arms around from a marketing point of view? 
And of course, it's just me giving you brand strategy advice. But you already know the stuff. The but III look at this and think, you know, there are people who want you, right, and who want your, you know, your marketing insight. They see and like, it's maybe not packaged. Exactly the way that you thought it was going to be packaged when, you know, you and I were talking about this, you know, like nine months ago or something. 
But it is you know, it seems to be aligned with people who have real money and who are serious and the work is intelligent. I mean, that's.

**Ellie Rofe | 07:03**
Well, the people who have real money is a questionable thing, and that seems to be the thing I constantly bump up against the amount.

**Ray | 07:11**
Well, you have thep people who are one thing. And then you have people ubs another.

**Ellie Rofe | 07:16**
Yeah, yes, UBS is a slow play, I suspect, but, could be very lucrative if I can get in there.

**Ray | 07:19**
I mean, they.

**Ellie Rofe | 07:29**
I know Paul desperately wants me in there. But there's just so many hoops to jump through. And it shows how much the landscape has changed when he's talking about needing budget to bring me in there because this is the kind of thing that banks used to just go both with budget on. 
So.

**Ray | 07:52**
Yep.

**Ellie Rofe | 07:53**
It's.

**Ray | 07:53**
That's her point.

**Ellie Rofe | 07:53**
It definitely shifted.

**Ray | 07:56**
So often there's. Who talks about this? Lemkin often talks about like, top three things, right? So if you're going and trying to make a sale in like one of these larger companies like. 
Well, you know, all slow roll, blah. The lesson I take away from that is that you're actually not talking about something that's essential to the customer. If it's essential to the customer, they've got slush budget for it.

**Ellie Rofe | 08:22**
M.

**Ray | 08:23**
And it was like, well, this is sort of part of my plan for the year and love to have you sort of as part of that. That's that that's all slow roll, right? But they're not gonna pull out the slush button, the slush money for it. 
Because it's not the thing that's causing them to scream in pain right now, right? You're the headache. But my arm's been cut off. I'm going to be paying for my arm to get reattached. And me, Jill I'll deal with the headache later. The I think it might be worth the biggest value you might get from your friend at UBS is to be understanding what his top three things are. It might be that, like, he's putting you in box a, but. Box B and those top three things. 
And you might be able therefore be able to really help him in a way that is quite affordable for him because he's just using it from the slush money you're getting it from out. You know, there's something there. Now. I appreciate. 
Like the bigger organizations. Getting access to slush money can be harder, but I find senior people have access to it. They don't just spend it on their friends, right? They will get caught out for that. 
But if it's about really addressing this thing, then, you know, it can often be kind of shocking, like, well, he doesn't have that much money. How much money do you have for it? I don't know. So things only 400,000.

**Ellie Rofe | 09:37**
Yeah.

**Ray | 09:40**
And I think there's you can be, you know, drawing on that and perhaps not and certainly not depleting it and have a pretty good, you know, thing to work with.

**Ellie Rofe | 09:50**
H.

**Ray | 09:51**
But when I look at that, like. Okay. Hey, you've got something there, right? The important thing is he want to introduce me, the head of event marketing. Blah. I look at no Paul Ubs his pain and like if and if it doesn't deal with your stuff, that doesn't deal with your stuff. 
But it seems like that's sort of what the next big opportunity is when I look at that particular bullet.

**Ellie Rofe | 10:14**
Yeah. I mean, II the slight difficulty is he is in a centralized role. So he is, I don't know, head of something markets, but he then. So he has like an. A hand in research. But the research branding Strategy design is all tied up with the head of that in research. 
And so he desperately wants that to change because he thinks they need to be competitive in the market. But the woman who runs that in research and controls the purse strings has been running it for 25 years and doesn't think anything needs to change. 
So then you have it's like internal politics going on because whilst he is senior and he is important, he is not the person directly in charge of those purse strings. I don't know what ones he is in charge of. I suspect hiring but I will I suspect that's the main thing he has control over is hiring and software like ops type OPEX type stuff, but I don't know, I'll check with them.

**Ray | 11:30**
And, yeah, I mean, look, for all these things, maybe there's something nothing there. But it seems like there's a. There there's a vein to at least investigate.

**Ellie Rofe | 11:39**
Yes. And he wants me to go to London and meet with the this head of event marketing who is aware that they need something. So she. He's been talking with her and about this over the last few weeks and he said she is aware that they need help with this stuff. 
So it might not be that the arms cut off, but it might be that it's a migraine, not a headache.

**Ray | 12:04**
Yep, and then like.

**Ellie Rofe | 12:06**
So? So I'mcrape it out.

**Ray | 12:10**
The one final thought I'll just sort of throw into there is that Paul might be the customer. Which case you're trying to find out who top three things are, he might be your coach, in which case he's telling you what her top three things are.

**Ellie Rofe | 12:22**
Exactly.

**Ray | 12:22**
And if you could be focusing the conversation on those things, then you get to significantly shorten time frame because you get access to the kind of slush money and. And for that matter, it's just about impact, right? All it all lines the right way right makes the thing speed up for you. It creates a lot more value for them if you're focused on something that really matters to them.

**Ellie Rofe | 12:40**
Yeah. So what I'm thinking is, Paul is effectively my champion in house. He has influence, he has a lot of influence over a lot of things, but he doesn't have the final say over anything. I don't think. 
And so I he said, let's meet up in London. I'll arrange a meeting when you're next back, and we'll meet up for lunch first, at which point he can give me the lay of the land. I can ask him the honest questions. 
And we can. We can. Then. You know, I can work out whether this woman who is running multiple events around the world for UBS, not just the one that Paul is particularly involved in, which I think is a bit of a flagship one, but she might have need across multiple things. 
So she might become, like you say, the actual client person who really needs me across multiple things. And Paul becomes the person for this specific event and the sort of internal champion or whatever.

**Ray | 13:48**
Okay, cool. I mean, I look at ubsing, I think it's pretty exciting. I think it's something where, like, you do any amount of work for them. It not only brings money in, but brings brand reputation. Wait, now I'm I can fit you in after my next meeting with UBS. 
That's a good thing to be able to say. I yeah, I remember my dad used to talk about that. Like he would, you know, get a client, like a relatively small engagement with something like IBM because he's doing strategic consulting and the. 
And he would then do, like, a survey, right? Because he, you know, they're asking him a question. And so the way he would answer it would be to go talk to a bunch of other companies. And of course, he was saying, well, I'm currently doing this for IBM and now they're associating him with, you got that kind of big client. 
And because that was sort of a sales wheel for him. Okay, that's super cool. So the. The. I mean, there's a little bit like you're doing some operational stuff in here, but it seems like the other sort of outward facing thing is the SDP thing, which is like their basket cases. 
So? They don't have any money?

**Ellie Rofe | 14:47**
Yeah, it's an interesting one. So, I spoke when I first spoke with the chairman, about Brown's strategy, and he just wanted to talk about visual guides and stuff. And I said, you don't need a visual guide. You need strategy because there's not you can't like, I think the thing that hit home at first of all I talk I love. I actually took my own advice for once in terms of pitch, and I was like, why now? 
And I was like, there's a timing window here. Everything's exploding, and that creates opportunity for a small party like you. But it will only last so long before things start to coalesce again. And. 
And so I talked about the timing window. But I said your color scheme is red and blue. You are the colors of the two most hated parties in the UK not the most hated, but the ones have collapsed. Everything maybe you need to consider how you're coming across and stuff like that. 
So they were really on board, but they kept. I just have to say this because I think you'll may appreciate the lunacy of it. They kept saying that their big strategy was elite capture now. I [Laughter] yeah, exactly.

**Ray | 15:58**
That's a strip.

**Ellie Rofe | 16:02**
I said, what does that mean? 
And they said, well, we're going to spend the next year or so, like convincing people from the media and academia and politics to and finance to, like, come over to the SDP and I was like, a that's not really a strategy. 
That's just table stakes for a political party. Like you have to be constantly trying to convince people to come over to you. But the fact that you're all running around calling something elite capture, which, by the way, is a phrase associated with rampant corruption. 
It's not a good thing. I don't think they even realized that, and the fact that this seems to be your strategy is alarming. So I sent them a thing which was really it was almost just to say, I'm out. This is ridiculous. Saying if you really want to do something like this then. 
And it was based on a tweet that the leader had put out saying we need a breakaway elite. And I said, elite breakaway is a far more interesting prospect. You say there are people in all the institutions who know how they should be run, but they are ideologically captured. There's problems in them. There are, you know, there's ossification in the system, there's issues, blah. We will be a home for you. Come to us, talk to us, tell us what's going on. We. 
And then they become the keeper of secrets because they know all the people in the institutions, whether it's the NHS or the civil service or the police or whatever, who are ready to break away. They is democratically unimpeachable. They're saying there are brilliant people in these organizations. We need their like we need their expertise and understanding. They're not slagging off people. 
It's like there's loads of ways in which it could be incredibly powerful, and there's ways you could create like a citizens version of it, et cetera. And I said, this is the kind of thinking I would be doing. I'd be looking at what you're talking about and how you can actually turn it into something that can be a campaign, that can get you coverage in the media, that can actually tell donors you have a plan. 
Because if you're asking people for money and they say, why, what's your strategy? And you go, well, we're just going to go and keep asking people for money like this isn't a plan. So they didn't reply. 
And then I spoke with one of their biggest donors cause I wanted to interview him and he was asking me to do some work for free for the SDP on something else. And I said no, because it's like pouring water into a bucket filled with holes.

**Ray | 18:32**
No.

**Ellie Rofe | 18:36**
In fact, it's more holes than buckets at the moment. 
And I am I'm not willing to keep doing that when I don't actually currently have much trust in what they're doing. Explained it sent the thing. He sent it on to the leader and I've got a meeting with him on Monday. 
But he did talk an awful lot about sacrifice. And my view is I'm not doing anything for free for them. Not just because I want cash flow in my business and not just because I want to situate myself as someone who gets paid by them, but because they need to consider this as something they have invested in. 
So if they won't put any money into it, then they can just carry on with their elite capture idea, which isn't an idea, but I it feels to me like this is a point where I can say yes or no. Now, I don't think at this stage the real opportunity is with the SDP, but I do think there is a very useful opportunity with Alister, who is the donor and he has worked on multiple massive projects with all sorts of. 
I mean, I won't go into this. Just a CV, whatever. He is a real operator. He is a very smart man. He's building this defense company. He has fingers in a lot of pies. I think him as a kind of cheerleader client, his networker introducer type person is where the real value is in this. For me at the moment.

**Ray | 20:17**
Yeah, the I think it I don't think you need to be doing the teacher lesson mode on the you know with the SDP with what it's called the SDB the which sounds too much like social democratic party idea socials the but I think you're professional, right?

**Ellie Rofe | 20:32**
It is. [Laughter].

**Ray | 20:42**
And I if I were talking to, like AA political. They call them operatives because, I don't know, they think it sounds cooler or something. But you talk political operative in the US. You know you're working for the whatever they are, they're paid. In fact, even this a little bit distorting how many of them are paid by donors. 
And therefore it's where we get these sort of extremists because donors themselves are extremists, right? And the people they hire are then sort of doing things that donors want. So that can certainly be distortionary, but like and I totally appreciate the mode of let's get people to do things for free for us. I'm all for that. I'm. 
You know. Fellow entrepreneur. I'm a Che O, too. Like, if I can make that happen, let's make that happen. But you know, you're a professional. This is what you do for a living. And the you're glad to be working with them professionally, but the.

**Ellie Rofe | 21:29**
Y.

**Ray | 21:32**
But what you found is that when they are paying you money and you are focusing your attention, not your spare time, focusing your attention on them, that's how value gets created.

**Ellie Rofe | 21:39**
Yeah.

**Ray | 21:42**
And if they want value to be created, that's the path we should do. 
And if they don't want value to be created, then we should sort. Then they should do the earth thing that will create value for them, right? There's. There's a line from. You know, I think this is from ADM, right about, like, being a like this is my profession, right?

**Ellie Rofe | 22:04**
M.

**Ray | 22:05**
So like it. Which means that I take which partially means you do it for pay, but means that that's why you take it seriously.

**Ellie Rofe | 22:11**
One.

**Ray | 22:13**
So then the reason I bring all that stuff up is that instead of a. Well, they need to decide where they're going to invest in this blah. 
That's like there's a lot of stuff that's kind of about them in that. It's like when I'm doing work, that matters. Work matters because I'm professional and because I treat it professionally. You know, I'm willing to sit here and have an hour long conversation with you. 
But then if you want to do more than that, we do something else. And now the SD p is sort of on the other side of that.

**Ellie Rofe | 22:38**
Yeah.

**Ray | 22:42**
And if they concluded that they, you know, I'm not the kind of person they would want to, you know, do that kind of work with. 
That's fine. That's up to them, but that's. But what they need is someone who they have that kind of trust in. Now, I don't know how well that sells to the person, but like, you know, that you are a professional and that there are political operatives out there and political operatives get paid. Is not. 
It's not an unusual thing that you'd be expressing. In fact, Mainflick offers are extremely well paid.

**Ellie Rofe | 23:16**
Yes.

**Ray | 23:16**
Yeah. Particularly if you're not working in the government and there's expectation. And then I don't know, like in the US, the way many political operators get paid as a paid is like a percentage of the media buy.

**Ellie Rofe | 23:30**
Yeah, that's some really complex stuff.

**Ray | 23:31**
And I'm not used to do that. I'm just like, I don't know what the economics are in the UK and like, whether it's a straight, you know, time for money deal or if there's something else, but like. The. 
If it's. If it's about. If there's just a structural thing that needs to get looked at.

**Ellie Rofe | 23:48**
Yeah, there will be some structural thing. The regulations around political party donations and payments and all sorts of things are relatively strict and quite complicated, but, my view is that's sort of for them to work out on some level. 
Like I will obviously look into it, but they need to make sure their house is in order. That's I'm not going to become an expert on political funding and regulations to get to do some stuff which will be underpaid but still compared to the value initially.

**Ray | 24:27**
Yeah, well, you don't want the STP to pay. You want this guy with asair. Is that what you his name was? You want him to be the client. If he wants to hire you to be doing work that looks into SDP, that's totally fine. 
But STP doesn't have money, and he does. And that means the only access for professional relationship runs through him.

**Ellie Rofe | 24:46**
Yeah, well, he's on the call. And I think that's basically been in my head. He's already donating money to them. He's already funding certain things. My view is, the things he's funding at the moment are some of that money is not it's not working as efficiently as it could be. 
So push some money this way so that the other money he's going to the party does more. That's basically the deal. I think let's make sure that the guy who's the head of COMS who has very little experience. Blessing he's very good. 
Like, in terms of he's smart and he's enthusiastic, but he doesn't have much experience and he can't bring a strategy together and actually hold it all together because it's too big and too complex for him. 
And he's too. Like, I wish he's too immature, but I won't go into that. But, well, you need someone who's running these things to not just like. Yeah, and then we can sock it to reform or something. It's like, no, come on, let's just try and think a bit about how we're connecting with the electorate as well. There is a big game to be played anyway. Yes, that is effectively what I'm thinking is the money that's going into the party at the moment is going into people executing, but the stuff they're executing on isn't bringing the returns it should be because there's no like strategy behind it. 
So it's just sort of drips falling into an ocean rather than actually having massive impact. And if they're going to be putting out seven or eight green papers this year, they need a strategy because just whacking people over the head with policy is not it.

**Ray | 26:39**
Okay, well, I mean, yeah, I'm TI suppose my thinking about the whole thing boils down a lot more to the who than the what or the why of it.

**Ellie Rofe | 26:39**
So.

**Ray | 26:51**
Like the party doesn't have money. This guy has money. There's a money business to be done with the guy and not so much with the party. 
And if he is just sort of screwing around with you to see if you can do more free work for the party. I think you might say, look, I've. I've done plenty of that.

**Ellie Rofe | 27:07**
Yeah. And I've, you know, I've I did him a deal. He was asking me to. I mean, it's a Sort of Typical Thing that a Man like him will Focus on. They get, like they get these Pet Projects that they're Desperate for someone to do. 
It's not completely without a rationale, but it's just not the thing that needs to be focused on about designing up this document that's been created, this like best practice thing for candidates who come on board, how they can build their campaign, et cetera. 
And I said, I'm not going to work through that and format that for you. What I will do is tell AI to format it for you and give you an HML file you can put behind a login on your Nation Builder account. 
So not as much work for me at all, but a better result for them. And I just thought, I'll do that because that's showing him that I can at least come up with a better way of doing something rather than just going, yes, sir, I'll do that for free for you. 
But I said, it's very much a favor for you, Alister. So, you know, put him in that position, basically. But I'm not. I'm not doing any more free work. I'm not doing any more like, quick questions from the head of cons about this, that or the other, because it's pointless and that's where I've got to with it. 
But yes, you're completely right. The who is much more important. And I suppose there's part of me that thinks. I guess this is why I'm thinking of it as an acid test. There's part of it me that thinks if there is a bit of a switch to be hit here where we can push these people that they are energized and determined, they just don't know what they're doing in terms of communications and strategy like strategizing that, actually turning it into something that makes sense to the wider world. 
If that change can be made, then there will be many more whos coming towards that area and I will be at the core of it. So I think that's why I just want to see what the appetite is and see whether it is worth me doing something whilst keeping Alister on side.

**Ray | 29:59**
Well, then we'll we find out. Should we move our attention off at the SDP then? Because it sounds like we sort of maybe cover that in enough detail. And then I guess this question, like you mentioned like you. 
You know, you're starting to get the pod going.

**Ellie Rofe | 30:14**
Yeah, I'm so aniso was my first interview. He's very well positioned to talk about all the different parts. Money, knowledge, power. I'm working out who else to speak to. 
And I think one of the interesting things I've found is trying to work out. And I don't know what your thoughts on this are. There are people who speak really interestingly about stuff, but I don't know what they. I don't know what reach or impression they have on the world. 
So and maybe it's just a mutual thing. I remember when I was at the film festival and someone, a producer said, every young actor, writer, whatever wants to work with Spielberg, but you've got to find your Spielberg, like the one at this level and then move up with them.

**Ray | 31:05**
Yes.

**Ellie Rofe | 31:09**
Like, am I just trying to find people where it's mutually like. And I have to. I think the other thing is I'm trying to understand where people are. I don't know what I don't know. So when people are talking about stuff, are they genuinely knowledgeable about it? Or if I interviw them, will I become less knowledgeable about something because I've been talking to someone who isn't genuinely knowledgeable about something? 
But maybe that's just a process I have to go through. I will just invite people I think are interesting or have something to say. And as I go through. I will learn. Or not.

**Ray | 31:49**
I think that sounds right. And then, like, when they're not interesting. But the I think people get stuck on this like they're trying to say, I want to ship the next thing I do. It's a good reason to not procrastinate to start some things early, right? 
So you could be finding a learning curve and then like, what you ship is sort of more downstream of those learnings. Although I'm be totally unafraid of shipping things that are the rough cut. Maybe this isn't my person. 
Maybe they don't survive as part of your thing longer term. Like when I think of the people who have done this really well, you know, people who we think about getting, like, you know, big guests in this regard. 
Like, you know, people like Patel or Friedman or whatever. They didn't start with those guests, right? They started by who can I talk to who is smart, right? And who is, you know, appealing, you know, and the and then have a conversation that drives value for my audience. I'm not at all proposing it should be like those two people, right? 
But like, if I think that model of what, you know, what creates value and then it's creating value for you because it's an interesting conversation. Like you feel like you came away. Like you like to say that you learned something and that you think it is good to share. 
And by doing that, you. That's value creation, right? For all the people who are all. I said. I say all. Probably initially. Like both people who are listening to you, or listening, watching, whatever.

**Ellie Rofe | 33:15**
Yeah. Yeah.

**Ray | 33:19**
Yeah. You know, listening on three X, you know, sort of getting let's go.

**Ellie Rofe | 33:24**
Eight.

**Ray | 33:29**
And then, you know, let's not forget that, like that same content of the conversation, then you're able to make use of that in a way that, like people in the previous generation could not. 
Because you go, hey, this was really interesting. What are the key ideas from it? What can you do to turn that into. I mean, I kind of love having the idea of like the idea deck as your carousel that comes afterwards, right? 
Like what do we learned this week? How does it connect to what we were doing before? These are all things you're able to do, you know, over and above any that's being seated by this. I'm helping this other company right now, you know with their interview vidcas series and has you know the initial thing was okay, just talk to your own staff right about like what he had learned because he's like a smart guy. Interesting. They got their first guess I should Robert go on as a guess for that because it's about the, about MCP stuff, you know. ROBERTS in that space and great, but the why am I bringing all this stuff up? I'm bringing all this stuff up because I think if you what you're doing is you're looking for the in people who you think are interesting and relevant to the field that you think is interesting and relevant and if you're talking about the things that actually are interesting, relevant to our people, it works. 
And I wouldn't be trying to super optimize it. The what the hermosi thing, right? Of more better new right? I think right now it's like more. And then based on the insight, you figure out, is the joy just doing more of this or does it need to be better?

**Ellie Rofe | 34:52**
Yeah, H.

**Ray | 34:59**
Because more can lead to better. Just on its right through climbing learning curve. And then, like, do I need to retool it to make it better, or do I need to come up with a thing that's new because this thing has played out? 
And I think that's a fine question to be asking, but I suspect you're on the early side of that. CRI.

**Ellie Rofe | 35:12**
Yeah, definitely. Okay, cool. Just start asking people. See how I go. It's interesting because there is AI suppose partly I was like I was. There is a somewhat of an opportunity cost to it because you have to research someone and understand them enough to get the right questions in mind, or to be able to listen well enough to know where else they might be able to dive into and stuff. 
But I still think that you're right. Like, it's just having conversations. I'm pretty good at listening and having conversations. I probably don't need to do two days of prep for every person, so.

**Ray | 35:58**
And as you do more of them, you'll get more confident your cost per session will go down. So I would not be totally worried about, you know, I mean, yeah, you'll be initially neurotic about it. 
So one, don't compound it by being neurotic about the neurosis. Like, it's like, okay, you want to do some more prep, you just do more prep. And then you'll gain the confidence. And then that will come to the other you. You'll get to the other side of it, and you'll have a much easier time with those, you know, conversations and like.

**Ellie Rofe | 36:26**
Yeah. Yeah.

**Ray | 36:27**
Because no one. No one's gonna be doing this for polish, right? They're gonna be doing it for, like, what are the. What are the good ideas that are coming out of this?

**Ellie Rofe | 36:38**
Yeah. Okay.

**Ray | 36:41**
These other folks have eventually gotten to a higher level of Polish, of course, but like, people don't listen to them or watch them because of the polish. 
Like it's like, wait, Patel's going to go talk to us. Sam Albin that's interesting, right? And let's or talk with Carpathy, right? Which he did like he was able to get some good controversial takes out of Carpathy, which I thought was that's where the real value is as an interviewer, right? 
It's not about what you say. It's about what does the guests say that's actually interesting and engaging and getting people to think.

**Ellie Rofe | 37:16**
Yeah.

**Ray | 37:18**
I's seen you do that. You're a wonderful interviewer. And for you pull ideas out of people, and I think you could have some really good stuff that way.

**Ellie Rofe | 37:28**
No, I think you're right. I just got to stop overthinking it and just get out there, just start interviewing and sort the scene out. I think that's probably the most important thing to sort out what's going on in this area. I need to sort it out. 
But. Yeah.

**Ray | 37:45**
What do you want all that bit to look like to be sure the. Yeah. And, like. I will tell you that the. The one thing you can do in that kind of situation is you. I got a very cheap, you know, hanging cloth that like, hey, if part of you is good and part of you is not, you can just, you know, use that and just sort of. You can always preview it by looking at the camera. 
And I only bring it because this stuff doesn't have to be expensive. As a solution. You don't need to go create a set or whatever. It's like. Or even your background right now. Like, which part of it is sort of part you're uncomfortable with? How do you solve that? You can just solve that part and, like, do a little bit of Hollywood magic.

**Ellie Rofe | 38:27**
Yes, I'm going to Nix's around this weekend. And so I'm going to ask him to help because he is the practical man, and he can, you know, put up jigs and jibs and all sorts of stuff like I might need to get stuff in the right place. Whatever.

**Ray | 38:47**
JACKSON Jill, that, by the way, that's a podcast episode.

**Ellie Rofe | 38:51**
[Laughter] I'll talk to the people.

**Ray | 38:54**
But I just I love the idea of you doing a hard tech podcast.

**Ellie Rofe | 38:57**
[Laughter].

**Ray | 38:58**
I think they're I think there there's juice in that. 
I think your knowledge, money, power, you know, triangle. I think there's, you know, there's marking juice in that, too. There's just there's so much you can do.

**Ellie Rofe | 39:10**
Yeah, absolutely. As I went through, I was like, there's so many questions and so many ways to talk about this. So, yeah, I will just start going and asking people for the talking for their talk time, basically and learn from them. Yes, definitely. 
Okay, to bring that round to the beginning. I was thinking of this as a way to bring people into the pitch side of things, and I'm not sure where the brand strategy sits because I'm just a bit like. I suppose I feel like if I go right, people are asking me to do that, then sort of some sort of formal strategy. Strategy and some sort of form comms is always involved. 
But, I suppose the marketing side of it, I find like I feel like because background is so varied, I don't have. I'm still. I just. I end up in the same track record issue again. I spent six months trying to find people to build a track record with PITCHDEX. 
That's not really happening. I've done lots of work for nothing. Or very low. And you know, partly because of the fundraising environment, partly because some of the founders and businesses weren't as strong as I thought initially or even didn't think. Just did it as a favor. They're not going to become success stories. They're not going to become a track record beyond me being able to show I what work I did. So.

**Ray | 40:59**
Well, Alie text isn't going anywhere. And when I think about, like, there's two big stories like Oppotech and Maddy. When I think about these things, like the recent months, both of them are sinking ships.

**Ellie Rofe | 41:12**
Maddie. Between you and me and the gatepost, I think. I think there are two structural flaws in the business that I don't like. 
I think we've done everything we possibly can to get her a raise, and she might get one, but she's. She's got some follow on funding, but I don't know how much at this point. I haven't spoken to her for a wee while. There's one risk aspect, which is that she needs to be able to build shear into these sensors. Shear sensing, and that is a six month project, and it's pretty much stop or go. 
It's not like, and then we'll do this, and then we'll do this. If the materials don't work in the way that she thinks they do, then it just might be that's not going to have shear. There are people asking for it just with pressure sensing at the moment and that's great. 
Like people top like Manus CEO talking with her about it for their gloves and stuff. So it's not like she's out of the running. And in many other ways, it's really advanced and better than other materials and or options. 
And the other thing is, I think part of the reason she really needs to raise is because their financials they've had a couple of contracts go at the end of last year. And so I think her financials are down. The swanny and I suspect in due diligence people might be like there's not really this is we're rescuing something here rather than helping it build. 
So I don't know, a pillows like.

**Ray | 42:51**
Just. Yeah, please go ahead. I'll tell my story about.

**Ellie Rofe | 42:56**
Okay, Apilate Tech, the CEO is absolutely determined. He's done it for a long time, but antimicrobial resistance is not a space that gets a lot of funding at the moment. 
It's he probably he should be. I'm going to check in with him because I was thinking February is when the grant the big grant that is given Carbex to antimicrobial drugs should be coming through for him. 
If he gets that, he might be able to raise off the back of having that, but that's a big if. Because he was too early, because he'd split his time down. Those two different paths rather than pushing everything into one of them. He might raise and if he does raise, that will be a big like a big story because helping someone raise that the question is how much he is going to recognize that I've helped him on any level. 
And giving a testimonial. But he's already told me I can use the deck so to.

**Ray | 44:02**
You don't use the deck, so that's that'll be how that goes.

**Ellie Rofe | 44:04**
Yeah, I guess.

**Ray | 44:07**
Well, I mean, like, yeah, go.

**Ellie Rofe | 44:10**
No car. Come on.

**Ray | 44:12**
Well, how much credit is he going to give you this? Different from, like, I worked with him, he was a success. 
I think that's the most important type of testimonial, right?

**Ellie Rofe | 44:19**
Five.

**Ray | 44:20**
The person who is out there saying I was a success and, you know, I'm giving credit to Ellie that would be good, but actually, I think that that's marginally better than him just being a success if he fails.

**Ellie Rofe | 44:31**
H.

**Ray | 44:32**
He says. 
But Ellie was great. I don't think that helps a whole lot, right? So when I think about like what the contributing factors are, it's like you're just sort of rooting very successful do what he's doing to the main thing is, it's a good point. I actually have just. 
I've been in this other transaction with a company that is, sort of. Well, actually, with Toby Oliver. I don't know if you know him over at Bravo Studio. He's a CEO of Bravo. And, you know, where I sort of had a notion of like of a direction of opportunity with AI apps. I thought he could have, you know, some special advantage. 
And I was trying to encourage in that direction. He's like, hey, we should do the more stuff together. So we started to work this thing. And then I discovered that like a couple weeks after we started working together, he ran to his venture capitalists and got them to write another check to, you know, presumably for a new business, which she then poured into the old disks.

**Ellie Rofe | 45:21**
Right. 
Wow. Okay.

**Ray | 45:31**
So, like, this is a. And like, it took me a few weeks to figure out this what was happening. And then once I did, you know, at first I'm having a little bit of pushing on him and then like his some of his other team members, like, wait, are you just trying to get fired? What's going on? The answer is yes. I am trying to get them fired because it's turning into a jobs program. 
But I finally sort of had it out with him just last night, and I sort of laid out. This is what it looks like.

**Ellie Rofe | 45:55**
Yeah.

**Ray | 45:56**
And it that this can't stand, or rather it can stand, but I'm not standing next to it.

**Ellie Rofe | 46:02**
Yeah. Yeah. Yeah.

**Ray | 46:04**
And so he'll he's going to figure out what he's going to do. 
But I think he recognizes that this is not like, a perfect way of doing things, and he's only doing it to, like, you know, try to save his people's jobs. But the fact that he has good intentions of heart doesn't make it a good use of funds and like completely pollutes the ability for it to be able to raise capital or do things in the future like this is not okay. 
So it needs to either get fixed or I just need to walk from it. Now, why do I bring that? I bring that up because I've seen the situation you're talking about. I'm like, wait, does this look like the rescue? 
Right? And so there's value, I think, in you being able to be a counselor to say this looks like a rescue, but the fact that it looks like a rescue doesn't mean that it has to look like a rescue or it just has to be a rescue, right? 
Like what's the really good part of this? How do you have a new investment really make impact? And a lot of that involves having to do some ugly things, like sort of talking about the whole jobs program thing. 
Like, yeah, he's that he has. He's hired a bunch of people who he can't afford in his old business. He can't just book them to the new business and, like, have it suck up the money that way.

**Ellie Rofe | 47:11**
Yeah.

**Ray | 47:13**
No. It's a. You have to have a capitulation. 
And if you do, you can clean the decks and then the new dollar goes further.

**Ellie Rofe | 47:20**
Yeah. Yeah, so I.

**Ray | 47:23**
Whatever. But like. But if you don't, then you don't, and that becomes problematic. And I bring all that stuff up because having had this conversation, hearing what you're talking about. 
I think there's an opportunity for you to be that kind of, you know, senior advisor to, potentially to Maddy to tell her something she probably already knows. Just like Toby kind of already knew, you know, what I was telling him. 
And the, and if they do the right thing, there's like an opportunity for moving forward and because like, hey, because you came to her because she was impressed, and she seemed impressive, she seemed smart, she seemed to be working on the right kinds of problems. 
And, like, hey, you've got. You need to figure this thing out in six months. Okay? Now we've isolated it. What resources do you need to be able to do that? Proof?

**Ellie Rofe | 48:10**
No, we've so the use of funds we have worked through that' all above board. The. I have shifted her positioning around this pipeline that she has for her original business, the automotive, because she was talking about it being a 32 million pipeline and it's not. 
So I've shifted that because that was such a massive gap between what she was saying and what the due diligence showed that what the data room showed that there was no chance of going through it. But in December, she laid off loads of people. 
So it's just her and her. I think it's just her and her co founder now who are actually employed on any level they're waiting for, you know, there are two contracts, but those two contracts are both really dicey. One of them the team changed they shut their America branch. 
So now dealing with a team in Germany who's less committed to it. That's like twenty million of the 32 million pipeline. And, you know, there's. It's just I have shifted all the messaging in the deck to be honest without sounding, you know, like EOR, but to be talking about the major focus, the major business, the opportunity, the pivot and the idea that and the honesty that she needed to have, which is that she's not a salesp and she shouldn't be doing the sales. There should be other people she should be helping and schmoozing the sales along, especially in the robotics, but she needs teams to do the other stuff. 
And that's partly what this funding is. But it's just it's like saying. I think my concern is that to investors, it will be like saying, here, here's a horse that looks like it's ready for the knacker's yard. 
But if in the next six months we can perfect this technology to get this horse to be like fit and healthy again, then it's going to win all the races that feels to me like and I genuinely have worked through every angle and worked with her on how to pitch it. I just think. 
I think there's been some foundational structural issues. I don't think Maddie is amazing at strategy. I think she's an amazing material scientist who's very determined and resourceful, but I don't think she's been thinking clearly about it. 
And then I think I've been encouraging her to go back to people who passed on the original deck, which was a dog's dinner of like three different stories and this 32 million pipeline of stuff and say, I've listened, I've learned, I've reconvened, I've worked with the strategists. We've looked at the future and then we've got a better approach now. 
And can we come in and tort you again and like, be the founder that is adjusting and learning and proving themselves to the market and to try and get another crack at the Whip with her warm intros and stuff. 
So I'm trying to push that one along, definitely, but it's I'm not sure where it's going to go.

**Ray | 51:26**
Fair point. So would I hear that story? As you just told it, the, she doesn't need capital. She needs a co founder.

**Ellie Rofe | 51:42**
Yeah, probably. I mean, she has a cofounder, but the cofounder is a CEO she's not a CEO.

**Ray | 51:49**
She's technical, and she cofounders a CTO. Then I mean by in you're just missing part of it, right? A an entrepreneurial business is a bridge between supply and demand. 
And then, like, who would be qualified for making for helping sell that stuff. I kind of wonder whether like, you know, one of the better things you can do to help her that would help her than raise would be to have her cut in a new co founder at a, you know, straight third of the company because or potentially more like a good salesperson wants more than that. 
And like, there's being a pride thing associated with it, to be sure. I've seen it all the time with, like, I built this piece of software, but I don't really know how to sell it, so I'm looking for someone who might be willing to sell it on commission for me. 
Like, yeah, that. The. Yeah, I don't know. And I'm a. You know, sales people that. That you should be talking.

**Ellie Rofe | 52:52**
Well, it's specialist sales for the robotic side of things. We. So in the go to market, we did have a volume sales team working on the traditional business stuff because that is just volume getting out in front of these businesses and saying consumer, automotive, you know, clothing, wearables, that kind of thing. Wellness. Et cetera. 
And just saying. This is this amazing thing, and just getting in front of people and that's kind of like the process, the robotic side of things. I'm like, you can't do that. It's too small a market to have cold callers anyway or anything like that. You need someone who is someone who can build relationships with all the hundred and fifty companies that are probably your target market at the moment. 
And they will grow and there'll be more of them over time. But at the moment, it's a very small pool. So you need someone who is going to be senior and is going to be managing the process and understanding the whole thing. Someone who. Who loves the game of this. 
Because I don't think Maddie does love the game of sales. So someone who'll be like, how do I, you know, tweak this, pull this, push this, do this to make this happen. And who am I talking to, who am I building relationships with? What am I winning? She needs someone who's going to be like that to go in there and change it. 
So we built that into it. But I said to may, I don't know the compensation side of things. So she put some figures in. I didn't know whether they were right or not, but that's where they are. So it's she recognizes it. She just. 
I think. Yes. I think she doesn't want to let go on some level, and I think she has been bootstrapping for so long that she is not in the right head space. And that's why I kept trying to say to her, you can't bootstrap with this raise. You're not going to have to, like, try and raise 20 million if you only need five. 
But like, there is no point in getting this raise. And then being struggling to get to the next milestones. The whole point of this is it's meant to get you to the next milestone, to get the next injection of money to, you know, to actually achieve the things you need to achieve. 
And you can't do that if you're still trying to do the sales and operations and like, you know, hang around in the lab. You know, you need to work out where you need your team to properly be shored up, and I think it's here, so she listens, she's very coachable.

**Ray | 55:28**
Well lots of people are good at appearing to listen, right? So what we I suppose you get to find out through what actions get taken after that.

**Ellie Rofe | 55:36**
Yes.

**Ray | 55:38**
It's a tough thing, actually. When you were talking about ASA at the beginning conversation, you talked about. 
You know, Maddie. End of the conversation. Are these two people who should be talking.

**Ellie Rofe | 55:49**
Good question. I don't know if he does investment like that.

**Ray | 55:53**
Forget about investment as sales.

**Ellie Rofe | 55:56**
Does he do sales? No. He's a he's like a civil engineer who runs major projects.

**Ray | 56:03**
But he does he sell the major project. We say civil engineer like there are people who like run the accounts who. I mean, there are plenty of people who are very technical who are great at sales. 
Like the. I mean, what's the difference between a master and as and a journeyman? You know, in an old, you know, art house, it's going to be the masters make sales who like the top lawyer.

**Ellie Rofe | 56:24**
I told about it. I could certainly ask him if he knows anyone, because he knows loads of people who could be doing the sales.

**Ray | 56:27**
Yeah, I'm not proposing the.

**Ellie Rofe | 56:31**
He's building his defense thing. 
So he probably doesn't want to go and work with one, but.

**Ray | 56:36**
I beg your pardon? I apologize for the interrupt. What I meant was for her to talk to someone who knows to do how to do sales.

**Ellie Rofe | 56:47**
Got you. Got you.

**Ray | 56:48**
I don't think I'm not proposing that they should be partnering up. I'm thinking, like what? She probably needs to start with a bit of mentoring. 
So who knows how to get deals done? How can she be talking to someone who knows how to get deals done, who, you know, probably really values his time and like, okay, if that's not worth talking to, then she's going to bring that to a close. 
And if she is worth talking to you saying, hey, there's some money here. Then there's, you know, more of a conversation that gets to be at. And like, how can you help her climb that curve, right? That she obviously needs to climb? There's an element of does she need to bring on a salesp? There's an element of does she need to become a better salesperson? 
And becoming a better salesp, that's where the mentorship thing comes in.

**Ellie Rofe | 57:31**
She needs both because she'll need to be involved in robotic sales.

**Ray | 57:33**
Yeah.

**Ellie Rofe | 57:34**
She can't just be like, Oof. At that stage of a nascent market?

**Ray | 57:39**
It cannot be somebody else's problem. She will. You're totally right that she will need both. And I guess part of what I'm thinking is by having her get in the habit of talking to more salespeople and fewer fellow laborts especially for is someone who's in technical sales, right?

**Ellie Rofe | 57:50**
M.

**Ray | 57:54**
Who has success, right? That she will. 
You know that. That she's not trying to get over the. This is just some empty suit.

**Ellie Rofe | 58:00**
Yeah.

**Ray | 58:01**
Yeah, those are the sort of things I was thinking.

**Ellie Rofe | 58:05**
Really interesting idea. Thank you.

**Ray | 58:08**
Sure. And it allows you to be more right. And I think that the, you know, the thing about, you know, the X versus Y is that you are more than just the Y, right? 
And more than just PITCHDEX, because you are a, you know, smart and strategic, you know, advisor. And then the trick is just getting paid for it.

**Ellie Rofe | 58:29**
Yeah, that' is the trick.

**Ray | 58:34**
It seems like you've got some good stuff in the pipe here. Can I ask how the app went before we bring off here?

**Ellie Rofe | 58:40**
Well, I've. I've put it out a couple of times to not much attention, so I need to try and work out ways to get people to go to it.

**Ray | 58:47**
Okay, yeah, fair enough.

**Ellie Rofe | 58:48**
And if they don't and it's not the right thing, but it's out there, it's shipped.

**Ray | 58:52**
Yep, fair enough. Let me know if I can be of service to you this week. I thought that when you did that rapid stuff, I thought. 
I mean, look, the app gets whatever attention gets, but, like, it's just about, like, getting in the habit of, like, turning that wheel. So if something like that looks like something you could do this week, get value from, you know, feel free to book me up the same way you did before.

**Ellie Rofe | 59:13**
Thank you.

**Ray | 59:13**
I'm glad. Do those kinds of double check ins.

**Ellie Rofe | 59:15**
Yeah, that was really helpful. I will think about what. What can fit into that?

**Ray | 59:20**
Cool.

**Ellie Rofe | 59:21**
Perfect.

**Ray | 59:21**
Great. 
Well, you have the weekend. We'll talk and one more there. We'll talk on tu today.

**Ellie Rofe | 59:25**
Okay, have a lovely weekend. Cheers.

