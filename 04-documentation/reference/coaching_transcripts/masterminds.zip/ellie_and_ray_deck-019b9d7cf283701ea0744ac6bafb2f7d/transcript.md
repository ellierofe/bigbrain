# Ellie and Ray Deck - Jan, 08

# Transcript
**Ellie Rofe | 00:04**
Hello.

**ray@statechange.ai | 00:05**
So how do you do today?

**Ellie Rofe | 00:07**
I'm very well. How are you?

**ray@statechange.ai | 00:09**
All right, I'm experimenting. I'm using my microphone from my Mac as opposed to the microphone from my... To see whether that was the reason for some of the drop-offs I've been having in the recent past.

**Ellie Rofe | 00:22**
Well, that's interesting because I'm hearing less artifacts or interruptions, so not interruptions, crackles from your Mac mic.

**ray@statechange.ai | 00:35**
Good. Well, let if you do me the favor. Just letting me know if you hear any more drops. I'd be super grateful.

**Ellie Rofe | 00:40**
Sure, absolutely. I didn't get dropped so much from you before. Every now and then there was a slight hiss or... It was almost like a plosive issue, but yeah, I could see you had the shield on, so...

**ray@statechange.ai | 00:56**
You think that wouldn't be as much of an issue, but maybe that was. But I'm wondering if, like, in the cable, you know, is sort of tired or, you know, it's an old us BB you know, so, like, there are any number of opportunities for things to go sideways.

**Ellie Rofe | 01:11**
Yes, of course. As always, thank you very much for this. I'm quite excited. I've had a week where I've been pushing on. So I'm back, which is nice.
What I thought I'd do today, I've pushed through the website this morning, and I'm just publishing that now. I thought I've got a process, and I don't know how much you think there should be a process behind this, but what I'm thinking is I'm going to spend no more than 45 minutes selecting the right decks, because some of the decks I've been using to test are old, and I just don't want old decks because it's just so irrelevant. Things that are getting funded in 2021 are just not getting funded now.
So find the right decks. Tidy up the project slightly because there are a number of different files in there that are like old prompts and stuff. So just not a big old... Just create an archive and just dump them in for the moment.
Then push those decks through what I've currently got and review the output from them, see if there's anything that really needs to change, and if not, just fix the front end so people can easily see those things.
Then put together a post for LinkedIn.

**ray@statechange.ai | 02:36**
Okay. How long do you think that would...? What do you think is the time frame for you to do one of those decks?

**Ellie Rofe | 02:43**
I think the processing is like three minutes. Reviewing it is about 20. Reviewing the output and checking... Obviously, the snagging point comes if I see that the prompt and the system is completely not getting things right and is missing really important stuff.

**ray@statechange.ai | 03:08**
Two.

**Ellie Rofe | 03:09**
And in which case, that's a prompt iteration process that might take a little bit longer.

**ray@statechange.ai | 03:14**
Sure. Okay, I mean, that sounds good. I would set myself up.
I might even just shrink it to one deck.

**Ellie Rofe | 03:24**
Yeah.

**ray@statechange.ai | 03:27**
You're going to pull it, run it through the system, analyze it, and then it's like, "Okay, you're going to make a post on LinkedIn about it where I guess we're sharing the deck and the insight you have."
Okay, I might propose that you do... Do you have either ChatGPT or Gemini? You have all of them.

**Ellie Rofe | 03:47**
I have all of them.

**ray@statechange.ai | 03:50**
Then use both ChatGPT and Gemini. I would like you to take the analysis that came out of it, and I'd like you to run it through Nano Banana and GPT image.
It is... They produce different kinds of results and they are... And I think you might find that it becomes something that's quite shareable. It costs you almost nothing.

**Ellie Rofe | 04:13**
Yep, okay, cool, I will have a look because I, yes, I've just I actually used ChatGPT this morning and the images have leapt in quality, really leaped, it's amazing. So. Yeah. I.

**ray@statechange.ai | 04:30**
I just say make me here it is make me an epigographic based on it. And it is stunning. The difference between Nano Banana and Nano Banana Pro is very significant. And but and GP image one five model is a little different.
Like I did a little experiment on state change to sort of ask people, hey, I made two of these and like, you know, what do you like? And I person said? Total like this one better. And then later, no, actually, I like the other one better. They go different ways.
I think they actually both become shareable and they help a lot, I think, with the question of wait, how do I describe this. Like, my goodness, look at all this text. This wall of text that came out and it was covering the wall of text is great for the AI but not great for people.
And I am increasingly using the like, you know, cloud code makes me some long document. I'm like, here's why you should use res this blah. Like, I don't want to read all that. I'm. And like, how do I get that thing, you know, summarized?

**Ellie Rofe | 05:30**
Yeah.

**ray@statechange.ai | 05:32**
And. And the graphics do an amazing job of increasing the density with which we can learn.

**Ellie Rofe | 05:38**
That's really interesting. I mean, Claude has become so verbose that it is astonishing, and I'm constantly saying, "Please, just a summary." But yeah, exactly.

**ray@statechange.ai | 05:42**
No.
It is paid by the word, you know.

**Ellie Rofe | 05:55**
My God, it's excessive.
So, yeah, that's really interesting. And I think I can... Yeah, I can play around with posting those images and things. Nice.

**ray@statechange.ai | 06:08**
See what I would wish for you is by doing one of these, right, you can take what you plan for an hour and do it in 30 minutes. That's what I want for you. What I want for you is... I feel like I'm barely getting about 75% of it in the course of the hour. I want to have an easy win because I think doing that you can demonstrate to yourself a thing that is very true, which is when you have assets, monetizing those assets can be a lot less. You put a lot of time into building out your assets.
Once you have that, like, "Wait, I can do more. Wait, here's how I can do it faster." There's a little bit like, "How much trust do you have in the way they got produced?" That's the thing you can look at the first time through.
I think if you allow yourself to do that, then you can have a lot more productivity from half an hour of just doing this one simple thing for one deck, then maybe for an hour where you're planning to do three and then do the post at the end.

**Ellie Rofe | 07:04**
Yep, absolutely. Okay, so process one, check it, make sure it's not coming up with anything that's completely lunatic, and then do the image thing.

**ray@statechange.ai | 07:19**
Actually, I might propose part of the way you do the check is through the image thing. There's a little bit of looking at it as an expert.

**Ellie Rofe | 07:28**
Yeah.

**ray@statechange.ai | 07:30**
So... There's a little bit maybe even get the AI to do the checking for you, which there's something fun there. "Hey, okay, Claude came out with this output. You can put it in the output, put in the presentation, and give it to ChatGPT, but I don't know how well that worked."
But I do think that getting the image right might actually give you some insight of. Wait, no, that's totally off. How did you come up with that idea? Wait. It came up because of the question I asked, "How by re-sequencing the asset generation could you reduce the time that you need to spend on the review?"
Because look at this whole thing. The 20-minute review is the biggest thing. So I'd like it to be a combination of you feeling like you did a higher quality review in less time. Higher quality doesn't require you to do twice as much time.
I think there's actually... Through use of assets to reduce that for you.

**Ellie Rofe | 08:26**
Yeah, I probably am a bit resistant because I have. I have seen how, basic AI is at just reading a deck and actually giving feedback on it, so the I'm a bit like, am I yeah, I'll test it. Do you know, I'll just test it.

**ray@statechange.ai | 08:47**
Or remember the... The graphic is the analysis is going in, not the deck.

**Ellie Rofe | 08:54**
Yeah, I'll test it. Absolutely.

**ray@statechange.ai | 08:57**
Yeah, and Super Gears.

**Ellie Rofe | 08:58**
Yeah, I trust AI a lot at the moment, which is fine, which is necessary, but yeah, it feels like some of the problems are getting better at certain things and worse at others, so I will...

**ray@statechange.ai | 09:12**
That's a perfectly fair observation, and not for nothing. That's a great observation to bring to your content because that's partially showing you being an expert, right, in both the immediate domain, but how to use AI to get even more out of it, which says you're very efficient with their time.

**Ellie Rofe | 09:19**
Y.

**ray@statechange.ai | 09:31**
Blah.

**Ellie Rofe | 09:32**
Yeah, I used it in the feedback carousel this week, which was good. We're getting there.

**ray@statechange.ai | 09:42**
Alright, okay. It seems like you're off to the races for, you know, getting get getting today. Going after a tougher last week, and I'm so glad to.

**Ellie Rofe | 09:50**
No, thank you.

**ray@statechange.ai | 09:51**
If you don't mind my saying so, you look a lot better than when we spoke on Tuesday.

**Ellie Rofe | 09:57**
Yeah, I've been fasting again. That always resets. That helps after an illness, I find.

**ray@statechange.ai | 10:05**
I'm just experiencing too many of my Brit friends ill.

**Ellie Rofe | 10:12**
I know.

**ray@statechange.ai | 10:13**
And you live in Britain, you know, it's all it's like ex pat Britain. I don't know what's going on with that.

**Ellie Rofe | 10:20**
Well, I did go back to the island, and everyone has had horrific flus and things there this year, so...

**ray@statechange.ai | 10:22**
You did.

**Ellie Rofe | 10:29**
Yeah. I think. I think it's. I think it might be a psychic manifestation, who knows? [Laughter].

**ray@statechange.ai | 10:37**
I think you're off to the races. Is there any other way that they can assist us? To you this morning before we... Then what? We're meeting again a little later this afternoon, right?

**Ellie Rofe | 10:43**
Yeah, no, that's perfect, I will crack on.

**ray@statechange.ai | 10:48**
Fantastic.
If there's anything you want to share, just send it to me or email, and we'll talk at the end of the day.

**Ellie Rofe | 10:55**
Okay, thanks, Ray. Cheers, care.

