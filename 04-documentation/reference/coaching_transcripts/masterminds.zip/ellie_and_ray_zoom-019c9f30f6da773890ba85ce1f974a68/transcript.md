# Ellie and Ray Zoom - Feb, 27

# Transcript
**Ellie Rofe | 00:03**
Hello. Hi, how are you?

**rhdeck | 00:06**
Recording in progress. So many things are all running at the same time.

**Ellie Rofe | 00:15**
[Laughter] I know the feeling. I keep having to switch off the 17 different AIIs I have running or whatever.

**rhdeck | 00:24**
Yes, and the and now I have AIIS that spawn AIS like. No. There's. There it's. It really changes the way one needs to think now. Like I'm a fan of deep work and the principles around flow.
It's a lot harder to get that when I'm popping around.

**Ellie Rofe | 00:45**
Yeah, M yeah.

**rhdeck | 00:46**
And yet there's a lot of value to be created by letting them do the deep work, right? But like, what's the sort of the high level idea I need to be, you know, managing?
And yet where do I then build up the ideas that are then go to feed into that like that's any right as a workflow thing I'm trying to spread out how has you know of course I've read your report and congratulations by the way on the billing.

**Ellie Rofe | 01:15**
Thank you. Yes, we're getting there. There's movement happening.
Yeah, it's. I mean, as I say, it's mostly been, I think, of weeks like this, a bit like an establishing scene.
So, like, you know, when you kind of come into a film and they show you where you are, and I'm like, right. I've just kind of established myself a little bit, in the thing, rather than or just sort of stepping out of the river for a minute and just working out where everything is flowing and what's going on.
So it's been really positive, I think overall. Obviously, billing helps. I've got a trip back to the UK next Friday evening, maybe Thursday. I'll go decide, and I'll be trying to meet up with people there then.
But actually, a lot of this week has been doing. Exactly what we opened with, which is trying to work out how to use things in a way that... I've actually... What I've found working on the front ends of ChatGPT or Claude, whatever, is that I find them far worse on some level for distraction and dipping in and out of things.
The other thing I found, which I was increasingly struggling with, was the output, because the output itself was so voluminous. Especially with Claude, you could yell at it, stop giving me 200-page responses because you're trying to boost my usage.
It would still just... And here's another 50-page response to one question. So managing the volume of output that the AI was coming in and then discerning what you actually need and what should be captured versus what is just noise and fluff, I found that was getting quite extreme as well.
What I found working more with OpenAI is that because it has access to things, there's just a process. So when it goes and does the first stage of research for me now, and I probably could have set this up with Claude, but it just wasn't... It just didn't feel as simple. I got it set up the whole research schema for me in Notion.
So when it goes and does the first stage, it then adds an overarching note summarizing what it's found.
It extracts useful statistics or claims from various reports and adds that to a claims database. All tagged and linked. It adds follow-up questions that arise from it that again can be prioritized, tagged, shifted around, or based on a specific area of research, which I can then use when I'm researching the landscape in the industry for calls and interviews and things, but for when I'm doing client work, when I'm researching.
So I might be researching a big question like, "Where is money actually moving into hard tech from how much is actually moving?" What's the reality of that situation versus noise, etc., as an area of expertise for me.
Then I'll be looking at, like, "Who are the Green Party?" as part of my work for the SDP, and it's all coming together. And then I have a printout of a report. I think this is increasingly going to be my environmentally unfriendly... Things I need to really think about and study are printed because I do think the context switching is too much sometimes. It's delightful.
So this morning I have been going across Telegram, chatting, and doing bits and pieces. The gateway dashboard, because sometimes I like using that. VS code I've been using this morning testing antigravity into Figma. Their AI is running.
So that orchestration feeling can work.
When the AI is set up and they're running properly, that orchestration feeling is incredibly powerful. But when you're then debugging things or just waiting for things to run and stuff that I think you have to say that's not my entire day.
There is a point where I go away and I learn something, research something, think about something deeply, rather than just rub the genie lamps.

**rhdeck | 06:37**
It's like this is study cells. The idea is like you're going to have a meeting with a client.

**Ellie Rofe | 06:41**
Yes.

**rhdeck | 06:44**
That's what you're doing with the machine. What we talk about orchestration. You know, the we had, it was I think it was maybe on Wednesday. Mark Pearson. You remember Mark. He's sort of he's a fairly brash guy who likes to really take over the conversation, but, you know, he was pushing on was this idea of, like, how do you.

**Ellie Rofe | 06:58**
Yeah. Yeah.

**rhdeck | 07:02**
How do you manage all these agents, right?
And he's talking about, like, how orchestration really matters. I was trying to push back on that a little because I felt like that sort of. You being a secretary to the whole thing, you know, like you're just kind of making sure of everything was moving around like.
And there. There's a mechanical aspect to that, but it seems like something that can and should be delegated itself. It's like, "What is it that you need to be doing?"

**Ellie Rofe | 07:23**
Yeah.

**rhdeck | 07:23**
The word that came out, I think, Senator Lo Hoki at the moment, I think was closer to correct is that you need to provide leadership, right?
How do you think about delegation? It's about leadership. Some of it is about the management of it, which is the more mechanical task, but the elevating task and that... How do you provide leadership?
Well, you go into the room, you're able to provide that leadership, but if you're just doing that all day long, you're not going to be able to keep on doing it. What do you need to have? A couple of hours of that or a couple of sections of that and a lot more, and that's what you're getting at, right?
Okay. Where am I building up the ideas that allow me to provide that leadership?

**Ellie Rofe | 08:00**
Yeah.

**rhdeck | 08:00**
That part is slower. So I think the deep work, if you will, is no longer on the shipping side, it's on the city side.
You're finding that reading paper helps with that, which makes a lot of sense to me because I think about your comment about doing morning pages in the garden, right? How far away from the screen do you need to be in order to be able to have that cation to actually go write, you know, four or six hundred words, right? Without getting... Having a
squirrel from it.

**Ellie Rofe | 08:29**
Well, and I think there's an interesting tension now in... It's something to really play with almost in saying, as I'm reading through this, I will deliberately be doing things that on some level feels slower.
If I don't understand something, I will be underlining that and bookmarking that for later, rather than just dashing into AI going, "What does this mean?" And then carrying on with something like... I think especially if you're a curious person or you're someone who likes having the answers to things, the ability to just constantly ask questions, get more information is very seductive.
But it isn't... I think... Look, this may be me romanticizing it. Maybe we need to just go limitless on this and make your brains completely adapt to it. But I feel like there is a point at which your brain needs to take things in slowly, needs to almost be at peace whilst taking things in, rather than the context switching, rushing around. This happened almost as a sense of it has to mark certain things.
We know that memory is like that you have to mark certain occasions on some level for them to actually root that memory. You know, memory is associated with things like emotion or volume or whatever. So I think the snippet world of just bobbing in and out of things all day...
I think if you don't tether it with something that's far more in depth, I think it is probably quite bad for your brain.

**rhdeck | 10:12**
Yeah, well, I mean my famework is learn, experiment build teach right where like learn and build our in theory the slow ones build seems to be getting much faster, sort of has more feeling experiment.

**Ellie Rofe | 10:21**
Y5.

**rhdeck | 10:23**
I'll try and figure out like how to put those two things together, but like learn. Yeah, learning needs to be slow in order for it to be successful for. And we all have different tactics. You're using paper, which is fantastic. Your point about not being able to serve, you know, stock. Let's go down the rabbit hole. That idea like just like keep on reading. My sons are doing some fairly hard reading right now. One is reading Locke's first and second treatises. The other one is reading Dask Capital.

**Ellie Rofe | 10:48**
Wow.

**rhdeck | 10:48**
Okay, going on the book too.

**Ellie Rofe | 10:48**
Nice.

**rhdeck | 10:50**
It actually gets tougher slogging as you move through it because it's actually published after Carmax died and at the writing, therefore it's course. But for both of them, the thing I'm trying to get them to do is to keep moving, because otherwise I don't understand what's going on here.
If they could spend a while staring at the same page...

**Ellie Rofe | 11:11**
Yeah.

**rhdeck | 11:12**
Your point is? Well, I'm getting sockcasting thing. I just go look it up. I think both of those are... I mean, they're different kinds of problems, but they're both problems with that ability to keep on learning what I... The thing I'm using is audio quite a bit for learning. I found that keeps me from being as tempted to either go down a rabbit hole or getting stuck because the river just keeps on moving, right?
I keep on paying attention. It gives you things to anchor on, because I know when I'm thinking about something from a particular book, like I'll be thinking about the Tree or the Passage or whatever I was on when I was doing that, which is sort of crazy, but...
I suppose the reason I bring it up is that this is not a solved problem. You are, I think, quite on target to be working on that problem because people who are able to figure out how to get that long form stuff more into their brain have an advantage. Certainly this wouldn't work to my advantage, and I suspect it's going to quite work to yours.

**Ellie Rofe | 12:09**
Yeah, I feel like a huge amount of what the AI should be doing is taking executive function tasks away from you so that you have more stamina left in your brain. So, it sounds like such a small thing, but the delight when I... When the noise of having to add stuff or process stuff in motion is just taken off my plate in a way that actually functions is amazing because it means...
I don't... I think part of the reason I've really enjoyed this week is because I've felt that lifting of a certain amount of noise in a way that AI hasn't given me before. That for me... I know we talked a little bit about the differences with OpenAI and...
It might just be that I wasn't using AI enough. I probably could have just done a Notion search and got ChatGPT to do it, but it just didn't feel like it was robust enough or working well enough to do that.
So there has been a sense of lifting that noise off my plate. That noise is particularly draining, unfortunately, for old ADHD brains. So it's been... I do feel more energy in me and more concentration span in me because I'm not spending hours faffing around with software.
Faffing around with software should be a thing that... I mean, I know I've been setting up OpenAI, but that's more orchestration. But clicking buttons and the noise of that... I'm delighted that that's no longer part of my life.
I know it sounds so petty that that's something that drains me, but it does. So that gives me the mental space to do this. I increasingly look whenever I look at the landscape and what's happening. I increasingly think ideas are the currency.
I think how you communicate those ideas is going to get even more important over time because there's so much noise around it. When you look at the meta of it, you are in a marketplace where everyone is... There was some study. I can't remember the stats now I'd have to look it up again.
So China bans TikTok for children under a certain age between certain hours of the day, and during those hours, the only things they're allowed to see are math and science and things like that. Then the exact opposite happens outside of China, on TikTok, for example.
The studies they're showing in terms of what it does to concentration spans, brains, mental health, and stuff is fascinating. So when you're talking about sharing ideas, the way you have to convey those ideas to a population that is increasingly incapable of taking them in on any meaningful level is really fascinating as well.
How you bring people into an idea in a way that encourages them to take into the long form side of things... So I'm not expressing this very well, but basically, yes, you and I might be working really hard to work out how we can make sure we keep getting long form ideas into our brain because we know that that's a competitive advantage.
But how long does it remain a competitive advantage if the vast majority of the people are not interested in long form ideas? There has to be some translation and escalation mechanism. I'm not explaining that very well because it's something that's just coming through into my brain now, but...

**rhdeck | 16:04**
Well, you're not the question... Is it that you're selling the ideas? I think one of the... It's a common failing of the intellectual to think that they need to be making other people intellectual. When people aren't intellectual, and they don't want to be intellectual, the
people who are... Well, it's a wonderful book called The Dictator's Handbook, which is a study of non-democratic regimes. It's actually a really good political science book, but the funny thing is that the key to it, and you see this in literature like 1984, is the necessation right of the populace, right? They serve, they need to be working.

**Ellie Rofe | 16:39**
1M?

**rhdeck | 16:53**
They need to be... Their basic needs need to be met, but they should be focusing on their striving, actually making the economy a little poorer for something as rich as the United States... It works to the advantage more of a dictator. Freedom is found in wealth, and when it's... Because when you have that excess time that you start to put your attention to other stuff. Initially, it's going to be more towards hedonism, and then eventually, that string runs out, and you're looking for how to self-actualize, right?
That's Maslow's right. The very top one is that you really have to have everything else crapped in order to be doing self-actualization. Self-actualization is pretty often shown up in political revolutions because people don't like to be kept down.
So, there's a little bit of how society wants to manage that bit. But the ideas you're working on are not so that you can be giving everybody else those ideas or making them into... Or selling those ideas. They give you power, right? They give you the market, very least.
That's a strong position for you to be in. It's only going to be some of those ideas that you then apply, and then your applications are... That's where the writing and that's where the air things are, right?
But it's not that the stuff you take in is not going to look like the stuff that you admit because that's what the market doesn't want.

**Ellie Rofe | 18:16**
No.

**rhdeck | 18:20**
Perhaps more pity, right? But then, as you elevate, you're taking in more rarefied ideas, and you're sharing them at a higher and higher level, right?
But that's the way that the career escalates, and you need to meet the market where it is and where it's ready to buy from you.

**Ellie Rofe | 18:37**
2.

**rhdeck | 18:37**
Which sounds like you're doing a lot of... While at the same time asking how you can get the most rarefied ideas you can into your...

**Ellie Rofe | 18:44**
Yeah.

**rhdeck | 18:46**
And the more you're doing that, the stronger position you're going to be in relative to the market and to, you know, the AI stuff. If you're spending your time orchestrating, that's not time you're spending thinking, right?
That's not study. Maybe you learn how to orchestrate. That's learning a mechanical trade is not nearly as valuable as the why of it. If you know more of the why of it, the orchestration actually becomes much easier.
I think there are a lot of people who are building really fast, but where are they going? People who are building half as fast but have an idea where they're going are doing much better.
Then there are people like Pepper Steinberger, right, the guy who made OpenCLAW, who's able to do both. Don't get me wrong, it's a superpower. But if I were to pick which I was trying to do first, I would pick the why before picking the how of the speed and...
So the pieces of paper you have in your hand. Easily the more valuable thing. Then you do a bit with the AI and you're able to get leverage on that. Then you figure out what that proper ratio is for you.
Which probably changes over time.

**Ellie Rofe | 19:53**
Yeah, absolutely. Do you have...? So one of my persistent questions is, "Do you have the AI doing much thinking for you?" Not like mechanical staff or making simple decisions and things.
But if you were to start researching something, how much would you let the AI do thinking versus how much you would just constantly check in on it and make sure that you are all over it?

**rhdeck | 20:25**
So very interesting one. I was... Do you know I talk to a lot of people?
I gather my thoughts. I will write a voice memo about things. I think I did that very first time when I was helping out data with a couple of things. This can be between you and me and Fest, most of course, but where did I have a...? Comes to building an internal Parker brand? Lessons from directories.
I have something in here which was API fine. What? Yeah, right. There's a bunch of those guys in here.

**Ellie Rofe | 21:19**
Sorry, I have to snoop. I just caught that word. I'm trying not to snoop, but I just caught that word and you...

**rhdeck | 21:27**
It's totally fine. So like the, so what so okay, so this is actually just sort of a cultural thing. I was trying to understand, like, what's going on with my friends over at Xano.

**Ellie Rofe | 21:37**
Right?

**rhdeck | 21:37**
I had a look at the meetings I had done, right?
Get okay, what are other people saying? What am I saying as well?
Then if I were just to do a search, Xano did the Zoho strategic position. Blah. Click on this one. I'm not sure why it won't actually show me the one I wanted to look at. Here it is.
Okay, so here's an example one and maybe showing a bit with the way I would go about it, and I think it's giving me trouble because...
This is not... I'm not sure why it's not letting me change anything. I apologize for that, but the...

**Ellie Rofe | 22:24**
None. No, I find Claude Desktop can be a little bit buggy now and then.

**rhdeck | 22:33**
Yeah. So I'm just going to tell it to quit and then I'll bring it back. But the reason I was bringing it up is that it gives you some ideas of how I approach this problem.
Okay? I didn't waste your time with that. The way I purchase problem is number one.

**Ellie Rofe | 22:45**
One.

**rhdeck | 22:46**
I will take the data that I have, particularly in conversations, what have you... And put that into...
Okay, well, if we're just going to do that, then I'll just go over here and just do Florida. But the... Yeah, eventually maybe it comes up, but I'll take conversations and ask it to be like, "Hey, what are the common threads that you're seeing?"

**Ellie Rofe | 23:12**
Yp.

**rhdeck | 23:13**
I'll give it a bunch of data, right? As for... Okay, where do these things collide? Because it's able to think in terms of ideas and be like, "Okay, what are common threads? What are things that are different, and what do I find to be useful about that?" I use voice memos quite a bit too.
So you're talking about how to write more in a long form. I'm finding I do it through dictation. I'm able...

**Ellie Rofe | 23:36**
No, yeah, maybe it's crashing itself.

**rhdeck | 23:37**
Easier for me to do it out loud than to be staring at a sheet of paper or what have you...
I'm not sure why Claude's not coming up, but maybe that's part of the problem. Yeah, sure, but the...

**Ellie Rofe | 23:47**
Yes.

**rhdeck | 23:48**
I'll take that and then ask it to restate it, link it with other things, and see if it does homework from there.

**Ellie Rofe | 23:55**
H yeah.

**rhdeck | 23:56**
So you're about like having it do thinking for me, what I have it do is surfacing for me, right? So like what are the ideas are serve sitting in all this stuff let's bring it out. And that allows me to be in the position of, you know, creating ideas and it's sort of doing some organizational stuff, forming and looking at like.
Okay, I think these three things are what really matter. Let's go deeper with that. So there it's a rethinking partner, but I'm finding it's doing more of the if you will orchestration work right of those ideas and then feeding that back to me to come up with better you know, better hopefully bear better thinking on the other side of that.

**Ellie Rofe | 24:21**
Yes. M.
So I have... I guess the distinction I am never quite clear on is that I can... This is like a 40-odd page document, and I could have it summarized for me and extract key messages for me.

**rhdeck | 24:39**
So that was the... It didn't work great, but yeah.

**Ellie Rofe | 25:07**
But... My question is really... There are points at which the value is for me to read it, ingest it, and understand the detail and to choose what I think the signal is versus the AI, which will potentially bring other things to the surface.
So I can... With longitudinal stuff, I've now set up so that I automatically upload Krisp transcripts into super base.

**rhdeck | 25:29**
Two.

**Ellie Rofe | 25:39**
Then there's a cron that goes through them every week and analyzes them. We've done an analysis of all the different things.
I can put things into buckets so I can say, "Right, let's look at this client project and how it went." Pull out stuff to help me improve myself, to help me write case studies, all that kind of thing.
But I guess what I'm never sure of is where it's reliable, a surfacer of things. When I've been involved with something, I can see it might have missed this. It might have missed that. When I'm learning or when I'm researching something new, where is it the most reliable?
Where do you have a mental flow chart for when you decide that you want to delve into something directly without the AI being a mediator for you? That's probably my summary question.

**rhdeck | 26:36**
Big ideas are worth me getting into without the AI mechanical... How does this connect?

**Ellie Rofe | 26:40**
Okay.

**rhdeck | 26:43**
What is this person saying? That's the best thing, actually, that AI helps with tremendously. And I've...
Then there's the thing I'm experimenting with right now, which is I'm going to have an AI council where I'm able to take ideas, book a notion, an article, maybe a voice memoir, and I'll run it against five AI, five private bots, basically like having five projects because each has its own context. All run it by philosophers. I run it by...
You know my... You know my stilted version of Rosierland and Seth Godin, and added a thing like, "Okay, well, where..." Then have a secretary ask a question, "Okay, were they in agreement, were they in disagreement to help me think about my thinking better, right?"
I'm trying to make experimentation valuable through dimensionality, right? A book is essentially a one-dimensional product, right? We hold it. It's in three dimensions, but text is one-dimensional. One word follows the next, it's serial.
So that's one of the reasons why audio works well for me because audio is very good at serial. We can only really hear one signal at a time. So what? I'm trying to learn about bigger ideas.
Right now I'm reading Kurzweil's "Singularity is Near," which is interesting because of what he wrote twenty years ago about AI. He was an AI entrepreneur, right? He did translation stuff, whatever. Dictation was the big thing.
The book is remarkable in terms of how it's predicting within a couple of years of... Okay, this one D is going to hit. He's describing it. Of course, he's describing in a slightly different way, but... Okay, he's roughly on track and just gave me to think about.
Okay, how does the curve of the economics work? So having established that, let's talk about the bigger thing. It's a big book, right? So even me listening to it at two x because that's what I need to be able to do to keep the attention going.
It's still a ten-hour investment that I'm listening to two hours at a time when I'm out in the mountains. That's deep for me, right? You know, previous to that reading book, other books on leadership, on, you know, technology, on philosophy. I just finished Shari Styles, Politics.

**Ellie Rofe | 29:09**
M.

**rhdeck | 29:11**
How can I be thinking bigger than the robots do? How can I elevate my thinking?
And sure. I've read things like, you know, alchemy and, you know, the.

**Ellie Rofe | 29:20**
4M.

**rhdeck | 29:21**
I think every book that Seth Goden has written I've read as well. I mean, like just I try to just get all these things into my head over the course last few years too.
And the more I do that, the more I have ideas then that I can be helpful to people like yourself when we're talking. But kind of remarkably into the AI I am seeing. It tells me about the parents it's seeing.
And then I'm able to cross it with parents I'm seeing from, like, bigger ideas I brought in from, you know, books and bigger thinkers. I mean, it sounds kind of hokey when I say that. Like. I'm. I'm looking at this and thinking, what would Socrates say?
You know, but the, I read earlier this winter, but the, like that's but that kind of, you know, structured thinking is useful, you know, and like that that's what I find that's where I get benefit out of the reading is like what are what our big ideas.

**Ellie Rofe | 30:03**
No.

**rhdeck | 30:20**
Then the applied part, that's where I'm looking for dimensionality. Dimensionality is going to be where the AI is able to say, "Well, okay, let's..." It's like that's why I'm not looking at ever. I try not to look at just a single document or a single
meeting or whatever.

**Ellie Rofe | 30:38**
This is what we in my English degree would have called intertextuality, where something sits as part of a continuum of ideas, forms, functions, and all sorts of things, rather than just what's this thing here?

**rhdeck | 30:38**
Like. The emails, documents, and meetings with these people. Compare them.

**Ellie Rofe | 31:04**
It's really interesting. I like it. I was asking, I think, the idea of looking to ancient wisdom or all sorts of... Across time is really interesting. I was asking based on the accountability meetings in our coaching and stuff where there might be ways in which I could more reliably progress and finish things or whatever.
It kept coming up with what it then called Silicon Valley repackaging historical eccentricities and sterile products. But, it came up with an idea that I just loved, which was the commonplace book.
So thinkers like John Locke, Charles Darwin, and Marcus Aurelius used commonplace books. They didn't organize them by project, they just had fragments. They'd write down an atom of an idea, a quote, or an observation without needing to know what project it belonged to. Yet they trusted that if they gathered enough interesting atoms, their brain would eventually recognize the pattern and forge them into a thesis.
You're effectively creating an ongoing cognitive commonplace book, but you're just like more and more ideas. The ideas are there. They just keep forming into, I guess, new or agilely applied theses depending on who you know what the context is. It just gives you more expansive ability to adapt to ideas and thinking.

**rhdeck | 32:53**
Right? I mean, Seymour Pepper, who's the first ever Lego professor at MIT. I've mentioned him before, a big thinker in both education as well as AI itself.

**Ellie Rofe | 33:05**
One.

**rhdeck | 33:06**
But he had, you know, pretty firm ideas that like, you know, creativity is largely recommendative, you know, and like that what we want to do is encourage that.
But I think the other half of encouraging that is in order for it to be recumitive, you need to have more things you can combine.

**Ellie Rofe | 33:21**
More Leggard pieces.

**rhdeck | 33:23**
The way you collect all those Lego pieces is through reading or whatever it is, it's going to get more of those into your head.
I think whenever you're doom scrolling, you're not getting more ideas into your head, you're getting maybe words, right, maybe mechanics.

**Ellie Rofe | 33:36**
He.

**rhdeck | 33:39**
But like, you know what? What what's the expression that, like, you know, small people talk about people, medium people talk about events, and like, you know, great minds talk about ideas, right?
And the and ideas take a lot more work, but they are super valuable. And I think that that's what we need to be doing, that that's the study part. I mean, study's always been. I've always encouraged write the whole long form whatever, but the.
But I think there are more returns on it in 2026 than there were when you and I were getting started with this in like, you know, early 25.

**Ellie Rofe | 34:09**
Yeah.

**rhdeck | 34:11**
Because there's the temptation, not just for the Doom Scrolls, everyone can recognize Doom Scrolls candy, and that's obviously bad for you.

**Ellie Rofe | 34:20**
M.

**rhdeck | 34:20**
Trick chat. EBT is moderate nutrition.
I think your point about executive function is a really good point because that's a level above the candy. Obviously, you're not just being mesotized at that level, but it's not...
But there's a level above it, right? The fact that that middle level is becoming cheaper for us increases the returns of the higher level work. Now, if you never do any executive function stuff, then you're the philosopher sitting in a chair who never leaves a room, right?
But I don't think that's the biggest area of risk. I think the biggest area of risk is that people think, "Well, I'm being productive, and that's enough."

**Ellie Rofe | 35:07**
Yeah.

**rhdeck | 35:09**
And I'm getting a lot out of the conversations to have tpt but to like talking about some of these you know like the you know the cul the culture issue, right that I'm examining all over Asana or you this other company, you know that I'm advising or whatever.

**Ellie Rofe | 35:19**
4M.

**rhdeck | 35:23**
But those are only going to... But they are useful in a way that's multiplied when I'm able to bring in higher-level ideas.

**Ellie Rofe | 35:34**
Yeah, yes.

**rhdeck | 35:40**
People look at them and think, "Wait, this elevates me. Now it multiplies you.

**Ellie Rofe | 35:45**
M.

**rhdeck | 35:45**
The reading, I mean, I would say reading, yeah, that that's what really elevates you, and the fact that you're doing that is great. The fact that you're looking for ways to be getting more of that is great. For me. The problem. My problem is I can get stuck on a page and I put it down right. This is making me think.
And now my brain is goo right like, you know, my own, you know, attention issues. The. But the Aud Day book keeps going.

**Ellie Rofe | 36:11**
Yes.

**rhdeck | 36:12**
I can't hang out there because it's carrying me along further. And that might mean there are, like some ideas. I'm not meditating as much as I might, but that's kind of. The point is that it's carrying me through their bigger thesis.

**Ellie Rofe | 36:23**
It is interesting. I think I'm stuck between the two in terms of the pros and cons, because as much as I think maybe an audiobook is better when you're in motion, obviously, there's no point in doing it if you're just sitting.

**rhdeck | 36:40**
It can't compete with using your eyes. If you're using your eyes to read and you're listening to an audiobook, you're just... The waves are just going like this.

**Ellie Rofe | 36:47**
Yes.

**rhdeck | 36:48**
You know.

**Ellie Rofe | 36:48**
Yeah, because it's an auditory thing. Reading... What if I...? So whenever I used to listen to lectures at uni, I would have to constantly write notes, because otherwise I would do perhaps what you do when you're reading. I would suddenly just drift off and I would come back.
So when I listen to audiobooks, I'm like, "No, I missed that whole chapter because I'd gone off into a daydream." So it's an interesting one, and I will keep experimenting with it because I know that they're different modalities. Some of that, I think, is just training for me.

**rhdeck | 37:28**
He.

**Ellie Rofe | 37:28**
I haven't read frequently since I was studying at uni, and I mentioned last week I'm trying to start reading again. Much more fiction.
But this isn't as difficult as reading secondary reading on Chaucer or going into the Green Knight or something. So it's still very palatable and easy to read. I think the beauty of it is I get to look at clues. I get to understand why.
Actually, that's one of the things I've tried to replace as well. I agree with what you're saying about doom scrolling. The only thing I find useful about scrolling social media and increasingly, weirdly enough, despite it being a cesspool, if you curate your feed well enough, X is that you will find clues to people who are doing thinking, who might be worth listening to and researching. In a way that you get a little bit on LinkedIn, but because it's so... A lot of the time on LinkedIn, it can be a bit obfuscated.

**rhdeck | 38:40**
Yeah, I look for book recommendations absolutely. When I see someone who I know and respect. I don't like Dave Gerhardt once had a stack of books. He was sort of bragging about reading. I'm like, okay, that's cool.
And I just add them all to my lady list. And then I started reading all the rest of the books by those people too, you know, and sort of. And, you know what? Whatever gets you into more reading. I think there's lots you can get lots of ideas you can be gaining from literature. There's there's a lots of trash out there, but we sort of need to identify that too.
But the. Yeah, I mean, my thing about study cell ship is that my thesis is. It's twenty hours week of each.

**Ellie Rofe | 39:19**
Well.

**rhdeck | 39:19**
You know, so like, where can we find twenty how and like the, you know, to your point about reading, it's a challenge, right?
But if you can take that study part and turn that a significant chunk of that into reading, there's such equity value on it.

**Ellie Rofe | 39:33**
Yes. Well, that's where I realized that what I'm trying to do now is... This is what I mean about the executive function part of it. Instead of doom scrolling on XI, I have blocked XI so that I can't look at it because it is not very good for you.
I have got a skill, a function, where I can say, "I want to know more about this topic." I go and find the people who are doing the most interesting things on this, and then I can take distilled information that hasn't got distraction around it and go and research it myself without then having 15,000 outrage posts scrolling past at the same time.
That's where I think there's... Again, perfectly possible to do that before now, but there's something about the way OpenAI works, the fact that I can talk. You can say, "I want to know more about this topic." I can just chat into Telegram.
I've got different groups for different collections of thoughts. You can use different skills, obviously, within each group. It's all... I know that I can access all the files it's storing and hop onto the server and grab information that it's trying to take down. Or I can get it to push it straight into OpenAI for me or whatever, it just feels much more freeing so that there's more space.
So it's been working very well. But the other side of that in terms of freeing is... I'm trying to... I am then trying to work out... It feeds into what Demetrius said the other day in the thing about how to distill these things into marketing content, how to best turn these depths of ideas and information and stuff into things that can be shared and structured in a way that attracts people and makes them interested.
So that's what I'm thinking I'm working on this weekend is a way to structure my thoughts at that. And I think there's... When I was working on Google, there's the strategy part of your business, and when I work with people, I honestly think that during our sessions, I suspect that if I asked it to look at the transcripts and work it out, I suspect some of the mental overhead that we all suffer from is that your strategy is fluid, and an awful lot of the problems come from when your strategy shifts underneath you without you realizing it, and you struggle to adapt and catch up.
Sort of unconscious changes in who you're targeting or what you're doing and why you're doing it. They're very difficult to shift into how you market yourself. Then there's static information about your business, which is like testimonials and your research statistics, that kind of thing, which are just discrete pieces of information that are useful.
But you don't update a testimonial every three days or three weeks or whatever unless there's ongoing work, so I'm really rambling now. Sorry. I have been up. But I woke up at 3:00 this morning.
So I'm probably a bit in the weeds of my own brain.

**rhdeck | 43:17**
Yeah, the...

**Ellie Rofe | 43:20**
Manage all the context.

**rhdeck | 43:20**
Yeah, I hear the whole early morning thing, too. I do the same thing.

**Ellie Rofe | 43:28**
Managing the context in a way that it's easy to use. It doesn't all have to sit in your head, but it doesn't then sit dormant in documents or notes or things that are outdated quickly.
That's something I've been thinking about a lot, and I've been testing Demetrius's tool, with interest, and I love it. I think it's definitely part of a solution on some level. I don't love not being able to just go in and change things directly, which is a really interesting thing for me.

**rhdeck | 44:04**
That is... You know what you might consider doing is having open Claude take notes for you.

**Ellie Rofe | 44:15**
Yes.

**rhdeck | 44:17**
You have an idea just open up Telegram, give it and have the, have it save that into notion have it like a notion I actually have a notion a page database, whatever it's called. Fleeting notes, right?

**Ellie Rofe | 44:34**
Yes.

**rhdeck | 44:34**
You were talking about, like, the with the common use? Is that what we called it, the common use book?

**Ellie Rofe | 44:38**
Or the commonplace book?

**rhdeck | 44:41**
Thank you. The but that idea of like fleeting notes, which is that'll cast an idea right like hey, I've got I had a notion let's put it in where let's put it in notion and then you know the I saved a bunch of stuff what do we think about this?

**Ellie Rofe | 44:46**
Yeah. Yeah. No. HY.

**rhdeck | 44:57**
Well, now you can have your AI go pull out your fleeting notes and say, "This is what I think. The key thing about dictation in general for my book is that you care a lot less about the fidelity of the individual of all of your ums and as individual words and more about how well it captures the ideas."
So what the... I actually use... I'm using Mac Whisper locally like Whisper Flows, Super Whisper, these are great tools. They don't cost a lot, and they let you just take these voice notes that they will then take responsibility for cleaning up because they can...
Because they're doing it all in one pass. They have a somewhat better degree of fidelity. Then you can say, "Okay, let's just have that go to my Notion or open-source or whatever to start to do things for you."

**Ellie Rofe | 45:48**
1.

**rhdeck | 45:49**
Then that becomes an automatable flow as well. Now I use voice a lot because I talk a lot.
I found both my ear and my voice to be an unlock for me, particularly in the last five years of my life. Whereas, probably at the beginning of that period, I was doing a lot of writing and wrote a lot of essays, and now I find it much harder to work with a single page of paper.
But I can talk about an idea for quite a bit and work some pretty good ideas. So it's the executive function part that I'm having a hard problem with, right? But the ideas, they're flowing.
So how can I uncork that? That's where I'm using the voice memo thing for... But just giving your permission, right, to be capturing those ideas because those ideas that you're taking in and to your point, how can you have them come out?
Then it's like, "Well, okay, if it's... If you put it into a safe space, right? Which is like the fleeting note idea." Then what of...? This makes for a decent post.

**Ellie Rofe | 46:44**
Yeah. I mean, I have tried doing that in various ways.

**rhdeck | 46:49**
Okay.

**Ellie Rofe | 46:51**
I feel like... I might be chasing a Sprite at this point, but I feel like... What I was seeking when I was building Google for clients and what they were saying they needed was just what I needed, which was something that had a single source of truth for certain things that needed to be in place to properly market your business.
I could be wrong, but I'm going to... I've time-boxed it, so I'm basically giving myself until the end of the weekend to rebuild the underlying thing. I had loads of downloads anyway. I've already briefed it's already off working and trying to get stuff sorted for me and it's obviously flows like that compared to when I was clunking around with Webflow Wisdom, Zano and AG and you know, ably and all this kind of thing like, yeah, it's much easier.
I've got loads of the context. I've got loads of prompts. I've got loads of structure. I'm just going to test whether that is the thing that keeps me stuck.

**rhdeck | 48:12**
Okay, so... I mean, that makes sense as far as it goes to see if that continues to be the thing that keeps you... I think the most important thing is that feedback loop, right? To say, hey, this is helpful. This isn't helpful.
You know, like, what's what was decreasing the friction between the good ideas you have in your brain to be able get them out. One of my. I mean, I talked about the learning experimental tech and. And one of the insights, actually, the reason I came on bringing up this insight is that I didn't have it. Somebody in the room had it when I was talking about this framework.
Right? And the idea that, like, hey, there's the diagonals. They'd noticed that experiment and teach, which were undiagonal from each other, were both my fast ones, right? Whereas build and learn were the slow ones.
And I think that sort of ties to as there's a there's another connection between those that teaching looks a lot like experimentation and giving yourself a permission to be learning how to teach through that kind of experimentation. What you're going to teach, right? The bigger ideas.
That's what you're getting from learning in the build and the.

**Ellie Rofe | 49:18**
M.

**rhdeck | 49:22**
So all of which, by the way of saying, let's just give yourself permission to try more stuff, because I bet it's going to be pretty useful.
I'll see what I'm...
I'm trying to get at experimentation is unstable, right? So when you talk about rebuilding Google, I would be trying to learn what is the best 10% of it.

**Ellie Rofe | 49:46**
Yes. Yeah.

**rhdeck | 49:48**
That then gives you leverage on that wonderful slow if you will learn part to be able to transmit that into the market.

**Ellie Rofe | 49:57**
Yes. Yeah, so that's why I was... I was like, "Do it as lean as possible." I've got a very small portion of it compared to the original. Then it's just testing it, playing with it, and working out what bits I miss as I play with it, or what isn't quite there, or what bits I need to link into something else or however it might work.
But, yeah, I'm trying to resist the perfectionist tendency. I'm trying to resist like, let's go and make it look beautiful. You know? It's. I'm. I'm trying to resist all of that and just say, does this function? Is it doing what I need it to do?

**rhdeck | 50:37**
Yes. I have a harder time doing that with writing than I do with video, and I think it's one of the reasons why I ship a lot more video.

**Ellie Rofe | 50:44**
Yes. Okay, yeah, no, I struggle a lot with video getting there, but...

**rhdeck | 50:49**
Yeah, sure. Well, you use what you like. But the point I was really trying to get at was not to be so much encouraging video versus threading, but to be saying that the thing that you're feeling precious about sometimes it's a matter of moving to the thing next door to that because that will then unlock you from being able to ship that
because the important...

**Ellie Rofe | 51:07**
Yes, yeah, yes.

**rhdeck | 51:08**
Not the medium. The important parts of the message.

**Ellie Rofe | 51:17**
I mean, I'm sure that the recurring issue I have is that when you talk about... When you are effectively a communications expert, even though it's hardest to do for yourself, that sense of having to demonstrate via everything you create means that it is harder or it feels harder to do messy stuff in public.
Because people are like, "But this person's meant to be perfect at communicating stuff." And that's where I think I end up struggling with shipping messy stuff. But I don't know.

**rhdeck | 51:59**
Okay, that's a fair point, but I think this gets back to where we started with the whole bigger ideas versus the intellectual versus the executive function thing. You to be more successful, are more intellectual. You're working on ideas, you're getting in more ideas, you're trying things because the circumstances around you are changing.

**Ellie Rofe | 52:20**
One.

**rhdeck | 52:20**
People who look at that and say, "Well, I don't want anything to do with that, okay? They're those people who are looking for reliability. They're looking for the steady eddy. They were never going to hire you for the job. They were always looking for something that is different for you.
That's trying to say you're not reliable. I'm trying to say that's when you look for bigger institutions, right? That's when you look for a big brand agency or whatever.

**Ellie Rofe | 52:46**
Yeah.

**rhdeck | 52:48**
I see many people get stuck on this.
I saw recently a post about how if you look at what has been super breakout successful in the course of the last few months, you see OpenAI, Claude, and what's been shutting down and going bankrupt. Things like Limitless Humane, those pendants, things had beautiful industrial design and are failing. Things that are hacky. They are rough at the edges, but they are getting to something that is really valuable and iterating fast. Those things are more successful. Have you ever read Charlie's Clock Speed?
Okay, so Charlie Fein is... Now I think he's a professor somewhere else. By the time he was at MIT, he wrote a book called Clock Speed, which is his most famous book, and it is about how markets change based on their pace.
So you're just saying that faster easing... Sometimes they're slow, sometimes they're fast. Talk about how when things are very fast, like markets really start to atomize, right? The supply chain broken up because you need to have more responsiveness because things are moving at different speeds.
Then what happens is as the speeds become more known, the parts of the supply chain that work at the same speed start to combine, right? To be able to start to get leverage on capital again.
But they won't have the same shape because maybe if you have letters A through J, right? Previously, you know, EFGH were all combined because they work together. They were at the same speed in one market. Market changes, they break up and then, you know, B through E become the new, but form a chain and something else doesn't or whatever.
But the. But. But his thing is that, like paying attention to what the pace of a given market is gives you a great deal of insight as to its structure and what its structure is going to be. And so the if the funding environment is changing fast, well, that makes a lot of sense. The person who is trying things is actually going to become much more appealing when the funding market is like a known problem or perceived, at least by the client to be known.
Well, then that's going to look, like a negative. Right? And the reverse is true, like if the market is moving fast. Like the person who is, like, still talking about the frameworks they had from five years ago.

**Ellie Rofe | 55:18**
Yeah.

**rhdeck | 55:19**
They may give you a warm sense with their stentorian voice or whatever, but they're not they're their ideas are not succeeding in the market because they're now disconnected, you know, from the market.

**Ellie Rofe | 55:29**
2.

**rhdeck | 55:30**
That's where... So I would just be doing what you think is going to be in sync with what your market actually needs and how you can be of service to it. So your point is that you don't want to look unprofessional, right? There's an...
There's a certain... You don't need to be unnecessarily messy, right? But it's not the case that you need to be polished in order for the market to take it on. You want to be where the market is.
If you're working on the key ideas, and it's a little bit more rough, but you are leading with the ideas, then you're leading. When I think of you as a communications professional again, intellectual versus executive function, the executive function stuff goes away, right?
Well, we make the prettier pictures. Are we going to hire Li to do that? No, we're going to use Stitch. We're going to use paper, we're going to use maybe somebody else, but robots can...

**Ellie Rofe | 56:27**
Professional Designers.

**rhdeck | 56:30**
Yeah, and so, what's going to differentiate us when all these robots are able to do this stuff?
Well, it's not going to be making a pretty picture. It's going to be having better ideas. That's where you are.

**Ellie Rofe | 56:41**
M Yes. I like the idea of thinking about that stuff as executive function rather than the sort of the real valuable work, because that shifts my thinking a lot.
That's a nice distinct, a nice distinction.

**rhdeck | 57:01**
Well, I'm very grateful for you to you today because you gave me a way to think about that. Or a term, the executive function term, right? First of all, we haven't really thought about it in this context for thinking about what is that middle level?

**Ellie Rofe | 57:14**
M.

**rhdeck | 57:17**
What is it that we're doing with these AI agents versus what we could be doing? I was thinking about leadership versus orchestration. No, well, in the executive function thing, I think really is very much about that because it's all applied.
It is important, but not the same high level. So I'm grateful to you.

**Ellie Rofe | 57:36**
Yeah, no, I like it. It makes a lot of sense to me. So there we go. We've worked something out between us.

**rhdeck | 57:45**
All right, we're almost to the end of our hour here, so I mean, just... I'll end where I started. Congratulations on making the sale. You got that going. It does seem like there's not a lot you're doing right now in the cell part of it. You're doing lots of experimentation.
We talked about doing some reading on the study part, which I'm thrilled about the reading part. Getting that thing going again. I think it's going to be really good for you in terms of building up that equity value. Can I very quickly ask what was sort of in the pipe for you for Cell?
Is there anything we can think about for how to put the mastermind to bear use for you on Tuesday?

**Ellie Rofe | 58:16**
Yeah.
I'd have to think about that, but definitely Cell is like I almost just had a... It was almost like a holiday week to work out and play with it stuff.

**rhdeck | 58:35**
Yeah, sure.

**Ellie Rofe | 58:36**
No permission.
But yeah. Sell is back on the menu next week. That's where I want the focus to be. That's why Google is boxed it this weekend. Then it's how I'm turning the research I'm doing, the ideas I'm having, and the other stuff into
something that's useful and valuable and high signal.

**rhdeck | 58:56**
I mean, Cell doesn't need to be a slog, but I think Cell's going to be at the applied point, right?

**Ellie Rofe | 58:58**
No.

**rhdeck | 59:01**
A lot of the ideas that you've been working on... I've been working with Clock.
Who's been working with open call? Actually, we had our whole session today. It was him wanting to talk, asking largely technical questions about open call and the...

**Ellie Rofe | 59:13**
Yes.

**rhdeck | 59:15**
There's. There. There. There's a lot in there. For you. Talking about that in the market, I think can be useful too.

**Ellie Rofe | 59:23**
Yeah, yes. Well, that I won't go on, but that does bring me to the limits of LinkedIn and where there might be other ways of doing things, but yeah, see you there.

**rhdeck | 59:33**
I hear. Well, I'll look for it against you on Tuesday.

**Ellie Rofe | 59:38**
Cheers.

**rhdeck | 59:39**
Thank you.

**Ellie Rofe | 59:39**
Take there.

