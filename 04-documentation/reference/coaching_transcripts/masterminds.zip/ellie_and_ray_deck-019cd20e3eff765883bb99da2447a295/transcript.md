# Ellie and Ray Deck - Mar, 09

# Transcript
**Ellie Rofe | 00:05**
Good morning, I'm very well.

**Speaker 2 | 00:07**
Hello, Elelly. How do you do? Today?

**Ellie Rofe | 00:10**
I apologize. I've realized I did not manage to fill out that document, which isn't very helpful.

**Speaker 2 | 00:15**
[Laughter] I was scrolling through my eyes at the bottom of my... At the top because it usually filled in from the top as opposed to others who, like Deatrice and Robber, both do those as to the bottom.
Why? They just keep on tacking it on, which is totally fine.

**Ellie Rofe | 00:30**
Okay.

**Speaker 2 | 00:32**
It just...
But because I didn't see it this week... It's in March. What's going on here?

**Ellie Rofe | 00:35**
I'm so sorry. It's chaos. I need to learn to manage it better.

**Speaker 2 | 00:40**
I hear you. Can I ask how things are going in the UK?

**Ellie Rofe | 00:45**
Yeah, good. Just been busy and... I was up to beautiful Suffolk this weekend for a friend's 40th birthday party, and it was one... I'm very hoarse because the music was very loud, but I danced for five hours and had a lovely time and didn't... I didn't drink, so that made a big difference to the rest of the weekend, which was nice. Compared to when I was younger and parties in the UK would be chaos.
So, it was lovely, but my voice has taken the hit, and I met some really lovely people who... It's interesting as soon as you start talking about strategy with people who get it, they're like, "I'd like to talk to you more about that."
One of them works for a barrister's chambers, and one of them works for an architect, and I'm like, "Well, these are completely out of my pocket for me, but I'm happy to talk to you at some point. Who knows what may come?
So yeah, that was interesting exactly.

**Speaker 2 | 01:58**
Do they have. You know.

**Ellie Rofe | 02:02**
Yeah, professional companies with lots of money. Let's have a look. So that was interesting. I think what's nice is it's getting easier to answer the question of what I do, even though what I do is a bit nebulous and not really that relevant to an awful lot of people's lives.

**Speaker 2 | 02:12**
Two.

**Ellie Rofe | 02:27**
It is getting easier to answer the question. Even when it's like, you know, my friend's mum asking me or something. The. The Chandler effect. You know, you have to be old enough to know friends of like no one knowing what you do is.
And being really impossible to explain. It is gradually shifting. But yeah, got the.

**Speaker 2 | 02:52**
Right? I mean, on the one hand, works worth doing is tends to be more specialized, right? It has a smaller domain, but. But the other thing that's going on here is you're just getting, I think, more confidence in what you're doing, you know?
And it's like, I can't explain it, but it wouldn't be. It wouldn't be interesting to you. It's not that important.

**Ellie Rofe | 03:07**
[Laughter] he.

**Speaker 2 | 03:08**
That sounds so freaking British but that's just something we all need to get over, right?
If we're going to be entrepreneurs, the... I was just in a group on Thursday where they were of people who were owning professional service companies and there was a little discussion on how you can get out of selling
so you can get into the Aerosoft you like. No, you have other people do their stuff so you have more time to do selling and around the room was Ray that was the least nice thing I heard today and I want to be here but yeah, that's fantastic.

**Ellie Rofe | 03:36**
Exactly.
Yes, yeah, I have realized.

**Speaker 2 | 03:47**
That's just sort of a good. A good sign for you. In multiple regressions.

**Ellie Rofe | 03:53**
I mean, I'm still not doing great selling online, and I need to change that radically. But I do really enjoy it in person, because in person, it's just having interesting conversations with people.
And I find, rather than having to do, like, a huge amount of, you know, deliberate or contrived conversion stuff, you just ask really good questions. And the more you just ask really good questions. And people go, okay, I get it. This person understands me, the more they're like, tell me more.
So I'm really enjoying that part more. And I think I just need to work out how to translate that to the noise of things like social media or videos and things. But we're getting there. And that's I was going to say that would be a focus for this week.
But I think this week is going to be just sort of trying to manage and get through the various. I've got interviews booking in for the SDP research phase, which will be interesting.

**Speaker 2 | 04:57**
Shipping work you...

**Ellie Rofe | 04:58**
Yeah. And so it sort of probably going to be a lot of ship this week again, because there's lots of foundational research to do.
But then next week, my hope is that the. That research will need to just sit for a bit. The Desk edit. On the research. And they will just need to the draw edit would they'll just need to sort of sit for it because there's so much information I'm gathering so fast and that's.
And I just need to then let my brain ponder on it for a week and during that time I'll get back to cell study. Sort of happening consistently, just in terms of at least understanding the nature of gathering research where I can help. Obviously, I had a great call, with Demetrius and Robert, which sort of confused me and enlightened me.
But that's because I'm in the messy middle of understanding these things. And they helped me understand more about that. We're speaking again tomorrow because I think managing the vastness of this data will be very important.
It's obviously a huge landscape to understand. I think possibly it's easy to feel like you understand it, but there's... Because of the nature of what it is, there are outrageous amounts of propaganda and assumption.
So trying to strip away noise is part of the process. It's fascinating, and it's a really interesting challenge, but the cell needs to happen because I can't just keep working solely on shipping and then get to the end of that process and go, "I've got nothing."

**Speaker 2 | 06:46**
Well, that's the reason why I say steady cell and ship, right?

**Ellie Rofe | 06:49**
Yeah.

**Speaker 2 | 06:49**
It's all the same week now. I appreciate that this will be the first week in a while that you've had significant shipping going on.
I think there's... You probably don't want to have it just be sequenced, right? I'll sell next week. The diet starts tomorrow. But I certainly appreciate what you're saying that now you've got more pressure on the ship, and you want to make sure you do that well. My impression, though, is that you probably have plenty of room to be able to make sure you're moving the three balls. It's just that previously we didn't have anything really allocated.
I mean, not anything, but it was just a lot less allocated to the ship side and then they helped each other. They did reinforce it. If you're studying, you're selling at the same time. It makes a ship better because you're then taking those same insights. You're just driving it right back and improves all. Do the work.

**Ellie Rofe | 07:44**
I would agree. It's just more difficult when I'm in the UK to actually make sure I got time.

**Speaker 2 | 07:48**
Sure.

**Ellie Rofe | 07:50**
I'm happy to try and at least post some stuff on LinkedIn, but then it's like have I got time to then actually respond to kind of thing or makes up, you know, posting pay dividends.
But maybe I just need. Maybe you're right. I just need to wake up an hour earlier, chuck something on LinkedIn every morning while I'm here, and then get on with the ship and other stuff. But
Thursday I'm in London, and then I have interviews in the afternoon. I'm in London in the morning, then interviews, and then on Friday I'm in London from ten till five, but it's across two or three meetings that just staggered, and then I have to go and see a friend that evening, and so it's really...
Then on Wednesday, I may have to take my mom to go and see her sister because she can't drive, and her sister's about an hour away. She's the one... It's difficult. So suddenly it's two days where I'm actually at a laptop, and the rest of it is meetings and calls and things.
So then I'm trying to manage my expectations of the week, but maybe I just need to shift my expectations of the week and say, "Well, I just say I have a protected morning hour where I post something on LinkedIn, whatever."

**Speaker 2 | 09:12**
There are two ways looking at it. One is looking at it from a time management point of view. One line is what you described.

**Ellie Rofe | 09:16**
He.

**Speaker 2 | 09:17**
Second is to ask...
All right, if I'm only going to have 50 minutes, what can I do with this 50 minutes? How do you move the ball? The nice thing about this is that it puts pressure on. So instead of expanding to fill the hour, it's like, "Okay, what's the most important thing I can do so I can knock that off?"

**Ellie Rofe | 09:38**
He?

**Speaker 2 | 09:39**
And if it's a post on LinkedIn, which it totally could be, then like, what does what's the one post? Right? And like, it takes me a while to do that. How is it? Is there a way to do it a little quicker? I don't have my laptop. Can we just do it with a phone? These are all things I'm trying to ask questions like, "How do I make a couple more of these things happen as my day gets crushed around me?" I like to be out on my snowboard for that period, right?
Not just inside, but I actually go touch the grass. That is part of what is healing about it all. I wish I brought it up because they didn't say that you should be spending an hour a day working on this. I don't think it's an hour.
It's... I don't think it's a time budget thing. It's how can you be putting something into the market? Is it a post, is it a reply, is it a whatever? To make sure that you are not losing touch with it because that becomes something you can build around. Going to zero means everything else becomes harder, right?
It's not necessarily only additive at that point because you can't multiply by zero, but even... But if it shrinks, that's okay. How do we keep it from hitting zero? So that way you can be back on a multiplier path, that's the way I would think about it.

**Ellie Rofe | 10:51**
Yeah.

**Speaker 2 | 10:54**
So the... Man, I'm going to sacrifice an hour of sleep so I can do this. How can we do this without sacrificing an hour of sleep?

**Ellie Rofe | 11:00**
He...

**Speaker 2 | 11:01**
Is there a transit thing? Is there something on the tube? Is there, you know, these you know, being able to take that kind of time to turn into something useful and if you have found that, like, replying to things is more useful than just writing up a post, maybe it's done through replies.
You know what does it look like? They can add value and be a good use and be high return on your time, and the fact that you've got pressure on it creates an opportunity to discover what those things are.

**Ellie Rofe | 11:36**
Yeah, that's a good question. I do struggle to understand the true value of LinkedIn beyond just creating content. I think there is value, obviously. I'm not saying there's no value, it's just what is actually derived from it. The struggle I find there is because it feels like it is a platform in the process of slight insertification because the algorithms have to change and AI is changing it all and all that kind of thing. Fine.
But that it's working out where time is best spent. But yes, I think creating shit content is the worst use of time because even great content doesn't get a huge amount of attention until you've built up and built up.
So it's... I think that that's the trap I feel, and maybe that's where I need to work out how... That's what I've been trying to do with setting up Google, but I got to derail a bit by the research stuff last week was working on how to generate decent quality content at a rate that means that you can actually keep building.
I guess you can just post mediocre content and just do it regularly. But I feel like everyone I speak to who does that isn't actually getting any returns on LinkedIn.

**Speaker 2 | 13:05**
That sounds about right. IG the... I think what you want to... I don't like the idea of posting content. I like the idea of posting ideas. Right. You shared with me at the beginning of our conversation the idea of a party talking about strategy with professional service organization. There are multiple ideas that were in there. I think what
you want to do is meet people working professional service organizations and they are trying to figure out the market too, right? It's not just big companies, it's you know, these others where there's, you know, the ground shifting under everyone's feet. Useful, yeah. Connects people who are relevant. Have you have another one, which is, you know, strategy is relevant to everyone, right?
And it's like, you know, because strategy doesn't need to be this sort of amorphous thing that people do when they're leaning back of their chairs. Is about how it really connects to the. You know how you and your offer connect to the market and that's an idea, you know that could be two pieces of content they don't for long it's like have I made you think today?
And those pieces where you have like that cool idea, they're a lot easier to build more meat around, but they're easier to have an idea around that like could I be post we have a basically a reply whatever like you have an idea, how do you share that idea with the world?

**Ellie Rofe | 14:34**
But is that my idea?

**Speaker 2 | 14:35**
And you were doing so effortlessly.

**Ellie Rofe | 14:36**
Is the idea that professional services need strategy? Is the idea that an idea is that an idea I don't understand? I think that might be where I lose it with LinkedIn. I don't understand how that is an idea.

**Speaker 2 | 14:56**
Professional services often don't have people thinking about strategy, right? It's a cash flow business. Strategy tends to be the domain of where you have a separation between equity and cash flow, right?
Okay, because you're making investments, right?

**Ellie Rofe | 15:13**
He.

**Speaker 2 | 15:14**
And professionals isn't usually making investments. Like, how do I put something into the market? They're go make money right now, right in cash right now.
And I'm sure we've all we all feel that, right? But that the. But those who are able to have a plan are more successful than the others. And the fact. And like you say, is that really an insight? But what you were just telling me was a story about meeting people who thought what you were doing was interesting and exciting and their professional services.
Right, like you say, a little bit out of pocket for what you're usually doing. Why is that pocket for what you're usually doing? Because that's not usually... People who hire this stuff. So, yeah, I thought the whole point of your story with that was remarkable.

**Ellie Rofe | 15:56**
I think it is interesting. So again, this is... And maybe this is the underlying question here, and this is really helpful. I'm not trying to be cantankerous, I'm trying to tease things out. I may be sounding cantankerous.

**Speaker 2 | 16:09**
You're replacing me as a true being. Cantankerous.

**Ellie Rofe | 16:11**
Are you okay?

**Speaker 2 | 16:12**
But yeah, go.

**Ellie Rofe | 16:12**
Fine. So the huddling algorithm. I guess if I'm thinking about it's like talk about the same thing.
Because as soon as you talk about other things, no one will see it. Because it won't give you reach. Because it decides what your niche is and who you should be put in front of. So talk about the same thing all the time.
Then it's like, "Well, I'm quite associative, and I do have lots of ideas and things like that are really interesting." But then it's when you start talking about out-of-pocket things because of the nature of the structure of LinkedIn and what it's trying to do with nicheing people and putting them in front of the right people just disappears.
Anyway, I think maybe this is a foundational... And maybe this is the underlying question. I'm asking, "Do I just write stuff for my own sake, as I'd said I would last year?" If it gets seen.
If it doesn't, and I stop worrying about the sodding algorithm. Or do I just view this as a functional part and try to work out how to write stuff that is actually going to create an effect? Because I think there are sometimes polar opposites, especially on platforms that are at that stage of maturity or in that specific...
I mean, LinkedIn is obviously very specifically because it's such a professional platform. It is more trying to push people into buckets that are easily categorized by the algorithm and who they should put in front of.
So yeah, I guess that's the question. Do I just not view this as a tactical play where I'm trying to work at how the time I put in directly can create effects and responses? Do I just go? This is just useful for me.
If it connects with anyone, it happens to connect with anyone.

**Speaker 2 | 18:13**
Okay, I think there are sort of you've identified the two big schools of content creation, right? Which are creating ideas that matter as you see it and then feeding the beast, right?

**Ellie Rofe | 18:26**
He M?

**Speaker 2 | 18:28**
I think Demetrius is going down more the road to feeding beast. He made a recent feed the beast article that actually worked.
Well, for him actually got like, you know, a lot of engagement where he said hey, you know, reply with X, you know, to go get your like apply X. They want free stuff and like it.

**Ellie Rofe | 18:47**
Yes.

**Speaker 2 | 18:48**
Then, as a result, it gives a whole bunch of people who apply to them and give them an excuse to go on them.

**Ellie Rofe | 18:53**
Hu.

**Speaker 2 | 18:53**
That's a strategy, and there are a bunch of people who do it, and there are some people who do it relatively well. I think the people that I like to work with are a little too authentic for that kind of scheming stuff to work as well as it does for others. I don't respond to those kinds of things.
People who I want to work with don't really respond to those kinds of things. I think the reason we're using LinkedIn is because it's the least common denominator way to be putting out your ideas, right?
It's like, "Okay, where should I put my ideas?" Let's start with LinkedIn. Not because LinkedIn is the totally right place to do it, but because it minimizes the friction between getting an idea out of your head and into the world and then having created something for LinkedIn.
It's like, "Okay, now I've got these ideas, right? They have these flows of ideas, they're going in those ideas have the opportunity to reach more people through LinkedIn. More importantly, and I think this is the way people use LinkedIn content. More like a number of people who are sitting around watching the feed."
That's not... People don't do scroll on LinkedIn down, but what they do there's a little bit of... In caught somebody summary. But I think there's a lot of proof of life stuff. So when someone has about you and they go look you up on LinkedIn, they see that you have all these posts which have interesting ideas.

**Ellie Rofe | 20:16**
H.

**Speaker 2 | 20:18**
Okay? And they're they will look for some degree of social proof. Like are you getting, you know, like some responses or whatever? But that's some indication of, like, whether you are, you know, sort of out of the wilderness or not.
But like they're primarily going to look at for like are you saying things that are interesting and I think people who are more versed at qualifying I qualify people who are like di I when I go to you know, someone wants to have a conversation, I go look them up. Do first question, do I know them? Don't have any connections.
And second question, you know, are they really are they posting anything? And I do that before I go look at the resume, because the resume is static and usually full of whatever BS like talking about the various weird things I did and I don't care.
So I think I see it more as a proof of life thing as having in terms of the way it will get you value to customers.

**Ellie Rofe | 21:04**
Twoh.

**Speaker 2 | 21:08**
Some people might discover you that way, but I don't think it's a big way to get discovered.
I think discovery has happened more through things like YouTube. When I've... People who reach out to me, I ask them how they found out about me, and the answer is not LinkedIn. The answer is YouTube.
Because that's going to be usually because YouTube is something where they have search intent, right? Then they find something that way and they see something that was smart and they want to do that and proceed. That's usually more of that or helping with somebody in a community or what have you...
Like, "Hey, you seem to know your stuff about X, so I would like to help you to help me with Y." That's been... So the... But I think the reason to start with LinkedIn is that it's a way to get out. You've talked before about doing Substack.
I think Substack is great too. ChatGPT has a slight problem of not having as much distribution, right? It's a place where you collect people into your list. But you have a bunch of people who might actually be quite interested in that.
So collecting those into your Substack and being able to reach out to them can be quite valuable as well. I mean, we all talk about having a mailing list, but really just about people who know you, who think... You can be building up more trust with them.
If that becomes a form that you are happier with, go for it. I think YouTube is great for outreach because it has both algorithmic and search intent and works really well for both those because it's tied to the Google search engine and blah.
I would encourage that for anyone who feels comfortable getting from a camera. But that's how I think about content. Like you having an idea. I want to pull those ideas out and put them into the world.
If you do that once a day, if you do that in 10-15 minutes a day, you will have a whole... You'll have 100 ideas in a quarter out in the world and more opportunities to get hit. Then people can look at them and say, "Hey, wait, here's a person who has a lot of ideas, and you do."
That would be that for me. That is a job to be done of that content aspect of the cell, right? I think if you're doing that, then you're getting more excited about your ideas and feeds you back to what these ideas are going to come from, which leads us to study.

**Ellie Rofe | 23:34**
Sorry, there was yeah, there was someone I see.

**Speaker 2 | 23:37**
That's the armorfly.

**Ellie Rofe | 23:40**
Is it a bee? Yes, it is interesting. I think partly on LinkedIn, that money, knowledge, and power piece. I think partly the reason I resist it is because there are ideas within that that are not really very popular within a LinkedIn echo chamber.
I think part of the reason I got the SDP job from X is because I was posting ideas and thoughts about politics that were frank and honest, not extremist or anything, but analytical in a way that I think maybe I sometimes resist the LinkedIn. There's a bit of an echo chamber going on there and a bit of an immune response to anything that isn't just feeding into the same slightly received wisdom ideas about stuff.
But maybe I just don't care about that. I just, you know, do the same thing there. And if people hate it, they hate it. And I do the same thing on X YouTube and Substuck. And if they hate it, and I just deal with what that is.
But yes, I found. I found that an interesting shift is that I feel like. I felt like I linked him as just a bit more performative in a slightly banal way and that there's things I was probably for me and this isn't about other people, it's about me. I was probably trying to shape ideas for a platform rather than just say, ideas that I'm having or areas I'm exploring that are interesting.
So I should probably think about that on some level as well. Where it's in a. In a slightly more, like. So as soon as you start getting into energy defense, you know the nature of any of these things. Politics does impact what's going on.
But as soon as you start getting into that, especially on LinkedIn, you're wading into, like the algorithms restricting you anyway. But there being a lot of, default opinions on these things that then like.
So a defense, a biotech company became a defense company a few weeks ago. And wall to wall the biotech sort of industry was like, this is so awful. Something that was going to save lives. Is now, you know. De becoming something that will kill and sort of yes, but you know what was it fortitudin and a pax a fortitude or whatever like piece through strength like the DES destroying defense capabilities destroys lives so that's like a you know a balance to be had there.
But that message was not welcome in those arenas because it's just a slightly more, I guess, simplistic view. Sometimes on these things, I don't know, maybe I should just, you know.

**Speaker 2 | 27:16**
Well. People push back, right? I if you. If you. If you have spiky ideas, people will say.

**Ellie Rofe | 27:23**
Yes, but am I just? Then I guess the question is, "I probably part of the reason I have preferred X is because it's fine being a hedgehog if you're amongst other hedgehogs, but if you're a hedgehog in a group of balloons, then what are you really achieving beyond prodding people to blow up?"
But not actually achieving a conversation or something that is push and pull or finding the people who are interested in those ideas or finding people who are just saying, "Ouch."

**Speaker 2 | 28:01**
Well, that's a reasonable point. So. So if what you're finding is that you're your people and people who want to buy from you are more likely to be on X than they are to be on LinkedIn, than just write tweets. Nothing wrong with that.
You know, for me again, the thing is, how can you be emitting yourself into the market linked it the purpose. You know, pushing into the market is the purpose and saying that it's not a wait, marketing or sales or whatever that that's thing I do next week is the thing we just do every day.
If we are doing it every day, we compound our benefits. And if we don't do it every day, then it slides and it's sort of very hard to get, you know, get that momentum. And it doesn't need to be about working on it, you know, five hour or making content five hours a day. Although if you don't have where everything's going on, that's not a terrible thing to do.
You know, the, it's a how do you know, sort of stay out there. So like when you're asking about hour thing, right? That's the reason why I talk about ten minutes. So the very conversation we're having. Wolf, you know, right. Doing on LinkedIn, it just seems terrible writing, you know, having hour day on LinkedIn seems like a, you know, like me having to do a grind.
But I could totally just, you know, spin off a tweet and then, you know, that's where actually people want to buy for me. Like, okay, let's do that.

**Ellie Rofe | 29:29**
Yes.

**Speaker 2 | 29:29**
Far is standing in the way of successful commerce.

**Ellie Rofe | 29:36**
Yes. It took me a while to come around to that one, didn't it? [Laughter] To make my way around to that discussion.

**Speaker 2 | 29:46**
Well, I mean, this is where sometimes, like, I'm just acting as a sounding board. You know, like you're and just trying to identify when you have spoken back to yourself in a way that, like, is unactionable.

**Ellie Rofe | 30:00**
Yes. I think there's a bit of a fear that I. Certainly in the UK there is a slightly claustrophobic atmosphere at times about talking about certain topics, and I think from a place of it's different if there was.
You know, I've got 17 clients in the mix. But then you're sort of like, what if I'm putting people off? What if I'm, you know, repelling people? But then I look and I'm like, I mean, half the people in hard tech are like very heavily opinionated in ways that are not part of the sort of LinkedIn milia.
Like, you know, you listen to Josh Wolfe or something. He's not, you know, he's not repeating lines that have been the de facto lines for like ten years. So I think, that there is a different sort of pool of people to be talking to who have that actually just the geopolitical interests. I'm not. I'm not really interested in what's right or wrong in this world while I am.
But I'm not. That's not my point. It's people who want to have the conversations about it, if you know what I mean.

**Speaker 2 | 31:10**
Well, right, there's geopolitical part. I mean, like. Like you say, you know, knowledge, money, power and the. And how these things, you know, intersect. I was thinking it was funny that when you're talking about, like, the, you know, investors who are talking about things that are, you know, non consensus, the SaaS stuff is just disgustingly consensus.
You know, and the like I TED to help my friends and some of whom I thought were actually good entrepreneurs and I discovered what they are herd followers.

**Ellie Rofe | 31:42**
Yes.

**Speaker 2 | 31:43**
And sometimes it's sort of sad for me to see that because, you know, for me, the most fun expression in finance is calling bullshit.

**Ellie Rofe | 31:51**
Yes.

**Speaker 2 | 31:52**
What's the what thing? Everybody else thinks that, you know, they should go left.
And you. You go right. And there's going to be money to be made there and that's. But then I discovered that these people have too much social equity, right? And of confidence to do those kinds of things.
And I see a lot of that, you know, and. And lots of people are like, you know, want to be hurting together, you know, because it's more comfortable to do that if you're comfortable the other way. There are a lot of people who are going to say that you're wrong. You sort of need to deal with that opprobrium.
But the coterie of people like, hey, that's interesting. But people who are calling the same bullshit. Those people are often quite wealthy, and they are they're looking for their for fellow travelers with which they can do this.

**Ellie Rofe | 32:35**
Yeah.

**Speaker 2 | 32:43**
And the what what's call it's called the cur to be unpopular, right? And the. And you being out there and sort of working to be more unpopular through just expressing the ideas that you have. I mean, I'd say that you're looking specifically to poke people in the eye, but that your opinions are spiky and they're not the same as everyone else's, and you're not trying to moderate it. I that's very you and the more. See what the authentic U looks like.
I think it's a very appealing, you know, opportunity to get to work with your mind.

**Ellie Rofe | 33:20**
Yes, I think that's a very good point. Not that I'm appealing, but that it is important if you are. Yes, I suspect trying to censor things and trying to appeal because actually I guess a huge amount of my connections are in biotech as well, and that is similarly like SARS, I guess maybe these big established ecosystems have something of this, and maybe this is an interesting idea. Biotech is a large, established ecosystem in terms of development, capital cycles, and that kind of thing.
Like SARS, I suspect it is more prone to certain levels of herd thinking because there is just the way to do things and the key influence. Nexuses or... In that world, we'll be creating a central people force towards them, saying, "This is how we do things."
They seem... Ironically for scientists, they do seem highly... Heard thinking at times, which is maybe because science is, I found, in the film and TV industry, maybe because science is very unstable or destabilizing as a thing because you don't know anything until you know it. There's this need for some sense of security.
But yeah, I get a sense of maybe a bit more heterodoxy in newer or emerging industries or ones that don't have that big ecosystem already built around it, which makes sense because they're more fragmented, I guess.
Okay. I will have a different approach, but yes, I think that...

**Speaker 2 | 35:20**
So yeah, just keep it small. If you can do it from your phone, all the better.

**Ellie Rofe | 35:24**
Y yeah, I think. I think that's an interesting challenge as well. Getting used to thinking through the phone screen rather than other ways.

**Speaker 2 | 35:37**
It's a question of how you like to write. I am discovering I quite like to write. I mean, I'm a talker, right? But I like to write through just doing a voice memo.

**Ellie Rofe | 35:46**
Yes.

**Speaker 2 | 35:48**
I will then have it clean up my voice memo.
I'm finding that to be a good way for me to communicate ideas more quickly. That way, I can wander around whatever, but still pick it out my words. I'm using it as an editor instead of as a come up with three pieces of content. No, I don't want the AI to come up with content, I want the AI to help slim down the content. That way...
So I'm not saying you need to use voiceware, but just a whatever decreases the friction for you and the fact that you have this time pressure, the shipping, creates an opportunity to push on that.
Okay, if you need to get something out, what's easier? Okay, well, Twitter is easier. X easier than LinkedIn. Okay, fine, what's next? Yeah, how do you get something that's gon to be, you know, useful out there good out of your brain? How you have the idea you're going to have your brain. How do you get the idea, you know, out and expressed? For me, I'm increasingly using voice. You can use whatever works for you, but like what? What helps shrink that so you get more bang for less buck, as we say over here.

**Ellie Rofe | 36:58**
Yes, I do love that phrase. Yes, I have been inspired by you. I have been using voice more, made easier using Telegram for Claude Bot and for using Super Whisper for developing and the research and extraction work I've been doing with the IDES or whatever.
So yeah, I've definitely been using voice more. There are times when I find typing easier and times when I find voice easier, and I think that's a really nice thing to start working out and just play with.
Because, like you say, sometimes voice allows you to just dump stuff and let the model work it out.

**Speaker 2 | 37:45**
And just your terms of phrase, right? Like the. The idea is for it to be you and not somebody else.

**Ellie Rofe | 37:54**
Yes.

**Speaker 2 | 37:54**
Nothing it...

**Ellie Rofe | 37:56**
Yes, and that's a very interesting... But I mean, they say people are now starting to write like AI because the feedback loop is pushing people into that way of thinking and structural grammatical structures.

**Speaker 2 | 38:09**
One.

**Ellie Rofe | 38:12**
I've always tried to prompt AI in my voice rather than dressing things up for it, so that it... I sort of became slightly aware of that early on, but it's so much easier in voice to just talk in your voice because there's no. Yes.
Yeah. There's no editorial process between thinking and... There's a little... But not as much. It's more immediate. You're right. Okay, so to recap, before I forget, I'm going to try to just put ideas out every day on Twitter, X, whatever.
I think if there are ideas there that I think are worth a bit more in depth, I might try and just substack them and start getting into a bit more of the long form and a thing that can cross post elsewhere. I will.

**Speaker 2 | 39:08**
Yeah. And then you know those can turn into essay. I mean there there's lots of, you know loop to go on here, but like we're not trying to do things.
I think if you do one thing, you will find the best things. And then that. That. That let's you just focus on the. The cream of the crop and not worry about the skin.

**Ellie Rofe | 39:23**
Yeah. Okay, cool.

**Speaker 2 | 39:26**
Can I quickly ask about study? Where are you in that front?

**Ellie Rofe | 39:29**
Yeah. The vast majority of the stuff I've been doing over the last week or so has been around understanding how to manage data, a bit around knowledge graphs and how to... The functionality of working. I worked across Claude, coworker, Claude, Excel, Gemini Codex all in the same fold or all on the same project, pushing them all off to do different jobs.
Just trying to work out the best way to source data, scrape data, analyze it, and get it into some sort of shape. So that has been more of a meta study on how I can do these big research projects faster.
I think when I think back to some of the questions I've asked in our Masterminds and Things research, it's an area I love, but it's an area that has quite a lot of friction points and potential lack of friction. I rabbit hole for myself where I can just be like, "Whoa, this is interesting."
Off I go. So it's... Yeah, it's been an interesting one for me to try and work out a process that is expansive enough that I can find the things that are really truly interesting rather than just defining what I'm looking for in advance. I partly what I was looking at, and I think maybe it would be an interesting thing to dive into a bit more is the difference between research in terms of market research and almost investigative journalism or the approach that other people take where you want... Where you're trying to just be expansive and understand what you don't know yet. I think it was Cheney who had the known unknowns or was it Rumsfeld? It was one of them. I can't remember. Thank you.
So a process that allows you to do that but not get overwhelmed by the amount of information you then collect so that you're not just drowning in noise. That has been the process. I'm still refining it, but I do feel like it's getting easier for me to understand where to start and how to shape it.
I work with AI to sometimes help me plan and identify areas I might not know or get a bit left field and say, "What am I not thinking about here in this picture?" Then it's a case of as I go through, I'm seeing where there's a thread worth pulling or not. Much of it is as I'm researching things or reading things or understanding more. I'm pulling out questions, but putting them to one side so I can review questions. With a having paused so I don't just keep following every track. I see where the tracks are and then go right which ones are actually most useful to me. The power of the draw edit. The thing where I said you put your script in a drawer for three days and then when you come out, it's much clearer in your mind.
I think I'm trying to use that a bit more. I can do some of that, obviously, because it is more objective than you are if you prompt it correctly, but I think it's useful for me to be directing some of that. This is the question of where I'm exporting executive function versus retaining judgment.

**Speaker 2 | 43:22**
That makes sense. Now, the thing about using AI for this set, like my framework for thinking about, you know, the study part is learn, experiment, build, teach, right?
So these I think of these four steps as being, you know, the way I make progress, you know, intellectually. And what you're describing so far is a lot of experiment, right? And the way it creates value is through speed because you're turning through a number of different areas and dimensionality because you're able to, you know, go because of changes in direction moving like, you know, sort of end dimensional space.
Right? But the. And it has a third thing, but. But in order for it to be multi dimensional, it needs to be tactile, right? You need to have something where you are, you know, reaching in to be putting some pressure on the ideas.
And it sounds like you're doing all those things. But part of the reason I bring it up is that even though that's good experimentation, it's only one quadrant, right?

**Ellie Rofe | 44:20**
Hu.

**Speaker 2 | 44:21**
I think that the one that we sometimes sleep on, particularly as we start getting more into a shipping mode, is learn, right?
So with Cell, I would say, "Okay, how can we figure out just that most essential part and even be able to shrink it down because the most effective parts of Cell could be the smallest."
But study is a little bit the opposite, right? So when I think about what a career looks like as you become more senior and more successful, ironically, it looks much the same as it does when you're unemployed. That's because study becomes the biggest thing because, well, study previously said starts as a big thing.
While I don't have other things to spend my time on, it ends up as the biggest thing because that's the thing that's creating the biggest returns for you. So the part of a study that creates the biggest returns is the part that's slowest, which is the learned aspect, right? Getting new ideas into your head and new media ideas into your head.
Because experimentation tends to be irritating. AB testing is refinement, right? And refinement is good. Refinement's important, but the more raw material you put in, the more value you get for the refinement and other...
Without the more raw material, what happens is we start refining the B stuff instead of refining the A stuff.

**Ellie Rofe | 45:39**
M.

**Speaker 2 | 45:40**
We can refine the A stuff into A plus and we can refine the B stuff into B plus, but if that's the case, I get some A ideas in here.
For about... We talked more about... We talked more about other folks that you have been reading. Can I ask where you are on the book front?

**Ellie Rofe | 45:57**
Not really anywhere at the moment. I've read about a few pages of Gabriel Garcia Marquez on a plane, and then I've been driving and listening to the Conflicted podcast about the Iranian war and what that means for the wider geopolitical side of things.
But not very much. So yes, that is an area where I have been behind the curve.

**Speaker 2 | 46:25**
Have you ever read Jurgen's Prize?

**Ellie Rofe | 46:28**
No.

**Speaker 2 | 46:29**
Okay, how do you recommend it? It's a story. It is a story of the political economy of oil, largely over the 20th century. It ends with the Gulf War, so...
I Iran features, as you might imagine, quite prominently in it. An excellent book. I can't really... I can't recommend it enough. He has a sequel that he made, like eight or nine years ago called "The Quest," which is about the history of oil between the Gulf War and 2016 or whatever, in which Russia features a lot more and basically some of the non-Middle East sources of oil.
But I bring it up because I think if you're trying to get your arms around what's going on with the Iran War and some of the story behind the story that both the oil and economic parts...
When I talk about history, he's sort of pointing like a unified history of the Middle East in the course of the last hundred and fifty years. The linguistic differences, right between the Iranians and the Arab world where apparently the Shah Iran...

**Ellie Rofe | 47:44**
Gof.

**Speaker 2 | 47:50**
I don't think it was Reza.
I think it was his father.

**Ellie Rofe | 47:53**
No.

**Speaker 2 | 47:53**
Met with Western oil companies, and basically his pitch for Iran was, "We're white like you." So wait, what's going on here? I mean, the northern border of Iran with Russia, it's the Caucasus mountains.
So they were saying they're Caucasian, which is... There's something true that... But wow, I didn't expect race to be coming from that direction, and of course, like I say, knowledge, money, and power are all linked together.

**Ellie Rofe | 48:16**
Yes.

**Speaker 2 | 48:31**
So as a story, that's very much linking in with your areas of interest and that is certainly relevant to current events. I've bet a lot of people are reading "Prize" right now. I recommend it. It's a rip in Yar.

**Ellie Rofe | 48:44**
Yeah, with the beauty as I'm now in the UK. So what I need to do is stock up on books that I can bring back with me because I've got a checked bag on the way back.
Yeah. So it's trickier to get them in France. So yes, that's a really good idea. I will find some great books, and that's a fantastic recommendation because it is... There's... I think it was on weight, but why? Probably...
But I think it was a trip, or it may have been in Ashley Vance's biography of Musk, but there was something about the branch versus the trunk of information. I think this is a really interesting example of where I might have lots of bits of branch information, but this is the trunk. This is where you can go.
Okay, I can get the actual foundational stuff rather than the snippets of bits. I understand around the...

**Speaker 2 | 49:39**
Just a second book recommendation. Have you already read Donella Meadows' Thinking in Systems?

**Ellie Rofe | 49:45**
No, that...

**Speaker 2 | 49:47**
Okay, Professor Meadows. Professor Meadows, wrote a wonderful book that is on systems theory that's really about, you know, systems as graphs.
Right.

**Ellie Rofe | 49:58**
Okay.

**Speaker 2 | 49:58**
And complexity, it is a very approachable book because her domain was ecology, right? So she's talked about it all in terms of these natural systems. And when she starts talking about it in terms of the natural systems, she's like, "I get it."
There's rain and there are rivers and there are lakes and there's all sorts of... How animals work, but then it gets to core issues of stocks and flows.

**Ellie Rofe | 50:20**
Hey.

**Speaker 2 | 50:21**
It edges versus nodes. How do these things work?
You can raise it to a higher level of extraction, and it becomes a very useful work.

**Ellie Rofe | 50:28**
He.

**Speaker 2 | 50:32**
It's not... You're going to speak of the history book. History books are long. ME's book is a thinking book. Thinking books are not long. Both excellent.
But like when you were sort of talking before about the graph stuff with Demetrius and with Robert, there's an opportunity for you to come back over the top, right? And be more thoughtful about. Okay, what is, if that's the knowledge graph, just what's the graph? What's the graph of the system?
And this takes you out of the whole abstract idea relationship, whatever, and into, okay, what would it be in nature, what's by river, what's species, what's my animal, what's the feeding ground, whatever.
And the. And then, you know, the Grgan thing. The yrgan thing I like particularly because it's just so readable. Right. And because it's pulling you along, it sort of makes it allows you to play uneasy as you are listening to it in your car on audiobook or reading or whatever.
But to, you know, one, it could be enjoyable. And second, as you sort of say. Wait, hell, look, that's very parallel to what's going on here.

**Ellie Rofe | 51:40**
I love the idea of the thinking and systems. I've realized that my underlying aversion to pure ideology is that it doesn't actually consider systems. It abstracts ideas away from systems, including human psychology and...
Creates a falsification layer that ignores the mechanics of a system and lets parts of it break down. I think I have AI have a sort of inherent part of me that thinks in systems. When I was younger, I wanted to decode the entire human psyche so we could fix all problems. That wasn't an acid trip.
I'd drawn a penguin, and I was talking to him. But that was a long time ago. But it was a drive to understand the underlying things so that... Sounds really interesting as well. I think that's perfect. Yes.
Okay, I look forward to it.

**Speaker 2 | 52:43**
Sure, I recommend those two as a starting point. I've been reading more philosophy lately, with my son, my sons and I are born running through a political philosophy. You know, curriculum.
And the one of them came to me and said, Daddy, you should read Hobbs. That's probably true. I read Leviathan, you know, in full. So I'm right now working my way through Leviathan.

**Ellie Rofe | 53:06**
Wow. Yes, I think I read that as part of my degree, but the ideas are probably internalized somewhere, but I've probably forgotten that. Funnily enough, that appeared on a list in Prevent, which is an anti-extremism or anti-terrorism organization in the UK.

**Speaker 2 | 53:15**
Eight.

**Ellie Rofe | 53:24**
Leviathan appeared as a book that might indicate extreme right-wing views, which is so bizarre.
Then so did C.S. Lewis and Shakespeare. So I think that's just that particular part of the civil service has got a bit cracked. But yes, these political philosophy ideas are dangerous.

**Speaker 2 | 53:47**
Well, I previously read through some Plato and Aristotle. And that TED, he should read hops now.

**Ellie Rofe | 53:52**
Yeah. Love that. Your boys are so cool. They're so steeped in the world.

**Speaker 2 | 53:59**
But and but part of the reason I bring up that was just a, you know, philosophy can be, you know, sort of interesting, engaging, and it is, if nothing else, chock full of ideas that force you to think through like you say systems, right?

**Ellie Rofe | 54:11**
Yes.

**Speaker 2 | 54:15**
Because what all officers are trying to do is. I mean, that's the whole idea behind the Enlightening project is, you know, starting from first principles, can you build up you know what, you know, a theory of how things can work out.

**Ellie Rofe | 54:27**
I...

**Speaker 2 | 54:29**
Yeah. Now. And. Okay, I'm. I'm not trying to say, let's go read three books for next week, but like the. I think if you have something you can hope to... In that you will find more ideas flowing through your head, it will make it easier to be shipping, and it will make it much easier for you to be selling.

**Ellie Rofe | 54:44**
He yes, yeah, yep, yes, no, that's a very good idea.

**Speaker 2 | 54:50**
You know, like the so instead of am I going to post about today? It's like, alright, what did I read yesterday?

**Ellie Rofe | 55:02**
I shall get ordering, get some books delivered by tomorrow, ready for train journeys as well.

**Speaker 2 | 55:11**
Superb. I'm. I'm. I'm excited for you. For the. For that work that's coming up and, yeah, I suppose just let me know if there's anything.

**Ellie Rofe | 55:16**
Six.

**Speaker 2 | 55:22**
I mean, and the way that you reschedule totally great.
Just do that whenever you need to, and we make things happen. Too many weeks we have done that and just lost the week.

**Ellie Rofe | 55:34**
Yes, yeah, I realize.

**Speaker 2 | 55:35**
Did you...?

**Ellie Rofe | 55:37**
I realized when I cancel and go, well, is it okay to reschedule? I then forget to reschedule because the days take me away. So yes, this Friday I'll need to reschedule for as well, unfortunately, because I'm in London for meetings.
So I will do.

**Speaker 2 | 55:51**
At your convenience a little bit earlier rather than later to make it easier for me, if you could.

**Ellie Rofe | 55:55**
Yeah, yes, okay.

**Speaker 2 | 55:56**
I just. You know. Book another time and cancel the Friday. Excellent.

**Ellie Rofe | 56:01**
Thank you for your patience with that.

**Speaker 2 | 56:04**
All good. Good luck with your meeting this week,
and I'll talk to you on Tuesday.

**Ellie Rofe | 56:08**
See you tomorrow. Cheers.

