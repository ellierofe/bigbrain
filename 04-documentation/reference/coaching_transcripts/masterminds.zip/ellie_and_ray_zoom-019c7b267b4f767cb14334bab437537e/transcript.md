# Ellie and Ray Zoom - Feb, 20

# Transcript
**Ellie Rofe | 00:05**
Hello, I'm very well.

**Speaker 2 | 00:06**
Hello, Early. How do you do today?

**Ellie Rofe | 00:09**
And you?

**Speaker 2 | 00:10**
Right, it's always a difference in like the, for the masterminds closer to your end of day. So you often get. See the lights in the background. And now you sure get. See the sun coming through and.

**Ellie Rofe | 00:20**
Wow, something closer to sun than we have had for about six weeks, so yes, it's very nice. It's. I think most of Northwest Europe has been in a very tedious, weather depression. But probably leaking out into a general depression where it just rained so much. 
It's unbelievable. Yeah.

**Speaker 2 | 00:47**
The a few people wonder how, you know, World War one slowdown, like all that.

**Ellie Rofe | 00:52**
Yeah, exactly. It feels quite trench like in certain places, yes, but yeah, it's nice to have a little bit of brightness in the sky, definitely.

**Speaker 2 | 01:03**
Okay, so the, yeah, I'm sorry, Angela, which is that, yes, this is a, well, it's a well, it's a book of engines and how they yeah, how they get made internally, right?

**Ellie Rofe | 01:03**
What's the book called Engines? 
Sorry, I've never noticed there's a book behind you just called Engines. What is that? Yellow B. Mid shelf.

**Speaker 2 | 01:31**
This is actually something in my. My children got really into a book by the same person about the elements. 
Right? So we made a book that had, you know, sort of a two page thing about each of the elements. Got really into that chemistry.

**Ellie Rofe | 01:44**
Hey, he.

**Speaker 2 | 01:47**
And. And then, you know, his way of combining science with display was, you know, attractive to them. 
And so we wound up getting, like, that whole full series. We have a tradition of every Sunday, two new books come out for them. You know, the from you know, from our store. We go to the library and, like, borrow forty or fifty books at a time. 
You know, it's something you do with kids, but the. But we started this during the pandemic because my wife had sort of built up this inventory of books that she sort of has her emergency supply, right? 
Like, give them. But then, you know, because they were everything was going relatively well, we didn't need them like. So it turned into this tradition that we've now been doing for, goodness, like six years now, which is that's a lot of books that have gone through, you know, that's like a hundred books a year. 
You know, times that many years. And the. And it gives me the opportunity like that. That was an example of wait, let's get them more into science stuff, right? And they were super excited about that. 
And then just me experimenting with what are ways to be getting them to be thinking about, you know, ideas and issues that are, you know, not what little kids are thinking about. Like that Gotham Alchemy, right? Son's book. Actually, they're both adoring Dave Trot right now.

**Ellie Rofe | 03:02**
Okay? Don't know him very well, actually. Dave Trotm.

**Speaker 2 | 03:05**
Well, I've never met the man, but the, his but Sutherland speaks really highly of him and so that.

**Ellie Rofe | 03:12**
I will have a look.

**Speaker 2 | 03:14**
Okay, we'll try that out. And then got that gotten them you know conaen Thaler right like the behavioral economics they love but like just sort of how to get them into like excellent books right about better topics.

**Ellie Rofe | 03:25**
Yeah.

**Speaker 2 | 03:35**
And the and they are they scoba mean they'll buy like you know, not buy. They will go from library and get like lots and lots of trash fiction, but they will mix that with these things. And they're not reading them because they want me, because I want to. 
But like, I'm able to sell these books because I'm actually excited about them because, you know, my own reading habit, just trying to take the best of those and bring that to them.

**Ellie Rofe | 03:58**
He yeah, wow, that's nice.

**Speaker 2 | 04:02**
I guess. Sunday books have their books. 
And like I've done, I've read somewhere around like 05:15 in the course of last five years.

**Ellie Rofe | 04:09**
That's very impressive. Yeah, I have lost the I want to read actually more. I have lost the. I think after my English literature degree, where you have to read so much so fast. 
Like, certainly at Cambridge, you have eight week terms, and each term is one essay on the paper you're studying, as well as an essay on like a, you know, critical theory or something like that. Li literary critical theory, not critical theory. 
And, so it's like, right, this week, you're just going to read, like, all of George Eliot and a ton of secondary reading, but you're not going to read all of George Eliot. You're going to skim through it. 
And it taught me terrible habits, and it sort of lost the love for me. But the other week I read, it's not great literature, but I read. My God. I forgot the name of it. Some massive book about a kind of spy and heading over to, like, Turkey to unravel something. It was really pacey. 
And I sat and read for twelve hours. I said to Nick, I'm so sorry, but today I'm not going to be here because I just was like, let's just devour this and remember that feeling I had when I was a kid. 
So it's so lovely to hear.

**Speaker 2 | 05:33**
Yeah, it's actually lovely to hear that you're doing it.

**Ellie Rofe | 05:34**
They're devouring books. Left. Right.

**Speaker 2 | 05:40**
One of the things we that I talked about on the study side is this, you know, learn, experiment, build, teach thing.

**Ellie Rofe | 05:45**
One.

**Speaker 2 | 05:46**
Where learning and building are supposed to be the slow ones, right? 
And I think as we get Busier's sort ofs easier for us to say, well, I'm reading an article or I'm doing a little bit of something, which, from where I sit, that can fit in like the experiment category, but the. 
But the learn is just such a big piece of it. And to my mind, it is slow and it's about taking in bigger ideas. And like, books are a great way to do that. Now I appreciate it is fiction. You're like, yeah, does not really count, but like the I think the just training your attention span a little bit becomes helpful for that and that whatever you can do that it.

**Ellie Rofe | 06:21**
Yeah, well, I do think and I think as eroding my attention span a bit as well, so I you know, I was thinking. So the last couple of weeks have been just difficult physically and mentally for various reasons. 
And I think. There has been a sense of. And it's sort of burst, I guess, living on this sort of precipice of, like, not having much money. And then when Nick's job fell through on Saturday, it was just like, God, this is hell. This is just too difficult. 
And I think, I mean, hopefully things will go through with the SDP, which will take away the immediate concern. And Nick's reshuffled stuff. And he's very good at, like, bouncing into action and hustling in a way that I'm not. 
And I think I need to learn from him a bit. I get stuck in my own head too much about things. But he. But I think partly I need to be, doing stuff that isn't. Well, that is slow. Like you say, it isn't just constantly trying to do something. 
And that just takes me into a different way of being and a different mode of thinking for a while, rather than kind of just existing slightly white knuckling life on some level, I think that's a beauty. 
And when I look back like my. My nun grew up in. My MoM grew up in absolute poverty. Long story to with my grandd being an inveterate gambler. But, when I look back at how my nan dealt with the strain of it was reading. It was like. 
And I'm not saying I'm in poverty. We're pretty skinny at the moment, and it's stressful, but I'm not in poverty. But that taking yourself away from a thing rather than just kind of white knuckling your way through it and constantly stressing, I think is really important. 
And I don't think that reading has to be literary. I think it can be nonfiction as well, because it's just immersing yourself in a different kind of idea, a different kind of world. So I think that's importantm.

**Speaker 2 | 08:37**
I think you. You used the I word ideas, right? Like the way I think about reading is not about consuming, you know, words or even knowledge per se. 
It's like, how can I get more ideas into my head? Because if you have more ideas in your head, there's going to be more that you can do with those ideas. I think there's a lot to be. You know, I've no doubt there's a lot that you can do with that, too.

**Ellie Rofe | 09:00**
Yeah.

**Speaker 2 | 09:03**
So that that's it's great that you know, it's good for us to be talking a little bit about the reading thing because I think when, you know, if we rewind the accountability like six months or so, we're often talking about a book and there's probably a correlation like and that say that stopping reading causes the problem. 
But like usually like we start to feel more strained and we're starting to stop doing some of those things, but those things are things that, like you say, they're slow, but they build the equity value, right? 
And now and that that's arming you with ideas that when the market's coming back to you're able to come to them with ideas.

**Ellie Rofe | 09:39**
Yeah, exactly. I think it is. I think it is really important. I think there's. I think it's in the artist's way, where it might be in something else similar, where they talk about going on dates like that. Feed you. I can't remember what they call them. Not with someone else. 
But literally just going to an art gallery or going to do something interesting or to see something beautiful. And I think there's an element of that in it as well, which is that, of course it has a purpose, but not everything has to have like a definitive this is the purpose of doing this. 
It's just like the process itself is part of it. And even, you know, I do wonder whether I should just step a because a lot of I'm not doing a ton of creative stuff at the moment. Maybe I step away and just create a lovely collage or something. I do Photoshop college compositions, but maybe I just step away and do that elsewhere. Or, you know, like, I don't know. 
I think that I know that when I. When there has been money coming in, I do feel a bit freer and that. So I have to work out how to channel that feeling and not feel quite so locked in when there hasn't been money coming in because that becomes self fulfilling.

**Speaker 2 | 11:08**
Yep. I guess you know to. You know of. Speaking of arts way. Are you currently doing war pages?

**Ellie Rofe | 11:17**
No, I haven't been. I haven't been, so I probably need to get back into that as well.

**Speaker 2 | 11:22**
Right? Not necessarily sure. But I think it's something you might find helpful in this moment because it's a great way for you to sort of, you know, memorialize your concerns. 
And then they stay on the pad, hanging on it. It's a remarkable thing for me, like, how you how I don't hang on to the idea if once I've written it down. And so, like, I'm. I'm not trying to induce some magic trick or anything, but it does seem to have an effect. 
But that's what allows me to be, you know, sort of launch into the next idea and not be sort of tied back to the thing that was sort of bothering me when I first got up that morning.

**Ellie Rofe | 11:57**
M yes, yeah.

**Speaker 2 | 11:59**
But that's. Anyway, that. I guess that's. 
That's. That's the reading and writing aspect of it.

**Ellie Rofe | 12:04**
I think it's a side effect of not shipping too much. I felt slightly better this week having done. And I need to do some photography work on it, but having done its website and it's beautiful. 
And I found a way to do it that was, you know, fast but actually really effective. And you tools to their best. And there was a sense of relief. I think. I think. I mean, not quite work will set you free, but, you know, the. 
I think there is definitely something there. I like, even the sort of promise of working with this guy Ross, who I met on the call the other day, who is a very smart man, who's got this chemicals company, which. Yes, great. That might be a lead, he said to me. Or we should probably talk separate to this call, but. 
But that felt like a lift. Not just, there might be money in this, but all this will be an interesting, you know, challenging but, you know, fulfilling exercise. So I think that becomes part of it as well.

**Speaker 2 | 13:15**
Sure. Can I ask what the risk is that you're looking at? That you'd be splitting with Oster? I didn't quite understand what the risk was. Of the engagement of.

**Ellie Rofe | 13:21**
Yes. So I in the proposal to the SDP, the payments were staged. And ASA and William. So the donor and the leader are very keen for me to get started as soon as possible. 
But for the SDP to get the money, they need to go through all sorts of procedural stuff because some of it needs to come from various like, reserves and stuff, which could take a couple of months. So ASA is going to loan them money to pay. For me. 
And then they pay him back once they've released that money. So because the first part of the project is, three to four weeks for the research and then one week for the target analysis and drawing up potential donors. Donor lists and stuff like that. 
And then ten days for the materials. Like ten days to two weeks for the materials. It shunted about 13000 pounds of risk to Alister within five weeks when the SDP may not have got that. So I said I would split it so that we just do a flat seven and a half thousand upfront of a total of 15000. There's a three month support period included, which is one weekly call or monthly if they want it. I'm not sure how much they're going to really take me up on that, depending on how busy they are. 
So we do that, and then the remainder comes either when they've got some money from the funding proposals or at the end of that period, whichever comes first.

**Speaker 2 | 15:11**
Okay, so basically the money comes from. So basically, it's the proposal is 7500 upfront and then 7500, say, in 90 days, right, as opposed to him.

**Ellie Rofe | 15:20**
Yeah, basically that. Yeah.

**Speaker 2 | 15:25**
But all the work, of course, is going to be done well before that 90 day period. 
And that's where the risk comes in.

**Ellie Rofe | 15:30**
That's where I share the risk. Because otherwise, Alister's outlay would be 13000 within five weeks. Five to six weeks.

**Speaker 2 | 15:39**
And this is quid or this is euros or this is dollars or.

**Ellie Rofe | 15:43**
Qui's process.

**Speaker 2 | 15:47**
All right, well, that's not terrible. So like the that's so particularly if as is wanted to step up, then I guess I'd ask like, what's the hold upp at this point?

**Ellie Rofe | 16:01**
They have to put it through the central committee. 
So they have to I think the chairman has put it through that vote. There is. There is. The reason this whole project came about is because Alister called me one night who asked me about doing some work, some volunteer work for the SDP, and he's on what's called the leadership team. 
And this was after they'd said their elite capture was their big strategy. The chairman had told me, the head of COMS had told me. And ASA was very charmingly trying to get me to do free work with the SDP and I said, I will not do free work. I basically unleashed why I wouldn't do free work because I didn't believe in what they were trying to do. 
And it felt like pouring money, pouring water into a leaky bucket, basically. And why? And I didn't realize that he wasn't at the meeting where they defined that strategy, and he hadn't been availed of that strategy, and he was a little bit dismayed by that strategy. 
And then he asked me to send him what? My alternative was that I'd already sent to the chairman and the head of coms. I sent that to him. He sent it to the leader directly, and I he said, do you mind? 
And I said, I think there might be some politics at play here because Stephen, the chairman has already received this. And they said they were waiting until William came back. And he says, don't worry about the politics. 
And now the politics is back. Because Stephen as the chairman, I don't think he's deliberately holding it up, but I think he's a little bit miffed that he feels like he's been sidelined in this. So he's putting it through process, which is fine because you do need that process. 
And I have suggested to Alister that I would love to talk to Stephen first when I'm doing the discovery interviews because I think he will have a unique perspective that will help me not only understand the party itself, but where this whole process needs to be managed as carefully as possible within the party. To kind of. 
Yeah, you know, big E up and make it clear that I respect his opinions, et cetera. So hopefully that process is going through this week. But I'm not counting chickens.

**Speaker 2 | 18:14**
Nope. No, those eggs are not yet hatched, so we keep on doing, you know, other things.

**Ellie Rofe | 18:16**
No.

**Speaker 2 | 18:23**
Any word on the, your other, stuff going on? Like the materials person. The. Which you didn't see in the report or. Or any of those other, like, sort of recent activities you've been doing?

**Ellie Rofe | 18:40**
I haven't followed up with Maddie. It's a couple of weeks since I last spoke to her, and I don't want to keep, like, hounding her. She said at the end of our last conversation. 
I will try and keep you updated because I do know that your money is contingent on this. And I'm like, that's not the only reason I'm trying to checking in. I do want to make sure that your, you know, the materials are working and it's useful for me, but. 
But yes. So I'm trying not to hassle her, but I will. I wanted. I was thinking I'd check in next week for that. So give it another few weekit.

**Speaker 2 | 19:11**
Yep. Remember, hasstling is when you're asking her for things, but it's not has you're giving her things.

**Ellie Rofe | 19:16**
Yeah. Yes. Yeah, and I do always frame it. AS can I help with anything? 
You know, do you need any help with managing feedback or updating the story?

**Speaker 2 | 19:27**
Well, yeah, and in fact, what I might even offer is because it doesn't snow skin off your nose, you know, offer a let's catch up. Let's talk about what you've been hearing and you know how and what, if any adjustments we should be making as a result.

**Ellie Rofe | 19:46**
Yes.

**Speaker 2 | 19:47**
And you can just packages all part of the service from your view. What you get at of is another touch point, right? Where she gets additional value. It seems like a win. Whi.

**Ellie Rofe | 19:56**
Yeah. No, it's we've done it a couple of times now. We did it at the end first week.

**Speaker 2 | 20:01**
Okay.

**Ellie Rofe | 20:02**
And we did it. So that was likely the first week of January, the ninth or something. Then we did it about a month later, at which point she'd built up about a million, but obviously not in the bag until she gets that lead investor. 
So we'd had a discussion then about whether she should. She was resisting going back to people she'd already pitched until she got a lead investor in this series of meetings. And I said to her, I think. 
I think you should go back to people you've already pitched. I think a really smart investor would see someone who has listened to the market gone away and found a way to improve their strategy and actually really deepen the proposal. 
So I'm not sure she was a bit arming and aring about that. And we. And I'd listened to one of her, calls and then given her some advice on how to frame, things that she feels are speculative. Like with an engineer's brain. She's like, but these figures don't mean anything. I'm like, the figures don't mean anything. 
But the assumptions behind the figures mean something. And the methodology and process by which you have arrived at those figures mean something? No. Projections can be like, yes, we 100% know that in 2028 we'll be earning, you know, 878000 in revenue. 
It's just not possible. But the thinking behind it is what matters. So she felt much more comfortable with that. She's like, yeah. We've put a lot of thought and work into that, and I think it's really strong. 
And it's like, yes, that's what you're telling them. The numbers, obviously, that's the whole point. So we it's been good. It's been useful. But yeah, I didn't want to keep chasing her and making her feel like she's got someone on her back rather than someone who's just checking in now and then. 
Because I think it's two weeks as we spoke.

**Speaker 2 | 22:08**
Okay, right, all that makes sense. So the so that's sort of where the Maddy stuff is. Then the other question I would have is, well, I guess, like, you know, where are you in terms of being able to. I mean, there was like, I'm sorry, I forg I only listen to this week's report. I hadn't quite compared it with the previous ones. 
But you had another fins solution you're talking to.

**Ellie Rofe | 22:36**
UBS. Yeah. So. That was the initial target for the portfolio. So I have sent that over to Paul and said to him, let me know, because he's the one ordering it internally. He said he'd give me a bit of feedback because I realized part of the struggle I was having was that. 
So Paul doesn't really engage with stuff until it's in his cycle. He's very busy. He's constantly doing like there's the Hextels, there's you know, the this conference that's happening, there's this big push or whatever. 
And so I don't he's quite in the cycle for this conference yet, and it's been incredibly difficult to get hold of him. When I do get hold of him, he's great, but he's a bit breathless and he's rushing through stuff and he's doing his like, thing before he can get to the thought because he's got so many things going on. 
So he said he'll come back to me with feedback. Now I'm meant to be. He wants me to meet with this woman. So I'm meant to be in the UK from the sixth of may at March to the 15th or something. So I am trying to push for that to happen so that I get to meet him and the head of global events in a couple of weeks in person in London. The goal was we would have a lunch together first. Me and Paul. To just kind of go through stuff. Probably team me up a little bit to what? He this woman wants to hear from me. 
But yeah, I'm waiting for him to give me a bit of feedback and I will follow up this weekend because he won't reply to me on a Friday afternoon. But I will follow up theend, and say like, where. Where are we this what can I do to get it just right for her. 
And then I've done or I've been working on today I'm going to finalize it after we get off this call. I've done a version of the portfolio that's more pitch deck focused. And that's for, the biotech consultant that Max introduced me to ages ago. That I have to be honest, I slightly forgot about, and then another guy he introduced me to just before, Christmas. Who is the that was a corporate access, spinout, basically consultancy in I think they said biotech and tech. 
So I will get in touch with them and see if they're in any need of anything. I will follow up with. I think he's a little bit of a waste of time, but I'll follow up with my friend in the, like P space, who just before Christmas asked me to do some work on a pitch deck, but it was a wreck of a deck. 
I mean, just awful. I can't tell you.

**Speaker 2 | 25:38**
That's a series. Wreck of a deck. And I say that as someone who on whom that expression could be turned.

**Ellie Rofe | 25:55**
I know. I think it would go down better on certain other places than the LinkedIn, which is a bit more like positive vibes only, but yeah, he just tearing things down. And again, this is a wreck. 
If it means yes, yeah, that might be a bit nicer.

**Speaker 2 | 26:08**
Or from wck to deck is

**Ellie Rofe | 26:14**
We put this out of the seabed. Yeah, it's he asked me to do something. It was the 23rd of December when he emailed me and said he needed it by 2 January. 
And it was just a bit of work. And it's like, okay, I don't trust it when people tell me what the work is going to be and how much of my time it will take. So he's arming an arning. He really wants help, but I think he's arming and ironing as to whether he wants to pay for it. Frankly, he asked me to do like if I get, if I win the deal, then I'll pay you. 
And I said, in a much more diplomatic sense, if you want me to work on this with you to make it actually make sense, then I will do a like 50% profit share or something. Or seventy percent. I can't remember what I wrote, but at this point with this deck, I'm not doing any sort of thing like that, so I don't think it will win a deal. 
So that was it. It was more diplomatic than that. But we have known each other for years as well. So he. Yeah.

**Speaker 2 | 27:20**
Alright, you have Claude, right? Do you use, what are you using for your email? So are you using Gmail or okay, is there a Cloud Outlook connector?

**Ellie Rofe | 27:29**
Our outlook? I don't know. I can check.

**Speaker 2 | 27:38**
All right. I've been doing some experimentation with Claude, and like, just plugging into my email, it is able to get really some very good insight when you talk about, like, things you've forgotten because.

**Ellie Rofe | 27:48**
Yeah.

**Speaker 2 | 27:51**
Because time makes tools of us. All right. 
But because, you know, just. You know, and. And even more compounded by, you know, the fasting and the work and health and what have you. Rather than putting yourself in a position of, wait, I forgot about all that stuff. 
Like, just say, let's go back over the last six months, you know? Who have I talked to? Where are my drop balls?

**Ellie Rofe | 28:14**
Yeah. Okay.

**Speaker 2 | 28:15**
It can do that. It can do that by going over email and the, this is yeah, this is just AAA mechanical use of AI like, I know I should do it now.

**Ellie Rofe | 28:23**
Okay.

**Speaker 2 | 28:33**
You know, it should be done. And I think you can flip these things and say, okay, what are things that you think you should do? How can you turn that into the passive voice? And how can you give that job to your best friend?

**Ellie Rofe | 28:47**
Yes.

**Speaker 2 | 28:47**
I think there's. I was just talking with someone. I actually talked with Demetris earlier this morning. About how to, you know, how his, you know, knowledge graph can, you know, sort of switch around and how CRMs often die on the vine because there's no information. 
And, like, his big advantage is. Hey, there's this place where there's information like, how can you get more information in? How can get information out? Like that's what I think his brain graph needs to be doing next. 
But what I didn't say was actually for a lot of the stuff is by email. I don't know, for a lot of that, AI can do a lot, but I don't think it's well known that people can that it can be used. You're already getting into it, you're already talking about things like Figma. S you know Figma mcp you know this is permitted to help you.

**Ellie Rofe | 29:26**
No. No. Yeah.

**Speaker 2 | 29:32**
I think you'll get something from that and you'll find. Wait, hey, there are these leads that have been lying around, and then you can be putting them in motion. And it's not about, like, how do you hustle and like, fill up all your hours making all the possible content. You're doing a health thing, you're taking you're helping out Nick, you're doing this stuff. 
But, like, let's make sure the stuff that matters we're putting into motion. I was talking to another guy, AJ. Lawrence. He does a. He does a podcast. Does some investing. We catch up once a quarter, and he. 
You know, his thing was he knew he was in trouble when he told his coach, I don't have time for coaching.

**Ellie Rofe | 30:10**
Right, yeah.

**Speaker 2 | 30:12**
I don't have time to think. I'm too busy doing things right. And you know, the, you know, as you've got, you know, these other pressures on you, right? 
It's like, okay, how can we figure out just the important parts? And, you know, to the extent that some of the important parts can be done without your marginal work. All the better.

**Ellie Rofe | 30:32**
Yeah, it is a really good point. I think, there is a perpetual SE I think partly there's a chicken and egg to this, which is that as I. Yes, AI is really important. 
I think I need longer term if I can build the business. I do need a bit more sort of like actual contractors or whatever, people who are able to do stuff for me that keeps me tick along. I think I'm not. I look at some people are like, I built this business just where they are. 
And I'm like, I actually think I'm better if I have people around me. And I've not realized that for a long time. But yes, I think in the meantime, leveraging AI wherever I can. And I am experimenting Claude and Excel fascinating like really interesting, going to be very useful when I'm modeling things again. Could not handle the SBIR data absolutely collapsed. It was just like I'm trying to batch it. 
Okay, I'll try to batch it like this. No, I'm trying to butt no, I can't I ur and just could not buttch it. But yes, it's still useful.

**Speaker 2 | 31:45**
We learned.

**Ellie Rofe | 31:48**
So, yeah, I think. I think partly the reason I have. Partly. I had to cancel the interview with Lauren because of everything. 
But then I feel like I have been. I need to. I need to work out how to best edit those interviews because the one with Alister is just a massive sprawl of information, and I need to, like, edit that down into something that's parcelable. 
And that in itself feels like a big old job. And. And I think I've been then avoiding the interview thing, partly because I haven't had the energy or the wherewithal to get to it. But. But I need to get back to that because that is another form of ideas, and that is ideas as well as talking to people and understanding them. 
It's just the processing afterwards is a bit of a pain.

**Speaker 2 | 32:41**
Well, okay, well, that's something that needs to be done right. And you sort of talking about people or what have you still using your accountability person.

**Ellie Rofe | 32:49**
Yeah, two.

**Speaker 2 | 32:52**
Do you think that person either is or maybe could know somebody who could be helping you out with the video eding.

**Ellie Rofe | 32:58**
Yeah, she I did want her to help me because she's incredibly reliable and I love her to pieces, but, it was she said a while ago I committed to just doing accounting, so I'm not doing anything else. 
And which is a real shame. But she did try to do some youtubing at one point so I can ask her if she knows anyone in that world who would be keen to do editing. Definitely.

**Speaker 2 | 33:23**
You're just looking for that bit of help. I've. I've asked this question in the first world before. And I keep on getting like these massive agencies who want to, you know, do professional video, blah. You're like the YouTube stuff that's way below we can't make any money that. 
Yeah, which is absolutely true.

**Ellie Rofe | 33:39**
M.

**Speaker 2 | 33:40**
I know, a somewhat prominent YouTube, and if you are looking, who I think was using some Eastern Europe folks helping out with editing.

**Ellie Rofe | 33:50**
14.

**Speaker 2 | 33:52**
He's not doing that right now. He's much more hands on with this stuff. He's doing it for reasons of quality control and sort of like trying to reconnect with his craft. More than I think. 
You know, Oster, you know that didn't work out. But if you're looking for recommendations that front. I can reach out to Tim and ask him about that. But you know, if the editing is the problem. You know, what you can do is get someone else to do the edit, and then you can look at the edit and you can be the judge of the edit. 
You know, we're not really getting the good stuff here. I remember he said something really good about X. And then you can sort of be looking back what got cut. And this puts you in a position to be able to dial in the eddor. The editor isn't going to completely remove it from your table, right? The job of the editor is to substantially reduce the amount of time, right? 
And to be the actor while you're the reviewer of it and have that go back and forth. But it might help get off the mark in terms of being able to ship that stuff, which then turns it into a marketable asset for you and makes you start to actually have the rest of the interviews. 
And you doing the interviewing is the highest value thing for you to do.

**Ellie Rofe | 35:00**
Yeah. I mean, I the struggle I'm having is I can't do it.

**Speaker 2 | 35:01**
But cheap?

**Ellie Rofe | 35:04**
I can't pay someone at the moment. So if the SDP thing goes ahead, then I can pay someone. If not, then it's entirely reliant on me. 
So I need to plan my time a bit better, and I need to make sure my energy is up so that I can keep doing all the different things the interviewing, the in inviting, the managing, the editing, the promoting, et cetera. 
And I think I probably just need to get if that's the case, I probably need to get six done before I start releasing it because I need to have worked the muscle, worked out the process and have some stuff ready to go in case there's any problems or breaks in the process. 
But, yeah, it's definitely the direction. And you rightte.

**Speaker 2 | 35:48**
I'm not sure. Weekly regularity is the thing you should be focused on most. And there are other people who have, like, done podcasts where I talked to, like, you know, I helped out like Preca Chara with his. With his podcast when I was his first guest, just to get some stuff in the pipe.

**Ellie Rofe | 36:01**
He.

**Speaker 2 | 36:01**
And then he was talking about, like, let's get, you know, he wanted to have, like, you know, three or four before they started. She'd be like, why would you wait? You know, one of the great things is if you and I'm thinking about the ster, right? What is the big benefit of you doing this? Part of it is you being able to share to the world, but non trivial. 
It's about your relationship with that person who just interviewed. So if you can, in a reasonably short period after you've had a conversation with that person, you know, produce something that makes them look good, that's a win. In that relationship, which it sounds like the relationship has, you know, lots of economic consequences too.

**Ellie Rofe | 36:39**
Yeah.

**Speaker 2 | 36:40**
And I appreciate like, you know, like I'm not trying to like do it all as soon as possible, but the. But becomes a reason for you not to say, let's get it banked so you can have, you know, smooth delivery afterwards. 
If what you have intermittent delivery of great content or great, you know, of their great insights, of them looking good, right? Then you will get the greater benefit of the relationship with them. Plus whatever the world happens to see. 
You know, you're not making you're not competing for your, you know, 07:00 pm Sunday night. You know, BBC 4 slot.

**Ellie Rofe | 37:17**
No.

**Speaker 2 | 37:18**
There is bc4. I don't even know.

**Ellie Rofe | 37:19**
There a BBC 4? Yes. It's the arts and culture part.

**Speaker 2 | 37:23**
Okay, I close on target.

**Ellie Rofe | 37:24**
Yes.

**Speaker 2 | 37:27**
But the idea is the, you know, just if you have something good, you know, share it, and then it produces more for you sooner. 
And like what we can do to sort of not have it be that you're rushing right, but that the stuff that's working for you is moving left on the timeline to be helping you sooner for all the reasons discussed. 
And then so that, you know, you were talking about, like, you get sick, you get injured, you get. I mean, neither you nor I are completely spring chickens anymore. We just need to anticipate that, like, not every week is going to be a banger, right? Or worse yet, some weekend. Some weeks are bang ups and like, you know how you can like, what's the most important part? We do that and then if there's more room, we can do more. 
But, I actually really like the idea of constraints because you know how many people I talked to my frankly, Cometri is a little bit. He's like, I'm spending so many hours a week making, you know, late tin content. 
Like, are you spending so many hours a week making LinkedIn content? And partial. I think it's just how he feels busy, right?

**Ellie Rofe | 38:34**
Yeah.

**Speaker 2 | 38:35**
And I kind of like that. You don't need to feel busy because you have these other constraints. 
But then, like, just have a clear North Star. Like, what's important? So we do that.

**Ellie Rofe | 38:47**
I have been. I have been trying to have that on a I've been trying to do a weekly setup with Justina. So in the mornings on a Monday before I speak with her, I review the previous week and then go, right, what are the three key things this week that I need to get done? 
And that's I've only just started this week, but it is it has been helpful. It is useful. I think I'm. I'm at a precarious point in that process, unfortunately, where the efficacy of that process is starting to wane because it's no longer novel. 
So I think. But I think this point at which I just have to push through and make it habitual rather than novel. And as I'm doing that workout, in fact, maybe a really useful thing I could do is dump transcripts of that of my morning calls because they're short into something and say, right, what is or isn't happening here? Where are the. Where are the, you know, the leaks? 
You know what? What is actually progressing? What isn't? And where am I, you know, making errors in my approach or whatever. And find a way to revive that in some way?

**Speaker 2 | 40:07**
Death for me has been one of the most valuable things I've done with Krisp is look across meetings. I've got a automation sets actually haven't downloaded. I have now have an open Claw running as well. 
You know the Claude butt. I've connected to my email and I have it connected to. Well, I have it up on Xano because I have a Xano instance, where I'm storing my Krisp transcript scripts as well as ones like from, you know, this kind of in Zoho recording. 
And it allows me just sort of ask, hey, let's look at the conversations I've had with X, right? Let's look at the cor look at the conversations and just, you know, what's the arc of it, how things changed, what's the trend? 
So I'm planning those to be far more useful than summary of any given meeting. So you might find that by taking those meanings you're having with is, you know, or what have you because you're hat and Krisp, you can pull them out, that you might be able to get insight that wasn't immediately obvious to you. I did that conversations recently, not with you, but like William someone else, and it was amazing. 
Like, wait, we talked about what when did that happen? And then I asked about that. Dive into that like then I understand that. Yeah, sure that does make sense that they said that then they said this, then there there's a line that's running through that and it sees that and I don't because it's reading the thing in real time and I'm just trying to remember it right in whatever the power from cabinet I'm got.

**Ellie Rofe | 41:34**
Yeah, so is. I have to say I stayed largely away from Claude open claw stuff because it sounded like a huge amount of noise and I just wasn't in the space to really have any use or interest for it at that point. Is it actually useful? 
It's not just hype. It's not just a load of, like, you know, Twitter influencers. And coin influences and stuff. Just trying to push something.

**Speaker 2 | 42:05**
It is useful.

**Ellie Rofe | 42:07**
Okay.

**Speaker 2 | 42:07**
I'd say there are, you know, three things about it that are really quite useful. The first one is the insight that, like, you know, you don't need to have a bunch of formal relationships for it for things to connect to the services and tools that you use every day.

**Ellie Rofe | 42:24**
Right.

**Speaker 2 | 42:25**
Right? Like, you know, this guy Peter, the guy who made who who's since now works for open Eye. 
You know, he actually made a whole bunch of these little tools, right? Like little thing for talking to Google Service. Little thing. For talking. Something else. 
Like. Little thing talking notion. And then he makes this Claude boot that actually sort of uses a lot of these things. Or it's like connected tissue for these little bits. And one of the reasons I think that's really interesting is that those are, you know, now instead of him having to have a formal relationship with notion or use the initial notion whatever. Or like the way that, you know, Zapier is done. 
Like you just do things and. And because the thing can create code under the covers. Because that's what all these agents can do. They can figure out how to build a bridge to whatever it is you need. This is where like, the whole Mac Mini part becomes interesting because it can additional like directly connecting something like, you know, Google Services or Outlook or whatever. It can just manipulate your browser or manipulate things on a Desktop. 
And that means. I want to go open up my Slack. Okay, I'll go open up your Slack and I'll send a message to Bob, right? That the kind of thing you can give an assistant to and they can just do on your behalf, which is very great. 
That's thing number one is sort of an idea that you can just do things as a result of code use. The second big thing about it, I think, is the idea of self improvement. So I could say figure out how to do X and it'll go get skills, it will go download software, it will grab things. This isn't actually super complicated for an agent to do, it just requires you to download it and then be in a new context. Cloud code can do this stuff too, except cloud code doesn't know about the things it did until you restart cloud code, and this is kind of like it's always restarting itself, which is not a huge technical insight, but like wow, it makes it so much more useful. 
So I figured I to do X and like it. It does the whole I know Kunu thing, and then. And then it can start to do kung fu for you. And that that's a that can be a remarkable and useful experience. That idea of self improvement that rather than I got to go find this plugin, make it work, you guys say, I read about this plugin like, here's a Twitter post with a plugin I thought was cool. Can you add that to yourself? 
And then it does.

**Ellie Rofe | 44:41**
Yeah, hu.

**Speaker 2 | 44:42**
So that kind of relationship is very different from what usually associated with software. The third thing I'm say is different about it is probably the thing that's most profound in our relationship with AI, which is our initial relationship with AI call it, you know, chat GBT right? It was all text generation. You type something, it type something back, right? 
And then there was a genenttic AI, which is really my tool use, right? So like I would, you know, I say what I want and then it goes and either gets things or does things. Right? Basically through expressing, you know, running functions right on either end, right figure, you know, has tools it was introduced to that can work with one of the big insights of cloud code.

**Ellie Rofe | 45:20**
Yeah. Returning in structured format, et cetera, blah. Yeah.

**Speaker 2 | 45:32**
You're using cloud code with the Figma thing, right? 
Yeah. So one of the big insights of cloud code is actually it only has like four or five tools.

**Ellie Rofe | 45:42**
Hey.

**Speaker 2 | 45:42**
So rather than having a huge universe of tools that figured out I need to know how to read and I need to list, I need to know how to do what what's called the bash tool and bash is the truck and it just is able to then do anything right?

**Ellie Rofe | 45:51**
Yeah. Yeah.

**Speaker 2 | 45:55**
That becomes the everything tool. 
And as a result. Training. Need to do nearly as much, and this really simplifies things. It just needs to know how to compile a command line to do that. And that's kind of all Claude Boots doing as well, right? You figured out. 
Okay, what's the command to go install this new tool to do whatever. Which, of course, the fact that it changes itself, that's part of what makes it dangerous from a security point of view, right?

**Ellie Rofe | 46:18**
Yes.

**Speaker 2 | 46:19**
Can do more stuff, but it what gives it exceptional power, right? Just like hiring someone and saying, go do this thing, figure it out. 
Well, it figures it out, and that's really remarkable. But the but third thing is autonomy. And the autonomous aspect is it does things not just when you ask it to, but later. So in Claude Bod or open Claude, this is called heartbeat.

**Ellie Rofe | 46:45**
He.

**Speaker 2 | 46:45**
And so the idea is like five minutes, sort of popping its head up and saying, I anything I'm supposed to do right now. And if you say every day I want you to send me an email at 08:00 am, they'll Papa says, hey, is eight am. 
It's 8 am. I ever send that email to Dele whatever. Like, I have a thing like half an hour before meeting, so it can bero, but you can be it can be a little more. I mean, it's a crime to the extent there's a process running every like five minutes. 
Yeah. Totally.

**Ellie Rofe | 47:15**
Three.

**Speaker 2 | 47:16**
Right. That's fish. But the other aspect of it is it's a process that runs every, the but the idea of the heartbeat is that it's combining that with judgment. It's waking up saying, okay, hey, what is there something I'm supposed to do now? 
And it doesn't create a lot of complexity. I'm like, okay, I have a whole calendar, and I'm gonna put this over here, the 08:00 am this over here, it's a list is my checklist, right? If it's 08:00 am, I'm supposed to do this. 
If it is, you know, Sunday at 12pm, I'm supposed to do this. If it's. If there's a that's supposed to happen in twenty minutes, I'm supposed to do this. And so asks what's my situation for each of those? As true. 
And that's really impressive. I found that last part that autonomy is so different from the way we generally work with AI because most AI is ask, you do a thing and it does a thing right? 
Your relationship with Claude. Code. It can be long running. 
Like maybe you're gonna put it down and go get yourself a cup of tea, but it's because you just asked to do a thing.

**Ellie Rofe | 48:11**
Yeah. Yeah.

**Speaker 2 | 48:18**
Compare that with, you know, you're saying, go do this thing later or every night or whatever. 
And the autonomous aspect is really kind of freaky in terms of how useful that becomes, because that's the kind of thing like we get to an assistant, say, just go make this happen every day or, you know, on demand or check my email and if it's something comes in, whatever. 
It's such a simple model for doing it not computationally at all, right? Because none of the I but it is but that's where the power. So that autonomy, that ability to self improve and that insight that it's like just made up of these little things that allow us to just do things. You don't need super special tools to get it done. Those are the great insights of open Claude. 
It's a reason why I'm not super worried about open Claude as a product, right? But as a concept and as a trend. Like agentic. AI was a big story. I think at 2025 a Thomas AI. It's a story of 2026.

**Ellie Rofe | 49:22**
It's interesting because obviously these probably are a bit more cronish, but I'm not sure. But GPT is just ChatGPT has put in some sort of task thing, timed tasks, I think, specifically, and automations, right?

**Speaker 2 | 49:37**
Automation in power. Yeahmm.

**Ellie Rofe | 49:40**
And Grock has now done the same. And I think Grock has like a run ten end basically so that yeah, you're right, it's people are trying to shift to that autonomy level. 
Interesting. What is the Mac mini thing, if you don't mind me asking?

**Speaker 2 | 49:57**
So the. Because open Claw is actually designed with a whole bunch of tools that work really well on Mac and because it knows how to do computer use. 
And basically having to do computer use as you is really powerful. And if you've ever seen, like, Claude or whatever start to manipulate your browser, it's a little freaky. It's like, wait, it's actually getting things done. 
It's doing that stuff with me. But like it that that's but that's a feature of open Claw. But the trick is you start to have it manipulating your Desktop while then sticking over your Desktop. So people are buying Mac Mini as a less expensive and a little bit headless way to have their. 
And putting open Claude on them. So they log in themselves, log in their browsers and say, hey, open Clath, go for it. And then OPENCLAWS acting as them. They have the same interface with OPENCLAW, like through their chat app, like a Telegram or WhatsApp or whatever. 
That's how you communicate with it. And then. And then it can just do things for you as you without interrupting you. So you're doing whatever you're doing on your primary computer. And then people will have it running on the Mac Mini. 
And the reason for the Mac Mini is because Mac Mini can run the same consumer software you otherwise use, right? And it's just using it. And you're just having the OPENCLAW stuff use it for you. This as opposed to like, you know, actually the way I use open Claude right now is through a virtual private server. 
It's called a droplet on DigitalOcean. And so it's machine running that's you know, I control but definitely doesn't have access to like a browser or anything to be able to do that stuff for me.

**Ellie Rofe | 51:27**
Yeah. Yeah.

**Speaker 2 | 51:31**
So it's a. Which makes a more lockdown experience, yeah, than one that's still super helpful to me. 
But like, Robert went and bought a Mac Mini so that he could have open cla working for him, and he's having. And my hackathon partner, AA is doing that. And, they're both finding it to be just phenomenally useful for me to just go have those conversations.

**Ellie Rofe | 51:54**
He that's really interesting. I mean, I have a Mac Mini that, has fun, just de facto become the thing we watch TV through, so. So I think it might be able to be put to better use. Causecause. 
Yeah. That's just sits in the room. Interesting.

**Speaker 2 | 52:20**
It's to pay attention to. Right. And like, you know, if you're paying attention to it through like, you know, through like the Codex apps, you know, automations or whatever. 
But. But those three things are the things I pay attention to. The first them makes it much more permissionless, right? That's the. Hey, all these little tools that be doing stuff like he, who was talking about this?

**Ellie Rofe | 52:40**
Yeah.

**Speaker 2 | 52:46**
We're talking about how Peter had no special access because he was just using that, which is. 
I mean, like, he's a very smart engineering who made another PDF processing software that was that's very widely used and sold it for a bunch of money. But the. Yeah, but the. But he didn't have any, like, special insight or special business relationship that some of those people brag about. 
Like, I got easier early access to whatever. No, he just had. Everybody else did, and he was able to make this just through. Because you can just do things.

**Ellie Rofe | 53:17**
He.

**Speaker 2 | 53:18**
And that both means there's a lower competitive bar, right? 
So don't think you're gonna be a billionaire doing the same thing. But means that we all can do many more of these things. And I think that the more we understand that about ourselves and how we work, the more we're going to be connected to like where the market's going in the course of the next six months. 
And that that's how the world has changed. I mean, whatever open Claw, I think became available at all at the end of a fourth quarter last year, maybe November, something like that. So it's ninety days. This is ninety days of this thing, and who the heck knows what's going to happen in the next 90 or the next 180, which is exciting stuff, but I think the economy thing is that the angle I would pay. 
I mean the first one, you can just do things. The second one, self improvement, is actually that someplace it's a security thing, but that's I think, a really cool aspect. I'm but I'm looking for Claude Code probably to start doing that by itself in the coming weeks. 
And then the autonomy part, that's just a different but that's just different model and one that I'm really looking forward to because it's going to build a value.

**Ellie Rofe | 54:25**
Yeah, fascinating. Okay, well, I am going to try it at some point. I'll go get this portfolio and more importantly, but I will try it because it's going to be fascinating.

**Speaker 2 | 54:36**
Okay, it is. Yeah, it is fascinating. And if you got a thing can be if I can be helpful at all on that front or really on any other. You know, you've got my county. I'm happy to sort of be coming in here, but to sort of keep in mind that like, you know, let's front load the things that are most important for you first. 
In that way, you're not feeling like you have to sacrifice the health parts, right?

**Ellie Rofe | 55:06**
Yes.

**Speaker 2 | 55:07**
Or other things you find to be important to be squeezing in more of this.

**Ellie Rofe | 55:11**
I think it's okay. I think the health thing is recovering now. It just knocked me quite significantly for a while. And then it takes a little bit.

**Speaker 2 | 55:19**
Yeah, the injury plus the. Yeah, right.

**Ellie Rofe | 55:22**
Yeah, I think. I think alternate day fasting and insanity was me at my limit. And I felt good doing that, but I didn't realize that then going and sitting on a roof on a fast day, running around the roof when I'm terrified of heights and then coming in and doing insanity, it just knocked me for six. 
And then I did insanity again, and then my back went. And then I was, like, really low and felt sick, and it was just. It's like, no, you are 45, stop it. And you're unfit and overweight. So, you know, you're just going to have to do this at a certain level, not up here, but it's fine. We get there, we work out.

**Speaker 2 | 56:04**
Yep, we do. Let me know if anything else second be of service to you and all of that. You have yourself a fantastic weekend. And I hope the sun stays out for. For you. And gives you a little break from the glo.

**Ellie Rofe | 56:14**
That would be very nice. Thank you, Ray. Have a great weekend.

**Speaker 2 | 56:17**
You too. Bye.

