# Ellie and Ray Zoom - Mar, 27

# Transcript
**Ellie Rofe | 00:03**
It's late again.

**Speaker 2 | 00:05**
It's fine, Ellie. No problem.

**Ellie Rofe | 00:07**
How are you?

**Speaker 2 | 00:09**
I am all right. Ma'am. It is turning into a glorious day today, and apparently, we are now far enough into what is supposed to be spring that I made the mistake of putting out my trash last night, and the bear came.

**Ellie Rofe | 00:24**
Wow. That's terrifying to me.

**Speaker 2 | 00:28**
I live out in the country. Enough that apparently, you know, bears.

**Ellie Rofe | 00:33**
I mean, genuinely terrifying. We have badgers, which are the most dangerous things, so it's another world.

**Speaker 2 | 00:46**
Yeah, there's a whole thing of, like in Europe, it's all pretty friendly, right? In terms of wildlife and the. And like the experience in Europe is like. Wait, when we go to, like, crazy places like, you know, say the near East, right? Or, you know, North Africa, what have you. All of a sudden, the biome was very different and more hostile and the same thing of America.

**Ellie Rofe | 01:04**
Yes.

**Speaker 2 | 01:06**
Apparently, there was a whole thing early on that people thought that the devil lived in America because of all the dangerous animals.

**Ellie Rofe | 01:14**
Wow, what would they have thought of Australia then? I mean, you know, it's a crazy town. I lived in the Northern Territory for a long [Laughter] time.

**Speaker 2 | 01:21**
Well, that's. You brought that?

**Ellie Rofe | 01:25**
Yeah. Yeah, I lived in the Northern Territory in Australia when I was out there, and.

**Speaker 2 | 01:32**
Really?

**Ellie Rofe | 01:33**
Yeah, and it's a totally different... It's like the real roughneck part. I was up in Darwin, which is like a port town. Subtropical and beautiful seas. You cannot go into them because they are filled with tiger sharks, box jellyfish, and sea snakes, very poisonous sea snakes and saltwater crocodiles. Just casually.
So you're like, "I won't have a refreshing swim today. I'll just stay quite far back."

**Speaker 2 | 02:11**
The saltwater crocodiles are... Those are huge, right?

**Ellie Rofe | 02:14**
Terrifying. Absolutely terrifying. We took a tour, and we were poor backpackers, so we were in this little tinny, like a little, you know, tiny little boat.
And we saw. We saw these, like, huge, two story, like steam paddle type boats. And this guy was talking to us about these crocodiles. And one came up. And I probably can't quite do it. Like the head was the eyes were so far apart. He was like, yeah, that's psycho. He's like, you know, 4m or.
And I was like, Christ. And then we looked out and they were holding up these pieces of meat on sticks from the second story of the boat. And these crocodiles were, like, coming up out, using their tail to basically come out completely out of the water vertically.
And we were like, my God. And then the guide's going, yeah, he could totally turn this boat over, you know? [Laughter] Okay. Well, I hope they're all in a good mood today.

**Speaker 2 | 03:18**
Yeah, that's just when you thought it was safe to go back in the water.

**Ellie Rofe | 03:19**
Terrifying.
[Laughter] No, exactly.

**Speaker 2 | 03:27**
I never thought it was safe to go in the water.

**Ellie Rofe | 03:31**
Or to hear my Australian accent. So, you know, there you go, so.

**Speaker 2 | 03:39**
Okay, so it sounds like... I thought that guy feeling you out to be his chief of staff. But that was interesting.

**Ellie Rofe | 03:48**
Really interesting. Yeah, really interesting. It's very early days, but I realize there is a pattern in the. I think a lot of people are very lonely.
I know this is going to sound... It is leading to something a bit more important directly. But every person I spoke to during my interviews with the SDP portrayed some sense in some way, shape, or form, some directly and some euphemistically, feeling lonely.
That's partly the nature of a slightly disparate, volunteer-led organization like that. But then when I met with Paul at UBS, he felt lonely. He feels a bit isolated at times. When I worked with Tom at Oxular, he...
I think sometimes he was paying me just to be able to talk to someone. The just the therapeutic thing frequently when I talk with people and I'm asking them difficult questions, but they get to the end of... They're like a therapy session because they're getting a chance to actually speak about stuff.
Obviously, I don't really want to be like an entrepreneur therapist, but there is something in this that's hard to package and hard to formulate, but I think is possibly quite valuable if you can turn it into proper, defined, objective-led engagements with people.

**Speaker 2 | 05:29**
I think you're putting your finger on a really important idea, and like you say, it feels like it's throwing in something, but it's not really like you talk about being objective. Light and yes, that's important, but I actually think that the connection is a really important thing to sell, and that often when you're talking to people who are in need, right, people who have a problem, often that problem is isolating, right?

**Ellie Rofe | 05:52**
One one.

**Speaker 2 | 05:53**
And in fact, the problem might be isolation, as it turns out. Like they. They. They perceive the problem the bigger it is because they're isolated. Or the problems causing it to become more isolated, whatever it is.
But like the, you know, one of the, you know, big advantages you provide is just the helping hand, the hand reaching out to them, which is probably the first hand they're seeing and that. But that's not nothing.
I think you might, you know, take that seriously, both as a, you know, thing about your offer, but like, what? You know, what the client's offering, right? Like being able to turn it into, you know, being able to identify how they how what SDP that was called, can be offering connection. Better connection because we are all isolated, you know, and like the and often those are the people who they can reach out to, in terms of the you know, what they're selling in the market, right?

**Ellie Rofe | 06:36**
M.

**Speaker 2 | 06:51**
What they're gifting in terms of the party because people who feel they've already got the connection.

**Ellie Rofe | 06:51**
Yes.

**Speaker 2 | 06:58**
Great. They're happy where they are, but people who are unhappy are the ones who aren't feeling connection.
Then these people who are spinning this thing up, it's because they sort of have that void, and while I certainly take your point of being objective-led, you want to create those results, there is an emotional quality to it all that matters.

**Ellie Rofe | 07:18**
M hey.

**Speaker 2 | 07:18**
And I've had people say, like, I was so looking forward to our call this week, right? I've become a source of connection that's otherwise, you know, they can feel lonely or isolated or what have you.
And someone who's actually, you know, listening to them. I know it starts to sound like Arby job, but there's a little bit of that.

**Ellie Rofe | 07:37**
There is a bit of that. I think being outside the structure is actually quite important, which is why I feel... It's partly why I think that it is useful to have an objective-led thing because otherwise it becomes a bit miasmic, and you know who knows what the next day is, and your role becomes shifting and loose, and then you're not actually providing that external viewpoint and the sense.
So Alistta said it to me directly. He said it's really hard to confide in people around you when you're a boss because some of those people... You need to retain a sense of helping them do their job rather than them feeling like you're asking not for counsel, but for emotional support.
But he said unfortunately, in an awful lot of environments, people will use it politically to try and gain advantage because there's a lot of ambitious people around you, and so there's a sense that people I've worked with... I'm not sure that's always the most healthy.
Maybe you want to try and create something where that's not the case, but I don't think you can ignore human nature. So I think there is a sense of being external to the organization, the problems, and providing a confidante role as well as having a different view because you do not own anything inside that organization, so you don't have to feel defensive or anything like that.

**Speaker 2 | 09:13**
Yep. I mean, when you think about it might be helpful just to give to meditate a little bit on how. Others in our society provide that kind of role. Like how a therapist provides that kind of role right through having a Designated Place, which just happens, right?
So you're always having that experience in this place and then you leave that place that the time is managed right? That you're doing this and then you get kicked out after 45 minutes or. Or whatever the length of the session is so it doesn't get to sort of be the thing. I'm extending and extending. My wife, who I, you know, love more than any woman in the world. Filibusters.
And the and like and people other people do this too, right? So, like, how can you know, sort of manage at priests, right? So, like, part of this is the people, part of this is really definitely a confessional role, right?
So how's confession work? Confession works with the screen between you and the priest. You're always going into the same environment again, the same kind of environment, right?

**Ellie Rofe | 10:24**
M.

**Speaker 2 | 10:26**
And then. But it's objective, you know, like I'm confessing to get the confession, which is the catharsis that then allows you to, you know, move to the rest of, you know, maybe be able to go on and be productive after that, right?
Because you're not being weighed down by this anyway. And I'm. I'm sure there are other, you know, maybe even better examples of that, but it's a way of. I mean, the priest has the job of more than just hearing confession, right? They don't sort of hear confession all day long.
And they're not sitting inside your lives, they're always outside. Whether they're supposed to be the community and how do they do that have one role and as part of that bigger sales stuff. I'm sorry. Not proposing that you should take up the cloth, but.

**Ellie Rofe | 11:10**
I haven't got the neckline for a dog collar. I just haven't.

**Speaker 2 | 11:17**
But. You know, but I suppose I'm just sort of saying that the these things your point about loneliness is a point that it's worth giving some thought to, right? Both in terms of how it affects your practice.
Because it's a real value that you provide.

**Ellie Rofe | 11:31**
He.

**Speaker 2 | 11:31**
It's a real need that people have. I'm not saying you go around looking for people who are lonely, but because it's going to be part of the package, it's going to be... How people will have the emotional reaction to you is that they are not only, like you say, having their objective bet, but they are having this emotional need bet as well.

**Ellie Rofe | 11:48**
2M yes.

**Speaker 2 | 11:49**
Through that. Through that connection.
And you're in a better place to do that because of your connection to the objective.

**Ellie Rofe | 11:58**
I think the connection to the objective is interesting. And I love the idea of thinking about how other, similar roles work, because I hadn't even linked to those things.
I mean, people say you're like a therapist at times, but I don't want to be one of those. So finding the patterns that I can extract from that and the disciplines that sit around that are really useful.

**Speaker 2 | 12:25**
I think that becomes the key, right? What do they do to maintain the discipline? Because obviously, when they say you're like a therapist, they're like... The alarm bells go off for me too, because it implies they might not be using this in quite the right way.
That's going to really create value for them.

**Ellie Rofe | 12:42**
Yes, I think it's a way of expressing something they can't always express.

**Speaker 2 | 12:42**
It's frankly not the way that therapists will allow themselves to be treated. Having met and known therapists.

**Ellie Rofe | 12:56**
It's just a shorthand, because a lot of the time they're still talking about business problems. They're not like, my wife doesn't love me, and I, you know, I can't fit into my trousers anymore or something.
You know? It's like. I mean, a weird therapist problem. But, yeah, there's a. There is a. There is an interesting sense in it. It's like an expression of. I have just wanted to be able to unload some of this stuff in a way that makes sense to me and I get some sort of feedback.
But, yeah, that's. I think that's. The other thing is, I'm very well aware that, you know, with Tom, the guy at Oxalla. I mean, he would call at ten at night and, like, just be like, can you speak? And then if I wasn't careful, it would be an hour and a half on the call while he just went through everything in his brain.
And obviously I'm like, well, I'm billing kching. But that's not a boundary. So, yeah.

**Speaker 2 | 13:58**
Well, right. It becomes part of the lack of a trap. So, to your point of staying tied to the objective, there's an emotional element that we, if we take it seriously and intentionally, it's easier to keep it under control if we allow it to sneak up on us or if we're trying to say, "That's not really us." He's calling about this thing, or we'll let that happen. It causes the overall experience with you to get diluted, right?
You're not the only person with this problem. Robert has brought this problem to me before, too, because he's got clients, at least one to my... Who is...? You know, just want to talk for three hours.
Okay, fine, but it gets worse for Robert because then the client just wants to pay for it.

**Ellie Rofe | 14:44**
Yeah.

**Speaker 2 | 14:45**
Boy, just talk. I was spending three hours with you that I wasn't spending with my fiance, and now, you know, we were just talking like and the.
And but the trick is like what? The way the clients sees the relationship, right? And just being able to, you know, manage that in a friendly way, right? But it's disciplined, I'm sure. And actually, I do.
I know for a fact that like that this is a significant challenge that therapists go through.

**Ellie Rofe | 15:17**
Yes.

**Speaker 2 | 15:17**
How to anyway, but, yeah, sorry, I didn't mean to make the whole conversation about that.

**Ellie Rofe | 15:17**
Absolutely. Yeah.

**Speaker 2 | 15:23**
That. That. That was a really interesting and useful, you know, and.
And valuable point.

**Ellie Rofe | 15:30**
Yes, it was. It was something that I put in there deliberately because it was something I wanted to talk about because it's sort of. I keep trying as I go through this process of engagement, I'm wondering what I can take from it to bring back out to the market in interesting ways.
Obviously, the knowledge graph stuff is a big part of that. That's really interesting. Demetrius has been fabulous in helping me understand better and giving me some rules and things that have helped me create a workflow that is working like gangbusters. Now it's really just the whole process of gathering and scraping and sourcing data and the process of defining, structuring, ingesting data and everything is just... It's all making sense. I'm learning about the landscape as I do the human in the loop stuff, but I'm not having to expend my own brainpower on stuff that I don't need to expend brainpower on.
So it feels like it's one of the best crystallized versions of the promise of AI for me, which is really nice because there have been lots of cases where it's not quite... This has actually caused overheads that have been problematic, and Demetrius has really helped with that.
Then I think... I find myself returning as I'm coming up from this intensive thing with all the interviews and this data and all the sourcing and stuff, which has been time-intensive. I find myself thinking, right.
So how can I take these data analysis skills that I'm learning? Or this data processing and analysis, I guess, and turn them into something else like research projects that I can then use as marketing as published stuff as assets.

**Speaker 2 | 17:19**
Hey.

**Ellie Rofe | 17:29**
The data I'm building in itself and the knowledge graph is an asset.
It's a huge picture of the UK political climate. I think I could probably do... Is to start incorporating more to do with innovation into this rather than just politics and start thinking about the money flows and the government side of that and feed into my money knowledge power thing and start bringing that to the fore in marketing and discussion and debate.

**Speaker 2 | 17:59**
Can I ask? Where are you doing marketing right now? Where you're describing your practice as being Rand Knowledge, Money, and Power.

**Ellie Rofe | 18:05**
No, I'm not doing much at all at the moment. I've been terrible. It's just...

**Speaker 2 | 18:09**
Well, I appreciate you. You were sort of you describe like you feeling like you're doing enough, not doing enough.
But the, that the way you describe your practice and your focus to me in these meetings, I think has been more compelling than what I'm seeing from you in the market. And the thought leadership work you're doing feels like it leads into those themes more than like the even really the way we're. You're talking about. Nicelyput.

**Ellie Rofe | 18:38**
Yeah, I feel like Nicelyput doesn't make much sense at the moment. I'm struggling to work out who to talk to and what to do.
So I just need to start talking about the stuff I'm talking about. It is a different register, I guess, and that's where I've probably been a bit hamstrung because at times I feel like an impostor syndrome.
The impostor syndrome kicking up in whatever. But what I have done, which is what you prompted a bit more, is start just talking about stuff rather than trying to define it into words first. I got Super Whisper, which is really helpful.
I'm finding OpenAI with Telegram, and just as I'm walking around, I suddenly think of something. Just being able to whip into Telegram and do that is really helpful. All of which is to say that yes, I do. I probably have a wider thesis around the return of materiality, rail politics. I don't know, rail politics coming and kicking the door and going, "I'm back." As we hit war and tariffs and reshoring and all these things and what that actually means for innovation, entrepreneurialism, and funding
in these realms, I've probably got more of a thesis than I think I have on it. And partly, I think what I need to get used to is just exploring that idea and debating it with people in public rather than trying to bring something fully formed.
That's probably where I just need to get stuck in on. The other thing is, you start on X and it's like, "How do we even start on this?" I've got no followers, I've got no connections, so it's just having to get stuck in and realize that it's going to be a six to twelve-month process to build there and take whatever is worthwhile taking over to LinkedIn as well to keep that visibility up. I think...

**Speaker 2 | 20:56**
Yeah. And yeah, and like, when you don't have any followers, it's more about engaging with other people's stuff, right? And when you have more followers, it's about, you know, putting things up on your own timeline and sort of seeing what seem to be valuable enough there is.
I mean, there's so much slop everywhere, right? But that's where your bit of, you know, actual authentic stuff can be standing outs.

**Ellie Rofe | 21:24**
Well, I'm thinking that what I should really do is when I'm researching a case file, as I have them in my head about a specific topic.
That's where the interviews come in as well, right? I talk to people, I cite them when I'm talking about stuff and then tag them and then... They are part of the story and I build connections and stuff.
So I think it's not just about going on X or substack or whatever and just typing stuff. It's about connecting with people and saying, "I would love to talk to you about this topic I'm working on and try to build things up."
There's so much... It's so rich when you look at hard tech, robotics, and there are huge robotics centers in the EU in particular, obviously in America and obviously China, but that's out of my remit.
Then you look at defense and El Segundo and what's happening there and how that and what is or isn't happening in Europe. And you know, that's obviously very different and then slightly more contentious.
But Israel is an interesting place to talk about defense innovation. Contentious but interesting. Obviously at the forefront of a huge amount of it. So there's huge opportunity. So I think that's where I feel like sounds silly. I feel like the work, with this knowledge graph and getting through these interviews with the SDP, it showed me that I have the interviews in particular all went really well. I got stuff out of people that they didn't think.
I know. I can tell they didn't think they were going to share at the beginning of that call. They felt comfortable enough with me. And I not in a trickery way. I genuinely am interested in them.
So they felt comfortable enough to share stuff with me. That was off the record. So on the record is slightly different, but it gave me an understanding that I can build rapport with people quite quickly. Come through a series of questions and direct them relatively well and get something of interest out of it.
That boosts my confidence a bit to go out and start interviewing people, but it's just cleared the deck in my brain of, like, I've worked the muscle. Now, does that make sense?

**Speaker 2 | 23:51**
Yeah, well, it does, because I think that the... I've made this pitch to a few different people, and I'm not sure how often I get believed, but I do think that interviewing is the one most important skill sets right now.
Your ability to get them to share more information with you. Not because you're going to go exploit it, right? You're not going to go and sell it.

**Ellie Rofe | 24:14**
Yeah, I think...

**Speaker 2 | 24:15**
Advertisers, you're trying to get back for them.
By doing that, what you're doing is you're mining secrets. That's something AI can't do for them, right? BECAUSE I can't give them the answers they have in their head. They have to know what you're doing is sifting those heads so that it can be repeated back to them and so they can actually make... You're making them manifest, right?
The... When we talk about connection, I think that connection to connect their ideas with the material world is... I think we might find it turns out to be a lot of what your practice looks like and what a lot of people's practices look like.
Getting at that and making that deliberate will help you move it faster, right? Because you're not sort of accidentally stumbling into... But what? I think it's about X, but then it's turned out to be about Y.
So the why is happening despite using the X. Wait, I know what it is now. I can sort of help it move forward instead of being dragged along by it.

**Ellie Rofe | 25:28**
I think it feels like that, sir. I think it feels like for the first time in a while, things are actually all starting to coalesce around certain ideas. There's still lots of opportunity to spray off in all sorts of directions.
But... Between the interview and between understanding and having done quite a hard data set. I mean, I have to say the sourcing of it is easier than other data sets because so much of this stuff is mandated to be public that... If I want to find out which companies have lobbying influence over the government, the lobby isn't that good.
But the APG, the all-party parliamentary groups, are all run by people who are effectively lobbyists. So, it's like there are lots of ways to do that. It's slightly more opaque in the entrepreneurial world, but I think there'd be ways and means, especially over time. They're just very expensive means at the moment.
If you can't. Like if you. If you can't find hacks around it, then it's just a very expensive, trip to some of the, you know, like, God, Pitchb and Crunch Basin, Carter and all these kinds of things that have like huge subscription fees.
But yes.

**Speaker 2 | 26:55**
Yeah, I was actually just thinking about metacognition for you. I like the. I'm just thinking about your thinking, right? And the, you know how some of what you are describing, right? And I actually started looking just now. I brought up your accountability book and like looking at you know the prize versus thinking and systems right where the prize is much more I think in the doing of your what you're doing right now with your practice right? Knowledge, money and power that's all about money and power, right?
And to a certain extent, knowledge the and then we're thinking in systems is about thinking and the and like what that means are you keeping up with the morning pages?

**Ellie Rofe | 27:43**
No, I haven't been. I should be. I've been keeping up with insomnia and then waking up screaming late for an 8 am call. But I should be...

**Speaker 2 | 27:54**
Okay. Well, I'm trying to put more shoulds on you, but one of the nice things about morning pages is that when you're thinking about your practice this way, right? It gives you an opportunity and an opportunity to wrangle your thoughts a bit about what you think, what the price is about what you think really matters.

**Ellie Rofe | 28:08**
Yes.

**Speaker 2 | 28:12**
You're outside of the immediate conversation or the immediate research you're doing in terms of the history of money and power, whatever that quiet of sitting in the garden and just writing it down is because the exercise of writing it down makes your thoughts coherent, right?

**Ellie Rofe | 28:17**
One.

**Speaker 2 | 28:27**
Once again, a bridge between your brain and the...
It's when things are more miasmic inside your brain.

**Ellie Rofe | 28:36**
Yeah, yes, actually, that's a really interesting... If I frame this for the slightly resistant part of my brain.

**Speaker 2 | 28:37**
That can be harder to work with.

**Ellie Rofe | 28:54**
I think it would be really interesting to see. I will try.
No, I will do it every morning for the next week and see whether I come to this call with more clarity, interest, or defined areas to discuss or something. Because I feel like I have raced it into it today with a... I was trying to think about what specifically to ask you as much.
I actually really enjoy it when we discuss ideas and thoughts and books because it's useful to have that sounding board, and you are a fountain of all knowledge, so the breadth and depth are always there to bring me value or insights.
It would be really interesting, actually, as an experiment to see if it changes the shape of my thinking when I come into the call next week. That's what the defined experiment is. Just a game I can play with my own brain. Basically, yeah.

**Speaker 2 | 29:57**
Okay. I feel like we've wandered around a couple of things, like talking about ideas. Is there a way that can be high value stuff? I want to make sure you know I'm helpful in having you have a good week coming up. Is there a way that can be or anything particular you're looking at in this coming week that is something we should be focusing on a little bit? Or is it that you're doing your SDD interviews or...
I guess if you're doing a lot of ship the thing... I'm not looking to make a mess of the ship, but it seems like the X factor might be the cell right now. You seem to be doing okay and studying. You found some good books. Great.

**Ellie Rofe | 30:37**
No.

**Speaker 2 | 30:38**
You've got some ship.
That's what you're doing with SDP. Great. But, you know, let's get you that next. Next client, too.

**Ellie Rofe | 30:45**
Yeah, absolutely, I think that is the key. What would you be doing if you just left things a bit cold for a while?

**Speaker 2 | 31:00**
I'm sorry, what do you mean?

**Ellie Rofe | 31:02**
I haven't been posting, there's no algorithm waiting for me to step into it, as it were. There's...
I've done quite a few follow-ups, but there's not a huge amount of follow-ups left. What would you...? What was the first thing you would do? I think sometimes I get such a big thing in my head. What's the first thing you would do?

**Speaker 2 | 31:29**
I think the first thing I would do is get dumped going. "You're using Super Whisper?" I find it often easier to speak than to write, and I think that's because I'm more of a writer. I'm more afraid of the word. Get more dumped out, talk for an extended period of time.
Then I would feed that back probably and use ChatGPT to be pretty good partner for this stuff. Help me sift out from there what's the next thing I should bring into the market? What's the next idea? Which of these ideas seems to be the sharpest one that I can bring into the market?
Then I think if you know what the idea is, the packaging of X versus LinkedIn versus whatever that becomes a lot more mechanical. I think that the blank page problem has a lot more to do with going to write rather than how we're going to write it. Sometimes we think what the problem is the how.
But really, the problem is the what. So the... I've... There are a couple of alternatives, right to just blabbing into the microphone. Although I'm starting to get better at blabbing into the microphone. I'm using Whisperflow and yeah, sort of jamming down on that function key in order to turn breast to a press talk. Blah.
And then, like, hey, where am I sending this to? Like, I just put it right into Claude. And then you know where the mission I give to Claude is. All right, help me make sense of this Bush with the interesting ideas, you know, help me sort this out a little bit.
And then, yeah, the next thing I will do is. You've been using Krisp? Are you? Have you installed the Krisp M CB server?

**Ellie Rofe | 33:17**
No. I didn't know they had one. I spent ages setting up some Zapier thing to try and sort out stuff.

**Speaker 2 | 33:22**
That's what I did for about the last 15 months. Then, in the last couple of months, I'm not entirely sure when exactly it came out, but about 45 days ago I discovered the Krisp MCB server.
It's buried in the documentation, but if you look at the documentation, just search for MCP, you'll find it immediately. The gag is it'll just work with your ChatGPT. You say, "Let's go check out my Krisp and let's go look at some recent meetings and what are trends that come out of this that can be helpful because then it's not just your ideas, it's your clients' ideas, or even your ideas as manifested through your client conversations."

**Ellie Rofe | 33:46**
Yeah.
Yes, that's really useful. I had set up in open-chatGPT because I'd done it all through these Zaps and stuff. Zapier had broken, I think somewhere along the line the zap.
So I didn't end up with the... Wasn't working. But I had to set it up to review our calls, the mastermind, my accountability sessions, and do a little reflective thing. Then I was going to do client-level reviews, but actually just dumping it all into one thing and just going, "Look at this talk to me is really interesting."

**Speaker 2 | 34:42**
Right? And like it can search, it can pull out what it needs. Obviously, the CMS server itself is just dumbest rocks.
It's a hammer or a screwdriver, right? But giving it to the AI plus your own insight and judgment... Well, wait, this is an interesting angle. Let's go research on these. Now you're getting ideas to be speaking back to you. You've got good words that are in front of you and this is giving you momentum towards...
The words are being given to you aren't the AI's words. You're not dealing with AI slop. You're dealing with your words. You're dealing with your client's words, what they have to say. What do you think about this?
Then you're starting to use push to talk to get your own thoughts out. Then you can start to express yourself in a number of different ways. So like that, I think what I find the thing that holds me back when I'm doing content isn't the mechanics of getting content out, it's what's the idea when I'm sitting on the chair lift thinking, "Okay, I should record a video. I've got a minute. The weather's nice enough, I can actually hold the phone in my hand." The problem I have is not "How do I package this in six seconds?" The problem I have is "What am I going to talk about?" This's worth talking about.

**Ellie Rofe | 35:53**
Yes. I think that's where I always end up in nots. But yes, it's a really good point.

**Speaker 2 | 36:02**
Anyway.

**Ellie Rofe | 36:02**
Yeah, well, interestingly, I have an all-on Twitter where I debate things with people.

**Speaker 2 | 36:02**
I'm just trying to give ideas on how to break that down.

**Ellie Rofe | 36:15**
I will not debate on a public domain because it's just too controversial and difficult. I'm not being edgy, by the way, but I'm debating things with people. And I think I've probably got much clearer in thinking about those things because I just do write, talk, think about them and have published on them.
So yes, clearing the decks to just keep doing that is.

**Speaker 2 | 36:41**
I just have to be.

**Ellie Rofe | 36:42**
Yeah, thank you. Clearing the decks to keep to do that faster because that is the loop. You're right. I mean, you've always said that's the loop, and I obviously clearly resist it, like some, like, errant child, but it is the loop.
So, I need to, you know, it's a system, a feedback loop. And if I'm not giving myself any kind of feedback loop, but beyond my own brain, then it. Yeah, or public feedback loop, I guess, yes. Okay, fabulous. That sounds like a really good plan.
And what's lovely is, now that I feel like I've sorted out how to wrangle things in, AI can just set that up nice and easy locally to just ping through all the time.

**Speaker 2 | 37:28**
Yeah, I have a friend who says, "Don't make me think or I don't..." Who he says is "Don't make me think" is a book and a good book. But what he says is, "I don't want to think." And I think that's a very dangerous place to be.
I think people like you and me, we want to think, right? We need a starting point and then we need a little bit of help to push that along.

**Ellie Rofe | 37:44**
Yes.

**Speaker 2 | 37:49**
Interlocutors are great for that. Like you say, for a debate out in the world, AI can be great for capturing what's useful, you know, from all that.
Right? That's good. So. But the interlocutors help us expand the pile, the AI helps us, you know, refine it right to just it actually does a decent job of finding, helping us find the good bits. The and so like how can you be out there more in the world and talk about this?
So certainly the conversations that we have you should be using this fodder for that, of course, but this brings up like why not have I mean you have been doing some aews, right?

**Ellie Rofe | 38:20**
Hey.

**Speaker 2 | 38:27**
So another play for you is there like a podcast approach or something where you can be having regular recorded sessions?

**Ellie Rofe | 38:36**
Yeah. Well, that's where I think I do want to do that and maybe have almost mini-seasons but defined things. I'm trying to understand more about interview-specific people. Make a significant cohort of those people that I interview founders who've raised in the last twelve months, and we'll be looking to raise again soon. Just
have good conversations with them because what I have realized, which I never would have thought when I first started working in this stuff, is that actually the best. I actually sell really well in person. Marketing and stuff. Despite me understanding it and having a certain affinity for it for other people, I don't think it's my best approach when I'm talking with people. I ask them good questions, and I have AI that can build rapport relatively fast with people, and I think that really helps.
So the chance to interview people to get to talk to founders on another thing, ask for advice, potentially get money, is a really interesting way of doing it. Then have those, and I think have a twin thing.
So I'm not just doing isolated interviews but constantly researching and trying to understand the data, the ecosystem, and the landscape while talking with people in the same way I've been doing with this big politics research thing.
So it becomes like... I think that is probably the route. I'm not... I'm trying not to overcomplicate it too much, but I think having... I will talk with these people to try and understand more about the defense industry, robotics, money flows, where money is actually flowing from into hard tech, or these... A crystallizing question. What was it? Someone said the crystal you put into potassium permanganate or something? I can't remember the thing.
It was like the... Are very nerdy.

**Speaker 2 | 40:37**
That's a nerdy reference, to be sure. Yeah, all that sounds so good. My thinking is that your interview process so far has gotten stuck on the edits and on perfection. So the that that's a problem that needs to be solved.

**Ellie Rofe | 41:02**
Yeah.

**Speaker 2 | 41:03**
The problem here is not that there are problems with it. The problem is your desire for perfection. This is where live casting might be to your advantage because then you have something that's out there, and you can always go make a clip or something, but it's just out there having a more refined cut or whatever. The longer you delay it, the more people have an expectation that you're a really good editor, and you have an expectation that you need to be putting yourself out as a really good editor, and you've never edited before.
This is sort of circling around the "We're not just going to ship." You are making connections, you are asking good questions, and you're getting good answers.

**Ellie Rofe | 41:46**
Yeah. Yeahm.

**Speaker 2 | 41:53**
You know, the original livecast version might turn out to be a little bit boring.
That's fine. One, people will watch it, and second or not a lot and some people will, and second, it becomes the basis for, you know what? You can stack on top of it, you know, clipping, getting ideas, what have you like interlocutors expand the pile of ideas.
And the if you're doing that asynchronously through debates you're having on Twitter. Okay. If you're having that sometimes is not the most civilized way of doing it. And then you have, you know, your you know, the live stream where you're just sort of hosting a song on, you know, where people are able to, you know, have.
You know, have conversations which you either you're facilitating if there are more people having them or it's if it's you and some others you know, can decide how to go about that. I do a couple this week.
Right now.

**Ellie Rofe | 42:47**
Right. How are you finding them? Do people bring different types of issues, or do people open up on a live stream? That's probably my underlying question.

**Speaker 2 | 43:03**
The answer is largely yes, and maybe more than they should. And I think part of that is my skill as an interviewer. Yeah. I will, you know, ask questions that like. Are me being genuinely curious about the other person and not appearing to be at all tricksy hobbitses or anything.
And they will say and they will share more.

**Ellie Rofe | 43:24**
Yeah, okay.

**Speaker 2 | 43:25**
I think you too, like this and then... Because they did it once, they do it again, and they don't feel bad about it. What you're doing is providing them with the gift of someone who's listening.
Then, gain them to do what they should be doing anyway, which is sharing their ideas because their ideas are not that special, assuming their ideas aren't that special. When they're trapped in their heads.

**Ellie Rofe | 43:46**
Yeah, I think I was thinking about the interview I did with Alistta. I don't know. We're coming towards the end. So this might be a diversion, but it might be a derailment question on some level. Part of the reason it's been a struggle is because actually the most interesting stuff he can say, he said off-camera.
That's obviously going to be the nature of certain things. But the story of what he's trying to do, which is effectively reshore something of an entire supply chain because the supply chain in Britain has been so degraded, is fascinating.
But it's like, "Okay, I'm not a quantum physicist, so apologies. This is the wrong analogy, but it's the one that pops into my head. It's like the observed particle. If he talks about some of this stuff in public out loud, then it would undermine his ability to actually make it happen because suddenly the MOD and the civil service are up for it.
The resistant parts of those places that don't want defense capacity, that aren't... Don't want money being spent here, would kick into action. And that's kind of where I'm like, this is the sort of I guess the three body problem of it is like that it feels to me like, am I doing a disservice if I get Founders to open up about too much founders in particular on a live stream?

**Speaker 2 | 45:14**
Founders generally overrate the value of secrecy that their ideas. There's some people who are working on legit secret plans, and like, if people find out about them, you know, the whole thing is going to be ruined, right? That the general term for that is a conspiracy.
And, you know, I don't know for sure, but I don't think this guy Alister is actually running a conspiracy. You know, like the so and like particularly political people think this way, I think far more than they than maybe they should. One of the things that, like, you know, Donald Trump has shown is the virtue of sometimes saying the quiet parts out loud.

**Ellie Rofe | 46:06**
Yes, I get that he disrupted things by just going there partly because of the things he's saying aloud are the real thing though.

**Speaker 2 | 46:12**
Well, I don't propose that everybody be as crazy as the current president of the United States. But look, there's an element of they won't be genteel or whatever, but that's up to them, right?
I think from your point of view, you probably do a service when it's something they actually talk about to actually surface that they are talking about it. It is newsy. It is interesting.
It is how they find their fellow travelers. If what he's trying to do is trick the government in something, that's a whole different deal. If what he's trying to do is like, "This seems like a really good way for us to be doing business, and we should be doing this." Then, particularly in democracy, you want people to be talking about it.
If you can be elevating those ideas, bringing them out, then I think you will do better service.

**Ellie Rofe | 47:10**
Yes, I broadly agree. I this... Sort of slightly goes back to the thing I felt about the thinking and systems thing, which is there are oppositional or hostile actors in any system, and the British civil service is quite filled with them. In terms of people who want to maintain the status quo or maintain the current suppliers and the benefits, direct or indirect, they may get from that.
So there is a bit of a game to be played to not hand over everything to people who have the power to be a hostile actor and prevent you from doing stuff if they have forewarning. But I agree. I think
there is power in sharing things openly and building your cohort and building your peers and just talking about ideas and socializing ideas, I guess as well.

**Speaker 2 | 48:09**
Yes. And you know Donald Meadows, you know who was writing, you know in the 1970 s about ecology, right?

**Ellie Rofe | 48:16**
Yes.

**Speaker 2 | 48:17**
Where her appears to be people like Paul Ehrlich, who were proclaiming the doom of the world as a result of breaking down these delicate systems, which just turned out not to quite be the case.

**Ellie Rofe | 48:20**
Yeah. Yes.

**Speaker 2 | 48:29**
I mean, the. It's a little bit like, you know, Marx and his theory of like, capitalism will lead to revolution, will lead to self correction. It's not going to be perfect, it's not going to be pretty.
But like this the world keeps on spinning, you know, which actually, if you read her book kind of carefully, like she kind of she really points towards that towards the resilience of these systems right through the.
But that's sort of not the enough politics that she was involved in anyway. My thinking is that, like, if you think you shouldn't be sharing something, you know, don't share it. But the. I think in general, you do these people a service when you shed light on them, because when you're sharing a light, you give them the opportunity for people to say good things about it.

**Ellie Rofe | 49:10**
Y.

**Speaker 2 | 49:13**
And you know the people who he might be worried about. Like the secret civil service. Those are people so trad in secrets. You don't think they already know about them, do you? Think even one past him? No, it's like the people in power are usually the ones who benefit most from keeping things secret.
It's the people who are not in power who benefit from ideas spreading more widely because that creates a broader base of support to be able to overcome the entrenched interests.

**Ellie Rofe | 49:46**
Yeah.

**Speaker 2 | 49:46**
Now, I don't know all the details of this stuff, and there are exceptions to every rule, but I think that when you're considering the value you're bringing to these founders, right?
Or to these people who are trying to filmment change.
Getting them to talk more than they think they should is probably helping them be able to bring the innovation and disruption they want to bring to the market because frankly, the more secret they keep it, the less likely it is to actually make change.

**Ellie Rofe | 50:11**
Yeah. M yeah.

**Speaker 2 | 50:21**
So I think you talk about the stuff or any other interviews you do. I think you're doing a service by getting them to talk more. If they don't think they talk, I mean, you don't need to... They say, "I can't talk about that."
That's totally fine. Great. They've now said that's the thing they're not going to talk about, which gives you license to talk about...

**Ellie Rofe | 50:39**
Yes. Yeah. Okay.

**Speaker 2 | 50:42**
I actually find that to be a great gift as an interviewer. When the interviewee says, "Well, I can't really talk about that." Say, that's fine.

**Ellie Rofe | 50:51**
Hey, ye.

**Speaker 2 | 50:51**
Now, I've put a box around that, and I'm using it to get a license for other things and that they circumscribe with more boxes.
I'm now looking for the channel through the things I do want to talk about because then that's usually the key. The things they really want to talk about. That's the gift you give them is like they have these things they are these ideas they're excited talk about. You're there to listen to them.
And it can't simultaneously be that no one's listening to me and they're going to steal my ideas.

**Ellie Rofe | 51:19**
Yes, okay, that's very helpful. Context or an approach. Okay.

**Speaker 2 | 51:28**
But that's for the out talk to people, talk to yourself. Get and make use of Krisp to see what you've already been talking about. This will give you a set of ideas, like it's self-study, right?
Then from those ideas you have now, this embarrassment of riches from which you can pull making content. Because now you're no longer trying to figure out what to talk about, you're just figuring out how to express it in this micro-posting platform.
Thank goodness for this micro, because that way you can just get out there in a couple of hundred characters.

**Ellie Rofe | 52:00**
Yes, yeah, okay, fabulous. I'm off to sell the Krisp MC P.

**Speaker 2 | 52:07**
All right. Enjoy that. If anything I can do for you this weekend, just give me a buzz and we'll talk. You on Tuesday.

**Ellie Rofe | 52:12**
Okay, fabulous. Thanks, Ray.

**Speaker 2 | 52:14**
Bye.

