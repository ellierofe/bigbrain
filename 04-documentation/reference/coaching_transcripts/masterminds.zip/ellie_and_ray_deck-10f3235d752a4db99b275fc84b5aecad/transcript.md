# Ellie and Ray Deck - Sep, 09

# Transcript
**ray@statechange.ai | 00:14**
Hello, Ele. My deep apologies, maam, for being TED to our call.

**Ellie Rofe | 00:17**
No, don't worry at all, it's fine. How are you?

**ray@statechange.ai | 00:21**
Very well.

**Ellie Rofe | 00:21**
I very much appreciate you giving me some extra time on the calendar to discuss my waffle from Saturday night.

**ray@statechange.ai | 00:29**
Yeah, it's an interesting problem, though. Tell me a little more about it.

**Ellie Rofe | 00:33**
Yeah, sure. So, I got a call from my friend. Where is she based now? She's just moved to Georgia, but she was in a cab in Chicago with her brother. She's kind of manic in her own way.
She was like, "I really need to talk to you. I really needed to ask you because this group that she's been part of for a couple of years, maybe even before the pandemic, she joined. They started off with a $1500 membership.
I think then it's gradually increased, and now it's at $7500. They have some software called Obvio, which is about events planning specifically for these kinds of enrollment conversion events of the type that I think you probably understand, like the Tony Robbins get-together you put in a room for one. They preach one or three-day events. You get people loaded, people in a room. You give them some information, you give them a load of pitches, and then you get people to sign up for an end product.

**ray@statechange.ai | 01:37**
The back-of-the-room sale. Okay.

**Ellie Rofe | 01:39**
Yes, the back-of-the-room sale. Not my vibe, but I get why people might like it as a model. It works to an extent.
So, she's been doing that. She's actually a client I worked with on her brand strategy because she does something called "Breaking Bread," which is where she teaches. She's a mediation specialist who's worked with things like NLP and EMR and all this sort of stuff.
She teaches people to bake sourdough while reconciling teams that are going through problems or creating ways to improve teams on some level. So there are lots of different... We created loads of different recipes for her to do anyway. She would like this thing as part of it. They're now offering a digital twin software. He was asking me, "Is it worth $7,500?"
Because I've pretty much got everything else I can get out of this membership at this point. I said, "I really don't think that off-the-peg software.

**ray@statechange.ai | 02:48**
Now, when they say digital twin, I mean, like, do you know what they're using for that?

**Ellie Rofe | 02:52**
I suspect they've built something themselves because they built their own software.
That's a good question, actually. Sage, Leap, let's see... sleep.

**ray@statechange.ai | 03:12**
Yeah, because I looked up Leap. I couldn't find any reference to their digital twin stuff. Just so you know, there are other tools out there if she's in that coaching type community and she's looking for something that's going to be based on her. There are a number of tools out there that can do this that are a little more off-the-shelf.
One that's from Digital's from Dynamite Circle that I'm more familiar with. It's called Coachbox.

**Ellie Rofe | 03:36**
Yeah, I have seen it. You know, exactly.

**ray@statechange.ai | 03:38**
It's like... Hundred is not... Not $10,000 a year.

**Ellie Rofe | 03:45**
And said this to her. There was one I saw that I think they had Gary V. on it and people like that. I can't remember what the software was. I think I actually landed on it when I was looking for something else entirely. What's the name of the Oracle? Delphi?
Maybe it was Delphi, no. Anyway, I'll have a look. But yes. She said, "Should I spend that money or some of that money on you doing this for me instead?" Because she'd seen Google when I was building it, and she was like, "I get what you were doing with it."
You seemed to know it. I was saying, "Look, I think the thing is..." She's written books, self-published. I don't think they're going to be the most amazing thing, but she has written books. She's got quite a lot of content, right?
She's got lots of events that she's run, and she's got transcripts and stuff. I said to her, "You really have to look at the systems." As far as I have worked out when I've been playing with this stuff, it's not about just dumping loads of information into a backend and then letting it search it.
You have to think about the structure of what you're putting in and add some level of context and categorization to it.

**ray@statechange.ai | 05:00**
Two two.

**Ellie Rofe | 05:09**
It was healthy.

**ray@statechange.ai | 05:12**
No, I sorry, just you mentioned Delphi. So I just sort of stuck that he into the.

**Ellie Rofe | 05:14**
Yeah. Yeah, it was that. That was it. Yes, Brendan Burchard and all these people on that one, that was it.
So I was saying to Ed, that's the thing you need to look out for. You definitely don't need to spend $7,500, certainly not as a reup each year, and that's crazy money. So she was quite keen on a... She said, "I just want your coaching rate because I want to just talk to you about Brown's strategy in general and help with my next steps because I feel like I'm at sea."
You always have good advice for me. And I was like, I don't know. I don't have a coaching rate, so I don't know what your advice is on that. Then she was like, "I want to talk to you about this."
As I say, I was like, "Should I point her in Demetrius's way?" She is pure chaos, and I think Demetrius might want to throw his computer out the room after a little while because I think he likes people who are a little bit more on the ball than that.
But I thought that was one question, and then the other question is, "Is it the best thing for me to say, 'Yes, I'll help you stretch this myself, and potentially, like you said, work with Demetrius as a subcontractor?' Or is it best just to say, 'Look, go and try one of these software things out, like Delphi or the one you mentioned from your... What's the.

**ray@statechange.ai | 06:53**
Coach Fox or one of the others. Yeah, sure.

**Ellie Rofe | 06:54**
Which problems.

**ray@statechange.ai | 06:55**
The, there are multiple tools, and I think there's a lot of... Like you say, if she's pure chaos and you are the whisperer, then you can be a bridge between her chaos and getting the order that allows her to be manifesting whatever she wants to manifest. There's a lot of... What were you using? What are you looking for? What's the interesting part of this, right? A lot of the value here when we talk about coaching stuff isn't asking good questions and eliciting that value.

**Ellie Rofe | 07:20**
He [Laughter] got?

**ray@statechange.ai | 07:24**
You know, the old joke about the consultant who is hired to tell you the time and then asked to see your watch? I think it's perfectly fine. One, I think you should have an hourly rate that way people can buy it from you.

**Ellie Rofe | 07:43**
Yes.

**ray@statechange.ai | 07:46**
That hourly rate should not be cheap, right? The idea is that it's not like the primary way you do things.
So if they're going to be doing that, it's going to be to get attention. So, a classic way of doing consulting is to take your target annual income
and divide it by a thousand. Generally, expect that if you are doing consulting, you're most often not going to be billable more than 50% of the time. So, one of the ideas is to sell ship and say, "Hey, 20 hours a week you're shipping, right?
That's available time." Then, 20 for the sale, 20 for the study. I think we want to target less than that because the more you do that, the more valuable that time is.
I would probably say that for a coaching rate, you want to go a bit higher than that. I'd probably double it again because the thing about coaching rates is you're helping them out for an hour.
I really like the idea of short and sharp engagements. In general, I found that people are far more willing to pay your rate when it's like, "Hey, I'm going to get the best of Li for an hour, for two hours, I'm going to experience it on the call." As opposed to hiring freelancers who can do stuff for you.
It's hard to keep that kind of multiple because there's greater the haze and the lack of trust that goes with what's going on with that. This is one of the reasons why I try to encourage both Robert and Demetrius to do more stuff on the line. There's huge value in that.
Then, as they have their clients who they've been working with for longer, they find that first their clients are saying, "Hey, can you just solve this problem for me?"
Then, as they move more to a lazy mode instead of an educator mode, that's where they get more price pressure from the client.
I don't know why I'm paying you so much money. The answer is you're paying so much money for the live thing now you're not using that anymore.
The whole thing is going in a certain way. One of the reasons why subcontracting could work is if what Demetrius wants is to be able to go build, Right?

**Ellie Rofe | 09:53**
Yeah.

**ray@statechange.ai | 09:54**
And there being the gateway to helping the client. There's a lot to be said about that. You can be bringing Demetrius business without him having to spend anything.

**Ellie Rofe | 10:02**
F four one, yeah.

**ray@statechange.ai | 10:04**
There's a deal to be done there, and you being a bridge to your friend, not being responsible for the build, but you supervising it. "Hey, this has got to be a certain way."
Having somebody who you have, who you've gotten to know over the course of the last several months, has some trust in you. Then there's you and you two can do business, right?
It starts by asking questions, and I think those questions are merely useful. One of the reasons I record all the calls is it makes the call more billable because now, in addition to being the service provided, it's an asset that the client has access to.
You can sort and Krisp really helps with that too, because then you can be giving notes and whatever. It was cheaper for you to do it, and they're getting the maximum value out of that hour or two hours or whatever it is with you. What is your target income in 2025? 2026? What's your target Income?

**Ellie Rofe | 11:21**
I've thought a lot about this. I've thought a lot. I'm terrible at setting targets. This is a really good point.
So, I was thinking, right? If I can get things up and running, if I can get referrals, engines, and a bit more exposure to people, I look at one client a month at around $10,000, which
seems to me like there's a world in which it's much higher if I'm bringing in more clients each month. That's capacity to do that. I think at the moment, I would have capacity to hit three clients a month before it starts getting a bit fractious.
I need to really make sure I've got some systems and outsourcing in place. But at the moment, I need to get a client that's paying full price before I'm going, "I can get three a month."
So, I don't know how quickly it's going to change. Obviously, we're at the beginning of back-to-school season now, so I'm hoping that there's more energy happening and more movement happening.

**ray@statechange.ai | 12:34**
Yeah, well, the.

**Ellie Rofe | 12:35**
You know.

**ray@statechange.ai | 12:36**
The. I might propose that setting a target of $200,000 feels reasonable. $200,000 divided by $100 an hour if this were
a full-time job, which implies $200 for the base and then maybe above that. I think this is your friend. You're looking to make it easier for them to do it. I might just charge $250,
and I think you probably get away with that. Then you can say, "You might have a subcontractor you can do which should then be getting more work done at a lower rate, which you don't need to bring up or talk about until such time as you're in the conversation." Like this seems like the right thing to do. I don't... You're trying to serve your client the best, and so it's not about getting them a totally bespoke thing, right?
Demetrius is thinking about... But you might be using things like Delphi Plus, Demetrius is connecting your friend's stuff. Then part of your marketing expertise is eliciting from your friend, "What are their best ideas and what have you that become the top line framework?"
Because part of the idea behind these things is to give them just to be able to pull right from your various insights. But who are you at the beginning? This is something I'm largely doing for myself right now. Through the change, right?
I've got a crap ton of content to sift through, but I'm finding it's actually pretty important to figure out what the "so what" is of this. What's the Ray way of addressing the question before we start getting into the research, et cetera?
For this client, I will tell you, I have pitched Mitch Van Dusen on doing something like this, and he's now shifting around thinking more about being able to sell mental models or helping people really much more in the personal development space. There may be an interesting conversation for you to have there, too.
But the big thing is not so much the technical aspect. People who can do the technical aspect. The big thing is you being a bridge to that technical aspect, and I think that could be a very high value thing for you to do, and I think it's very compatible with the kinds of pitching you're doing on the biotech side, right?
Because your expertise is not specifically in biotech, right? It's about using marketing principles to connect complicated ideas with the market that's ready to receive them.
The coach to audience is a variant on this theme, just like a biotech VC to investors is a variant on that theme. And you can probably use the fact that you're working with your friend as part of your proof of excellence in this kind of translation to help biotech people, right? They may say, "Our stuff is completely different from anything else."
But you worked on other complicated things. You can build these bridges, and the approach you're taking is going to be probably helpful in this regard. You'll find that the same techniques are going to help you on both sides, and that there may well be cross-validation from a marketing point of view. It might be more that biotech helps you with the coaches than the coaches help you with biotech.

**Ellie Rofe | 15:54**
Yes, he.

**ray@statechange.ai | 15:58**
I don't know.
But I do think that these are parallel tracks, and it makes sense. There's a bit of when we're building a business, trying to figure out where the money is. Where are the people who have the pain and have the trust in you so they're willing to trust you to solve their pain?
This seems to be in that intersection. Which is why I thought this is something that's definitely worth investigating. You charge her too little, right? Because you're building it up.

**Ellie Rofe | 16:27**
Yeah, that sounds good.

**ray@statechange.ai | 16:27**
But I think if you say 02:50, you like can by ten hours.

**Ellie Rofe | 16:37**
I do. I mean, I have realized the thing I love most, and it's part of the reason I think sometimes I feel like I'm not the best fit in biotech, is because the thing that most people in biotech love most is the science.
The thing I love most is how ideas become connected with an audience, how they become businesses, and how it is better for everyone. But I think, as you said before, maybe that's why I do bring something different to biotech because I'm not interested. I'm not interested in the science. I don't just care about science. I'm not a scientist.
It's that idea. Whispering. It's about saying, "Right, these are all the things in your head, and this is how they become the business that you want them to be." I love that part of it. I actually had a lead magnet once called the Idea Olympics, where I was testing people's ideas. It was actually for a signature talk.
It was like, "Have you gone through the right training to get into the Olympic level thing?" You know, "Have you thought about this? What about this? What about this?" I loved it because there is such a huge gap between ideas. I struggle with it myself, which is probably aware. When people talk about trauma bonding with your audience, I'm like, "I struggle with expressing my ideas," which is why I love working with you because you help me clarify things.
But I love doing that for other people. So, I think this is definitely it. It is all in the same wheelhouse. It all feels... That's why brand strategy feels very similar to Pitchdex to me because it's just bringing ideas from here out into the world in a way that they can get into money and success.

**ray@statechange.ai | 18:25**
Yep, like, you know, like from Harry Potter penses, right, like pull the pull that pulled the ideas out.

**Ellie Rofe | 18:29**
Yes.

**ray@statechange.ai | 18:33**
Yeah. There's a lot to be said for that. I think it could be quite fun. I don't see it being particularly distracting. But like any of these things, making sure it doesn't go off the deep end. This is why I like doing time materials billing at the early side of it.
You know, because it's not like you're desperate to get as much money out of your friend as possible. Like you're going to make good counsel. Okay, here's some cheaper way to do it. You can be online.
Here are a couple of tools that seem to be reasonable. This one seems reasonable. Okay, but then there's the work of loading it up, right? All right, so I know somebody we can probably get for a few hours to be helping out with that. You okay if I share your details with them and then you go talk to Matrix, blah blahs.

**Ellie Rofe | 19:22**
Yeah, okay.

**ray@statechange.ai | 19:24**
Like should not feel compelled to be talking to Demetrius, but I think he's a good guy. I think he's going to be... On average, the rates will be on a trust-adjusted basis, be pretty favorable. He's obviously interested in space.

**Ellie Rofe | 19:40**
Yeah. No, I feel like I've often said that the thing that I look for in a subcontractor is trust more than anything. Because the last thing you want is to have done something, handed it off to someone else, and then find that you've got another ten hours of work to do to unravel things or whatever.
I feel like Demetrius is smart and determined, and I trust him to push stuff together. If that... I'm not saying that everything just turns out perfect straight off the bat, but I trust him in a way that gives me peace about handing stuff to him versus being like, "God, what on earth is going to happen from here?

**ray@statechange.ai | 20:20**
And is actually one of the reasons. There's one thing that I think is good about the mastermind thing that we've been doing, which is building that trust so that one could be learning from each other, but two potentially be able to do business
together. Regardless of whether you actually wind up doing business together, the hope I have is that you can now take on an engagement like this, right? And be able to provide value, have impact, be able to make a bit of money, because you're not afraid of it. My goodness.
But what if I had to actually take on the other half of this? How would I even go about this? It'll be expensive, and it would not be my wheelhouse. Well, you can combine these things.

**Ellie Rofe | 21:03**
Yeah, absolutely. Okay, that's very helpful. So $250 because I'm obviously often working in pounds. So we're looking at dollars and $200,000 as the target.

**ray@statechange.ai | 21:19**
Assuming it was... If you're talking about $200, your goal is like $120,000 pounds. Okay? A hundred and $20,000 pounds is like, roughly 17180?

**Ellie Rofe | 21:27**
One. I mean, I think the exchange is in the crap a bit. GBP one time.

**ray@statechange.ai | 21:35**
Both sides are in the crap right now.
I don't know what's going on. These two countries can't seem to manage a way of paperback.

**Ellie Rofe | 21:44**
Let's not even start in France. Where am I going to live? $163,000 Roughly.

**ray@statechange.ai | 21:50**
Okay, yeah, I actually think $200,000 a year is what would be my wish for you heading into that. That's the run I want to get you to. In fact, Really?

**Ellie Rofe | 21:58**
Y.

**ray@statechange.ai | 21:58**
The room. When? I want to get you to it's something more like $20,000 a month. You're that kind of talent.
We can talk about how some of these things scale or don't scale. The doing of the pitch deck, to your point, that's not the immediate problem. The immediate problem is just gain some points on the board. This is some points on the board, and it's good points, right? All is, you're not taking money from your friend. You're helping provide them value, and they're paying you to keep you serious about what they're doing.

**Ellie Rofe | 22:28**
Yeah.

**ray@statechange.ai | 22:29**
This is, I think, a great thing, being able to do business with your friends.
So I don't. I mean, sometimes I will do the. Yeah. How about I just sort of, you know, do this for free? But that's for people I don't want to take money from and help them.

**Ellie Rofe | 22:42**
Y.

**ray@statechange.ai | 22:43**
Don't take money from them, okay?
That's what I do. A family falls in that category, right? But non-blood relatives, yeah, sure, gladly do it because what you're giving them is preferential access, right? Rather than discounted access and the seriousness of your attention.

**Ellie Rofe | 22:59**
Yeah.

**ray@statechange.ai | 23:02**
And I think that's, you know, the there's a line from Madman where he's talking to, like, you know, Conny Hilton where he says, you know, this is my profession.

**Ellie Rofe | 23:13**
H yeah, okay.

**ray@statechange.ai | 23:14**
You to have fun conversations with you,
but now that we got to my professional... Let's have a meeting, and I appreciate this is not exactly like the domain, but it very much is a domain of your area of expertise. This is about marketing and the SPB being.

**Ellie Rofe | 23:31**
No.

**ray@statechange.ai | 23:32**
We'll pull out the best of them.
To the extent that I can be helpful with this and to help make this a more successful engagement, I'm glad to. Both in the context of usual coaching, but you can use the same link that I gave you to schedule up all your stuff. I would wish for this to be more successful.
Just if you will permit me. It just seems really interesting.

**Ellie Rofe | 23:53**
Yeah, definitely really interesting. I think I feel quite comfortable charging her because I've done brand strategy work with her quite extensively. At one point, on a preferential rate.
She's got a lot of value. She does love talking to me about stuff she's going to talk at length. So, that's fine. It's coaching on brand strategy first and foremost that she wants to understand her direction.
Within that, because I know a decent amount about the AIoS space and she doesn't, then I can help her understand what her options are in terms of this idea of a digital twin.

**ray@statechange.ai | 24:32**
Digital twin AI, how to put this stuff to work. Yeah, and you can both be provided direct advice and be able to connect with good people and be the gateway for that. There are a number of ways you can do this that all create value.

**Ellie Rofe | 24:44**
Yeah.

**ray@statechange.ai | 24:44**
I personally try not to subcontract stuff. I refer it instead.

**Ellie Rofe | 24:48**
K yeah.

**ray@statechange.ai | 24:50**
But depends on the trust relationship. So, the trust... No way, I really want you on this. Can you make this happen? That becomes a subcontractor relationship, right? It's really... But I bring that up just to say there are more than one way to skin the cat.

**Ellie Rofe | 25:08**
One.

**ray@statechange.ai | 25:08**
And should be feeling the license to be doing what you think is appropriate for them to be providing them with the best value.

**Ellie Rofe | 25:15**
Yeah. Yeah, okay. Perfect. Sounds good.

**ray@statechange.ai | 25:19**
Allright. And you awake can be helpful. Tea this morning or this afternoon.
By the way, where are you right now?

**Ellie Rofe | 25:24**
I'm back in the UK. This is my spare room.

**ray@statechange.ai | 25:26**
Okay, got it. All right, then, let me know if I can be of further assistance, and we'll talk later this afternoon. Investment.

**Ellie Rofe | 25:36**
Yes, perfect. Okay, ch thanks.

**ray@statechange.ai | 25:38**
Thank you. Bye, record.

