# Ellie and Ray Zoom - Oct, 03

# Transcript
**Ellie Rofe | 00:04**
Good morning.

**Ray | 00:06**
Good morning, Alie. How do you do today? It is a gorgeous sun rising up over the mountain. A kind of a golden sun on Canada. Like all the leaves are on the ground to change the color of the ground.

**Ellie Rofe | 00:21**
Nice. That sounds beautiful.

**Ray | 00:24**
It is and I could see more blue out through too, which means once again, winter's coming.

**Ellie Rofe | 00:27**
[Laughter] Your favorite time [Laughter] I take a Ph gain a friend.

**Ray | 00:33**
Yes, I appreciate it. Not for all, but it has been pretty good here, and it seems like you've had an okay week, too. I appreciate the...
Yeah, I was just saying I appreciate the report, and I was glad to hear that.

**Ellie Rofe | 00:41**
Sorry, I was talking over near what you say.

**Ray | 00:48**
You know? I mean, look, we all have the good ones and the bad ones, right? But it's nice to hear the... The upper trajectory.

**Ellie Rofe | 00:55**
Yeah, I think mentally, energetically, not energetically in a spiritual sense, literally energy-wise, there's just a radical shift. Enough. I mentioned it to a friend who has anxiety and has been really struggling, and she started taking a bit of Eltrasine and lion's mane.
I mean, it's not like radical stuff. She went out for a run, and she came back euphoric and was like, "What is going on?" She did some digging. It was like you probably just suddenly got dopamine available to your system properly again for the first time in a while.
So it's using it, and you just... It's a subtle but radical shift on some level, even in just terms of... Yesterday I did about a 15-hour day, probably, and I haven't been able to sustain focus like that for a long time. I used to do that.
And then on the bounce. Do more and stuff. And, you know, I was, like, very hard working, but I've been struggling to.

**Ray | 02:01**
Yes, you're not telling it anymore.

**Ellie Rofe | 02:03**
Yeah, exactly. I've been really struggling to sustain focus anyway, and I'm a bit tired today, but it was absolutely... It felt like how I used to be able to focus, sustain energy, and persist.
Yeah, that was good.

**Ray | 02:20**
I'm so happy for that. So, you're... I guess my... I appreciate the report, I appreciate the thoughts, and it does... How can we help? You have this coming week be even better.

**Ellie Rofe | 02:36**
I suppose I have focused more on Upwork. I'm wondering about other platforms in terms of money. I'm intrigued whether it's just a different quality or if I'm missing something I should be looking at.
When you say CodeMentor, I was doing tiny jobs. I feel like I've been searching and applying as far as I can with the fact that connects cost money, and I can't just randomly apply to everything, which is the point of them.
It feels like I'm either not able to find the niche that I am, or it just isn't there. Because when I think about the things I can do, I look at document design, I look at slides, I look at templates, I look obviously at pitch decks and investor staff, in case there are the things that people could use me for properly.
But I'm not excluding anything else. Graphic design is bust because people are just like that. It is a mess at the moment.

**Ray | 03:39**
Yeah. Don't care.

**Ellie Rofe | 03:46**
So I don't know whether I just need to see if I can just get by without a car for as long as possible and
just try and get work elsewhere or what... I honestly don't know how to. The platform seems like a catch-22 where if you're not already on them, there is now a flood of not just people from developing countries who can work for very little, but people who are just doing stuff with AI obviously or churning churn.

**Ray | 04:16**
Yes.

**Ellie Rofe | 04:26**
And I keep looking for even the $10 jobs, even if it would turn out at 50 cents an hour, you look at them and then it's like, "No." The $10 jobs that people are putting on there are like, "I want a pitch deck. I want someone to write it, design it, brand us, put together our business plan type of thing."
They're just absolutely outrageous. So I just don't know, it's really... The catch-22 with all of that is if there's no point, as far as I can tell, there's no point in doing things where people are delusional about what they can get for a certain amount of time or money, even if it's one dollar an hour. Some of these jobs would actually end up...
Because they're probably not going to give you a good rating anyway, because I have no concept of what they actually, realistically should be getting.

**Ray | 05:17**
YP so my strategy on Code Mentor was to look at jobs that have... There are some jobs that come in, right? And within an hour, they would have like 40 responses or right?

**Ellie Rofe | 05:35**
Yeah.

**Ray | 05:36**
And there were some really top-rated people who were applying to a lot of these things, and they would get a lot of the work. That's just how it goes. As a client, that's what I want. I want, "Hey, who's the best in the world for this?" I want to go get them and get them at a reasonable price, and they respond to me quickly.
That's awesome. But that's because there's a... You know that. So, what I did was I looked for the ones that weren't getting responses and the people who put something up and saw, "Hey, this isn't getting anything.

**Ellie Rofe | 05:56**
Yeah.

**Ray | 06:03**
And I came in usually with an idea, right? I say, "Hey, have you looked into X? Haven't looked in X. Would you be able to help me?" Then that would lead into things, right? But it's like the story of strategy just keeps on repeating, right? Hit them where they ain't.
Like you're saying, there are a bunch of people who have a very low cost of living who don't have your ethics, right? This is a problem with Code Mentor. Eventually, I got kicked off of a Code Mentor because somebody came to me and said, "Hey, look, I see that you're a really credible person. I'm getting scammed left and right on this platform. There's someone you can recommend, I recommend." Demetrius actually entered into Mont Beatrice's clients, and then Code Mentor said, "Hey, you just recommended somebody off our platform, that's not okay.

**Ellie Rofe | 06:50**
Yeah.

**Ray | 06:52**
He was concerned about fraud.
Then they kicked me off.

**Ellie Rofe | 06:53**
Yeah. Yeah.

**Ray | 06:56**
So the interest of the platform is to make those matches on the platform, right? So, for me, when I was doing Code Mentor, it was at its best for me when there were these holes, right? Those holes weren't easy for me to fill, right? They were like challenging things.
I had to go look up and learn a little bit to be a helpful person, but the person was so totally at sea that there was an opportunity to do it. That gave me a little more confidence in how I could...
You know, the kind of thing I now do is a change. Really bring in problems that I haven't seen before, but I'm able to use diagnostic processes for them. But first, is there a category of work that is under-served, right?
That's what I was looking forward to. I wasn't just going on the platform and going right into the middle. I was looking for the vulnerable FLA, that was the way that I was able to make more progress quickly, and what I found was there was plenty of vulnerable.

**Ellie Rofe | 07:45**
Yeah.

**Ray | 07:53**
FLA People would come in, they would have a JavaScript question. JavaScript questions are fine. 50 responses immediately.
Because everybody knows how to JavaScript. Because everybody went to a big boot camp. You discover most of them don't actually know how to do it. But whatever the claim is, you show something about, I don't know. C++ or something. People have, I don't know what that is.
Then they run away, and then that shows as zero responses for an hour, for two hours, for a day. I pop in and they're like, "My goodness, I'm so glad somebody could help me. I thought I asked where that is. Can we identify the context of Upwork or use it as a sandbox for the market to ask to identify the vulnerable planks that can be helping you narrow in on an offer because your point is..." Hey, somebody who just wants something for $10...
Okay, yeah, you're right. They don't really value the work. So, who? One values the work, and two, is not being served. They're not getting the 50 answers.

**Ellie Rofe | 08:50**
Yet, I mean, I have been searching a lot by people who've had zero to five responses, and I've searched on a number of different keywords. I can't work out. Maybe I'm not imagining it well enough. I can't work out what the keywords are to get something where... Because where you're talking is like getting someone unstuck. How do I do this on up?

**Ray | 09:17**
Well, that's what Codeup is, right? Yeah, I take your point.

**Ellie Rofe | 09:20**
Yeah. Artwork is like, "Can you do this for me?" It's not like, "Can you do this one slide for me for $10?" I wouldn't do it, obviously, that's fine. It's like, "Can you create a whole pitch deck for me for $10?"
That's the level we're at, so finding the ways in terms of how to search.

**Ray | 09:47**
Yeah, you want to show me for a second what you're looking at.

**Ellie Rofe | 09:52**
Hang on. Yeah.

**Ray | 09:54**
AB.

**Ellie Rofe | 09:54**
I was just thinking. I'll just go into it, and then you can tell me where I am. I have to log in,
but maybe it's just that this isn't the right platform and there are better places for me to be. I haven't.

**Ray | 10:20**
Well there and there are other platforms with platforms, you know, like there's Freelancer, there's Contra, there's.

**Ellie Rofe | 10:26**
Yeah, I looked at Upwork and there just wasn't much in the way of the stuff I do there because it was a bit more developer design type work, but I can definitely have a look.

**Ray | 10:39**
Well actually it but that could be all too well, there are a bunch of Graphic Designers on there too, but, yeah, I take your point.
And as opposed to like, you know, people who are. Well, I suppose I ask the question like what kind of work is that you want to do or that you imagine is, you know, sort of your.

**Ellie Rofe | 10:54**
And I mean, I don't say that slightly tongue-in-cheek. I have no particular.

**Ray | 11:06**
Which is actually a little bit of a problem, right?
The more you say, "I'm open to anything," the more you're competing with the people who are open to anything.

**Ellie Rofe | 11:13**
Yeah, but that's just to try and turn the key to get reviews in. I don't know what to
do. So if I get very specific and say, "I will only be helping people with InvestoRx," then there are ten things. Let's see, rather than waffling, who is on there today?

**Ray | 11:29**
Okay. Sure.

**Ellie Rofe | 11:32**
It's a fun little thing, right?
I've just searched for "pitch" and less than five proposals and I will look at the most recent.
Right? I don't know where that problem is. This has only been up for six hours, and they want a pitch for dollars.

**Ray | 12:08**
Theyre looking for someone from India.

**Ellie Rofe | 12:10**
They are? Yeah, there you go. That's what that was, acquiring businesses.
Okay, right, so this is obviously a large budget, less than five. They want someone from India.
One-page investment design. Sorry, go away.

**Ray | 12:47**
I don't know what investment design is [Laughter].

**Ellie Rofe | 12:51**
This speaks to my problem, which is when something is... They've just put in $5 to do this and there is no brief. It just suggests to me that this isn't necessarily...
The other thing I tend to look for is if they've hired people before, who they've hired, and they do occasionally hire people who might not be like it. It just seems to me like they hire just very low-price turnaround things.
But I can try to apply to that for $5. But this is again where it's a balancing act because that takes eight connections out of the thirty-seven I currently have. And I don't know, like, I don't know.

**Ray | 13:46**
The APN for a five-dollar thing. Somebody who is positioning themselves as... I clearly have money to spend because they spent a bunch of it. Like $10,000. Wherever the thing is, right or no, that's a different one.

**Ellie Rofe | 13:58**
What's that? Sorryor.

**Ray | 14:00**
Well, down here someone has how much they've spent.

**Ellie Rofe | 14:04**
Here. That's how much they spent.

**Ray | 14:07**
Yep, okay, yous yeah, okay, yeah, you're resuming.

**Ellie Rofe | 14:09**
One point.

**Ray | 14:12**
Yeah, I was just noticing that it was actually on the list as we were going through this. Which I suppose there's a little bit of how serious these people are could be an indication in that way.
But it just seems like you're... Yeah, it's all the same stuff. So, what's a... I guess I'm asking, is there a search for jobs? Is there just a feed you can look at recently posted jobs.

**Ellie Rofe | 14:50**
There is the reason I've been avoiding it and trying to use the filter is because so many of them have already got loads of responses.

**Ray | 14:59**
Which is actually kind of what I was trying to go for, is if we were to scroll down looking for things that have proposals that are less than five, whatever the best one did yesterday, right?
Maybe it's because it's totally stupid, right? There's no bid range, okay, so we don't even know where it's from.

**Ellie Rofe | 15:22**
No, that's it.

**Ray | 15:25**
They don't seem to have any particular concerns, they've never done this before. They have three open jobs, never hired anybody. Okay, and there there's it kind of goes both ways. I actually found, like, for example, on CM, most people were posting for the first time, right?

**Ellie Rofe | 15:40**
Yeah.

**Ray | 15:42**
I've never been on before that. Most people were asking one question and then they don't come back. People who have repeats tend to not put up a post. What they're doing is they're using the platform to engage with whoever they want to engage with.
Eventually, you're smart enough and you say, "Okay, well, if I'm not interested in gaining new business through this platform, I can just take this outside and not pay the rate anymore, okay?

**Ellie Rofe | 16:03**
Yeah.

**Ray | 16:07**
I mean, yeah. Do you talk to Deris about this at all?

**Ellie Rofe | 16:12**
I haven't yet, actually. I should try and talk with him.

**Ray | 16:16**
Okay, yeah, he just he actually waived me off for today's session because he was his he's got a family thing.

**Ellie Rofe | 16:22**
Al right, yeah.

**Ray | 16:23**
But maybe in the coming week you can compare it.
And he thinks upwork is awful. And this seems consistent with that. But I guess for both these things like I look at these things in the context of study like where is there like a you know, trying to use it to suss out where is there demand that is not by supply.

**Ellie Rofe | 16:48**
And no, what were you going to say?

**Ray | 16:48**
And so I think, yeah, I was going to say that by taking that approach, you know, you can start to sort of ask, you know, weirder questions in here. And instead of what kind of work do you want to do?
Like, what kind of work is there in the world? Right? And like, what seems to get loud responses? What doesn't seem to get lou responses?

**Ellie Rofe | 17:07**
Yeah, I mean, I guess one way of doing it would be to, let's just put space in there. Will it let me?
Right, so I put nothing in there. Then I guess one of the things you could look at is who's looking for an expert who's got less proposals,
projects with less than one month. I'm trying to think of other filters I could put on this, maybe that or that. I think that might be a more interesting filter because that's just people leaving a $10 fixed budget on things where they can't be asked to put a budget on it.

**Ray | 18:00**
Yeah, sure. I actually found that people who put stupid prices on things, I would be able to come in and say, "Here's my rate if you still want to do it that way."
The things that say $10, you can just say, "Hey, look, this is not a $10 job, it's a $50 job. Do I still want to do it.

**Ellie Rofe | 18:15**
Yeah, okay, we'll just try that for a minute now. Home done?

**Ray | 18:26**
Lots of technical stuff in here.

**Ellie Rofe | 18:29**
Yeah, I think there is.
If I was, I could probably do stuff like that, but... Excuse me.

**Ray | 19:07**
No. I take your point.

**Ellie Rofe | 19:11**
Just thinking what other... I wonder whether there's something like Keynote, which people don't use or search for probably. Nope, not so that.
Okay, take off that. Let's take off that.
This might be a woman who I got in touch with because I saw a job like this. Just as a brief sidebar, I saw a job like this. There's so much plagiarism in the online guru world. They're like, "Can you just create 90 slides from my screen recording for $20 and send it to me?

**Ray | 20:02**
Yeah.

**Ellie Rofe | 20:11**
And was like, "Well, who doesn't have their original slides from a screen recording? I'll just double-check with this woman because I could see who it was meant to be. Who've done it? I'll just make sure that someone isn't trying to rip off her work.
So I went and sent her a contact on her website, and I got a stream of abuse back about how I was really weird and shouldn't stalk people and what a Karen I was. I was amazed, like, "Okay, yeah, I was like, Homer going backwards through the hedge gift.

**Ray | 20:37**
That's lightly hilarious.

**Ellie Rofe | 20:43**
It's like, "Okay, so when was this from?" So last week, I don't know when things have been put on that long ago, whether I meant to do it or not. That's a question I've had. It looks like a very good, decent job. Fine, but it says an urgent timeline from last week, and it's a waste, it's money to apply to it. Does this mean they've hired someone for this job, right?
So that's not there anymore. That's just not been taken.

**Ray | 21:22**
It is odd the fact that they've hired this. Why didn't even show something.

**Ellie Rofe | 21:27**
I don't know. That's another problem I've been seeing. You look at something that's from last week that's urgent, and the job hasn't been taken down. I don't know why they do that.
Wow.
Yeah. It's a deadline. Two days ago, and they want people from elsewhere.

**Ray | 22:02**
Well, and part of the reason I want people are elsewhere is the belief that people are going to be cheaper, right?

**Ellie Rofe | 22:08**
Yes, except the locations are looking for Japan, and it's not necessarily that cheap within that, but.

**Ray | 22:17**
Yeah, although this to say Asia and Argentina, like, I really don't understand the connection here.

**Ellie Rofe | 22:24**
No, exactly, I don't understand that one.

**Ray | 22:27**
Yeah.

**Ellie Rofe | 22:27**
They just want of people from those places.

**Ray | 22:27**
Okay.
No, I take your point.

**Ellie Rofe | 22:36**
Three weeks ago. I'm not. I genuinely would like to solve the riddle.
Because it seems like it's slightly insane that you can't get work.

**Ray | 22:48**
Well, and I think there's a little bit of... What's the... Yeah, right. You're saying that you'd only... You were trying to leave things open because saying you only do X is too specific and there is not enough demand for it.

**Ellie Rofe | 23:02**
H.

**Ray | 23:03**
The one question I have is the more specific thing: how is it for supply?
Right? The second thing is you don't have to just do one specific thing. But I think when we cast the wide net, what we see is the entire spectrum. We're looking at the bell curve from the point of view. Its biggest hump, which is where there's lots of demand but lots of supply, and that puts you in an uncomfortable position, right? Really, where you want to go is where there's perhaps a bit less demand but where there's even less supply.

**Ellie Rofe | 23:31**
2M.

**Ray | 23:32**
And why picking multiple pointy things to see if these are flanks, right? To probe for weaknesses in the market. And there's a little bit of us being more clever about searching for that. What
about actually just asking the question? Right? What kinds of jobs are not getting filled on Upwork? Try to ask the AI that question for a minute. Specialized, scoped, and higher-trust projects get filled. Vague under budget, generic listings stall, which seems about right.

**Ellie Rofe | 24:14**
Yeah. Well, that is... Yeah.

**Ray | 24:18**
Okay, what categories of work rather than how to make a better posting? Yeah, it's not the question I'm trying to answer. Okay, high-skill niches and low-trust commodity gigs. So you don't want the low-trust commodity gig, but I do think you want the high-skill, more technical thing, I think a technical skill.
I think part of it is when you're feeling like, "No, I've got to go to Upwork." Perhaps it's coming from a place of less self-confidence, right? You are pitching things you think are the lowest common denominator as opposed to what do you think is much more like it? Give some examples here on the technical side, because I'm technical.
So I just learned from me, right? Because it's about data engineering.

**Ellie Rofe | 25:06**
4.

**Ray | 25:09**
What about, like, Lakehouse migrations, which is a funny way to put it? What about compliance and security? What about legacy stacks?
That's an interesting one. What about working with technology people haven't worked with in a while, right? Not the cool new stuff. Is there something you know more about that not that there's going to be as much supply, right? Not as much demand, but there'll be even less supply.
I think there's a running gag that Cobol, which is an old computer language, is now actually a way that people in their fifties and sixties make bank because there's nobody who wants to work on that tech.

**Ellie Rofe | 25:45**
They birds rise again. Yeah.

**Ray | 25:52**
And banks are... They are like banks and whatever that have installed systems in the 1960s and desperately don't want to have to replace them.

**Ellie Rofe | 26:00**
Yeah, Yeahm.

**Ray | 26:01**
So who can we get to work on this? And that's not going to be what cool kids want to work on, right?
So like that that's just an example, like, you know, strength against weakness thing, right? And like, where can we find that? So this idea of, like, niche technical seems about right, but like, the things that are more nichey could be useful.
Like if it's biotech plus marketing. I don't know how much of that shows up in Claude, but like, yeah, you're starting to see some of these niche-type skills, which are less to get you specifically to do something but more to say, like, how can we be putting some pointer sticks on thism?

**Ellie Rofe | 26:42**
Okay, I will keep playing with that and see what I can see. It has pushed me and other things have pushed me to pull together a portfolio, which always takes longer than I would wish it to take.
It's like pulling teeth. I think what I've realized is I have to create a bit of a modular portfolio. So create a series of interchangeable pages, case studies, examples.
So that if I'm sending it to a COMS IR biotech studio or whatever, then it's leading with stuff like the work with Margo or Oxy or a pilotech. If I'm sending it to a presentation agency, it's leading with the presentation design work. The irony is in the high end. The highest funded pitch decks are often the ugliest that I've done because they don't care about their brand, and biotech investors aren't worried too much about how pretty something is, so you end up putting something quite ugly together. Or they're so early that they haven't got a brand and they haven't got money to pay me to give them a brand.
So you end up in this sort of... Well, it makes sense and visually it tells a story, but it is ugly, and I can't put that in a portfolio. So you end up with that sort of... So I'm shifting stuff around depending on who I'm sending stuff to, but it has at least forced me to put together a portfolio and think about that, which I haven't done for ages and involved filtering through dozens of slide decks and design projects and all sorts of things and try and work it out a bit.
So that's good.

**Ray | 28:29**
And just to ask, what about the Upwork things? Are they opening you to more basic kind of work? Is there that kind of more basic work available to you through your network?

**Ellie Rofe | 28:42**
Well, that's a good question. I don't know. I've got a friend who just got hired, although I'm not sure exactly when he's starting. He's just got hired by a top-end business school in Switzerland. I can't remember the name now.
He's going to try and push stuff my way, but that's got a lead time on it. I could potentially ask... I've got a friend who works at Deloitte. I could ask if there's anything she can outsource to me. Not sure how much freedom she has to do that,
but I could try.

**Ray | 29:20**
The question of her ability isn't what drives your asking.

**Ellie Rofe | 29:23**
Yeah.

**Ray | 29:24**
We go, "Fine. People know that they have an opportunity to do something nice for you." you.

**Ellie Rofe | 29:29**
H yeah, [Laughter].

**Ray | 29:29**
You step back and say, "I'm not sure I can do this thing, but maybe I can do this thing." Sometimes people just respond to the questions. Trying to get off the desk, fine. Then they'll do that and then they move on.
You'll find that there are people who think well of you, who, if given the opportunity, will try to do something nice. Well, I don't know if I can push something into myself, but I just heard about this other person
who has this problem. You only find out by getting into the market. So, I think upwork is a way of getting into the market. Upwork is cool in that it gives you insight into how the market's behaving.
When I think about my time in CM, there was a little bit of... Okay. Getting the positive reinforcement loop, right, of the successful engagements, which were small and clear, like I initially told you, we'll just get on the call. We get it on the call right now.
One of the things is about the immediacy of it, right? Once you're actually engaged. I appreciate Upwork might not have that dynamic, so be it. But then the other thing was just being able to see how the market was shifting
and where that ongoing demand was. Just about the dogs that weren't barking. This led me down the road to probably doing more work where I discovered two big fields at the end that were of high interest, which were the crypto side and the low-code side, and both of them were pretty lucrative. Crypto was going the way it did through 2022, but low-code was dying in 2025.
So, all things have their day, right? But yeah, all of you by saying that the thing that you have opened the door for yourself on gives you permission to open to use that opening outside of just this one specific domain.
I think you'll find that when you are to cross, you might be able to bring more money in the door. When people and when you deliver for somebody, that creates reputation. That makes it easier to be gaining the next bigger stuff you can find. It starts the wheel.

**Ellie Rofe | 31:37**
Absolutely. I was thinking actually, and I don't know how you obviously have been at the head of this in tech at the moment, especially talking to people. One of the things from our call the other day I was thinking about as one of the most interesting questions at the moment is how to identify market fit in a really fast-moving market.
So you see people who set out their stall as an AI expert, for example, and they're trying to do stuff, and then Claude comes out with something or Anthropic or OpenAI comes out with something that basically wipes out what they were doing, these systems they were setting up or whatever they were doing.
You've got industries that are barreling into AI, not knowing what they're doing. Brrling back out again all over the place, losing people, bringing people in. The hiring rate drops, the hiring rate goes up, and it's obviously a high-flux environment.
That seems to me normally in high-flux environments, there are opportunities, and I think it's what do you... I mean, I know that you... But you currently have an audience, which makes a massive difference because you're literally tapped in.
So you can see the fluctuations happening in real time, I guess, as you see people shifting, as Ivan, for example, did going, "By the way, I'm just all in on Casor now, and I'm not doing any of the things I've been spending the last eighteen months doing."
That's a big signal, right? But, what would you say is your understanding of how to identify that market? I know you know when you feel it, but how to see those opportunities in the market that's doing this.

**Ray | 33:34**
Yeah. I mean, getting out and talking to people. I find there's just no substitute for that. I take a lot of meetings. I used to do Lunch Club, which I actually found really helpful for us to get into this habit and to gain a practice round.
So we talked about that maybe earlier on.

**Ellie Rofe | 33:51**
Lu Club. Sorry, I haven't heard. I don't think I have heard you talk about that.

**Ray | 33:54**
Okay. Lunchclub.com, which is a service that is now more on Autopilot but is still useful because they'll just match many. Q you know, with other people who want to have interesting and useful conversations.
I find that it tends to be serious, professional people, right? Because that's who you are. Then they schedule you up, you have an hour-long conversation, and then you can be in touch with it. Not most people. But for those people I've talked to, I had whatever 150 or so conversations using the GE Club.
Really, what it was giving me was practice talking to people who weren't in the context of providing immediate service. It actually really helps you practice selling. You know, working with people sometimes are idiots. I remember working with this one guy in the Lu Club who was totally blown up at me because he had, as his business idea, something awful, and he thought he was going to get a lunch club and have people say, "My goodness, can I buy this for me now?

**Ellie Rofe | 34:48**
Right. He was da the skippy bittch.

**Ray | 34:50**
The end, yes.
He was really enraged that we were able to get 50 minutes into the conversation and he had made a sale with me. It was clearly his first one, too. It was just... I was trying to be calm and about...
But I met extraordinary people in the course of it. I found it just to be useful. The other thing is just being out in the market. I have a group, a saved group of tabs, which are a bunch of communities, right?
I just checked the top of those communities, felt that heartbeat, right? What's going on at Cursor? What's going on at Windsor? What's going on at Love? What's going on at... Say, what's going on at Weeb? What's going on at Bravo, et cetera?
Then, what's my opportunity to get a little more deeply into those? The office hours were a big part of that for me. That would then lead to the model I was doing later on. Zoho's
office hours were something that really modeled state change on because I would basically take over Zoho's office hours. Like, within the first couple of ones I was in. Because they are nice people, but they're not really technical unless Montgomery was on the call.
They were basically idiots helping idiots and being able to serve.

**Ellie Rofe | 36:09**
I did that [Laughter] a couple of times when I went out to... I know... Officer... [Laughter].

**Ray | 36:14**
Yeah, one of the idiots. Cardik got really huffy with me over chats, saying I was demeaning to him, which was whatever. It wasn't the easiest conversation to have, but it was long lines of him saying, "Why would you ever need to know this piece of information in order to make this thing work?"
Dude, if you don't know the answer to that question, you're probably not the guy I'm talking to. He got very huffy and offended about that. I'd be trying to be generally nice, and being nice sort of helps a lot, but
okay, the answer to your question of how do you identify where these waves are is to be aware. That requires time spent in the market. The more time you spend shipping, the less time you can spend doing that, which is why I talk about study sales.
Yeah, right. The time you're spending in the market, the time you're spending on LinkedIn or whatever, you're hearing people talk. I think that when I talk about sales, it is as much about listening to the market as it is about speaking to it.
Study is really about listening and gaining information, not immediately about those market refluxes. Then the skill that you need in order to be able to work in a fast-moving market is change management, right? Being able to identify how to change yourself and be changing the client.
Okay, hey, this is working. No, now this is not working. You know, once again, to bring up our friends over at Zano. They have taken the whole year to shift their stuff by 20%. They are well over 18 months into building this Xanoscript thing that they've been doing that they're hitching their whole star to.

**Ellie Rofe | 37:53**
Yeah.

**Ray | 37:54**
And it's slow, and they are not tied to the market. You can clearly tell as you talk to more of them. Their culture is internal, not external. This is true for a lot way.

**Ellie Rofe | 38:04**
Yeah.

**Ray | 38:06**
And your ability to help is going to be being the person coming in from the outside saying, "Hey, sure, it's chaos out here, and I get you, and I get this chaos, and I'm the bridge to the real value on the side."
That itself is, of course, a trust-based sale, right? Definitely Kalty, but that's how you find the fit. It's seeing where the fluctuations are, right? Building trust with the clients who are on the other side of it, who are looking out and saying, "What is going on out there?"
Then the service you can provide is connecting them to what is valuable at that moment where that fit is because that fit might change next week. So, an engagement, right? That's going to be, "Hey, we're going to do a six-month engagement with ChatGPT as your company."
Then, ChatGPT becomes irrelevant within six months because there's this other API stuff, assistance, rag, and all this stuff. Okay, now what are we doing? Become, and that's awesome for consultants because it just means it's time for the next thing, right?
But the product-market fit is not just the product market, right?

**Ellie Rofe | 39:19**
Yes.

**Ray | 39:20**
It's it's the product market moment, and that requires you to be aware of things at different points in time.
Then, "Hey, in this moment, this product or this offer and this market are meeting. You know, I often talk about meeting the market moment. When I talk about... We go out to do these things, and I think a market moment, as recently as two years ago, would have been something in the last six months, and now it feels like we're really lucky. For the last six weeks, I joked to another head of strategy that it's a new market every Monday.

**Ellie Rofe | 40:00**
Yeah.

**Ray | 40:01**
But why change management itself becomes a skill, right? Being able to help those bridges and being able to have the work you do be able to execute and create value in a relatively short period of time because then you're helping them get on the clock of the market.

**Ellie Rofe | 40:16**
He. Interesting.

**Ray | 40:26**
You you ever read Clock Speed by Charlie Fine?

**Ellie Rofe | 40:28**
No Clock speed.

**Ray | 40:31**
Yeah, Charlie Fine is a professor at MIT Sloan. At least he was the time. He really likes Claire Christians. You can tell how it's heavily based on Christians's work.
A big part of it is how the speed of a market changes its structure. So, what slows down, you start to see more consolidation, right? Because the way the market is slowing down, we're going to operational efficiencies become a bigger part of the way you're going to create a difference between customer value and your costs. Whereas, when the market is moving really fast, it's going to be through reactivity.
That's going to be the small players we're able to keep on recombining themselves in these different supply networks that are going to create more value. Me, a helpful company, understood.
Work with that is really useful, particularly if it's a company that has previously worked in a more stable supply network. And like that, what does that look like? This is one of the reasons why I think your Claude projects are a really interesting offer and direction of offer because you're like, "Hey, here's how we can bridge Claude into your marketing."
Part of it is because you created the projects themselves can be useful. I think you being able to teach people and being able to bring out... "Hey, this is the kind of thing that will elevate you.

**Ellie Rofe | 42:01**
Yes.

**Ray | 42:02**
Can be a really interesting thing as well. I don't know if that's the thing you can lead with, because usually you have to lead with where their pain is. They are that they're really looking for...
It's only when they get to know... I trust you that there's this room for the thing that you know can be the bigger impact for them, and that they have a propensity to believe that because you are here with that.

**Ellie Rofe | 42:26**
Yeah. I mean, I love doing that stuff. It's just the point of pain leading into all that stuff is generally... I don't know who my market is, I don't know who my audience is, I don't know what my offer is.
So they aren't earning money, which is the slight thing I've... It's so difficult. I love that market. I love working with people, helping them understand, helping them discover answers and bring it all together with strategic thinking rather than just wishful thinking about stuff.

**Ray | 42:59**
Sure, there's no $10,000 gig to be done with that, but if you're trying to break through, I mean, I do think there are multi-hundred-dollar-a-month gigs we've done with that.

**Ellie Rofe | 43:03**
No, but breakthrough to what is the question? I'm not sure what that breaks through to with people who don't have anything.

**Ray | 43:17**
Well, one, they have the ability to pay that price point if they don't have the other price point. And the thing is, what do they have today and what will they be tomorrow?
Like, if you're thinking about what value does this create in the market, one is it gives you some cash, right? They're like, "Hey, yeah, I can't pay you $10,000."
Yeah, fair enough. They can't pay you $10,000. Could they pay you $100 or $200 to be in a course, right? That is about this. Do you have an audience that could be working with that? That's where you put yourself from state change people, right? Is there a way to make, to turn your relationships in state change into a couple hundred dollars of people doing that kind of thing, right?
And probably do create outrageously high levels of value. Because they like you and whatever, it turns them into references, right? That becomes a sales asset for you. What else? I'm trying to think about here, the other thing about most entrepreneurs is that they fail.
But what do they do after they fail? See, they're in addition to being people who fail, being entrepreneurs, they are usually pretty high-powered people in the rest of their careers, so they fail into being the kind of influential people that will be really useful to you in your career as well.
That's not cash today, right? I'm not trying to confuse the issue because I appreciate that there's cash flow today, but if what we're trying to ask is, "Okay, where's the next thousand dollars going to come from?" It seems easy, and I don't know, easy. It might be too strong, but there might be an easier way to take some of these entrepreneur types who you know and like to be saying, "All right, well, let's do 99 each. We're going to work through this thing. You're going to get access to this content, and you're going to be able to make this kind of marketing progress
in the course of 48 hours.

**Ellie Rofe | 45:13**
It's an interesting point in that given the way of economies and things shifting. One of the projects I was pulling together for my portfolio was helping a guy develop his sales deck and branding for a new business because he'd been made redundant. He went out and got $50,000 worth of work in the first six months with that deck, which is not what most people do.
I dare say he wouldn't have done it had he not had the deck he originally had. I'm not suggesting that it's Pitchdeck, but like you say, is there a low-ticket offer where it's corporate levers, basically people who are either being made redundant or whatever? Where to reach them is a good question, I guess, but, yeah, people who are setting out into business from corporate.
So, they do have money because they've normally got redundancy packages, and they might not know how to market themselves, but they're smart and they're high achievers and that kind of thing.

**Ray | 46:30**
Right, solo consulting. Mark, you know, Mark yourself as a solo consultant or win the deal in the room as a solo consultant. These are definitely potential things to do.
If you say people lose their jobs, they have initially money they need to spend. If you could make it... I would start by just making it a ridiculously good deal.
Yeah, because then, hey, you do the first one, they're like a hundred dollars each, and they all get snapped up or whatever. Maybe the first one doesn't get snapped up that much, and the second one gets more snapped up because there's now some reputation to it. Now you've got more demand than you've got supply. Great. Now you're increasing your rates to sort of equalize that and figuring out how you can be increasing the value of the offer to move it up.
I appreciate that's yet another drain on your resources and energy. But entrepreneurs are fun to work with, which makes it, I think, a little bit less draining, right? Than you know. Talking to XYZ scammers.

**Ellie Rofe | 47:40**
Yeah. Yeah, there was a point yesterday when I was working with Anid late last night, and we were... She really made me laugh. She was talking about delivering assays as a service and how she had to work out how many she could deliver based on how many scientists she had in the company to be realistic about the growth.
I was like, "Absolutely, that's really important, just so I've incorporated those." I said, in her seed round next, not this pre-seed round. I said, "Have you incorporated anyone else in there?"
She was like, "What do you mean?" I said, "Anyone else in the business other than you and three scientists as you're growing into this thing that needs to be selling into, like, twenty different pharma things?"
She was like, "No, I hadn't thought of that. I just thought of scientists." It really made me laugh. It was like, "You might need some other people to help you, by the way, because you're a CEO, you're not going to be spending time in the lab, and you're going to have a lot of stuff going on."
But they are fun to work with in that way. As I was looking at it, I felt excitement for her. I was like, "I think she's very accomplished. She's got a lot to learn, but she's very accomplished. She's very determined and really does care." I said, "You're looking to exit one of these points, are you?"
She went, "If I was smart, I would be, but I'd love to see this all the way through if I can." That was okay. It's fun, it's exciting to work with people like that. It does give me a sense of joy.
I'm wondering whether there's just an AA consultation session, a strategy sounding board session where I say we work with AI over a course of an hour or 90 minutes to do business design to make sure that you know who you're talking to and what you're bringing to the market in the first instance.
It's just a sounding board session. I have offered strategy sounding boards before. I did them for free just to test it, but maybe I can test it with corporate levers and just see what people think or don't.

**Ray | 49:49**
Yeah. I mean, I'm wondering, is there an angle here? You have the design aspect, which is them filling out this survey and form. There's a let's make a presentation. You're showing them how to use Gamma again.
Again, the whole... Sure, you could get some big design, but how can we help you make more progress and be able to get better design out of it? You're not totally happy, we can of course fiddle with it, right?
But always big questions like, "What's the story?"
This allows you to cross over with it. Now, what you have is basically part of your course requirement. Now, before the next thing, you need to go get yourself Gamma, right?
Then they do it for one month. I can get it for one month, whatever. You have that be part of the cost of your course, or you could talk to Gamma about getting coupons that you can give to people for their first month or something, which could be really great because that could potentially give you a relationship with a vendor that lets you do a bit or here.
All it's in the same... I mean, there are three things we've talked about here that I want to make sure we don't lose sight of them just because it's the most recent thing we talked about.
So, one is trying to look for your stuff inside of work, which will both give opportunities inside of work as well as give ideas for what other market opportunities you could do, right?
So, using Upwork as a model of the market. Second, is talking to people who you already know about what kind of work they need in terms of giving yourself permission to be doing lower-level stuff.
Then third is, this is a little bit more going back to the entrepreneur idea where you have some reputation where you have credibility where you have things like, say, change where you can put to work or you know, I think. Have you seen No-Code Pro-Code as being like a guest talk over there? It might not be terrible either. He's got a bunch of people who are all entrepreneur types who are trying to build their apps. They're not consultant types. They're building out their whatever, and they're going to be concerned about things like, how do you do? How do you sell better? They might even have good skills. They just don't know how to sell.

**Ellie Rofe | 52:17**
Yeah.

**Ray | 52:19**
And the question I have is can you put together an offer that is something insanely easy to buy, like a $99 offer, right where you're going to get five people per session in a room?
The reason, by the way, is that five is really for your own ability to manage it. Later you can get better Halo. Then you're doing the kind of thing you did a couple of times in SA change.
I mean, just the experience of that was really cool. Okay, what did they need to have? You need to have Claude and you need to have Gamma, and if you don't already have those, you can get them.
Here are the subscription links, right? But you're going to need these in order to be able to use the tools that we're going to put together here. At the end, you'll have a slide presentation, and at the end you'll have a story, and you'll have access to the project that you can use to be able to have further conversations with it as you see fit for as long as you decide to keep these subscriptions open.

**Ellie Rofe | 53:26**
Okay, I'm going to have a look. Claude has just introduced the possibility of making slides, which I suspect might be better than Gamma.

**Ray | 53:34**
That'd be awesome if you can. If you can do that and you become like the Claude Slide person, that could be great, and not for nothing,
that's actually pretty good content marketing if you're looking to make slides.

**Ellie Rofe | 53:43**
Yeah, yes, yeah, I have thought about.

**Ray | 53:46**
Look, I'm a designer, and I will always want to be doing more of this stuff by hand. I appreciate it. Not everybody does, and I think this stuff can do some pretty good things when you're a
let's talk about Gamma. Gamma becomes one. You can have Claude Slide or whatever, right?

**Ellie Rofe | 54:04**
I did. I started writing something out when I did a test with Manus first, but it is something I should be doing more of, which is what AI is doing with slides because most of it's not very good, but there are some functional parts to it, and trying to be dispassionate rather than obnoxious about it is important.

**Ray | 54:24**
And think you being a professional saying this part isn't so good and this part is better is useful stuff and puts you in a... When I think about that kind of thing as a content marketing aspect for you, like video or whatever, I think that could be really quite attractive to the market.
I've always found that production values are not the most important thing. It's having an interesting idea. This actually brings us back to YouTube as a search
are people searching for and looking for or not finding, and what is not out there? Is there a whole lot of stuff about how to make better gammas? Is there not a lot of credible stuff? Can you be bringing more to that?

**Ellie Rofe | 55:08**
Yeah.

**Ray | 55:09**
And I'm sorry. Just to close the loop on that, we just went from Upwork through your network through entrepreneurs through YouTube. Let me bring it back to Upwork for a second. Is there a pitch for "Hey, you're looking for these slides? I'm a Gamma expert, right?"
So instead of getting them all done by this, put them into Gamma. If you currently have Gamma, I can set this up, share it with you, and then you'll have it. You can modify it to your heart's content after that.

**Ellie Rofe | 55:41**
Is Gamma growing?

**Ray | 55:44**
Unclear to me, and you can plot or whatever.

**Ellie Rofe | 55:47**
Interesting. Yeah, I'll have a look.

**Ray | 55:51**
You you see where I'm going with this, right? If you are upfront with... I have this expertise and I use a tool that gives the same leverage.

**Ellie Rofe | 55:59**
Yes. Yeah, absolutely.

**Ray | 56:05**
And you might be able to afford to be able to take on these engagements. I want twenty slides or whatever. Okay, I would be using this tool, in fact. Or we can do a session where I can show you how to use this tool and then that way you could be owning it going forward.

**Ellie Rofe | 56:24**
I know we haven't got much time, but do you not feel like the issue isn't the "how-to", the issue is the underlying thinking?
That is the problem. And that's a far more sticky problem to try and solve, but sometimes.

**Ray | 56:36**
For it to be...
Yes. But the "how" people confuse those issues because they don't know about them, right? So if what you offer is the "how-to",
it becomes clear that it's about thinking. It's like, "Okay, now we've done the "how-to" part. I think there's probably a good session to be had about the thinking, and this is my right that's your... I mean, that's a classic product for prospects.

**Ellie Rofe | 57:00**
1M.

**Ray | 57:00**
You know, he's you know, trip it's a trip wire offer, right? You start by selling what they want at a price point that they can afford to buy it, and then you switch. Just means hopefully they can still afford to buy.
But like, you know, but that you sort of started the relationship where.

**Ellie Rofe | 57:22**
M.

**Ray | 57:23**
Okay, I have to run. I'm very glad to discuss this more over email, what have you. I think you're hot seat this week, so it's something you want to bring up.
Yeah, I'm so glad you're doing better. I think there's lots of opportunities opening up in here. You know that we're starting to discover with this upward stuff. I think if we just look at it expansively.

**Ellie Rofe | 57:48**
Yeah, absolutely. I felt like that's happening. That shift has happened in my brain of trying to look at things more expansively.

**Ray | 57:54**
Super and cool.

**Ellie Rofe | 57:55**
Probably fabulous, Ray.

**Ray | 57:57**
I'll play there by bye.

