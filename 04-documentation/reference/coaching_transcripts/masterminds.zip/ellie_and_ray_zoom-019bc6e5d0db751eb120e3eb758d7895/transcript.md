# Ellie and Ray Zoom - Jan, 16

# Transcript
**Ray | 00:02**
Hey, I am...

**Ellie Rofe | 00:03**
Hello, how are you?

**Ray | 00:06**
Well, today it is Friday, which means I actually get to do work tomorrow, right?

**Ellie Rofe | 00:07**
Good Friday [Laughter] exactly.

**Ray | 00:18**
That tomorrow my sons are going to a robotics competition, and that means I actually do get to work for the full day tomorrow.

**Ellie Rofe | 00:25**
That's very exciting what they do. What's the competition? Are they entering or watching?

**Ray | 00:31**
They're entering. They're. This is a. We homeschool, but they do some after school activities.

**Ellie Rofe | 00:37**
He.

**Ray | 00:37**
Right? And we got them in violin. They're doing a chess club, and they're been doing this robotics club or robotics team. And they will they've made it to states, which I think is like, you know, top half.
It's a little bit of a filter. And they'll get to, you know, meet other kids who are interested in this and, like, you know, get to compete and see how their whole thing does. I'm. And you know, the this get to make that kind of progress.
So I'm excited for them this sort of it's more it's where they get to do more middle school level stuff. So socially, it's very nice for them, right? They're meeting kids their own age. Some of the are things they do. They are sort of out of band.
And another thing we've discovered is that some a lot of stuff is sort of designed for KIDS up to maybe age 13.

**Ellie Rofe | 01:27**
Got you.

**Ray | 01:28**
Now they're getting into the top end of the age bracket. I liked it a lot more when they were at the bottom end of the age bracket.
So how can I find new things so they can be reaching?

**Ellie Rofe | 01:38**
Yeah, that sounds so good. And is there like a Robot Wars vibe to it, or is it like, what can the things you've created do?

**Ray | 01:48**
I think that there's a, it's not so much Battlebots as it is, you know, there are specific tasks that they're supposed to do, right? And like, how many of them do they do and what time? And I think that's the nature of it.
I think the boys would be more excited about it if it were, in fact, robot combat.

**Ellie Rofe | 02:07**
[Laughter] Yeah, well, it's like it's the difference between like what?

**Ray | 02:10**
Because I'm as...

**Ellie Rofe | 02:14**
I used to have a horse, so I'm like, that's like Robot Jim Carner. They can do, [Laughter] like, loads of tests and, you know, playful tricks, but not, like, jousting, which would be slightly more [Laughter] aggressive. [Laughter] I love it.

**Ray | 02:28**
They're not doing jousting, they're not doing Death Match, they are doing but yeah, and it's good they've learned a lot about robotics and they get to do. My boys, apparently, are sort of at the leading edge of the people who know I do some computer programming.
And that's, you know, the it's a useful experience for them because like a lot of the other things we do, like in the homeschool context, tends to be the most advanced academic work they're doing.
So they have something that's pushing them. But this has the social dynamics of being around kids and teachers who don't or not invested in the way that their parents are invested in them is useful.
You know, it's like, let's, you know, give. Give them more of that variety of experiences so that they can be, you know, building up the right. Calles.

**Ellie Rofe | 03:17**
Love it. And if there's any really useful like programs or directions in that. Robotics is an area that I'm going to be looking into, and I have no pride in starting with, like, you know, elementary stuff and working up the routing branch kind of learning model.

**Ray | 03:32**
Yeah, sure. You know, I think I mentioned did I mentioned last time, you know, Brian Halligan and what he's trying to do with, you know, bringing more hard tech stuff into Boston.

**Ellie Rofe | 03:48**
Yes. Yeah.

**Ray | 03:49**
Okay, well, then that's my immediate business idea. Then, based on what the boys see in terms of sponsors, what have you all...? I can definitely give feedback on that back to you.

**Ellie Rofe | 03:59**
Yeah, fabulous. And yeah, no, it's clearly very exciting as an area at the moment and it's I can see it growing.

**Ray | 04:09**
Yeah, well, I'll yeah, and I think we're going to see more manufacturing in the particularly in the United States.

**Ellie Rofe | 04:11**
But...

**Ray | 04:20**
I don't know quite how it can be working in Europe, but in the US I'm expecting to be at see a bigger focus, particularly on automation technology because of the decision to like basically increase the cost of labor by getting rid of immigrants. Which, okay, but like that but that is that's that that's a knock on effect, right? Is that we're there will be more demand for robotics and automation, which previously the capital investment couldn't be justified because you know, you'd be competing relatively cheap labor.
Well, now between tariffs, which is overseas cheap labor and immigration crackdowns, which makes you know, labor locally much more expensive, you know, it's making your everybody's life worse. But it will have that effect of people who invest in Robos or will see better return on investment.

**Ellie Rofe | 05:06**
Yeah, it is really interesting to me. This is. This is something I see completely both sides of. In that I have an inherent sort of openness to globalization and, you know, intramural sports days and stuff.
But I'm quite a pragmatist in terms of like there are clearly lots of war sabers rattling. So it would be really good to have supply chains resored. So like, how did the West maybe overegg the... Let's bring in cheap labor and outsourced manufacturing? Yes, to a degree. Is there going to be a massive over-crection? Yes.
Robotics is definitely... When I was doing research on LLaMA, it's happening in Europe as well. It's just not happening to the same degree because the energy prices here are so stratospheric that it's harder to reshore on any level.
That certainly is the case in the UK. There's going to be a huge tussle over whether they continue down the road of massively subsidized renewables and high energy prices or retrenchment to a transitional phase with oil, coal, and gas and just building out a ton of nuclear.
But the reassuring is happening. What manufacturing exists already like BMW, and we're one of the first to partner and get cobots in to start building their cars or finishing off certain bits of the car.
So yeah, there's definitely a huge shift. There'll be an interesting question around how much that brings value to life in an economy, as to how much it actually brings jobs and whether those jobs are trainable for people who are unskilled or not and things like that.
But it will be fascinating. There will be lots and lots of work in terms of maintenance and refitting factories and... I'm sure compliance and regulatory adherence and all that kind of thing as things go on.
But yeah. It's a really interesting area.

**Ray | 07:20**
And not for nothing. What you were just talking about might go back over the Krisp, but these are all excellent topics for you to be writing about or speaking about because they are about you looking at... Hey, what are the knock-on effects of heart tech areas, right?
Why is more heart tech happening? Why is this a bigger deal now than it was before? Well, it has a lot to do with nationalization or non-nationalization.

**Ellie Rofe | 07:47**
Yeah.

**Ray | 07:48**
Non-nationalization, hopefully. The although there is more naturalization going on in the US where, like, you know, companies are handing over stock to the government.

**Ellie Rofe | 07:56**
A rin.

**Ray | 07:57**
Yeah. So it's. It's a passive form of naturalization, right? It's not a not what you know what the you know Fritz did with rails or whatever, but like the anyway, but certainly the idea like hey, if you can depend less on trade.
All right, then how do you get the things you want those changes to more capital intensity, the changes to whatever. And like you, being thoughtful about this may get you cited. But like it positions you, I think, more as a person who is thoughtful about the subject as opposed to a person who just happens to be a good Designer.
And that's a. That's a higher end position for you to be, as you discovered with Matty.

**Ellie Rofe | 08:33**
Yeah. I mean, I did a post on basically how geopolitics is the specter at the table of every hard tech pitch deck because you can't pretend it's not there. It is, and you want to address it.
But it really didn't... I mean, it got no impressions. So I think that we mentioned briefly on Tuesday whether that might be strangled. So I'm going to play around with it as part of my content approach because I think it's higher value and it's interesting, but it is possibly just completely strangled by LinkedIn because they're a bit more... We want to keep it light.

**Ray | 09:15**
Well, right. So I think that you... What you can do is replace... You might just think of geopolitics as the specter that dared not speak its name.

**Ellie Rofe | 09:26**
Yeah.

**Ray | 09:27**
So, what else are we saying? We're talking about onsoring, right? We're talking about automation, right? We're talking about a resurgence in manufacturing right now. Now we sort of you're basically talking about the same about aspects of the same thing.

**Ellie Rofe | 09:42**
Four.

**Ray | 09:42**
Yeah, without using the big word. But the big word becomes the thing you use in the meeting that thing you're using in the content that might be able to get you unlocked. Because I think it's a good subject to be getting into, right?

**Ellie Rofe | 09:55**
Yeah.

**Ray | 09:56**
Like what are the societal consequences? What are the inputs and the outputs of this hard tech bit? And then you become. You know.

**Ellie Rofe | 10:05**
Yes, that's the goal over time. I am, yeah, I am thinking about ways to potentially start writing beyond LinkedIn. And this is a sort of midterm rather than an immediate term thing.
Well, researched, what Michael Simmons calls blockbuster articles, but something that is researched over the course of a month. But what comes out of it? Or research and written over the course of a month.
But what comes out of it is actually really impactful and important. Rather than churn. And I'm thinking about what is the most high value types of things to research. Like, one of the things I was discussing, there's a guy called Mark Montgomery who seems a little bit of like a potential outsider. Odd fish in the VC AI world. Fine.
But he engaged with the post ride. Said heart attack is hard because of the risk, the length, the amount of capital, et cetera. And he's like, this is stuff that VCS don't really even understand. And he was talking about how the big funds.
So obviously a 16. Ed. And, Lucks a 15 billion fund and only 1.7 of it was for software. And Luxe was a 1.5 billion funds still in their same investment thesis, which is frontier tech and how so many of the VCS are locked into LP's ten year like you know parameters.
So can't do that kind of pivot. But everything is not everything, but lots of the real upside is still flowing into hard tech because software's being slightly cannibalized by AI there's obviously a massive geopolitical shift.
When that happens, that brings huge opportunity. But it is in atoms generally. So obviously, defense is going bananas because of everything that's going on. Biotech is harmed because of Trump talking about drug prices, for example.
Panic over what? Because every pitch deck. The US used to be the first market because they knew they could charge like a wounded bull. It would be different in the UK.

**Ray | 12:29**
I hadn't heard that one before. That is a really good pun on charge. I love that.

**Ellie Rofe | 12:36**
Yeah. The Old Essex comes out now and then and brings something useful with it. [Laughter] But, yeah, it was, it is, a fascinating time. So I was thinking maybe one of those pieces, one of them I think that would be interesting is how you bring what is the process of reshoring stuff? How do you actually bring value to an area? How do you make an area attractive for it and what does it do to the local supply chain? The wider supply chain? What does that mean for hard tech investment? Whatever.
That's a bit sprawling, but one of them was how much money is actually moving into hard tech versus hype.

**Ray | 13:16**
He's such a great place to be.

**Ellie Rofe | 13:22**
Trying to discern which LPS are actually trying to push money because obviously it's not always advertised who is or isn't, but trying to work out who is pushing that stuff, pushing into that direction, what the shift, what the trends are within the verticals and how that kind of thing.

**Ray | 13:44**
Atli, have you considered making calls to the LP?

**Ellie Rofe | 13:48**
I haven't considered making calls to the LPS, but I try.

**Ray | 13:53**
I mean, what you were just saying, like just sort of made it seemed like the logical next step is like v VCS care. VCS are middle people, right?
But well, these VCS are interested in this. Now, the fact that a 16-year-old raised that money is an indication that their LPS care about those subjects, right?

**Ellie Rofe | 14:08**
M.

**Ray | 14:13**
The LPS are the source of money, not the VCS.
So if you're able to go and see a step behind that, you will make you attractive to everybody who's downstream the LPS in the supply chain. I know we talk about going to meetings with VCS, what have you...
VCS are so busy there... Whatever. You go talk to an LP...

**Ellie Rofe | 15:04**
Yeah.
H yeah, I do. I do think just about in time to make advantage of the shift because whenever I look at stuff, the vast majority of it is so f even obviously an awful lot of them will shift and move with the markets anyway.
But even podcasts, blogs like Influencers and stuff, they're so Saar brained when they're talking about fundraising and startups and money that there is a gap where people don't talk about this stuff. Whenever anyone talks about traction, they talk about ARR, but they're not talking about clinical results or, you know, tier one manufacturers or, you know, whatever else it might be that shows traction in different places.
And so I think there is a real scope here to sort of set out my to stake my claim on a certain patch of ground that not many other people are trying to.

**Ray | 16:35**
Tech of bio of you know robotics, more heavier manufacturing material science. Then I think about how AI can infect them and allow people to be able to move faster. How does that change the way capital intensity works?
But you still have the capital intensity because you're still working with atoms, not just bits.

**Ellie Rofe | 16:54**
Yeah.

**Ray | 16:56**
I remember, like, working with us in crypto. Like, what people wanted was they wanted to have a coin they could go sell and make a lot of money on.
Okay, but how does this create value? What's the next step after that? Actually, I don't know if I've told you this, but I took a run in 2022. I think actually trying to do something real in the world of crypto, actually around intellectual property protection in the world of crypto by basically having contracts, etc. that could be verified and then tradable to handle intellectual property rights in crypto.

**Ellie Rofe | 17:21**
Fiox?

**Ray | 17:30**
And, you know, there's just no appetite for it.

**Ellie Rofe | 17:32**
No. Because it's too serious.

**Ray | 17:33**
So the question was, where's the coin they wanted? They wanted a little fraudulent coin that people could go buy and then they could run away with because it was all about...
And that was going to be the fundraising mechanism. But there was no... Who would want to buy this? They didn't much care, right? They cared who would actually be able to raise from it. The more connected you were to... They could call them RW as real world assets.
It's like it's a retronym thing, right? But the idea... Go off once you actually start touching the world. We don't want anything to do with that. Even though it was only intellectual property, things were outside crypto.

**Ellie Rofe | 18:12**
Yeah.

**Ray | 18:13**
It's like, "Wait, now it actually touches ground, right?" But they have that nice wheel going of just amens or bare yet just like speculation. All I was saying, I know that's very attractive, right? To finance people like the whole super that was like super bits.
Then I talk about super bits and the trick is you can't just live in bits because that market is getting walled off. And now how do you get this into the world of atoms? And you know, there's now more money to be made because of X and Y and Z and now you've got good insights about that.
I think you're in a wonderful position for it. It's going to be a lot of studying to get from here to. So that you can be that expert. But, you know, you speak with great, you know, confidence and credibility.
And you're very smart. And I think that you're. You're in a great position to do this.

**Ellie Rofe | 19:09**
I feel like the... So in terms of goal setting in the next 90 days, I have a tangible goal, which is to get four to six clients to have gone through the process. Which means I am pushing one single thing over and over again on LinkedIn, and I've just been trying to set up.
I've done a lot of get-up posts like empty thing, empty screen post, go for it. But I haven't... But that's now that's running out of steam. I need to actually just create a system I can work through to do something more systematically.
I realized beautifully that actually the system I need to do completely mirrors the system I do with the PITCHDEX, which is what am I actually trying to achieve with this? What is the strategy behind it? How do I create something of value? I gather all those pieces into one place, and then I craft it into a narrative, and then I polish it off with something visual, and it's like, "Okay, this is the process I need to go through."
It's simple. I can work out the questions I need to ask myself. I can keep experimenting with them because I've got a framework that helps me generate stuff, so that's useful. But aside from... I'll have to do some cold outreach within that as well just to try and connect with people and hopefully get in front of founders raising a series A rather than a seed.
But in addition. And Maddy. Now he has one investment. It is a follow-on, but it's one investment so far already, so hopefully, she can get the rest, and it's all coming through. I'm going to follow up with her today.
If that comes through, that's fabulous because that's like a really nice case study.

**Ray | 20:53**
Victory.

**Ellie Rofe | 20:58**
The wider thing I'm talking about with these blockbusters is why I've been flirting with the politics side of things as well because it's a party that's really serious about policy. They're sadly not that serious about positioning, I don't think, but they are serious about policy.
There was an opportunity potentially to relate these two things because, as you always say, politics, money, and power. Sorry, knowledge, money, and power. Right? So if I'm dealing with the knowledge part of it and the power part of it, and then I'm trying to work with UBS and get in on the finance part of the money and work with VCS for the money.
Anyway, I'm rambling there, but my goal is my study. I worked out some study stuff the other day. So like Pomp.

**Ray | 21:52**
You alluded a little bit to the positioning on the just before the loss plot on that I was looking at thinking what you need is donor direction.

**Ellie Rofe | 22:01**
Yes, so that's...

**Ray | 22:03**
So if you should do this no fund it, then that's that. That's the play, I think.
Otherwise, they just don't have money.

**Ellie Rofe | 22:10**
Yeah, so I did suggest just before this call to my insider there, the head of comms who is not a head of comms blessing, he's very good, but he's got no experience with it. He was... He helps one of the candidates campaign and then just got gradually moved into the party because he's really... He's very smart and very hungry.
I said to him, "Look, if money is the problem, then you need me to help you get money. Like, let's not worry about the brand positioning and stuff. First, let's just work out how you can create a credible narrative for people to start giving you money, not just like membership, but money.
And so I've proposed that to them we shall see, because you're right, they just need money. It's ridiculous that they're. I think they're slightly. Confidentially, I think they are slightly. I think they don't actually really want to get into the dirty world of politics, by which I mean actually speaking with the electorate, I think they quite like, although they are sort of anti elite.
I think they quite like the idea of being elite. So it's like, you know, the usual. We shall see.

**Ray | 23:33**
Maybe they really won't be a think tank. I don't know. Think tanks are a thing in the UK.

**Ellie Rofe | 23:36**
I think they would probably be better as a think tank. Yes, and I think one of them has been involved in think tanks, and it's very much that sort of vibe.
I think they would love to just churn out white paper after white paper and green paper and all sorts. AI made up. It hallucinated. A book I really want to read. [Laughter] It was something like Hard Roads into Hard Tech or something.

**Ray | 23:57**
Okay.

**Ellie Rofe | 24:05**
It was like some academic... It completely made up from MIT talking about how tech was going to reshape the world. I was like, "That sounds amazing." But there's loads of stuff like venture capital and the finance of innovation. The hard thing about hard things, which is more just generally startup stuff.

**Ray | 24:28**
That's do about that, yeah, the butter.

**Ellie Rofe | 24:30**
Yeah, the where am I? The power law, venture capital in the making of the new future, superforecasting thinking in bets. Lots of things that are maybe showing up. Some of the stuff that I'm a bit hazy on around theory and fundamentals and all that kind of thing, but I think more interestingly will be just getting out there and trying to understand the landscape in my own way or bring something new to it in terms of what money is flowing into this. I do wonder if I get a couple of these down. Carter publishes an awful lot of stuff.
And the guy keeps caveating it by going, but by the way, hard tech is different. Hard tech is different. And so I'm wondering whether I say to them, can you give me the data and then just let me, like, produce something that's specific?

**Ray | 25:30**
Yeah, well, and it suffers a bit from hard tech isn't a sector, right?

**Ellie Rofe | 25:36**
No.

**Ray | 25:37**
It's sort of a way of describing a number of sectors, right? What? Robotics, materials, bioenergy.

**Ellie Rofe | 25:44**
Yeah, a lot of energy.

**Ray | 25:45**
It probably falls in that category, right?

**Ellie Rofe | 25:47**
Obviously there's energy consumption apps, which is a different thing, but energy production. You know, innovation and hardware and.
And usage.

**Ray | 25:56**
Production, transmission, storage.

**Ellie Rofe | 25:58**
Yeah.

**Ray | 25:59**
I suppose all energy is only transmitted and stored because we can't create energy. That's not how physics works. What?
Like you mentioned, defense space goes with that too, right? Like SpaceX type things because those two things are really badly...

**Ellie Rofe | 26:10**
Use space, aerospace, logistics. Some of it depends. Some of the supply chain stuff is more... But it feeds more into automation and robotics. There is the deep tech side of stuff and quantum and machine learning and stuff, which is less... It crosses over a bit more, to be honest, and it's less something that I... It's more baffling to me most things I've seen around.

**Ray | 26:39**
Right, it's just paying for preferential access to labs, right? The those pets are much more speculative, right? The thing about hard tech, as I've understood it, and you can tell me if I'm thinking about this wrong, is basic. I would describe hard tech as bits and atoms with a greater ratio of atoms than bits.
So, yeah, well, building semiconductor manufacturing facilities was sort of a fall in this category, right? Building a fab is a multi-hundred million dollar effort. Great deal of precision that goes into it. Quite capital-intensive.
If you make the right time tips, it will mint money.

**Ellie Rofe | 27:14**
Yeah, and that's an interesting one because in my head, it incorporates an aspect of R&D rather than more construction real estate.
But I mean, start construction real estate really isn't a bad place to be. One of the guys at the SDP who's now doing a defense or trying to do a defense startup has been in construction for years, has done some very high-profile projects.
That's like a 200 million raise. They're pretty high. They don't get the same attraction or interest as some of the other stuff, but there's a lot of money floating about in it, so it's not a terrible place to be.

**Ray | 27:57**
Well, it has the advantage, from a financial point of view, of being about the acquisition of physical assets. So as opposed to investing $10 million in software, right? Invest $100 million.

**Ellie Rofe | 28:17**
Yeah. Yeah.

**Ray | 28:23**
Tech that doesn't exist in the... Which is probably something that's worth talking about. What's the difference? Concrete. How much concrete's involved?
Because it's like people who know construction actually have an advantage. Because you combine the person who knows how to build with the person who knows deep science. Now you've got something that is able to bring it into the world.
The cool thing about software, as you get the person who understands the science, they can express themselves directly in software.

**Ellie Rofe | 28:46**
Yeah.

**Ray | 28:51**
That's sort of the promise of it. That's the reason why it's so attractive
and gets good multiples but it can't use capital the same way.

**Ellie Rofe | 28:58**
M.

**Ray | 28:59**
Trying to put 100 artworks. It's very hard to do it with a software company the way you do it. Software companies serve light money on fire in their sales process, right? To hope that you're going to be able to grab a bunch of land. It works differently in these other tech companies.
As long as lighting fire and sales process is a better way to spend money, it has a competitive disadvantage but we're seeing now that competitive disadvantage is reducing partially because markets are contracting.
All of a sudden that super low friction thing that software companies depended on has some more friction to it and that's clogging up the works.

**Ellie Rofe | 29:32**
Yeah, and cannibalization and all sorts of...

**Ray | 29:36**
They got a free show.

**Ellie Rofe | 29:41**
Yeah, I think because there's so little moat now, as you've talked about with the idea that if you can build something, then why can't someone else? Now, because it's like KING obviously there's a simple simplicity to that, which isn't... Which belies the fact that there's more work to be done under the VIB coding hood, but people are suddenly going, "It takes you ten years to build this incredible innovation and no one else can magically retro-engineer it."
So you've got maybe even if they can start working at what you've done, you've still got three to five years ahead of them to start taking advantage and cementing your place in the market. That's where the moats are.
So now we're really excited by the moat, which is what lots of people are talking about again, and it's just... Yeah. There are still very speculative things. The risk profile really comes from whether the R&D comes off normally.
Once you're past that earlier stage, generally, it returns to the same questions of "Can you outdo, can you beat competition, and how are you going to do it?"

**Ray | 30:49**
Yep. Yeah. And the thing I like about getting at just a bit outside of bio is that it means you get a wider and woolier set of, you know, constraints. Right? Like you start saying, well, how about instead of being a pharma company, we make dinosaurs?
You know, that would be, you know, that's a heart tech. And that's a whole different application, but in different set of concerns. What have you. And like, you know this the fact that it's getting wi wider and weird weirder is that's great for you, right?
Because you're a person who can talk about XY and Z and like you're on the investor relations side and you're sort of looking at it as hard tech because you're talking to these because that's where the BCS are, that's how they look at the world.
So you're at the right level specialization, which is associated with demand, right? And then they can bring you in as a bridge between their supply and that demand.

**Ellie Rofe | 31:42**
Yeah.

**Ray | 31:44**
It's a lot of study that really becomes the key to that in order to be that kind of credible resource. Which gets to your point about like, you know, research and sort of the, you know, we talk about like the study fits best in here, you know, sort of since probably a little bit under indexed on that, you know, this week and last week too, right?
And like the how we can ramp that up so that we can be building out that practice.

**Ellie Rofe | 32:06**
Yes, absolutely. That's why I want to get the cell on rails as much as possible because there's just been too much friction there, and it's taking my attention away from where there's really much more interesting value in the cell. Friction in terms of actually producing content and getting out there.
So yeah, I think that's a positive direction. Are there any other...? When I think about Blockbuster stuff, I've got a really interesting idea. Should I be trying to push that not just on my website, not just on LinkedIn as an article or whatever, but should I just be trying to pitch that to other people's audiences, VC blogs, or even magazine-style things or publications that are looking for this kind of content? Or is it just too early and it's just going to be too much of a distraction?

**Ray | 33:10**
I think you got to have something to say before you're offering them the thing you'd be saying like the ohwise. You have to be offering them a promise of what you're going to say. And that would be based on your, you know, prayer credibility, you know?
So I think if you're if you have those relationships, I mean, go for it, you know, but the. But what I'm hearing is like it's a little speculative in terms of what it's going to produce. So go be in a position where you have something to say. In fact, be yet be the person who's been saying it. Be gaining traction.
Because what you want, the way this is really going to work is, wait, people are really connecting to this. And then you go to the BC say, hey, people are really connecting to this. And you probably want your people to hear about too.
And now the thing, one of the things VCS really like is they like to seem smart, especially to their LPS, right? So one of the, you know, criteria, right. For you. One of their investments is going to be would we want to trot them out right on LPD and like, people who look good for that are going to probably win over.
It's one of the reasons why they, you know, look for, you know, good looking, you know, clean cut Stanford kids, right? And because when they have those, they can put them in front of there these rich LPS.
And the Richlp said, yeah, sure, these look like, you know, real, you know, founder type people. The way I imagine the founder type people, to be sure, perpetuates racism, but that's... But that's part of what they're looking for is to look smart.
So if you're helping them with that... But it requires you to have that momentum, I think, for you to build that. It's a multiplier, right? It's a one to ten thing, not a zero to one thing.
So that's a zero to one thing. The other thing I think would be great for you. I feel like I've given this advice a few times in the course of this week is, in addition to being a fine writer, you're a fine speaker about these things. I would love to have you just interview folks and have it on YouTube.
I think those conversations would then put you in a position to be able to gather secrets. Some of the best secrets might be the ones that are just... You're putting out in public anyway, but no one's seeing them yet.
Now you can turn them into better insights. You get to find out what people are actually clicking to, right? Then you can be double-clicking more into that. That tells you how your blockbuster stuff should work.
Because you don't really know at the beginning of the blockbuster what's going to matter.

**Ellie Rofe | 35:26**
Yeah, that's... I have wondered about interviews. In fact, after our last call, I thought, "Why am I not interviewing founders who've recently raised?"
Then I thought... So many people are doing it. Is it just more noise? Actually trying to interview LPS would be really interesting if they're willing to do it. Maybe even wider stuff like if I'm...
I think what I keep coming back to is that there genuinely is a reason that whenever you read Luxe Capital LP letters, the letters that he sends, which are very verbose and overblown, and he publishes them because he loves his own voice. I get it, but they are suffused with policy, not like politics is one thing.
Yes, there are macro movements, but the impact of policy. So maybe there is a world where I try and work out who has expertise on policy and how it might affect this as well. Try and keep moving into those things.
I think it's... I'll try not to make it the everything-in-one-world project, but be realistic about who I can talk to that actually has something interesting and unique to say, and then hopefully be able to bring founders to me who have something and are thinking along those lines. I don't know.
That's a bit rambly.

**Ray | 36:57**
Well, yeah, I mean, I think if you just go talk to smart people who won't talk to you. I think the fact that I like the fact you are have now this connection maybe through st. P the for these you know, bunch of people who think about policy right? Could you talk to them like, hey, policy for manufacturing technology, policy for bio. They might have different people.
I mean, this becomes like a gift to them, right? Because you're making them look smart. You're putting it up on your site, you to sort of promote them, give it them the right to go promote it, because all it does is promote you. They're probably going to be incompetent, not doing anything with it.
But like this gets you going, right? If you're saying there's a policy angle, great. Be the person who's talking about policy. You think there's a manufacturing angle? What about talking to, like, people who are more boring, like people who are involved in manufacturing? What about people who are involved in, you know, your university connections, right?
And the just, you know, get them to see who you can get to talk to. Because. You mean you are, you know, a charming and energizing conversationalist, right? You can be. I think they would have a good experience for it. The first people to do it are going to be people who already have some degree of trust in you.
But then you can say, "Hey, I had a conversation with these three other people. I'm doing this seriously, I'm doing this every week, talk to people." Then I just put it up and let it share, and then you can turn to clips and whatever else.
But it's a nice thing that allows you to study and sell at the same time because it builds up your reputation at the same time that it's creating content. Now, instead of you staring at a page trying to make this thing right, or maybe you have a page full of stuff you're trying to tweak to make it right, which I'm familiar with. Both those situations, you're just having a conversation. You're elevating them to be smart.
Then because it's on your territory, it makes you look smart. Then you're able to use that to someone else and then just cycle up. Anyway, I think that as a... When we think about what your content strategy is, right?

**Ellie Rofe | 38:54**
Yes.

**Ray | 38:58**
There's a bit of sort of feel like it's sort of a, you know, a mill of this LinkedIn stuff.
Well, what you need is to have ideas to offer into the market, right?

**Ellie Rofe | 39:06**
M.

**Ray | 39:07**
And you have ideas you're putting those ideas in some of them getting squelched like the geopolitics thing. But the how would it be easier, right for you to get, you know, a greater density of ideas into the market there than producing you know that for you like say it put on rails.
And I'm not sure there's that much automation you can do, but there is a how can you make it? Just a super easy and pleasant 30-60 minutes. You got it.

**Ellie Rofe | 39:32**
Yeah, absolutely. I think the beauty of that is... I will be interested in all of that. There is no angle of it that I would just go, "Well, there may be some really completely arcane thing," but most of it is fascinating.
I've just thought beyond interviews. I think maybe one of the things because I am a bit puppish about the innovation that people are doing and the way it changes things. There is that...
I think part of the reason I am quite excited about the shift into hard tech, into atoms, let's say, is because it has been a bit stagnant for a while, and I think part of the reason everyone keeps going... Why aren't I living in Star Trek? Why haven't I got a floating hoverboard?
Back to the Future. I know those things are... But part of it is because nobody's been putting money into innovation and invention in that way. I'm not saying that people are going to be desperately trying to find a floating hoverboard, but I do think that there are people who are starting to push again at the boundaries of what's possible.
There have been all along. But money is starting to flow into the boundaries of what's possible. So I think there might be something where, with a giddy tone, I can talk about the most exciting, weird, and wonderful things that have been funded in the last month and tag the CEO and start being like an optimist, not quite a futurist, but an optimist.

**Ray | 41:08**
Yeah, I love that because then when you tag other people, they tend to respond to be happy with it.

**Ellie Rofe | 41:16**
Be connecting with energy and volume. Not just analysis as well. Just literally tagging people and glazing them.

**Ray | 41:33**
I love the fact that I love the imaginary book. I think the imaginary book could be a great title for a videocast series, right? The hard road to hear tech.

**Ellie Rofe | 41:48**
[Laughter] Excuse me.

**Ray | 41:52**
I can totally see that being compelling, you know, like the it's compelling and authentic. And then. You know. Like you say, you're connecting with these people.
And the fact that you're connecting with these people then makes it easier for you to say, and by the way, I have a vidcast and just sort of talking to people who are smart about this and you know, get your get respective and talk to policy people DA you know, would you be up for thirty months?
And the. And like, I, if it turns out to be more than it's worth, I totally get that, but, I've been thinking about this thing, like, it's just sort of it's way under index. I was just talking with Toby Oliver about this for like the chat CHPT app stuff like, you know, realizing he just needs to go interview everybody who's managed GP app.
That's his best possible marketing for what he's looking to do. And the thing is, there are not that many, right?

**Ellie Rofe | 42:43**
Nine.

**Ray | 42:44**
With hear tech, like it's a relatively limited set. So once you start cracking into it's not like you're my goodness, right?
But there are like, you know, 500 million software founders, and like, you know, who's going to care about these people, the hard tech ones? Actually, there's it's a more limited set. Wait, you're you talk to Bob.
And now your credibility when you go talk to Phil, who knows Bob is going to be that you would talk to Bob, you know, eat not necessarily doing this business for him, but like if we're going to be doing free services for people, that seems like doing it in public and getting this kind of thing seems like a higher return on investment.

**Ellie Rofe | 43:18**
Yeah, and it is just... You don't have to look very far to see people who've really cemented a reputation just from talking to other people. Like the joy Rogan has almost nothing.
I mean, I don't actually dislike the man. I think some of the moral panic over the fact that this MMA obsessive DMT obsessive is going to somehow completely revolutionize the political world is overblown.
But he has the same angle on everything he does, which is "Have you ever tried DMT? Would you like to...?" I don't. Do you like MMA? Let's talk about this. He actually is almost invisible in a lot of those conversations on some level, but he just kept talking to people. He wasn't actually... I was thinking about it the other day. He wasn't wildly opinionated on stuff. In fact, his whole vibe is that he is so cross-spectrum in his stuff that he once supported Bernie Sanders and now supports Trump. He's a bizarre sort of slightly conspiracy-minded non-like in his terms.
But he just kept getting people on. The more people he got on, the more other people wanted to go on there and talk to him. I'm not saying that I want to become E. Rogan. To my God, no, but it is...
It is incredibly powerful what can happen. There is just... It's so mutually beneficial for people to just keep trying to raise their profile that there's a reason that model has completely taken off.

**Ray | 45:05**
Yes, because he is he yeah, right, because he's a being a compelling interviewer is worthwhile, and I can see you being a compelling interviewer. You know, I've actually been very surprised at how well, Demetrius did right at being an interviewer.
Like particularly hit had that, you know, sort of external salon of a bunch of, you know, people who are clearly because I know Demetrius clearly more expert than he was in these domains. He was just elevating. It was doing great.
But right now, the thing I'm trying to get him to do is just do more meetups. Because I'm pretty sure that's the point. In front of his, you know, the rest of his pipe. That's like clogged up. What I think about you the content part, I think.
I think your idea of Blockbuster is a good idea, but I don't think you need to be holding back from the market to do it. I think instead the ambition should be you want to be at the end of a month to be contributing something great to the market.
So how do you do that? You don't do that by going back into your corner. You do that by engaging more people and having more tee and secrets, right? And that's going to come from having more conversations with folks. How do you get more conversations with folks? We can definitely one way to get them in private is to have them in public. The. I kind of wonder how much value is there for you in like the fifteen minutes right before you go live or go on the air or whatever where you're sort of talking about this sudden like and you're just like, scribbling down or crisping it or whatever, and then you have public conversation.

**Ellie Rofe | 46:32**
No.

**Ray | 46:39**
But then you had the benefit of that additional 15 minutes.

**Ellie Rofe | 46:42**
Yeah. It's amazing how often you listen to podcasts and they say, "We were talking about this just before we came on." And I won't go into everything we said, but they'll be like, "I won't go into everything we said because clearly there were secrets."

**Ray | 46:51**
Yeah, feel...

**Ellie Rofe | 46:59**
That means that interviewer and that guest now have a secret between them. Which... It's more of a relationship.

**Ray | 47:09**
From a time allocation point of view, wouldn't you gladly spend two hours with someone to get 15 minutes of private time as opposed to... I mean. I love it. There'll come a time when your book is so full that that's no longer a good trade, right?
But you have Slack in your system. That seems like a really good... It seems like right now it's still better than a bunch of other stuff when we think about study. I think about, "Okay, what are the serious books and then where are the conversations?"
I think about someone like Thrish Patel, right? He's been doing really well as a podcaster. What was he doing? He is... He's studying his butt off before getting into these conversations.

**Ellie Rofe | 47:52**
One.

**Ray | 47:53**
As a result of... These two things feed back into each other. I think there's a company that if you had those things going on, I think you could really get a significant wheel going.
In fact, you already have some drugs. I think about the SDP thing, like, "Hey, if you just want to talk about policy stuff, should you ever talk about policy stuff?" It seems like if they're like, "Well, we don't really have money for you."
Well, could you come to my podcast?

**Ellie Rofe | 48:18**
Yeah, they are... I think their next one is at the end of March, but their next green paper is, I think, their industrial policy.
Now I don't know what is in there and whether they've thought about the entrepreneurial startup side of things or whether it is to do more with manufacturing and energy and hard industry, but it will...
I'll chat with them. I know Matthew, the guy who's writing it, and maybe he can come and talk to me a bit because they'll want to trail it and they'll want to build some interest.

**Ray | 48:48**
Yeah, and then the... If you just start it's a pair of the pots, right? You just start doing it and you will get better at it. I'm not expecting the first thing to be good or the fifth thing to be good,
but if we are doing them on the regular, we significantly shorten the timeline to them getting quite good. And like I say, you have enough innate skill that I'm actually thinking that I don't know that everyone's going to know about it, but I think if somebody were to discover it on number fifteen when they're getting more traction,
then they go back and look at number one, and they're going to say, "Hey, wow, this is really good. Why didn't you hear about it before?"

**Ellie Rofe | 49:24**
Yeah, okay. It's just... I'm excited by the idea of just learning as well and meeting lots of people. It's always interesting.

**Ray | 49:32**
Right? I think that the trick is when we talk about studying in the market, the highest... Well, studying in the market and then deep reading are the two most valuable forms of study, right? The trick becomes... My standard for study is if you're reading an article or something or an occasional article or you are going through your LinkedIn feed... Those qualify really as study because they're neither deep enough nor in contact enough.
That's why I'm particularly excited for this whole thing of getting you more in contact because I think if you do that, you have a number of conversations. Then I think you have a number of those conversations. You read a couple of books, and you're able to bring insights back to the market that they will not have thought of that will be legitimately... I don't know if they'll be novel because often these things are about rediscovery, right?
But they're going to be valuable and out of band for a lot of people and drive a lot of value in reputation.

**Ellie Rofe | 50:29**
Well, that novel rediscovery is interesting in itself. What have we forgotten about investment since the software takeover in early 2000s? I guess mid-nineties. What interesting things have we forgotten? What do we need to relearn?

**Ray | 50:46**
Well, I'll do you better. I would propose that the software as it was done in 2000 versus 2002 was a significant change, and there was another significant change in 2009. Basically, post-financial crisis, both of these changed the way software investment happened in 2002. Sure, it was a lot more software, and they were trying to decrease the risk.
But it was still a... It was the start of SaaS because that's when Salesforce hit. Then, in 2009, we basically went to zero interest rates for 15 years, and that substantially changed things. Bush meant that software and the idea of a subscription business had a much higher present value because there's almost a discount rate associated with it.
Capitalization became much weirder. Now, wait, I could capitalize that because now there's a bigger spread in my cost capital versus your cost capital. I wonder how much of a financial, macroeconomic thing there is in addition to whatever political stuff is for more manufacturing-oriented businesses as well. All of which, I'm sorry.

**Ellie Rofe | 52:01**
Eight?

**Ray | 52:03**
I'm not trying to give you a particular thing. Just say, I think the whole field is really interesting,
and you're going to find some really cool stuff to talk about.

**Ellie Rofe | 52:09**
Yeah. And I can just like I've got equity analysts like I know some, but I know the heads of equity analyst departments.
And potentially I could be talking to people in specific verticals there sectors and say what is happening here from your point of view? And yeah, and economists as well like although [Laughter] yeah.

**Ray | 52:40**
Talk to everyone. I would propose at the outset that anyone's willing to get on camera with you. Let's just do it because these are all conversations in service of helping you look smarter. Then, as you have more people, it's going to become easier for you to get more people.
So, let's not let the perfect be the enemy of the good.

**Ellie Rofe | 52:57**
Yes, absolutely. Okay. This feels like I'm building towards something that is actually important, that is actually not just important, but it's actually a bit life-giving and will drive things. Drive things? Well...

**Ray | 53:14**
Yes. I'm super excited about the Maddie news. The... Thing, I think is just so interesting. First of all, being able to put them to work for you for the near term, but there's a little bit of... Is there a donor thing here?
Because if you know the donors, the person who's a donor to SDP is more likely to be an LP.

**Ellie Rofe | 53:35**
Yes, that's a really interesting point. So I don't know enough about the political fundraising system, and that's one of the areas.
But I do know that they have a chance to differentiate and say we're not just doing back-and-forths in back rooms, we're doing something differently. That's one possibility. It may or may not work, and they may or may not go.
But I think that the steps are the same. One of the things I was thinking was maybe part of the payment is that I am somehow linked with the donors. Maybe I'm not in the room every time, but something...
I have some sort of role where I am connected with the people who are donating and the people who might donate, and I am able to somehow be present. That is a form of payment
because these guys are connected. They're not as highly functional, they're not as funded at the moment because they've been titling around a bit, but they are connected, and their signal as well. They say...
I mean, it's not a great optic in terms of the fact that the court team is now entirely male, but they did sack their deputy leader, who was the only woman in it. But it's a very common left-wing thing in the UK, but she was from the Communist Party.
Dragging it all down. There is a signal there to me that they are determined and they are trying to move into startup mode. I just think they don't quite understand what that means.
So they're talking about, by 2034, we'll have done this. I'm like, "No, by the end of the year, you will have done this and you will have this money." That's the... I talked to them about the timing window and stuff like that.
So there are possibilities there. I just have to see how startup mode they can really go and whether it's worth my time or whether they are just going to be slightly self-indulgent intellectuals sitting in rooms talking about how they could just fix everything if they were given the chance.

**Ray | 55:52**
Yep. Even if they are, you figured out how you can put them to work for you.

**Ellie Rofe | 55:56**
Yes.
That's a very good point. If life gives me intellectual lemons, you make entrepreneurial lemonade. [Laughter].

**Ray | 56:04**
Okay? Good. You draw some banger lines, you're going to have a good week. I think. I think this week is your turn on the hot seat.

**Ellie Rofe | 56:23**
Yeah.

**Ray | 56:24**
We work on Tuesday. I'm a bet to work for you on Tuesday's meeting. Then finally, on Monday, I saw that you did the thing again.
However, I do have a conflict at 12:00. I apologize, it was not on my calendar at the time. Would you mind pushing it back by 60 minutes to do it at 01:00 my time, which is like whatever time it is for you?
Okay, so currently it was at 6:00 PM your time, right? Okay, so I'm just going to take that 12:30, and I'm going to drag it down to 01:00 PM. You'll get an updated invite, and you and I will talk again at 12:00 PM your time on Monday morning. On Monday afternoon, I guess.

**Ellie Rofe | 57:08**
Yes, okay, perfect. Yes, sorry, I'm getting confused in my diary, I'm going to sign off.

**Ray | 57:11**
Fantastic. Does it?

**Ellie Rofe | 57:15**
Okay, thank you, Ray. Take care. Have a good weekend. See you.

