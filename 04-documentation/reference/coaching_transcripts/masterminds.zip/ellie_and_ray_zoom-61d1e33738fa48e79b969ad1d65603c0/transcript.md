# Ellie and Ray Zoom - Oct, 10

# Transcript
**Ray | 00:02**
Hello, Ellen, how do you do today?

**Ellie Rofe | 00:04**
No, sorry, I'm a couple of minutes late.

**Ray | 00:07**
Not at all. Would you mind terribly if I asked after your health?

**Ellie Rofe | 00:12**
Yes, all good, thank you. How are you feeling? I just had a stomach upset. So it was a brief horror. Then Done?

**Ray | 00:20**
Yeah, those are quite unpleasant. Mine has been kicking my butt all week. I got bitten on Saturday, and, yeah, it was a dog bite. That was a start ball. This... I don't know if I put that into the thing.
Yeah. And like I thought nothing was wrong, it hurt or cleaned it, the stuff we're supposed to do. It's a domesticated dog. It has or putatively decimated domesticated. It did bite me.
But anyway, it had shots and whatever, so I wasn't that concerned. I just bounded up and continued with the visit. That was the reason I was there. Then doing my things over the course of the next couple of days, and then a couple of days later, I was just...
I was quite ill. My wife, bless her, said, "We are now going to the hospital together." Me, you know, we went to the local rural hospital. Interestingly, you might think animal bites are an unusual thing in a hospital because they're usually not,
but in the country, right, where it's actually a very common thing. They say, "Yeah, sure, we know what to do with that." We're going to hook you up with a bag, and we're just... As a dog, okay? We're going to put up these antibiotics, and they just had the game plan, but it's been kicking my butt all week.

**Ellie Rofe | 01:43**
Wow. Who's got a dog that's biting? I mean, I can't stand it. Like he's got dogs that are biting people still.

**Ray | 01:53**
Yeah, you know, this is a dog where they will put the dog away when strangers are coming around. Now we know why, right?
But it just came charging right up at me and went right for my arm.

**Ellie Rofe | 02:13**
Wow.

**Ray | 02:13**
So maybe a guard dog?

**Ellie Rofe | 02:14**
German Sheph.

**Ray | 02:16**
Yeah, I don't know.

**Ellie Rofe | 02:17**
Is it a German shepherd or something?

**Ray | 02:20**
Breeds certainly very protective and, near as I can tell, very sweet.

**Ellie Rofe | 02:21**
Okay, yeah.

**Ray | 02:25**
I got a toddler in that family and apparently have no concerns about that, so. So fine, that seems to work for them. It just has the... It's owned by a family member. I'm not to give them any trouble or whatever, but animal control came around, and they wanted to know we were the dog.
Because of what you were saying, people, dogs shouldn't be biting people. So it was a bit of a thing, but yeah, I haven't had a full day since, and I think today is probably going to continue that trend. I did my call at 6 am. I'm doing my call with you, and I think I might hang up my spurs for a couple of hours because it's just.

**Ellie Rofe | 03:09**
Yes, yeah.

**Ray | 03:10**
The body is spending all its energy trying to fight the infection.

**Ellie Rofe | 03:14**
You need to fight that stuff off. I mean, God, I love animals. I'm surrounded by them, but I.

**Ray | 03:19**
Two.

**Ellie Rofe | 03:21**
I mother got half-attacked by one of our cats a couple of years ago.
When you start looking into all the things that they can carry beyond rabies and stuff, which is vanishingly rare in France now, but way beyond that, it's like, "Okay, well, you need to go to the doctor because you definitely need antibiotics and stuff.

**Ray | 03:35**
No.

**Ellie Rofe | 03:46**
It's a horrible stuff. I'm so sorry.

**Ray | 03:49**
Yeah, well, I mean, just mouths are dirty, and that's, you know, that's just how it goes.

**Ellie Rofe | 03:53**
Yeah, I was.

**Ray | 03:56**
So anyway, that's been of the week.

**Ellie Rofe | 04:02**
Yeah, just as a lighter relief from that. I once got very sick from a dog infecting me, but it was a dog trying to give me kisses. I had given my dog in the UK a lamb's treat, which tells you how delightful animals are.
Shortly after chowing that down, she jumped up and tried to kiss me and licked in my mouth, which is one of the most disgusting things. It was Christmas morning. I have never been that sick in my exactly.

**Ray | 04:37**
Goodness. Okay, so more than one door into this house, I guess.

**Ellie Rofe | 04:44**
Animals are rank. [Laughter] I'm so sorry.

**Ray | 04:50**
Yeah, I'm surrounded by dog people. There are a lot of people in my family who are dog people. Certainly, a lot of people here in Vermont are dog people.
"Hey, you're living out in the country, don't you have a dog?" The answer is absolutely not.

**Ellie Rofe | 05:05**
Yeah, I love dogs, but I have friends who are just like, "No, this doesn't make sense.

**Ray | 05:06**
What do you do? Yeah. So it sounds like this week was heavily about the aside from the your, you know, stint being ill, for which I'm very sorry. Sounds like.
But about this quick thing.

**Ellie Rofe | 05:22**
Yeah, there's been a lot of work on that. And meeting with her just after this, actually, she presented it to her lab, got a load of feedback from lab people.
It was lab people's feedback. It wasn't sensible commercial feedback. So... We've talked about feedback already and how to process it and not to go and change everything every time you get a bit of feedback.

**Ray | 05:43**
Yeah.

**Ellie Rofe | 05:44**
And she started panicking a bit. And I'm slightly wondering. I've obviously gone way over and above on this because there's so much she didn't know, but I'm slightly wondering whether there is an opportunity here.
But she's very smart. She's not naive. She's just naive.

**Ray | 06:02**
Yeah.

**Ellie Rofe | 06:03**
I'm wondering whether there's an opportunity to parley to offset a little bit of that overinvestment by saying to her, if it's within your budget, I could do... We'll just try it for a couple of months, like three months to start. Or something I can do, like a 1,000 a month retainer where you have a call every Friday and go through any feedback and I give you advice on what to process or how to assimilate that feedback. What to do, et cetera.
So it's just limited.

**Ray | 06:38**
Coing. in. Business coaching? Service?

**Ellie Rofe | 06:42**
Effectively coaching. Yeah. And I'm just wondering. I've been considering whether this is actually a much more interesting... Not right now, it's a thing to build towards, but whether this is actually a much more lucrative route, which is I do the debt for people.
But then on full pay, you have a 4,000 pounds a month contract where you work through with them as they're raising and help them progress the narrative as they need to as they meet the real world of investors, which they inevitably do. I'm just wondering if it's worth having a test for that one call a week. Some as sync feedback during...
And that obviously then gives me a little bit of something coming in for the next few months. If she wants it, it's not a massive outlay for her, but it gives her stability. She said on one of our calls, you should be a coach. You're really good at helping me understand stuff and things like that.
So it's like, well, maybe this is a way of polling a little bit more value out of the engagement itself, testing how this might work in reality. Maybe helping her get closer to that close and that moderate success fee that I've got booked in.

**Ray | 08:01**
No.

**Ellie Rofe | 08:02**
But don't know. I'm going to talk to her because I think she's going to have lots of questions.

**Ray | 08:06**
Yeah, I really like that idea of... For a lot of people, it can be particularly if it's not a fast-moving engagement.

**Ellie Rofe | 08:08**
She really wants, I suspect, for me to keep doing stuff on this deck. It won't feel finished to her at the moment, but the scope of our original arrangement I've gone way and above beyond.
So I need to draw a line there and say anything else needs to be scoped, and we can either do it literally work on an hourly rate and it will ramp up quite quickly if you want me to keep doing changes to your actual deck or we do this S.

**Ray | 08:48**
I like fast-moving engagements. I try to encourage them, but
if it's not going to be fast-moving, then it starts to look like a retainer engagement. Having a pricing structure for that makes a lot of sense. This again brings back to our friend Dan Priestley, right, the whole four types of products thing and the. Ellen Weiss talks about this, where this kind of thing that you're talking about is I think you can probably afford more easily really becomes a potential long-term, lucrative source of business as well as the hunting license, which is the other big IO.
So, I love your idea of all right, weekly calls and this is covering your prep for each of those calls and they're having them as high-quality experiences. You're recording them, you're giving them back to her so she has them as a force, right?
That's sort of how connect somebody out and then... Yeah, a thousand quid a month. Then I suppose you'd rather have equity than euro.

**Ellie Rofe | 09:46**
It will be a.

**Ray | 09:49**
And then...
Yeah, and then it doesn't even need to be until she does the fundraiser, right? This is you providing senior advisory services, right? If that's really what she needs. Consider what you said before about brand strategy, which is a lot more fun than looking at what this business is, right? As opposed to building the presentation for them, which is affecting a change, right? It has a core product aspect to it.
It's a combination of synchronous and asynchronous work. Finally, it requires them to have a particular thing they're trying to do with the presentation, which is tough, right? This person is just trying to build, it's much more protean, right?
So, they're looking for help getting through this. It's not like it's obvious they should spend a big amount of money on this one particular artifact. You take on those lines so that it feels right to me.
If there's a market where you can be getting people to come on using your services for 1000, 2000, whatever it might look like per month. And I would not be shy about underpricing your initial customers to get some on the board.
That's a nice, reliable source of income. It'll churn, right? It'll last for six months or something. Then the other thing not to let sleep on is the hunting license aspect because it turns into, "Wait, we really need to get this thing done."
Okay. All right, is there something that you think you're the absolute best person to do that, or are you counseling her on how to get that done for less?

**Ellie Rofe | 11:35**
Yes. I've literally told her to put more money for marketing in her budget and said some of that you might want to spend on me, by the know?

**Ray | 11:44**
Some and you, but some others, you can say, "What's the world-class resource?

**Ellie Rofe | 11:45**
[Laughter].

**Ray | 11:49**
And you've got the confidence because you've got the relationship to say, "This is something I think the best thing you can do is spend it on me." This is something where
I think the best you can do is spend it on something where you don't need that kind of rate. Then she can decide what to do. But because you're on the inside to be the inside track for all that business.

**Ellie Rofe | 12:07**
Yeah, absolutely.

**Ray | 12:10**
The thing is, I don't know if this continues to be true in bio, but if she's a person who's got grant money or seed money or whatever to fund this stuff, this could be very different than the other kinds of indie hackers that you previously found yourself doing brand strategy with, right? The question is, who do you have? Who's got the credibility for the business? One and two access to some money so that three they can pay you because I would start. I suspect that all of them have the need for you, right?
But this kind of product could you take it down the road that could be pretty darned joyful for absolutely. And I think the point you're making and like, "You put together a presentation, it's about having the retainer part for the presentation."
It's like the presentation of anything is leading you into this other, more senior advisory business that's more valuable.

**Ellie Rofe | 13:10**
It's really interesting you say that because that's where I got to eventually with a whole round table of advisors on an AI chat.
But it took a while.

**Ray | 13:18**
I'm almost in what you're saying.

**Ellie Rofe | 13:21**
You are six times the speed of a power of a robot on its own with about 20 times the speed. So well done. [Laughter] Yeah, I took a little mastermind approach there.

**Ray | 13:32**
The. So you are using Mitch's little AI mastermind approach.

**Ellie Rofe | 13:41**
I was trying to work out the positioning because I saw I was flipping flopping a little bit.
Then, we're saying, the big issue is that this credibility gap where I'm not a scientist. I don't have deep biotech expertise. I don't have a ton of Razors recently or any recently, and raises take time.
So I'm in this kind of catch-22 of trying to do work for less to prove myself, et cetera, and that's when... It's really similar. It's funny how... This must be so frustrating for you. It's funny how there's the thing, but I just can't quite see it properly, and then the little switch flips and then you go, "No, I understand it now."
So we've been talking about the tool to research and update and get instinct insights on the market. We've been talking about the VC report and how they can be both a study and a sell.
Then the pitch analysis tool as a thing that would be an interesting kind of almost like a magnet, certainly marketing, but a quick turnaround thing that you could do for people that could become something.
And I suddenly realized it's both. So that tool is the study as well. So I can take... I've now found quite a few pitch decks. It's a bugger technologically because I run on SlideShare, so I'm going to have to try to extract the images.
I think there might be tools online to extract images from SlideShare slideshows, but I'm going to manually analyze ten of them first, and I'm going to be thinking about things like where in the deck the first problem slide is, where in the deck the solution is, and how many slides are devoted to XYZ. Using that slide structure visualization, giving it a score in terms of commercial readiness across the market, understanding the team, the investment milestones, and all sorts of stuff.

**Ray | 16:02**
He.

**Ellie Rofe | 16:03**
Design and extrapolate that into something that is not just here's a report I could give clients.
But in the meantime, is here's some proper analysis that I can do that I can then talk about. So it's funding both things. And then as I'm doing that, I can tighten up the report because at the moment, I've been a bit. The visual of that structure is great, but the rest of the port report was a bit loose and it was frustrating me that it wasn't quite right. I can tighten up that prompt. I can tighten up that tool and make that really valuable and gradually move that towards a paid thing, a paid diagnostic.

**Ray | 16:37**
Play for mat 28th.

**Ellie Rofe | 16:44**
So an initial diagnostic, the pitch deck, the retainers... It's a really nice flow. But more than anything, I was... Then I said in a separate chat, I was like, "I'm doing this. Do you think I could eventually pivot it into Brown Strategy?"
Because I think that's more intellectually engaging sometimes because you have to think much more about positioning on a wider level and proper audience analysis rather than who you are talking to with investors.
There's I think there's a bit more of a two-way communication thing that I enjoy about it. And I showed the difference between the initial deck for Strata CL and the next one. And they're like, "Well, you've just been doing brand strategy. You've dressed it up as PITCHDEX, which is what people want. You give them what they want, but you're giving them what they need."
The long-term engagement becomes brand strategy. I think that's much more via... I think part of the reason I've had such a disconnect is because biotech on its own, if I'm working on drug development companies, there's such a big lag between pitching and getting the investment and commercialization. They'd get an exit normally before then.
So, the brand strategy piece is very tenuous because they're really just working with investors and Kols and things, and it's within the industry. They're not trying to think about that commercial side of it.
But if I move... If I incorporate in my work clients who really are getting to commercialization like a diagnostics company would get to commercialization within the first couple of years. If I, as I'm doing this research, if I start bringing in more verticals in hard tech, some of those verticals get to commercialization much faster than biotech. The drug development side, which is one of the longest leads.
So, I think it's a really interesting route. It suddenly started clicking for me that it's not either/or, and that I can build X. So, I can't remember which one it was in the round table, but one of them was like, "You don't just show expertise by results in terms of fundraising. You can show expertise by showing expertise through this kind of research."
You're literally... You've been saying that to me, obviously, but on the granular level of PITCHDEX, and the things that people who are like VCs might not even know some of this. But people who are unable to see their pitch deck founders who are unable to see their pitch deck can then see their pitch deck in a way that they can't now. Then that extrapolates out to so many different types of engagement potentially.
I'll try and keep on a path maybe towards Series A initially, but, if you like, incubators and accelerators, you could do bulk diagnostics and then potentially get them to pay for you to do the ones that are closest to being commercially valid at the moment, just to do the pitch deck.
Then you're in with someone else or VCs. I'm going to talk to that woman who I've realized is a partner. So, when she talks about decks and stuff, she's like, "No, we don't need any of that."
But I'm going to say, "Look, is there anyone lower down in your company that would be interested in feeding back to me, supplying me with a pitch deck, and feeding back to me about what is or isn't working with this tool from a VC point of view?" Because then it would help them analyze the DEX faster and process things faster.
So, it could potentially have a tool that you sell into VCs if they haven't got that already, but they might. But it just feels like there were things that weren't quite fitting in, not quite fitting together.
It feels a lot more like they are much more now.

**Ray | 20:54**
Yeah, that's awesome. Can I ask what you used for the round table? Okay. It was just a Claude project that a single Claude project or user had multiple Claude conversations going, each of which had different context or how do you get them to have the different personalities.

**Ellie Rofe | 21:14**
So I did an iterative thing first where I worked through some strategy ideas, just with a standard Claude instance chat. I think I probably fed in some ideas and talked through stuff on a one-to-one basis. Then, at the end of that chat, I asked, "Can you give me the names of five to six people who are experts in... I think I listed lead generation consulting and high-end service provision. God, I can't remember what else."
It came up.

**Ray | 21:55**
So it's spit. I mean, Weiss and Branson and... Yeah, okay.

**Ellie Rofe | 21:59**
Well, it spat out. Let me see if it spat out at you.

**Ray | 22:02**
I'm actually very curious what names it would choose.

**Ellie Rofe | 22:03**
[Laughter] If you really wanted to dig in, if you didn't come up with the right things or you didn't use that, you could really come up with loads of different people.
So that was as right.

**Ray | 22:21**
But I was curious who they were. They're experts. And then I can go read up on those experts because I'm trying to, you know.

**Ellie Rofe | 22:25**
Well, we could suggest some better ones. April Dunford, author of, obviously, Awesome Positioning.

**Ray | 22:30**
Y.

**Ellie Rofe | 22:33**
Blair Ence, founder of Win Without Pitching. Jonathan Stark, Value-based pricing, productized services. PEEP Larger Liar, founder of Winter BTB Messaging testing and CXL Conversion Optimization.
So about messaging round Fishkin, which was a surprising one to me yeah.

**Ray | 22:56**
Good.

**Ellie Rofe | 22:59**
So transparent content, led B2B marketing, and audience intelligence tools. David C. Baker, author of the Business of Expertise in selling your professional service firm.
Daniel Priestley, funnily enough, author of Oversubscribed.

**Ray | 23:15**
Yeah. He just keeps on showing that, doesn't he?

**Ellie Rofe | 23:18**
Well, he's done very well at being a key person of influence, hasn't he? [Laughter].

**Ray | 23:24**
It was a book that... But it doesn't even cite KPI as the reason to pay attention to it that I like Oversubscribed. Okay.

**Ellie Rofe | 23:37**
No, it does mention that. Sorry, it's just Oversubscribed as the angle. So then, yeah, if it's like... It's always got these little stage directions like.

**Ray | 23:43**
Yeah.

**Ellie Rofe | 23:47**
April Dunford leans forward with notes, Blair Ence puts down coffee. Jonathan Stark adjusts glasses like it really tries to get into it, which is hilarious.
It's like a badly written screenplay.

**Ray | 23:58**
No, here's your cast of characters, and then what you do, and then you continue the chat and say, "Hey, what would this person say about this?" That's the modality of it?

**Ellie Rofe | 24:09**
Yeah, Jo me just to share the screen and show.

**Ray | 24:11**
What do you mind? I'm desperately curious about because, like, this idea of, like, bringing a mastermind together, I actually think is. I found it to be kind of awkward.
All right, a simulated round table, okay?

**Ellie Rofe | 24:24**
Yeah, so I've put files in project files in there, so this is... You can't see any attachments there in the project.

**Ray | 24:24**
Where? Everybody... Just gives their comments on it. Interesting one.

**Ellie Rofe | 24:36**
I give the overview that the thing you'd give me just to make sure that it doesn't pick the wrong people and just to guide it what we care about here.
Then, yeah, it's just like they start talking.

**Ray | 24:55**
Yeah. Is this a pretty good step?

**Ellie Rofe | 24:57**
It's really interesting. They start talking, they interact with each other. So they're writing about pricing psychology, but you're doing it backwards, blah.
Then, some of them get into testing. Obviously, that's why I had the testing person in there. This is interesting. You have no distribution linked in. Organic is declining, agencies have this YouTube takes this, blah, build a data asset creates continuous value.

**Ray | 25:27**
Yeah, I was doing it all, shouting too, right? So these were all coming off the same thing, Yeah.

**Ellie Rofe | 25:34**
Yeah, this one shot, which is fascinating. I was wondering if it would do that. Daniel smiles on my phone. Then obviously, it talks about engineering demand, and then in other ones, it then synthesizes it, and then gives homework stuff.
Then, I pushed back on people saying, "You've got expertise." I said, "Well, I can't demonstrate it." Then they start discussing the credibility gap, for example, and that shifts their strategy a bit.
Yeah, exactly.

**Ray | 26:11**
A little bit of... You're absolutely right about that. Yeah.

**Ellie Rofe | 26:16**
Of course, there's all the hazing, but glazing, rather not hazing, but yeah, this is interesting, right? Manufacture credibility through a different path. Position yourself as the researcher instead. Build authority through published insights, which is things that you've obviously been telling me.
I just didn't quite connect with the vehicle for that. I wasn't quite understanding it. Then I think later on, I mentioned the pitch diagnostic, which might not have been mentioned here, but maybe not properly.

**Ray | 26:58**
2?

**Ellie Rofe | 26:59**
And yeah, there's... I mean, it gets quite long. Then you know, because each one of them has to have their say.

**Ray | 27:02**
Yes. Does?

**Ellie Rofe | 27:06**
And after this, I then dumped it into ChatGPT after this and said, "I put all four conversations in with my interjections and said, "Can you look for inconsistencies or flaws in this advice and where it ends up?"
I'm constantly dotting around between different AIs. Anyway, I would work on something there and then take it into another. Sometimes that's just because I get frustrated with Claude's. I tend to work through Claude more, but then I get frustrated with its suddenness. This chat is now full and there's no precursor to it, particularly, so I... Obviously, GPT just has the endless chat, and it loses some nuance and understanding after a time, but you can still get it to do certain things.
It's better for execution at that point, so that's how I do that.

**Ray | 28:04**
Two.

**Ellie Rofe | 28:07**
But. then I took that plan back into Claude.

**Ray | 28:13**
No, yeah, the it all sounds very, it's very cool.

**Ellie Rofe | 28:14**
You can see, I kind of workshop things around a little bit, but... Yeah.

**Ray | 28:25**
The, the context window becomes a problem over time. Claude actually, Anthropic came to the market as their big competition. Committed value was that they had a bigger context window than anybody else back when they had like a thousand words or something, right?

**Ellie Rofe | 28:44**
Yeah.

**Ray | 28:44**
And it was and well, never needed. It was very much a Bill Gates moment. Have you heard that story about Bill Gates? The whole 64K thing?

**Ellie Rofe | 28:53**
That's why the Y2K bug and everything manufactured manifested. Because they just thought they'd never need more numbers.

**Ray | 29:00**
We'll never need more memory, never need more numbers. So, as opposed to... I was talking to an engineer over at Facebook. You can tell where the money's going on Facebook because he used to be working in security, which was super high-end, and now he works in AI, which is super high-end there.
So this tells you maybe that Facebook isn't a serious security anymore, but he told me that one of his research colleagues, he works on the infrastructure side. He said that he doesn't foresee any time when there's going to be a slackening in demand for GPUs.
Because AI is just about imagination. Then there's no limit to human imagination. What happens is the more stuff we have, the better the technology gets, the more imagination we're just able to start to put to work, which just fills up the demand again, right?

**Ellie Rofe | 29:56**
One.

**Ray | 29:56**
Yes, we did the thingously doing. Now we have new imagination.
It's like there's no physical limit to it, right? Because it's just from our minds, and we keep on going up and up. The and I think about that in terms of the demand for tokens, for example, is a small version of that demand for GPUs, and why NVIDIA stock is going up is a bigger version of that.
But I got to say that you're doing right now, like that mastermind thing. In addition to being a very cool exercise you did for yourself, that is a freak and compelling story for you to be putting into the market.
And people have heard... I should... We've talked about digital twin stuff, right? That's one of the most effective digital twin use cases I've seen. Mitch does this stuff, too.
In talking to him one-on-one, you can learn a lot about it. He never ever shares anything publicly because he comes from a branch of marketing that's all about... I've got a secret, right?
His fear is that his real market value is that he knows half a dozen secrets, and if he shares them with... If he lets go of every one of those, he erodes his competitive edge.

**Ellie Rofe | 31:17**
Wow, it's an interesting idea.

**Ray | 31:19**
I that is not my idea of a free persist.

**Ellie Rofe | 31:25**
It's half-true, I guess. As someone once said to me, "I'll cut you a check to make things happen faster and easier.

**Ray | 31:29**
5.

**Ellie Rofe | 31:35**
They don't do it just to get some magical knowledge out of you. They get the magical knowledge out of you,
and then they're like, "Wow, that was magical knowledge, But.

**Ray | 31:44**
But the other thing that happens here is... Well, there are two things that are two key principles I think are important. One is... I have seen, many times, consults become far more successful after they publish a book. Dunfords' practice took off after she published, obviously.
I've met her, and she would say that too, right? In terms of her consulting practice, her consulting practice was largely based on talking to her old clients, right? But then, when she published, obviously awesome, she started getting into all sorts of VC deals and whatever.

**Ellie Rofe | 32:16**
Yeah.

**Ray | 32:20**
And often use the example of Michael Porter as well, right? A professor, a successful guy to begin with, to be sure, but then he publishes on strategy and on competition, and the various tones that are now the cornerstones of business strategy.
He had to open up Monitor to handle the business, and Monitor became a pretty big consulting firm that was able to stand on its own. So, I wish by way of saying that my observation is that it attracts...
What happens is you put this in front of people, and then they fail to actually implement the ideas. It was your idea. They come back to you. The second thing is the experience you were just describing. They have the conversation and go, "Wow!"
Part of it is hearing it from you is different than hearing from someone else. Much like you were talking about, you heard it from me, not from the AI. Why are you suddenly
hearing it a different way? Well, old Bosson. I used to say you could only learn what you almost already know, so the idea has made it a way in. Wait, something else gets at the rest of the way in.
Sure, whatever gets the rest of the way in and gets the credit; who cares? But if you have seeded the ideas, they're actually going to become more receptive. They're more likely to be successful if they read the book because they almost already know about it easier to tell them.

**Ellie Rofe | 33:41**
No, absolutely. You don't just dump a book. You have to seed the ideas because then people want to know more about them.

**Ray | 33:47**
Well. that's what the book is. The book could be a complete playbook. If you read this and understand this, you'll be able to do this all yourself.
That can be the promise of the book, and that can be an accurate promise. But the vast majority of people will not do so competently. That's the reason why they need help because they don't have the competence for that part.

**Ellie Rofe | 34:03**
That reason is a story brand consultant.

**Ray | 34:03**
And back to you. Yeah, so my... Anyway, all of which would be by way of saying that this is awesome stuff. I'm so glad that you found that to be helpful, but I look at that and think you sharing that story with more people than just me will be attractive for you as a marketing consultant.

**Ellie Rofe | 34:28**
Yeah, okay, you're right. I'm much more excited now to start talking about stuff. I think when I was trying to do stuff in LinkedIn before, I just felt like I was walking through jelly.
I do wonder, and this is more when I've got a bit of traction in my own... Or at least a little bit of a rhythm and pushing things. I do wonder if I should be on X. It's where I went to look for people posting their pitch decks.
It's where a lot of hard tech and frontier tech people still are, and I think, yes, it's a cesspool on certain levels, but it's fine. I'm quite robust on that level. I don't really care if they are trolls or lunatics or whatever.
It's more about just finding ways to connect with people outside of immediate circles or people who might look at LinkedIn once a year. You can see who's active on X. Really?

**Ray | 35:30**
Yup, you can definitely. Well, I suppose you can see who's active on both, but the, you can totally do that. And then, you know, x is can be powerful. YouTube is powerful.

**Ellie Rofe | 35:42**
Yes. That's the other thing I was thinking of: pitch deck breakdowns. Obviously, some of the pitch decks I found are from Crunch Tech Crunch doing their breakdowns or takedowns. They call them.

**Ray | 35:53**
Two.

**Ellie Rofe | 35:54**
But I think there's an element there, but there's a really scientific part, or not scientific but statistical part, that's playing a role. I talk about stuff, and just... Yeah, just as an aside, because it's just popped into my head and it really made me laugh when you said you can't guarantee that with the Pillar Tech. The other guys... I just had a call with them this morning, and he said, "Yeah, it's been really interesting since before you."
So before you came on, we were trying to do all these different things. Since you've come on, what I've realized is that we're trying to do too many things. You can't do AMR and oncology together. It was like... He just... It made me laugh so much because he was just pitching it as things that he had worked out rather than stuff that we had talked about.
I was like, "This is brilliant." He's completely bought in. There's this ego partner. I'm like, "He's not giving me recognition." Then I was like, "No, this is perfect." He's totally bought in, and he's really excited about pushing through with his antimicrobial resistance deck on full bore.
I realized that's a more powerful place to get people to go, so that felt good. yeah.

**Ray | 37:14**
It was incep. It was inception.

**Ellie Rofe | 37:19**
Yeah, [Laughter] exactly. It's fully internalized. [Laughter] So, yeah, it will be interesting. That should be done by the end of next week, so it can be shipped out and potentially another ongoing thing because I think he's realized that he might need a bit of a brainstorm now and then, but we'll see.
But yes, so that they just... I think the research project one question I do have for you is.

**Ray | 37:54**
Hey.

**Ellie Rofe | 37:57**
And is pragmatic. If you're still feeling okay, if you need to go, then that's fine.

**Ray | 38:03**
I hope I'm not giving off the impression that I'm not paying attention by I'm plugged in. We're good.

**Ellie Rofe | 38:09**
Not paying attention, just looking a little bit tired. It's just a pragmatic question. Is this their table just the best place to dump information for now.

**Ray | 38:24**
If what you need is something tabular, it's a pretty good place for information. I might use that or Google Sheets depending on the type of thing, but I think this looks nicer.
Yeah, sure.

**Ellie Rofe | 38:34**
I want some relational stuff. I do have a bit of a glitchy issue which I've asked them about, which is that I basically need to be able to count the number of slides in here that have a specific deck relation and then count basically the number of slides.
So this breaks down each slide based on what's on it. And this one would then have like the number of slides total on it. But other than that, I think it seems like a useful place to start. I just didn't... The only thing I wasn't sure of with their table was they don't have an MCP of their own.
The user-made ones were not particularly functional, or they weren't the last time I tried. Does it matter?

**Ray | 39:26**
Yeah, there's some stuff you're right, there's some stuff that's community-made for it, but they have their agent omni, right?

**Ellie Rofe | 39:35**
Yeah, which is dreadful.

**Ray | 39:37**
Yeah, I've heard that too.

**Ellie Rofe | 39:39**
Yeah, I didn't know.

**Ray | 39:41**
Okay. Well, I... Yeah, I was wondering to say what I think you thought I was about to say, which is that I don't know of anything better than just using... If you want to be going down the AI or embedded route, Claude Rote Road.

**Ellie Rofe | 39:43**
Sorry, what are you going to say?

**Ray | 39:57**
I think there are like two or three different community-made Airtable servers, and I'm not sure which one is going to be the right one for you. I haven't worked with it much.

**Ellie Rofe | 40:06**
No, I'd vaguely considered just whacking stuff into Zoho into a free instance, but then I'm like, "It's not my favorite place to be." I love Robert's tool. I think it's very useful, but in itself, in terms of working in the tables and staff, it's pain in the ass, so I don't know.

**Ray | 40:20**
Two. If what you want to do is work in tables, there are better tools for the job, right? They're much more table-first. If you're looking at business intelligence work,
like looking into a big query or something, it can be a better place for you to be. Then you'll load the data and then be able to do your SQL to make this stuff
that's the level of power you're going for.

**Ellie Rofe | 40:51**
What I'm aiming for is initially, I will manually review these decks as I'm manually reviewing them after the first ten max.

**Ray | 41:00**
Two.

**Ellie Rofe | 41:02**
I will want to then automate stuff like work through these 20 slides and gauge how many words are on each slide, what the slides are about, et cetera, and just have that populate automatically, and then eventually have it analyze automatically as well.

**Ray | 41:20**
No, I think I would use the tool that allows you to make the initial progress and then not think that there's any loss in switching tools later as the job to be done shifts.

**Ellie Rofe | 41:21**
But I'll just stay in Airtable for the minute.
Yeah, okay, [Laughter] yes.

**Ray | 41:37**
I think that's how you keep from losing your sanity on this.

**Ellie Rofe | 41:42**
And real value is in analyzing things, not in building tech. So, yes. Keep that focus.

**Ray | 41:49**
Yeah, I think that the new pattern I'm seeing is using AI to build tech for analyzing things almost in the moment. Did you get to see any of the OpenAI presentation from earlier this
well, I'm not... Given your focus, I'm not sure it's best to use your time, but for me, it was a big validation of my thesis of where software is going in terms of things that are embedded inside the AI. Basically, ChatGPT is going to have apps, and that's one of the big... I like the check it... Whatever technology behind it.
The important thing is they're going to apps, and that means that the software will be experienced inside ChatGPT.

**Ellie Rofe | 42:32**
One.

**Ray | 42:32**
The second is... As I say, but the second thing was the big thing they did at the end. It was about using Codex, right? Which is their code-coding tool. They compared to cloud code, and they did a demo, like a live coding demo.
But what they did in the course of it was they made a tool and then used the tool for the rest of the demo. That, for me, is what I would call it ephemeral software. They were like, "That's a demonstration of how you can change the economics of software by doing that." Why do I bring all that up? I bring it up because you might find that using AI to do more of this work...
I mean, you're like, "Hey, can I go find the MCC server to do this?" I only actually use AI to go make the MCC server to do this. I was saying that's something you need to go build, right? But if we treat it as an ephemeral thing, then that helps you timebox the time you're putting into it, what camera resources go into it, whatever.
Frankly, if you put it off, everything gets cheaper the later you do it.

**Ellie Rofe | 43:36**
Yeah.

**Ray | 43:37**
So the idea of, "Okay, focus now on getting that data and getting that initial bit of insight, you'll be able to immediately put that to work in terms of content, whatever, that's a strong position to be in."
Now you're doing is building an asset, and the idea I want Tech to be able to squeeze more value out of that asset. Okay, let's solve that problem. Subsequently, the first part is hopefully helping finance the second part, and the second part becomes cheaper because it's being done further on the timeline.

**Ellie Rofe | 44:03**
Yeah, well, I want Tech to help me build the asset eventually. That's what I mean.

**Ray | 44:09**
Well, it depends on which asset we're talking about when the asset I'm talking about is just building the darn database like there there's right. But the database is made up both of raw data and that's based built on analyzes you're doing of it right?
And I think what you're telling me you can tell me if I'm wrong about this is that you're the place where you're finding your blocks has to do with, like, more of the analyzes, right?

**Ellie Rofe | 44:34**
No, the time-consuming part is adding in each slide, saying there are 20 slides in this presentation.

**Ray | 44:41**
Okay.

**Ellie Rofe | 44:45**
I add each one in, say what the slide is about,
work out the roughly the text density on it, and work out things like what? I can't remember all this stuff now because it's gone out of my brain.

**Ray | 44:55**
Okay, what about the idea.

**Ellie Rofe | 44:55**
But there's a mechanical part of it which is time-consuming.
I'm happy to do it first for you because I think it's important to understand what's working or not.

**Ray | 45:08**
The idea that's popping in my brain, just want to make sure I say it before I lose it is: have you thought about notion?

**Ellie Rofe | 45:15**
I did wonder about notion.

**Ray | 45:18**
Notion has XL, and Spott is willing to think about structured databases right?
We'll traverse right, can do structured data within structured databases. So you can have your slide, and then you can have one of its fields can itself be a database of it, sort of like a presentation as a document, right? Presentation as a document or of a presentation.
But presentation as a document is going to be one line item on that which has XYZ fields including ASA document, which will contain all the notes they're looking for. But then the structure...
It can contain another element inside it as self-a document that is slides, right? It's me, turtles all the way down. Now, it's not as well structured or as performant as a SQL database would be, but it gives you everything. It gives you all the data and then a place from which all it... If you want to go, bring it into something that's more highly structured, like a business intelligence type environment.

**Ellie Rofe | 46:11**
Yeah.

**Ray | 46:11**
And a place in which you can use it and treat it as a content asset, and you can get MCP to do the work for you.

**Ellie Rofe | 46:11**
Yeah.
Yes, that's a really good point.

**Ray | 46:22**
That is actually an insight that Demetrius has really driven home for me. The use of MCP, right? He's using it to fill in the graph database stuff he's doing.
You're thinking, "Man, I don't want to do all this hair table work. Can't the machine just do it for me?" I'm like, "Yeah, sure it can." But if Airtable is going to give us the data, maybe we won't pick the tool that is more responsive.

**Ellie Rofe | 46:53**
M.

**Ray | 46:54**
If we had our drillers, we might want something that's more tabular, like an Airtable, but we give... Given the set of constraints we have, maybe it's worth looking at other tools because it would significantly reduce your timing cost.

**Ellie Rofe | 47:08**
Yeah, no, that's a really good point. I think I'd head to Zano because Robert's tool is incredible for just doing the work. Like I've tested it out, and it's great, but I don't like the product it's using generally.

**Ray | 47:16**
Yes, it is.

**Ellie Rofe | 47:23**
I mean, it's fine. It's not... But it's a slide to Bracken up for what I'm doing anyway. So yeah, Notion makes perfect sense. I use it all the time anyway. So I can... I can really run this a lot out. The databases and the formulas and the views and everything can get a huge amount out of that.

**Ray | 47:44**
Yeah.

**Ellie Rofe | 47:44**
Yeah.

**Ray | 47:44**
And are very serious about this stuff. They have first-party MCB now, which will make... I think even to the point where it's like...
I think it's a Claude connector that's just part of their marketplace, right? As opposed to being something you need to go upload the URL for, something like that.

**Ellie Rofe | 48:01**
Yeah. No, my Notion's linked to Claude, so it would do research. When you're doing research, it will ask if it wants to look at notion.

**Ray | 48:10**
Super cool. Well, it seems like you got some good stuff going. You've got the Apio Tech that has come back and is seeing the light a bit. That's great. You've got the Crick Institute individual. You've got a pathway to both create more value and get yourself better income out of it, which is a serious win. You've got this new content stuff going,
and in fact, the very thing that's giving you ideas for the content is itself an idea for content. It does seem like you're in a really good position coming up this week. How can I help you make it better?

**Ellie Rofe | 48:54**
I don't know. I feel like things are in a good position. I've got my hot seat on Tuesday. If you have any tips for me on how to... I really struggle with questions for that.
If there's any tips on how to make the most of that, that's great. I think we've talked about it before. I just... For some reason, as someone who's quite imaginative and analytical at times, I just find myself bereft of questions a lot of the time, or my questions are a bit reductive.
No, I think I feel like the biggest way to make the week better is to have an expectation of what I'll have done in terms of analyzing PitchDex and posting by the time we next speak.
Maybe accountability is the piece.

**Ray | 49:48**
Okay, so what is your objective for the coming week? There's a whole lot of unknowns here. So, holding yourself to a specific number might turn out to be not all that interesting. To have made meaningful progress feels like the more appropriate goal of this KR.

**Ellie Rofe | 50:04**
Yeah.

**Ray | 50:07**
But. you have a sense based on what you know today, what you think meaningful is?

**Ellie Rofe | 50:12**
I think meaningfulness is like... I think it's ten of these things analyzed, and an initial understanding of where the most value is coming from in terms of the insights, in terms of how that can be translated to the tool that I would use with clients because there's a research side which is more analytical and looking at stats and figures.
Then obviously the layer of analysis of mine over the top of it. But then there's a question of what you would output for clients if you were doing a diagnostic with them. So, I think Pitch is understood and a genuine understanding of where the value is at least initially.

**Ray | 51:05**
Okay, so if I might... You might profit from saying you're going to get the first couple of them done before Tuesday and bring them to the meeting and run through your analysis.

**Ellie Rofe | 51:17**
Yes, okay, good point.

**Ray | 51:23**
Does this make sense to you?
Right? What questions does this cause them to ask? It's a couple. They are smart people, right? They're a little more naive about the particular space, which makes them look a little more like VCs and what you know, and I think you will get potentially useful feedback on that front.
So that helps accelerate the thing that is your KPI for the week.

**Ellie Rofe | 51:51**
Yeah, okay, lovely, great plan in place.

**Ray | 51:55**
Awesome.

**Ellie Rofe | 51:56**
I hope you feel better, go rest.

**Ray | 51:57**
All right. And I hope that you stay better. I'll talk to you better.

**Ellie Rofe | 52:02**
Thank you, chers.

