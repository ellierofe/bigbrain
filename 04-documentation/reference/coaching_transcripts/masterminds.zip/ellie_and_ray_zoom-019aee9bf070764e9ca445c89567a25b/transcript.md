# Ellie and Ray Zoom - Dec, 05

# Transcript
**Ray | 00:07**
Hey, how do you do today?

**Ellie Rofe | 00:09**
I'm very well, and you?

**Ray | 00:11**
That's all right. I got the word that our mountain opens for business tomorrow.

**Ellie Rofe | 00:16**
There you go. That's...

**Ray | 00:18**
I get to walk out my back door and, you know, well, for the first week, for the first couple of weeks, I'll probably be like, have to huff a quarter mile uphill, but the.
But then after that, it will. There there's the chair lift that's down at the here at the base. You know, they are able to open the mountain more easily. And the upper part. So us sort have to get up to there either through driving or walking.

**Ellie Rofe | 00:37**
Have I got here?

**Ray | 00:40**
I sort of do my pilgrimage on foot.
And then later, you know, the more kid friendly section is lower section. And they're once they get upper open, that's when they sort of run the snow making down here. And then once that's ready to go, they'll open that up.
And their big goal to get that opened by before Christmas.

**Ellie Rofe | 00:55**
Wow. So they actually do snowmaking there.

**Ray | 00:59**
Absolutely. At our altitude, sonmaking becomes a really important part of making the whole thing work. Like, when you're like in Colorado, the Rocky Mountains or the Alps fall in this category, right?
Like, where the. You're. You're going high enough that, like, you're. You're. You're going so high that the air is too thin for the trees, right?

**Ellie Rofe | 01:20**
Yeah.

**Ray | 01:20**
So there's above that, there's just the snow stuff, which is one of the reasons why skiing in those mountains is a very different kind of experience because there are big open bowls of whatever the...
But... But it means that you have two things working for you. One is temperature, but the other is air pressure, right? The air pressure difference causes the air to more easily turn solid and turn to snow.

**Ellie Rofe | 01:44**
Got it.

**Ray | 01:44**
We are just at lower elevation.
And so that means that there's a you both need the temperature and you need the tceip, but then you. And you just need more of it. And, you know, global warming is a real thing. Average temperatures here are just higher than they were, say, a generation ago. There's more humanity here.
So like the radiation for humanity itself is pushing it up. And so this place actually probably far more dependent on, you know, artificial snowmaking in this decade than it was 50 years ago.

**Ellie Rofe | 02:18**
Wow. Okay, really interesting. Is it like a one-and-done thing or is that a regular thing? They have to do it all throughout the season?

**Ray | 02:26**
They will do it as much as they can throughout the season. And there are kind of. There are two major constraints of snowmaking aside from the obvious expense. One is you can only do it when it's really cold.

**Ellie Rofe | 02:40**
Yeah.

**Ray | 02:40**
So snowmaking doesn't require it to be, you know, zero C it's got to be basically like, you know, negative. You know, negative six, negative seven C or lower.

**Ellie Rofe | 02:50**
Wow.

**Ray | 02:50**
In order for the tech to actually work, to actually do that crystallization and send that stuff up.
So they have to wait for the really cold days and really the overnights, right? So it runs a lot at night.

**Ellie Rofe | 02:59**
41.

**Ray | 03:00**
Living on the mountain. That means we're often hearing the noise of the machines overnight, which is a little bit of a comforting thing. The like you live out and ruler must be so quiet.
Well, not in this part of the year, but the other consideration is that you need water for it, right? You're turning and you're drawing that water from sources below. This is a climate change thing. We're increasingly going into floods and droughts, which means that the useful level of water is actually less than it used to be.

**Ellie Rofe | 03:26**
Right. Y.

**Ray | 03:33**
And we've had a couple of seasons where, like the Mountain's ability to open more has been throttled by the availability of wire. This is gonna be one of those. In fact, the Mountain was just purchased by a new owner. It has been in receivership for years. There was a whole scandal where, there was a the company that bought it that was, you know, basically doing visa fraud.
So there and which is a whole story, but like the but the so the company's basically been in bankruptcy, been run by a receiver for since we moved here. Since before we moved here. So it's since the pandemic, basically.

**Ellie Rofe | 04:05**
One.

**Ray | 04:06**
Then they finally sold to a new owner, but the new owner doesn't have any experience operating it. So they thought, "We're going to get this thing open. We're having a pretty good season, and we just need to do some snowmaking."
Then they were told they couldn't do as much snowmaking as they thought because of the drought conditions. They couldn't draw the water level too low.

**Ellie Rofe | 04:27**
Wow.

**Ray | 04:27**
And that was so the, you know, all of this sort of, you know, back and forth. It'd originally had the ambition of wanting to open this past weekend, and fortunately weather has been good to us.
You know that funeral that I went to on Tuesday? I actually spent five and a half hours driving home. It was ordinarily a three-hour trip, as there had been all this snow falling and there were bad conditions and cars were strewn all over the road.

**Ellie Rofe | 04:47**
One.

**Ray | 04:54**
It was, you know, interesting.
And the. So they've got enough weather that to come down to be able to open this weekend, which they're very glad for. But otherwise we're sort of throttled on being too aggressive about it because even though they've got the equipment now because the owners made a capital improvements water still water.

**Ellie Rofe | 05:13**
Yeah. Wow.

**Ray | 05:16**
Sorry, that was a lot more about detail about how, you know.

**Ellie Rofe | 05:21**
I find all these things fascinating. Any chance to get a little bit and learn and cram into the old brain is fine.

**Ray | 05:28**
I actually have an uncle who's a financier. He worked in fixed income, debt derivatives, all that stuff. He looked into joining a consortium to buy this place out of his bankruptcy. He looked into it.
He has a new expression, which actually I have now, which he gave me a year ago and I've since used a number of times, which is that he now talks about a business. A negative thing to say about a business is to say that it's a ski resort because it has all of these terrible economics and no economies of scale and no possibilities for economies of scale.
It's geographically limited. You have a bunch of little businesses, parking businesses, a couple of concessions, and a couple of whatever. There's no opportunity to get your arms around it.

**Ellie Rofe | 06:15**
No?

**Ray | 06:15**
There are companies even that buy up a bunch of ski mountains, and then they keep on training them around because there's no leverage in it.

**Ellie Rofe | 06:24**
Yeah, I was going to say there's no bridge at all, right? You're just. You're just. Behold. Into the mountain. The weather, the capital expense, the.
Yeah, there's like.

**Ray | 06:35**
And these tiny little businesses are geographically distributed. I mean, what the there's no sort of Walmart esque opportunity to it.

**Ellie Rofe | 06:43**
No.

**Ray | 06:44**
I thought it was really interesting. I actually have found that there are a number of tech businesses that are ski resorts.

**Ellie Rofe | 06:52**
Okay, yeah, I can imagine.

**Ray | 06:54**
I like that's something I look for.

**Ellie Rofe | 06:55**
[Laughter] Yeah, well, it's seasonal as well, right? So that's even worse because you're like, "We have to make everything in this time."

**Ray | 07:06**
A lot of it, yeah. There's a little bit of like, "What can you do to make it more if not year-round at least seasonal?" They support mountain biking in the summer.
But let's not be confused. That is not nearly as much money. For a small mountain like this, there's a problem of basically the economy, the local economy has declined. This used to be the local mountain for a working town, but a mill in the working town has been gone for decades. Now, what we have is basically a bedroom resort town.
There's a little bit of pushback of how much we're looking to get those people from Massachusetts, Boston, the nearest major city, or Quebec in Canada to come here and have this be a place where...
There's that bush... No, this is for us. No, it's really not. I have to say, if I were owning this mountain, I would hike the prices and make it a premium experience for people coming from those cities because I can't see how otherwise you make any money at it.

**Ellie Rofe | 08:06**
Yeah, but I understand.

**Ray | 08:10**
And which is shown by the.

**Ellie Rofe | 08:13**
Yeah, I do understand. Long-term locals are very nervous about someone becoming a tourist town.

**Ray | 08:21**
Yeah, and I totally get that. I just don't see the alternative except for the mountain continuing to turn over in bankruptcy and them getting to toil and continuing in poverty in the meantime. It's a good deal for me, right? It keeps the cost of living down here and the
mountain continues to exist and doesn't have lines and it's beautiful and I love it. So I get to exploit it, but it's one of those things where I'd much rather be a customer than an owner.

**Ellie Rofe | 08:50**
Yes, yeah, absolutely fascinating.

**Ray | 08:55**
It's an interesting business, but not the one we're here to talk about today.

**Ellie Rofe | 08:55**
[Laughter] No, that's all... [Laughter] No, which was a shame, but I think fine, we learn from it.

**Ray | 09:03**
So the. The. The thing didn't happen.

**Ellie Rofe | 09:14**
So what I'm thinking is I'm going to talk to Natasha, if not later today, then on Monday.
We weren't going to do it live today, but she's a bit late with her slides. Then I ended up in my rabbit holes on the app because I didn't have the deadline, and I ended up making it the "everything app," which was wrong.
It's not even an app really, but tools. But I'm thinking what we should do is just say we didn't get takers. We want to do some market research. Which of these sessions would you be interested in attending for free?
We should do it for free and just see what people come up with and what they get. Get some engagement, hopefully, get some people coming along, get some response. You say the dynamic that happens on a call and the understanding you get and the recommendations, hopefully, and things like that.
It's just making something happen from it rather than, I think, is the way I'm viewing it.

**Ray | 10:14**
One.

**Ellie Rofe | 10:17**
I think Natasha seems to be on board with that as well. It's just she's she's been very busy as you know, you would be.
So yeah, it didn't happen, but we learned a lot. And there's an awful lot of bits in place now that we had to ramp up to get in place that are now in place and other things kind of coming into place so that the next sort of stage, it can be more experimental without being such a huge lift.
So that's good.

**Ray | 10:49**
Okay, that's great. Okay, so, like, you have, I mean, you're making lemonade right from it, so I think that's a that seems like about the right way to be thinking about it. And I mean, obviously, I've read the report, so we don't sort of need to do all the walk through on.
But I appreciate a little bit of update on that on the workshop.

**Ellie Rofe | 11:14**
Yeah.

**Ray | 11:16**
What can we do this week to help next week go better?

**Ellie Rofe | 11:20**
I think one of the things that would be useful just to kick around is when I worked in companies for people doing stuff. I was the work that was high quality, but it was fast.
I don't know whether it's just a shift that's happened in me moving to France, the pandemic, the higher exposure level of this, or the higher thinking level involved in what I'm doing, I don't know, but now I feel like just go slow.

**Ray | 11:59**
Zero.

**Ellie Rofe | 12:02**
Can you hear me?

**Ray | 12:05**
There we go. Could you just repeat what you just said? I think we got a little bit of a blip.

**Ellie Rofe | 12:09**
Yes, we did.
Yeah, I feel like the... Used to be very fast as well as good quality. It's gone slower, and I don't know whether it's a shift that's happened over time to deal with the pandemic. It's just me getting old. After the COVID, my brain slowed down.
I know that much. At or to do with moving to France because I shifted from sprinting everywhere like I did in London to suddenly going slow. Are you struggling?

**Ray | 12:41**
I don't know. I'm trying off a bunch of things I've got in here, so we'll see.

**Ellie Rofe | 12:43**
Okay, I'm getting the red bars, but... I don't know.

**Ray | 12:55**
One moment. I'm a bunch of stuff off.

**Ellie Rofe | 13:04**
But you have frozen... How interesting.

**Ray | 13:20**
Do you know better?

**Ellie Rofe | 13:21**
Yes. Now my connection's unstable. I haven't got anything open on here. Hang on, let me shut down that and that. No, I shouldn't shut down Zoom, that would be a draft.
Check that off.

**Ray | 13:46**
I'm not as shut down as I can be.

**Ellie Rofe | 13:49**
Yeah, same. Hang on, this one little Google Chrome. Okay.

**Ray | 13:59**
The piles of our over-the-top communications.

**Ellie Rofe | 14:03**
[Laughter] Exactly, right, can you hear me?

**Ray | 14:07**
Yeah. We'll see what we can do.

**Ellie Rofe | 14:09**
Okay, cool, yes, basically I feel like I have slowed down a lot, and sometimes that seems to be definitely an element of perfectionism. I do wonder a little whether there is an illusion of speed in AI, whether there is a sense sometimes of moving forwards but actually not moving forwards. I don't know.
I just wondered if you have any ideas, tips, or whatever to progress things faster and close things off quicker because it... I feel like things are dragging.

**Ray | 14:54**
I'm sorry, could you just repeat the last sentence? I got a little bit of a blip right there through the end.

**Ellie Rofe | 14:59**
Okay. I wondered if you had any tips or suggestions on how to progress things faster and close things off faster and how you move through things.

**Ray | 15:15**
Too long in your, in the report.

**Ellie Rofe | 15:20**
Sorry. You've blitzed there?

**Ray | 15:23**
All right, let's try both turning off our video, and we'll see if that works better.

**Ellie Rofe | 15:25**
Y yeah.

**Ray | 15:26**
Less tax on the network.
Okay, sorry. So the question is, how to... Just tidy things off faster. Well, can I ask Al?
Give me one moment. I'm going to try switching networks. Recording in progress.

**Ellie Rofe | 18:03**
Is that any better?

**Ray | 18:05**
How do I sound any better to Ellie?

**Ellie Rofe | 18:08**
I think so. You seem to be consistently there, although there's a bit of weirdness going on the line, but it seems cool.

**Ray | 18:16**
Yeah, one moment.
I'm just dr I be a P nelly.

**Ellie Rofe | 18:29**
Okay, it's so amazing. Echo.

**Ray | 18:33**
Must be one second.

**Ellie Rofe | 18:34**
Okay.

**Ray | 18:44**
They most recording stopped. All right, how do I sound out to you, Ellie?

**Ellie Rofe | 18:54**
Better. Yes, may you?

**Ray | 18:57**
Okay, well, we'll see. I just wished my phone on the theory that maybe my computer was sort of the source of the problem and that means I'll lose recording.
But, you know, whatever. We made progress.

**Ellie Rofe | 19:06**
Yes.

**Ray | 19:08**
So the question I meant to be asking you was about time allocation, right? And how you presently are allocating your time when you talk about these initiatives and how you think about tying them off.
How do you think about the planning or the way you associate time for that?

**Ellie Rofe | 19:24**
It's a very good question. I think I've probably gone from overplanning things to underplanning things.
So I will try and break down a list of what I need to do, but not really allocate time or think about it in those terms.

**Ray | 19:46**
Yeah, the thing I use... I mean, the framework I use a lot and talk about in Sea Change is the idea of the one, two, and this is actually a management technique I use in companies I've been running over the course of the last fifteen years since I first came up with it.

**Ellie Rofe | 19:47**
And I wonder whether. I wonder whether. Partly as well, with my sort of occasional time blindness.
Anyway, I wonder whether it's just worth setting a clock, like alarms or something.

**Ray | 20:23**
Which is the idea of giving... I mean, setting the clock for an hour, right? To work on something.
Then basically, if it's not producing in that hour, you put it down. If it is producing, you give yourself one more hour. The idea is that at the end of that second hour, you know the mission is to basically go get validation, right? This is still the right thing to be working on.
What I found is that a lot of things that we think of as being a day... The clarity we have about them shows up in the first couple of hours. No, this isn't true for everything, but it's true really for a lot of things, a lot that it's worth... It has become shorthand among people. I manage to talk about giving something a one to... Then it has the discipline of... I'm giving you a one, two, and I'll see you in a couple of hours.

**Ellie Rofe | 21:20**
I think it's a really. It is a really good idea because it's enough time to get into something.

**Ray | 21:27**
Yeah.

**Ellie Rofe | 21:29**
Like you say, if there's progress in the first hour, it's enough time to continue through with the. With the progress but not enough time to get bogged down and then go into the sort of the. The doom loop of trying to fix things or trying to force stuff.

**Ray | 21:44**
Right. The idea is in the first hour, it's about abandonment. You want... It's giving you permission to say it's not working. I'm putting it down, right?
Then go back. It's not something you have to give it the old college try for the hour. It really is more like in that first hour, it's okay to put it down if it's not producing. Usually, I have a pretty good idea of what's producing versus not. Things aren't that mysterious.

**Ellie Rofe | 22:09**
Yeah.

**Ray | 22:10**
But the other half of it is a discipline of stopping even when things are going well, right? Because the there are sort of two ways we get into the doomopop. One is this isn't working. This isn't working.
And the other is it's kind of working. And the long, slow slog that we start to get, you know, pot committed into is what I have found to be where we can really lose a lot of time and that often happens like in the second or third round.

**Ellie Rofe | 22:35**
Yeah.

**Ray | 22:44**
So after the second hour, when we're in this mode, my thing is, "Okay, well, what's the next one too?" Because it puts you in a position of what's the discovery that happens after that?
Because usually, it's like you've gotten to a certain point, and you have some degree of insight, and now it's like... But if I could do anything next, what's the next best hour I could spend and then be on there? Of course, there's a tax in the middle here, right?
So it does prevent getting into a day-long flow, but... I do find that it really turns learning much faster because there are many days where like, maybe one hour was a good one.
And this now sort of gets you set up to be doing those, you know, four of them in an eight hour day right by if that's for four two hour chunks.

**Ellie Rofe | 23:33**
Yeah.

**Ray | 23:34**
And when we are, you know, and I have found, in general, the days where I'm keeping that discipline are better days in terms of getting more done and learning more and producing more than the days where I'm like, I'm just, you know, in the flow for the whole day.

**Ellie Rofe | 23:43**
M.
Yeah, I can as you talk about it, I can see there's cause there's a third trap for me in particular, which is the excitement trap.

**Ray | 23:56**
There are occasionally things where it's valuable.
But those are more the breach than the main.

**Ellie Rofe | 24:11**
Which is kind of what happened on the thing.
You know, I played with the idea in Google AI Studio because obviously, Gemini 3 came out. And then suddenly the UX is dancing and you're like. And I just sort this out and I'll just sort this put out.

**Ray | 24:29**
Hey.

**Ellie Rofe | 24:30**
And there's all that excitement. And then because it's Destructive. Because it's not grapping stuff fine, et cetera, because it's just like, suddenly the machine starts, like, causing problems.

**Ray | 24:36**
Hey.

**Ellie Rofe | 24:43**
That's probably after hour three, and probably actually in our two to three, and then I'm hooked. I'm starting to like...
But no, because I was so close, and I'll just do this, and I'll just do this. Hang on. No, this isn't right. I need to rethink this because the report and analysis of an existing death is different to a report.
Suddenly, I'm in. I'm in a complete and utter... It's like a playground, but not. So that's one of the real dangers. I think that what's nice about this is it feeds into a certain element in me, which is that I have a competitive side. I like that kind of constraint.
So instead of being like, "I'll just get these things done today and then meandering through them," it's like, "What can I get through? What can I see is happening in the next hour?" It feels more expansive.
I know it's permission to put it aside. I know it's not saying this is what I'm going to do, but it's... There's still a moment by the time that final whistle blows where I've got to... I set off three research reports on ChatGPT, and I've messed around here, and I've done this over here, and I'm kicking three balls along because I'm doing different things across the thing.
I haven't reflected on any of those things. It's forward motion, but it's not forward motion that is as productive as it could be. It's not for motion. That's as interesting or as reflective as it could be.

**Ray | 26:30**
Yeah, the... There are certain types of forward motion that don't call for that, right? Because they're like deeper execution, although I find more of those you want to get off your plate, right? Things that respond well to one or two tend to correlate with things that are growing and the...

**Ellie Rofe | 26:46**
Yeah.

**Ray | 26:48**
And yeah, so I think we've got a you know, maybe a tool that can be, you know, helpful for you in terms of doing that and going forward. The way I do a one too, is, I will actually call out to my Alexa and say, set timer for an hour.

**Ellie Rofe | 27:07**
YP.

**Ray | 27:09**
And that puts me in a position to, you know, be reminded about it. I've learned the virtue of using totally to call out, not having to be something I have to type on the screen, but something I'm just doing orally keeps it out of the band. I first learned that in terms of managing screen time activities for my children, but then, hey, that really works.
I use it for my own discipline as well. So I find that as a mechanic helps me maintain that discipline when I'm doing this stuff. Well, yeah. Especially if I'm going to have a big open day.
It's way... I'm able to turn it much faster.

**Ellie Rofe | 27:49**
I like that a lot. And I yeah, I think it gets. A nice shape. Like you say, it adds more rhythm to a day. And that, I think, can be especially useful. I have.
If I have calls booked in the afternoon. Sometimes I sort of have a. I'm not as bad as I used to be. I didn't realize this was happening when it first started happening to me. But the concept of weight mode, I don't know if you've heard of that. Where you're like, yeah, when you are they talk about it a lot on sort of ADHD and autism forums.
I think it can be slightly fantasized if you're not careful. But the. The idea that when there is. An appointment later in the afternoon. You sort of end up in this paralysis where you're like. And it's ridiculous, but it is.
It is a syndrome that happens across the board where that's happening later, and for some reason that puts you in this weird paralysis. And I'm not as bad as I have been in the past because I'm. I'm aware of it happening, but actually this is a really nice momentum. It doesn't matter what's happening later, it's what has what's happening in the next hour, not what's happening on my do list, but what's happening in the next hour.
It's. It's a way of being present with stuff rather than trying to anticipate, if that makes sense.

**Ray | 29:20**
It makes a lot of sense to me. I mean, there are people who make plans for the week. There are people who make plans for the day. I do find that I do best. Like, what am I just doing right in front of me right now?
And that doesn't mean that there's not an absolute there there's no planning, but like the my universe is focused on this thing in front of me, and that is. And? And if I can stay focused on that, that's going to be what creates the maximum value.

**Ellie Rofe | 29:47**
Yeah, okay, that's very helpful. Thank you. I think I had. I have realized that I have. I have a tendency to try and make everything the everything thing. So that's one of the things I'm trying not to do. [Laughter] So, like, when I have.
It's really interesting, even when I. Even when I write stuff, there's always and this but this is like it this is relevant, and that sort of, connective everything is connected, everything everywhere all at once, type of, approach or not a tendency, it's not a conscious thing, it's a tendency.
And I think that's something I'm trying to get more conscious of as well. So with this thing, you know, I'm trying to just create something that I can wax and pitch extra and start talking about them on LinkedIn, and suddenly I'm like.
But while I'm doing this because it's in Gemini and it's working fast and it all feels fluid and exciting, et cetera.

**Ray | 31:02**
Recording in progress. Go ahead.

**Ellie Rofe | 31:05**
Yeah. Then I'm suddenly trying to, you know, add loads of bits and pieces to it, because this can just have the things, the tools I need in it and stuff like that.
And it just as I say, it just becomes bigger and bigger. But there should be some insights and there should be some benchmarking and blah. And. And I think just getting like, you know, the skateboard or whatever, it's like just get it out there.
And so I resolved to just do five things, like five like do one round of checking the prompts with five decks in analysis and then start talking about them. Get feedback. Hi. Try and get some engagement and interest in it and then move to the next stage or the next stage and iterate with people rather than iterating just in my own brain in circles.
So there's... I think there are ways I'm becoming more aware. But actually, I think the one-two is a really nice model for me to be actually moving forward faster when I am on my own with stuff.

**Ray | 32:21**
Cool. Yeah, I think one of the most important things about the one to use as a management tool is that it causes the person to go talk to somebody afterward, right?

**Ellie Rofe | 32:31**
Yes.

**Ray | 32:32**
That the either at the end. Either in the one or at the end of the two.
You know, it's say you're not trusting the inns of your brain. You're talking to someone else, and that is what's leading to it. And like to your point, like that's that person is in the market. That's great.

**Ellie Rofe | 32:46**
Yeah, okay, absolutely.

**Ray | 32:47**
I find that kind of accountability really helps, because it means that whatever you're creating will need to be shared with somebody else, right? It means you're shipping something. As opposed to just, you know, contributing to the, you know, hazy idea in your head.
Well, yeah, you can go.

**Ellie Rofe | 33:13**
Another question I had is I heard just before our call that I heard from Madison Maxy, the Lumia, who still seems to be struggling to get any bites, and she sent me their new deck.

**Ray | 33:23**
M. Yes.

**Ellie Rofe | 33:33**
It's very beautiful, but it's completely scattered and terrible. There's this... I don't know if this is a mad urge, given everything I've been through with other people, but there's this urging me to say, "Give me a small amount upfront and defer the payment because I think she can raise money with this business."
Am I just falling into a trap of wanting to work on something between now and Christmas and push through on a new project and... And not, you know, basically doing the same thing again?

**Ray | 34:15**
Well, is it a bad thing?

**Ellie Rofe | 34:20**
I don't know.
I mean, I the thing is, she is I think the difference, I think, is that she actually has a business that is revenue. It's not pre revenue, it's there. She has technology, she has developed something that is in the market.
And this is the next stage of development for the business as a whole. In a new market as actually an awful lot of the same market and new markets. And I look at it and I think she's very fired up. She is. She's getting meetings.
It's just, I look, I mean, the story just looks fractured and fragmented and not particularly interesting in the way it's being told and not particularly, like, commercially compelling. But I think the commercial compelling stuff is there in the business.
So I just feel like maybe she is someone who can get funded. She is someone who is actually out there with revenue. And she'd be a really the other thing I keep thinking is it's it is there's so much biotech when I've been mapping.
I've been trying to sort of map the hard tech thing because I realized the more I looked at it. Biotech has a really structured ecosystem because of the I guess because of the history behind it and especially pharma and drug development and stuff, because of the absolute churn out of academia and the amount of sort of translational things that go on, because there is just that pipeline in pharma. There's really obvious exits for all these things or most of them not all.
And some of the other areas don't have that same massive amount of infrastructure and cottage industries set up around it and stuff when it does a bit but not as much. Robotics and automation really doesn't seem to. Defense sort of does, but it's like defense doesn't have the same kind of exits because you're generally selling to a state rather than end users. Space similarly.
So each ecosystem is slightly different, and I just thought biotech is lovely, but it's very crowded, and helping someone raise in another vertical might be a way to start establishing that hard tech thing on top of the work I'm doing with analyzing decks and that kind of thing.
So I don't know. What do you think of my rambling? Am I convincing myself? Or am I being strategic?

**Ray | 37:15**
Well, I think you... The hard tech thing was you having a thesis that there was a market beyond bio that you could be of service in.

**Ellie Rofe | 37:21**
Yes.

**Ray | 37:23**
The material science is part of that. So that seems to be along those lines.
I think you're finding that to be attractive, what you're doing was restating your hard tech thesis, and it seems about right to me. It seems reasonable. It seems like a reasonable hypothesis to test, right?

**Ellie Rofe | 37:41**
Yes.

**Ray | 37:42**
And the and this becomes an avenue to test it. It's an avenue to test it when it's stopped, you're not you know, it falls in the category of having a significant study aspect to it, right, because you're learning more.

**Ellie Rofe | 37:55**
Y.

**Ray | 37:56**
But it's not like you're. It's. It's competing with, you know, significant income sources at the moment, right? So that makes it cheap to do. I was actually just having. You know, it's funny, I was having this conversation with Demetrius a little bit earlier today, and on both these themes were popping up. The first one of, you know, the you know, do more study when you don't have as much, you know, to ship because that's building equity in your company.

**Ellie Rofe | 38:24**
Yeah. H.

**Ray | 38:25**
And the other was about this pace thing that we were talking about, you know, previously. And you have an opportunity to learn more quickly about this hypothesis and potentially with this person.

**Ellie Rofe | 38:37**
Yeah.

**Ray | 38:38**
But the but so that becomes like the study aspect of it.
But the other thing was and this relates to the cell aspect of it, is when you and I were talking, I don't know, maybe six months ago, we had a discussion about, you know, you want to position yourself with winners, right?

**Ellie Rofe | 38:57**
Yeah.

**Ray | 38:59**
And this is one of the troublesome things about a Pleotech is that they have, you know, this it might be interesting work, but you're concerned that it's not going anywhere. And that's going to be you know.

**Ellie Rofe | 39:09**
Yes.

**Ray | 39:10**
So you just get to be associated with a loser, right? Although it does seem like that's at least turned into one referral directly out of that. That's cool.

**Ellie Rofe | 39:18**
Yeah, that's great.

**Ray | 39:21**
But. But like, if you think this person is a winner, then doing some work to associate with her seems like there's a real positive thing.

**Ellie Rofe | 39:24**
M yeah.

**Ray | 39:30**
The fact that the initiative that you're working on might be a winner or a loser is actually less important than whether the client is a winner or a loser, because you get to be associated with the client.

**Ellie Rofe | 39:41**
Yeah, that's a really interesting point. Really interesting.

**Ray | 39:49**
And if the client, like the initiative doesn't work, but the client likes you. And the client goes on to be successful. That's a. That's a. That's a. There's a market asset for you is that positive relationship and the whereas a client that yeah, you did an awesome piece of work and they still go on to be a best case. Even if, for example, he's successful with the raise but then falls on his face right then, that's not going to... That probably doesn't work nearly as well for you.

**Ellie Rofe | 40:21**
And I have that exact comparison now.

**Ray | 40:21**
So...

**Ellie Rofe | 40:25**
You say I worked with Oxyon and I made good money out of Oxular, but the CEO was a basket K and the CSO, actually, they.
I mean, they were like warring children a lot of the time anyway, but, you know, this incredibly promising thing raised 37 million, and about 18 months later was having to be sold off at a fire sale.
And so I can talk about raising that money with them. But when people hear if people who know it when they hear Oxyer, they're like, yeah. Because, you know, the CEO had a bit of a reputation. And so it doesn't reflect glory if II mean, sometimes they're like, wow, you must be patient.
But you know, it's like, yeah.

**Ray | 41:17**
Three.

**Ellie Rofe | 41:18**
So you're right. Whereas when you talk about... When I talk about, imago, it was like, "Yeah. Sold to 1.2 billion to merge." Nice.

**Ray | 41:30**
Right, if you are helping make people make good investment decisions, yeah, just always by the way... It seems like there's an opportunity for you to do well on that.

**Ellie Rofe | 41:33**
Yeah.

**Ray | 41:41**
And like that's that would be the kind of calculus that I would use for saying this seems like a reasonable way for you to be, you know, building up equity.

**Ellie Rofe | 41:55**
M.

**Ray | 41:56**
And, you know, like you say, having the potential for it to turn into something, you know, to turn into income.

**Ellie Rofe | 42:05**
Yeah.

**Ray | 42:05**
If the raise can be successful. Now, the, you know, if you think she's a winner and basically and everything you've been saying about her so far makes me think that's what you think is true about her.
And if you think that's true, then that's raw material. And like if the, you know, the fact that the deck is pretty but vapid, which I think might be the summary of what you're scribbing, is you know, great.

**Ellie Rofe | 42:32**
Yes.

**Ray | 42:36**
You get to focus on the part that is high value for you to be contributing anyway.
I know you've got design sense, but I think the high-dollar value part is going to be connecting, right? Her business. It's really investor relations, right? It's connecting her business with what investors need to understand in order for them to make an informed decision.

**Ellie Rofe | 42:56**
Yeah, absolutely.

**Ray | 42:59**
Your belief is that the more they make an informed decision, the more they understand her business and have clarity on it, the more attractive it will be as an investment to them.

**Ellie Rofe | 43:11**
Informed and persuasive, you know that they're being two parts of the same thing, really?

**Ray | 43:14**
Yes.

**Ellie Rofe | 43:18**
Yes, and you're completely right about design. I'm not a designer, I have design sense, but it's a part I would love to orchestrate more than execute as time goes on.
So, looking at this deck, it's like actually one of the things that you've just realized you've just made me realize was subliminal. There is unlike a tech pillar. It's not like there's a huge design lift for me to have to do here. They've made it look attractive there. There could be ways in which the visual communication is better, but the underlying design aesthetic and concept behind it is already there.
So that's a huge tranche of work that isn't there for me in this if I saved. I mean, assuming she wants to and she's got enough time. But that does make a big difference as well. You're right. And you've just crystallized something I've sort of been thinking about, which is that long term, that is definitely something I want to I do want to orchestrate it because design, we understand what pitchdkes need to do all the time.
So I would like to orchestrate that part of it rather than execute it.

**Ray | 44:28**
Yeah, and now you've got your thing where you get to say nice things about the person who she hired, right?

**Ellie Rofe | 44:33**
Yeah, exactly.

**Ray | 44:34**
This is really this is a very nice looking deck. Like did all the design things you'd want the trick is the story, right?
And the you know and it's utility as a tool for the investor to clearly understand, you know, the awesome opportunity that you represent. And then. And that's great that now you're being complimentary. You're not even reviewing or dis the other person's work. You're just saying, that was super nice. Here's the part we need to do next.

**Ellie Rofe | 45:07**
I mean, I look at that work and I think that's someone I would have designed stuff for me. I suspect that's not where they want to position themselves, but who knows?
Yeah, okay, I'll think about how to frame it. Then the other question was the conversation with Lauren, it was really interesting. Actually, I... [Laughter] I think I learned we were about four minutes from the end of the call. Five minutes maybe from the end of the call. She says, "What's your pricing?"
We've just been talking about early stage and how difficult it is for them to pay on anything. I've been talking about how I'm trying to get tools that help me with clients one-on-one but then may work for early stage.
I did decline into a tiny amount of waffle, like thirty seconds of waffle. And I saw her eyes keep flicking either to the clock or to notifications on her screen. I was like, "Okay." She moved past it really quickly.
I was like, "God, have I completely destroyed that thing?" Because it was a fruitful and definitely engaging, good connection conversation before then. I dumped it into AI and they're like, "No, she's just a VC. They guard their time like smug and so..."
But you just need to have a crisper way of presenting stuff if someone asks you that, which was really interesting, but I suppose I wanted to ask you if... So she's raising her first fund. She wants to work with biotech.
Within that, I think she's still a little bit AP-inclined in terms of women's tech health tech. She had a really interesting angle. We were talking about the lack of funding, and she said, "You can get money out of the Department of Defense now because I've been saying about how I'd looked at the FBIR and where funding was going."
She said, "You can get money out of the Department of Defense if you frame it rightly because fertility is a really important thing for them." I was like, "My God, that's fascinating."

**Ray | 47:31**
God.

**Ellie Rofe | 47:36**
Slightly Handmaid's Tale, but just an edge.
So I'm thinking she really wanted to learn more about it. I gave her my standard pricing stuff and how I'm developing this tool, and if she's got founders that she can push my way, then I'd treat them as a beta tester for this tool for that very early stage.
But what I guess I'm struggling to see at this point is... Then she said once she's funded people, then she wants to make the most of non- dilutive capital and they need to help with their story.
She thinks I can help with that. And obviously then raising a Series A or a seed if she's done preced. But in the immediate term, are there opportunities here that I'm missing? Beyond... Let me work with some founders, hone these tools, and see if there's a way I can be part of your platform. Basically, once you're re-raised your fund.

**Ray | 48:44**
Yeah, I've heard this platform pitch before. I've never really seen it go anywhere. The and so, I mean, I would, you know, pay attention to what she's up to, but it sounds like she's full of horseshed. The I think the interesting angle here is you helping her raise from the LPS.

**Ellie Rofe | 49:04**
Okay. Interesting.

**Ray | 49:08**
Anything more than that is just sort of whatever at some point in the future if she does deal flow and like she there there's no clarity as to this plan, right? She doesn't have a playbook for it.
And like the idea that she's going to put them together with a bunch of these vendors and how's it how does it make money? You know, it feels very it feels hazy. And when things feel hazy, they become exponentially less substantial, right?
So what is? So what's not easy in this relationship and in this situation is her drive to raise from LPS, right? From either H& WS institutions. Whatever her target is, right?

**Ellie Rofe | 49:52**
Yeah.

**Ray | 49:53**
And, you know, her needing to explain what her plan is.
And, you know, so I would think that if you're talking to a VC, you know, the two kinds of conversations you're having are first, you know, getting recommended to. Get getting recommended to either port cos or would be port cos for, you know, helping.

**Ellie Rofe | 50:15**
Yeah.

**Ray | 50:18**
So she can be making better decisions with them, right?

**Ellie Rofe | 50:19**
Y.

**Ray | 50:21**
Or for their own raise. Because we need to remember that all VCs are money managers, and it's easy to think of them as being on the other side of the table, but they are then on the same side table relative to their...

**Ellie Rofe | 50:27**
Yeah.

**Ray | 50:35**
To their limited partners and especially for these smaller funds, they are scrabbling right to these family offices to these, you know, high net worths to you know, they're trying to piece together a million here, a million there.

**Ellie Rofe | 50:39**
Yeah.

**Ray | 50:53**
That can be very tough, like raising money from... I remember having a conversation with somebody who told me that it was the job of angels to put in the highest risk money. Are you freaking insane?
The family offices... H&W are people putting in their own money, right? This is very different, actually. Once you get to a higher level of money management, you're talking about pension funds, which is still... Once again, back to dealing with other people's money, but when they're putting in their own money, the risks that you need to get them over are very different.

**Ellie Rofe | 51:22**
Yeah.
It's institutional versus personal.

**Ray | 51:35**
Yes, although institutional some institutional includes family offices, which looks a little weird, right? In terms of like the closeness because you if family office tends to have a professional money manager with one client and the.

**Ellie Rofe | 51:48**
Yes.

**Ray | 51:50**
Anyway, I'm obviously... There's a whole spectrum for how that side of the house works. But the reason I'm bringing it up is when you're talking to BCS recognizing their money managers or money women in this case and looking at both sides of that relationship.

**Ellie Rofe | 52:02**
One. Yes. I hadn't thought at all about whether she needs help in conveying her pitch.

**Ray | 52:14**
Is she successfully fundraising right now? Because if she is great... I think there's a certain thing here when she takes the conversation with you. Your first thing is what is the pitch that she's closest to.
That's going to be the reason that she's thinking about you, right? Whenever you're talking to ABC, if you think about both of those things, you're in a stronger position, right? Are they trying to figure out how to raise their next round or fund? Rather, in their case, they called a fund. Or is it about their deal flow?
Right? Not only can't they make good decisions on that front.

**Ellie Rofe | 52:56**
Yeah, it's a really good question. I'm now checking whether she did or didn't raise it. She says no.

**Ray | 53:07**
Do you think it's her pocketbook?

**Ellie Rofe | 53:10**
No. I'm wondering whether she said, "I have raised," or "No, I am raising." She is raising as a fund. [Laughter] Yeah.

**Ray | 53:20**
Everyone's always raising. That's, whether she's closed any tranches of it or whatever. That's a whole different deal. Like my friend Anthony Atlas, who I had, you know, sort of sent you the email about to be a follow player like whatever.

**Ellie Rofe | 53:38**
Yes.

**Ray | 53:40**
But the but he similarly is quote unquote raising.

**Ellie Rofe | 53:45**
Yeah, interesting. Okay. I mean, that would be a very interesting place to be in helping them raise that money.

**Ray | 53:59**
Yeah, I think and there's much more money in it, you know, that's a those are bigger dollar or bigger euro mats.

**Ellie Rofe | 54:05**
He again. 20 founders in one.

**Ray | 54:14**
Yeah, well, there's a certain economy of just... If you're working in financial products, just work in finance.
Anyway, it's a thing you might just want to pay attention to as you're talking to the VCs that you have opportunities in both directions. You might think of their referral opportunities, but they're potential clients and hard tech for the VC trying to pitch their hard tech fund to the LP, and the likelihood that the LP is versed at all...

**Ellie Rofe | 54:42**
Yes.

**Ray | 54:47**
The likelihood that a VC is versed in hard tech is actually pretty high, right? Because that's what they're doing. They're specialists. But the likelihood that a VC that their LP is well versed is relatively low. There's a thing I remember talking to one VC about one thing they look for in the people they fund is whether they could communicate with their LPS because one thing they will do, like all the VCs do, is they will gather together their portfolio codes for their annual conference, retreat, or whatever.
Yeah. The purpose of that is not to help the portfolio codes. The purpose of that is to turn out the portfolio codes so that they can be seen by the LPS.

**Ellie Rofe | 55:28**
Yeah.

**Ray | 55:31**
Hey, look, we're managing your money. Well, please don't sue us and try to get to dry powder back.

**Ellie Rofe | 55:36**
A beauty. Prade yeah.

**Ray | 55:40**
And the and like they will look for people who they think will do well in those circumstances because that that's not just a will this investment make money, but will this investment help me raise more money?
So I can have bigger assets under management. Bla blah. Right, because that's how their economics work.

**Ellie Rofe | 56:06**
I like the SLI of tech because with AR tech it's just bigger bets generally capital-intensive and longer-term.

**Ray | 56:13**
Yeahm.

**Ellie Rofe | 56:16**
So you have to be able to you have to be able to be compelling within a completely different framework. So we're going to chunk, you know, half a million at 30 different Saars outfits and hope two of them are unicorns.
Like, you know, whatever.

**Ray | 56:39**
Right, the capital test seems really... You raised two key points, right, which are the time and the quantity of capital.

**Ellie Rofe | 56:51**
Yeah.

**Ray | 56:51**
Then there's a third part which I think is reasonable for us to consider, which is risk that hard tech because it's harder to understand and because it depends on more things in play as opposed to SaaS, which remains very mutable all the way through, increases risk.

**Ellie Rofe | 56:56**
Ye.
Yes. Yeah.

**Ray | 57:09**
And when you think about, like, what are the three considerations of finance? They are time risk and stake.

**Ellie Rofe | 57:15**
Yeah. I mean, risk is massive, not just through the technology but through regulation like the macro environment. Obviously, macro affects SaaS, but it's easier for SaaS to pivot generally.

**Ray | 57:28**
Two.

**Ellie Rofe | 57:35**
Yeah, M.

**Ray | 57:36**
Right. So there's back-row risk, there's geopolitical risk, there's... As you point out, there's regulatory risk, and you know, the investor needs to show that they are good stewards, right in terms of... And can navigate those waters both and in picking better horses and being to help manage those horses through those rougher waters.
I've totally mixed up the metaphor now.

**Ellie Rofe | 58:07**
No, those fine horses don't like rougher waters. [Laughter] Yes, okay, that's right, I've just realized the time... Sorry, that's really helpful. I might just ping back and say, "Here's a summary of what I can do for funding."
By the way, do you need help refining your pitch?

**Ray | 58:28**
Well, actually, what I...

**Ellie Rofe | 58:34**
No, I've lost you now.

**Ray | 58:41**
And just ask I was proposing can you hear me now?

**Ellie Rofe | 58:42**
Sorry, I left you after... Well, actually, what I... Yeah, okay.

**Ray | 58:50**
Okay, yeah, just sorry about that one moment. Okay, the thing I was going to propose is that you might just ask her how her raise is going and what she's hearing back from the LPS, right? This gives you the advantage of one sounding like you're curious about what she's doing, which is a good place to be from a sales point of view.
Regardless of how the relationship goes, you will have data, and probably she will give you some quotes that you will probably be able to dine out on for talking to other investors in the coming months.

**Ellie Rofe | 59:24**
H Yeah yes.

**Ray | 59:31**
So I've always found that like the w what's the expression when you're looking for money, ask for advice, right? So like when I'm talking about what I think might be an interesting customer, my first move is to ask them about what they're up to.
And then that allows me to sort of, you know, dial in on what the opportunity might be.

**Ellie Rofe | 59:52**
Yeah, okay, perfect, I love it. This has been incredibly helpful.

**Ray | 01:00:01**
I'm so glad and super interesting to be hearing about that. I'm looking forward to learning more about both those, you know, sort of leads and what they turn into and actually, next week, maybe you'll be able to tell me about that, the corporate advisory, right?
Because you're having that meeting next week.

**Ellie Rofe | 01:00:17**
It might be the week after, but yes, thank you.

**Ray | 01:00:21**
Okay. Super cool. Give me a buzz if I can be helpful to you. Otherwise, I'll talk on Tuesday.

**Ellie Rofe | 01:00:26**
Have a lovely weekend. Cheers.

