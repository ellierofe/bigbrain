# Ellie and Ray Zoom - Nov, 07

# Transcript
**Ray | 00:07**
Hello, Ellie. I'm so sorry for the late notice and being late, even by that standard. It's apparently I'm just having a morning where I'm completely off the rails.

**Ellie Rofe | 00:15**
[Laughter] Off the rails. This man is out of control. We're going to have to call the police. [Laughter] It's fine.

**Ray | 00:24**
Yeah.

**Ellie Rofe | 00:24**
I don't mind at all. I just, sometimes it's actually quite nice when people are late because it just gives me a really focused session where I'm like, "I'm just trying to get this done."
I'll just try and get this done. So it's like a race against the clock.

**Ray | 00:37**
Goodness gracious. Yeah. So right before this, I had a pro office hours on schedule, and then I was late for straight up. Like, I just forgot that it was at seven, and like, I showed up at like, 07:40. It was like this not and like, this is not my first sort of weird error this week.
You know? I'm I think a little bit off kilter. The family member I went and saw earlier this week, and probably for the last time.

**Ellie Rofe | 01:08**
Yeah. Yeah, but you mentioned you weren't sleeping while waking up with that icy grip around your heart. You know, it's not ideal.

**Ray | 01:18**
Well, yeah, I like the... You see it, it's a sad moment. Yeah, and there's a little bit of... I suppose we all have a little bit of everything going on right now.

**Ellie Rofe | 01:30**
Yeah, very human. Are you getting away from news and noise and stuff and having peace as well?

**Ray | 01:38**
That would be a great thing if it were true, wouldn't it?

**Ellie Rofe | 01:39**
[Laughter] You dream scrolling? [Laughter] Yeah, yes.

**Ray | 01:46**
I. You know, I do doom-scroll too much. I've taught my sons the first rule of Twitter: never tweet, evere.

**Ellie Rofe | 01:59**
I mean, I think the first rule of Twitter and TikTok is just don't go on them because they're dangerous places to be.
But Twitter is unfortunately very useful still in many respects.

**Ray | 02:11**
There is that okay? So, you know, there, your report this week was actually a little bit full of self judgment.
But the if the sort of the. You know, it opens with two posts. Poor. Very poor. Come on, you know, not, but.

**Ellie Rofe | 02:32**
[Laughter] I really internalized like the school report writing.

**Ray | 02:42**
Okay, so, what can we do? How can we be focusing our time together to be able to help you have the best possible week?

**Ellie Rofe | 02:53**
It's a very good question. I've been thinking about it. I mean, one of the questions I have is about moving more into the US market and whether you see inroads there. I mean, it is slightly harder to network in that sense, but... Unfortunately, Europe is more and more of an economic basket case.
I've seen quite a few people that I go, "Yeah, that sounds familiar." American entrepreneurs tend to be a bit more dynamic, a bit more determined, and be moving a bit more. It feels like sometimes, when I'm networking and talking with people in biotech, it's this sleepy
vibe. I've worked with Americans a lot before, and I love it. Then I had that call with Maddy at Lumia, and she's just on it. I don't know, that's just one person, but it feels like I'm imagining that.
Yeah, that would be one question. Are there any recommendations? Anything to recommend? Am I just imagining that? Is that a false premise in the first place?

**Ray | 04:31**
Well, I'm sorry, what is the premise here? Just about America versus Europe? Or do you mean one industry versus another? What's the distinction?

**Ellie Rofe | 04:37**
I think America versus Europe in terms of dynamism, the money that's there at the moment, the funding, the stuff that's going on, it just feels like there's more of all of it in America.

**Ray | 04:49**
Two.

**Ellie Rofe | 04:50**
But maybe I'm wrong. I'm not saying America's in an amazing place, and who knows what happens if the bubble bursts, but it's just pretty. The UK in particular is a sinkhole at the moment of people just being miserable and pessimistic.
I mean, I know that's very much our vibe anyway, but for real-time rather than just an affectation, so... I don't know.

**Ray | 05:25**
You find when you step back far enough, you start seeing this. You start painting with very broad cultural brushes.
Any reasonable business is not going to be operating at that level, right? The vibe of the continent does not drive your business.

**Ellie Rofe | 05:44**
H.

**Ray | 05:46**
It's going to be about the much more specific set of people who you want to work with. In statistics, we learned that values aren't single numbers, right? They're ranged, right? They come in the form of a bell curve.
Your interest is not like what the center of the bell curve looks like, right? That's going to be a bunch of people who just have nine-to-five jobs. You're always looking at the edges of the curve.
The fact that the country in general is the continent in general is sleepier than, say, what you see out of America, right? That the sharp end doesn't seem as sharp. Okay, maybe that's generally true.
But then there are the people who are worth working with, right? Then because those represent more than enough for you to be able to do business with. But the way that you reach those people may not look like the way you reach them in America, right?
The same tech and the techniques you use and the ABC techniques you use, which work for finding an American entrepreneur, use ABC techniques and you find people who are kind of sleepy in Europe. That implies to me that there's a difference in technique required to go find the right edge of the bell curve. There are quite a few hucksters in the US, that are...
You know that. I mean, they pollute the pool in different know.

**Ellie Rofe | 07:15**
Yes, but I would argue possibly less so in hard tech, just because it finds you out quicker because you can't... Because of the massive capital intensity of it. So it just... It doesn't always, obviously.

**Ray | 07:33**
Look at work. Yeah.

**Ellie Rofe | 07:34**
Yeah, Elizabeth Holmes was still developing and doing R&D and ripping people off. So it's not like a one.

**Ray | 07:43**
Well, hard tech has its own requirements for, like, what, how people can be more successful. I would not confuse aptitude with affectation.
Right. There is a way that people speak in the UK that is where self-deprecation is far more acceptable in a business context as opposed to in America, where if you're not selling yourself, what are we doing
the way, it took me a while to understand. As an American, I didn't know how to operate in that business context because self-deprecating humor has been my stock in trade, and I like that. That doesn't work as well, right? Nobody wants to hear about your humility
unless you're the most humble person who's ever been. Nobody could possibly understand how humble you are.

**Ellie Rofe | 08:46**
Love it.

**Ray | 08:49**
The, but like, what can you step past the affectations, right, to figure out, okay, what's actually underneath because you can well, if you can then speak to them speak in the language these people want to be spoken in, right?
Be focused on where the big value is. I think we get somewhere if it's not just affectation, if it is actually, I don't know, this isn't really valuable. Whatever. Then they're depressed and they need a different kind of help.

**Ellie Rofe | 09:21**
This is kind of what I mean. I speak self-deprecation pretty fluently, and there's that. But there was... Look, that might just be my own version of the doom scroll Malay.
It might just be that I am missing signals elsewhere. I think what might be interesting is to delve more into... I haven't really looked out into... I've done a little bit of what VCS are talking about in terms of hard tech, frontier tech, deep tech, whatever.
But not so much since I was thinking about doing the investor survey. So, I might just do a bit more work on that and work out where people are and where they're talking about being and where I can find pockets of energy and determination that... Not that there isn't determination.
It's just when I say "sleepy," I mean, I think Americans are foundationally just in the nature of your culture and your business, even your founding a bit more entrepreneurially. So, when they're thinking about stuff, they are thinking about the business side. Whereas there's a little bit of prism going on where people are like, "Do I have to think about the business?"
I just wonder whether I'm doing too much of an educational uplift. I don't know. I think I need to step back from that conversation because I'm going into all sorts of random speculation there.
I think I need to step back and say, actually, no. What is far more interesting is to go away and think about this as a little research project. Take my priors to one side and go, right. What is the actual thing I need to understand here? Who am I looking for? Where do I find them?

**Ray | 11:20**
Right? I think that's probably right. There are lots of cultural things that can be talked about, but when we start saying, "Well, baby, it's based on your founding from being frontier people in the 17th century."
We're... Yeah, the conversation's got little for us. I might suggest that particularly since you're focusing on the question of hard tech, ask where the money is, who's doing the investing, and where the flows flows?

**Ellie Rofe | 11:47**
Yeah.

**Ray | 11:47**
And might further those. There are at least three major capitalist centers where investment is happening that you might give some thought to, which are the United States, Europe, and the Arabian Middle East.
Actually, I see the Arabian Middle East. I probably need to throw Israel into that, too, because there's a lot of money flowing in there.

**Ellie Rofe | 12:14**
Yeah.

**Ray | 12:15**
And bring up all three of those because when you think about that, it puts you in the middle instead of being across the pond from the center of gravity.
You're in the middle. There are these folks on either side that can be pretty useful to know and by looking at what is it that makes it hard tech? A lot of what makes it hard tech is capital right?

**Ellie Rofe | 12:35**
Yeah.

**Ray | 12:36**
That's a big difference between that and, say, most software stuff, right? It's the reason that a lot of what we talk about in AI... Okay, well, what are the big issues in AI? Certainly, there's a lot of software stuff, and that's how OpenAI is spending its money non-trivially on hiring super expensive people.
Okay, that makes hard problems, but not so much hard tech from a segmentation point of view. I think people who are building the next generation of chip fabs are hard tech.

**Ellie Rofe | 13:08**
Yeah.

**Ray | 13:08**
It's capital-intensive. BU gets to put that to work.
So, who are the investors who are putting those bigger checks right for purchasing the necessary hardware and accoutrements that go with these kinds of projects and what are they investing in and what are they looking for?
Then that helps move you along, like you're talking to... I forget the name of the celebrity, right? The one you had a conversation with. They had a good conversation from this past week.

**Ellie Rofe | 13:39**
The celebrity.

**Ray | 13:41**
Well, she's more... She's like a 30 under 30 type person, right? She was more of a woman.

**Ellie Rofe | 13:45**
Yes. Maddy.

**Ray | 13:48**
Yeah, and her thing is that you just... Like Cheli's working with materials work, right? Okay, what do you need to raise the money for?
Then, where's all that flow going? The observation there was that it was almost like an IR thing, right? More than working on the deck because she had somebody who was helping her with the deck.
She wasn't thinking of you as a deck technician, right? She's thinking of you as the font of wisdom.

**Ellie Rofe | 14:28**
Well, she wasn't initially thinking of me like that. And then she.

**Ray | 14:32**
Okay.

**Ellie Rofe | 14:35**
She just said she'd seen my website and thought it was interesting and asked how I worked.
Then, it was the best sales call I didn't get any work from ever, but, bless you, sowing seeds and all that. I started talking about how strategy first, blah. She asked, having looked at her deck, what I would consider or what I would ask her about.
I mentioned a few things. She started talking about how it's difficult because they've been around for a long time, but this is only their seed because they went to market with their former product, et cetera. I said, yes, you need to frame this as capital efficiency. You're not just running to get money. This is actually a genuine opportunity. You've got go-to-market experience, et cetera.
She started lighting up because I think what she realized was the person that she'd brought in to do her deck this time is not asking those questions or considering that reframing. They're talking in airy terms about narrative and story and vision.
So it went really well. I might have that consultancy side of it, which would be really interesting. But mostly, she was just seeing if I was worth it for her series. I think she spent quite a lot of time trying to find someone.

**Ray | 16:03**
Yeah, we'll see how that goes. Okay, but it just seems like you're... I appreciate that. I appreciate the clarity on that as you talked about the strategy and the review of the deck.
That's not the worst offer to have, too, because usually they have something.

**Ellie Rofe | 16:26**
As in review as in reviewing a deck.

**Ray | 16:32**
Yeah.

**Ellie Rofe | 16:34**
Yes, I've thought about that. It slightly undermines the USP angle I've been going with, which is that it's all about strategy, because when you look at a deck, you can't see what's missing.
But I.

**Ray | 16:46**
Well, no, you can't see what's missing. I mean, you do a deck plus you do some. You look at their deck, you do a little bit of homework. You're not able to start to see opportunitiesm.

**Ellie Rofe | 16:56**
Yes, sorry, you can't see what's unspoken in the deck in terms of things that are hidden beneath the surface of the company. So you have to make a certain amount of assumptions, which is why I always start with your slides. I'm putting them to one side because I just need to know about the company itself because that's what the deck is meant to represent.
But I could do that, and that's basically my entry point for my product for prospects or whatever that I've been trying to put on the website this week is just to get an analysis of your deck. As a little automated thing that will send them an understanding from the initial review of the deck and then say, if you want, get into touch with me.
If you want to discuss the findings and get deeper analysis and someone who can really understand your company, and basically, I think part of what I'm selling is because she started one of the things I've noticed and theid was like this too.
Adj to an extent, less so. By the way, sidebar, I did follow up with him very politely, and he replied very politely and said he really wants to pay me once they've raised and to keep in touch.
So fine. Thank you for reigning in my baser instincts. I think part of why I'm selling them is the ally, for want of a better word, because that word now has so many other connotations but the wingman, whatever we want to call it, the person who is non-judgmental, who they don't have to perform to and they don't have to. They can literally just get all of the ideas about their company out of their head and talk through all these questions they have and how to frame it and how to talk to investors about it.
I think that when I think, a lot of people are selling narrative stuff and they just do this big, what's the story? What's the story? What's the story? And they're not saying, what are the things you're hiding? What are the things you're not wanting to talk about? What are the things you're terrified investors are going to ask about?
So, long story short, I think that's what I've been thinking about in terms of the flow, the initial offer is you can get a breakdown of what you know where your deck stands now according to these parameters.
If you want to go through it on a deeper level with someone as a sounding board and an advisor, then we get started with that go/no-go entry offer, no.

**Ray | 19:46**
Yeah. Well, the thing I'm thinking about is I had a conversation earlier this week with someone who was saying that they were offering a subscription for their product, and I said, "Well, why are you making this subscription so...?"
Well, because that way we can build up trust over time. The thing that clicked with me then was that a subscription is not a way you build trust. A subscription is what you do after you have trust, right?
In the old magazine days, when you would have a... What would you do if you didn't have trust yet? You would just buy it from the newstand. You would get the subscription to it when you had a deep enough relationship with the periodical and the product that you want to be having this in your home every week, right? It was partially about savings, but it's really about regularity, but regularity comes downstream. I'm thinking about what you're describing and wondering whether there's a bit of... Thinking about the product in terms of the sequence of the journey that you want to go on with the customer, right? That has an efficiency to it as opposed to if you were to say you've had this whole series of things you do. What is the thing that they would be ready to buy from you first because it creates the first value from meeting them where they are, right?
They would get value from it, and they would have an ROI on it. ROI that's not just the same as now, I'm ready to buy more stuff from you, but right there, they would be happy with that. Then that's basically like the quality that Priest can bring him back to talk about as a prop for prospects, right?

**Ellie Rofe | 21:34**
Yeah.

**Ray | 21:34**
Because that's the thing where they are getting value from it, they have paid you for it. Then ideally, it is increasing trust, right? See, you have the new elect trust that's moving you towards being able to have the core offer, right?
But they're not buying it because it's the leading core offer, they're buying it because it solves their problem today. Anyway, the reason I'm bringing it up is when you talk about the conversation with Mattie and where she is and where a lot of people you meet are, you're not meeting the likelihood that you're meeting them in that moment before they're hiring their person to do this work, it's not super high. Or they applied the work with a J, right? He had a deck and then what?

**Ellie Rofe | 22:15**
Home Yeah, homemade. Most of them will have a homemade dirk. Yeah.

**Ray | 22:21**
Sure, a lot of them have homemade decks which they may or may not be proud of, but they will have pride in, right? Always a little bit hard to do that.
Then what is the thing that you can be doing that would be giving them an asset at the end of that engagement? That is relatively easy for them to buy because neither is requiring a whole lot of their time, nor is there a big time delay right in between when they pay, between when they give you whatever you're asking for and when they get the value.
Anyway, the conversation you're having with Maddie and the thing with AJ, sort of making me click a little bit through that. There's a question. There's a difference between what the ideal journey that you would take the customer on if you had your druthers, right, versus where at what point do they come in? I actually had a similar thing with state change.
I thought, okay, what I can do is people who want to get started with this, they will come meet and we will teach them some bare mental Mars patterns, whatever. There are a couple of people who come in at the beginning, but I actually find the vast majority don't.
Most of them come in because they've already been burned by a couple of things, right? So now they have singed fingertips. They're showing up trying to figure out how to not singe themselves next time.
This is a different place. They're coming in the door, and now how do I help them build those models? There's a little bit of how to get them over their resistances, right? Since I'm not seeing them when they're totally new, there's some stuff they need to unlearn. There's some built trust. They need to build in order to be able to learn things they would need to make the progress they need to make. I got one guy who's coming to office hours very regularly. He's making almost no progress between office hours, and I'm kind of worried for him.
But that's just part of building trust. Anyway, by way of your conversation with many others like you, most people you're going to meet at the wrong time, so how can you be having a conversation with them that works when it's the wrong time? You find the right person at the wrong time. How can you help them make progress right?
Then that's putting you in a good shape for what comes next. If you're a car dealership, obviously, your core offers are seldom the car, but not everyone's ready to buy the car. Some people you meet when they're ready to come and buy a car.
But a lot of the best of your wins are going to be people who we've already built up trust with before they come in the door.

**Ellie Rofe | 25:06**
YP.

**Ray | 25:06**
So how do you do that? What is the way that you're building that reputation with them? There's a bit of free product that's content stuff you're doing, and then there's what are these offers? They can come in and say, "Hey, I think Ellie is great. I saw Mattie. It's amazing. She saw your website."
That's super cool, or this is your content or whatever, right? But it's given me the wrong day relative to what your core offer is. So, is there something that they are looking for when they talk to you that can be a little bit less sensitive.

**Ellie Rofe | 25:40**
Yeah. So, I have considered... I think part of it is because I'm not currently in touch with VCS, I have been when I do the process with them because it's all anchored to the deck and the underlying process of creating that. I think I feel very secure on that ground.
I have considered... So one of the things I mentioned to Maddy was objection mining, and how we go looking for all those things so that you are prepared for them. I think that's a really useful thing to do, but because I'm not currently in connection with VCs because it's just... I don't have the connections at the moment.
Maybe that's the thing I just need to fix as a matter of urgency. I think that will unfortunately be cold outreach. It's not like I just don't have the ways in at the moment. But maybe that's the thing. I feel like a bit of a fraud saying, "Well, let's just brainstorm loads of investor objections when I'm being speculative about what they are because I'm not talking to investors regularly enough to hear what they are thinking at the moment."
To really genuinely reflect that. So that feels a little bit fraudulent in the context of working through strategy and thinking about the actual logic of the strategy and how it can be presented in a way that makes sense. Then I... It feels like it's tethered. I don't know why there's that difference, but there is in my head, maybe, but I have thought about that.
I have thought about presentation coaching. I went through because she asked me what I could do for her on a custom basis, and I went through a few different options in my head. I was thinking, "Well, maybe we could do like in a thousand twenty if the slides come back and they're not ideal or the slides." She knows she's got investor meetings and she's got to go out of it.
But it's a bit like... Maybe it's just my lack of intellectual flexibility here, and it's something that I need to work on. But when there is a deck that's wrong, it's a bit like... Maybe this does come from my history with screenwriting and that sort of storytelling. It's a bit like when there's a problem in Act three, it's not like you can fix it in Act three. It needs to be fixed in Act One.
Sometimes, the 80/20 of improving stuff can be really difficult. It might just literally be slapping some notes on a slide to call out a deficiency that's been ceded elsewhere.
But yeah, I guess that is an option. Or, I guess, preparing for it in objections or thinking about it, maybe I'm being a purist, and it just is what it is. What's the 80/20? How can we uplift these slides to better reflect your strategy, but without having to do a whole deck revamp?

**Ray | 28:54**
The expression that comes to mind is the perfect is the enemy of the good.

**Ellie Rofe | 29:00**
I may as well just ask. Could you just tattoo that on me? Actually, no, you just tattoo on your forehead so that whenever I'm talking to you, I can see.

**Ray | 29:10**
Goes behind or has like a chiron at the bottom here, right? Yeah, the.

**Ellie Rofe | 29:13**
Exactly.

**Ray | 29:18**
I think that is the crux of it. You can see lots of opportunities for things to get better. By the way, Mitch runs into the same problems when he's talking about copy. I'm like, "Dude, you gave such great counsel
in 45 minutes. They will make money from that." That's an offer, but because it's not the full thing, he's reticent about it. I get that. You are an expert in your craft, but people who can get past that can create a lot more value in the world.

**Ellie Rofe | 29:46**
Yeah. Yeah.

**Ray | 29:49**
And that doesn't mean you don't get to do the bigger work. But it's actually often the key to being able to do the bigger work is being able to help people. There's a 1.1 version of this, and there's a 2.0 version of this.
What can you help them with today? You can help them with the 1.1. The thing about one point ones is that they are they have they're quicker, right?

**Ellie Rofe | 30:11**
H.

**Ray | 30:12**
So don't break what came before. That's actually a key idea of 1.1 versus 2.0.
Two point zero is like, "Okay, we're making this big cutoff change to embrace the future." But that's going to be cutting off the past and the... There are risks that go with that, right?
When I think about the three components of buyability of risk, time and price... Actually, the implication for me is that the 1.1 might turn out to be very lucrative for you because by eliminating risk, because you're not requiring a big transformation, by limiting time because, well, it can't be that big a project, so you're not going for it.

**Ellie Rofe | 30:45**
Yeah.

**Ray | 30:57**
Your ability to be well paid per hour goes significantly up because even though it's not as high value as the other, it can be very high value for them that they can actually realize today.

**Ellie Rofe | 31:11**
Yes. Okay, so I like this because there's a cradle-to-grave, to Nic McDonald kind of idea or strategy.
So, if, for example, the event with Natasha works, that's really priming people. That's saying, "Prepare for your bloody rays and hire us to help you with it.

**Ray | 31:27**
[Laughter] he.

**Ellie Rofe | 31:29**
And people should have the funds and recognize the value, then they would come in for the full thing.
But if we imagine a website of services and it's not the names of the services but it's already raising the question mark that's the filter. Are you already in the trenches and that's where it's... Let's work it out. You're in the middle of it. You don't have time. You don't have the luxury to sit there and ponder strategy and narrative. Just need to fix things fast.

**Ray | 32:01**
Two Then, I suppose, as a software person, I think of there's the one point.

**Ellie Rofe | 32:02**
Yeah, okay. I really like that.

**Ray | 32:10**
No problem. There's a 1.1 problem. There's the 2.0 problem, right?

**Ellie Rofe | 32:13**
Four.

**Ray | 32:13**
The 1.0 problem is you haven't raised it before. Let's go get the 1.0. There's a 1.1 problem. The 2.0 problem is, "You're doing it, but it's not quite working as well as you would like it to."
This is how we do adaptation in a short period of time. Then there's the 2.0 now, which is the thing that got you to seed that won't get you to A, B, or whatever, right? Thus becomes a 2.0 story.
I think having a real offer on the 1.1. The 1.1 offer is not as sensitive.

**Ellie Rofe | 32:51**
Yeah.

**Ray | 32:51**
I already hired someone for my 1.0. That's fantastic. You know what I've got? Most people who I talk to have already done something for version 1.0, and they're already in the mix.
So, when we're under a bit more time pressure, I do research and review to help elevate the story. We do the baseballs there. So, maybe, Mattie, what we should be doing is when you get that back, you can send it over to me. I'm glad to take a look, and then I have a process. My process is end conversations over. Why did bla. Blah, right?

**Ellie Rofe | 33:29**
Yeah. I ended up sending her something that was effectively a 1.1, I think, like a review across the deck and then working out the 80/20 deck tweaks. And then my heart and my mouth as I sent it, thinking, I don't know what this deck's going to look like.
So it could be, we'll just take this mess off the slide and hope that something happens. But yeah, I really like that framing. That makes a lot of sense. It does help me meet people where they are rather than just go, "No, that person's not right for me because they're not preparing for their raise in a month's time or whatever." Yeah.

**Ray | 34:16**
And I don't know, maybe. Yeah, but that we, it's it is something worth cotrating by a little bit.

**Ellie Rofe | 34:27**
Yes.

**Ray | 34:27**
And you know, and if it doesn't look like that, I think this idea of what's a product for prospects, the imperfect version that is giving them value today, right? That I think you might reasonably say that's competing with your core offer. Just like the car, the dealer, the super dealership that we have down next town over in St. Johnsbury that is very excited about providing us with various maintenance jobs because doing that transaction makes it more likely we're going to buy our next car for them.

**Ellie Rofe | 35:09**
Yeah. So there is a certain amount of overlap. But I guess that's my question. When I think of the product for prospects, there was a sense I saw Daniel Priestley talk about it in terms of teaching basically the product for prospects as a way of teaching them about your IP, about the way you work and getting them intrigued and excited to work with someone who works in that way.
So you give them value, but an awful lot is about them going, "This person, I get them, and I like the way they work." Or no, I don't like that. That's where they go, which is where I thought this product for prospects was, the report that shows them a dashboard or heat map or something around which areas are strongest and weakest,
and where there's a potential reframe, for example. And I was trying to think about the client journey, I guess, and someone sitting there at eleven o'clock at night, stressed and frustrated with the debt and seeing this opportunity to just push something through a report to get another lens on it.
Obviously, there would have to be disclaimers that this is AI and it can make mistakes, et cetera, but it's primed with as much of me and my view of things as possible. They get something back with the upsell incorporated into that report. They get back...
But I don't know if that sounds like it's flimsy or not.

**Ray | 36:54**
Well, the question is...
I think it's worth asking, like, do you think this is taking money out of your mouth?
Because if it is, I think that's a positive sign because it's what I think of pro prospect working. The auto dealership, right? That is providing the fixes to the car, right? They're delaying our need for another car, right?

**Ellie Rofe | 37:26**
Yes.

**Ray | 37:28**
You can think of it like
this: it's against their interest, right? They want our car to fall apart so it's more likely we'll buy something sooner. But what they're doing is they're making it that we will be delayed, right? And they're providing something that isn't tied to our timing of needing a new car, right?
Because the previous one broke or something. They are providing the... But they're doing it, they're providing the best foot forward to provide the maximum value. For us, the value is we can go to a dealer and use our car and put our children in and not have to worry about it.

**Ellie Rofe | 37:56**
He. Y.

**Ray | 38:02**
The. you think about these things, have another tool, have another lens on it. Is that big enough value, right? For someone who is worried about that, what are you providing them with? Peace of mind? Are you providing them with... They're like, "This isn't right."
Are you providing them with actionable, useful counsel that has a track record of people being able to raise better as a result? That's a 1.1 type thing, right? That would be like the "Is there a clear..." I actually think that the 1.1 offer or that maintenance offer actually has a higher bar for the tangibility of the value delivery because you know, I go buy a new car.
Yeah, I had an older car. I have a newer car. A newer car has a nicer smell. How has my life really changed as I go from one to the other? Obviously, it's necessary, right? But often, the lift doesn't feel that way. If I just rewind to what I was with the previous 1.0, how have I... Whereas the 1.1, the fix of the car, my car was rattling. Now it's not rattling. Immediate value couldn't drive it. Now I can drive it. Immediate value.

**Ellie Rofe | 39:28**
Yeah.

**Ray | 39:30**
So that's the reason I'm bringing this up in the context of how to look at the value prop of it, which isn't to say that the analysis you're describing is necessarily the wrong thing.
I was just looking at it from their point of view, what is the how is it that their lives are going to change?
If they can see that immediate value in that short period of time, that is building up the trust that will cause them to take on the risk of working with you for the core offer.

**Ellie Rofe | 39:55**
YP So the goal of it was they get an assessment, they get a summary of priority fixes like the 80/20 fixes, I guess. What's the biggest two or three changes you could make? I was considering splitting it into... If you're pitching tomorrow, do this.
If you've got a few days, do this as well. Contextualizing it to them and their experience.
Questions that investors might ask or for them to consider. So that... The goal was the value is to reframe this, I think, and this is the question whether it does or doesn't. But sometimes education is an "aha" moment.
There's pragmatism in there as well. But what I see is a load of information about sales companies, in terms of creating a deck or whatever. Thousands and thousands of blogs and analysis and templates and all that kind of thing. Then you get the layer of endless talk about narrative and story.
Natasha, whom I'm working with, keeps talking about the deck and she's like, "Yeah, I just tell them to fix their Y and understand their why and their vision because that's what investors care about."
I'm like, "In a sense, do I believe in this thing? Absolutely." But if someone's got the most amazing vision in the world and they show some hockey stick chart... Maddy had it. It's the classic hockey stick.
From two or three million to a billion by 02:35.

**Ray | 41:52**
Of course it is.

**Ellie Rofe | 41:53**
Yeah, with steps like... There was no breakdown of what that actually looked like and what the strategy was for that value. No amount of vision is going to make an investor go, "Sure, good."
So I think they get a lot of advice elsewhere about this stuff and less about the fundamentals. Now, I'm not sitting there and doing financial modeling with them.

**Ray | 42:20**
Sorry if I might... I apologize for interrupting, but I think you used a really important word that I'd like you to meditate on a little bit, which is fundamentals.

**Ellie Rofe | 42:28**
Yes.

**Ray | 42:29**
Fundamentals? A judgey word.
That was the reason I was bringing it up. Because I think what you're doing is you're starting to describe what this other person was saying as a little bit of stuff. Right. Like, all airy vision and that, but
you're talking about the real stuff. Now, I do think when you talk about strategy, when you talk about tactics, when you talk about the steps to get from here to there. Mechanics is even a good word for this, right? Something that actually the particular P engineer types who are in hard tech will appreciate the word mechanics.
Like that the business is a machine, just like anything that they're building. [Laughter] That there are meaningful steps to get from here to there. It's a process of invention.
You don't know what all those steps are going to be just yet. But just because you're talking to the money people doesn't mean that all of a sudden the rules of how the world works have gone out the window. Now, the reason I bring this stuff up is that using the term fundamentals makes it feel like you're doing it all wrong, right? You're playing the wrong kind of basketball.

**Ellie Rofe | 43:27**
Yes. I don't use any marketing, but I will avoid using it in any explanation in the future.

**Ray | 43:34**
But I do think that there's a really important value there because you can... That's a great 1.1 offer. Like, "Hey, here's where you're doing underpants gnomes." If you're familiar with that nickname, it's a...
It's a name from 20 years ago. South Park. The Underpants Gnomes had a business plan. Step one, collect underpasses. Step three is profit. Step two the.

**Ellie Rofe | 44:00**
Hey.

**Ray | 44:03**
But so then we which is kind of what they've got going on, right?
And you can catch that out and be able to identify. That's not the totality of what you can do. But if that is a good example of something you do, then that becomes something you can be looking for, right? You can provide a short period of time. You can even get AI to identify those opportunities.

**Ellie Rofe | 44:23**
But that's what the reports are doing, saying we think that maybe this is your defensibility.

**Ray | 44:24**
And now. What? You're doing? Yeah.

**Ellie Rofe | 44:33**
So Maddy had nothing in her deck about the patents attached to this new technology.

**Ray | 44:39**
Okay.

**Ellie Rofe | 44:39**
And She's like, "Who wouldn't do that?" and "Who wouldn't put patents on it?" I'm like, "But they just want to know because it just signals that you're thinking about defensibility." Do you like talking about it being a $100 price when others are much more expensive? That looks like you're competing on commoditizing your product.
But if you put that as a... These are slow industries. Once we get in there, it takes ages to retool and recalibrate. So, we get multi-term contracts. It's harder to get away from us. It's sticky. Et cetera. Then that price looks like a commoditized race to the bottom pricing is actually needs to be framed as a moat that you are able to do this at lower margins to get in there to then get the constant turn of needing new sensors on robot hands, whatever.
So, that's the kind of analysis that's involved in this stuff, those investor-ready dimensions of a deck. The thing is, vision is included in it, but not the only thing.

**Ray | 45:52**
M Well, I'm just... I guess what I'm trying to say is that I really like the idea that you're the one who brings it to ground, right? Your idea of other people will talk about strategy, a complete strategy and vision, right? You're more at the mechanical, tactical. Can you? Does this thing tell the story that goes from A to B to C to D as opposed to just someone else pointing A to Z with a smile in the middle?
Right? The life of the hockey stick thing you were talking about there. There are all sorts of... You can get deeper into that, right? To build with that in mind is different from fixing with that in mind.
Right, over the top, right?

**Ellie Rofe | 46:35**
Yes.

**Ray | 46:36**
Or providing some counsel or what have you. But I do think that becomes when you're talking about Priest, right? What is it that the dealership is doing right by showing that they are competent at making good advice on what to fix and then fixing it?
Well, wait, they are now the company I will trust with those mechanical things when it comes to the bigger sale.

**Ellie Rofe | 46:59**
Yeah.

**Ray | 47:01**
The what Priest is saying is like something that would demonstrate that you have this kind of quality to you.
But the. But that's why it's good for you, right? The reason it's good for them is because it takes them to a point a to a point B that they want to be on. That is super valuable for them to be on. And they don't.
And that they don't need to trust you to know that they're now and B but instead them GA to B is causing them to trust you more and trust your trust the other ideas you have in the process. They would go through and like that would make them want to do the 2.0 with you.

**Ellie Rofe | 47:41**
So sorry, I might have misunderstood. That is the right analysis of the product? Not the right... But a good idea for a product for prospects. Then.

**Ray | 47:53**
I do think that what you were describing is having those pieces of things that start to break it down. I think it has both those qualities of being able to be more. This is what you know, this is what Li is about as well as things that can create more value for them.
But I think the framing of it matters, but you thinking about, "Hey, what are they going to have? What's going to be true for them at the end?" Right? I think one of the ways you were describing it earlier in our conversation was they have another lens on it, and that having another lens feels very European. To use the framework you were talking about at the beginning, right?

**Ellie Rofe | 48:23**
H.

**Ray | 48:30**
It's just one more lens. It's just another point of view. Okay, why am I paying for that? Right? As opposed to something that has a little bit of ego and swagger bound to it, which is these are missing things that cause pitches to fail.

**Ellie Rofe | 48:51**
Y.

**Ray | 48:52**
And we do is we are doing the diagnostics so that you're going to have whatever conversation you're going to have with them. It's going to be subject to whatever their investment thesis is, blah.
But we're making sure that we take care of these basics and put your best foot forward, which includes things like checking for intellect, checking for defensibility, which is intellectual property protection. We're checking for...
You know, what are the steps on the growth curve? Making sure we don't just have a smooth hockey stick. There are a few things that you can even start to imagine. You being able to describe in advance what this thing does and what the service is.
Then, they're able to... They might just take that checklist and go apply it. But even if they do that, they've learned about how you work and what you're like, and they're more likely to... With you, et cetera.

**Ellie Rofe | 49:40**
Yeah, that's what I was thinking. So I've put them into buckets because there are too many. I just say ten or twelve depending on the business.
It's basically answering investor questions with specifics. So the first one is, "Do I understand this? Do I get it?" That's the problem, market, solution, investment case, value proposition, if you want it in there, then it's, "Do I believe in it?"
That is proof, traction, vision, "Why now?" Can I trust investing in it? I need to reword that. Can I trust it or do it? Should I invest in it? That is like development roadmap, go-to-market strategy, funding, ask, use of funds, ask the ask, et cetera.
That's all the mechanics that people often ignore and just try to skip over or fudge or whatever. Obviously, the team is part of all of those. Really? But that's what I'm thinking. These are the three big questions that Adeck needs to answer, and they're a mechanical thing that's stripped back from all that.
Actually, I like the term "mechanics" because that's what I said when I was talking about the deck flow analysis. I was like, "I used to think structure was this ineffable thing that you had to just feel."
Then I realized I can color-code slides and see the structure because, obviously, structure is physical. It's a physical thing, and this is a mechanical thing. Yes, there is an art to how you express it, but is it, "Have you answered these questions?"
Because a deck is just a series of answers to questions that people have, and that's how I'm framing it.

**Ray | 51:24**
2.

**Ellie Rofe | 51:29**
And think I'm trying to position it as you are the smart founder. You're not just going in there waving a vision and a wand. You're saying, "I will."
I will think seriously about how to structure this in a way that makes sense to people and answers questions. Don't know.

**Ray | 51:51**
There. There is something in there about, like, you know. You know, hard tech means asking hard questions or something. But. The. I'll.

**Ellie Rofe | 52:01**
Yeah. It is a different thing because people are giving you huge amounts of money and they have to trust that you're... The way in which you are developing this makes sense that you are...
I've seen a lot of people raise, and they're like, "We're raising two million here and one and a half million from grants." My question is, what happens if you don't get the grants? What's that? That seems kind of...
I know you think that it's like we're putting in non-dilutive funding here. But if you don't get them, can you still develop this thing? Or have I just put two million into something that doesn't go forward? I don't know, there's lots of stuff around that.
But yes, that's what I was thinking. It's mechanics. It's all the different moving parts, and are any of them weak?

**Ray | 52:57**
Two.

**Ellie Rofe | 52:58**
Are any of them. Is that cog slipping. Or.
You know. Yeah.

**Ray | 53:04**
And way, I mean, you can start to play the source game with it, right? I think the fundamentals... I know I jumped at that word.
Fundamentals... Because I think there's a real offer in here that has to do with the part where we take off the judgment aspect of it. I can see how that might be able to sell a bit easier because now it's differentiating.
Because instead of just saying, "Well, that thing is obviously wrong," say, "They're doing that part. That's fine. This is how I do our part. This is one of the reasons why you have that complementary aspect to the thing you're about to do with the sessions, right?

**Ellie Rofe | 53:44**
Y.

**Ray | 53:45**
And they'll have a Telegram group. You're just... She's the sky and you're the ground support, but that's where the war gets won. You know, you've got to get from boy...
Anyway. Okay. How can I be a better service to you heading into the coming week? Because we're a little past the time.

**Ellie Rofe | 54:18**
Yes, sorry. I think I just need to commit again. I'm going back to the UK for a few... In fact, for the next week. I just need to remit to posting every day because it does make a difference.
And just clearing through the work to start marketing the event. I might send the landing page if you have time to have a look at it and see if there's anything stupid in there, but.

**Ray | 54:46**
I'd be delighted.

**Ellie Rofe | 54:47**
Okay, fabulous.

**Ray | 54:49**
And if. Yeah, I'd be glad to take a look at it and, yeah, let me know anything else I can do to be of service in the week and we'll. I'll see you again on Tuesday.

**Ellie Rofe | 55:01**
Okay, happiness. Thank you so much, Ray. Get some rest, take caree.

**Ray | 55:04**
Thank you. Thank you. Bye. Bye.

