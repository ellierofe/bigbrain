# State Change Mastermind - Aug, 05

## Key Points
- Robert reported organizing an MCP event for the following day with six signups, expressing optimism about the content generation potential and business impact of this initiative. 
- Demitris shared his progress in building a personal brand through one-to-one sessions and co-building services, noting positive signals from previous conversations and scheduled presentations at Zapier Office Hours and another community event. 
- Ellie expressed gratitude for joining the mastermind and receiving substantial help from both Demitris and Robert, particularly with MCP development and report creation strategies. 
- Discussion centered on Opus Clips tool performance, with Ellie questioning whether the typical 80% miss rate for generated clips is standard or if specific interview structures could improve output quality. 
- Robert advocated for more intentional content preparation over relying on automated clip generation, suggesting that pre-planned questions and structured responses yield better results than post-conversation editing. 
- Demitris recommended using multiple tools in combination, specifically Descript for recording and sharing plus CapCut for editing with background sounds and visual elements. 
- Ray outlined a two-interview approach for content creation, explaining that the first interview generates new thinking while the second interview allows for clearer expression of refined ideas with better signal-to-noise ratio. 
- Ellie acknowledged that interview formats help her communicate more naturally compared to direct recording, as she tends to modulate herself excessively when trying to appear professional for the biotech industry. 
- Ellie demonstrated her Claude-based pitch deck analysis tool that color-codes slides to identify structural issues, current problems, and missing elements in fundraising presentations. 
- Demitris suggested using the analysis tool as a lead magnet combined with 30-minute guided sessions rather than self-serve functionality, emphasizing the value of personal interaction for relationship building. 
- Robert recommended sharing the tool publicly for credibility building and lead generation, noting that it makes Ellie appear smart and hardworking regardless of whether prospects use it directly. 
- Ray emphasized that the tool's primary value lies in demonstrating competence and generating inbound sales rather than becoming a standalone product, suggesting the screenshot alone would be effective LinkedIn content. 
- Discussion of Daniel Priestley's sales framework revealed agreement on the importance of having structured processes for professional sales conversations, though Ray noted distinctions between high-end professional services and more repeatable business models. 
- Ray reframed Ellie's service offering from pitch deck creation to successful fundraising outcomes, with Robert suggesting this broader goal represents better marketing messaging for her LinkedIn presence. 


## Action Items
- **Ellie Rofe and Robert to schedule and conduct a follow-up discussion about the complex technology and faster ways to make the report more interesting.** - _Ellie Rofe_, _Sep, 16_
- **Robert to watch approximately ten hours of Daniel Priestley's content to understand his communication style and frameworks.** - _Robert_, _Sep, 16_
- **Ellie Rofe to create a LinkedIn post featuring the color-coded pitch deck analysis tool screenshot immediately after the call finishes.** - _Ellie Rofe_, _Sep, 16_
- **Demitris to schedule the next agenda for his upcoming video collaboration with Robert.** - _Demitris_, _Sep, 16_



