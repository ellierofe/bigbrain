# State Change Mastermind - Aug, 05

# Transcript
**Ellie Rofe | 00:02**
One.

**Robert | 00:07**
How's everything? Anything new?

**Ray | 00:13**
My goodness.

**Ellie Rofe | 00:14**
Hey folks, how's all going?

**Ray | 00:16**
Well very well, hoping air quality is creeping up today, and I live in Robert, you're over in Toronto, you've been... I don't know if you've been experiencing that much of this super spokiness from the wildfire.
So just north.

**Robert | 00:35**
Yeah, it comes in and goes, sometimes you just be driving, and then you'll just be like, "Is there a fire nearby?" Then, you know, it smells like someone's burning wood everywhere. But so I can only imagine where it's closer to it.

**Ray | 00:53**
Yeah, and I don't really know how close I am to it. But last night, I went to the gym around sundown, and my goodness, that sun was red in the sky because there was just so much particulate between me and there.
Even now, I'm sitting here with the... We have air purifiers because of COVID concerns. But I've got it running right next to my desk just to clear out all that stuff on the ionizer and just have clean air while I'm trying to work.
It's localized. All right, well, let's go around the horn. What kind of week has it been? And Robert, you had the hot seat last week. Can we start with you, sir?

**Robert | 01:36**
Sure, it's been... So, I mean, since last week, it was a week of study, but then lately, just getting back into the market and just taking your advice really like making that MCP event for tomorrow.
I have six people who signed up for it, so that's really good, and I think it just makes a lot of sense. It will lead to content. I think that there's a few things that will just line up just by that one taking that one action.
So yeah, I already feel good about it. I'm looking forward to it. And that's probably in itself just a good feeling. So I'm trying to ride that instinct of like, "Okay, it feels good, it's good for the business, then do more of it."
Just try to double down on what works. As much as that seems like, it's like there's that aim of the Netwitt and the genius and the bell curve of just... I'm just...
I think maybe just if I just try to just be more dim-witted about it, I think I might get better results. So, yeah, I'm just trying to keep it simple, and that's mostly what I'm up to.

**Ray | 03:09**
Super cool. All right. To be just couldn't check with you, sir. What kind of week has been?

**Demitris | 03:18**
It was a nice week. I closed the past week with very nice thoughts and signs as you know. I'm trying to find my way in building a personal brand. So I had some nice signals, some conversation with people who we had the talk or a call where they knew from previously that I'm doing the service in a one-to-one session and in co-building, which is the first goal of this communication. I
had a nice conversation with early closing last week. I found, first of all, the time was incredible for me because I learned new stuff. And I think we created a nice frame of conversation for our videos. Rob, your turn is coming back to you, man. [Laughter].

**Robert | 04:29**
After that.

**Demitris | 04:31**
So we're going to schedule our next agenda. Now I'm... This week tends to be a little bit weird because I have distractions from the pharmacy project. I spent most of the time doing stuff about that. At the same time, I wanted to be focused on my staff.
So I prioritized what matters the most. Thankfully, I have to schedule to join as a presenter to two events. The first event is a Zappier's Office Hours, which was nice and as the first experience, I really liked it and enjoyed it. The
second event is on the upcoming Friday on another community where I'm going to present the Digital Twin approach and the Digital Twin NVP as I built it for myself and a client. So yeah, that's it so far.

**Ray | 05:40**
A Superman. Can I ask? Did you get to the thing yesterday, that office hours bit that was an NCO event? Do you get to record it or do you not get the... Do you get the film? That's what I'm trying to ask.

**Demitris | 05:53**
? could get the film. From my Krisp video recording. But if I get it, I don't know if I could use it. Okay. So I wanted for the first time to have the run and see how it works and see how the bonding with the other guy. Send it goes well, because I had so many thoughts about that. He's a different kind of person in terms of personality in the is.
Yeah, everyone is unique, not different. We're unique. So I want to see how that works. And after that, I wanted to ask Claudia for her permission and doing that, okay, instead of using it, but I have the recording on my Krisp for thoughts and ideas like this kind of thing.
Yeah, the recording.

**Ray | 06:53**
Sure. No, I appreciate that. So you have that for your reference, but not really something you could directly turn into content on your own first party basis. I love this thing of you doing those office hours.
I think it's a wonderful way to be establishing you with a greater credibility in the short term. It's something that we can definitely be talking about more next week. And then Ellie, can we ask what kind of week has been? Was true today. That was not true a week ago.
And then after that, we can ease into the hot sea Part.

**Ellie Rofe | 07:24**
It's been a great week, thank you. Firstly, thanks for bringing me into this mastermind. I had lovely chats with both Demetrius and Robert. Huge amounts of help from both of them. It really galvanizes you or helps you over things, which is amazing.
One of my questions is actually related to my questions.

**Ray | 07:43**
9.

**Ellie Rofe | 07:47**
I could have a thousand questions this week, to be honest, but let's work through them in some sort of order. Yeah, I often struggle to find questions.
Then I sat down and brainstormed and really thought about it, and then came up with too many. So, damned if you do, damned if you don't. But yeah, that was really nice. It was over. That was on a Friday. I spoke with them both, and Robert helped with some huge MCP stuff and GI, thinking about ways of making the report that I'm creating interesting.
If there were faster ways, it looks like. We'll talk again, but it looks like it's quite complex, and the technology's a bit early, but it's fascinating. Demetrius interviewed me, as it were, or just chatted with me, asking questions on video and grilling me.
Then I used something that I'd completely forgotten about, and I don't know if people have heard of Oprah's clips. It was really interesting, and I just wanted to check. My first question is a slightly more pragmatic one really, which is...
So I dumped it in like thirty minutes of a conversation, and it just processes it into all these different clips. I didn't know if other people had used it and found that sort of... 80% of these clips are garbage generally.
Look, consider even if you get ten to twenty percent out of this that are good, that's still a very fast way of getting some clips for social media. But the other thing I was wondering is if there's a nice paradigm or structure you can use for the questions you're answering to create more high-value content. What in that interview section? Which can then be dumped into something like Opus Clips to generate something that has more high-value insights with a greater number of high-value insights that would fit into this shorter clip.

**Ray | 10:03**
Could you maybe restate the following question? I think that the following question was really the key to it, right? How to get more value out of it, but I'm not sure. But can you describe your thinking on that a little bitm?

**Ellie Rofe | 10:13**
Yeah, I don't know if Opus Clips always has a high miss rate, and it's just a case of throwing as much as you can at it and seeing what sticks against the wall, or whether there is a structure you can use for the video recording that helps you get a higher rate.
Do you just have loads and loads of short clips? Loads and loads of short questions? Quick questions. Do you tailor the questions in advance? Demetrius was doing it extemporaneously, and it was really insightful and really helpful because he was just asking questions out of left field.
But is it prepared for that? That's my question. Or multiple questions wrapped into one.

**Ray | 10:55**
Yeah, sure. Can we open it up a little bit? I have my own interview techniques that I've used in the past. I'm glad to bring them back around, but I don't want to pollute. Thinking of doing interest from Robert before we get into those.
Robert, since you weren't part of the conversation, could we get your thoughts on this?

**Robert | 11:13**
Yeah, for sure. SP well, I think that.

**Ellie Rofe | 11:19**
Let's not have TA.

**Robert | 11:22**
Well, I just think that in general, the tool is probably going to produce... I think every person maybe has a different tolerance or maybe a different way for how they want to go about creating content.
And so for every person that's going to do that, there's a lot of factors that play into that. In the sense that you look at all of that stuff and then you think, "Okay, I have to watch all of them and I'm going to have to listen to all of them to confirm for each one."
For me, I can just say, when I would look at that wall of clips, I never felt like doing that. Every time I would get back ten clips or 20 clips, it would create a sinking feeling in me because I just didn't want to. I felt like I was going to watch them and then I wasn't going to post them. Or I just didn't feel like the... I'd rather do the opposite, I found. Which is to be more intentional about the content.
Maybe at least to know if I know ahead of time that I'm going to turn this into content or just know that, "Okay, I'm going to answer these ten questions, and then I'm going to be able to maybe just have a bit of preparation to know that I'm going to articulate it a certain way, and then I'll know that that's going to go downstream into the quality of the output of the videos."
I think that's where... Now, obviously, the downside of that is that it takes more preparation time, right? To do that. But I think that there's a middle ground where with just a bit of preparation, then maybe when you look at those clips, you'll be able to see and expect at least some kind of order. Rather than what I see when I look at them, it's hard for me to know what I'm looking at because I know that I touched on all kinds of things during the conversation, and I wasn't...
To take that and turn it into a free-flowing conversation turned to content, it's tough. But I think if there's a bit more, just being intentional about it and just a little bit of preparation, I think it would maybe serve the process better.
That's just some of my thoughts.

**Ellie Rofe | 13:46**
No, I think you're right. Interestingly, I think one of the areas I really get bogged down is in editing, and that's where my perfectionism really hits. So, I found it's easier for me to press play on things and just ignore them or say, "Yes, that's a good one," or "Acceptable" in my head than it is to go into Descript where you're just cutting text.

**Robert | 13:57**
Yes.

**Ellie Rofe | 14:10**
I'm a nightmare. That will just be there for three hours.

**Robert | 14:13**
I I get stuck on Descript for a long time, long periods of time. So, I totally get that. I think that at least I can just say that for me, I found that using Tele, I liked how well, basically, I just liked the flow of going from Tele to DSCRIPT.

**Ellie Rofe | 14:27**
But.

**Robert | 14:35**
I found that actually, with me being a bit prepared for the video and coming in and being able to give a good presentation of what I'm trying to communicate. Then, when I would use Tele, it would chop it up nicely. It would get rid of the better parts of Descript because I felt Descript almost took me backwards, but it just turned it into... The cuts were very obvious, and it wasn't enjoyable to listen to anymore, but just to say that there was. I don't.
I think Descript could actually be a negative in some cases when it comes to... If you really are paying attention to how it comes out by the end, I've just... I've noticed it going a lot to Descript. I was enjoying listening to myself more quickly and then that means I would hit publish more quickly and so yeah, that's the main thing.
Yeah, super cool.

**Ellie Rofe | 15:31**
Great, thank you.

**Ray | 15:35**
DEMERIS you've played with a lot of these tools, and of course you were a party to the conversation, but then the whole editing process, something Ellie was doing more on her own, but you've looked into a bunch of these. What's your thinking on this stuff?

**Demitris | 15:50**
I think that all of these tools guys are very good in only one thing, and they're missing the rest. My experience using Descript is very good for recording yourself for self-recording and using the final result with Descript.
So, sharing the video with colleagues, with your audience, and so on. But the editing process inside Descript is not that good. While they're doing some progress right now, yet I find myself cutting parts. The cutting inside Ellie is quite hard.
Well, I found Kat which was a recommendation from a friend of mine. He said, "Look, everyone on Instagram uses that. Go and use it." It's good for only one thing, and it's very good at adding some sound in the background to make it more interesting and adding some shapes and illustrations on the screen.
So I found Kat is quite easy to do the editing, but they found it after three months. Pain with Vide, pain with Opsclip, pain with other tools. Right now I'm using Descript and Kat. It's fine. I found myself that when we uploaded the entire conversation to an AI and asked him to create the clips for us, he didn't find the right ranges to select by default. Claudia from Nco Community built a workflow on that where she feeds the transcript to AI, who asks to find the ranges, and then she gets the ranges and goes on editing like having them on the notes.
But what they do is just upload it and say, "Bullshit." Nice keep it nice, cut it out. Next one, we split. I split it in like that. Quite creepy, but it has a flow on my end. Definitely, video editing is not the most enjoyable thing, even if you think that you're not getting paid back immediately from that.
So if that helps you, from my statistics, I found myself in the fourth consecutive week to start getting steady engagement. My personal posts have more engagement than my videos, but in the sixth week, where I had the first conversations, people got to know more and they found some stuff more interesting. It was quite more enjoyable for them to consume this content.
And I think we have to break the ice with the video talking afterwards, of course. A few months ago, I was quite freaky with that. We have to just go to market and just start talking. Definitely, we have to express ourselves with videos, with text, with whatever. The first thing is what we have to be focused on, just doing stuff, even in the wrong way.
For example, if LinkedIn doesn't validate videos, you're going with a video on LinkedIn. It doesn't matter. You don't go anywhere. Just do it, and then we can specialize on that. In terms of the questions, I think it's a very nice point. Being prepared for those questions makes the conversation more valuable. The conversation with Ellie became like that. I was a bit prepared because I knew that it was the first time with Ellie.
Well, I was experiencing with Robert and from the past, and I'm trying to do it with other colleagues. So try to find some interesting questions. I gave you quite general questions. But the purpose, my thought, was to make her feel more comfortable during these times.
What are we doing right now? Is it worth it to spend my minutes in this conversation or not? This is so... Every professional has to take into account. So, I found quite general questions.
But it could work for the next time I find myself needing to do some deeper investigation in her domain and use the feedback I received from the first part and then get into deeper. Except if she has some wonderful case study to showcase.
For example, this was quite helpful from Robert. Robert was coming with he was very excited or very tired, but excited too, showing something new he built and said, "I have something." He was quite tired, I remember him, but he was.

**Robert | 21:15**
So tired.

**Demitris | 21:16**
Yes, I find many times too tired. Not that engaged, but it was clear your enthusiasm from what you built. This is nice if someone with, for example, today's horrible day for me, not too great mentality.
And so on a normal day. Okay, if someone joins me but he will not say "one", you know, as a professional, my job is to give some... not be a clone. So, in this, happens to everyone. Let's keep it that it's more enjoyable for everyone.
Last point in closing, I posted on Friday in a state chains, a video course from Caleb Ralston. He presents himself like a brand consultant, but actually, he's mostly a video editor, video consultant, and stuff like that.
He has a course of six hours and started doing it during the weekend. Too many interesting things. He talks mostly about the content part and all the things we discussed already since my starting with state changes, the same thoughts came from him. A couple of expert thoughts came.
And that's why I'm saying this story is that the most viral story video from Gary Vaynerchuk was that one he wasn't in a we place, maybe in a bathroom eating... for a certain number of seconds. It was that weird that attracted everyone during the feed. It said, "Who? What is he doing?"
It has a waiting moment, and when he ate, he transferred his message. So, these kind of things... As Rori Sather, his name is the alchemist author. She said, "Don't look for logical solutions, look for the weird thought." Long story. Thank Thank.

**Ellie Rofe | 23:46**
No, it was brilliant, thank you. I just wanted to clarify, you asked really good questions.
I think I need to prepare in some way because you weren't asking bad questions at all. I just think that because of the way I was responding, the structure of the conversation was a bit dense, Maybe.

**Demitris | 24:06**
We can repeat it with the same conversations and the same questions.

**Ray | 24:12**
And there we go. The conversations I enjoy the most are the ones where I get to develop new thought patterns, and they're the ones where I'm the least quotable. Something interesting might fall out of my mouth in the course, but there's a whole lot more. Or what... I'm stuttering because I'm thinking, right?
Good questions make me think, and that I really enjoy in the moment, and that is improving my knowledge. Part of our knowledge reputation, moal stuff. This happens to me all the time when I'm in live events, happens to be in state change, whatever. I am, though, the most quotable, right?
I'm producing usually the best repeat content. I repeat content that someone's like, "Should use in the video or beat content because it hasn't been ingrained in someone's brain the fourth or fifth time I'm set up." At that point, I have distilled it. I'm pulling something from my memory and just popping it out. It comes through.
I have a high signal-to-noise ratio. My approach in these interview situations is that the first interview is to get the thinking going because usually, I'm talking to people, and they haven't thought about these questions before.
If I'm doing the asking and in a good conversation, often, I haven't thought about the topic yet. Right? And so I don't really have my quotes ready to go, and that makes me less good when I'm being interviewed for media. I need to stop with the stuff that's creative. I need to go to the stuff that I can just pull from memory because that's going to be more useful, right? For them to clip off or whatever.
In a situation like this where he's getting you to think and you're thinking and pulling out the ideas, the first interview is about getting the person to express some ideas. We can be using things like Krisp and whatever to...
Okay. What were the key ideas in this conversation? What seemed interesting, and then getting into the turns of phrase you thought were particularly neat. This is where the interview is in a better position to judge. Wait, there was a really good turn of phrase in there. Than the interview is. I just had this happen in office hours where I dropped a line about AI and Dad Petro was afterwards asking, "Hey, what was that?"
Right? Because I want to use that. So he saw what the line was, he was trying to dig out where it was and looking for quotes like that. It is actually a little more challenging. We're going through the transcripts. Transcripts aren't that reliable at that level, but that's where you're using your memory, right?
Then the ideas where you can use AI to help us a lot. Then we come to interview number two, right? Interview number two is like, "Hey, we talked about this." So first, let's center our brain on this particular topic and basically let's take some runs at it.
You'll find that because you're not thinking about this anew and because you're doing it repeatedly, it has become increasingly clear, right. Less noise with the signal. And then it will become easier for the AI detector, whatever, right? The Opus clip thing to detect that, "Hey, you said something Krisp in here that was less than 60 seconds, and let's go.

**Ellie Rofe | 27:18**
No.

**Ray | 27:19**
So I find doing this in two steps. You can't really do them in sequence because you need the time to think and evaluate. What are these ideas that are worth doing? Because you don't need 100 clips from this conversation, right? You're going to go through an hour-long conversation and you're going to have maybe two or three, if that's really good, maybe four or five, and that's all you need.
That's all you want. You want the good stuff, and the good stuff that you can put out there, and you get to do that again. But I find that doing this in two passes is what allows you that distance to go from thinking up good ideas to being able to express them with clarity.
It's not about expressing them in a super viral way or whatever. It's just about that signal-to-noise ratio and getting rid of some of the UMS and URs, but I wouldn't even worry about those too much.
It's just the difference between thinking about it and expressing it at the same time versus just working on the expressing of it. It doesn't need to be at the point of perfect, or probably you're probably not even good to your own standards, right?
Because you're going to find that whatever you express is less than what your idea is in your brain, but that I find allows you to do it with greater clarity. So, when I'm doing the chair lift shorts, I record multiple numbers more than I actually post up because I'm usually taking a couple of runs at the idea first.
It's only going to be once I've got the idea that I'm able to put up. Some of them come out the first time you get into a groove, and you'll learn how to do this more. But many of them are after a bunch of things where I have to end it with a funny face or something so that I am telling my editor this stuff. [Laughter] Because I know that I didn't quite get that right.
That's been my approach. Then I love tools like this because it means I get to spend less time in the editing bay or not having a person go into the editing bay or whatever to go find that stuff.
It's technique, an interviewing technique to create those moments, and you're going to know where those moments happen. I don't think there are many situations, at least, where you're using a tool like this and it's telling you about moments that you didn't know existed, right? That are then going to be publication-worthy.
Maybe I'll tell you, but hey, wait, that was an interesting idea. Okay, let's do something for us to tackle next time. But I think it's going to be in the second interview that you're able to have the thing that's going to be a little bit more shipping-ready.
Overall, I find that sounds like a huge time investment. Having just two of these conversations to be able to get there is so much less than might have been otherwise. Two conversations are probably a lot more fun than a conversation.
Plus, some significant editing process. Try to fix all the ums. And as just out of the audio, if you're talking to a celebrity or something, you got to deal with it. This is what professionals do, right?
If you're not, and you do have two bites at the apple, it can be simpler. simpler.

**Ellie Rofe | 30:17**
Yeah. And II mean, you guys were completely right about the interview process being better. Because as soon as I'm just recording on my own and I'm staring at a little light or whatever, I'm just like, "I'm not an actress, clearly." [Laughter] Just awfully stiff. I can't bear it.
That's all really helpful. I feel like a bit of AA deb asking this or a doc or whatever the right American term is to avoid me using it more. English swear words. But I do sometimes think, and I've been thinking this a little bit.
It's not a big existential thing. But I do think some of my resistance is because of what I see of the biotech industry and what I understand of it is quite a dry, reserved place. I think sometimes I'm not just modulating my thoughts, I'm modulating myself while I'm trying to do this stuff.
So I think there is an element there, just broadly. I actually really love the work I do. I've been working with that deferred payment client who is fascinating. I really like thinking around problems.
Boy, are there some big problems to work out with this company. But I find the wider industry very bone-scrapingly dry. So I think I end up... I think I'm kind of overly conscious there.
That interview process helps because then I'm just talking more naturally. I'm not necessarily completely modulating myself as much as I would be when I'm trying to record directly, if that makes sense.

**Ray | 32:04**
That's fantastic. I think the interview helps you. I don't think you're the only one who the interview helps. That you guys could be helping each other. You can be setting it up like, "Hey, we're going to do the meeting, come up with some ideas, and then you are trading spots."
Then everyone gets to come out with those clips that are more helpful because you're helping both surface. If you will go to drill for the oil of the idea and then refine it to a state where it can actually be distributed.

**Ellie Rofe | 32:33**
Yeah, absolutely. Okay. Thank you. The other bigger question, I think, or maybe, it's another problematic one, is this tool, what I made. So if I just get that out the way and get these out the way so I can actually see it.
So this is in Claude. I've got the screen arranged so I'm not showing brand names, which is why it's like this, but basically, this is the little tool I've got in Claude where you would add a PDF, so you just add a PDF in here, and then it comes out with an analysis, and it's color-coded to show where the current issues are.
So, you can see with this pitch deck, there are dots around, there's a hell of a lot of solution stuff really about their science and things. There's a tiny bit of clinical proof, there's a tiny bit of differentiation, but it's a color-coded way of quite quickly seeing the depth of it.
In some depths, I've tested with this tool, the science bit is like 12 or 15 slides long in a 28-slide deck or something. So, as a tool, I'm using it, and I'm going to talk about the concept of color-coding your slides to see the structure of your deck and what you are or aren't including where things are missing, et cetera.
But Demetris and I were actually talking about this on Friday, whether this is a lead-gen type of tool and, if so, whether it's like an assessment funnel where you just get people to go in and self-serve it or whether it's a one-to-one opening like 30 minutes or an hour-long analysis, the usual.
I think we talked about them last week or the week before that kind of hunting license type process. So yeah, I've just been thinking about that. Both of them create different questions, I guess.
If it was a self-serve tool, then I can't really just have it. Claude has to be set up in a different way. I wouldn't want to just be sharing all the prompts and everything with people. It would have to be something where they literally just go, "Upload a PDF," and it does it for them.
But then that's developing a tool, and as you mentioned, I'm not a front-end developer. I'm not a developer, I'm a pitch deck specialist, so that's what I should probably focus on. If I do it one-on-one, my slight concern is the barrier to entry, then having to book a call to try out an assessment tool.
So, that was my rambling thoughts on this one.

**Ray | 35:46**
Okay, well, this was you in the room with Dimitri. So, Dimitri, could you get your plumbing house? Would you mind sharing what you thought coming into all this?

**Demitris | 35:54**
Yeah, what they... I suggested to Ali or back on Friday. This is my opinion for the day, guys, is to use it as a lead magnet and join in a conversation with the person and run it together in a 30-minute session.
So, they can interact and guide them. I'm not a fan of giving it as a task to the client because they will avoid it for tons of many reasons, but if you do one step more and come closer to them and get in conversation with them, what's going to happen is that first of all, they're going to meet you. Secondly, they're going to see,
and they can validate.

**Ray | 36:46**
If they like you.

**Demitris | 36:49**
As a consultant and all of these problems that come after the personal conversation. So, my suggestion would be that one does it together with them. If there are some technical concerns, doing that on a call and there is a need to build something, we are very glad. Go and build it in an afternoon with our coffee, lunch music, and recording [Laughter] and just do it cool.

**Ray | 37:25**
Robert, what do you think?

**Robert | 37:28**
I think that, in general, that you could benefit a lot from just making it from just sharing this in general, like the fact that you worked this way and that you've made this and
again, like the. And because I think that there's Prato's principle where you know what, 80% of your returns are going to come from 20% of your efforts. I think maybe you could look at some... This is just me,
just my thoughts. I'm just thinking that just making it clear that, "Hey, this is the way I work." Even if they weren't able to use it themselves, it just makes you look smart, right? It
just makes you look like you work hard, and this is something that is an output of and a preview of what you consider to be something that's good, which just looks good. When you first pulled it up, I'm like, "What is this? This looks good."
So I think that's always a good thing to put on the market, and it wouldn't take very much, right? Maybe you're looking from that perspective and how much you would gain from that, I think might be in a lot of it. It might not be 100% of what you could possibly squeeze out of it, but it would...
You're going to get quite a bit out of it, even if it might not seem like putting it in their hands would be the most effective way. I think that there's something here to just make this visible and share it in general.

**Ellie Rofe | 39:19**
Yes. So I'm jumping because, I mean, that's why I created it first, it was just for marketing. I use it a bit myself, but it's a useful point.

**Robert | 39:28**
Because it looks good, like it looks really nice. I think that it might make someone even more curious to ask you about it, right? Then even validate further and further how many people are talking about how many people want to know more about it and so on, right?
I think it's at least an AI step that might encourage you to take the further steps because the further steps are going to require... You know, they'll be like, "You know, the idea is really going to get tested quite a lot."
And you're in your motivation for building it until it gets to that point, there'll be a thousand headaches between here and it being, you know, it working, depending on how you envision that.
So probably for me at least, I at least try to swim to some island and swim to the next island and so on.

**Ellie Rofe | 40:27**
M Okay, that makes a lot of sense. So it's like a stepping stone. I start talking about it in marketing. People are interested. I can be like, "Right, we'll do it on your deck."
So I incorporate these ideas, build it that way, and if it becomes something that is actually a really useful tool, then turn it into something that people can self-serve with or however that might work.

**Robert | 40:54**
I think this makes you look like you're smart and you work hard. And I think that's always a good thing to put into the market. And I. Yeah, you know, that's my again my netw way of dim wit way of trying to look at it just like it makes you look good. You might as well share.

**Ray | 41:14**
Yeah, it definitely has. The whole left-right says this is cool, and the middle says this could be a product that could be, but blah, right? I think this screenshot goes on LinkedIn, this is great. This is telling a story about you. You can make a video where you're describing how you do this, and this gets to Robert's point of, it's just selling more of you and being the thoughtful person they want to work with. You're answering the right kinds of questions.
It's just improving your credibility, right? As a competent, thoughtful person. Not only that, you're taking the biotech stuff, but wait, you're doing it with AI. I love AI, and I can see that being a pretty useful stuff.
I think this is great, and I think to Robert's point about swimming between islands and what the nearest island you can be putting this thing on is so you can be getting some profit from it.
Then to your point, if there's a next step of how this thing can be delivering value for you, fantastic. But if what this thing does is generate inbound sales for you, then it's doing its job, and we don't need to go to Lilly, I think.

**Ellie Rofe | 42:32**
YP okay, have [Laughter] sure, yeah.

**Ray | 42:36**
By the way, this was fantastic. My reaction is that, man, I want to throw one of my presentations through this. Yeah, I'm looking at it, it's fantastic for that, the kinds of people who you and I think the people who you want to read it and the way in which you want to read it.

**Ellie Rofe | 42:47**
I mean, it would be pretty confused if it wasn't a fundraising pitch at the moment, but we can definitely create one for other presentations as well.
It is fun to look at. I see it's helpful. Okay, have this.

**Ray | 43:12**
This screenshot is just brilliant.
It's great.

**Ellie Rofe | 43:17**
Okay, fabulous, I will get a post together as our call finishes. Cool, and then I've now forgotten the other questions. I had these ones written down, and obviously, I've forgotten the others. One question I wanted to ask is if anyone... I saw that you had a chance. I didn't know if everyone had a chance to look at that, Daniel Priestley.
Whether that seemed like Daniel Priestley actually is when we talk about videos. He's obsessed with models and frameworks and foundations, so he wraps all his ideas up into models and frameworks and stuff. Which is why I think he does end up quite quotable, partly because he's done the work to create those... He's done that thinking time and those processes and evolution.
I do think he's always got an interesting model that he's sharing to do something with. I was intrigued by his thoughts on that as a sales pattern as he called it. I don't know if everyone had a chance to watch it.

**Ray | 44:23**
You mean situation, magic wand, obstacles in the middle, and then the one, three he had for how you go over that.

**Ellie Rofe | 44:28**
Yeah.

**Ray | 44:33**
Yeah, I thought it was fine. I... It reads like other sales conversation frameworks I've seen.
I think the biggest thing is to have one. That was the broader point he was making in his presentation, the importance of treating this as a profession and therefore treating this as a process that you are executing on, as opposed to just flying by the seat of your pants and using the client's half hour poorly.

**Ellie Rofe | 44:57**
Yes. Yeah. Okay. Interesting.

**Ray | 45:04**
The, go ahead, sir. Yes.

**Robert | 45:07**
No, I was just going to say that, basically, I apologize because I was just about to watch... I haven't... This is... I don't know enough really to say anything about the person because I've just literally Google his picture right now. When you were talking...
So I don't know anything about him, but I can just say that I think it's good to find... For me, Ray had mentioned somebody once, Dan Sullivan. I think that with all of those people, they're almost like... I just watch a bit, and then if something catches me or if their communication stuff works for me, then I'll...
I'll end up going for it. I've read this thing once where they said that, like, if you want to just get the most out of, you know, particular content, you know, or a person who speaks online, just watch like ten hours of their content, and then by then, after the ten hours, you'll notice that, like, they just start repeating themselves, basically.
So then you're and then you're good. So, I think, yeah, like I if probably that's the same way I would approach this for me personally and cli like I would, you know, start to listen to Danance. This is his name, sorry, Daniel Priestley. Just changing screens and then.
Yeah, like, but this is how it starts for me. It's just recommendations. So, yeah, I will look into it and I think the only and maybe my point is that the only difference maybe between them is just their communication styles, like kind of how they work for people.
But they're. But even though they're all kind of saying the same thing. I always appreciate the way that they put it, right? Like in the way, in the words they use and the frameworks. Because I feel that it is a part of the way that it feeds into my own thinking and the way because I'm in the business of giving advice to people.
So it play it becomes like tools that I get to deploy. And so yeah, like so appreciate it, I appreciate it from for myself.

**Ellie Rofe | 47:19**
Yeah and I sent there's no requirement, it was just in case it's useful. I absolutely agree. Having spent a lot of time watching and listening to various gurus, especially because marketing is there's a thousand and one opinions, and sometimes they are...
Marketing is awful a lot of it's just old stuff dressed up in new clothes, and everyone finds a new model. So, absolutely, I agree. I think in the marketing world in particular, there are a lot of gurus selling stuff that worked for them yesterday. There are a lot of gurus who sell a particular process or a particular tactic.

**Robert | 48:10**
Marketing to marketers it's like endless cascade of marketers.

**Ellie Rofe | 48:12**
Yep, yeah, and like, yeah, and that cascade is just dripping with slime as well.

**Robert | 48:16**
This market is all the way down. It's a bubble.

**Ellie Rofe | 48:21**
So [Laughter] yeah, it is absolutely.
Finding people you resonate with. And I find Dan, less sort of sleazy hard seller, more like he's very entrepreneurial minded. He's obsessed with building long term value as well. Not just, like, let's treat people like ATMS and just get some money out of them and then, you know, disappoint.
So it's always interesting to find that right person for you. Absolutely.

**Robert | 48:57**
The.

**Ray | 48:58**
The sales process, I thought, is and thinking about salesmanship as a discipline, I think has a lot to be said for it. Priestley, if you're into Priestley actually in Oversubscribed, I think he does this well where he talks about demand generation as being key to the party, which I think is largely correct.

**Ellie Rofe | 49:20**
1.

**Ray | 49:21**
The are other good resources along these lines.
I think going into these conversations with a plan and a hook through which you can both qualify the lead, right? Is there a discrepancy between their current state and their intended state?
Then, being able to identify whether you can help them and then if you can, it's being able to explain the process between here and there. I think when we're doing professional services, the idea of "Is there a pain actually" becomes far more important than the structured process of "Here's our 123 for solving it" because you don't really have a super-repeatable process when you're selling it at the super high level. You're saying you want to lean into... You are a special snowflake, right? You have problems that nobody else does. I get you in a way that nobody else does. This allows you to provide the thing that will probably justify a relatively high rate and is very pleasing to their egos. I tend to think that a lot of what Priestley talks about, when he talks about his entrepreneurial approaches, feels a little bit more... Ten years ago, he talks about building up the practice in 24 Assets, and he gets to a...
Well, you're going to have a whole bunch of people and they're going to be repeating your stuff, right? It's like the Michael Gerber theory, right? You have so many SOPs, and that's going to be turning more into your business. Whereas I look at it. Who's the person that I admire? In this David Macer, I don't know if you've ever read any Maister stuff, but Maister is probably the guru of consulting, right? There's a guy named Alan Weiss who's a million-dollar consultant. He's more for us.
So, we're entrepreneurs a little bit more at the level that we're at, but if you want to think about it, okay, how does McKinsey operate, right? We're at that kind of level. That's where this guy David Maister is.
The reason I bring this distinction to the party is that both those that talk about high-end professional services talk less about repeatability and more about identifying the pain and the value.
Because by doing that, you know, one of the things that Weiss will point out is that when you do that, you're focused on the high value for the customer. It's a lot easier for you to charge a higher rate for them too, which then makes it easier for you to actually deliver a really high value and just keeps the positive wheel turning.
This seems to happen both at the individual level. Like Weiss can sometimes come across as a bit of a hustler, whereas Maister has been almost academic in his approach, studying how these other consulting firms have worked.
His master book is managing a professional services organization, and the approach she has to talk about three different types of engagements. This is all stuff that can be talked about more,
but the idea that there's a difference between high-end professional services and the kind of repeatable, for lack of a better term, slop that I think is a lot of where Priestley's clients are, if not Priestley himself, is worth giving some consideration to because I think at that higher end, there's more money in it. The clients are higher quality,
and I don't know, I get much more of an intellectual kick out of that level of business, and I think you probably will as well. I bring all that stuff up because this difference in how cookie-cutter the offer is, where the difference is understanding the pain part, the opener that is very much constant, and I think becomes where a lot of people fall off is trying to tell you all about my offer, right? As opposed to really trying to understand either their pain or their ambitions so that you can figure out how you and your competences are going to slide in to be able to help them either apply a balm to the pain or achieve their ambitions.

**Ellie Rofe | 53:26**
Yeah, I mean, I always find myself a bit torn on these because the end product when you're doing a pitch deck is always a pitch deck. So my solution is not going in there like a management consultant and finding ways to revolutionize their business on that level, although by the process of going through the pitch deck, they might revolutionize their business. But.

**Ray | 53:52**
I yeah. I was just gonna say that. I think you are overstating the vagueness of the way a management consultant would come in.
I think you're understating the complexity and bespoke aspect of what you're doing because your end game is not a pitch deck. Your end game is a successful fundraise. Just like your corner of this is largely expressed through the pitch deck, but the pitch deck is only successful if it leads to the other thing.
That other thing is really what you are selling them on, and that's what you are delivering to them, or at least you're helping them make progress towards that because that's their ambition. Their ambition is not to have a pitch deck. The pitch deck is a tool.

**Ellie Rofe | 54:36**
No.

**Ray | 54:37**
They're actually meeting their ambition, which is to be doing the fundraising, be able to build the big business they want to make.

**Robert | 54:47**
I just want to throw in there that whatever it's worth, that because we're all connected on LinkedIn and everything, that I think that would be an angle that you should probably incorporate just based on...
But because of the fact that again, just from my corner of LinkedIn, from just where whatever I see from my corner, if I think of what has been posted about, I think more of a pitch deck than getting to
achieve your fundraising goals. So if that's what it is, which is to achieve your fundraising goals, it seems like a bigger goal, right? Or whatever, right? It just seems like it's not a... It's a matter of something else to market, you know? Obviously, you'd know better than I would. Do you know what I mean?
But I think that there's a message in there.

**Ellie Rofe | 55:40**
Yeah, I think maybe I'm holding off on that because it's a while since I've helped someone actually raise funds and now we're in a... It's a much tighter market, and in this market, I'm always torn, and maybe this is a limiting belief I have. I feel like the biotech market in particular is very much... As I say, they're reserved. They're very risk-averse because all the risk is already going into these massive long processes and high failure rates and stuff.
They're all scientists, but they do all want raises as well. So it's like, yeah. Am I just shying away from it because it feels grubby? Not grubby, but it feels like a lie to me. Or is it that I'm just.

**Robert | 56:32**
It's them who wants to raise, right? Like.

**Ellie Rofe | 56:36**
Yeah.

**Robert | 56:37**
And. think, and I just want to mention that a lot of these people are, I'm assuming, just like anything else, motivated by themselves. They're trying to close themselves on this idea. A lot of the time, you can't even talk them out of it because they want to do it so bad they're going to do it either with you or without you.
So I think maybe just from that point, you're not going to really convince the company. It's like, "Hey, you should." That's not the goal. At least to go... They just introduce the idea to them from zero that they should be somewhat of a situation where they're looking for this already.
Then the ball has already rolled for you. yeah.

**Ellie Rofe | 57:16**
Yeah, okay, no, this is a really nice reframing. It's making me think a lot. Okay, I'm going to re-review this transcript because we've come up to time, but I think that is a really useful insight. Now, for me to go away and create more desire-based content?

**Ray | 57:41**
Well, and that's the reason why we're going... I mean, that's part of the whole FC survey and all that business as well. You're already going down this road here. I think it's just sort of a matter of like, wait. Hey, here's how I can be, you know, getting more value from it sooner a closer island to use Robert's previous analogy.

**Ellie Rofe | 58:02**
Yeah, I need to keep that analogy in mind in life in general, I think.

**Ray | 58:06**
[Laughter].

**Ellie Rofe | 58:06**
[Laughter] So it's less time flapping around in the middle of an ocean.

**Robert | 58:09**
Me too. [Laughter] I should keep it in mind too, believe me.

**Ray | 58:16**
Not Robert. I actually thought that was a really good analogy. And as we were talking about, repurposing this, these conversations, looking back, "Hey, what are the things that Robert said that were really useful?"
Because I think that would actually make for pretty good content. Because I think it's very practical and it paints you in a really good light as well, how you can be either cut a short video about that or writing or whatever.
But I thought that was a lot of wisdom in it.

**Robert | 58:49**
I would put it down for sure. There'll be a post, thank you.

**Ray | 58:53**
All good, everyone. It was an absolute pleasure getting to work with you today. We'll meet you all at the end of the week and we'll see you again next week. Take care. Bye.

