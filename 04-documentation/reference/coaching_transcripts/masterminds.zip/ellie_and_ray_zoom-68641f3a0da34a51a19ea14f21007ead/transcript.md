# Ellie and Ray Zoom - Aug, 22

# Transcript
**Ray | 00:03**
Hello Ellie. I apologize for being late for you today.

**Ellie Rofe | 00:08**
Sorry, I'll say okay, can you hear me?

**Ray | 00:16**
I can hear you. I've heard you just fine all the way through.

**Ellie Rofe | 00:20**
Okay, cool. My, I think my little martial speaker might be blown, which is devastating. It was this little cute thing that I yeah, anyway, how are you.

**Ray | 00:28**
Why are there people there? I am well, and I was opening with an apology for being a couple of minutes late to our call.

**Ellie Rofe | 00:42**
At all?

**Ray | 00:43**
I appreciate appreciate.

**Ellie Rofe | 00:43**
It's very unusual. I assume there's a good reason.

**Ray | 00:44**
I really am sorry. Go on, please.

**Ellie Rofe | 00:48**
Now, what are you going to say?

**Ray | 00:50**
I was only going to say thank you for the very thoughtful weekly report.

**Ellie Rofe | 00:55**
Pleasure, yeah, a bit more useful than random scribblings. Last minute.

**Ray | 01:03**
I think it's... Yeah, and I saw the stuff you dumped in very at the end, and we'll talk about it all, but I just wanted to open with that. It was a delight to read because it gives me a window not only into your activity allocation but into your thinking and that which lets me be more helpful, but lets me just delight and gain. See how your mind works.

**Ellie Rofe | 01:27**
[Laughter] Or doesn't, as the case may Yeah, no, it's been... I think it's been a good week. It's certainly been more energizing than some of the weeks I've had that felt flat.
I think, between speaking to people more and moving more, I am feeling much more alive, as it were, which is really good.

**Ray | 01:50**
No. Yes.

**Ellie Rofe | 01:59**
And is so interesting. Having conversations with people really is...
It's still like... I still often find that when I'm talking to people in this industry, there isn't the same immediate sympatico I have with some groups, but it's still fine. I'm going to just crack on with it.
Because I could offer a lot. So I'll just keep goingm.

**Ray | 02:33**
I think that's right. The whole thing about immediate sympatico...
If you're feeling the immediate sympatico, then there's no difference that you're bringing to the party.

**Ellie Rofe | 02:42**
This is true.

**Ray | 02:43**
You that doesn't mean you need to be going where you're not wanted or something, but that bit of friction or difference from where you are versus where the other folks are, that's where you're creating value. I was just talking to Demetrius earlier this morning. We did our coaching call, and he was discussing the call that he had with you.
You talked in here about, "Am I overstepping or whatever?" I think it's fantastic because I'm pretty sure the conversations he had with me, plus the conversation we had with you, added to him being one. Go talk to Demetrius.
For me, the mission is not like, "Hey, I've got these ideas and you should go implement those ideas." It's to get your juices going and be finding the things that are going to be most valuable to you.
So I appreciate it's an investment on your part to be having conversations with you, and I'm glad that you're getting energy out of it too. But the fact that they are talking to you and they're getting ideas that are not just sympatico with the ideas I might be sharing is getting them to think about...
Okay. What is their third way that allows them to take the reins and lead their business forward, not from having to start completely cold but having some ideas, and now decide to choose among ideas as opposed to invent something from whole cloth or just play follow the leader? Leader is such a massively bare position for them.
I'm so glad that your conversation with them afforded them that opportunity.

**Ellie Rofe | 04:07**
Okay, good, as long as you're cool with it. Because I didn't actually... It was just a response that if they ever needed a help at hand. Then when I started speaking with them, I was like that they have so much to give and they just keep getting stuck on who they're talking to.
It is one of the hardest things for early-stage businesses to work out.

**Ray | 04:31**
Sure.

**Ellie Rofe | 04:32**
But if you don't work it out.

**Ray | 04:33**
No, there.

**Ellie Rofe | 04:33**
It's just all much harder. Okay.

**Ray | 04:38**
There's a risk I'm finding in these coaching sessions as I've sort of, you know, evolved this in the course of the last, you know, nine or ten months I've been doing this stuff. The, like the first session, it seems obvious there's action, right?

**Ellie Rofe | 04:52**
H.

**Ray | 04:52**
But then what happens when we don't take the action? If they don't take the action, we start talking about what's the follow-on idea to the action. Now we're talking about steps 23456, which they haven't taken for things for which they haven't taken step one.
There's a disconnect, right? So it's actually really helpful to have a separation in conversations about, "Okay, what's that next step? Five steps ahead versus what just needs to be today."
If they're having conversations with you, they're like at that kind of strategic club, which are very important for figuring out what to do today and if I can be. And I'm sort of now reverting one thing I've been doing the last couple of weeks has been reverting a bit to what's the next hour, right? To finding those parts.
Okay, there's some parts are going really well. They're making a whole bunch of, you know, thought leadership content that's fantastic. They're not talking to the customers. How do we get them off that mark, right?
And the it's I want them to have the outlet for thinking about the five steps ahead. And I want them to have, you know, the. But the call to action. And same thing for you and same thing for me.
Like we all do it right there. There are parts where we're, you know, analyzing lots and thinking about it lots. And I had the phenomenon with actually with all my children, where he was talking about the thing he wanted to build in VR now, building in VR takes some time.
And what I was discovering was he was bleeding off all his creative energy related to the build by telling me about it.

**Ellie Rofe | 06:10**
Yeah. No.

**Ray | 06:16**
And he's going to do it because he did the thing that he really wanted to, which is express it.
He just expressed it with words. Okay, so what I need to do is get him to not talk about it. So he then.

**Ellie Rofe | 06:28**
Yeah, it's really interesting. There's a thing in writing where if you talk too much about a project, you talk too much about a screenplay before you've created it, then the energy just dissipates and there's a.

**Ray | 06:38**
He.

**Ellie Rofe | 06:44**
There's the same thing.
I think they've done studies on affirmations, and you have to be very careful about how you structure affirmations, because if you structure them in the wrong way, it actually increases complacency because something in your brain feels like, "Yeah, I've done that." Even though you've just talked about it.
So it. Yeah, completely sort of, fritters away the energy that's sitting there, that sort of gap that creates that potential, that energy potential. It just goes H it gets fascinating.

**Ray | 07:20**
Cool. So how can we use this hour to help you focus and focus that energy for you to be making maximum progress for you in the coming week.

**Ellie Rofe | 07:30**
Yes. Well, one of the things I was thinking, as I talk more and more with people, I'm aware I have a tendency, they joke about my permanence, which is a silly thing. But
I have a tendency that I forget. As soon as I've spoken with people, I have a really nice thing, but then I forget about people who exist. Not in a nasty way. It's just literally out of sight, out of mind.
I sometimes even with my own mother, who I love dearly, I will sometimes go, "Shit, I haven't spoken to her in five days." Just because the days have disappeared or whatever. I don't know. I suppose partly... What I'm thinking is, how much should I regiment or put systems in place for this stuff versus just keep in motion and let things happen slightly more organically? I hear two different versions.
People are like... I have a process where people get surfaced every month if I haven't spoken to them. I get in touch with them, and it keeps me in pace with people. I'm part of me who likes that,
and part of me thinks I'll be overengineering It?

**Ray | 08:38**
Well, the once a month thing is nice because you're not making...
You're not spending every day on the engineering or the process stuff. You get to spend most days on the creative stuff, and then you have the one day a month that you're taking care of your things.
It's kind of like Mike MCALLOWITZ's profit-first model, which is all predicated on spending one day a month basically doing your bills and the accounting and then all the rest of it. Just don't worry about it, because it's...
So I like your idea of... Most of the time you want to be focused on the stuff that makes sense for you. There's something where, "Hey, I can help." "Hey, what about having an agent running for you on a daily basis?"
Okay, meetings and looking at your meetings, looking at your emails, and then being able to even just surface for you an email. "Hey, maybe these are things we're gonna do to follow up."
I mean, it could take care of it for you, but just what you're looking for is a nudge, right? Then that might be something that's helpful, but I think in general... I knew this executive assistant who was wonderful, worked for my boss at the time, and her line was, "When you hear someone say, 'I need a filing system,' they mean they need someone to do their filing.

**Ellie Rofe | 09:51**
[Laughter] Right. Okay.

**Ray | 09:54**
So I think about that. When I think about someone talking about, "I need to have systems." Okay, we need... How can you make that somebody else's problem or something else's problem?
One of the marvelous things about AI tech is that you can just express your intent. "I'm going, Mr. Zapier bought or whatever." Here is my Gmail, here is my calendar. Now I want you every day to go look at my calendar and do so instead of setting up an automation.
It's a structure manual, and you can see how well that works. But I think the fact that technology exists and the fact that you had the data in the first place means that you can probably safely focus your energies on that, which gives you the most energy, right? As opposed to our previous point, frittering away on the organizational stuff, you don't want to have that go to zero. We have that too low a level and it causes problems.
But between minimum and some significant level up, it doesn't really change anything, right?

**Ellie Rofe | 10:51**
Yeah, I saw Dan Priestley talk about something.

**Ray | 10:58**
So like, you want to sort of hit whatever that minimum is and then b the maximum U3I find that like.

**Ellie Rofe | 11:07**
I don't know why he keeps coming up, actually. It just seems to be everywhere at the moment. I think that's the thing. He's using AI very well, though.
He had an interesting thing, which is it's a little bit like a Carpathian's human-in-the-loop thing, but he's like, you still need humans to instigate. You still need humans to complete, but the AI can do an awful lot of steps in between.
I thought, yeah, that's kind of... I'm trying to think carefully about it. I've played with so many different AI tools and used and created different AI tools and projects and different ways of using them over the course of a couple of years that I think I'm just trying to refine where I use it and where it's wasting my time or where it's actually becoming useful. It seems like it's useful, but it's not actually being so useful.
So I'm trying to refine those thinking patterns. With this kind of thing, yes, it's much more reliable than my brain at floating things, so that's where it's useful. Use it, and it says, "Definitely, it's better than me at doing something or it can definitely save time." That seems like a great place to start.

**Ray | 12:31**
I mean, the thing that's changed my life the most in the course of the last several years has been County, you know, being able to have a calendar that I can just respond to. Hey, someone wants to meet. We're not going to have a pull back and forth. I'm trying to remember if I responded or if I need to act. No, here's just a link.
Then, basically immediately, the other activator doesn't right and on, and then, "Hey, I have a meeting, great, let's go ahead with that meeting." Hold on. The... So, yeah, there are certain automations that drive a lot of value, and then others are like, "Hey, I tinker with that thing for a while, then I don't really play with that much anymore."
So, what actually drives massive amounts of value for you and takes care of the things that are otherwise hard and ideally hard and boring, right? I think replacing assistant-level or clerical work is where I would start because it's not the kind of work I really want to do.

**Ellie Rofe | 13:21**
YP absolutely. Extracting action points from meetings, for example.

**Ray | 13:27**
Something Krisp as well, right? Yeah, and then I can tie that into a reminder. There are tons of opportunities to start to create more complicated bots about this stuff.
But I suspect a lot of this is... I put it differently: AI is all about data. It is a tech, it's technology that's derivative of machine learning technology, right? It's... That's... You know... And that's the case. The more you hear about these big AI companies needing to spend money on acquiring lots of data, then using lots of compute.
Well, that's you, right? You have your data, and you've got your compute, but the question is what can you get more leverage on? You have data, so you're getting more data, really helps you, like you alluded to this. You said having more meetings makes it easier to write.
Totally. When I'm out on the mountain, doing those chairlift shorts, it's often because I'm reading a book, listening to an audiobook.

**Ellie Rofe | 14:29**
Yeah.

**Ray | 14:31**
And then, you know, I pause it and I cut it short based on an idea that like sort of maybe rift of, you know, meeting or something.
But mostly hearing the books, these things all echo around. And the more I learn, the more I talk to people, the more I read and study, the more I find I have to say. That can turn into cell, and that whole wheel, training care, right?
The reason I bring that up relative to the other is that you're getting more data now, right? The survey as part of that is getting secondary research data. You have your conversations that you're having, and you're pulling those to Krisp to get more of that, all that is giving you more of an asset that you can then apply a layer of AI to. Whereas previously, you had this much AI and this much data, and you're going to find you get more value.

**Ellie Rofe | 15:18**
Yeah.

**Ray | 15:19**
It looks like this.

**Ellie Rofe | 15:22**
Yeah, absolutely.

**Ray | 15:23**
And you're doing that would be fantastic.

**Ellie Rofe | 15:26**
I'm getting that it's.

**Ray | 15:29**
Having more conversations. You have a corpus of knowledge that's building up wherever you do, through the voice memos you do and then transcribe.
It's building up in your Krisp, in the summaries as well as in the transcripts. This is all what Pier Tel calls secrets. This is all information you have that nobody else does.
It's not just information about reading Gene Asimov novels or something. Right? This is you talking business, both directly in the line and just adjacent to what you do with other smart people.
You get to learn more about what you were saying and thinking. You get to learn what they're thinking, and that's all valuable, right? That's the knowledge, reputation, and wealth.

**Ellie Rofe | 16:16**
Yes, absolutely. What do you think I need to be talking about more? I mean, I still need to get better insights from the reports. I was thinking I spent more time on the ingestion and how to manage the data than I have actually getting insights out of them.
But what do you think I need to be talking about more?

**Ray | 16:35**
Well, based on the conversations you've been hearing, what are the... What are the topics that seem to really be clicking with the people you're talking to?

**Ellie Rofe | 16:45**
The stuff that really clicks with the people I've been talking to is the stuff that I have been talking about, which is how difficult it is for scientific leaders to formulate and explain their work.
And that it's a difficult environment at the moment. There's lots and lots of questions about the UK, and what's going on here in terms of funding. But it's kind of... I mean, a lot of it is stuff I'm talking about already, I think.
Then obviously there's stuff that the conversations with the adjacent peers, they really vary. They're interesting sometimes in terms of they'll talk to me about how they've been using LinkedIn or something, which is really nice.
It's the nuts and bolts stuff. But they do have such a... It's a bit like you drew the distinction between, the God, his name's gone, the guy who's like the services consulting guru versus Daniel Priestley. In terms of the target market, it's very different.
So quite a few of the people I spoke to are dealing with production-level biotech companies rather than R&D. And so they're talking about funnels and marketing and direct response and landing pages and all that kind of thing with them.
But the people I'm talking to, that's... I mean, I've talked with these people as well and said, "Is any of this relevant?" Not in that blunt way, but are there ways... We brainstormed with one guy about whether you could do an email funnel for recruiting for clinical trials, right? An interesting idea because you need to educate people and bring in people who might have the condition or their families have a condition, but generally, there's such a split in terms of what they're doing.
The closest I get is the people who are helping founders build their reputation on LinkedIn. Founders rather than whole teams who are selling, but a founder who is trying to establish himself and the science he's working on, et cetera, they're just at completely different stages.
So, when you're talking about the industry, it's still broad strokes rather than getting into the brass tacks a bit. I am trying to speak with someone, there's some crossover, and there might be some ways in which we can work together. She's off at the moment, but she does funding, so she helps people refine the message and connect with the investors, which is obviously where I would be going longer term as I get to know more and more VCs.
So, she's going to be really interesting. She doesn't do the pitch decks herself, so even if that means for the meantime, I help with that side of things, and we carve out how that works for those relationships initially.
I'm getting introduced to more and more people. The beauty is every time you speak with someone, they introduce you to someone else. Or certainly when you speak with people,
I think what I've realized is there are people who are doing a similar thing to me. It's interesting for me in terms of how I'm running my business or how I'm getting clients. It's more to do with execution.
It's useful talking to them, and it's interesting, and they're just decent people. There are people who are connecting, there are people who are dealing with funding, they're dealing with investment on some level, and they might not be the same as me, but there's some level like the guy I chose in New Jersey or the guy I spoke to who works with. He does a kind of real estate, but regeneration like the biotech corridor coming through East Anglia, down through Cambridge into London, Essex, etc. He deals with a lot of people who are investing and lots of people who are super connected in the biotech world because they're creating these regeneration areas in biotech.
So people like that are really directly interesting and useful, and I learn a lot from them in terms of what's happening in the wider industry. So I think I need to try and get more of those as well.

**Ray | 21:17**
That's interesting. People who are at the use of funds level, right? So there's the founder who has a need to do X. You have the investor who's writing checks.
If you can do X, but in order to do X, you're... I mean, the nature of biotech that is capital-intensive and where you're going to be using facilities and what have you, that's where the real estate park comes in.
I think you being sophisticated about all that is one of the reasons I thought the survey was a neat entree here. But you opened this previous little soliloquy talking about how you're talking to founders and talking to them from their point of view, how it's hard, it's not the same as X whatever. All fair enough. What if you could turn around that perspective? What is the investor's view of an R&D level company?
Right? The investors, the higher end, they're talking to these people who are writing bigger checks for these companies. It's relatively well-defined. So those investors are then getting advice saying, "Hey, look at XY and Z, but you don't have that."
So what does it look like? How do you know what creates clarity for an investor? What helps them make a decision of what's a good investment versus not? So that you can be because, sure. Sometimes money's easier to get, sometimes hard to get.
Right? That's but interest rates and regulatory and blah. But there's always cream and skim, right? So how can you be the cream so that they are continually getting you as opposed to hoping that there's enough of a market that you can be skim and still get some piece of that pie?
That's the thing they can do something about, and that you are talking about. So, as I was listening to you, I was thinking there's a perspective problem here. You're talking from the point of view of the founders, maybe in the point of view of your peers.
But what you really want to do is talk from the point of view of those who they are, who they perceive to be their betters, right? Then, because I think of myself as looking up to the investor. I care what they see and what they care about.
Then, if what you can be doing is providing that, that's moving you to be at the level with the investor, right? You're pulling them up, and I think that... That's just a storytelling thing, right?
It's just a perspective, and it's because a lot of the same basic things are true. It's not like you've got different counsel to bring in each of those two cases. This question, "How can they hear
that?

**Ellie Rofe | 23:54**
I think that's where I want.

**Ray | 23:55**
That? Yeah. Then get this. Problems off.

**Ellie Rofe | 23:57**
Yeah, no, you're right. I think that's where I need these. I've been trying to get the working prototype, which has slightly faltered this week, but I want to crack on it this afternoon and tomorrow morning and clean it up to have something to go back when I prompt the Biotech Industry Association to have a little like. Just so you know, here's a little prototype of how I think the report could look to prompt them to then get the introductions because they've gone a bit quiet. I thought they might in August, but I want them to pick up.
It's tricky to get in with investors. So, the one thing I had a couple of people say was, "I could introduce you to this VC." Then go, "No, we're just in the middle of doing something with them." The problem with introductions to VCs is that everyone is always wanting something from them.
So, they don't want to burn their powder. They want to keep their powder dry, you know? So, that's where I'm... I totally understand that, because if someone said, "Can you introduce me to Dina?" or whoever, I'd be like, "Well, I don't want to introduce you to people if I don't think it's going to reflect well on me or if I think it's going to compromise stuff."
So, that's where I think if I can put something novel in front of them. So, it's not just me asking, but me offering and asking. So, that's where I'm a bit delayed on that, but I think it's been really interesting. I'm still continuing a certain cadence of calls and introductions and trying to connect with people.
But I think the next week or the next few days, in particular, I need to balance or I need to focus on that and get that out the door, show that person, and then start talking about that more on social as well.
Try and move to exactly what you're saying, which is being able to talk from the point of view of the investor rather than... On a personal level, not just me talking from the point of view of the investor, but me talking as someone who has developed thought, built, shown ways to use data to express things, et cetera, in a different application than Pitchdex as well.
So. Yeah.

**Ray | 26:10**
And then your report starts to become like it becomes a bit of your sales pitch, right?

**Ellie Rofe | 26:10**
Okay.

**Ray | 26:15**
Because, like, "Hey, this is how I'm able to convey a story of whatever." But, yeah, that all sounds right to me. Now, one of the themes I've been working on with both Robert and with Demetrius is the idea of one hour.
Right. So, like, you were talking about something that would take you a couple of days to do. That's fantastic. If you got the clear vision for that, I would say totally go with it. What does the first hour look like for you?
Because that's often the thing that lets either we get some momentum or we don't.

**Ellie Rofe | 26:44**
Yes, I've been trying to break down. I think the first hour looks like just getting on and breaking up all the PDFs, which I've been avoiding, and then pushing them into Vectia, which I've got a little script set up to do so.
That's fine. That doesn't take long at all. That will take 5 minutes, and then start querying it and seeing what it's actually coming back with. So testing the actual retrieval, and I know how to do it. It's ridiculous. I do know how to do it because I've done it once. I just did it with full PDFs.
So it's like that admin obstacle that I think has just made me go, "That's a really big job." But even as you asked, I was like, "It's not going to be less than an hour to get that done, so.

**Ray | 27:37**
Then. that's fantastic.

**Ellie Rofe | 27:37**
Yeah, we'll see how it goes, but yes, hopefully, it'll be done by Monday at the latest.

**Ray | 27:38**
You know, it's not about trying to fill an hour. It's just say, "Hey, what is one thing that can be true at the end of the hour that was not true at the beginning of the hour?" I would say, "I don't think that'd be more than fifteen minutes." Great, fantastic. Let's...
But let's call it an hour and then take their award, or whatever, but to celebrate the accomplishment. Because then you have it. If it's possible, I would love to just see a little demo of that, too, once you...
I mean, do a little screen share or something. I would love to take a look at that.

**Ellie Rofe | 28:14**
I'm going to do some work over the weekend.

**Ray | 28:16**
Hey.

**Ellie Rofe | 28:18**
I think one of the underlying things. I think I need to work out. So I have...
I have historically had this thing about working overnight and I can get tons done and I'm incredibly productive sometimes, especially if I'm insomniac and I just end up working overnight because in my brain, it's quiet time.
It's something that I think I need to be more in control of because when I think about working on the weekends, it's quiet time.

**Ray | 28:51**
8.

**Ellie Rofe | 28:54**
I don't have any meetings. I don't have any expectations. It's just... It feels like it's encapsulated time, which on the one hand is very powerful to know that I can have that level of focus and productivity.

**Ray | 29:08**
Hem.

**Ellie Rofe | 29:08**
But I think I need some little tricks, some little hacks or whatever to go... Well, I can actually just create that for a couple of hours on a Tuesday, even if I've got a meeting coming up. You know, it's not that I can't... There it is.
I know this sounds ridiculous. It's not a conscious thing. There is something underlying, something bubbling under the surface of my brain that just goes. Well, it's lots to get on with today. It's a weekday or whatever, there's no quiet time today, and it's just completely...
Yeah, it's not even that conscious. It's not even that level of consciousness. So I think I just need to retrain some underlying thing in me to go, "You don't have to work like that. You can get that level of peace during the day. You don't have to wait for nighttime just to.

**Ray | 29:59**
Yeah.

**Ellie Rofe | 30:00**
Just a kind of a side rather than a deep, meaningful... I think.

**Ray | 30:04**
Yeah, sure. I think there are a couple of things. One is, I find studying to be my hack to being able to be productive when I'm not feeling like I can be that productive. I find myself staring at the screen, putting things down. Going to the gym with a book in my ear becomes a way for me to make progress without... And then I've got more ideas, and that can be a bit regenerative, right?
From that point of view, that's a hack that I have used for how I can get that back. A second hack that I've used is the NAP. It really helps. I find that we are at our sharpest, or certainly I'm at my sharpest, but I find... It's the principle I have when I'm teaching my children. I teach them the first thing in the morning, and then basically by noon, we're done.
Then I guess I've got my meetings or what have you, but the reason I schedule it this way is because I believe that for the first hundred to 200 minutes of the day, our brains are maximally open and we are ready to learn and think in different ways.
Then as the day goes on, we're getting a little more tired. Right. And so you're the... As goes down, their ability to consume becomes far less. I find that to be true for me.
It's one of the reasons why I get up early in the morning because we've talked about that. It's for being a couple of golden hours, and that allows me to make more progress. I find the darkness and the quiet... The darkness of my... It becomes a cue for me.
I think my brain says, "This must be quiet time. You can actually get this thing done." Then the sun comes up. There's actually a reason. I think it might be a little more productive in the winter because it's darker longer.

**Ellie Rofe | 31:50**
Interesting.

**Ray | 31:51**
That weird does that sound.

**Ellie Rofe | 31:51**
But you see, productivity in the dark is the same thing as me working overnight. It's a sense of almost seclusion, almost like I'm in Weird Al. That means that I'm just purely here now rather than here there and everywhere.

**Ray | 32:10**
And, do the things that work for you. That way... I find the nap can help me too. It doesn't help with the light, but it does help with me being very close to the last time I got rest, and then I get a golden hour after that, and I'm like, "Sure."
But you spent two hours, an hour nap plus the hour of waking up to get an hour of work. Which I think is a great trait because I'm trying to figure out how to get those few good hours of creative work on a daily basis.
Then I'd get carried through by the meetings, right? I'm aware I'm plugged into the meetings, but I get energy out of talking to people. I like it. I think you were largely liking it, although you did talk about how the rectangles and the Zoom things were a little more exhausting.

**Ellie Rofe | 32:57**
It's not exhausting, it's more ephemeral. I think that's the thing.

**Ray | 33:00**
Twom.

**Ellie Rofe | 33:02**
It feels like things pass through, and I connect very much in the moment, and then I'm like, "Woof, it's gone."
It's a bit the same.

**Ray | 33:11**
Ye.

**Ellie Rofe | 33:12**
It's a bit like with science. Once I'm working on a pitch deck, I can tell you I could explain every single facet of the science I'm working on. Six months later, I couldn't tell you the beginnings of it.
It's a real zoom in, zoom out. So, I... That's what I find strange versus meeting people in person. Not exhausting, just dizzying, I think, in terms of it just coming and goes.

**Ray | 33:33**
Okay, more context switching is the challenge. You don't find yourself in that phenomenon where you're having a whole series of 15-minute, especially unscheduled conversations when you're meeting people at a conference or something, is not up.

**Ellie Rofe | 33:48**
No, I think I must have... I think there's something about body language or maybe even scent. I'm quite hypersensitive to smell. I don't know. There's something where I create connections in my brain, not connections with the person, although hopefully, I do, but there's a greater connection in my brain when I'm talking to someone physically.

**Ray | 34:11**
Yeah.

**Ellie Rofe | 34:13**
Then than just seeing the screen.

**Ray | 34:17**
8.

**Ellie Rofe | 34:17**
But I mean, it's not the end of the world. As I said, I think one of the things that I've realized is whenever I start doing something new, it will occupy a far larger part of my brain, not just because it's hard, but because it's novel, and I will hyperfocus on it, or I will find it more interesting for a while.
Then gradually, it will just rhythmically plop into life, and it's not such a big thing. So now I know. When I first started working on LinkedIn, I was like, "I'm going to do it in the morning, and then I won't touch it again."
Then that kind of disrupted my day. Now, I could post something in the morning and walk away and not have any interest because it's not really taking up so much of my brain power or interest.
It is so the thing with them calling it "weight mode." It's a weird... It's certainly a lot of ADHD forums and coaches and stuff that talk about it. I do find it's quite a common thing where if you have a meeting at four o'clock in the afternoon, it looms on some level. Now I have gotten better at this.
So this is where I'm thinking. Combined with the novelty, I will just through reps, through practice, get into a nice, better rhythm with it. Because, you know, meetings at four o'clock in the afternoon and the rest of the day, you just don't get stuff done because there's something there happening later, and it seems ridiculous. People, as I say, people call it "weight mode."
I've got much better at that. All my meetings are in the afternoon. I don't have any in the mornings, and I use that time in the mornings. So again, I think some of this and some of why I need to be aware of is maybe when I'm preparing for these calls, what is actually leverage that I can work through with you?
Because your brain is like... I want to use it the most. What is something that is just a temporary blip? I've.

**Ray | 36:17**
2.

**Ellie Rofe | 36:19**
Maybe as I start encountering things, I need to give it a couple of weeks and see if I'm still encountering them two weeks later rather than take this time.

**Ray | 36:26**
No.

**Ellie Rofe | 36:27**
So I'm just working this out as we're talking. Like, do I need to think about every last thing? Because actually, sometimes they're just novel problems that go away when the novelty itself goes away. Does that make sense?

**Ray | 36:39**
It does in the same spirit as we were talking about before, talking about something bleeds out the energy on it.
I mean, it's one of the great things about morning pages where it helps you work out ideas. But if you have the things... I'm concerned about the let's get back to it list. Do you have a notepad or a
got actually two whiteboards I use for the business and two that I use for teaching my children. But the two for the business I use for... Wait, I've got something I want to do or something I want to be thinking about, and I don't want to lose that idea.
I will put it up on the whiteboard. My other rule about the whiteboard is everything on the whiteboard is temporary. Right? So, no permanent stuff goes up on the whiteboard. Sometimes stuff stays up for too long,
but the intent of the proper use of it is if it's going up, it's coming down. So, that kind of... Wait, what's on my things to be thinking about list? Because those things are up there for more than zero seconds, but the whole point is supposed to come down.
So, I have something I could put a date next to it and then... Wait, hey, that's been a couple of weeks. All right, let's talk about that, or why did I ever put that up there?

**Ellie Rofe | 37:48**
Yeah. Exactly.

**Ray | 37:50**
You can choose what medium works for you. Now, I like using the whiteboard because it's kind of... I like the action of standing up to it and the slightly more painting action of working with it.
The way I can look up and reflect back to me. If working on paper works for you, that's fine. I recommend keeping it non-electronic because the electronic stuff is the most ephemeral and the most worky.
We can cover things electronically because we got the desktop. These multiple windows, whatever we put into an application that we never open up again. As opposed to the notepad that's on the desk or the whiteboard that's on the wall,
these are tricks I use, right?

**Ellie Rofe | 38:31**
Yeah, that's new.

**Ray | 38:33**
They try to keep those kinds of things. One, keep from losing them, right? The other, and this is actually really important, is to keep them from having to take up mind space all the time.
This is for later. How do I make it later? By memorializing it. Now? Yeah, I don't need to worry about I wrote that up.

**Ellie Rofe | 38:57**
Yeah, I have what I call an ideas bucket, which is in my Notion at the moment, and I have not for this. I or I call it the squirrel chasing list, which are ideas I have where I go, that'll be cool.
They come a thousand times a minute. Then I put them in there. So I don't then spend a week working on something that was completely pointless. It was just a real passing hyperfocus that I didn't need to work on.
So I have, and it's what I was saying to Robert as well, everything is just for now anyway. So, any choices you make, any things you do, if you've got ideas, if you've got people you want to talk to, put it in the bucket. Put it in the ideas bucket.
It's not going anywhere. It's not gone forever. Just put it over there, and if it's really important, it resurfaces itself. Really? So, I do have something like that, which is in Notion, that I could try and do on Notepad. I don't actually have a one.

**Ray | 40:12**
Or wherever you are as I do.

**Ellie Rofe | 40:14**
Yeah.

**Ray | 40:16**
Please finish your thought then. I'll make a comment.

**Ellie Rofe | 40:19**
No. I see what you are saying, Carva.

**Ray | 40:22**
All I was going to say is, if Notion is what works for you, I wouldn't discourage you from it. I just find that when I...
I've got lots of Notion pages. I was sympathizing with the Notion thing. I have a whole Notion thing called Fleeting Notes, and I will occasionally use it. The best thing I use it for is copying and pasting stuff I've seen. I use it as a swap file, or better yet, as a... I will regret it if I send this draft email. How many memos do I have to corporate executives saying, "I really think you're screwing up here.

**Ellie Rofe | 40:43**
[Laughter] Very nice. [Laughter] Yeah, I do love love.

**Ray | 40:56**
Okay, you know what? I'm going to pull that out. I've got to put it into Fleeting Notes, but I bring it up just because I go... It becomes a bit of a drop rather than a reminder. That's what... I find the reminders that work for me.
You should find what works for you, right? We started the conversation trying to find the path that's going to work best for you. But the path that has worked best for you is to have something front and center.
So, if the Notion thing works for you, that's great. If it's not working, you have a couple of alternatives. You can be given a get-go, take a run at at.

**Ellie Rofe | 41:35**
I used to have a whiteboard. I haven't had one since we've been here since we redecorated this room, actually, so I will have a think about where one could go.

**Ray | 41:41**
No.

**Ellie Rofe | 41:46**
There's not enough all-space in here, unfortunately, but I will have a look because I think it is a really nice idea.
Actually, I think there's a possibility of having that split, and my other half could use it. Things as well, and have a shared dumping ground.

**Ray | 42:02**
Yep.

**Ellie Rofe | 42:03**
Yeah.

**Ray | 42:04**
And the modern whiteboards are nice too. They're lightweight, they're magnetic, they erase. Well, if you, like me, have been using them for a quarter century, then it's like, "Hey, wait, this is not the same as the Quintette whiteboard I bought way back when.

**Ellie Rofe | 42:21**
Go. Here we go.

**Ray | 42:24**
That was heavy, and it was...
Then it would just get marked up, and you could see what you drew on it last week every time you're drawing out this week. But anyway, I'll... Which, by the way of saying that... Yeah, whatever. That works for you.
I think that release is just so valuable.

**Ellie Rofe | 42:44**
Yeah, I think just, my nan used to say... But I think sometimes just saying this too shall pass... There are certain things that I'm... When I start doing something, it's all exciting, new or different or somehow not quite titillating.
But there's something going on where it demands my attention or it drags my focus. And knowing that, to be honest, most things involved with a business will gradually lose their luster. The things that don't are the things that are great.
I do like talking to people. I do like doing sessions like I did with Dmitri, Robert, and a Pillo tech. So the things that are sustainably interesting or sustainably interesting Arget and other things that you maximize for, and then everything else, you can just go, "Let's not put too much effort, not too much focus on that." Let's find ways to minimize the focus on that. I think.

**Ray | 43:44**
With our bit of time left, how can I be of maximum service to you in the coming week?

**Ellie Rofe | 43:50**
I was actually going to ask... I think it's possibly a simple answer, but I had a call with Pillo Tech, who were really interesting. Frustrating on some level, I think.
I think the CEO is pretty knackered, and I think he's possibly lost a bit of fight, but... So it's just sitting slightly uncomfortable with me, and I don't know whether I just make my... Just record my thinking on it in an email and leave them to decide. They're talking about spinning out because they've got two different assets in two different areas and talking about spinning one out into a new company.
I said, "So you'll need to do that before you raise because, obviously, this other asset..." He said, "Well, no, I don't think we've got time to do that before we raise, so we'll just have to spin it out afterwards."
I said, "But isn't that going to complicate things with the cap table? You've got investors. What are you going to do to the investors who invested in this company, and you're spinning something out with an asset that's in the company they invested in?"
He said, "I'll just mirror them." I said, "We need to raise funding to develop that asset." So you're going to have basically Ghost Vector A sitting on the cap table who don't have anything. They haven't invested anything in developing that asset.
He went, "Yeah, we'll sort it out." I'm like, "Where does your responsibility start and end as a consultant?" I guess it's for me to tell you. I know where the pitch deck stands, but the whole strategy around their fundraising is just... "We'll sort that out later." Do I just register that I've registered it in a call? Do I just register to them?
Please get some advice on how to structure your bloody company so that you're not creating huge problems.

**Ray | 46:07**
This is the company you're doing at Onspack, right? I think you do Onspack for two reasons. One is the practice, and second is the win, right?

**Ellie Rofe | 46:18**
Yeah, no.

**Ray | 46:20**
I would propose that you do not want to be associated with a loss.
So my question to you is a little bit less like, "Are they taking your advice and more, "Do you think that they are at risk of having a loss as a result of the stupid way they're managing their Cap"? Deal?

**Ellie Rofe | 46:44**
I think he's on holiday next week. I think he looked knacked. I think he has been struggling on this alone. I think the guy that he had in the call with us is very aware of it and has been trying to make the same points or similar points to him that spread too thin. My biggest concern has been doing a ton of work on a pitch deck when he doesn't have a proper fund.
He hasn't thought strategically about the raise. That's why I've been trying to make him think. So I guess I think it slightly depends on how he comes back from holiday as to whether he is re-energized and thinking about it and addressing it.

**Ray | 47:37**
Then the right... We're getting closer to your answer here, right? Just say you need to go on his holiday, you need him to come back. You need to see what he sees when he's got clear eyes, what he sees was he wants and was he ready to do.
That tells you whether you're going to be associated with a winner or a loss. If it's going to be a loss, then the question is, "Are you getting enough value from the practice?" Right, to be willing to deal with being associated with this loss for longer because you're longer associated with a loss.
So the process of heading into a loss is usually known. Like you've seen those political campaign retrospectives, right? Whereas the winning campaign is all about their brilliant strategy and ideas, their get-out-the-vote.
Then when you read about the losing campaign, it's all about a knife fight. Now they're all trying to undercut each other. Whatever. It's like for the change of a small number of votes, you will just reverse the two stories, right?
It's the same group, but the vibe just changes, right?

**Ellie Rofe | 48:32**
Yeah, that's absolutely where I was trying to point out or what I was trying to point out, why would anyone go for this?

**Ray | 48:36**
Whether hanging towards win or hanging towards loss. So I think there's a... You want to be associated with wins, and you want to be part of the win.
But the way I put it sometimes is I don't want to be on the rocket ship. I want to help build the engine, and then I want it to take off, right? What I don't want to do is work on something or even have a seat on something that isn't going to break orbit.
So, when you look at it, you're like, "Hey, this could be successful, and I think I can contribute." Those two things are what I think would be most meaningful, right? In terms of getting the engagement going.
So, what you're looking for is a read on the first, on BA, both those things, right. First, whether it can be successful in the second, whether you think you can have influence that will help them achieve the kind of success that they would want to achieve. My intuition, based on your description, is that anybody who can read a cap table would say that is madness because you're looking to make the simplest possible investment. The person has an investment thesis. I want. I'm putting money against this to advance my investment thesis.
If you're saying I'm your advancement thesis plus anything else, you are severely diluting the value of me spending either my capital or, worse, my time. Because my time's even more limited than my capital on pursuing this deal.
I'm looking for reasons to say no.

**Ellie Rofe | 50:17**
I will revisit with him the other question I had, which is slightly more like something I feel I should know, but I've realized I just don't, and I don't know if you do. I was introduced to this by one of the board members who is an angel investor on it, and he's introduced me to lots of other people. He's very well connected. He's a very lovely man. When there is a situation like this, my instinct is I shouldn't tell tales out of school
for my future reputation. I should be protecting the founders' ability to trust that they can confide in me and talk to me about stuff and not feel like I should go running off to the board member.
But obviously, if I pulled out of this engagement, I would have to talk to the board member about why, if I said I don't think this pitch deck is the best in this context, I don't think this pitch deck is right for me to carry on with. Then I think I would have to talk to them because part of the reason I'm doing this is because he said to me, "Well, once I know how you do an engagement, I will be able to recommend you to other people."
So, how? What are your thoughts on that?

**Ray | 51:40**
If you... Well, that's a tricky situation to be in, right? So, I don't mean to downplay it. I do think you first talked to the CEO about it, giving them the best chance to act on what they think is right.
What they think is right is... We're just going to do this, and we'll just sort it out later, and you can say, "All right, that's fine." But sort it out later isn't what I do, right? I appreciate if you've got the relationships that would allow you to make that kind of progress.
I think that's wonderful, but probably means you don't need to be spending the time on the fishtack because that's clearly about personal relationship stuff. So, rather than having you spend time on the part that's not going to help you make progress,
I think you should probably spend time on those personal relationships. So, my proposal is that maybe we should just not work on this until you get some different counsel about that.
Then I'm glad to have this conversation again, right? You never say no or goodbye, you say, "See you later." Investors do this, too, all the time. They never say no, they say later, but the right way, and you can do the same thing.

**Ellie Rofe | 52:50**
[Laughter] Seven months later.

**Ray | 52:56**
Of course, maybe later always means no, right?
You need to learn how to say no. I can't tell you how many people, how many founders I talked to, we talked to the investor, and they loved it, and they said, "Come back to us when you have traction." I'm like, "Okay, well, that's there.

**Ellie Rofe | 53:09**
[Laughter].

**Ray | 53:11**
There's a seven-letter summary of that that starts with F and ends with off.
But anyway, you can use that somewhere, it's nice to be laying them down. Then you go talk to the board member, and you can explain and basically use the same language you used with them.
So, look, you looked at... I think you think the pitch deck is the limiting factor here. It looks like there is a corporate structure issue. The CEO seems quite committed to the corporate structure and seems quite confident that relationships will allow them to do this.
But I've been in these situations before, and if the corporate structure looks like this, I don't think the kind of investor who's looking for the storytelling is going to respond well because the story itself won't be clear because now they're investing in two companies, not one.
This guy has a vision, right? I'm not here to undercut that vision. So, having done that analysis and having had that working relationship, that's where I left things.

**Ellie Rofe | 54:09**
Yeah.

**Ray | 54:14**
And, I don't know if you couldn't make a pitch deck. I'm like, "Okay, fair enough, but that's... I think you being able to explain why they don't need a pitch deck is the critical factor." Then, the good counsel you can give to the other... Okay, I hear what you're saying. I can't believe he's doing that with the corporate structure.
Fair enough, but corporate structuring is not my area of expertise. I understand you have a CFO, you've got your own expertise on that, and that's great. My read on it is that it just means that has the downstream effect. This is probably not what this guy needs.
I'm bummed that I don't get to work with you on this, but I'm not looking for his time. His time is worth even more than the money. So, let's make sure he's spending the time on things that are going to be most important.

**Ellie Rofe | 55:06**
Nice.

**Ray | 55:07**
And your contact will either appreciate that. That level of attention or. Or he or she won't. But I think that level of attention is what makes you can be nice about.

**Ellie Rofe | 55:17**
Yeah. I think Marx will just know exactly what I'm saying. He's worked in equity research for years, I think. Yeah, I think he'll know exactly what I'm saying.

**Ray | 55:28**
I don't think you need to use lots and lots of words. Don't need to waste time with it because he'll get the signal very quickly.
But, you know, you don't need to be throwing the founder under the bus on it. But I do think you don't. You do not need to waste your time, his time or the investor's time if you don't think this is going way.

**Ellie Rofe | 55:48**
Yeah, okay, that sounds good.

**Ray | 55:53**
Fantastic.

**Ellie Rofe | 55:54**
Thank you very much. That's really helpful as always.

**Ray | 55:56**
I'm glad it's your hot seat, I think, on Tuesday, so we'll look forward to that.

**Ellie Rofe | 56:00**
Yes, I should be dazing.

**Ray | 56:05**
And if I can do anything to be of service to you, I'll look forward to just to send me a ping. If you do, you know, get that Victoria query thing going, I would be absolutely delighted to get to see that screen share.

**Ellie Rofe | 56:18**
Yes, absolutely. Okay, perfect.

**Ray | 56:20**
But that's good day.

**Ellie Rofe | 56:20**
Thanks, Ray, thank you.

