# Ellie and Ray Zoom - Feb, 06

# Transcript
**Ellie Rofe | 00:07**
He very well.

**Ray | 00:08**
Hello, Ellie. How are you doing today?

**Ellie Rofe | 00:11**
Thank you. And you.

**Ray | 00:13**
It is turning into a wonderfully gray day. Which is good for someone with my fairer complexion. To go outside without, you know, simultaneously freezing parts of my body and, like, frying the parts that are actually exposed to the sun.

**Ellie Rofe | 00:27**
Very nice.

**Ray | 00:28**
But, yeah, all the good and so excited for you. I really appreciate you sharing the. The good news.

**Ellie Rofe | 00:33**
[Laughter] It just made me laugh.

**Ray | 00:33**
Midweek.

**Ellie Rofe | 00:37**
I saw it and I was a bit confused because Asa had in the title he'd put Sophie Roe because clearly he was talking to someone called Sophie and he's a little bit absent minded. 
And I was like, what's going on here? What is this about who's Rory? And then I saw who it was dressed to, and I was like, wow. Okay, worry, [Laughter] yes, and I re interviewed Alice yesterday and he said, did you see that?

**Ray | 00:56**
3.

**Ellie Rofe | 01:05**
Because I'd. I'd gone to text and I was like, I'm going to speak to him about it in person rather than just be like, over text. And I said, I don't really have heroes, but if I did have heroes. Lorie Sutherland would be one of them. 
And he said, I thought so and then paid me a fantastic compliment. He said, I we have been trying to get hold of Rory Fages. He was meant to give a keynote at the last SDP conference and had a conflict. 
And so Alice has been in touch with them for about a year off on X and he go and touched them again now saying, you know, we'd love to have a dinner. And positioned to William that I should be there. 
And he said, I think it's important because I think you think a lot like him. And I was like, what an incredible compliment.

**Ray | 01:54**
Betty. That is such a nice thing to say about Rori.

**Ellie Rofe | 01:57**
[Laughter] Well, I then looked at some of the ideas I've had for the SDP and I was like, yeah, there's a lot of costly signaling going on here. 
And like, yeah, it's. It's a completely different way of looking at politics. But fascinating. Fascinating times.

**Ray | 02:15**
It is. And, you know, this is a you know, we keep, you know, doing the spade work. And, you know, some oil comes bubbling up, so, you know, that's wonderful. I mean, we don't count those particular eggs, right?

**Ellie Rofe | 02:29**
No.

**Ray | 02:30**
I think, but I think it's survey it's a good market signal, and yeah, sounds like you've got that going. When are you putting up? The. The stair thing? The. The interview?

**Ellie Rofe | 02:43**
I want to. I want to. I mean, there's like two hours of conversation, and so I need to edit stuff because we. So it's been really interesting. And I'm. I'm like going, would I love to learn to be a brilliant interviewer because actually, it's a really interesting skill set and I'm going to have to learn it. 
Just like, you know, talking to lots of people. What I realized in the first 45 minutes of now, Alister kept offering to give me more time. I'd asked him for an hour, and he said, do you need more? I can give you an hour and a half. 
So it was like, okay, fine. He likes talking. And I think he likes talking to me, in fairness, so he the first, I would say, 40 minutes of the original thing, if not longer. I let I asked questions that were a bit open ended and I didn't direct things enough. 
So he was he got very anecdotal and abstract and it was interesting but not wildly valuable, which is fine. I live and learn. And I. And he then called me later that day. He'd had to leave to go on to another call. He called me LA that day and he said, did you get everything you needed? 
And I said, you were brilliant. But I think I didn't quite follow up on certain things well enough. And he said, I can give you another half hour tomorrow. So then he gave me another hour because he likes talking. 
So I was I'm learning lots even just in those two spaces. He's a very associative thinker. He, you know, trips from one topic to the next. He is very anecdotal. He's got lots of great stories, both from his own history, and he will randomly mention Cassius or, you know, Pit the Younger or Pi the Elder. 
You know, like, there's just there's a lot of stuff going on there, and, I put some of the. I put the transcripts into a couple of different AI chats, and I was like, where did I miss opportunities? And I think I've worked out those two things. I wasn't asking questions that I thought seemed stupid or obvious, but actually, I think there's huge value in asking the obvious question sometimes. 
So, like, when he's talking about how he can manufacture an artillery shell and it's basically 33% less than the current shells. I didn't say so that's good. Why? Because it just seems obvious to me, but there is a question to be like so what does that mean for something like Ukraine? 
What does that actually mean for the reality there? What does it mean for the MOD and the Treasury? To me, it's just like, they're all obvious, but I'm leaving and it's what I won't let my clients do. I'm leaving the implicit instead of making it explicit. 
So I learned that and I I think. I think I sometimes just miss. I it's a skill I'm going to have to develop, but as I'm listening to someone talk, I will be interested in just following them along rather than stopping and making them synthesize or go deeper on a certain point so they might skip through three or four points. 
And I'm like, this is really interesting. I'm just listening to them and not making them go right, actually, can you just can we stop there and again make that point explicitly? What do you actually mean by this? How do we, like, dig into it a bit more?

**Ray | 06:33**
Yeah, and you don't need to interrupt, you know, like it's you get to solve all these problems in the editing bay. And so say, all right, you we just talked about three things, right? Let's go deep into each of those. 
And that becomes part of what you need to be doing is you're that's why you're doing contemporaneous note taking. It is like it's as interesting as the story is. Your job is to figure out. Okay, what problems are there left to solve? 
Because. You can. Go. Listen to this.

**Ellie Rofe | 06:57**
Yeah, and that's yeah, I think it's that sort of learning to, you know, pat your head and rub your stomach. I'm get I'll get there. I'm not there. And I think that that's fine. 
But it was really interesting. And, there's I think I realize there's a conflict somewhat. It's not a conflict. It's not an either or, but it's something that I need to manage properly in my own head as much as with the guest, which is I need to dig deeper and as an interview of my role is to help the audience get really interesting insights and useful things from it. 
But sometimes when you're digging deeper, and this is probably where I just have to give people veto rights on stuff because I'm not in like I'm not in a news interview, journalist trying to get gotches or anything. The last thing I want to do. 
And this is what I struggle with on my portfolio. So it sort of links in with everything I struggle with when I'm helping someone with their strategy on their pitch deck. If I'm talking about that in a portfolio, I don't want to make. There's a really fine line between making the founder look stupid or not stupid. 
But like, they've got great big blind spots that they haven't worked out, you know, and obviously, as a strategist or whatever, that's my point is that I help people with those blind spots. But these people are building a company or building a reputation or whatever. 
And my job is to help people build things. So I don't want. I don't want to be asking questions that would damage that opportunity at all. So like there's really interesting questions to ask ASA about the Ministry of Defense and their procurement process. 
And. And what we talked a little bit about he talked about Mesopsy, which I'd never heard of, but basically a single buyer, not like and that was really interesting. And what that does in terms of the supply chain for the buyer as well as the suppliers. 
But I think I held back from asking him certain questions because I know that he's in negotiation with the MOD and I didn't want him to end up, you know, I didn't want to put him in a position where he was scuppering his negotiations with them by criticizing them, you know, very openly or whatever. 
So it's I think that was a it's not anything really to do with AA that was a little brainworm in my head that was altering how I was interviewing him. And I just need to be more conscious that I can ask questions. Tell them they can get rid of the answer. 
You know that we can cut that if they feel like they've gone too far. But I shouldn't be restraining myself when I'm asking questions.

**Ray | 09:55**
I think you can give them veto. And of course you can send them copy of recording. They won't even look at it most of the time. So the. And then, you know, I think a lot of it is just you. You will look better when you make them look good, right? 
Because what you're trying to do is make them more thoughtful and more incisive and, you know. And a journalist, a bad journalist, right? Makes a story about themselves and about how they were able to get their subject right. 
It's like classic Frost Nixon stuff, the. But a good journalist or a good, you know, interviewer, you're trying to get the maximum from that person, right? And the maximum for that person will make that person look smarter. 
Maybe it'll make him look edgy. Right. Like. Patel. Right. Recently had an interview with, Carpathy, and he got carpathy to talk, you know, about AI in ways that were kind of, you know, a little sharp bellbowed and that was really useful. Was good thinking from but, you know, create a little bit of controversy. You don't need to go that far, right? 
But the but he didn't do it by asking probing questions or giving the gotcha, right? He did it by just keep on lobbing out softballs. Hey, that's a really neat point. Can you talk about that a little bit more? 
Right? That's, you know, that I have found in my interviewing, right? That the. You know, the my. My biggest friend is silence. Right? And then when they've run out of steam, great, let's focus the question somewhere we have it. Knowing where I'm going to take it after that. 
And then the second greatest friend is the Eding Bay. Because you're not going to use the whole of the interview. I mean, you could, of course, put out the uncut version, but, you know, like, you're. You just want, like, the best bits of it, right? 
Like, hey, you sit down for two hours and you're going to put up the thirty minutes of, you know, which is essentially the highlight reel. And some. It's going to be your questions. And by the way, it doesn't need to be you asking the questions, you know, from the actual footage, right? You can react questions. Which then makes it easier to be using more of their film because, like. 
But wait. That doesn't quite connect to what I was asking before. Like you can just sort of, you know, put that in, but because your mission is still to make them look good. And I think that all sounds that sounds fantastic. 
I think the issue of being too polite. Sometimes people ramble on and on. But that's just cause they ramble on. You just see. More time for those people.

**Ellie Rofe | 12:21**
Yeah, I mean, so Aliister said to me after the first one, ask my wife and she'll tell you I need to be interrupted sometimes. Which made me laugh him in good self awareness. 
And I did interrupt him a little bit more because he suffers from the same thing I do. Which is you start here and then you go around here. And you go around here and when I'm work with clients, that's actually where you often get. You ask them a question, they go around the houses and then they circle back to the answer. 
But that's slightly different to someone who's so sort of free associative. It's more like jazz. So you ask them a question there, and 15 minutes later, they're talking about, you know, how Pitt the Elder Constructed the Civil Service and how that was Destroyed by, you know, the 1947 Accords or something. 
And then you're like, okay, so how does costs plus compare with.

**Ray | 13:09**
[Laughter] So my question was about.

**Ellie Rofe | 13:14**
[Laughter] So I realized. 
I mean, I think he was. He was both a very valuable thing, partly because he is a very clear champion of mine, which is a nice, you know, relationship to have with someone. 
It was a very valuable guest, but quite a challenging one to have on at the beginning because he's not like, I think in neat little captured thoughts. 
It's like we here we go. But yeah, it was goodm.

**Ray | 13:44**
Well, that's fantastic. So I'm looking forward to the I'm looking forward to the pot. And, yeah, that's just all good thought leadership stuff. And then you have a serious person who you talk to that like, hey, this is gives you evidence that, like, you actually have talked to serious people and that they don't look like idiots at the end and they don't look like they waste their time. 
And like, he says something nice about it as well. Then that's

**Ellie Rofe | 14:08**
Yeah, exactly. And then I'm so I think she'll be a very different kettle of fish that Lauren. She's very she's she was doing some stuff at the JPM conference, which is no bad place to be. I think she's got more of a sort of industry profile in that self promotion way rather than Alice to just having lots of connections and experience. 
So that's with Lauren, who I spoke to just before Christmas, who's raising her first fund. 
And I think that will be interesting because I suspect she will be more naturally cautious and. And actually quite compartmentalized in how she talks about things. 
I think she. It will be an interesting shift in. In I'll learn a whole new raft of things that I will have to, you know, be better at an interviewing. But I will get. I'll get to flex a new muscle a bit. 
Yeah, interesting stuff.

**Ray | 15:07**
All right, well, that that's great. That's what's coming down the pike. So basically you have something that looks like it could be turning into, you know, money. They have the interviews going, which is actually very. 
I mean, I appreciate that there's an aspect of interview that's about study, another aspect that's about self. Because if the, you know, this is then useful content, which kind of leads back to your issue about like, hey, what do I put onto LinkedIn or whatever?

**Ellie Rofe | 15:29**
Yeah, I think that's what I got to.

**Ray | 15:29**
The interviews have been messed up. 
You know? Like thiss.

**Ellie Rofe | 15:34**
I just spoke with, I mentioned her in the thing Stacey, who is a well, she's a fractional CFO now in biotech largely. She used to work in aerospace and defense, so I'm trying to tap her up for connections there as well. 
Yeah, I think part with I think part of the issue with LinkedIn and actually where this I interviews idea you had is just perfect is. I think I just keep looking at it and thinking it's you can put ideas out there fine, but I don't think lots of founders are sitting on LinkedIn waiting to read a post. 
And I think partly I am thinking when I promote this thing, I probably need to promote it on X and Substack and things like have a different audience where people are discussing and debating things a bit more. Versus the purely not purely, but largely self promotional, slightly echo chambery vibe in LinkedIn. I'm going to test it. 
And see.

**Ray | 16:40**
Well, the purpose of being out on LinkedIn is having you be thinking about ideas and communicating with the market on a regular basis, right? It's the from my point of view, it's the easy way to get started with that, right?

**Ellie Rofe | 16:52**
Yeahp.

**Ray | 16:53**
And so like the way I actually earlier today, I was doing, you know, my session with Metris, and he was talking about like well, you know, I put stuff on LinkedIn and then people don't DM me asking to do business with me like that. 
That's not actually the pathway. The I think that if what you're doing is you're making your content a level down, right, having very depth to it, and then you basically are stripping some clips up, right to be giving a hint. Hey. Here's where the value is. Never level down. 
And you're pulling them down one level and now they're spending half an hour with you right on the, you know, because you're talking or with Alister in this case, to get more of that. And then you become their gateway to more of that. 
And that's going to be how you are to building up that credibility of people who are coming in that pathway. And that's I think that's all to the good. And you know, we start with LinkedIn because it's immediate contact with the market, you'd get immediate feedback, you get immediate likes. 
That's all to the good stuff. But like now you're in another level up. And I think that's. That's. That's a stronger place for you to be.

**Ellie Rofe | 17:59**
Yeah. Yeah, it is interesting. And I just think the interview content is far more interesting because, like you said, it positions. It's me talking to far more interesting people or more experienced people or people who have ideas that might be directly relevant or new to people. 
And, yeah, I think it feels like a more interesting way to be connecting with people. I don't know, I haven't quite articulated that very well, but it's. I yes. I fundamentally agree, I think, with what you were saying. 
And I'm just trying to, I still need to put stuff out on LinkedIn, but it's just it's always a struggle. It always feels like it's, it always feels like it's not adding much value to the market, and I don't know why.

**Ray | 19:00**
Well, yeah, I mean, like I say, the two things that matter are more frequent communication market and the development of ideas, right? And the so the other that's about creating content and posting on linked in. These two things sort of help with that, right? 
But if you have another mechanism for doing that, for example, if you're doing that through the interview with Alister, then like, what you could do is, hey, let's pull clip from the interview with STER. Hey, that was really cool. 
Like as you're getting into the ending bay. Wait, hey, that was a good minute. Pull that right.

**Ellie Rofe | 19:25**
Yeah.

**Ray | 19:26**
And then that becomes a far more valuable thing you can be putting into, you know, the LinkedIn pipe and that helps you.

**Ellie Rofe | 19:34**
Yes, exactly. I feel like I'm becoming a curator of value.

**Ray | 19:40**
Well, we all are. I mean, like, there there's a well, that's like Plato's theory of recollection, right? Is it like it's there's we're not creating new value, we're discovering the value that was on the surface the whole way through.

**Ellie Rofe | 19:51**
Yes. Yeah. Yeah. But that I think just re [Laughter] you and him.

**Ray | 19:55**
I can. Do you know. Deep references to Alister. 
Sorry.

**Ellie Rofe | 20:02**
I tell you it would never stop. [Laughter].

**Ray | 20:08**
Okay, well, th that's all. Yeah, anyway, why do I bring all that up? Because it seems like you're focusing your attention on the right stuff. You're focusing your attention on like, let's get the interview up. 
I think once you get into the editing bay, you will have material for LinkedIn that will be. That will all get easier for you. Do you have a tool for, like, getting into, like, being able to take those three hours and turn them into, you know, whatever the type is?

**Ellie Rofe | 20:31**
Well, I'm recording them in Riverside, and one of the things I want to do at the weekend is just sit down and see what they. 
Because they do an autoclipse for you. 
They sort of do the Opus Clips thing. But what I want to do is dump the footage into Opus Clips and see which one comes up with more interesting bytees. Because you can direct Opus Clips, if I recall. You can be like, these are the things. This is the stuff that we're looking for. 
And, not sho.

**Ray | 20:59**
Yeah. You prompt, to, you know, figure out what was supposed to pull out using when it goes by the clips it. I find it doesn't okay job of that.

**Ellie Rofe | 21:08**
Yeah, I'm going to just test a little bit because this is a chance to just play around and see what does or doesn't work. And. I'm not gonna. You know, it's gonna. The first bit is go. Going to be heavy lifting. 
It's going to take. Take me a while to get a nice clipped interview. I'm using AI where I can, but some of it will just be manual. And because obviously when you're interviewing a guests, you have to make sure you're fair to them as well. 
And you're not like, just putting out something that doesn't make them look good because they're unpaid. So they're giving their time for free?

**Ray | 21:42**
They are and they what they really wanted is to get a good. Yeah, so the way they get paid is through just getting to look good in your results.

**Ellie Rofe | 21:49**
Yes. At the end of it, he said, I sound more intelligent when I'm talking with you. And I thought that's actually a really nice place to be with people that they feel like you're bringing stuff out of them that makes them feel or look good. 
And so that's sort of a bit of a benchmark. Like you said, making them look good is a really useful thing to do.

**Ray | 22:14**
Yep. You know, the other thing that occurs to me is, I mean, the chap isn't that long. I want to even just try taking that transcript, putting it into Claude as like it, make a project of it and say you have the conversation with Alister Bott.

**Ellie Rofe | 22:28**
H.

**Ray | 22:35**
Just download a lot of.

**Ellie Rofe | 22:35**
So.

**Ray | 22:38**
Yeah. You downloaded a lot of his brain. Being able to ask him what he thinks about XY or Z, it's a just an easier.

**Ellie Rofe | 22:43**
M interesting.

**Ray | 22:49**
I mean, like because you can just sort of dump it in at a system prompt.

**Ellie Rofe | 22:51**
He.

**Ray | 22:52**
It's like it's a not totally crazy thing to do. 
It's something I've actually been doing. My children, we've studying philosophy. That's. I brought the Plato thing, and the I've had them now read the Apology, the Crido, the Fido, the Meno and the Republic, right?

**Ellie Rofe | 23:07**
Wow.

**Ray | 23:07**
So we've done quite a bit of Plato.

**Ellie Rofe | 23:07**
Okay, possibly.

**Ray | 23:09**
I think we've done enough Plato at this point. Right on and the but they were the ones who kept adding books. I didn't have. I over the mio on my. On my list to do. 
And they're like, can we do this too? Okay, anyway, I'll wish. By way of saying that, the other thing that they are really excited about doing is they like to take these philosophers and they dump them into system problem. We use AI Studio over on Google for that because it's cheap and easy. 
And then just start asking them what they think about various issues in world affairs, like asking Locke what he thinks about the Greenland situation.

**Ellie Rofe | 23:39**
5.

**Ray | 23:44**
Gets some interesting results.

**Ellie Rofe | 23:45**
Okay, interesting. I have. Look, I st a good idea.

**Ray | 23:51**
And like, sort of in the vein of, like, stuff you've already been doing, like you're thinking like you've already been thinking, how do you use the AI more creatively, right?

**Ellie Rofe | 23:57**
H yeah.

**Ray | 23:57**
And so I sort of want to give you a, hey, you're doing this thing, what else can it turn into? 
And this idea of being able to use the interview to extract people's ideas, it's something I've talked with Mitch Van Dusen about that he's never really followed up on. But as you get to be a good interviewer, you know you can be. 
Yeah, then using the product of the interview, I mean, partially for hey, here's greatest hits, that's the pod, right here are the clips. They're like good for sharp marketing on social media. And here, instead of having to expose the full three hour whatever, that's all sitting behind the bot.

**Ellie Rofe | 24:36**
Such a clever idea. I love it. And I think they would get a real kick out of it as well.

**Ray | 24:42**
People love talking about themselves and they love talking to themselves.

**Ellie Rofe | 24:51**
I' such a good idea. Okay. I'll play around with it and seem.

**Ray | 24:56**
And it's all just sort of like, what's the asset? The asset is the interview that you did right now, what are the, you know, and if that's the goose, what are the golden eggs that come off of it? 
And then, you know, how can you be an even better maker of more gooses and whatever for geese or whatever meo work thing, the but I think. Yeah, and, you know, you'll get that from just getting your next interview up. 
And then, you know, this guy can, you know, the whoever whoever's having this, you know, this Mark Montgomery character who's like. I'm not quite sure yet. That's fine, you know, go to a bunch of others and then, like, give it back to him. 
Like, hey, here's what I got turned to. Got turned into a pod, got turned to this. And now that's not what other people do, right? That's not Patel, that's not you know anybody else that's you thinking more deeply about it.

**Ellie Rofe | 25:43**
Yes. 
Always it. Well it's you thinking more deeply about it, but it is a really good idea. [Laughter] I love it because people are like, yeah, what was my bot fell?

**Ray | 25:57**
Well, packaging. The assets are all you like. It's all in your interviews and your, you know, seleshing of people and the way that you ask questions to pull more of their brain out.

**Ellie Rofe | 26:08**
M and that becomes a way to ask, depending on how it goes with the calls this Lauren is in for an hour. Which is why I was kind of assuming was enough time to get 20 to 30 minutes max of podcast out of someone. 
But if it turns out that actually, like obviously bigger podcasts are doing longer and longer form like two, three hours is now quite common for a podcast, they're getting to epic film length and people are still tuning in. 
And so there is clearly a Desire for Long form. But for me, starting off, that's a big arc for people because they're not getting exposed to like a million people in an audience. But if I say we can do an hour and we'll do the interview and I can try. 
But if you want to give me longer, I can create your bot. Like your bot will be much more informed then that might be an interesting thing for them to just go, what does something based on me talking sound like? How? How smart do I sound? What am I?

**Ray | 27:21**
Well, yeah, I think you can be offering the plus up. I think just saying, let's sit down for two hours, is I got to I've been in a bun, I've been in at least several podcasts, and they all say, we'll take an hour. 
And then always is more than that. So they're never good at managing the clock. If you can, if you just sort of say, look, it's two hours because we've all done this before. These things always take longer. 
But more than that, by focusing on this thing for two hours, you know, we're able to sort of do, you know, do some circle backs and get the. Get the thing. That actually makes it even better. Half hour for the result.

**Ellie Rofe | 27:56**
H.

**Ray | 27:57**
Because it's not AI mean, many podcasts would just say, this is a live conversation that we do for 55 minutes. You're like, no, what we're going to do is we're going to have a conversation and I'll cut it down and get like, the thirty minutes really makes you look the best.

**Ellie Rofe | 28:09**
Yeah.

**Ray | 28:09**
Because that's what I'm interested because it's gonna be the part. What part where you're most thoughtful? It's a part that's creating the best ideas for the audience. Everybody wins. And by doing it this way, we get the chance that you can express an idea. I can. We can identify that as a good idea and then go back and do it again, right? 
So the. And I think if what you're doing is you're describing that as something where you're on their team to make them look better and you'll pay for it. You know, this person may say they only have an hour. Whatever. 
But I think you now have an explanation for why it creates value over two hours and that the. And in order to get the good thirty, you know, you need to start with the bigger pile, right? If you're a live streaming conversation, yeah, sure, an hour's an hour, but that's not what you're doing. You want to give them the thing that's going to make them look the best, which is should simultaneously make it be safer for them, right? 
And higher value, right? And so that the these this two hour thing then gets a higher return on investment than doing one hour of you know who.

**Ellie Rofe | 29:17**
[Laughter] yeah, okay, that's interesting framing, I like it.

**Ray | 29:25**
And the and yeah, let's see the max. And again, so this all sounds fantastic.

**Ellie Rofe | 29:30**
Two.

**Ray | 29:32**
I know there's nothing in here about your material science, friend.

**Ellie Rofe | 29:38**
When no, when did I speak with Maddy? It would have been last Friday, wouldn't it? I can't remember now.

**Ray | 29:46**
Well, if it was before the 30th. It was. You know.

**Ellie Rofe | 29:53**
No, you're completely right. I think I spoke with Maddie. I spoke with her on Monday, so I didn't add her in her, which was an oversight. 
So I do need to get back into doing that every day and just tagging like writing up afterwards. 
Yeah, it was a really interesting call. She'd said I really appreciate her sending the Fathom transcript with the video because I got to see and it's fascinating. I was saying to Nick, she has such a strange like it's a wonderful mix. 
I think it's probably what's given her the theability to carry on. So in the hard yards, she sounds a little bit nervous sometimes, but she's got this she's from San Diego and she's got this incredibly chilled out, like Sokal vibe. Sometimes as well, she's like, yeah, I don't know. 
Like these things might happen. But she was bringing that who knows what will happen vibe to the projections and being like, yeah, we have forecasts that, you know, we can get up to like 900 million in revenue, but who knows what will happen? 
And I'm like, this isn't a philosophical question about the nature of the future. And she's obviously technical. She sells into engineers a lot. So she was like, well, this isn't material, this isn't real. 
So I'm just kind of dis disclaimering it everywhere. So we had a good conversation where I said to I know that you can't project the figures with confidence because the figures themselves and I think most investors will know that those figures are not really the figures that they're like they can't go. We're banking on these figures coming in that the idea is the thinking behind them. 
And so that's where you have surety that's where you have said this is why we believe this will work here. And you know, we're but you know, this is base case JP Morgan projections, these are these projections. 
But it's based on the idea that we've had a hundred calls with the market and they've told us they want replaceable parts. They're not looking for a five year duration because they can't get it. And as it is, we're the most durable thing. 
So that's why the recurring revenue is in there. And that like I'm telling you this badly, but it was a good call. And even before she starts hopefully pitching that side of things a bit better. The go to market and the revenue with a particular thing and the moat where she was a little bit loose. Even before she starts to do that, she has gone from. I put all the. I'm trying to create a case study from it, and I put everything into Claude cowork. I put everything into a folder and let Claude start working through it. 
It's really good at managing context. And it dug out that in her transcript when we first spoke in November, she had been in the market for four or five months and raised 6% of her, 2 million target. 
So that's what, 120 grand, I think. 
Yeah, and after a month now she's about a million of her three million target because we changed her use of funds because she needs more to really make it work. 
She hasn't yet gone back to investors. She'd pitched before. She said, I want to try and get a lead investor before I go back to people. I said, I'm not sure you need to wait for that. 
If you go back, she. And she said. I'm a bit nervous about going back to people because it looks like I've just changed my mind. I said you pitch it as what it is, which is a founder who has listened to the market reflected updated their strategy to be better and, you know and take that to the market. 
So I there will be investors who think this sounds flibbery gibbet, but there'll be investors who think this sounds like a mature founder who is ready to reflect and adjust and listen and learn. And they might be even more interested in what you're doing now. 
So it was an interesting call. And I think I would love. I will be trying as and when I do decks with people, I will be trying to embed the idea that I work with them while they raise rather than just give them the pitch deck because I think it's really valuable for me as well as them. 
I think that's a I can't I don't think I can make it non negotiable. I'm not sure, but I think it's a heavily in, you know, enforced type of relationship because it's so easy to just get lost once you're out pitching without someone there to reflect and help.

**Ray | 34:35**
Right? You can suppose enforce or not enforce or whatever. But I think that they'd say, you know, you in fact, this is good content, is to just be talking about this phenomenon, to, you know that the that, you know, pitching is a process, not a point, right?

**Ellie Rofe | 34:42**
H23.

**Ray | 34:56**
And that the, and we even sort of even the word pitching feels kind of wrong, sort of feels like, wait, this is the one meeting and then it's all over. It's not it's about relationships. It's about going listening to the market about coming back. 
It's like, you know, coming back to the investor that you talked to the first time. You talk about, like, not having ideas for LinkedIn. This is good stuff. You know, like the. The stuff that you just were talking about. 
Like Maddie's challenges and you just sort of redescribe them without using her name. That's that. That's high value material. And I think it shows you being thoughtful about this process in a way that others are not because investors disagree with you. 
Well, then you'd be wrong in terms of your investor relations strategy, and that would be itself challenging. But if they agree with you, which they probably will, because you're probably right about this, then you can get people saying this is right and it's not what other people are saying. Other people are like, I wanted to go make your bitch deck and here's your bitchdek and lu.

**Ellie Rofe | 35:53**
He.

**Ray | 35:54**
They're not actually that, as you know, they're not, you know, as hands off as that, right? 
But they tend to be. My big thing is to make you the deck, and then your job is to go be selling with the deck. And that's sort of the handoff from point a to point B and you're like, well, actually, you know, go hire whoever you want to go work on that. 
But what really matters here is the story. And the story takes time and evolves over time. And. That's awesome.

**Ellie Rofe | 36:18**
Yeah, I have been trying not to do too many. Like I did a few. The problem is, as soon as you work with someone, you get loads of insights, and then you startsting about those insights. 
If you do that immediately, then that person knows that. So Maddy follows me. So I was connected with me, and she was like. This sounds familiar. That. That. You know, who are you talking about? And so there was sort of like a. I didn't want her to feel like I was exploiting her story or over focussing on the lessons that she should have learned.

**Ray | 36:55**
One.

**Ellie Rofe | 36:56**
You know, and especially I might be overthinking this, but it just feels to me like she is out there in the market and me talking about ways in which Maddy was, you know, implicitly doing things wrong or not understanding stuff is not the best vibe to be pushing out there as her advisor. I sometimes. 
I think what I might need to do sometimes is capture lessons as I learn them, and then when they are no longer hot for the founder, talk about elsewhere. So maybe I should now be thinking about the lessons I learned working with Ajay or Anid. Just in the terms of not over saturating a founder with ideas of what the process was working with them. Is that fair, or am I overthking it?

**Ray | 37:46**
I think you are a little bit overthinking, which is going to be perfectly natural for the first few times you do this, right? And then you'll become more relaxed about it. I think being able to take a lesson and then basically anonymize that lesson is good content, you know, but it's just good thinking, you know? 
And that's one of things I like about the getting into the markets that makes you evolve your thinking. And now you've got. Now, once you put some words to it, you actually use them in a private conversation, whether or not they ever seen it in the public. 
Like you have practiced it. Now, it's kind of like doing the Arab. You think like having, you know, having it out there, having shipped it, you now have an idea of like, hey, here are a couple things that worked. Here are some things I'm going to avoid. It just puts a brighter lines around it. 
And the thing that usually causes us to overthink is when we don't have the bright lines.

**Ellie Rofe | 38:41**
Yeah, okay, yes, I think that's true. Yeah, I think it's interesting to me. I see. And some of these things are clearly made up. 
Like when you see people talking about, I had a client and they were doing this, it's like, no one's talking about their fucking clients like that. Excuse my language, but, like, if that's how you're talking about your clients online, I wouldn't want to be one. 
Like, stop talking about them like they're morons. You're making up that there's sort of a made up case. Actually. One person I've seen do it very well is someone who literally makes up. But it's a conversation based. 
So he will do like a AA like mock up of a text message conversation or something with someone who. And he acknowledges that that's fake, but it's based on things. So it's not like I spoke with a client and they were an idiot and I made all their problems go away. 
It's a sort of. This is a pattern recognition thing.

**Ray | 39:42**
Yeah, you want to make them look good. It's part of the idea behind the earview is the people who interact with you look good. That. Is. That. That's the cell behind the CLL.

**Ellie Rofe | 39:50**
Yeah, but this is where I come back to with case studies. Like, I really struggle with this because. And I'm trying to position it as what the founder was too deep in the weeds to see because, like, that's the whole point. I'm making the implicit, explicit, et cetera like the. 
Because when you're doing case studies, the before and after has to show serious transformation. But the before, if you look at it cynically, as some people may can suggest, you know, a lack of insight on the founder's part or a lack of, you know, effectiveness as a leader. 
So you pitching it again, am I?

**Ray | 40:36**
Sorry, I'm interrupt. I've thinking about a little bit of a jank. And I apologize for that. Please finish your thought. I apologize for interrupting.

**Ellie Rofe | 40:42**
No. That was it. Please. Go.

**Ray | 40:45**
Okay, yeah, sorry, just a little click there, the, you don't need it before.

**Ellie Rofe | 40:54**
Okay.

**Ray | 40:56**
People who work with you look good, do they believe they will look either way? It doesn't matter. The only people who are going to hire you are people who are worried the people who have hired you should just look good. You make them look good, right? 
So, like you when if you look like this gets to your. You know, a portfolio. The portfolio from like. Hey, here's client work I did. Doesn't show the before of before they were total idiots in terms of what kind of advertising, marketing or positioning they were doing. You just show this is what it looks like to have work for me. 
I think that's allowed. I think. I think that can be. I mean, if you're trying to figure out, like, what's the value add of working with you? I mean, if what you did was taking them from bad to. Okay, that doesn't work nearly as well, right? 
But then again, if you'd only take them from bad to okay, what were you doing there? That's why we're supposed to talk about, like, picking winners, because that's gonna be people who, like, on the other side. These people look good. This presentation looks good. This story looks good. 
Like, what did you work on? You worked on this, which worked in a ding, right? And like, you know the strategic positioning we did this is this, right? Or looks like this is this.

**Ellie Rofe | 42:08**
M4.

**Ray | 42:08**
And then you can be crediting the founder for that all the way through or whoever you're working with. 
You know, speechwriters don't take credit for the speeches they don't have. But they can say, hey, here are some speeches. I was kind of involved in. And here's how good my boss looked right when they were going giving that speech you don't say. 
And then my boss couldn't put two words scare without me.

**Ellie Rofe | 42:30**
But it's what I don't understand with the portfolio when you're. When you're doing advertising, the end product is the advert or its customers. I guess, I'm trying to articulate it. What is?

**Ray | 42:50**
The strongest pit, the strongest sell is. I worked with them and they raised $30 million.

**Ellie Rofe | 42:55**
Yes, of course.

**Ray | 42:57**
And if you don't have that, then you're another level down. And people that will become obvious pretty quickly, right? 
Because people are like, hey, what's the job you done? I'm trying to raise $30 million. Did you help them raise $30 million? No. Okay, well, now you're already in the back foot, but the. But the next level down from that is. This is the story that we worked on.

**Ellie Rofe | 43:16**
Yes, but that's kind of what I'm trying to say. How do I cause? Because it's not just the story you worked on, it's the fact that the story, the value that I'm bringing is not. We created a story. The value I'm bringing is we shored up the strategy. I was talking with, someone I adjusted my grid for politics, and I was talking with someone about the do I get it, do I believe it? Do I trust it? Thing and I said the first step is to articulate so things that have become just assumed in the business, you clearly articulate what you think those things are. 
So there's like I think there was like there's articulation, there's clarification where things are confused or there's dissenting voices or even dissenting voices in the founder's head, and then there's fortification, and that's where things are not strong enough, where the strategy itself is just lacking. 
And they're the sort of three different parts that I'm doing. That's really the transformative work I'm doing with people rather than just and this is the I think this is the quandary I always end up in. I don't want people to just think I create slides. 
And we've talked about this, right? I can't just be a slide creator. So if my portfolio is just here's some slides I created and they got some money, then it feels like it puts me very much in that category. 
So I was trying to show like, that strategic gap map, for example, showing the before and after. Like, this is what it looked like, and this is where we got to with it. So it's sort of visual, but it's a glance that, like, we shored up the competition side of things. Or, you know, that was a five out of ten and then it was an a out. 
And I don't know, I'm marking my own homework there, but fuck it. It's I think people will get it when they see it. So. I don't know. Maybe I'm completely on the wrong track with that. But that's what I was trying to avoid was just like here's some slides and a number that deck raised because it that feels like it's not telling the actual story.

**Ray | 45:28**
Well, you can't tell the actual story that's not available to you because the actual story is, you know, some combination of confidential and not as maybe not as fla to the client because you know, they were less ready than they became more ready, right?

**Ellie Rofe | 45:40**
Yeah.

**Ray | 45:41**
So it's a you know, here are wins you are associated with.

**Ellie Rofe | 45:45**
H no.

**Ray | 45:45**
And then when they're asking, well, what happened here? You can be telling that story more in private, but you can't be doing that in public, right? 
Because the same basic principle of. You don't want to be making them look bad. Right? Your. Your. Your job is making them look good all the way through, right? And the and always by way was saying like to the extent that you're challenged for the thing you feel like you're overthinking is the before and after. 
I think if you just if you show the after that's a lot and then the and then they can read between the lines that like you are associated because of pattern, right? With good actors. And then when they asked, well, what did you really do to have an influence on this? You can have that conversation. 
But, you know, I think in general, they look at, like, what they have. And if they believe their stuff is already awesome, well, they're not going to hire you in the first place. And they think their stuff is, you know, needs help or whatever. Then. 
And they see that you are associated with output. That's good. Then they think that's worth having a conversation about.

**Ellie Rofe | 46:49**
Uhmm.

**Ray | 46:49**
And of course, the other aspect is going to be like you're naming somebody who has agreed to be named by you, and then they go do that check, right? Which that's only going to happen if you made that person look good. It was not even like a folio.

**Ellie Rofe | 47:03**
Okay.

**Ray | 47:04**
Like, you know, my wins as of my clients wins, right? It's their successes, celebrations is that. I mean, that's what I've done in the past. When I look at like, what does consulting look like? It's like, previously, they were leaking money all over the place. 
And then I came in and we fixed them up like they. They didn't want that story told.

**Ellie Rofe | 47:28**
No, but that that's where I struggle with. I don't think here's something they have that shows. I think this is why it feels like it's really just a referrals based game because the idea of marketing stuff where it's like here's a completely untethered after, which is a vague win is not particularly compelling to people because people feel like that is a. 
So the reason I think I got the SDP well, I know the chain of events for the SCP work. There was nothing to do with, like a portfolio or selling. I guess it was. It was because I gave them an example of my thinking for free. They had an idea, it was Leite capture. I said, here's a better idea, elite breakaway. This is why it's better. 
This is the way I think. This isn't the only idea I've got. 
But that's. I don't know how you scale that.

**Ray | 48:38**
Well, okay, the, first you're not a point you need to worry about scaling you're at you're still at the do things don't scale phase. So I'm not sure that's, necessarily the challenge I would worry about just yet. The.

**Ellie Rofe | 48:57**
Just to clarify, I don't mean scaling really. I mean how do you marketize that? How do you turn that into something that to marketing rather than part of the sales process?

**Ray | 49:11**
Well, right. What you're really saying is like, where in the funnels go. Right? Like you talk about top of funnel work versus midfnel versus late funnel. I think.

**Ellie Rofe | 49:22**
Yeah, kind of.

**Ray | 49:22**
Okay.

**Ellie Rofe | 49:23**
I'm just trying to work out how on earth I market the business that I can't. This is the thing that I think I've struggled with, and part of the reason I struggle with LinkedIn is I end up talking about concepts on LinkedIn rather than work, rather than actual transformations because I can't talk about stuff. I can't like you, if I talk about the stuff, the work I've done with certain founders, it will make them look bad because the before was bad. 
And so I can't do that. And I can talk about the after to a very limited effect because it's under NDA, a lot of it. Maddie never signed one funly enough, but, it. And even then, like, no one wants to look at a like, 20 page deck to see what someone someone's after is anyway. They want to see examples.

**Ray | 50:08**
No, well that okay layer ends I think has a really good angle on this. You read his win with that pitching manifesto.

**Ellie Rofe | 50:18**
No.

**Ray | 50:22**
It's kind of what I fault for this because it his answer to your, you know, conundrum that you're talking about. The what they want is free work. What they are, you know, the you know, how do you actually, you know, market those things is thought leadership, right?

**Ellie Rofe | 50:39**
H .

**Ray | 50:41**
So this is a bit of what you're doing on LinkedIn, right? You've sort of been thinking about doing this, like going deeper, like with the subsect stuff, right? But like you positioning yourself as a leader is what then caused them to say, yes, I want to work with us. I want to work with those thoughts and with you as person, right? 
And then bring that to and then they're validating that through who they know, right? So you have a referral base business of, you know, people you talk to and who have some degree of trust in you. But then there's a okay, who else can how can you widen that circle and how can you make it easier for the people who you know to be able to recommend you? 
Well, they could just recommend you. People who? When? They have something that they need, but you could be giving them things that are smart, right? That then they can be moving on with that. That's kind of like what the that's a version of like what you had been doing with like with the LinkedIn stuff you had the good intuition of like, hey, there's some combination of like YouTube or the interviews for using Substack for more, you know, written content of like, you know, Ele being smart about the world, right? 
And as you have talked to more people, you have access to more secrets that you can be sure. I mean, I don't think like gossip secrets, I mean like just market insights, right? Telian secrets that will that then provide value right through these different media right that either your friends and people who have high opinion of you can be helping you distribute that they can people can just find through some kind of named SEO or agentic or whatever.

**Ellie Rofe | 52:08**
2.

**Ray | 52:09**
But you become part of the discourse and that I right.

**Ellie Rofe | 52:11**
But then when it comes to an engagement, they go. Have you got a portfolio? I can see.

**Ray | 52:18**
And now we're like the next level down that. But to your point, it's not marketing at that point, it's part of the sales funnel. That doesn't win you, that doesn't get you business. Coming to talk to you, it's part of you closing the deal, right?

**Ellie Rofe | 52:29**
Yp.

**Ray | 52:30**
Why are they looking at your portfolio? 
Because you're talking about a serious, you know, engagement, right? And now. Now what's the job of the portfolio? The job of the portfolio is no longer something or the case studies or whatever. It's no longer something you're putting out into the public. 
It's something that's private. And now what you want in that portfolio is something that, yes, you can be sharing. You know, you can open a kimono more, as it were. But the you still want to make sure that's making those other clients look good because they know they're going to be the next one to go into the portfolio.

**Ellie Rofe | 52:59**
Yeah. Yeah.

**Ray | 53:01**
And then it's like, hey, here are some wins. And then you can say, well, I can share this with you and then, you know, just talk about it for a few minutes, right? Just like, you know, just like you would with any presentation you give to an investor, right? 
It's like, you know, you have that conversation which sort of gives a sense of how it work for you. And then. But. But why do I bring that up? I bring that up because there's question you were asking about scalability, how you push yourself out there, that's where the thought leadership comes in, right? That thought, leadership, relationships, and these two things compound each other, right? People who have varying levels and that increases the no, like trust, which brings them into. 
Okay, well, I'm trying to figure out whether I should be doing business with you today. And how am I going to qualify that? I'm going to qualify that through reference checks. I'm gonna qualify that through taking a sample of some of your stuff. 
Like how can you make that a shorter path for them? Right? And that's that I think, becomes a job of the portfolio. And that means you're not just sort of sending your portfolio to people, right?

**Ellie Rofe | 53:58**
Hey.

**Ray | 53:58**
Your portfolio is like the next layer down. 
And when you have it as a sales tool as opposed to your point as a marketing tool, what you can do with it becomes very different.

**Ellie Rofe | 54:07**
Yeah, okay.

**Ray | 54:09**
And the and I think what the. But I think this idea of thought of your you. 
I think you're starting to look at the portfolio as a way of scaling your reach right here. Demonstrations doing.

**Ellie Rofe | 54:19**
It was fthering stuff it the portfolio was about furthering the relationships with people and how I talk about stuff. 
But then I think I abstracted that to how do I talk about what work I do in marketing in that higher reach stuff? But I think you're right, it's I just don't talk about it. I mean, I guess when you look at some of the people who run top podcasts, they don't talk in depth about what they've done with clients. They talk about their ideas a lot of the time. They might. They might, you know, fictionalize or abstractify things for a book, but they don't spend their time talking about case studies. 
So yeah, I get what you're saying now. Thought leadership as the sort of big signal, the broader signal and then more specific but still heavily redacted stuff in as part of the sales process itself.

**Ray | 55:17**
That's kind of what it feels like. And that as a result, you get to worry a little bit less about the redactions of the one level and you get sort of, you know, be more expansive on thought leadership at the other level. 
And of course, the more stuff you put out in thought, the your sh up the easier and the more stuff you talk about in interviews if you sort of have an idea and you get that to be reflected back to you from like one of your interview subjects, that's great. 
That's wonderful that you got all the excuse to go talk about that idea.

**Ellie Rofe | 55:42**
Yes, yeah, okay, cool. I realize we're at time, but that's really helpful. I think I did the door knob question, didn't I?

**Ray | 55:52**
I'm and I'm so glad that you did. Okay, great. I think it's you and TJ and finally you.

**Ellie Rofe | 56:01**
Yes, okay, cool.

**Ray | 56:04**
You mentioned a little bit of complete finisher stuff, which we didn't really get to, but we talked about some other subjects. 
But if I can be helpful using the kind of, you know, method that we used a couple of weeks ago, I would be honored.

**Ellie Rofe | 56:13**
Yes, yeah, that's a really good idea.

**Ray | 56:15**
Delighted.

**Ellie Rofe | 56:17**
Thank you, Ray, thank you. Okay, have a great weekend, peers, bye.

**Ray | 56:20**
I will record.

