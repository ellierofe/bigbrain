# Ellie and Ray Zoom - Aug, 08

# Transcript
**Ray | 00:04**
Hello, Ellie, how are you? Recording in progress.

**Ellie Rofe | 00:08**
I'm all right, thank you. One second. I'm actually just setting up the phone reminder before I end up not doing stuff again, because just as I set up, I got calls and got distracted.

**Ray | 00:18**
I appreciate the use of the meme as well. That was very funny.

**Ellie Rofe | 00:27**
[Laughter] Okay. Perfect. How are you?

**Ray | 00:37**
It's been a week. There's been a lot happening this week. My family is out of town, and when that happens, I just really lean in more to try to make the maximum productive use out of the quiet time. This week, I shipped the state change assistant.
So we now have an AI that is starting to do the state change things. I got... When I first had this thing in early June, I had an early draft of it. Okay, I'm just going to shift this thing really fast and talk about how this is the right thing to do. It was the right thing to do because I talked to a couple of people who then told me just how completely useless it was.
Now I'm having... I found myself getting a little lost in the middle, so I set up a town hall this week that I would just roll it out to people, start talking about it more publicly, at least in the context of a change. Not so much marketing on the outside yet, but getting it going on the inside. I got a lot of feedback, and I need to separate now the question of people who are fans of it because they're fans of me versus where the real utility is.

**Ellie Rofe | 01:51**
Yeah.

**Ray | 01:51**
But the most valuable thing is that people are actually using it. It's creating history. It's creating understanding. And like this. Okay, now the wheels are really starting to turn with it. So for me, a little bit of a lesson of like, "Okay, you do that early ship? Yep, discover you will build this again. Time to go back."
Then I went back and came back around to this. Now it's like the first time around, I had undue pride in what I'd accomplished. The second time around, I had undue perhaps trepidation.

**Ellie Rofe | 02:18**
Yes.

**Ray | 02:19**
But I see what can happen next to make it so much more viable.

**Ellie Rofe | 02:19**
I.

**Ray | 02:24**
And it's so much less complicated than the other things I was thinking about, right?

**Ellie Rofe | 02:27**
Thinking about.

**Ray | 02:28**
So it is that disconnect between the amount of work and the amount of value that only really becomes clear when you start having more market interaction.
That's been my lesson over the course of the last eight weeks.

**Ellie Rofe | 02:43**
Good nice. That sounds very good. So what did you end up with? Because you're using call history and your essays, is that right?

**Ray | 02:55**
Right? So it's using the right... I've got my essays, I've taken all the shorts, right? The whatever, 500+ shorts, turned them into... Load them in all of the office hours, which is over, well over a thousand hours of video, as far as that goes.
That's what I took. I took call state change posts and all the conversations I've been involved in on the stand-up forum. I was able to scrape those. A lot of people come in for Xano stuff and sort of brought those in.

**Ellie Rofe | 03:20**
Wow, fabulous.

**Ray | 03:26**
Okay, that's starting to get more interesting. And took it up a level by creating different mentors. So, I have one that's more focused on mental model questions, one that's more focused on Xanadu questions, and one that's more focused on just saying, "I want to go find if you've ever talked about X."
Then that's more of a search question. Then the thing I did on Lark, but it's actually relatively popular is I have this thing. I think I've talked to you about it before. After meeting, I will take the transcript of the meeting and get that turned into a song.
Well, I made a tool for that. Now, people, when they're having their conversations with the assistant, they can... There's another mentor called the Musical Mentor, which can take whatever you're doing and express it in the form of a cell.

**Ellie Rofe | 04:11**
[Laughter] That's hilarious. I love it. Is it a musical style? Is it like going to the IO nice.

**Ray | 04:22**
Well, actually, I allowed it to figure out the style based on the context and on the user's preference. So, if you ask it for a dance track, it will give you one. I used to know for it.
Not just lyrics, actually. It produces the song, produces the track, and that gives you the track. Then there's a separate place for the songs that got generated in the course of your conversations so that you can turn that into a bit of a soundtrack for you later or whatever.
The goofing with it, I find, is where the joy comes out. It's where we start to create something really differentiating. When you're doing all this stuff, it's like, "I need to do X."
That's always a table stake stuff, the stuff that's like those little grace notes of joy that start it off and are differentiating. Now, they're having a uniquely state change array experience with it. As opposed to... Yeah, House is better than ChatGPT, which is a perfectly reasonable question just from a chat point of view, because ChatGPT does its job really well.

**Ellie Rofe | 05:22**
Fascinating. I love the music thing. So, what you're running is a sort of chat function with subagents.
When someone asks a question, it contextualizes the question and then sends it off to the right agent.

**Ray | 05:36**
Yeah, when, you know, you and I are both, you know, initiated in this field. All it is just sort of swapping out the system prompt.

**Ellie Rofe | 05:44**
Yeah.

**Ray | 05:46**
And innovations are now message by message so that you can have... So, like you say, it has a subagent type experience where you can decide. You can even rerun the same previous question or the same previous conversation to this point.
Yeah. Now, this time, let's do it with a song. This time, let's do it with mental models. This time, let's... Where, which is not something I've seen elsewhere, it's all part of my experimentation with how we can get more value out of these different kinds of prompts.

**Ellie Rofe | 06:20**
Yeah, it's fascinating. I think one of the... Apart from the fact that it's just really interesting and sounds like a great system, as I've been ingesting more and more of this report stuff, it has been a struggle to get the blunt tools within Gemini or ChatGPT to do the right kind of analysis and
frame things in an interesting way and just get the data ingested in a way that is concrete enough or accessible enough but not overly detailed. So, the rag side of it, I think, has been tricky within those blunt objects, and then the analysis side of it...
I've been arguing and rring about what I can actually. How much I can achieve in these front-end things versus what other bits I might need to stitch together to actually make it useful?

**Ray | 07:18**
Yeah.

**Ellie Rofe | 07:24**
Because I am struggling. I've found some great reports and some really interesting stuff. But getting it to pull insights out rather than just finding random bits of information it likes out of those reports, does that make sense?

**Ray | 07:36**
Yes, it does make sense. There are two things that I've found to be helpful in this regard. I know that Mitch Van Dusen really likes Sim Theory,
and there are some other tools like it there, targeted towards experimentation and the learning process where they can just load in the data, but they tend to be a little bit buggy, and I find that to be a downside for the reason you were describing. Basically, it becomes too much of a rifle shot. They're pulling out these little snippets from the documents, and that's not really what I need. The thing I have found more value in...
Actually, I have a private version of the system as well that I'm doing weirder experiments with and experiments I couldn't quite do in public. One of the ways I'm doing that is I'm looking for as I find really good books, I'm taking those books, finding the PDF of them, and then processing that PDF. So, I'm taking that PDF, and there are websites that will let you do this. You're going to upload a PDF and download a Markdown representation of it. Markdown is just all text.
So, the idea is I can take that, which previously would have been like, "Wow, Claude doesn't like to handle more than a hundred pages of a PDF at once, right?" Because it's trying to comprehend the whole thing by literally reading it, but as a series of images.
Well, you can shrink it from being effectively a million tokens whatever to being just the length of the book, which could be like 60000 tokens by fracturing the text. Now, don't get me wrong, that misses some of the visual parts of the book, or what have you, particularly something.
It's like a very visual presentation, and you might lose more, but, my goodness, you get so much. It's like a transcript. The transcript being generated automatically by Krisp. Between you and me, it's not only perfect. We start reading it, we're like, "This isn't great."
Then you go to Key Insights, it's like, "My goodness." You can get the outlines of it. The reason I bring all that up is that this Markdown approach that I've been taking allows me to get a lot more context into the window and then focus the question on how to ask it for what's interesting in here.
I can do things like take three books, load them into the context window or more, and then start asking comparative questions without having that rifle shot. I'm just trying to find the snippets that are interesting based on X. Just by saying, "Okay, well, here's a view of Marshall McLuhan right?" Or of Daniel Priestley right? His books are mostly available through ebooks. You can download them and load them up this way and get some pretty interesting stuff going on.
You know, asking about things like his books didn't really comprehend, but the AI is able to take his mental models, his frameworks, whatever, and then apply them to the question at hand in a way that is quite illuminating.
I bring all that stuff up just by way of looking at it as a data exercise and a way of taking the books and saying, "Well, let's throw away the 20% of it that takes 80% of the resources." By compressing it essentially into the text and then seeing what kind of insight you can get out of that.
Because the answer is usually quite a lot.

**Ellie Rofe | 10:51**
Yes. I think some of these reports have a lot more text. Some of them are almost entirely charts and tables. I guess it would... I guess it would push the table into Markow.

**Ray | 11:00**
Well, the tables that can push the Markdown... the images... it might start to lose... But the thing is, things that are much more visual tend to be shorter. You can load those in and say, "Let's get insight. Give me a summary of this document." Or what is one of the charts? They have to say... What have you?
If it's giving like 15 pages, but the problem is when you take the same thing you were doing for a 15-page slide deck and apply it to a 200-page book, you're.

**Ellie Rofe | 11:19**
For I'm not talking. T.

**Ray | 11:24**
You're about a lot more expensive for a lot less value, right?
So I mean, having, once again, bringing McLuhan into the conversation, matching the medium to the message, and helping quite a lot in giving you the best value from what each of these things is by treating them as different.
That's what I mean by that. This being a data exercise much more than a development or what have you exercise. Then once you have summaries, now you can plot those summaries against each other, right?
But the summaries... What you really wanted were the summaries of trends and ideas. What was remarkable here, as opposed to what you say, was just these rifle-shotted facts that you might get extracted because of the way things are hit in the vector store using cosine similarity.

**Ellie Rofe | 12:12**
Yeah. So what I did was upload into a Claude project. I kept trying the Markdown thing, and one of the things I found difficult was you end up...
It's like a photocopy of a photocopy in that when you ask it to summarize long, complex documents, especially ones with lots of charts in, the summary itself creates an approach because it picks out the things that it believes might be useful and ignores some useful nuance, then when you ask it questions, it still feels like it's doing that. Let's make it... It's making big statements and claims and assumptions, and then you say, "Can you source these?" I had asked it to do so in the system, but it didn't.
So it goes through and sources... Then it's like, "Actually, the entirety of the trend you are collecting from across all these documents is from one of the reports, and it's just that you've landed on that one for some reason."
That's then becoming the basis of this analysis for this whole section. I suppose that's where I'm struggling. Maybe it's a prompting issue, as much as anything.

**Ray | 13:36**
Well, actually, you know, at first when you say that's a prompting issue, I actually initially misheard it as that's a promising issue, which was where my brain was going, like that the fact that stuff is hard is actually really useful exercise, right?
Like if anybody could do it. Like, whatever, right? The. Wait, it seems to sort of get stuck in this little cul de sac. Okay, well, can we get it to re reviewe itself? Can you get to make a report and then go review that report to say well, which things are sourced and how well what are the trends that this report that was the previous round said and how we'll sourced through those and basically acting as an editor versus the initial, you know, writer or reporter and then doing that. Return to Sunderb.
And we started to you start to think about that like how that could be a multi agent thing or whatever. And you could do something as complicated as like using, you know, Flowwise or something for that.
But, you know, even just in the context of immediate chat, I bet there's something to itive like having that multiple pass. You've already had that idea of. An agent that works better with sequential passes.

**Ellie Rofe | 14:41**
Yeah.

**Ray | 14:41**
With the stuff you were in state change when you.

**Ellie Rofe | 14:42**
Economist and so a lot of the data is commentary mixed with source data like figures.

**Ray | 14:44**
When you were like doing that for the marketing frameworks.
He.

**Ellie Rofe | 14:57**
And I guess part of what I would like to do and this is one thing I've never touched on before, and I've really just thought about it right now, which is why you're getting this question, is.

**Ray | 15:05**
Two.

**Ellie Rofe | 15:14**
I've dealt with an awful lot of... With textual data and contextual data, but not actually raw data. Obviously, raw data historically is what an awful lot of systems we're dealing with. I've never done that, but I leaped straight into dealing with huge amounts of text. How?
Well, say an example to go back to it, because I haven't really been able to do much with it, but the huge amounts of data in the Srib, for example, and if I can get other sources like it, how well does AI analyze raw data like that? Or do you need to create a meta-analysis first and ingest that into the AIS?

**Ray | 15:59**
So this is a really interesting one to me because your intuition is right that AI can just ingest all this data for breakfast, but actually, it doesn't do that.
Well, we started looking at structured and particularly numerical data because it doesn't really have tokens. How am I supposed to do this stuff?

**Ellie Rofe | 16:16**
Cancer.

**Ray | 16:17**
So this is where tools become really interesting because what you've been doing so far is you're taking the relatively simple approach.

**Ellie Rofe | 16:17**
So can.

**Ray | 16:24**
I'm just going to throw a bunch of texts at you and ask you what you think about it, right?
But then you have all right, I'm throwing much text at you, and that's causing you to start thinking. In a certain way, I'm creating these mental impressions, but there's no way I can memorize
all the stocks that have been on a daily basis at the NASDAQ for however many years, right? But that's really useful information, and the kind of thing that people sometimes say, "Ray, that was amazing. How did you know this stuff?" The answer is I use Google. The tools help with this.
So instead of... So what we're doing is we're getting the AI to a point where it can start to ask better questions, right? And so far, you've been asking better questions and getting AI to give you answers.
But the next level up is to get the AI to be asking questions like, "I don't know. I should find out what the answer to this is." Or, "This trend seems interesting. I should dig into it more." Whatever it becomes, like the kind of parents you want to have.
Then you want to provide it with a mechanism by which you can do that. That's where we get tools. This is where MCP comes into play. You would provide so that you're getting it to a point where...
All right, we're having a useful conversation about this, or it's having a useful exercise. I've been doing deep research or whatever. All right, I'm going to go look up those stocks. I'm going to look into this data.
One of the most straightforward ways of doing that in terms of the data is to say, "I'm going to have my data in Ocean, Airtable, or whatever, and have it search for that." You can not only do a simple search using vector search, but it can do things like creating Excel formulas. It can create SQL. This is where dynamic code becomes a really interesting thing.
SQL is a language, right? So it's one of the simplest forms of dynamic code. I want to understand what the monthlies are for this particular stock or whatever to verify this trend. Then it goes and looks for that stuff up.
If you just load the data into it, it doesn't quite know what to do with it because it's not in sync with the word. It's just like if I were somebody to pour that data at you, and you were to read that spreadsheet, and I would start to ask you questions. You'd be like, "I don't know what you're talking about."
But I give you a book, and you can talk well about the book. There are two different kinds of data that a particular kind of brain can ingest. But what you can do is use the fact that even when reading the book, "That's interesting," turn around and go look something up. The
idea that we're not just giving it the data but we're giving it a gateway to data isn't so much about protecting trying to protect your context window or anything specific. That's trying to give it a tool that matches the way that it thinks because it matches the way that we think.
There are certainly lots of cases where we cheat and we look things up instead of actually doing the reading. But the numbers are a good example, something where we are almost always mediating through tools, and the AI does well with that too.
Fortunately, there are relatively simple tools. You can have one, I think there's even a super-based tool where you can give it access to a super-based database, and it will just go do lookups. Airtable is more straightforward; we'll do that. You can go look up the base, ask questions based on the labels, the fields, whatever it figures out.
Okay, what's the question I need to ask? What's a summary I need to ask about? It can do some remarkable things, but that's the way I would think about that, instead of saying how do I load the data, how do I give it access mediated by it fo.

**Ellie Rofe | 19:47**
So I could feasibly, as an initial thing, rather than trying to use Claude projects, for example, I could feasibly have summaries and ideas and stuff like that in a Notion workspace that it has access to, and then have a Superbase or Airtable with raw data, and then just have access to those tools, different tools for different types of data.
Then it knows how to access that and what to do with it. Because it's being given the structure via the MCP of what it can do with that data. Got you. Okay.

**Ray | 20:31**
This is all I mean, there are steps between there and being able to get innovative market insights, but there were many fewer steps than there were before this conversation.

**Ellie Rofe | 20:43**
Yeah. Okay, that sounds good because it's felt like I'm wrangling with something a bit slippery, and it's never quite working with those rentals.
I've been avoiding going off into deep dives like, "I'll just do it because obviously my brain goes, it will be really fun to play with Visual Studio, Claude Code, and just start creating stuff."
But I know that it will be fun for the first 60%, and then they'll just be bogged down in noise and won't actually be getting to the end result I need, which is the insights.
I'll just be like, "I'll have enjoyed a massive little curiosity binge and a dopamine buzz from playing around with the tools and then not gotten where I need to get.

**Ray | 21:35**
My town hall last week, this week about the assistant. I got a number of good ideas, but the one that really is taking up real estate in my brain that I'm most excited about is this idea of Shopper because you know what you're describing as the temptation I want to just go build that thing when in fact, there are a dozen things out there. Let's be the top of that, right, and provide the value on top instead of doing all the baseline stuff. There's a bit of that in terms of how can we mediate that and how can we make that an easier, more obvious thing to do because people often just don't even know what they're looking for. They don't know how to give it a name, which means they don't know how to search for it, which means they think that doesn't exist and start creating from first principles.
That's a less story of a lot of redundant invention out there. But the other thing is, machines do the same thing. So if you ask AI to please, you know, I want to go and make an X. Well, similarly, it starts to just be responsive to what you're asking for.
As it dials in on what you really mean, it doesn't step back and say, "Maybe we should just go buy an X?" It says, "Let me edit the thing I've been making for you." It's trying to do things on the margin.
So the idea of how can we help the AI wrangle itself? Just don't reinvent the wheel. Once you've figured out this is a wheel, let's go do something else, right? Even if you already built half a wheel so far. Just don't keep throwing good money after bad. A hard thing to do, but I think a real value point in there.
So all of which is a way of saying that the temptation you're describing is perfectly common, and the correct solution is yes, try to let's shop where we can, but sometimes the way that we shop or the discovery process of shopping might start with a bit of building, but then we need to have to step back from that and say, "Wait, now that I know what I want, I can see there are 15 of them out there, and not be in a position where you're trying to justify the work you've done
so far." So far, but rather ask how you can shorten the path to creating the value that you want to get to.

**Ellie Rofe | 23:44**
Yeah, I think that's a really good point, and I love... There's quite a few... Is it Sen Cookeol cock or something? There's people who do prompt sequences for building your own app, and it wouldn't take much work to tweak those to do prompt sequences for shopping your own app.

**Ray | 23:59**
He.

**Ellie Rofe | 24:07**
Like, just saying yes, let's scope this properly. Like there's a big focus in some you know, scope it think about the functionality you actually need MVP functionality, not like 7000 things.

**Ray | 24:12**
Two.

**Ellie Rofe | 24:20**
And that's the halfway house that I've been missing.
I've been trying to brute force the AI studio for Gemini or Claude projects because I don't want to end up distracted and getting that because I get very excited by the initial bit. It's full of promise and excitement,
but that's where using AI to scope and then find the things that I can potentially knit together very much like Demetrius does. He's very good at finding the things that are there and then knitting them together.
That's his genius, really. That's what he does for people a lot of the time.

**Ray | 25:01**
Yeah, he's a composer.

**Ellie Rofe | 25:01**
Okay.

**Ray | 25:03**
He's come up as a composer, I think. The idea is that you are inventive, you are creative, and the trick is to bring the best of those together, right? The idea is that it is a new outcome, right? A new source of value for the customer, but based on the other.

**Ellie Rofe | 25:23**
Yeah, okay, I shall have a look because that feels more like the data stuff really helps because I have been trying to work it out and not quite getting there. Especially... The other thing that I think would be useful
is almost grading like metadata on this. I have... When I've been asking you to do Markdown summaries, I've been saying, "Can you give me some metadata or meta data from the title and date and publisher and all that kind of thing, but grading and categorizing the... The data is a Goldman Sachs better than, like, Startup Insights, in terms of the actual data that's there or the analysis that's being done.
For this project, maybe I need to be going through and considering that on a wider basis. Some of these, the investment banking side of things, they do have reports about funding and stuff, but some of their industry analysis is much more about mature companies, listed companies, what's happening there, versus what's happening in terms of funding, for example.
So there's elements there as well where there's a side of sabotaging the data and categorizing it as much as ingesting and finding the best ways to use it. So that's some of the stuff.

**Ray | 26:59**
Well, right. We should remember that, like you in here, you have a role as an analyst in which you're wrangling information, but you have a role as an expert where you're able to provide a filter on this information that allows more meaningful stuff to come up.
Meaningful is subject to whatever your priorities are, right? So, of course, this can be colored by whatever biases you're bringing into it, but if your observation is, "Hey, look, Startup Insights is probably giving Goldman Sachs great insights," it's probably going to be biased towards larger companies, which means they're more useful for the future. Whereas Startup Insights is going to have somewhat junky data, but more likely to be close to what is in the froth of the low-end stuff by providing that kind of insight. Your insight on top of Goldman Sachs on top of Startup Insights on top of JP Morgan and whatever else you're pulling it from, you wind up with something that nobody else could do, right?
Because it's not just you as an analyst and not even you trying to convince the AI that what you think is true. You can just be layering your expertise on top. And that's a significant value-add. Most people won't be able to get the other information in the first place, but the fact that comes with your ideas sitting on top of it is... It's not stone soup, but it actually adds value to the rest of it.
So I would shy away from that.

**Ellie Rofe | 28:26**
Okay.

**Ray | 28:27**
To say that, "This is something I'm learning," is that I originally had a... Okay, well, how do I organize this to have it pull the right information out of my... Whatever my library is? It's coming. There's a lot of value in just having the cheat sheet of, "Hey, here are ten things I tend to say all the time.

**Ellie Rofe | 28:48**
Yeah. Here are the ten most common problems that people come up with.

**Ray | 28:53**
Ten common problems, ten common frameworks, whatever. Then, but this is so reproposed, it's ten pages long. That's a drop in the bucket from a context window point of view, yet it could be the most important stuff in there, right?
Because one has your insight, right? With this data. That's alchemy, which is the term that actually... Damit was using earlier today. It's alchemy because you've now taken public information and turned it into proprietary insight because it's been layered with your opinions and expertise on it, right?
That turns public data into a secret, and secrets are available.

**Ellie Rofe | 29:38**
Yeah, okay, good. Yeah, it's been really interesting. I'm feeling a lot more clarity now after this as well. I know there's a lot of heavy lifting to do between clarity and execution now, but that makes much more sense to me.

**Ray | 29:57**
Sure. The wonderful thing about working with data is that as you play with it, you have these intermediate artifacts that are creating value, right? And as you experience them, they'll create value for you.
You can then be sharing them with clients with your mailing lists, what have you. It doesn't need to all be in the form of the final report. There are all these assets along the way.

**Ellie Rofe | 30:22**
M way, creating Okay, fabulous. I'm in. I've got that call with the VC on Monday. I'm looking forward to it.
I was thinking, based on what I've been talking about and understanding of the investment thesis, now I see it everywhere. There was a big article that was talking about founders. It was really focused on SaaS. A lot of this stuff is...
But founders don't know how to tell a story. They don't know how to tell the vision. I'm like, from what I see, they just don't have to say when they're going to make money. Why is everyone obsessed with visions?
It's so weird. It's like, what is it, ten years on from Silicon Valley, the sitcom? We're still going. No, everyone just needs to hear the vision. Anyway, [Laughter] it's.

**Ray | 31:15**
Radio on the internet. Still, my favorite scene from that of.

**Ellie Rofe | 31:23**
So, I might have to rewatch it because I love it so much.
I think there's... I think I have an in to say this is what I'm seeing and then asking her after I've asked her what she's seeing in the market and this is what I'm seeing and where I can shore up my skill set to be more helpful to these founders, in turn, making them more helpful to her.
One of the things I've been thinking about in terms of this VC report is that I had it in the background the other day. It's not. There's a lot of noise and hot air in it, as you'd expect given the people on it, but that's Stephen Bartlett, Alex Hormosi, Cody Sanchez, and Daniel Priestley having a roundtable about building businesses, etc. One thing I did think about was they were talking about the usual routes.
I'm wondering whether I'm just overthinking this or whether it would be useful for me to send letters to VCs with an envelope coming from France with their handwritten address on it and just actually try to bypass all this noise and get in front of them with something. Or am I just creating a load of work because I'm just overthinking that? I'm hopefully getting introductions directly to some VCs, but I want to keep trying to attack this myself as well, rather than just relying on that one flex point.

**Ray | 33:10**
Well, a couple of things come to mind. The question is, what's in the envelope? What is the value you'd be delivering to to.

**Ellie Rofe | 33:19**
So it's a request, obviously, but there would be a personalized section, which is about what I would hope to understand more about. Based on their experience, based on their investments and their apparent thesis.
Then, offering them... There'll be a QR code and a link for them to go and look at what the report would look like and to book a call with me. Obviously, as another offer, if you would like to do this, I could offer discounted pitch services for one of your portfolio companies or something.
So, it's a sense of trying to connect with them. I am asking them for a favor, but I'm trying to offer something in return and trying to make it as clear and simple as possible.
What did you think? Should it be in the... When I suggested it? What was your. Like. Should be sending that.

**Ray | 34:42**
Something of value like this is a report, this is an insight, this is something that is going to help you make money today.
You know, the which is whatever it is as opposed to what you're talking about is basically a direct mail sales pitch.

**Ellie Rofe | 35:00**
Yeah.

**Ray | 35:02**
And can be fine as far as it goes. But now, if you're talking about, "I help you help your investors," then they will associate that service with whatever the quality is of this marketing piece, which would probably be true for anything you do in terms of communication, right?

**Ellie Rofe | 35:16**
H.

**Ray | 35:20**
You're a communication marketing professional, so anything you communicate in the market is going to reflect on you.
So, what do you think is the best foot forward? If I would think if it's a good enough idea, then it's something you would be suggesting to your clients with their push decks to be sending a letter, that kind of thing, because that's the way you get in the door with those kinds of folks, right?
So, if you think that's the kind of thing that would work, I think there is... I would love the idea of the handwritten letter, it is certainly differentiating. But I think that the way you want to open the handwritten letter is XYZ, you know, recommended that I get in touch with you, that becomes... Wait, what is the reason they're going to care about you?
It's not going to be because of a who, not because of a what, right? The who I needs to be... Wait, I got a letter from the famous Ellie. Right? I got a letter, and it was referred by X, and really not meaning one of those two things. Why am I continuing to read this thing, and now you're just starting to tell me a story about marketing or what have you?
I think there's a better story about that. I think that the pitch boils down to there's a lot of time that's wasted in pitches and wasted in... But I wouldn't even use the word "pitch" because it feels so cheesy.
Right? But in investment meetings, because the investor is looking for an understanding of the economics and geography of the business, and these scientists just don't know how to do that, right?
There's... But there's... Which doesn't mean there's not value there, but it means it can't be discerned, and therefore there can't be an intelligent decision made. This is why you do what you do. Blah.
But what is the value they're getting from that note immediately that they will be able to feel in the first fifteen seconds, or that their secretary is looking at and saying, "I need to put this on my principal's desk because this is going to provide that person with a lot of value"?
It's going to immediately improve their day. As opposed to being a nicely handwritten picture among 100,000 pictures we're getting today. So that's the kind of thing I would look at, like you were describing. You know, it would be a personalized section or what have you. I don't think that's quite good enough.
I think it needs to be... What if you're going to be doing something as personal as a handwritten envelope and ideally a handwritten note? It should be because there's something for them to care about, right?
That you are delivering to them value today. That is your free offer to use Priestley's construct for that. That's the first of the four, and that might be the best way to reach those people.
But I think that it would be probably best for those people who have some reason to want to talk to you to begin with, right? As opposed to being totally old, that's the reason why. Either it's because it's from you or because it was referred by Bob, right?
If it's one of those two things, then I will pay attention to it. Then you get another fifteen seconds to sell me in the next thirty seconds. Then that gets to me. Very classic direct marketing stuff.
I think people's willingness to open the mail because it's their entertainment for the day is very different in 2025 than it was whenever the born letters were written back in the 1980s or whatever. I actually have it on my shelf, not this in view.

**Ellie Rofe | 39:15**
Okay, you have what? Sorry, right, okay, wow, yes, you said that's not in view.

**Ray | 39:20**
I have the born letters.

**Ellie Rofe | 39:28**
Sorry, I'm slightly distracted in my head.

**Ray | 39:31**
Yeah, sure. So I like that idea. It feels very guerrilla marketing here in red, and that's an oldie but a goodie. The tactic that doesn't scale, which is what direct marketing is all about, and you're at a point where doing things that don't scale makes a whole lot of sense.
So as a medium, I like it. The question is, what's the message? The way you're describing it so far sounded like you were burning the value of the burn through having just another pitch.
I think if you're going to make a request along these lines, the request I would make is that I'm doing a right?

**Ellie Rofe | 40:12**
Yeah.

**Ray | 40:12**
Li as developing market expert is far more interesting than Li as providing, you know, investor deck, you know, services.

**Ellie Rofe | 40:23**
Yeah, no, I would have been.

**Ray | 40:24**
Like.

**Ellie Rofe | 40:25**
I would have been saying, "I'm doing a survey. This is what I'm hoping to understand from your point of view.
But what?

**Ray | 40:32**
Right.

**Ellie Rofe | 40:32**
I'm wondering. What I've been pondering in the back of my head is whether the thing that might be interesting to them is a slight adaptation of the analysis from the structure tool.

**Ray | 40:34**
But then. What happened? Yes.
He.

**Ellie Rofe | 40:54**
And I've been researching and analyzing decks and the problems that they have consistently. The next piece of this puzzle to get better pictures on your desk is for me to talk to you directly to be able to understand from your point of view what you see and what you care about most. To complement this more data-led analysis or whatever.
Does that stand out? I mean, it's visually arresting when you see those little color codes and stuff. If they've got a note and then they've got a sheet or two with some information on about what patterns and trends have been seen or whatever. Don't know.

**Ray | 41:40**
Well I think you say you, including, "Hey, here's the... Here are you know, I've attached you know a preliminary with a first round of findings in my second round. I'm doing it because of the virtue of... One is can be an interesting report, which ideally it should be because you should be someone who knows how to tell an interesting story."
The second is establishing your bona fides, that you're not going to go ask them dumb questions because you already did your homework. So, I'm doing this in two rounds. The first is secondary research with a little primary research,
and the second is talking to the smartest people in the industry. I was hoping that you would do this. And then, everyone who participates, I will give you a copy of the report.
You have some ambitions to make it a little bit more... You have to have an AI agent to be able to interact with it, to understand it better. The most important part is that this information would be available to you.
Because my whole thing is to help investors and founders be able to express and make better investment and.

**Ellie Rofe | 43:05**
YP.

**Ray | 43:07**
And I like that you can sort of decide that bare investment decision thing.
But like that idea like what you do isn't just about helping founders extract money from the VCS, but about the VCS, yeah, getting better return on their time and better clarity on their deal flow because you know, the founders are doing a their job.

**Ellie Rofe | 43:28**
I'm just wondering on Monday, I'm wondering if a reciprocal ask ask.

**Ray | 43:36**
He.

**Ellie Rofe | 43:40**
So Dina works at Orbimed, which is a massive fund for biotech. A big one, not the biggest, but it's big.
They must get hundreds of pitches there, and they must have some place. They save those pitches. So assuming that data, there aren't any data issues with the pitches they receive, the solicitations, and the stuff.

**Ray | 44:06**
They shouldn't be confidential, but that's usually a requirement when you send something to as.

**Ellie Rofe | 44:09**
Exactly. They won't be non-confidential.
It's just GDPR and crap like that, but I don't think that should apply. But there is a possibility where I could say to her as the first step to create some of that better primary data using the tool and an analysis that would be useful to them potentially, too, is can I have access to your pitch, the pitches you've received, run them through this, analyze patterns,
and if this tool is useful for you as the first passes. I'm sure they must be using analysis on this stuff by now. If this tool is useful to you as a first pass analysis on Pitchfix so that you can get a summary of what's happening, then obviously, we can work together or whatever.

**Ray | 45:06**
Well. yeah, I think you're getting too tied up in the utility of the tools, right? What you're looking for is data and your expertise, right?
You are sure you're coming in, and it sounds like you got two asks. The first is that we'd love to talk to smart people, maybe. Do you know smart people about what they are saying in the industry? You've been doing your secondary research, you've been looking at it, and you can talk about the various sources you've been doing. Mackenzie and Goldman Sachs and whatever, and
now what you're doing is the next layer on top of it, which is this thing, and you want to have that down. The second is that you get a lot of these pitches, many of which are unsolicited, many of which, I'm sure, are just going straight into the circular file.
One of the things I'm looking to do is get a better understanding of what you are seeing now. I'm doing tooling for studying this stuff, whatever, but if it were possible and I don't know if it does as to find out if there are rejects, I'd love to be looking at the rejects.
I'm sure many of the rejects are rejected because the business is bad, but you're going to find, hey, look, in the vast majority of them, they're all making the same seven mistakes.
Then that becomes content for you. I examined a hundred pitch decks and blah, and you don't need to leave it about what's in it for them.

**Ellie Rofe | 46:32**
That's what I.

**Ray | 46:36**
You know. You. They can. People will do favors for you just because you ask, especially when you ask for their garbage.

**Ellie Rofe | 46:48**
Yeah, that... Yeah, okay, I like it.

**Ray | 46:48**
It's so easy for me to do. I've got 50 of these things in my inbox. I'm just going to forward them to you right now.
Or they give you grief about GDPR. I would name learn the Thing.

**Ellie Rofe | 47:09**
I don't... Who knows? I don't get the impression Dina has much truck with that kind of stuff. So yeah, okay, that's
clarified things in terms of how to go ins.

**Ray | 47:22**
That sounds wonderful. It sounds like there's lots of opportunity there. Yeah, the remember three circles of... There are people who are ready to buy from you and people who are almost ready to buy it from you. People who don't... I would probably be spending more of my energy in the second circle, right?
Your idea of making phone calls and doing direct mail approaches... I would keep that in the second circle and give it that higher level of attention because second circle stuff... People who don't know you, that's where it just gets thrown in the trash, and that's where all that energy just gets burned away, and then for that, you're looking for reputation, really.
That's where your social media stuff comes in. That's where YouTube can come in. It's where referrals are getting talked about by the people who you are serving today, that comes in, and the circle expands.

**Ellie Rofe | 48:16**
But that's... Yeah, so the catch-22 there is I haven't got a ton of people who can introduce me to a ton of VCs, so I don't have many VCs in that second circle, and that's it. And maybe I should prove myself enough in terms of not being a pain in the... In terms of asking decent questions of them. Those become people who might introduce me to other people if deemed useful.
But those are the other people in their competition, and they're fiercely raved. So who knows? And.

**Ray | 48:55**
Well, then, I mean, the alternative to the referral thing is that if you know them, and this is the person who works across the hall, then you know that that's one of the most compelling openers to a cold call, right? "Hi, I work with...
I've been doing work with X across the street and solving... Solving Y for them. Is that problem for you as well?" Boom. You're establishing that you're credible based on... You are either a neighbor or aspirational.
That's a strong place to be. Then it's like, "Okay, well, these investors are not paying attention to that. What are they paying attention to?" Remember, you don't always need to be selling your core service. You can be looking for, "What are the pain points that your core audience is experiencing?"
That's why Dann Sullivan... Who do you want to be a hero to? Because it keeps you focused on those people. I'm like, "Okay, so what are their problems today?" Maybe the kind of problem you want to solve is over here, but if the thing they're feeling acutely is over here, that's probably what you'd need to be focused on delivering for them first.
Maybe on a free basis or prospect, even if that's not what your core competency is. Otherwise, how will they ever find out about your core competency if you're never talking about them? Talking about things that they care about.
So, the answer is I don't know what those specs care about, and you're looking for some insight. Your secondary research is giving you some angles on this. And frankly, the fact that they maybe that they talk to startups insights or whatever, right? You got a quote from something, you can bootstrap that into a conversation. Hey, look, I'm doing research on this. I saw that you gave a quote to... If I could have just 20 minutes, I'm putting together a survey in the biotech investing field because I help founders talk in the language of the VCs so they could be having more informed conversations. Could I? It would be possible for us to do 20 minutes now, 20 minutes later or whatever.

**Ellie Rofe | 51:04**
Yeah, this is true.

**Ray | 51:06**
And that becomes the basis of something. So, when we talk about your valid business reason, it doesn't need to be necessarily people who you have done business with. It doesn't need to be someone who's referring to you. It can just be a factor across the street. It does need to be someone who you've actually worked with.
If you know the referring point is from this secondary research, which, frankly, you are one of seven people in the world who's actually reading.

**Ellie Rofe | 51:32**
Okay, cool. I think that gives me a lot to get on with. I think Monday will be interesting as a kind of scene setter for me. It's a while since I've spoken to BC in this industry.
I've obviously heard second-hand lots of stuff. The biotech VCs don't speak so much online. They're not as big as they're big noise and VCs congratulating themselves, which you get a bit more in SaaS, so they're a little bit shadowier than the others.

**Ray | 52:02**
Yes.
That comes to a useful question. Where do they do their professional development and networking? Well, we do this conference that's in London, but it's going to be next month or wherever.
Fine, then you should be there.

**Ellie Rofe | 52:25**
Absolutely. The conference season starts in September. Some of them are just out of this range at the moment, but I think there's one that I might be able to get a Wangler secondary invite to in October, and you know I will be.

**Ray | 52:29**
Academ yeah.

**Ellie Rofe | 52:39**
I will be trying to make my way to as many as possible over the next six months or so and scope them out and work out what is or isn't possible through them.

**Ray | 52:49**
Yes. Then the second question is, "What are the conferences that are worth going to as conferences?" Then, where are the conferences that your friends are going to? Right, like BCS or whoever, it's like, "Hey, I'm going to be at X, you should..." Then, you can ask if we're going to... Yeah, you should totally come.
I'll introduce you to people. Okay, now you have a value proposition that's very different from just going to a conference and sitting in the stands and paying attention to what they have to say.

**Ellie Rofe | 53:22**
Yeah, absolutely, yes. That's... I have been asking people, and that's a question I should absolutely ask. Dina, where should I go to meet you?

**Ray | 53:34**
Cirer cool.

**Ellie Rofe | 53:38**
Yeah, okay, well, that's a good question.

**Ray | 53:39**
Where is Dan? In the city.

**Ellie Rofe | 53:47**
She is normally between London and Switzerland.

**Ray | 53:50**
Okay, yp.

**Ellie Rofe | 53:52**
She. did move to Alby Mer.
I don't know if I think she's managing UK EU deals, so she's probably still there, but Alby Mer is US-based, so she might be in New York and.

**Ray | 54:02**
Okay, fair enough. Yeah, that becomes a question mark as well, and you make an interesting point about Switzerland. Cool, this helped you get me right to start hanging out with Neek.

**Ellie Rofe | 54:17**
Pardon?

**Ray | 54:18**
This is I'm just checking, and I appreciate only a few minutes left, so I want to check if there's anything else we can do or if you are feeling okay heading into the new week.

**Ellie Rofe | 54:27**
Yeah, no, this makes a lot of sense, and it's been really helpful as always.

**Ray | 54:32**
Super cool. I'm glad.
Let me know if there's more I can do, and we'll see you on Tuesday.

**Ellie Rofe | 54:38**
Okay, chairers, see them.

**Ray | 54:39**
Take care, my he goo.

