# Ellie and Ray Zoom - Aug, 08

## Key Points
- Ray shared his progress on the state change assistant, explaining how he shipped it after receiving feedback that his initial version was not useful, and is now seeing users create history and understanding with it. 
- The AI assistant developed by Ray includes different specialized mentors focusing on mental models, Xanadu questions, search functionality, and a unique "Musical Mentor" that can transform conversation transcripts into songs in various styles. 
- Ray explained his approach to data ingestion for the AI system, converting PDFs to Markdown format to reduce token usage while preserving most content, allowing for more efficient context loading and comparative analysis across multiple books. 
- Ellie described challenges with using Claude projects for analyzing complex documents with charts and tables, noting that the AI tends to make claims based on limited sources rather than providing comprehensive analysis. 
- Ray recommended using tools like Superbase or Airtable to give AI access to structured data rather than trying to load all data directly into the context window, explaining that AI works better when it can query databases like humans use reference tools. 
- For analyzing raw numerical data, Ray suggested implementing MCP (Multi-agent Conversational Programming) to allow the AI to formulate questions and access tools that can query databases, create SQL queries, or generate Excel formulas. 
- Ellie realized she could use a combination of Notion for summaries and ideas alongside Superbase/Airtable for raw data, with the AI accessing different tools for different types of data through structured MCP. 
- Ray discussed the concept of "Shopper" - helping users and AI avoid reinventing existing solutions by encouraging them to search for available tools before building from scratch. 
- Ellie recognized she could use AI to scope requirements and find existing tools to knit together rather than building everything herself, similar to how Demetrius composes solutions from existing components. 
- Ray emphasized the value of adding expert analysis to data, explaining that layering personal expertise on top of public information creates "alchemy" - turning public data into proprietary insights. 
- Ellie shared her upcoming meeting with a VC from Orbimed (a major biotech fund) and discussed strategies for making connections with VCs, including potentially requesting access to rejected pitch decks for analysis. 
- Ray advised against Ellie's idea of sending handwritten letters to VCs unless they provide immediate value, suggesting instead to focus on establishing credibility through preliminary research findings and offering to share the final report. 
- For approaching VCs without direct connections, Ray recommended leveraging secondary research to bootstrap conversations, using quotes or insights from publications to establish relevance when requesting meetings. 
- Ray suggested Ellie identify conferences where biotech VCs network and seek introductions from contacts who will be attending those events rather than just attending as an audience member. 


## Action Items
- **Ellie Rofe to investigate data tools and approaches for analyzing reports and raw data, particularly focusing on using AI tools with structured data access rather than brute-forcing through AI studio platforms.** - _Ellie Rofe_
- **Ellie to offer participating VCs a copy of her completed research report in exchange for their input.** - _Ellie Rofe_
- **Ellie to ask Dina for access to rejected pitch decks from Orbimed to analyze patterns and demonstrate the value of her analysis tool during their meeting on Monday.** - _Ellie Rofe_
- **Ray to meet with Ellie on Tuesday for their next scheduled conversation.** - _Ray_



