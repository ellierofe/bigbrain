# Ellie and Ray Zoom - Nov, 21

# Transcript
**Ellie Rofe | 00:04**
Hello. Sorry, I am a few minutes late.

**Ray | 00:07**
Fine, absolutely fine. Where do I find you in the world today?

**Ellie Rofe | 00:11**
I'm in France, but I'm huddled. Excuse the complete unprofessionality of this, but I'm hud unprofessionalism of this. I'm huddled in the bedroom because art central heating isn't working and it is for reasoning.

**Ray | 00:22**
Goodness, I'm sorry. Yeah, I've been living with that for the last week.
The boiler went out. I think like a couple of hours after our conversation last... Actually, no, we didn't have a conversation last week, so we would have had it.
So, yeah, it went out, and it turned out to have been... It's like one of those not igniting. Okay, what's the procedure like? Well, for turning off, turn on again and you press the relay button.
Okay, I turned it off, I turned it on, and started smelling a burning smell. That's not good. And as the burning smell, I thought it was pretty familiar, right? I recognized it immediately. Obviously, it wasn't oil burning like something that's more familiar than that, more close to home. It was burning electronics.
So the controller failed.

**Ellie Rofe | 01:13**
Wow.

**Ray | 01:15**
And the controller is actually a very expensive part of the thing.

**Ellie Rofe | 01:18**
Yeah.

**Ray | 01:19**
So it's like half the cost of the boiler. And then not only that, it's not available. So I went through all of this first and said, "Well, they came out on Friday. You're sure?"
But we'll just need to put an order for the part. Good news, we already have the part. That's great. We'll get fixed on Monday, and then Guy comes in, he's like, "This part does not fit in that space. Why did they think this would work?"
Then they discovered that it was actually a more expensive part, more expensive electronics part that was failing, and then that part wasn't available at all. And then it's like, "What are we talking about here?"
The answer is we need to replace your boiler. Previously, when I asked about this, "Hey, is this thing worth replacing or do we finally need to replace boiler?

**Ellie Rofe | 02:00**
Yes.

**Ray | 02:02**
Like, the boiler?" They said, "Well, we're scheduling for after Christmas."
Okay, then I guess we need to get that fixed. Now, no. I think about telling you it's after Christmas, and no, for this kind of... You don't have a heat situation. We do it on a tighter schedule this coming Tuesday.

**Ellie Rofe | 02:17**
Right.

**Ray | 02:17**
All of which is by way of saying that I am right now in my office with a space heater running, no access to hot water or heat. The rest of the house is very cold, and I sent my wife and children away to have some adventures while we're dealing with this.

**Ellie Rofe | 02:36**
Yeah, so you're like at the frontier while the wife and children get her head away.

**Ray | 02:39**
And At least now we know when the whole story comes to an end.

**Ellie Rofe | 02:48**
[Laughter].

**Ray | 02:50**
Yes. You know, the here I am sitting here surrounded by all these computers, but, like, I'll still call myself a frontier first.

**Ellie Rofe | 02:59**
Yeah, why? No. [Laughter] Yeah.

**Ray | 03:01**
And guess we both get to live with that today. Is there a central heat?
Is there a plan to get it fixed up or what's the.

**Ellie Rofe | 03:13**
We're trying to decide, as it's a long story, but basically we don't have town gas or whatever you'd call it. We have a cistern, a tank, whatever.

**Ray | 03:26**
Yes, sure, we did you.

**Ellie Rofe | 03:28**
Yeah, and next year, we're hoping to completely remove that and just move to solar air sourcing, heat pump, maybe a wood burner. So we're trying to work out whether it's worth trying to fix this out from this side of things or whether we just muddle on through until March, when it's going to be warmer anyway, and just deal with getting another couple of oil burners, like oil heaters and stuff, and just make our way through the winter with it.

**Ray | 03:56**
Two goodness, one.

**Ellie Rofe | 04:05**
It's. We'll see. We'll see it. It's probably cheaper to buy a load of thermals, some radiators, and just go with it than it is to deal with sorting all that out.

**Ray | 04:23**
Alright, so, let's the week ahead. I appreciate the report and the sharing about the stuff with Lauren and the offer and what have you. How can we help? You have the best possible next week?

**Ellie Rofe | 04:43**
It's a good question. I think I've just spoken with Natasha about the event, and she said we've had unique views excluding us, we've had fifteen people look at the page, and three people clicked through to payment and nobody paid.
So that's an interesting moment. I do.

**Ray | 05:09**
It was a thing, wasn't it? Was it always a paid program? Okay.

**Ellie Rofe | 05:16**
Yeah. I think people might be saying, "Secure my spot", thinking it's free, and then seeing that it's not, and that might be part of the reason that's happening. Or they're just deciding... Who knows?
So, thinking of ways beyond that, we brainstormed some ideas around... Obviously, now I've got to fix the ratio on the page as well, so it's not contained as much, but it's still not ideal. I hate the software she's using.
But we... So the page looks a bit better. We've just recorded a video. I'm not sure how good it is because we did it off the cuff and it's a bit all over the place, showing the thing I'm building and how it's going to be used during the session and given people a tangible understanding of why this is different. I'm going to be posting a bit more about it anyway, in general, and post a bit more about what people are going to get and maybe add that as a video letter.
Then I was thinking I should probably talk to Dina, the VC I know, and say if you've got any early-stage companies because she tends to work at a later stage. If you've got any, you know, people raising seed or series A who this might be useful for, to get a kickstart. This is happening in a couple of weeks. The same to Aydan and AJ, whether they know anyone who is in a position where this might be useful for them.
Just try to get out to people directly.

**Ray | 06:59**
He.

**Ellie Rofe | 07:01**
And going to do the same, and I don't know whether there are any other great ideas you have around promoting it, really, from what you understand of it at this point or anything that's not making sense.

**Ray | 07:18**
Well, I wonder if the offer was exciting, but all these things are funnels from attention, right? So, you, the idea would be that you have people who have come to know and trust you a certain amount who are like, "Hey, I now have a way to redeem that right by doing this next level up." The fact that nobody's looking at the offer implies that either the two of you aren't really promoting it to your people or that you know you're not really at that point yet where you have those people for that kind of thing in the funnel.
I've been thinking about stairs. Is this really like a stairs step up, or is this like the second floor? You need to have something in between in order to be able to bring people along.

**Ellie Rofe | 08:06**
Yeah, I do think that's a risk. And I did wonder about that, and I think it is... I think that's probably the diagnosis, that it's just not right. We're not there yet in terms of... I think Natasha has more awareness. She has packed people into a paid workshop before, but not this cost. She's cheaper.

**Ray | 08:34**
Cheer. Cheaper. More expensive before. What's the.

**Ellie Rofe | 08:37**
Cheaper?
Yeah. I can't remember exactly what the workshop was, but I think it was more like $7,999. I do wonder whether this is just too big a leap at this point, and whether we just reduce it and just drop it down and see whether that makes a difference.

**Ray | 09:00**
Two?

**Ellie Rofe | 09:04**
And haven't been promoting it as heavily as I would have been, but for the trip back home and the problems that were going on, family problems. But I have started now.

**Ray | 09:13**
Yeah.

**Ellie Rofe | 09:14**
And hopefully that will build. I'm building back and getting a bit more engagement on things.
So yeah, I feel like we've got what have we got? Fifteen clicks. It's barely enough. You can't tell what's going on with something until you've got at least a hundred people looking at something.

**Ray | 09:35**
Yeah. All you know is that they're looking at it.

**Ellie Rofe | 09:40**
Yeah, we know that 5015 people have looked at it. There are 31 page views. It's not great. So yeah, that's all we know at the moment. So I don't know whether the goal is this week to push out people individually, keep promoting on LinkedIn. I don't know whether it's worth talking to...
It's just too short a time. Short term for new contacts, like direct contacts, I think, to say, "Hey, we're doing this." In two weeks' time, take notice of this. Yeah. I don't know.

**Ray | 10:20**
Yeah, the... Yeah, it's interesting. I was talking with Detrius, and his coaching call a little earlier, and his thing is, "Ray, I want to open up the new doors and go talk to Twitter."
Right? The irony is that his situation is that he doesn't think that his stuff is getting him GA clients, but he and I just did this meetup last week. They got 65 sign-ups.
So, there's a tension for the next level up. Then, part of it was he doesn't really know what to do at that point. So, there was a little bit of turning the wheel from, "Hey, he's trying to be broad attention," to, "How do you curate the people who have expressed enough interest to spend an hour with you on a call?" Or at least, twelve of them decided to spend an hour on the call.
That's an indication of engagement that then you can curate, right? So, for him, it was a "Hey, you're at this level, let's work." Or you have a bunch of people at this level. Let's work on those instead. What he did was he dumped an email and said, "Now I'm looking for the next thing." That's an asset.

**Ellie Rofe | 11:30**
He.

**Ray | 11:32**
Let's take care of that.
I think the situation for you might be a little bit the right?

**Ellie Rofe | 11:39**
One.

**Ray | 11:40**
You try and say, "Hey, I've got something up here. We don't really have it up here yet, at least not at that kind of scale, right?"
So, the question is, how can you stairstep it down a bit and be able to have something you can spread the word about? I actually thought a lot of the posts you're putting up, talking about these issues...
I think they look nice, and they are interesting and they are useful. The trick is just to keep going until you get that engagement wheel going, right? People notice, have them solve the problems they care most about. I gotta say, the angle that you used with state change that got a lot of attention is an angle you're not using anymore, which is AI.

**Ellie Rofe | 12:32**
Yeah. I'm just about to post about that because I'm building with it. So how to... How to get it to do that.

**Ray | 12:39**
Right. And like, you know, marketing. And in the age of AI, hard tech, in the age of a I mean, there there's a lot of, you know, connecting with trend stuff that like I thought you were doing really well when you did that stuff.
And state changed, you know, earlier this year.

**Ellie Rofe | 12:52**
1.

**Ray | 12:52**
And got... I think that hasn't been as part of what you are doing, right? Because I think it's more like you're trying to describe what you do as opposed to thinking about it as this is a product.
Now you're marketing your own... It's physician healing himself, right? You're actually looking at what you are doing as something to be marketed, right? Even though it's marketing by itself. People who do that well really soar.
You've seen people who do that well, and there's a little bit of just being able to disconnect and say, "Hey, you have the product and be able to market that."
Part of that is doing things like connecting it to trends, right? Like the kind of thing you'd give advice to someone else to do the same thing you can do for yourself. I think that would help, but the other aspect is...
Okay, now, what's the offer? What's the thing they can buy first? Where to buy is just involving some degree of commitment, right? Professor prospects level category that is... That moves them up.
If what you're finding is, "Hey, this is too big of a stairstep, they can't get there." Okay? What's the thing below that? You could be looking at the cheaper workshop that's totally an option.
I think that the event... What Robert's done, and Robert's events are going well despite his piss-poor marketing of them. The Demetrius stumbled on actually promoting it well and got it, but it's not following up on it, but it's showing that there's a lot there, and I think there's that opportunity for you. I don't know if it needs to be free. I don't know if it needs to be just cheap, but the...
I think there is a question of what that next level of engagement is, which then gets more people in because I think that will help broaden your scope. Because then you become remarkable because they've actually engaged with you on an experience that more people will have, and then they can then remark about it. You can even ask them
to spread the word about it, which then gets you more attention, which gets you more engagement, and then that turns into people who are building that trust, which then turns into doing business because they need a combination of having that basis addressed and having a need.
Some things were jumping straight into the transaction that's great, but what becomes the more reliable process is moving people along that spectrum. And a squeeze page is about getting you into the transaction.
That's fine, but in order for a funnel to work, you need the Y part.

**Ellie Rofe | 15:50**
Yeah, okay, I'm trying... I could be wrong. I just feel like there's such a disconnect in terms of the audience and that... I feel like the tech audience, the audience that is wanting to build stuff and is really excited to hear more about digital twins, MCPS, and things, jumps on those calls really readily.

**Ray | 16:16**
He.

**Ellie Rofe | 16:20**
And I feel like the founders who are struggling, especially in biotech. Natasha's lovely, but I do find biotech a much more frigid environment and much more locked off generally compared to people who are like... Yes, I'll just jump on. They're quite skeptical. They're quite locked away in the lab. They're quite science-focused and network-focused and not necessarily jumping through these funnels and jumping on calls.
So I'm just trying to work out how to frame a regular meetup so that people who are struggling... They'll go to an entrepreneur that the crick is running because the crick is the crick, or they'll...
But even then, they struggle to get people to sign up.

**Ray | 17:15**
Ye.

**Ellie Rofe | 17:15**
And what they were saying to me. So I'm like, "I completely agree on the meetup being a great way to get people in." I'm just trying to work out what the angle is to say to people, "Come along to this for an hour and spend it with us." Make it tangible enough that they actually feel like it's worth their while.

**Ray | 17:44**
Well, I mean, you can take some of these insights about the deck workshop, right? A 90-minute
workshop, "Why your deck is not connecting with investors." Three things you can do: whatever... There's just riffing obvious marketing constructs, but...
They have a problem, you can be offering the solution to it. Frankly, anything that you can offer that is solvable in Meetup is not something they're going to go pay lots of money for you anyway.
So there's no big loss. You're just building up the trust. I would expect that the first Meetup for people who are going to show up, then you put the Meetup on YouTube, and it was like, "Hey, we had a good up.

**Ellie Rofe | 18:29**
Yeah.

**Ray | 18:35**
Or you don't even need to call it Meetup. We did the first good workshop, right? Workshop mastermind.
These are terms that elevate it, right? Then we're doing one in two weeks, doing another one in two weeks or the next week or whatever cadence you think is good for you.
I've encouraged... For example, I try to encourage shipping posts or videos, a couple of times a week, figuring out what can be easy enough to do that.
Then shipping a... I say Meetup just because it's a recurring thing, but the opportunity for people to go spend a little bit of time with you on a one-week basis because that way when they're feeling pain, they're like, "What's going on? Zoho is talking about this stuff, and her content seems reasonable. She seems like a real person.

**Ellie Rofe | 19:29**
Four.

**Ray | 19:29**
That becomes the way they can engage with you at that next level. Great, now they've engaged you at the next level. You've always got their email because of the Loom whatever, and now what's after that?
That's the... You're going directly from social media to engagement, which is a heavy lift, right? But this allows them to be climbing that no, like trust. Maybe nobody shows up.
And your worst case scenario is like you have like, you know one other person in the room and you're going through your content and then you still have the content now, right? You got the video you've got, you know, for an audience, whatever.

**Ellie Rofe | 20:08**
1.

**Ray | 20:08**
I always tell people, like when they are, you know, when whenever they get to be on stage or something to get somebody like a friend in the audience to be recording them doing it.

**Ellie Rofe | 20:18**
Yeah.

**Ray | 20:19**
So you can always have that picture of you going out like this, with a thing head, because the other trick I've heard and learned is to always look up a bit for those photos as if it's the mask in front of you, whatever.

**Ellie Rofe | 20:23**
One. Yeah. Yes. Yeah, [Laughter] nice.

**Ray | 20:41**
But that that's sort of it puts you in the easy place for someone to talk to about the content because it feels a little more natural than to sort of staring at a camera.

**Ellie Rofe | 20:50**
Yeah. Okay.

**Ray | 20:54**
But that's a fallback thing. The fallback is that it creates content. The highest value is going to be that you're having a conversation with somebody.

**Ellie Rofe | 21:03**
Two.

**Ray | 21:04**
And somebody's showing up and you cop a bit of content, and the content is connected by that person, stop. Have the conversation with them because that's the biggest value that's going to be in that trust relationship.
Probably that's going to be riveting content for somebody else, too.

**Ellie Rofe | 21:19**
Yup, okay.

**Ray | 21:23**
But yeah, that seems like you've got something in terms of the meetup of the workshop. I think a workshop could be very cool.
But if people aren't going to pay $500 for it, will they pay just now for the time?

**Ellie Rofe | 21:36**
Yes, I think that's a good thing. Cool. And do you do... Would you just run the same thing? So, in my head, I'm thinking I've got this tool that I'm...
It's really not that complex, but it's a tool I'm building. It would be very simple to take people through it in 90 minutes, even an hour, and have more discussion time.
Because the whole part of the thing, I realized the reason I wanted the tool is because decks are quite heavy lifting and there's lots of complexity in them, and that's part of the problem that people really struggled to solve.
So finding a way to cut that Gordian knot, just get information and progress quite quickly, would you just repeat the same thing over and over again?

**Ray | 22:34**
With the same content.

**Ellie Rofe | 22:35**
Yeah. Would you just be like, "This is a webinar, basically?" Or would you keep changing it up.

**Ray | 22:42**
Well, because I've got terrible discipline, I'd probably keep changing it up. But you know, I'm reminded of you and I are both fans of Royce Harland, right?

**Ellie Rofe | 22:52**
One?

**Ray | 22:53**
And if you've seen his talks, they are the same freaking talk.
Even though they're getting onto YouTube or whatever, my boys were excited about Sutherland and getting to see him speak. Okay, fine, you can see him speak at a TED talk. Then they said, he gave them a talk to their place.
Sure, it's 45 minutes of his 50-minute talk, all from the books, all the same content.

**Ellie Rofe | 23:12**
[Laughter]?

**Ray | 23:18**
And you know that's not necessarily bad. And then I guess what I'm trying to get at is that I'm trying to give them... Now I think we've seen enough for Syn. Let's go find some of our Thinker.
But for you know, the reason he gives the same talk is because people haven't heard his stuff before, and the people who have heard it and have heard it want to hear it again.

**Ellie Rofe | 23:36**
Yeah. He's hammering. Yeah.

**Ray | 23:41**
So I don't think that's a problem at all.
I think, if anything, my lack of discipline or people wanting to do something different probably retards my progress. So if you're afraid of, "Am I going to be boring if I keep on doing the same thing?" No, discipline will work for you. You'll probably initially edit it until you have something more refined that really clicks. Then once you have a thing that really clicks, the hard part is for you to keep on doing that because you're getting bored with it even as the audience is not.

**Ellie Rofe | 24:06**
Well, that's where I've tried to hedge that by saying we do the thing with the AI, we do the thing in the tool so that there is a live thing. There's always going to be something slightly different, there's always going to be different questions coming out of it, and I will be learning rather than just teaching.
Okay, that's interesting. I will... I'll start doing... I might have to start doing that after this workshop is meant to run so I don't just start cannibalizing just in case there's some mad people who want to jump in.
But, I will... I think after that I'll say yes, I'm doing this, come comejoin.

**Ray | 24:54**
And if you would permit me to, I would definitely be there.

**Ellie Rofe | 24:57**
Yeah, absolutely, you got an odd pitch deck, yeah, hard tech, any old hard tech.

**Ray | 25:03**
For my bio company. Right? I'll just define it. It would be all hard as 5% Tech.

**Ellie Rofe | 25:11**
[Laughter] Exactly, perfect. Okay, that's very helpful. I shall keep pushing on.
I think more than anything, though, the process has pushed me to just get on with talking about stuff, just get on with studying and turning things into something. So I don't mind it. Even if it's a failure as such, I don't really mind.
It's been an interesting experiment, and it's been a bit of a forcing function for me to move on. It's just given me a bit of structure to start talking about. Then, yeah, I think, I suppose that's an interesting thing you say about trends because I have felt like, and I guess they always get engagement.
But I felt like every time I see a post about AI, unless it's genuinely interesting, radically different, or from someone who is a foremost expert, I just roll my eyes and move on. Because, really, is the rule of three used in AI content or whatever?
It's very boring. But I suppose that's just an overcorrection on a massive level, isn't it? Because AI is just there now. It's not like it's refusing to talk about the Internet in the early 2000s or something and just going, "No, I shan't talk about this."
So it's just finding ways into it.

**Ray | 26:58**
No.

**Ellie Rofe | 27:00**
Yeah. I've just been, like, over correcting there. Massively.

**Ray | 27:05**
Well, you feel because of the post-mobile era and whatever, like you felt like you're all in on AI and then that didn't work out for me.
It's a little bit of a pain, and I don't mean to be unsympathetic to that, right? But it's you're right about that. It's a big trend. It's not going anywhere. And the and there's a lot of value to be created in there, you know, and people are looking for, like, hey, where are my shortcuts going to come from?

**Ellie Rofe | 27:30**
[Laughter].

**Ray | 27:32**
Like, can I make this stuff happen? Frankly, if you're in Bio or whatever, you care a lot about this AI stuff. Suleman wrote, you know, whatever it's called, the coming wave.
I think he wrote about two years ago. He wrote about generative AI and bio.

**Ellie Rofe | 27:48**
Okay, yeah, and every company I'm working with, we have to address that one way or another, that AI. That's what investors care about.

**Ray | 27:48**
These two are very aligned.

**Ellie Rofe | 28:01**
You can't pretend that they don't, even if it's just addressing the fact that AI can't do what this company is doing, and you know that, or you know that this company is fixing something so I can do something. It has to be addressed. Yes, I suppose part of the thing is I use AI. I mean, I have. I love it. I use it all the time for all sorts of things, as you well know, and it just feels like I think for me, I struggle to think why anyone would give a TOS about what I'm doing with it, because it's
so personal to me, some of the stuff I do. I use it across the board for all sorts of things. So, I think the positioning of that is me just talking about trends in AI and how they're affecting investment, or is it me talking about how I use AI? Because I feel like everyone's talked about how trends, how AI is affecting trends in investment and stuff like that, and people with far better understanding of those markets than me.
How I use it and how I use it for PITCHDEX is probably a bit more interesting, I guess.

**Ray | 29:21**
I think both of those things are interesting because the question is, how does it affect Bio, how does this affect the investor contact for Bio startups? Useful, right? This is all you as the whisperer, right? The same thing you were looking at, going down the road of doing the survey of the investors and whatever else. The position of expertise that you have is so much more valuable than you being a Pitch Deck person, right?
Because the Pitch Deck person is a technician who does design work, right?

**Ellie Rofe | 29:44**
One?

**Ray | 29:49**
Where you are a wise advisor and the, you know, and of course, you can do the design work too. But like, I actually really love that audit thing that you're doing with that materials science. Woman because the, you know, the you instead of you being the technician or doing all that work, you being able to say here is my you know, here here's the higher level advice for it.

**Ellie Rofe | 30:04**
No.
One.

**Ray | 30:15**
It elevates you.
It is probably the most interesting work for you. It has a lot of good stuff going on there. So you're talking. So this is broadly about... You can talk about how you use it yourself and how it works in the market, and I think even you connecting those two things.
I'm not saying everything needs to be perfect, right? But if you're doing both of those and you're talking about, "Hey, here's a connection." We talk about how this stuff is happening in the market. This is how I see that happening in a microcosm right here in my everyday right now, and then you're the sharp tip of the spear, and you're the person who understands it because you are wired into it.
It's actually kind of nice because now you're a person who understands their domain, and you understand this other adjacent strange domain that they know is hard, right? They know their investors care about it, but it isn't really what they do.
Okay. Now you're a bridge. So I love the idea of you connecting more to that stuff if it's something that works for you.

**Ellie Rofe | 31:22**
Yeah, I think I just feel in terms of the investor side of it and the market side of it, I feel like or the capital flows. I feel like that is an area I am not an expert in. I can look and think,
"Well, I know that I can look and say, "Perplexity has done this and these people have done that from my experience of using AI, but I don't understand it in the same way that people are at the face of it." Do what is actually happening in terms of AI investment valuations and that kind of thing.
So that feels like it could be undermining me if I start talking about that side of things, but I do think I could talk about it in terms of talking to investors about your business and making sure AI is in the mix, you understand the landscape.
But that's more of a positioning landscape question anyway.

**Ray | 32:28**
Right? There is always a huge universe of stuff that you're not credible to talk about, but there's a pretty good universe of really interesting stuff that you are credible to talk about, and I would encourage you to do so.

**Ellie Rofe | 32:38**
Yes. Okay, got it?

**Ray | 32:41**
The fact that I'm not good at talking about this shouldn't keep you from talking about this.

**Ellie Rofe | 32:45**
Yeah. Uhmm.

**Ray | 32:48**
And, they're like, "But what about X or Y or Z?" Those are good points. I know people who are really expert at that point and that. But that's not really where my focus has been because it's such a big topic.

**Ellie Rofe | 33:02**
No.

**Ray | 33:02**
And your ability to, like, refer them across the street to people who are expert at, you know, other stuff in there, I think is good too. You know, the "Hey, here's stuff." I don't know, it's totally great.
I find talking to an expert... There's the first part where you are overwhelmed with their level of knowledge and insight, and then there's a big credibility-building moment where they say, "I don't know," because once they've done that, you have greater confidence at least that you're not being bullshited.

**Ellie Rofe | 33:35**
Yeah.

**Ray | 33:38**
So I think it's perfectly fine for you to be saying, "Hey, here I've got some insight here." That's a great question. I don't have the answer to that. That's what a guest host can be good for. Do you have thoughts on this?

**Ellie Rofe | 33:57**
Okay. all I care care.

**Ray | 34:01**
I think that's some great stuff. I think the stuff you have been talking about on social media is compelling. I like the visual aspect of it, right? You putting that to work shows that you're a visual storyteller.

**Ellie Rofe | 34:13**
M.

**Ray | 34:15**
And, that the workload of doing it isn't getting ridiculous. There's a lot to be said for... I mean, I'm actually right now, I put up this silly thing I made in Gamma, right about the social media image I made of it, and it's getting actually quite a bit.
I mean, even just being visual is good. You being actually good at being visual means that simultaneously increasing distribution as well as showing off part of what you do will be the product.

**Ellie Rofe | 34:45**
Yes, definitely. That is the goal. Okay, [Laughter] that's where I have historically ended up, completely stimming myself, but I'm actually pushing through it and just going, "I just keep talking." I just keep talking. I hear from interesting people and stuff.
If I'm perfectly honest with you, I think there is a layer where I have worked with very high-level people, and then I have broadly marketed in the past to people who are more in that sort of Daniel Priestley, Tony Robbins world where they are. There's just a lot of emotion and psychology, and the actual content isn't very high level a lot of the time.
I think sometimes I feel more exposed working with industries where there is high expertise, whether it's the investors or the scientists or whatever, and not... I think that's possibly a huge part of where I am. I get nervous around this stuff because I know a lot about storytelling and stuff or whatever, but then I start diminishing it.
I think I just need to go a bit balls out and not worry so much about it.

**Ray | 36:24**
Yes, I'd say there you have it. What you're describing is simultaneously the knock-on effect of Brit, the self-deprecating attitude towards it, but I associate with women in business, right?
Not you. You use the term "balls out." I think there's a reason for that, [Laughter], but just to say that, you know, you... I learned a lot from you, and I think there are people who you have taught at Schlange who have learned a lot from you. The people who you taught through these, even the posts that you're doing, are learning from you. You have a lot to contribute and to share.
I would wish for you to do that. The more you do that, the more credible you are. The more they know, the more they trust you, the more that turns... You don't want to be something that feels completely like... I'm not wanting to turn into Grant Cardone or Tony Robbins or any of those, you know, folks.
You know that that's. And then, you know, I'm sure you're like, I can't quite be that. Like, you don't need to be that, you just sort of need to be more. But you don't need to be out there. And I think having confidence that the things you have to say are in fact, valuable, right?

**Ellie Rofe | 37:52**
M.

**Ray | 37:53**
And add value to folks and be willing to talk about the subjects that they then in turn care about, right?

**Ellie Rofe | 37:59**
He.

**Ray | 38:01**
The. And. This is where, like, connecting to trends becomes useful, right?

**Ellie Rofe | 38:04**
Yeah.

**Ray | 38:05**
Being willing to play with your own practice the way you would play with a client's practice, I think becomes useful as well.
Yes, basically, yeah. Turning you into an American tech pro. Yeah, sure. Let's give you a little bit of that. Because I think combining that with the actual character and competence that you exhibit every time you and I talk, I think would allow you to get distribution on the thing that's really valuable?

**Ellie Rofe | 38:39**
Yes, I am getting there, but this is helpful. Thank you. Okay.

**Ray | 38:46**
Okay, so you're working this workshop thing, you're updating your website, that's making you think about that stuff.
That's great. Can I quickly ask just... You didn't quite bring it up here, but the topic you brought before is the issue of hard tech more broadly, right? You had a little bit of access to people who are thinking in terms of hard tech, going beyond just the bio part, right?

**Ellie Rofe | 39:13**
Four.

**Ray | 39:15**
Is that anything you've done more of?
When we talk about study. And not much studying happened this week. Fine. But I think that's if you're thinking about market insights, I don't know, have more market insights or if there's a direction you can take to be starting to learn more a little about that angle of the market to the extent that it conceives itself as a market.

**Ellie Rofe | 39:24**
Yeah.
Yes. So, I'm funny you should ask. I forgot to mention this. It's one of the things I do find with AI is that sometimes you end up creating your own information firehose to drink from and then you're like, "No, I have to actually rationalize this stuff because the AI can't rationalize it because it will rationalize its own mistakes into it."
So, I ended up doing too much. Yes, this. I've done some analysis. Not some analysis. I did a research prompt in Claude to get a proper understanding of the top names in hard tech, some high-profile people, reports, and publications, et cetera, to start analyzing them using that tool. I developed the report analysis tool anyway, and started building that and coming out with insights from these people as part of my content.
So, borrowed authority. I've actually noticed there's a young scientist, and she's doing it brilliantly. It really made me realize she keeps... I mean, she does it almost exclusively, so it does end up pinning you into that world.
But she will do summaries of her learnings from other people over and over again.

**Ray | 40:57**
Zero.

**Ellie Rofe | 40:58**
And think it's known as borrowed authority, but it's the idea that you, inhere, some of their expertise by repeating their expertise and sharing it with other people.
So, that was part of my thing here. Just trying to connect with more people. So, that woman that got in touch with me and has booked a call is in connection with a really interesting hustle. VC like the cold of them is really interesting.
Anyway, I'm just trying to really broaden my knowledge of the VC landscape in this world and the trends, and Josh Wolfe is a good example. Who is Josh Wolfe? Who publishes investment theses and all sorts of things?
So yeah, that's definitely on the radar. Expanding into that and then trying to connect with more people who are doing that more. Ideally, it's Lauren's intro to me was great to see someone tackling this space, which I really liked because I was like, "That feels distinctive, that feels like I'm new in something." I'm into something new.
So yeah, I think that that's where I need to really claim ground. It's been my concern about working with Natasha and lovely. I don't mind doing a biotech thing at all, but my concern is I don't want to get too pinned into that.

**Ray | 42:50**
Yeah, the, you know, I was looking at your the top ten and sort of realizing a lot of them, like Sequoia Anderson, who was like a lot. Majors just sort of the majors, just an angle that might be interesting for both content creation or research boutique.

**Ellie Rofe | 43:08**
Good. CO.

**Ray | 43:11**
What are small ones you haven't heard of yet? In fact, that's actually really interesting. Content series too.

**Ellie Rofe | 43:17**
Yes.

**Ray | 43:19**
And funds will then want to promote you, right? As well as you providing something that's remarkable into the market and being you, the IR, storytelling, hard tech, biotech, that's puts you all in that zone. Another thing I have tried to encourage Detrius and Robert to do, and have not yet had success with, is advice I got from YouTube actually, a YouTube specialist from Google who was giving advice to a friend who runs a popular channel, and the advice was, "Go make more videos about right?

**Ellie Rofe | 43:59**
H. Within, like, this is gamma.

**Ray | 44:01**
Because people.

**Ellie Rofe | 44:03**
This is, you know those products.

**Ray | 44:06**
Yeah, right, so or, you know, and then some of which are like when people are looking for that product, they find your video, right?

**Ellie Rofe | 44:07**
Yeah.

**Ray | 44:13**
They're looking for a certain type of problem. They're finding your video. Your video is helping them make decisions, and that is improving your authority, right? It sort of becomes easier, right, because.
Then it's a lot easier for you to go build the content around it, because instead of you trying to come up with all your own ideas, you're describing their stuff as we're putting their front center. Do a little demo. You're able to describe bit of that and then you can just sort of move on. It becomes cheaper for you to produce simultaneously.
It's great for the counterparty connects with somebody else, which helps with the marketing part. It's what audiences want. It's what they are looking for. I do my mental mod stuff, but my mental model stuff is like that's what people look at.
If that's not the first video of mine they watch, right?

**Ellie Rofe | 45:00**
Yeah.

**Ray | 45:01**
That's what they do when they're following up with you. There there's a whole category of that for you in terms of content, but things that like sort of push out that edge.
Anyway, I think of that sort of product thing. I wonder if IK investment houses might be part of that for you, too.

**Ellie Rofe | 45:15**
M absolutely, yes. I think it's just really good study for me. It's an area that I just should know more about.
Yeah. Okay.

**Ray | 45:34**
Okay, I appreciate getting to see that. You're working the workshop today. You've got some ideas regarding content and where else might come down the road. Is there anything else I can do to be of service between now and next Friday?

**Ellie Rofe | 45:54**
I know we don't have a huge amount of time, but when you glanced at that, the new bits of the website, was there anything that stood out as wrongheaded or a missed opportunity?

**Ray | 46:11**
It's. didn't quite understand why it's so yellowed background. It doesn't look gorgeous as I'm trying to say.

**Ellie Rofe | 46:17**
Okay. Cool.

**Ray | 46:24**
So there's a little bit of... Okay, if it's just about copy, I get that.
But if what you're doing is you're saying, "Hey, I'm the presentation expert," and you dial more at that, then I think that's the first impression you want to give. If you already have some designs for slides or whatever, then I think even having it look like a bunch of slides would be totally fine, right?
But when I was looking at some of these other images and whatever, the copy looks actually quite compelling, right? But the images and the visuals didn't seem to be quite up to scratch.
And I think when you're making the first site, that's fine, particularly the white background site looks like, "Okay, that's just a site copy." Whatever. That's fine, but particularly if you're going down the road...
But if Deck is going to be right there in the front, which I don't totally know that it was, the... What's the presentation? I actually think again, so what... You mean the circles and the yellowed background?

**Ellie Rofe | 47:29**
Not a fan of the brand. You're not a fan of that new brand, Lu? Yeah, the color and the grain and stuff.

**Ray | 47:47**
I think it would look better if it were more intentionally a presentation.

**Ellie Rofe | 47:53**
What do you mean?

**Ray | 47:56**
Well, what I'm thinking here is the... And this is an idea that's not totally baked in, but right now, the way the page is set up, it looks like a site.
It's low-resolution, right? But it's rough and ready, and it has... It looks like a web page where I think you have an interesting opportunity here. This is just maybe me going too far off the rails.
Particularly as I looked at the screenshot by screenshot, I started thinking about this as a slide deck. If the page is a slide deck, which are the mechanisms available to you, you can have a page or have it contained within it, whatever you want to bet on it. I think it could be potentially compelling.

**Ellie Rofe | 48:37**
Yeah.
Yeah.

**Ray | 48:55**
And then I would ask a question like if this were a slide deck, would this be meeting standards?

**Ellie Rofe | 48:59**
He.

**Ray | 49:01**
You know, partially. I think the storytelling part and the advisory part are the highest value bits,
but I get that if you're going to be involved in visual storytelling, there's a visual part, and people will judge on that.

**Ellie Rofe | 49:08**
No.

**Ray | 49:13**
So I'm looking at that. I'm not really feeling it on that aspect of it.
I know that you're good at that. So I would wish for this to be representative of that, particularly if it's going to be like, "Hey, you're doing it for a deck." I am perhaps too much enamored of my own idea of having the page via deck, but there's... I guess it's just that visual part.
What is the visual that you want to give? That gives them the sense of... Yes. She's got the aesthetic that I want to connect with as well as the words that are telling the story that I want to connect with and the expertise right in the domain where I'm looking to sell to.

**Ellie Rofe | 50:11**
Okay, interesting.

**Ray | 50:12**
And about that particularly because of how well the social media stuff has looked.

**Ellie Rofe | 50:18**
Yeah, that's really interesting because I hate the design for the social media. That's just... [Laughter] Yeah, this is a higher-end design, but it's editorial design, so it's much more like magazine-style stuff, which is possibly why you're not responding to it because it isn't like... It probably isn't... It's not strictly B2B design, though.

**Ray | 50:29**
As design, I think, is the key. Whatever design you're going to feel comfortable with because, obviously, you've got to live with it. But the.

**Ellie Rofe | 51:01**
There are elements that are more B2B.
I think maybe it's just... So the stuff I did for the workshop was a pop-up brand I did because Natasha hadn't got a brand, and I didn't want to use mine. I did something that was really safe and boring, and I couldn't stand it.
But I think maybe that's just a case of me stepping back and saying what I love isn't the point here and finding something that I can still tolerate. That is not giving people the reaction of... What's that? Which... [Laughter] It appears. This design Has.

**Ray | 51:52**
I think that I really want the reaction I'd love to have them have. I want that at my deck.

**Ellie Rofe | 52:00**
Yeah, okay, yeah, I do, and I do like the idea of a deck. I have to think about mobile, but even then, it could work out.

**Ray | 52:06**
Because that's if they in thirty seconds look at this and are like, "Wow, that's nice." I want that... I want the promise that it is.
And it seems like whatever... I think you have an opportunity to do that in a way many other businesses do not.

**Ellie Rofe | 52:34**
But yeah, I do have an opportunity.
I'll have a look and think about how that would work. I really love the deck idea, and I'll work out how to tone down the design. [Laughter].

**Ray | 52:49**
The ray deck. All right, let me know how it can be most helpful that I think it's your you're in the hot seat this week.

**Ellie Rofe | 52:58**
Yesm okay, perfect.

**Ray | 52:59**
So if I had the group, give some thought to how we can be putting that to maximum work for you.
If there are things that come up, ideas you have along the way that we can help with, just email me. You've done that before, and otherwise, we'll talk again next week.

**Ellie Rofe | 53:15**
Thanks Ray. Take care, have a weekend.

**Ray | 53:17**
Take form, take.

**Ellie Rofe | 53:18**
Yeah, same to you.

