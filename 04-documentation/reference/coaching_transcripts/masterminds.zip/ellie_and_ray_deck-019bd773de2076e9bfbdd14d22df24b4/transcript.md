# Ellie and Ray Deck - Jan, 19

# Transcript
**Ellie Rofe | 00:04**
Hello, I'm so sorry, I have no idea what happened there, I tried to bury the things.

**ray@statechange.ai | 00:05**
Hey, Action. I got a note saying you joined the meeting, and I dug into it. I think you joined the same meeting as this morning or from earlier today.

**Ellie Rofe | 00:22**
I just used the Krisp join and record to join, so Krisp must have had a little moment.

**ray@statechange.ai | 00:30**
Well, I. You know, I I'm. I'm. I'm glad we're connecting now. And, yeah, it all works.

**Ellie Rofe | 00:33**
Yes, fabulous. Okay. So, do you just want a little preview of how I got on?

**ray@statechange.ai | 00:41**
Yeah, sure. How do you get on? How to be a service?

**Ellie Rofe | 00:45**
I think you were okay. So, I did end up ignoring the type form and stuff because type form is paid upfront, and I'm trying not to have loads of subscriptions at the moment. Jot form didn't really embed very well.
By the time I started digging through the documentation, I thought, "So I'll try and get it to just do one."

**ray@statechange.ai | 01:08**
Yep. Here. That's the mission.

**Ellie Rofe | 01:09**
Then I tried two different things. Initially, I tried adjusting an existing project, then I tried creating a brand new project. Neither of those is really good.
Then I realized I just need to add it onto the website because that project is pretty robust. So, it's flowing quite nicely, and all the formatting and stuff are there. The PDF is a bit tricky, but I think I'm getting there.
That's the one piece that has been harder.

**ray@statechange.ai | 01:46**
Do you mean for your output or the input?

**Ellie Rofe | 01:48**
Output.
Yeah, but I'm getting there. I've got it formatted properly now. I've got it to put everything into the HTML because it's easier to design HTML than it is PDF.

**ray@statechange.ai | 02:01**
Yeah, that's how a friend of mine does his PDF reports. He puts it into a web page and then has whatever the service is using take that web page and print basically printted. PD F.

**Ellie Rofe | 02:12**
Yes. So I got Puppeteer taking that and turning it into a PDF. I just need to finalize that bit because at the moment it's still sending the HTML in the email body, but we'll go that.
So, yeah, I think... Let me share quickly.

**ray@statechange.ai | 02:29**
So...

**Ellie Rofe | 02:31**
I'll show you how it's going. So this was an actual report for a tech where I uploaded their original one, and it's saying this is what your investment case is based on the slides in this deck, and then gives a summary.
That's quite a long summary on that one. So I'm going to test that. Then it says what things support that investment case and where the risks and weaknesses are. Then the full strategy analysis shows details of all these things.

**ray@statechange.ai | 03:13**
Wow. Here is some stuff going on here.

**Ellie Rofe | 03:19**
Yep. It's actually coming up with pretty good stuff. Considering I haven't done a huge amount of tweaking on the thing, I do need to do a little bit like GTM is not quite the same for biotech, so... Fine.
But yeah, it's pretty accurate. It's coming up with pretty decent stuff so far. Then some key investor questions. So, like, what are the critical ones, what are the highly important ones, etc.?
That's that. It's capturing emails. So what I haven't done yet is set it up with resend, but what I haven't done yet is take the email and put it into a marketing piece or add any marketing funnel bit there.
But I think for a first blast, this is pretty okay. And I'm going to ask people if they want to help me test it.

**ray@statechange.ai | 04:22**
That's fantastic. What's the input look like?

**Ellie Rofe | 04:26**
It looks like that. So this obvious needs to be cleared.

**ray@statechange.ai | 04:34**
You're currently pitching as a PDF. Great.

**Ellie Rofe | 04:39**
Yeah, and then once you click that, there's a processing...

**ray@statechange.ai | 04:42**
Okay, yeah, if I might throw one more thought in here.

**Ellie Rofe | 04:46**
I...

**ray@statechange.ai | 04:52**
The stage and status are things. These as dropdowns make categorization for you easier, but they can make it harder for your clients.

**Ellie Rofe | 05:08**
Okay.

**ray@statechange.ai | 05:10**
So the thing I pay attention to, right, is whether they like those dropdowns or whether you might even consider replacing both of those with just an opportunity for a paragraph.

**Ellie Rofe | 05:15**
He...

**ray@statechange.ai | 05:23**
Tell me a little bit about your fundraising, where you are today, because the AI will be able to take that and turn that into categorization for you.
People can say, "Well, is it CD or is it Series A?" And now and then that becomes a blocker.

**Ellie Rofe | 05:41**
M.

**ray@statechange.ai | 05:43**
The I was sort of wondering about this, like whether people sort of see themselves being in the in between state.
Like in particular people who are not sure who actually make for the best clients that regard because they are that x factor is exactly where you want to be as opposed to being just the design vers employer.

**Ellie Rofe | 06:02**
Yeah, okay, interesting.

**ray@statechange.ai | 06:05**
So I'm curious, you know, and you do you have telemetry on, like, how many people open this versus how many people, versus the number who actually complete it?

**Ellie Rofe | 06:16**
No. So that's the other thing I need to add. And I've realized I need to add that to my, site in general because I haven't got any analytics going on site.
So that was a project I wanted to do. A project task I wanted to do.

**ray@statechange.ai | 06:27**
Sure. Fair enough. Is there something you like for analytics?

**Ellie Rofe | 06:35**
Well, what did I ask AI the other day, and it came up with some ideas of just open-source stuff rather than a ton of Google Analytics GA stuff.

**ray@statechange.ai | 06:44**
Sure.

**Ellie Rofe | 06:47**
But I can't remember. Is there anything particular that you would suggest?

**ray@statechange.ai | 06:51**
Well, the one I use I like is called Fathom they chart.

**Ellie Rofe | 06:54**
Yes.

**ray@statechange.ai | 06:55**
We're appreciate what you're saying about stacking subscriptions, but it is a it's relatively inexpensive. It doesn't go farming out this stuff for a bunch of other things.
And it makes you the customer because you're actually chargeing for. Right. And then. And they have a very simple little tag. You can drop in or another AI can drop in for the purpose of, like, putting in more of these types of events.

**Ellie Rofe | 07:23**
Okay, I feel like I tested this ages ago, and it was pretty good, but I just wasn't in the right stage to use it.

**ray@statechange.ai | 07:33**
Yeah, sure. The extent, the ease of the extent, the fact that it's one extensible, and 2, that's easy to extend because of the tech. Of course, you just have AI do it for you.
But to your point, if it gets rid of the complexity of the Google Analytics J4 stuff and whatever else...

**Ellie Rofe | 07:52**
Yeah, which scrementtal?

**ray@statechange.ai | 07:55**
I tend to think so. I appreciate that there are people, there are serious professionals who divide their time between complaining about it and thanking the Almighty for it because that's keeping them in business.

**Ellie Rofe | 08:05**
Yeah, perfect.

**ray@statechange.ai | 08:07**
But like, they. I like it. Anyway, did just by way of, you know, it becomes another way for you to sort of not have it be your problem of like, wait, now I've got to have a dashboard. Now I got to figure out a place to store the data, and they just sort of take care of the stuff.

**Ellie Rofe | 08:23**
Okay, nice. So yeah, we'll add some analytics to this and see what people are clicking on.

**ray@statechange.ai | 08:26**
But the and then I'll assess my deck.

**Ellie Rofe | 08:30**
That's nice where they get...

**ray@statechange.ai | 08:33**
And. And do you. Do you have a demo of the pitch assessment? Because actually, the what. What you're showing here looks kind of compelling, but I appreciate it's based on an actual client.

**Ellie Rofe | 08:40**
M no, this one isn't.

**ray@statechange.ai | 08:43**
Right?

**Ellie Rofe | 08:45**
So this is a demo of Flux Dynamics, yeah, exactly.

**ray@statechange.ai | 08:48**
Okay, got it. So now so you can have a, you know, sample of the report and then, you know, the. Called action, which is to assess mine.

**Ellie Rofe | 09:00**
In a future version, I just put something here to break it up, which I don't want to use finally, but it was just there in a future version. There is a possibility that while it's developing the other things, it goes off and does an image as you've suggested, like an image summary of what your deck is.

**ray@statechange.ai | 09:21**
The TL;DR of it, if you will.

**Ellie Rofe | 09:23**
Yeah, exactly.

**ray@statechange.ai | 09:23**
Yes, this is gorgeous.

**Ellie Rofe | 09:24**
Yeah.

**ray@statechange.ai | 09:29**
I mean, just well done today.

**Ellie Rofe | 09:31**
Thank you.

**ray@statechange.ai | 09:33**
I would love to just see it, I guess. Well, let me ask you this. What is the distance between you and being able to click the... Whatever your push is. If you use a tub to push it up or whatever?
So that's actually part of the Nicelyput site.

**Ellie Rofe | 09:51**
I think he's pretty much ready to go. I can tighten tweak forever in a day but I think for the moment, I might just whack a little beta thing on it.

**ray@statechange.ai | 09:56**
No.

**Ellie Rofe | 10:03**
Eventually, I think this probably needs to be a page with some sales language around it for it to be a lead magnet.
This to be a form within that embedded in that page but so people know what they're getting from it because obviously this is just trust me, bro but I think that's basically it.
In that itself, I could probably get based on what we're outputting, I could probably get it to start taking some screenshots and basically create that page for me this evening.

**ray@statechange.ai | 10:38**
Yeah, I think that seems possible. I wouldn't hold off on putting up this before that. I mean, this is good and I would love to have it. I would love to have it. That is a thing like this ends with you being able to ship and have victory and then get the enjoyment of your evening and then hopefully that is inspiring to do the next thing.

**Ellie Rofe | 10:59**
Yes. Well, it's a fast day, so sometimes in the evenings on a fast day, I do end up just tinkering on a laptop because I'm slightly zoned out but focused, if that makes any sense.

**ray@statechange.ai | 11:10**
Yeah, I hear that.

**Ellie Rofe | 11:11**
Yeah. Nights look very different when you're not eating.

**ray@statechange.ai | 11:16**
Yeah. That. Yeah, well, you know, congratulations.

**Ellie Rofe | 11:19**
Yeah, yes, yeah, okay, I will do absolutely.

**ray@statechange.ai | 11:21**
This was wonderful. I can't wait to see it on the nice put Ducco site. Miss AOR, just, like, let me know when I can go check it out.
And co. Is there anything else I can do for you tonight? This is. This is awesome.

**Ellie Rofe | 11:39**
No, I think this is great. As I say, sometimes the deployments can be a bit glitchy, but the AI normally works its way through them.
So I'm just... It's all pretty Git and... Versatal and Super Base are all pretty much well set up, I think now, so it should be smooth running to get it out there.

**ray@statechange.ai | 11:59**
Super. All right, well, I'll look forward to your note about that. You have yourself a wonderful evening. And if I can be a further service to you. You know, in the week. Don't hesitate to buzz and ear that I'll.
I'll see you tomorrow.

**Ellie Rofe | 12:15**
No, this is brilliant. Thank you, Ray. A perfect forcing function for me to push through. Yeah, bye.

