# Ellie and Ray Zoom - Oct, 31

# Transcript
**Ray | 00:03**
Kelly, how do you do today?

**Ellie Rofe | 00:04**
Hello? I'm very well, thank you. And you?

**Ray | 00:11**
Recording in progress. There you go. All right, so, I read through your report, but like, sort of how are you feeling about your week?

**Ellie Rofe | 00:23**
Good, are you okay? You look a little bit tired. [Laughter].

**Ray | 00:28**
That's. Yeah, that does sound a little bit like me this week.
I've got... You know, there was a point early in the pandemic when this was when I started my early morning cycle, and I referred to it as waking up in horror. I could wake up with a start in terms of concern about the world, my children, what have you.
Of course, the pandemic gave a lot more immediate stuff for that, and I occasionally run through that through combinations of whatever might be a local stress or the world being in a more precarious place. Certainly, the world is in a more precarious place.
But probably the slight bit of explanation for it all is that I have an uncle who has just moved himself into hospice.

**Ellie Rofe | 01:15**
Yeah. That really?

**Ray | 01:16**
So I've littleled out that doesn't need to be a big subject of conversation, but it is definitely something that is affecting...
And probably a little bit the... By my waking up in horror phenomenon for the Digger week.

**Ellie Rofe | 01:31**
Yes, waking up like there's a hand just clutching your heart, and you go, "What is happening?" [Laughter] in horror?

**Ray | 01:38**
I guess it's time to wake up now.

**Ellie Rofe | 01:42**
Yeah.

**Ray | 01:43**
Yeah, well, and then you get past all that a little bit, but that's the subconscious knocking on the door saying, "Hey, there's some stuff to take care of over here.

**Ellie Rofe | 01:52**
Well, I'm very sorry. I won't labor it because, obviously, it's banal, but it is what it is, so I won't labor it for you now, but, yeah, I'm.

**Ray | 02:02**
Yeah, and I appreciate you've got your family things, and we all have these things. All things happen in context. The secret to life is not to break, but to bend, so sure, bend it a little bit.

**Ellie Rofe | 02:22**
Yeah, fair enough. Okay. Well, if you ever need a break from calls and things, just say... Okay.

**Ray | 02:29**
I appreciate that.
I think I'm doing okay. I appreciate the offer. Yeah, I will take it seriously.

**Ellie Rofe | 02:36**
Good. Yeah, I'm feeling quite good about the week. I think I have... You mentioned about posting and the dopamine hit. I do have a sense of achievement that I've just done it.
I think the joy of just saying, "Don't worry about strategy for the moment. Just get the rhythm, the habit, the noise out of the way in your head and just do it." I dumped coaching transcripts into a Claude thing, a really mean Claude,
you know? More Claude every now and then gets really nasty's like, "Look, you moron." That's the basic tone it's taking with you. So I was like, "I will use that." So I just was like, "I'm going to post what I'm going to post on LinkedIn."
I've written more because I actually find that's often faster than trying to faff around with AI. But I just post it in there for a sanity check and say, "You're not here to try and buff this up because when AI tries to buff up a LinkedIn post, it turns into awfulness.

**Ray | 03:43**
No.

**Ellie Rofe | 03:43**
Just a sanity check that I'm not missing an opportunity with this or I'm not saying something really stupid, and then it will go, "This is stupid." Why does anyone care about this? Get rid of this and then ship it.
So that's been my little process, which is very simple and very stripped back.

**Ray | 04:02**
Great.

**Ellie Rofe | 04:04**
That is nice.

**Ray | 04:05**
I do find getting it to be cranky can be very helpful for just identifying challenges. My son's actually... I actually put up the date change afterwards. The state changed assistant has these different mentors that have different tools but biases in their prompts that guide people in the right direction.

**Ellie Rofe | 04:21**
He.

**Ray | 04:24**
But the one that I showed my sons the mechanism for making these right.

**Ellie Rofe | 04:28**
M.

**Ray | 04:29**
And wanted to make ones that were all sorts of emotional states, which I found to be really interesting. In fact, the angry mentor really does surface ideas because it wants to say that you're wrong.

**Ellie Rofe | 04:41**
Yeah.

**Ray | 04:43**
So I find getting the AI to be a little cranky. It pushes back more, and I find that to be a useful mode, not always the most supportive mode, but a very useful mode for it to be telling me something I didn't previously know and maybe taking the in direction I wasn't already going to go.

**Ellie Rofe | 05:00**
I find it prompts me to be more determined or quite contrarian anyway, but if it says something that I disagree with, I'm like, "No, that's stupid. Of course, I need to include that."
It's really important context. So you're like... and it shifts from "My God, is this the right thing to be posting?" I'm bloody posting this, but it's like ice.

**Ray | 05:28**
Yep. Well, yeah. And if it can inspire you to action, that's good and important. I was just talking to Demetris about that earlier today.

**Ellie Rofe | 05:40**
Yeah. No, it's been good. I've literally just had ten minutes ago got another sales call booked in for Monday, and I think that's.

**Ray | 05:51**
Wonderful.

**Ellie Rofe | 05:56**
I think that's possibly from LinkedIn, but from an article posting about her win at the best pitch in her thing and thanking me at the end of the post and stuff for my help.
So I think that's really nice as well.

**Ray | 06:14**
My goodness.

**Ellie Rofe | 06:15**
Yeah. It feels like there's some momentum. There are bits and pieces that... I haven't done quite enough on the Pitchdeck Analysis project, but I think next week I can do it or from tomorrow, basically, I can just be building that and posting about it.
I think the one thing I do struggle with is how to... There are certain things that are just quite complex, and I know LinkedIn isn't the place for them. Maybe I just eventually will be doing YouTube videos or articles on LinkedIn or something because there are certain things where it's like multiple steps, and there's no point in putting all of that information into a post.
So I'm trying to do what you were saying before. I'm trying to do it as instinctively as possible and just take a single idea, what if you could make a front cover for a pitch deck more effective, and then just give a quick example of that or whatever.
But then there are ideas that are rattling along that feel like more substantial pieces of content that require a bit more planning and need a different venue. So I think that's probably... Maybe just another week of posting every day on LinkedIn, these small insights and small snippets basically, and seeing whether I can make those as interesting as possible as well or whatever, and then start building out more. I guess the engagement level content that has a bit more to it.

**Ray | 07:53**
Right. I mean, there's a question like things that have more to it because they are more substantial ideas.
Then there are things that have more to it because it took you more time to do them, and the first of those is more valuable than the second. I think sometimes we can use those. So, the fact that you've got these ideas you're rattling around that you haven't found a way to do in a relatively short form is useful because those become domains.
Then you can be asking, "Well, what's the market telling you about what you've been saying so far that they actually seem to care about?" It's one of the great things I found about YouTube and the shorts.
I can look at relative responses, right? "Hey, this seems to be getting more engagement, more views, more whatever likes or whatever. People seem to connect with this idea or this topic and then be able to go down that more, which you can be doing because you think, "Hey, there's more double main hits on that.

**Ellie Rofe | 08:39**
Yeah.

**Ray | 08:45**
And can be good too, but I hear that the bit about the bigger stuff. It's not necessarily the case. You need to be doing that with more work. "Hey, if there's an idea here worth doing, what's the way that you could be getting that idea out in the market with lower cost?" There's the kind of prototyping that we would tell any client to do.
Right? Physician Hesel?

**Ellie Rofe | 09:09**
Yes. Yeah, exactly. It's things like I've been playing around with getting clawed to work with slides.

**Ray | 09:22**
Yes.

**Ellie Rofe | 09:24**
And it is really interesting to me anyway. Probably not to anyone else, but what would be interesting is if I can get it to actually churn out slides that are really good. So, I've set myself that challenge rather than being like, "These slides are crap from my haughty.

**Ray | 09:40**
No.

**Ellie Rofe | 09:40**
I'm, these are not good enough.
I suspect that will be a multi-step process, and sharing that with people. I can do a very brief rundown, obviously, but sharing that with people is probably a video or maybe a carousel or something.
But it's something that is just because of the nature of the fact that it will be somewhat like there are multiple steps in this, and there's a little bit of context to each step. It probably doesn't lend itself to a LinkedIn post, but it might be a linked article that is then summarized in a carousel and linked out to.

**Ray | 10:14**
I think yep, and or substack or whatever, right, they just sort of have these bigger ideas.

**Ellie Rofe | 10:19**
For example.

**Ray | 10:25**
You want to be communicating in the world. I think that's totally fine. What I like about video is it can take something that you're not quite sure how you're going to put into writing or shrink it down, and then you can do it in a much shorter period of time, right?

**Ellie Rofe | 10:34**
Yeah.

**Ray | 10:39**
I find myself with a piece of paper. I am perfectly capable of losing hours on it
if I am talking to the camera or to a human being like yourself, I'm expressing the same idea. About five or ten minutes?

**Ellie Rofe | 10:51**
And that is where I was thinking. It's one of the reasons I've been avoiding it. Every time I feel an idea start to balloon into that, I just go, "Bench that." That goes to the side.
I will find a different thing to talk about today to keep the rhythm up, because otherwise this becomes a time suck. And probably a demoralizing one. When I spend three hours doing it, I don't get it finished and then have them posted.
So I'm just trying to recognize my weaknesses, and as I'm recognizing them, finding ways to shore them up in incremental ways rather than trying to attack it all head-on and as I often do, end up behind again or just going, "Who needs to market anyway?"
But yes, one week of.

**Ray | 11:42**
Okay.

**Ellie Rofe | 11:42**
[Laughter] I've got two sales calls booked in. Hopefully, they'll turn up better, but I'm aware they might not, so that's the nature of things. I did wonder, do you think it's too...? I was going to connect with them on LinkedIn if they haven't already and just say, "I'm really looking forward to speaking tomorrow or whatever the night before." Just to send a little mental prompt, though.
It's not like her. I booked that last week, and I've forgotten about it.

**Ray | 12:17**
Right. Sending them a DM of, "I'm looking forward," meaning tomorrow. Here's the link.

**Ellie Rofe | 12:23**
Yeah, just something personal, like I've looked through the deck. I'm really excited to talk to you about your work. That kind of engaging with them a bit beforehand so it feels human rather than just having gone through Callendly.

**Ray | 12:38**
Yes, I think all that seems fine, right? It's an opportunity for a little bit of a personal note. I think the fact that you send anything at all is going to be distinctive.

**Ellie Rofe | 12:48**
Okay, cool. But yeah, it's gone well there. It's gone less well with a pillar tech, and I'm waiting to see whether anything comes back.

**Ray | 12:59**
Yeah, well, you said you have two topics, so which one do you want to tackle first?

**Ellie Rofe | 13:00**
That was.

**Ray | 13:03**
You you want to tackle that one first?

**Ellie Rofe | 13:05**
Yeah, let's talk about that one quickly. So, I sent the deck, and AJ confirmed that he wanted to book in a call. We booked a call for Wednesday. I got on the call, and his body language was off, his whole tone and demeanor were off, and I was great, so we'll just work through it. I had some questions. I'm sure you've got some questions. I'd love to hear your thoughts.
He was like, "Yeah, I just think there's some good stuff there, but I just think that I need to rework some stuff. Can you send me the slides?" I was like, "Okay, fine.

**Ray | 13:46**
He.

**Ellie Rofe | 13:48**
And said, "Is there anything particular that isn't sitting right?"
He was going, "No, that's good." I was like, "You're working through the slides going, 'Yeah, that's...'" I said, "But I've been working on the 20,000 genome sequence, and it's like this."
There's all this other technical stuff that we need to put in here so that people understand what it is. Now, he's either... He was basically just like, "Just send me the slides." Fine, except if that's the way he's closing off the engagement, then that's highly obnoxious.
Because he's meant to be recompensing me, and he has not even if we're not doing finances. I put in huge amounts of work. Anyway, I took all the emotional response I had, dumped it into Claude and ChatGPT, and I was trying to work out whether I'd overstepped and upset him because I've done lots of strategic thinking and put stuff into his deck that he hasn't thought about clearly. Despite me trying to tease stuff out, I wonder whether there is a sense of him feeling a bit out of control. The deck is basically pushing him to make declarations that he hasn't, that he doesn't think about and doesn't want to think about in his business.
What is its IP protection strategy? What is the funding process? What is his development strategy for the lead program and the platform that he's now decided is the central thing? I wonder whether he just wanted to talk arily about his vision and some science and hope that people would fund him. I wonder if he'd even looked at it, because the way he was talking through it sounded like he might have been seeing it for the first time. It felt like when I was in supervisions and I hadn't read the novel or the poetry that I was meant to have read.
That's okay. Yeah, really love the words and the clever.

**Ray | 15:56**
Words, yeah.

**Ellie Rofe | 16:04**
So my key question and the thing I was thinking about was I sent him the deck with some documentation saying that because I'd said to him on the call, I totally get there's lows and lows. More to the 20000 genome story.
Stacking upfront and making it too technically. We've added in so much commercial stuff into the deck and so much context around the lead program and the market for it and how you're going to beat the competition, et cetera. I think I would just caution against putting too much technical stuff in there.
Then I reiterated that and added and explained all the things that we have added into this deck that weren't in there before, and the things that he still needed to review and confirm as an internal strategy thing that he clearly hasn't gotten to me yet.
I did that because I thought if he does completely ghost me and then shows an absolute pile of crap to Max where he's taken it back, taken out all the detail, taken out all the not detail, but the actual. Here's how we bring this to market. Stuff.
I have documentation to say to Max. That's not what I delivered. That's not what I was trying to do because I think the next question he's meant to be speaking with Max on Monday. The next question is if
he is just completely divorced from this because whatever he feels threatened is an ego thing. Fine. I know he's under stress, and I know he hasn't done any of this thinking, but how do I then make the most out of that engagement anyway? How do I make sure that I get some sort of
lift with Max in terms of what I can do? How do I obviously then look at... I've already been thinking about no free engagements again, obviously, learnings from that. I'm thinking, potentially the woman that had asked me for some examples of design work and things like that, she had seen the Apellate tech pitch because she's an investor and she, as well as a consultant, had seen it. She said, "If you can do anything with them, I'll be..."
That's an incredible thing because it's a mess. So I thought I might just send it to her as an example of design. I'm going back to the UK to see if she wants to meet up and then just talk to her and get her view on this kind of thing and working with these founders in science and blah, and just trying to use it as a potential to have her as a... To see if she is willing to be a somewhat mentor type figure on the scientific consulting side.
I did ask AJ if I could use slides in marketing, and he said, "Yeah, that's fine." So.

**Ray | 19:06**
Okay, well, take that. Just for that, it might be incredibly stupid on his part, but whatever he can take it.

**Ellie Rofe | 19:12**
[Laughter] Yeah. Yeah. Absolutely.

**Ray | 19:16**
Is this the company that had, like, two businesses where they're talking about, like, doing a spin offff or whatever?
Yeah, the it's a tricky thing. It does not totally if he's under a lot of pressure that he would take it out on a vendor. Second, it is a bad habit, but these particular, but male senior particularly going to take it out on women, which sucks.
But I think there's a lot of context that explains more of this situation. But that said, I don't think you're really in the deck making business, right? You're in the CEO advisory business.

**Ellie Rofe | 20:12**
M.

**Ray | 20:13**
So the trick here, right, is when you go to talk to this person, Max or whoever else. Sure you delivered something, but the ultimate mission failed, which was being able to advise.

**Ellie Rofe | 20:26**
Yeah.

**Ray | 20:33**
Now, you're never going to persuade someone, and this is one reason we look for wins, right? You're not. Persuade someone to do something. They're not they don't want to do so really a good part of this game and they want to do the dishes right? Want to be looking at the businesses more business, et cetera. The founder who is not inclined to do that.
You know, what they really need is not a consultant to make a ratcheck. What they need is a partner who's going to be the, you know, competent marketer of the business.

**Ellie Rofe | 21:00**
MY exactly.

**Ray | 21:02**
And not a service you can provide.
I mean, that's not a service any vendor can provide. So I think you talking to them about the experience of working with them is one thing, but you can talk about some slides that you made. But I would not put myself in a position of saying, "Hey, I delivered good slides to him, and he just ignored them."
Because that's actually the whole point, is that he just ignored them. He's probably not bereft of other good advice or good slides. He's just again, ignoring it. The big value would be if he were not ignoring it. Now, I don't exactly know what's going on in the context of particular psychology or the relationship, what have you.
I'm glad to get more into the detail of it, but I think that job of that advisory job is the real job. Even if it's being packaged as doing slits.

**Ellie Rofe | 21:56**
M.

**Ray | 21:58**
And what he does say, "I don't even want to think about this anymore, and I just want to take back control of it on theory."
I've felt this before. I felt this myself before. The theory of wait. Having a vendor here is actually causing me more stress because it means I have to be thinking about this stuff that I'm not thinking about. If I just take it myself, I won't need to deal with the vendor.
Then you just don't do it.

**Ellie Rofe | 22:19**
Yeah, M.

**Ray | 22:21**
Seems seems like a likely outcome to the story. Which, again, is not fantastic. It's not strictly your fault, but it's not a successful end to the engagement, so there's no... Hey, this was successful and he screwed it up. It was
because the real mission is about the turn. Anyways, I bring that up because when you go to talk to those people who are supposed to have a framing of certainly how they're likely to be seeing it in their heads.
If they like you, they're going to want to be sympathetic to you. But I don't think you need to give excuses on the lines of, "Hey, but he had good slides and I gave him an A to do list." What have you stayed? You serve what? A certain way.
And give time, maybe he comes back around.

**Ellie Rofe | 23:06**
Yeah. I think this is where it isn't. It isn't so much the slides. It's that the slides that he shows them don't include the strategy work. And so that's my problem with it. If that's the case, then all that work that I've done gets hidden unless I add it.
That's what I was thinking, saying to Max. I was thinking about contextualizing by saying to Max, obviously, we started this in July and it was meant to be a quick process. As you know, we had to work through some strategy changes because he took the strategy changes to the board, and I suspect he took them as his own idea.
I've been thinking. But I think if I just say, "We had to work through some strategy changes." They were telling two different stories, two different drug development programs, which were completely unaligned, et cetera.
To say it's been a really interesting process. I'm not sure where it stands now, but I don't want to just go in there like I'm trying to tell them, but I don't want to just have done all that work and then Max go, "She's done a load of shit."
There's no strategy in this. So it's. I guess that's the thing, I want you. I don't know whether I just give Max a call this afternoon because he's very approachable. He's very smart.
I think he knows some of this about AJI think he's felt that this was possibly not a great investment on his behalf and that this is a struggle. So I don't know whether I just pick up the phone and say, "Hi, Max, just to know, just let you know that it's been a long time." Obviously, the process with J working through with the pillar TE, it's taken time, but it's coming to an end, and I just wondered if you're around when I'm back in the UK next week for a catch-up or not next week. The week after next.

**Ray | 25:04**
Yeah, well, right, I mean, like, if you say it's July, then that that's 90 days in, right? Hey, it's been 90 days. You know, did. You know, in an intermediate. Would love to get. Would love to get your advice.

**Ellie Rofe | 25:17**
Yeah, okay, one.

**Ray | 25:21**
Invite becomes the mechanism by which you can be sharing what you think about it.
But you're not delivering news, you're asking for counsel. Now, that so you get to sneak in your thoughts about this, but you're focusing on theirs, which probably gives you a better lesson and there's possibility of.

**Ellie Rofe | 25:38**
Yeah.

**Ray | 25:40**
Well, okay. I mean, I guess I need to go look into this more or whatever. The thing about investors and investments is not going well is they tend to be pretty brutal and just stop working on those investments because their time is too valuable.

**Ellie Rofe | 25:53**
I think Max is, as his colleague, the other consultant I spoke to, she said he's way too soft, but I think he's reached his limit with it, so, yes, okay, I will contact him.
I think that's the best next step. I'm not too worried about the psychology. I've thought about the psychology of what's going on. I've tried to think of it from a few angles, and I've given Aja a few days to just go away and do what he was going to do with the deck.
If he wanted to come back and collaborate again, then we could discuss it, but with very specific limits at this point. Any further work would have to be paid for, but the point is...
If he didn't... I can't control that. I just wanted to work out what things I can control and how I can maximize any value from it. Basically, after the fact, apart from my own personal learnings and things.

**Ray | 26:51**
Well, one, you now have access to the IP, right? He gave you, I think, stupid, but he gave you the okay on it. Use it, especially if you're proud of the work, which I think you are, then go pull that up. That's the real outcome. The second real outcome is checking in with the investor because it gives you an opportunity to talk to the investor.
This is the classic thing, and when you're looking for money, ask for advice. You take this approach, and that becomes the way you move that forward. Then, with this gentleman in particular, what'll happen will happen, of course. He's bringing his presenting ideas as if they're his own. They know that you were there.
Anyone who's inclined to give that guy credit for his strategic insight when they know that you were involved somewhere in the process is probably looking to not give you credit for the strategic insight no matter what.
So, I wouldn't worry about it terribly. You did good work. You go talk to the person who's actually going to be helping you get the next piece of work. If there's anything to that at all, you are nothing but friendly and gracious.

**Ellie Rofe | 27:56**
Yeah, yes, absolutely.

**Ray | 28:03**
You know, to this to the CEO routing forum, and then you just move on to your next engagement. It's tempting to want to do more explanations or whatever. This is what morning pages are for.

**Ellie Rofe | 28:20**
[Laughter] That's a very good point. Yes, okay, that's a really nice point. I will do some morning pages.

**Ray | 28:32**
But, yeah, I do find that putting up the more... Have I told you that I went through a whole conversation with Claude about. Well, I was writing a note to my friend Berksh over Azon about, "Hey, I think with the danger you're in.

**Ellie Rofe | 28:48**
[Laughter] Yeah.

**Ray | 28:48**
Yeah, okay, and then Claude told me, "Just don't send it, that's not a good idea." That was cranky Claude, right? Instead of, "You're absolutely right. How about we think about this a different way?" But I do find that internal counsel... Of course, all it's doing is holding up a mirror, telling me what I would tell myself and.

**Ellie Rofe | 29:08**
Yeah.

**Ray | 29:10**
And I would have given myself the chance to tell you better advice, you know. It comes across. It's pretty good.

**Ellie Rofe | 29:17**
It's is really important, and I think the nub of it is positioning myself in the right way. I delivered some slides, but I delivered strategy, I delivered some consulting.
Funny enough, I had a call with the guy who is creating the ammunition factory in Coventry and had asked me about a website, and I'd sent him a figure which I suspected to be way above what he was thinking because he used to... I wanted it just to be done. I said to him, "I think because I did a couple of graphics for the SDP, you've it's positioned me in your head as someone who does a bit of graphics."
But I'm a strategist. So, this is... There is no point in getting me to do just a bit of tidying work on your Squarespace website. There are other people who'll be much better for you at that. He will just make it look a bit prettier, which is what you want at the moment. I did suspect that this... I couldn't do a ridiculously cheap job on this for you because there's a limit to how cheap I can go.
I think there are other people out there for you. And he immediately said, "Interesting. I did wonder, tell me more about this strategist thing. What do you do?" I said, "He said, I think that's something I need to learn more about."
I said, "Pitch takes, blah." He said, "We need to be raising $250 million in the next few months." I have this process I work through in terms of the idea, the schema, the detail, and the application. As we get to the detail, we're in the detail at the moment, but as we get to the schema, I need to go out and raise
$250 million. I think that's when I need to be coming and talking to you. So, yeah, it was really nice. I was like, "Yes." Repositioned. Nice, so that works really well.

**Ray | 31:17**
Fourmmm.

**Ellie Rofe | 31:20**
What was the other thing I wanted to talk to you about? My brain's gone.
Papa. Yes, the workshop challenge idea. I think I worked out one of my concerns. So, this I think is really interesting. The last time this woman did a workshop, she said because I was saying to us, what sort of numbers are we expecting? Not... I want 50 people on this workshop.
Just an intrigue. I was quite surprised. Hoping to get 5 people the first time I did a workshop and I got 20. I think if we position this right, we could get that or more, but she was saying she works very much in the... She helps families identify the right investors, the right fit investors, so they're not just spraying and praying that they're actually trying to find ways to connect properly with investors who are more likely to be interested in what they're doing.

**Ray | 32:27**
He.

**Ellie Rofe | 32:27**
Find better ways to make approaches, even build those approaches.
I mean, this is a very sort of common theme at the moment you start raising before you need to raise, et cetera. Start talking to people, make connections. Don't just suddenly turn up and go, "Please, give me money."
She does lots of mindset work with them. She's far more of a coach than a consultant, and she'll probably split the difference.

**Ray | 32:49**
Three.

**Ellie Rofe | 32:51**
I know, but that's sort of how she frames her work a lot. And she does work on messaging, and she does help them get clarity, but in terms of the actual storytelling, she's she doesn't know it and can't do it.
And how to structure it and how to underline. And she doesn't do the same granular stuff I do about investment readiness. And this like, where's the defensibility, where's the, you know, what does the actual funding roadmap look like? What are the milestones, et cetera?
So, she suggested a workshop or a challenge or whatever we happened to call it. With potentially a joint offer after that. I think maybe there's as much value in people being able to go to us individually as well. She mentioned a community that we could funnel people into.
And I think that's when I started going. Okay, I'd already said we need an agreement between us because obviously, you know, this is how things are apportioned. And who's doing what. And that kind of thing is important for us to clarify in advance.
But, when she said community, I was like, I don't know that I want to be locked into, like, permanent community with women after one event in the nicest way possible. I don't know her very well, but I think maybe it's just a pop up community where it's like from this at the beginning of December until the holidays, we will, you know, we will be available in this Slack channel or whatever it might be, and then it closes.
And if we decide that actually it's you know, this is quite a nice thing. And we're quite happy to do it in the month that we're doing it. Then fine. We can think of a way to parlay that into something that we keep open or whatever.
But to me, it's like putting a lid on it. I think it's quite nice as a selling point. You don't want to be in another endless community, but this is a really focused one that, the sell of the thing is prepared to raise in 2026.
So by the time we hit Christmas, you are there with your plan in place and you know what you need to do in terms of your strategy and you know what you need to do in terms of investor outreach and starting to build with them.
If you really want help with that, then you can come and hire us one way or another. I can ramble any more. What are your overall thoughts on the idea? Are there any red flags or whatever?

**Ray | 35:33**
Sure. When people say community, I think what they usually mean is a forum, right? In an open space in which people can have conversations on the topic at hand.

**Ellie Rofe | 35:41**
Yes.

**Ray | 35:48**
And are a number of different technologies you can use for a forum.
I use Circle because it's more persistent. Slack and Discord are both good for ephemeral chats. You can do something as simple as a Telegram or WhatsApp community, which is more popular in Europe, which is nice and simple, just a list of people, and they write messages, and everybody else gets them, and there's no real threading to it.
But that's not that big a deal. Now, what I found about forums is that they tend to be, particularly at a small level, Q&A. People have a question, and then they're hoping there's going to be an answer from the expert.
The reason people say on the forum is to be able to ask questions, but just be able to see more answers coming from you.

**Ellie Rofe | 36:30**
Y.

**Ray | 36:32**
The reason you would want to do it is so you can hear more questions.
So you can better promote yourself by being able to hand out those answers. I would say you probably want to have the rule of the forum that there's the anti-Las Vegas rule, right?

**Ellie Rofe | 36:48**
[Laughter].

**Ray | 36:51**
You know that which happens on the forum.
Yeah, sure, you can talk about it anywhere. At the very least, take your own counsel that you give and plan that's going to become stuff you could do on the outside. That to me is the big value of the forum, right? That you get questions that prompt you to say something smart. That you can then cash and save for somewhere.
I mean, you and I have probably both got the same piece of advice, which is to go over all the stuff that you've written in the course of the last year and copy it into a document.
Then all of a sudden, man, you have all these prompts and all the stuff that was good that you now can say. How can I contribute that? So it's people like you and I who use the written word a lot. That can be a very handy way to do it.
This becomes a way to prompt those right, and that is actually the reason I do forum-based marketing because it's easy. You have a question? Can you give an answer? You're maybe looking smarter as you do it. My take is starting a new forum is far lower value than attaching someone else's because you know you can be providing the same kind of expertise to... The value I was describing is not about owning the forum. The value is about being able to interact with people.

**Ellie Rofe | 38:01**
Yp?

**Ray | 38:01**
So here, the value is through the interaction. Now, the way that you create more value for them that's specific to this group is, in my experience, not the forum, it's events. I've seen small communities of Slacks, whatever state change FAS category two.
Sure, there's a forum, but the primary value is delivered through the events. So for me, the big value of the forum would be to say that you're going to have this workshop and then you're going to have, I don't know, two office hours that happen afterwards, and the office hours are just open.

**Ellie Rofe | 38:34**
Yeah.

**Ray | 38:38**
People ask questions, you don't go over. We're just going to do it for the hour, right?
It's just a mail bag stuff, it's super easy for you, right?

**Ellie Rofe | 38:46**
Yeah.

**Ray | 38:48**
Doesn't doesn't require a whole lot of preparation. Allows you to be immediately helpful to those folks. And then the purpose of the thing in the middle is basically for scheduling as well as people asking follow-up questions or leading questions.
You can even someone can ask questions like that. That's a great question. We should bring that to the office hours, right? Keeps you from feeling trapped by that. Because again, in the same spirit of that, would you stare at a piece of paper like, "How am I going to write this in?" Stupid WhatsApp app becomes super easy if you just press in for five minutes.
By the way, that five-minute monologue you're about to give becomes remarkable material you can go use elsewhere. You should not be shy about that. I would say that one of the big things you want to have this community is access to your own words and voice.
Because you talk about like, you need to make some video, what have you, like this is how you play on-site for video and for them, it's like, "Well, you're giving us more hours. You are really getting more opportunity to create content that you can be putting elsewhere."
So we're getting the plan easy as you do it.

**Ellie Rofe | 39:53**
Love it. Love that framing. Okay, that's nice. So that makes sense that clears that up. Does it seem like AI means to me, I just thought it's fairly low risk.
It's like as long as I derisk things like not getting tied into a lifelong business with a woman I've spoken to twice. But it seems fairly low risk to just try it and see how it works.

**Ray | 40:14**
No, you do it, you do an event like you say you do. I've talked to her about it. "Okay, what's well, we do a community. I think your community is we're going to have a month-long follow-up, which is going to be these two additional office-type things or whatever, but all of which gets you more benefit for low cost."
By the way, if you're the person coming in with a plan, it does sound like you'd be the person who'd be able to get what you want from it. You limit your exposure, which seems pretty important.
So it becomes can't lose, right? Three people show up, and probably all three people show up to the office hours, too, right?

**Ellie Rofe | 40:57**
Yeah.

**Ray | 40:57**
And you're putting this into your video or whatever, you don't need to show the fact that there are only three people on.
It's going to be all about you anyway.
So the opportunity for you to be on camera is where I think the real value is. When Demetrius was doing his thing last week with Betch, I thought about that.

**Ellie Rofe | 41:16**
Yeah.

**Ray | 41:18**
That is great. He was there with Mitch, but he got to do two things I thought were really useful. The first is he got to talk smart about his subject when you're talking about the Claude and the MCB and whatever.
Then he was the. The facilitator for Mitch. I don't think he appreciated sufficiently how useful it is to look like... and be a gracious host.

**Ellie Rofe | 41:44**
He is very naturally so gracious as well.

**Ray | 41:45**
So, like.

**Ellie Rofe | 41:48**
And I was really pleased that you didn't see the prior call on the prior call. He very much took... He wasn't hosting Mitch so much as playing second fiddle to him, and Mitch, obviously, is very confident, and he has that TED-like extemporaneous talk thing.

**Ray | 42:08**
Performer. Yes.

**Ellie Rofe | 42:10**
Yeah, and I loved that this one. I don't know if Demetris did it deliberately with this in mind, but I suspect he did. Where he actually showed the thing. He went through something and demonstrated it because it's tangible.
I think that's what was missing from the first call anyway. Demetris owned that. I know that it seems like Mitch owned the thinking, but actually, I think Demetris owned the value in terms of creating AI, so it was really strong for him.

**Ray | 42:39**
I think they both profited from it, and I think that they profited more because the other was there.

**Ellie Rofe | 42:40**
Yeah, yes, absolutely.

**Ray | 42:46**
So I look at it... So, Robert got his thing that has actually gotten some pretty good traction.
It's been up and down. I've been providing a little bit of guidance to where it seems like he's getting more bites because I think he's too busy performing and not enough seeing what the reactions are right.
So, I think that that's what I'm able to help with. But the one he did last time was just in jaws were on the floor for the whole time because he was doing what Demetris does in terms of describing it just showing value. What he doesn't get is the hosting and graciousness part because it just doesn't have the opportunity to have a co-host but a guest.
It has been really quite effective. Anyway, I was thinking about that in terms of how we can take this lesson that we've learned from Robber's working very well for his practice. Demetrius seems to be emerging birth practice. How can we apply it to yours as well?
It seems like you've got a way to get started here, and nothing says it needs to be working with anyone else. Nothing says you need to work with this person for much longer. What I would do is...
I think the big value is being able to cut it into content. I appreciate that we had a conversation a while ago talking about Opus. Now, Opus was a little too rough, but that really works.
I gotta tell you, the engagement I get from the Opus clip stuff that I do with Yousine from the pod that we did back in September, and that will start again sometime next month, is remarkable because it seems to cut down to give the minute version of...
Okay, here's a useful idea.

**Ellie Rofe | 44:21**
Yeah, I think the problem was, and I think we thrashed this out. The problem was it was the first call, and I was just waffling about stuff. So, Opus was trying to catch value, but it just wasn't really managing it.

**Ray | 44:33**
Yes.

**Ellie Rofe | 44:38**
But I think, given that this will be more prepared and there'll be some thinking behind it before you can get there and then get the office hours calls within the strict context of this, I think there's going to be loads that I can get from it. Absolutely.

**Ray | 44:52**
Yeah, and the and then yeah, the it gets easier, you know, as you do you know more of them like you can figure. Okay. Is there somebody else you can do this with? A co-host? Is this going to be like a videocast?
It's going to be whatever. But it becomes the conversation, and it becomes an easy way to create content.

**Ellie Rofe | 45:10**
Yeah, absolutely. I think there is something more powerful in terms of brand building and speaking on a call as an educator, as a leader. Then there is just talking into a camera. Just as a business owner or a consultant or whether I think there's something different to it.
If, for example, the Cool does come together with the Crick, the speed, the talk, the lunch, learning, whatever does come together with the Crick, then standing at the front of a room at the Crick talking about it is so much more powerful than just talking about the same thing to a camera here, with no audience but just me talking through thoughts.
Because it immediately positions you as someone who is leading others through are it.

**Ray | 46:09**
It's getting to see you in action, working with others, and then, wait, I want some of that too.
I mean, what does a coach or a consultant, whatever? It's just teaching,
and I think if you are like you say, if you're showing you doing that in a group setting, someone can say, "I want more of that for me or my team." Then it's a Blair idea, right? He talks about the thought leadership and the content of all that.
But a big fraction of that is the idea that the expertise is actually the sales tool. So, how can you demonstrate more expertise and give them that big idea without requiring them to have done the engagement first?
This is a way of doing that. I love this idea, and I've given a couple of things on how I might try to get more out of it in the... In the course of the month. Then I'll be keeping your eyes open for what the next opportunity for that looks like.
Because this feels like the feel of a repeatable process.

**Ellie Rofe | 47:09**
Yeah, absolutely. Do you think the angle is right to prepare? You know, get ahead of the others, be smarter about it, prepare properly. Whatever. Not just your crap.

**Ray | 47:22**
4.

**Ellie Rofe | 47:24**
Let's try and fix it.
But you're going to be the smart people who are getting ahead by preparing for your raise next year.

**Ray | 47:35**
How many posts are there about, like, I've had 50 meetings and I haven't gotten my deal done yet, right?

**Ellie Rofe | 47:43**
Yeah.

**Ray | 47:44**
So the most pitches don't convert. It's not that a pitch is crap, it's that it needs to be very elite in order for you to get where you want, and you need to be ahead, and there's an opportunity for you to do so.

**Ellie Rofe | 47:55**
H.

**Ray | 47:57**
So the... So, yeah. I think the whole "let's get ahead." I don't think even thinking about it is about "let's just sort of amp up and be ready for next year." I think there's a... It's not enough to be good. It has to be great.

**Ellie Rofe | 48:10**
Yes, I keep... I was actually thinking that Maddie Maxy, Madison Maxy, who does the materials thing, was looking through her deck this morning. In comparison to what she's actually doing, it's completely underwhelming.
I mean, it's ridiculous. She's doing something so sexy and exciting, and it looks like a deck from the mid-2000s. That's telling about an HR initiative. It's just astonishing. But then I was thinking, well, I'm not going to go into this because I'm always... I'm always unsure about how helpful it is to talk to people about the odds stacked against them being a woman, a woman of color, and getting investment.
I was thinking my advice about that would be the same as my advice to anyone, which is just to make it undeniable. Make your pitch undeniable, make it as unmistakably amazing and brilliant an opportunity as possible. It doesn't matter who you are. Really, that's the entire goal of what I'm trying to do with people.
So, I guess that's... Yeah, it's not just happening in 2026. Get ready to be undeniable in 2026. Get ready to push through with the best version of everything.

**Ray | 49:36**
Yeah, actually, think briefly talks about that topic really well, but the turning of phrase I think is from Cal Newport, right? Be so good that they can't ignore you.

**Ellie Rofe | 49:47**
Yes, yeah. The beyond denial, I think is Dave Chappelle. But yeah, similar thing like.

**Ray | 49:57**
But. yeah, I think that all sounds really quite... I mean, one, I think in the case of a vaccy, that could be... Yeah, I like that idea.
Okay, there's stuff in here that's very good. There's stuff here that's really good. There's stuff here that's C-grade, right? These people see a whole lot of pitches. I think the opportunities get all to an A, and I think anything less than that has a much harder time getting converted.

**Ellie Rofe | 50:20**
Yeah.
Yeah.

**Ray | 50:30**
And think that ends about right for me. I'm always stunned when people show me their presentation decks first. It is like pulling teeth to get people to show them to you. Then, this is what you're showing the investor, like this.

**Ellie Rofe | 50:41**
Because they're so ashamed.

**Ray | 50:45**
But. But you have all this awesomeness over here, and you're showing like.

**Ellie Rofe | 50:50**
Yeah, I can tell you, they're doing robotic material, and it's in Bugatti's, but that's nowhere to be seen.

**Ray | 50:53**
Yeah.

**Ellie Rofe | 51:03**
There's not even the only picture they've got of it.
I've got to show you this because it just makes me laugh so much. I won't go on about it, but now I could just be... You know, this could be my bias here or my preconceptions. This is their website.
So they felt like this weirdly disembodied arm that's floating around in the deck, but the only real image that this video is quite cool, by the way, but they have none of this in the deck, none of this imagery, none of this beautiful motion and excitement.
This is the only thing they put in, and this keeps reminding me of control pants to make yourself look slimmer. It just feels so unsexy. It's like, well, it's an incredible.

**Ray | 52:00**
Yeah, I don't really know what the point of this image is.

**Ellie Rofe | 52:04**
Yeah, I mean, it's just showing that there's some flexible electronics, and this is basically the kind of thing that needs to be there. Then all the beautiful stuff there's so much. I mean, it's like here's the term random number. Here's another random number based on a percentage of that number with no real thought behind it.
It's all over the place. It's fine, but, yeah, it just... I think that's really helped solidify it. It is like being undeniable and pushing things to the best version of them so that, because you just don't get these opportunities, it's not like those investors are going, "Yeah, come back again in a month when you've worked to OW." They're totally bored by that person. I don't want to see them again.

**Ray | 52:59**
I think of these conversations as being about three things. Right? They are about the race, the jockey, and the horse. She's obviously the jockey. The way there's a great archive somewhere of Mark Andreessen's posts.
It's called the PM archive or something, and well, which includes some stuff he wrote way back before he started Andreessen Horowitz. But one of them is about what he looks for in investment.

**Ellie Rofe | 53:40**
Four five.

**Ray | 53:40**
And says there are three big things he looks for, right there. The three things are what's the product, what's the team, and what's the market. He keeps on getting the product over and over.

**Ellie Rofe | 53:50**
YP.

**Ray | 53:50**
But the product isn't interesting. The product is the part that's easiest to change about the company now.
Okay, well, then it's got to be about the team. They've got to show me the team over and over. Now, the team is important, but that's actually not the key. The key is the market. If this is the right market, then show me this is the right team for that market.
The product becomes the evidence of the team's ability to protect the market, which I always thought made a lot of sense as a like.

**Ellie Rofe | 54:15**
Yeah.

**Ray | 54:21**
And know that, and I put it into the framework of the race. The jockey and the horse, in that order of parity.
So, it's like, what's the... All of this should be coming back around to why they're the right jockey to bet on, right? Because it's not a horse, it's her right, and whatever her team is right, that would be where the investor is really placing their bet.

**Ellie Rofe | 54:48**
I really want an analogy now.

**Ray | 54:49**
And but the and like at seed level, I mean that's investors even talk about I mean a betting on the jockey not the worse for me the race thing is sort of the additional thing that comes into it but like you know the but then her ability to talk about the race is evidence of her quality as a jockey.

**Ellie Rofe | 54:50**
I love it.

**Ray | 55:13**
Otherwise, it's just signaling. They don't need to know the TAM. They're either in this. This market is either in their investment thesis or it's not. And within investment thesis. Is she the right horse to bet on?

**Ellie Rofe | 55:27**
Yeah, I do think they need to know what she understands.

**Ray | 55:30**
Chucking.

**Ellie Rofe | 55:33**
I think that's something that sometimes misses is, is she the right person to bet on if she has no clue about the market and hasn't thought about how they're going to grow?
That's the signal that I think sometimes a lot of people shore up the product because they think the more they show the science, the more they show that this is all derisked and this is all great and is a sure thing because look at how much we focused on this science, and it's amazing.
Actually, just showing that is a massive warning that this person hasn't thought about the market. So, in attempting to shore up the evidence that they're really smart and they know what they're talking about, they're actually diminishing their standing as the person, the jockey.
Because, you know, they look like they've just spent years and years plaiting the horse's mane but haven't worked out how to put the bridle and saddle on yet. It's just to really extend the metaphor. [Laughter].

**Ray | 56:36**
We can definitely go deeper. Although I'm not an equestrian, so I don't have that much to work with all with that, but I definitely hear that. I think that the key attribute of any entrepreneur is that they've got to be a marketer.

**Ellie Rofe | 56:50**
Yeah.

**Ray | 56:50**
Every entrepreneur is a marketer.
Otherwise, what are we doing here? It's about linking some piece of expertise or property or whatever to commerce to increase its value. That's the definition of an entrepreneur. And the chef seems to be a profile person and is respected and whatever.
There seems to be marketing there. And if you can be helping to elevate that and bring that out, I wonder whether a lot of scientists worry about that. Like, they worry that if they are doing too much of the market side and not to be seen, the serious scientists, whatever.
There's a whole public intellectual problem in academia as well, but if you want to be in a business, that's a gag.

**Ellie Rofe | 57:28**
Well, she should be owning AI. She should be seen as a visionary that's owning this category, not like someone who's just pulling together a bit of a product, which is what the deck feels like at the moment.

**Ray | 57:45**
Super cool.

**Ellie Rofe | 57:46**
Yeah.

**Ray | 57:46**
Alright, that takes us to the end of our hour. Are you feeling okay heading into a week?

**Ellie Rofe | 57:52**
I think so. Yeah. Well, good. But seven days of posting, focusing more on the pitch, a couple of sales calls to get me through, and the coaching on is my whole st.

**Ray | 58:03**
Yeah, I was about to say it's going to be your hot seat on Tuesday, so, if there's however, we can be helping you further accelerate the week when you're halfway through.

**Ellie Rofe | 58:15**
Yeah, perfect. Okay, thank you so much.

**Ray | 58:18**
Awesome.
Have a great weekend. Quicker.
By. Bye.

