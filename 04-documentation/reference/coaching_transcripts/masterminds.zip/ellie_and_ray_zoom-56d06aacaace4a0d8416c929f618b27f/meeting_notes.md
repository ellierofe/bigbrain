# Ellie and Ray Zoom - Sep, 05

## Key Points
- Ellie expressed difficulty in creating a portfolio that demonstrates before-and-after improvements in pitch decks, as the changes involve more than just design but also structure and investor-focused content. 
- Ray suggested creating a guide-like document that combines key principles of successful investor presentations with redacted examples of Ellie's work, allowing her to showcase her expertise while protecting client confidentiality. 
- Different audience segments require different portfolio approaches: consultants who might refer clients, VCs who want to see results, and founders who need help with their pitches. 
- Ray recommended creating three distinct assets tailored to each audience segment rather than trying to develop one solution that appeals to all of them. 
- Ellie's portfolio should include slides from multiple presentations rather than one complete deck, allowing her to showcase her best work across different projects while maintaining confidentiality. 
- For demonstrating animation capabilities in pitch decks, Ray suggested including links to videos hosted on platforms like YouTube or Wistia rather than trying to embed them in PDF documents. 
- Ray advised against building a complex automated tool for pitch deck analysis before validating demand, suggesting instead a "Wizard of Oz" approach where Ellie manually processes submissions behind a simple form interface. 
- A lightweight form allowing founders to submit their non-confidential pitch decks for analysis was agreed upon as a better approach than requiring them to book calls, reducing friction in the customer acquisition process. 
- Ellie will create a "vomit draft" of her portfolio materials to share with Ray for feedback, helping her overcome perfectionism and make progress on the marketing assets. 
- Ray cautioned against overengineering solutions before establishing clear demand, noting that "clarity tax" occurs when uncertainty about what to build causes projects to spiral out of control. 
- The agreed action plan includes creating a graphic portfolio for referrers, developing case studies for the website with before-and-after metrics for VCs, and implementing a simple submission form for founders. 


## Action Items
- **Ellie to create separate website pages or assets tailored for three distinct audience segments: consultants, VCs, and founders** - _Ellie Rofe_, _Sep, 12_
- **Ellie to create and send a draft portfolio document showcasing design work examples and case studies for Ray's review** - _Ellie Rofe_, _Sep, 12_
- **Ellie to develop a graphic portfolio targeted at IR consultants, including redacted examples from previous work across industries to demonstrate design capabilities** - _Ellie Rofe_, _Sep, 12_
- **Ellie to build a simple web form enabling founders to upload non-confidential pitch decks for analysis instead of scheduling live reviews** - _Ellie Rofe_, _Sep, 12_



