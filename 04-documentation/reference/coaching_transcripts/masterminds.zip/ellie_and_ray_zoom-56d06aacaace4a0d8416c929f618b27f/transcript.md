# Ellie and Ray Zoom - Sep, 05

# Transcript
**Ray | 00:04**
Hey, Ali, how are you?

**Ellie Rofe | 00:05**
Hello? Right, I'm very well. How are you? Actually, I'm not very well because Tom brought a little cold with him, but I'm fine.

**Ray | 00:14**
I am so sorry to hear that.

**Ellie Rofe | 00:16**
It's fine. It's fine.

**Ray | 00:19**
The. I, you know, pre-pandemic, I had an office in downtown Boston. Actually, I picked it up in 2018 with a five-year lease. Then, like, three of the years were during the pandemic. It was not the world's best investment.
Over $100,000 down the drain. Anyway, remote. For those last three years. But I remember when I first moved there, it was actually in the part of Boston that was near what's called Chinatown, right? Where there's a more heavily Asian American community and, particularly Chinese American.
I'll tell you, every fall, I would see the people all around the office on the street wearing masks. It was weird. Okay, you're all right, you're wearing masks. It just seems a little weird. Of course, because they were so scarred by the SARS epidemic that happened in 2012, and this who has gone to the diaspora, right? It wasn't just people in China or in mainland Asia. It was all around the world.
But they would all do it, and I thought that was weird. Then, of course, COVID happens, and then everybody's doing it right. Since then, what I've realized is that by continuing to take precautions, everyone in my family gets sick a lot less.
I remember when I was growing up, getting sick was something that was more common, of course, in an institutional school, but hey, someone sneezes, it sneers near you. There wasn't hygiene about it because we weren't. We weren't afraid of a cold in a way that made us more afraid, but just made us more diligent.

**Ellie Rofe | 01:40**
Yeah, well, yeah, I have gotten used to it, but only because I suspect I've been so remote that there's.

**Ray | 01:44**
And think we've all gotten... I don't know about you, but Astrally, I have gotten much more used to not having that be just part of the usual seasonal routine. Allergies, going to happen, colds...
Yeah.

**Ellie Rofe | 02:08**
And that harms my immune system in that I just never am around anything.
So my mom is 78 and looks after my brother's two little kids, four and five-year-old. Her immune system is stronger than mine at the moment because as soon as I get something, I'm like, "Ugh!" because I just don't get anything.
So it's a really interesting one. I remember a friend who suffers with very bad anxiety. Lofy kiwi girl at the beginning of the pandemic or somewhere through the pandemic saying to me, "I've made a conscious decision not to think too much about germs, or I'll go mad."
I'm like, "I understand that one as well." So I sit somewhere in the middle. I don't... It's annoying when I get sick, but I take it as part and parcel of things a bit because if I panicked about germs, I probably would end up... I'm going into London.
It's dirty and disgusting. You hop on the tube, and suddenly you're going to be covering yourself head to toe in an antiseptic jail, but it's so fascinating because... No, I never considered it before.
I mean, I used to regularly wander around London, touch things on the Tube, and then sit eating a sandwich on the tube. I probably wouldn't do that now because I got so used to washing my hands between things in a way that I didn't think about before, so.

**Ray | 03:33**
Well, right, and I think there's such a thing as being... You can be paralyzed by the fear to your point, like we're not talking about being.

**Ellie Rofe | 03:33**
Yeah.

**Ray | 03:43**
Hughes right. No, we're not. Howard Hughes, that's a bit much, but we are...
But like, I mean, now when I get on a subway, I'm wearing a mask, and I don't think much of it, not everyone else is doing it. In fact, most other people aren't doing it, but I'm doing it. Just by doing those ordinary things...
I remember even flying. I remember the first time I flew to NCS. I was sitting next to a gentleman from Florida who gave me a lot of grief for wearing a mask. "Okay, dude, you don't need to wear one."
That's fine. You know, I'm here. I was being perfectly pleasant with him, even taking off the mask to talk to him so you can understand me clearly. Then, for the majority of the ride, I was just going to put on other people eating, whatever that was. That was fine.
For my sons, it's like they don't want to go into a place unless they have their mask for them. It just has become part of what we do, right? When we go into these circumstances, it doesn't necessarily separate them from the other kids. They're still playing with them. They're chatting with them, they're talking their heads off, but it's just...
When it comes time to eat, eating isn't quite as social as it was because otherwise that's a big transmission zone. But they have conversations. They do D&D, they do whatever they want to do, and it's just... It's a different set of things.
Anyway, all of which is my saying that I have my sympathies for. My goodness, being sick is terrible. It used to be just another one of those things, and I don't think it's any worse to be sick than it used to be.
It's just that we all get to live much more of our lives without it, and so we... I think, appreciate much more what we have once it's gone.

**Ellie Rofe | 05:13**
Absolutely. I think... I think I do get more sick when I get sick now, though, as well, because of the.

**Ray | 05:18**
Okay, well, that come with age. That comes with age.

**Ellie Rofe | 05:24**
Yeah, I do wonder that as well. God, [Laughter] but yes, so, it's fascinating though.
I mean, he must have been 16-15, 16-17 during the worst of the pandemic somewhere around there. He does not cover his mouth when he coughs. He's coughing, sneezing, hawking stuff up. No concept of it. Which is fascinating to me. I thought kids would have been absolutely drilled with this stuff. I thought they'd be closer to germophobic, but no, fair point, but yes, it's been fascinating to have a kid here.

**Ray | 06:03**
Well, I think if you were fifteen during it, then you're in your most rebellious time. So, whatever is being drilled into you just pushes the other way, right?

**Ellie Rofe | 06:14**
I mean, a twenty-year-old, but still. Yeah, just a completely different world. Just lost in his phone. Constant noise. Hours go by where he's just looking at one Instagram video after another.

**Ray | 06:31**
Eight.

**Ellie Rofe | 06:31**
And a huge amount of their communication, him and his mates, is just sending each other Instagram reels, which stuns me.

**Ray | 06:40**
It is. There's a wonderful book called "Save the Cat", which is about screenwriting.

**Ellie Rofe | 06:45**
Yes, yeah, exactly.

**Ray | 06:46**
Have you read it too? Yeah, well, but I remember the back part of the book is just a reminder that you're not writing the movie for you. You're too old.
If you're actually reading a book, you're probably too old to be watching a movie.

**Ellie Rofe | 07:06**
I was thinking I am definitely old. Like this is radically shifted. This boy is living in his phone.
I don't get me wrong. I'm not a device naysayer. I spend time on my phone, but it's just the weft and the warp of the lives in a different way, it's fascinating.

**Ray | 07:28**
Well.

**Ellie Rofe | 07:29**
But yeah, absolutely.

**Ray | 07:29**
And a decade ago, being on your phone meant, you know, either texting or email, right? And it might have meant Facebook. And now to your point, it does seem to be and sort of then like Snapchatting, right sort of doing it through messages and now it to your point like communicating back and forth using video like this is just. I find one fascinating and two, really important as a marketing professional to be paying attention to how people work because in a couple of years they're going to be the mainstay of the business market too.

**Ellie Rofe | 08:01**
They talk a lot about Gen Z and their vibe-based approach to things. Which is why Brat Summer suddenly shot out of nowhere and had no real core to it. It was just vibes.

**Ray | 08:15**
Yeah, we say that, but it's always the next generation. With the hair and the music, have you seen Mad Madmen?

**Ellie Rofe | 08:22**
Yes. No, actually, I got into it and I felt like I was being bludgeoned over the head with very obvious messages and I got bored.

**Ray | 08:23**
Okay, that's a good point.

**Ellie Rofe | 08:29**
But I should probably try.

**Ray | 08:31**
Yeah, but one of its obvious messages is a generational shift, right? Because, you know. Don Draper is pre-Boomer. He's so-called GRA generation, and then you have the boomers who are the young people, right?

**Ellie Rofe | 08:40**
Five.

**Ray | 08:43**
And one of the reasons why it's appealing to older folks, right? It's like he's when we're young we but the but his observ right is that the boomers are about and the boomers are explaining it to you, right? That they are about feelings and ads, right? They don't want to be told what to think. They want to feel things.
Like, okay, well, they're all about fives, and then it's like, Jen ers, they're all about fives. Millennials, they're all about vibes and im zars, they're all about vibes. They're not like us. It's like. No. What happens is. Young people are all about vibes.
And then. As you get. Older.

**Ellie Rofe | 09:15**
I'm not sure that the millennial thing was very much... They're all about values. That's when greenwashing and things like that absolutely went stratospheric. The millennials were all about... Depending on where you are on the political spectrum, what you might call social justice or virtue signaling, depending on where you stand, but that was definitely a huge part of it.
There is a shift away from that, not necessarily to virtue signaling or stuff, although there is partly that, but actually, it does remind me a little bit more of the 90s, where it was slightly more anarchic. There was less meaning in a lot of the stuff we loved as kids in the 90s, and it was quite vibe-based.
Grunge is quite vibe-based. Some of the TV, certainly in the UK, was just anarchic. There's comedy by people like Vic and Bob, who were a huge comedy duo and things like Shooting Stars. Where it was nonsensical, and it was hilarious precisely because there wasn't...
They were just completely out of nowhere.

**Ray | 10:32**
Hey.

**Ellie Rofe | 10:33**
And feel like there's a certain level of that anarchy coming back in the way that they view things. But yeah, I mean, who knows? I'd need to spend a lot more time with them. I remember my nephew, a couple of years old younger than Tom, who for about a year or so, talking of Snapchat, would spend quite a significant amount of time sitting in a room with us. He's a lovely lad. He chats and he's completely isolated, but he'd just be taking a photo of his trainer or taking a photo of his ear and just sending it on Snapchat, and they'd be sending this crap back and forth to each other, and it's a bizarre form of communication.

**Ray | 10:57**
Three.

**Ellie Rofe | 11:09**
It's almost like cave painting level. It's just like, "Here's an image. Here's another image." There's image.

**Ray | 11:14**
Yeah, right, and but it is some kind of, code to it.

**Ellie Rofe | 11:14**
There's an image, here's another image, and it's all signifying something. Do you want to get Susurian on it?

**Ray | 11:25**
Okay, cool. Anyway, the I think it is fascinating to discuss youth culture in the youth market. There are probably some lessons to be carried over here.
I think in the main, we're selling to the CEOs, and we probably need to be stepping back to millennial CEOs, so let's talk about your week. I've read your report. We don't need to go over that part. I guess my question is, what did you come into this conversation with, thought-wise or question-wise? How can we be helping you have your next week be the best week it can be?

**Ellie Rofe | 12:00**
I'd love some help. I feel like I'm going around in circles on this. So, pragmatically or strategically, helping me brainstorm how to set out a portfolio when there are...
So, part of the reason I created that tool to analyze PITCHDEX was because it's very difficult. It's not just about NDAs; there's a real genuine difficulty in doing before and after on a pitch deck if you're not just doing design because the before and after isn't, and people aren't really going to take it in as a sort of before and after thing.
They're not going to go through all 20 pages there and all the 20 pages there. So, I don't know whether it's just case studies as I start rubber-dogging this, where I talk through the changes and show some before and afters of design so people can see that it looks better.
But the foundational problem with most design is not that they look better. The foundational problem is that they don't make sense to an investor. So, how to put together a portfolio that can show design, that can show thesis and structure in a way that is easy and simple for people to look at and navigate.
That's what I've been struggling with a bitt.

**Ray | 13:25**
Okay, what if we looked at this a little bit more like that? Like that LinkedIn post that you put into the report, right? Instead of a hey, this is something that explains me. This is a resource for you, right? These are five things for you to be thinking about that are, you know, well, I mean, this is more like sort of an ebook type approach.
I mean, that's kind of what this guys advocating for, right? But like you. Either in the form of a video, right? Or in the form of, you know, written content that they can consume to basically help them so they your, if you will, your best ideas, right?
Sort of put out in content form because if they were capable of executing on your best ideas, they would execute on them, right? The but the usually it's they need your help, right? To execute, either in terms of the energy that you're bringing in or the expertise as to the how or the nuances or the conversation or whatever.
It's often just like about activation energy, like it's not for them lacking knowing what to do. Although in many cases they don't know what to do, if the information were put in front of them, they would still make progress.
The person in that information would have credibility. That's where this guy, Caudle, is going, right? It's like, "Hey, here is my book on how to solve the problem." Now, I will give you those ideas, and you can go execute on this.
Of course, you're going to be incapable of executing on... A couple of people will execute on this, and they'll say, "I got this awesome book," which will only be good for your marketing, and then everyone else will say, "I don't really have the time to do this. It seems like the right thing to do, but I don't know how to get started or how to execute on it."
Now, what you can do is offer them to say, "Well, instead of you doing it with your time, you do it with money." Now, they have a belief that this is the right thing to be doing, and you're the credible person to do it because you've brought them the information about it. Now you can be moving forward with it.
I think that is the essence of the ebook or the book strategy as being outlined here.

**Ellie Rofe | 15:17**
Yes, this was the other side of things, which is when people who want to refer me or who want to give me work like talking to me, and they're saying, can you show me some examples of PITCHDEXS you've worked on? Can you show me some of the work you've done?
So this is more of a portfolio thing, but I do agree with you read the sending stuff out to people.

**Ray | 15:42**
I should think they're the same thing. See, when they say a portfolio, what they're looking for is evidence that you're someone that they should talk to. That other person's worth talking to.

**Ellie Rofe | 15:50**
They specifically asked me for examples of design, for example. They're not just saying, "Can you give me some ideas?

**Ray | 15:54**
Well.

**Ellie Rofe | 15:55**
They're saying, "Can you show me examples of work you've done? Not just ideas that I have."
So they're specifically asking me for that. And The.

**Ray | 16:05**
Why not just include the designs in whatever this would be? I mean, it does seem like the way you do it would be a couple of before and afters. Here's a sequence of the way a biotech executive thinks about it internally and this is the way the investor thinks about it because it's flipping it.
Then you have the design as part of that because you're showing a few examples, not like to your previous point, "Is trying to solve the let's show you a before and after slide deck, right?" Here are a couple of sequences.
That becomes part of your "How to be thinking about this?" which then puts your friend in a position of giving someone, "Hey, here's a useful resource my friend came up with, and I know they're open to work." The
reason I'm bringing all that up is, we can look at just creating a portfolio of "This is your design sense," but I'm not sure anybody cares, right? Isn't that a late-stage validation problem?
Is that the thing that's keeping people from buying from you or is it...? I guess I'm just trying to understand. I appreciate that. That is the word they're using. Right. But you're not a graphic Designer.

**Ellie Rofe | 17:15**
No, but when I talk with people who are saying... So three different people from slightly different angles, one is a she who works in investor consultancy as well, so she's helping people find investors, she's helping them shape their messaging.
So there's crossover. But she says, "There are people I work with who need the deck, and I can't do that bit, so I want to give you work where they need the deck.

**Ray | 17:49**
No is okay.

**Ellie Rofe | 17:49**
And view is at the moment, I'm not going to go, "Well, if I'm not allowing you to do the messaging and give them my best ideas, I'm not going to do it.

**Ray | 17:56**
So when you are being... So I think I now better take your point that this is basically you have you're discovering that there's a slightly different offer than the one you were originally pitching.
That's a little more narrow but can make money, create value, and has a different sales approach because you are basically acting as a subcontractor or someone else is doing the bigger messaging, and you want to be able to demonstrate confidence with this specific thing.

**Ellie Rofe | 18:10**
Yeah.

**Ray | 18:20**
Got it? I'm with you.

**Ellie Rofe | 18:22**
And a time when I went to Dina as the VC, she was like, "Can you just send me some examples of decks?
I just want to see things. I want to be able to show people this is a deck that was worked on that got this much funding."
So it's a combination, I guess. There are case studies that people want to see, there's the portfolio stuff. I absolutely agree that there should be something on there that is more instructive and more useful in terms of application for the target market, the ultimate target market.

**Ray | 18:53**
M. sure. So, if you were to just take a deck that you'd previously done for a client and throw some tape over it, right? It'll do a bit of redaction. Would that not solve the problem? Or like what? What problems then remain
if you've taken that first round.

**Ellie Rofe | 19:15**
So I can do redaction, but what you can't see is that before and after, you can't tell what's changed on that, what I've improved or haven't.
It's like people are saying, "I want to see what people are saying.

**Ray | 19:26**
How about it? Do you think they care? Sorry, go on, I beg your PII. I think there's a little bit of delay. Please go ahead.

**Ellie Rofe | 19:35**
I want to see what you can do. Some people ask specifically for before and after. Some people just ask for the design, and so I don't know whether I do need a loader before and after. The other slight issue is that some of the places you work for that get the best results...
This is I don't think people need to care wholeheartedly about design in terms of graphic design. They do need to care about infographic design and the actual general impression you're giving about the company.
But it's not really a graphic design task. So the results, some of the pitches that have got really good money aren't like this is so beautiful. They're just well laid out and they're just easy to read and explain.
It's more about visual hierarchy, consistency, and professionalism rather than some beautiful graphic design task. So there's a bit of stuff going on there. I guess I'm trying to work out how to give people an impactful understanding of before and after, something that ideally is eye-catching because people aren't going to spend hours looking; they're just going to try and get a feel for it.
So it's not like heavy on the explanation.

**Ray | 20:54**
What about a book that is like the slide deck after? Let's just stick with the after, because the before has a problem of being somebody else's intellectual property, right?
So let's leave aside the... I'm going to share with you the before if they want to see the before and after. What if instead of what he had was after commentary? Right? Here is this slide. Originally, the description was XYZ. You can see here, though, this is looking at it from the investor's point of view and puts you in a position to provide your professional insight over the top of it and to limit it to just showing the good stuff.
Because to your point, even if you could show the original before the fact that it's all out of sequence and part of it is the reshuffle, I think, is significant to the challenge.
Then what they're looking at is whether they think that which you're putting as the output here is something they want representing their company. Now, to your point about beauty and what have you, it's like...
But you can be directing their attention. Here, the focus is on being very functional, and graphic flourishes are dampened in favor of clearly telling. Was a pretty complicated story.
Now you're even talking about how you use this to tell the story and how you have respect for their story because you're not just covering it up with lots of adornments. I'm imagining that slide with notes, type style, that prints like PowerPoint, which is the smaller version of the rectangle, and then that based on what you were describing.

**Ellie Rofe | 22:39**
Yeah, I don't know.

**Ray | 22:44**
So far. Combined with the idea of the thing that could actually even turn into a bit of a book, that's what was popping into my brain. I don't know. What were you thinking about in terms of layout or how to tell that tale?

**Ellie Rofe | 23:00**
This is where I keep going round. So partly I was thinking I could show the structural before and after using those little squares like the tool analysis that I did where you can see [Laughter] the little... Here's the color of the thing.
And there's how we changed it to show that it's more complete. There are more colors in the final version because I've added normally something about the market or something about the investment, the milestones, et cetera.
It's less science-focused and that it's a better structure. It's not as imbalanced or whatever it might be. So I wondered whether there's a way of doing that, but in itself, although it's... You go. What is that? It takes a minute to understand it as well.
It's finding a way. I'm thinking of a sort of customer journey UX type thing where people come in expecting to see because this is how people think about pictures. It's about bridging the gap quickly between their expectations and what they see. People and maybe I'm going to dig deeper in marketing about this, and I'm overcomplicating it, but people expect to just see before and after stuff. They think of it as design. They think of it as like, I want my pitch to look great and I want it to be a really lovely pitch.
They understand that there's some content stuff going on there, but they don't understand frequently, as I talk to people, they don't understand that there isn't often an investment thesis involved.
So it's trying to give them a quick before and after. Maybe it is just case studies. Then elsewhere, there are some design examples that are really simple. But case studies actually break down the before-after in terms of what you were saying, where there's a natural narrative to what is going on, why we made choices.

**Ray | 25:09**
Yeah, I'm imagining a document, right? We need a document because that's the way they can send it over email. So it's like there's a big interactive app, which of course will be overengineering.
It's not quite what we're talking about. A thing to send over is a PDF, right? I'm imagining it being something that becomes a nicely put guide to successful investor presentations.
What are the key principles? I think that's on page one or two after the description of you. I'm imagining the issue of story points, right? Imagine that at the slide or a page that makes use of the cool structure you have with the colors.
By the way, since people are going to be reading this on the screen, we don't need to worry about printability. We can use all the colors we want for... You being able to describe... Okay, here are the key considerations.
By limiting it to one page, you keep it. You keep yourself from digging a hole of trying to explain the entirety of the idea, which is actually an important part of thinking about presentations. A presentation is not the entirety of the idea, right?
It's the part that gets you abstractly. Then, be able to support the talk, and then imagine that there are two or three pages like that of key principles, and then you have a sample. This is an example for David before and after.
I think that the problem with the before is that, like you say, it's a sequencing, but the before is ugly. The key thing about the whole document is going to be a sale by example, right? You being able to pitch yourself, of course, and then the back is being able to pitch a biotech firm, right?
And say, "This is redacted. This is based on some actual work, but names have been removed to protect the entity and the..." Then you can just be doing a slide by slide review of... Hey, here's what's going on.
Originally, this was actually four slides in the back. I moved it up to the front because, actually, this is the most important thing from the investors' point of view. Blah. I'm imagining being able to have a paragraph, and you're limited to a paragraph, right?
So, it's not too much of commentary on a per slide basis. As you go through the 20 slides and then two slides per page.

**Ellie Rofe | 27:41**
Yeah.

**Ray | 27:44**
Keep them smaller, that way, they're not taking up the whole page, right? Then you have a slide in a box followed by...
This is much like the notes page you have for some of these printouts, but this then keeps you to have that discussion, right? It's not trying to carry the load to describe the entirety of your value proposition, right? As an example, your price was what was in the front part.
Now you have the basis of a bit of a book, right? The key principles of making a successful investor presentation. Then the example where they can see slide by slide at the back, and then that's your stuff at the back. Assuming that's something that you are marally proud of, including discussions of, "Hey, this is not the most beautiful slide." Even you being able to own that.
Right? But this is why we structure it this way because not everything might be beautiful. Everything is intentional, right? Because you're trying to make use of every minute that the investor is paying attention to it and every thought they have along the way.
That's the reason why you structure it the way you structured it. Then you have that again at the end, and you know nicely. LI, this is how I do business. This solves both problems, right?
Because it's giving them something that is going to be your... If you will, an example of your skill in design. It's immediately helpful because it's not only your skill in design, like here's how to make a pitch, but the bigger slides, if you will. Those are ones that are like pitching you.
If they look at it, I think, "Hey, this seems like an attractive thing I want to have associated with my company." Well, then they're more likely to hire you. If they look at it and say, "This is not the kind of thing I want to have associated with my company," then they work. Be a good client.
Anyway, that's it. It's a first round of thought on approaching the problem, but it breaks it down to having probably no more than six slides in the front and then having your appendix, which is the most of the thing, right? Which is the example in the back.
Then, "Hey, do you have something?" I absolutely have something. Here it is. Then, they can look at it, and you're giving them more than they asked for.

**Ellie Rofe | 30:02**
Okay, there's one major question that's coming off my head, which is part of what I need to show is animation because that is an important part of pitch design, certainly for things like the mechanism of action. One of the best ways to show that is actually to show an action rather than have static imagery.
Does it matter that it's not in there? I don't know.

**Ray | 30:29**
You add it through giving them a clickable URL that opens up YouTube or something, Wistia, or whatever. You don't need to embed it in PDF. They're not good for that job. It would make it really huge.
So, I think your point, "Hey, here's a page." This page actually really needs animation. So you have in your notes, here's the link to see how this thing moves, which will be important to understanding it.
Then they go to, like, the unlisted YouTube or however you're hosting the video so that they can take a better look at that. This is actually where things like Wistia or some of the other sales-oriented video things can be helpful to you because you want to find out whether people are actually coming in.

**Ellie Rofe | 31:11**
Yeah, that's a good point. Okay, so the portfolio isn't really a portfolio; it's just a how-to with one example in it.

**Ray | 31:23**
Well, you could.

**Ellie Rofe | 31:23**
Do you think I should still be building case studies on the website?

**Ray | 31:25**
Yes. I go.

**Ellie Rofe | 31:26**
Or do you think that's just it for the moment and just keep it simple?

**Ray | 31:34**
Well, what do you think people are looking to buy when you're talking to them? What do you think is holding them up from actually moving forward? Do you think it's an absence of case or.

**Ellie Rofe | 31:48**
I don't think it's that for founders, but I think it's about... I think what this really is is an AAA referral mechanism, a way to make it easier for people to say yes. Choose Elevate not just on my say-so but go and look at what she's done.
That is where I think it really is. I think that's one part of it, and the intention is important. I think part of the issue with founders is again, sell them what they want rather than what they need. I guess I'm thinking the vast majority of them just think they need some help making their pitch look good and or help with... They might think they need a bit of help with content or structure. The vast majority of them aren't.
That's where the sales call comes in, and I talk to them. They go through their pitch, and they normally tell me some stuff about their woes with it, how they're struggling with making these decisions.
Then, I outline how I work, and that's where we get that conversion. I'm happy to do more of that upfront in the marketing, but I think that it's bridging that gap between what they're expecting to see, which is I want someone to help me make this look great, which in their head is the problem with it and the reality, which is that it's not firing. Not because it's not designed nicely, but because it doesn't actually have the right content in it.
That's the sort of gap that it feels like I need to somehow bridge with this. That's where there's a before-after thing, and I guess it's there's so many different... You said the people who are purely in the investment space and don't actually deal with the pitches themselves, they are very useful as referrers.
There is tons of potential. Even if I'm not doing the full ball pitch deck like I normally do, I mean, I still would basically walk them through that process, even if someone's done their messaging with them and even if it's not like me going in with that offer, there's still... Then normally, once we've done the offering, we've worked out how to visually depict their business, how to actually explain things better. They then normally want to bring me in to help them with other ideas and areas.
So it's not bad even if I'm not being seen initially as the messaging person, I will force myself to be seen as that, but I still bridge the gap between those two things. Engagement is showing them some before-after design work for those people VCS.

**Ray | 34:41**
Yeah.

**Ellie Rofe | 34:43**
It's finding out, I guess. I guess part of the thing with the VCs and part of the reason I feel like that might be a bit of a slower burn... Part of the reason I was thinking about this... Hammer founders with a tool that they can use that really opens their eyes is because I think VCs at the moment... It seems universally... Every time I speak to someone, they're just going, "Don't bother trying to get in touch with them.

**Ray | 34:57**
No.

**Ellie Rofe | 35:11**
They know what everyone's saying.
The only way to impress them is to show them they have done it. So it's like a humility layer. It's like, "Stop trying to tell VCs you can do this. Show them you can do it by doing it with a number of different founders." Solve difficult problems.
So where I thought, yes, ideally, I'll just leapfrog that and go to the people who have multiple portfolios because that seems like a great big lever to pull, the Aristotelian lever to go.

**Ray | 35:37**
Two.

**Ellie Rofe | 35:47**
We with them, they're all just like, "No, we're not at that point. We're not at that lever at all at the moment."
Or you can't. You haven't got enough. Have to pull So.

**Ray | 35:58**
Right, they are taking what we sometimes call a Missouri attitude, right? They're saying, "Show me right?

**Ellie Rofe | 36:04**
He.

**Ray | 36:04**
And fine. So, they basically... The essential problem here is they don't believe that your intervention is going to produce better results for them. Okay, fine. Take the point. So, there's a little bit of people who do believe in you that can work with that.
But that's the relationship that you're already working with. Then there's taken on these hard cases that you can win. I think that's really the name of the game here, and that means it's going to be about selection.
Because there are plenty of hard cases that you can't win, and taking on those doesn't move the ball for you, right? Good effort doesn't really help you that much. So, I certainly take your point on that.
So, how do you get more of those cases? I think there's a little bit of selection and knowing them. I think there are more cases out there, and you can probably get more of those meetings because they are in a tougher way.
Then you're looking to be selective about who those folks are. When I think about this graphic design angle, right? The nature of the portfolio... I don't think people are looking for multiple complete presentations. They might be, but I don't think they're looking to spend that kind of time, particularly if we're thinking about visuals. This, by the way, can be something to help with your reaction. The challenge is instead of looking at it as "Here is one contiguous presentation, like that's 25 slides long."
It's a series of sections, from different presentations, which, assuming that you're proud of all of them, they go from one to another. It keeps them from having the one story for the company, which is important, keeps the focus on what you have done about it, which is nice because by breaking that rhythm, they're no longer judging the company that's being underneath or looking at your stuff and allows you to show multiple takes on the visual part of it, right?
So, if they want to see more examples of you doing your best work, then that's where, well, these slides really aren't as great as the slides for this presentation. So, let's swap it out.
So, your 20 slides, if you will, become like slides from five different presentations. That allows you to have a greater variety and solves the portfolio problem. And you give a portfolio. Absolutely.
I've got this book that actually gives some key principles and then in the back gives samples of... These are your actual slides I've made, along with commentary on them. But you get to see how I both approach the slides and what the output looks like subject to a certain amount of reduction.
That's what they're looking for out of this. You can take those same assets, put them on your website. Once you've done it from one medium, you can be remixing it for others. I think that the usual challenge here is not making the bottle for the wine.
It's just collecting the wine itself and having confidence that you're ready to share that wine. I think you've done a lot of really good work, and you're a smart person, and I would wish for more of that to exist in the market.

**Ellie Rofe | 38:54**
Okay.

**Ray | 38:57**
I don't know. Do you have maybe those five presentations from which you could clip if you were in that or more when you think about, "Hey, what do I really have for a portfolio, leaving aside the mechanics of how then you turn into a portfolio, the raw materials.

**Ellie Rofe | 39:15**
Well, the question and the biggest reason I was worried about staying purely in biotech as well is, do I have five presentations in biotech that are worth showing in terms of results, design, and the amount of control I had over them?

**Ray | 39:32**
8.

**Ellie Rofe | 39:32**
Probably not.
That's part of the issue. This transitional thing into this slightly closed industry. The two clients I've got since coming back to this, both have stalled because their strategy wasn't there. I should have... Within a couple of weeks, have... Within three weeks, have a bit more, and maybe I wait until I've got that underway as well so that there's at least a bit more substance there.
I have... I have presentations that show cross-industry stuff, working in management, consulting, media, finance, M&A IPO stuff, which I would have to be very redacted, but not all biotech.

**Ray | 40:08**
Hey, yeah, sure. But if the issue is portfolio for design, then it doesn't only need to be about biotech.
If the issue is about strategy for investor relations, the biotech itself matters a lot more. So, there are different jobs to be done here, right? If you're talking to these other.

**Ellie Rofe | 40:36**
Yeah.

**Ray | 40:37**
Yeah, other markets. Other, you know, IR consultants, right?
You're going to be a subcontractor in a specific zone. You can show off that part and you get to use assets that you couldn't use for you being the IR consultant to the founder, that's fine.
That's why these are not all... I mean, I know I was trying to be like, "Hey, how can we have something that does multiple jobs?" But if your assets are basically you have assets that allow you to do one job better,
but they don't help with our job. Then we just have different artifacts for each of those. And that's fine. Near as I can tell, only three audiences, right?

**Ellie Rofe | 41:16**
Yes, yeah, kind of yeah.

**Ray | 41:24**
Consultants, the VCs, and the principals, the founders themselves.

**Ellie Rofe | 41:30**
They're are... Which is probably why I'm finding it a bit difficult because I'm trying to find a way to appeal to all of them, but that's just not the way forward.

**Ray | 41:32**
No, three assets.

**Ellie Rofe | 41:38**
So, yeah, as a design.

**Ray | 41:40**
Yeah, three pages on your site too.

**Ellie Rofe | 41:41**
Yeah.

**Ray | 41:43**
Probably each one will work with a different ebook or whatever. Yeah, and yeah, you got so many good ideas, and you are an impressive person to talk to and you express yourself well in writing.
I think there's a lot of opportunity if you allow a draft to get expressed. Would it be helpful for you to try putting together a draft that you never want to share with anyone else?
But maybe you share it with me because I think if you show it to someone who is outside of your household, right? You might be able to get feedback of, "Yeah, this is the part we probably don't want to show, but this part is really very good." Let's go.
You might then get the ability to give yourself the permission to share that and get that momentum.

**Ellie Rofe | 42:30**
Yes. Yeah, okay, that sounds good. Yep, absolutely. So, I will put together the vomit draft as I think of it, and you'll get to see all of that from it. LU [Laughter] okay.

**Ray | 42:52**
Yeah, and yeah, let it be okay to be the vomit draft. You can prefix it with all that, and I really shouldn't ever show anything like this. I just ignore all that and should just look at the vomit draft, but the...
I think that's just how we get things going, right? We get that first prototype. We put together the skateboard, and then we see where we really are.

**Ellie Rofe | 43:25**
Yes. Okay. So, that's the portfolio side of things in terms of approaching founders with a useful thing. I'm coming back to the tool as a useful thing because it involves them doing something rather than reading something and then getting immediate feedback based on what I would be like, based on me, based on my advice.
So, it's almost like starting to work with me. And obviously, the first output being programmed to have something and being able to track, talking of Whistar and things like being able to see a tiny little tool, not over-engineered or complex, like a literal input where you can upload a PDF, not a chat, not an ongoing chat, but a literal input where you cannot unload a PDF and then it gives you a response and analysis of it with the idea that as people are doing that, I can then see what they've put into it. The analysis goes out and understanding, doing a bit of sneaky screening, I guess.
So, when people get in touch with me, if they get in touch with me having used it, then being like, "Do I want to work with these people or not?" Are they insane? Is their pitch deck insane? Are there any signs that their company makes sense?
But I don't know, I feel like I was attracted to the idea of just sending something out to people. Whilst I understand the idea of the PDF, I feel like that's a useful thing in terms of people who say, "Have you got something you can show me?"
But just going out to people and saying, "Here's how I do stuff," feels less exciting than testing your pitch, like getting a free analysis of your pitch that you know... I don't know.

**Ray | 45:46**
Yeah. Why not start by making the test just a call with you? It's a test your pitch. A 30-minute call. Then, a 30-minute call. You're just bringing up your AI and showing how that works. You're looking at your thoughts. Here's what the AI has to say about it.
Then, that's a useful conversation they've had in 30 minutes later. They are richer for it and, more importantly, they build trust with you. That becomes a presales call for you if you get flooded with calls.
That is a bad use of your time. Then that becomes a reason to be wanting to introduce more automation. I think your bigger problem right now is that you do this in its crickets.

**Ellie Rofe | 46:24**
M yeah.

**Ray | 46:25**
So
putting in a whole lot of setup for the tool in order to solve a problem of scale when what we don't really have yet is a problem of scale. I would sort of see it like if you make this offer right and it goes gangbusters, then let's talk about how to tool it up, right? Basically investing right in order to make something that will handle the flow.
But you're talking about building a tool, "Hey, have someone upload their PDF or whatever." They need to be willing to upload the PDF to someone they'd never met, so maybe they would...
Maybe you can just make the form. See if they'll send the PDF and then what you're going to do is manually run it through your tool, right? You're not trying to automate that process. You're just going to give them the output. See if they'll do that from their point of view.

**Ellie Rofe | 47:15**
YP.

**Ray | 47:19**
It's the exact same experience, right? It's just more work for you. But I like this Wizard of Oz approach because it keeps you from having to invest a lot in building a tool that's of a kind you haven't really built before. You have validation that's going to be producing returns.

**Ellie Rofe | 47:36**
Yeah, you're completely right. It's the friction of saying, "Find 30 minutes in your calendar according to this thing," rather than just chucking a PDF in something when you're sitting there at 11:00 at night working on your pitch and you don't know why it's not working.

**Ray | 47:59**
Yeah, given the offer gi give given the offer of like, just chuck it in and it will get reviewed asynchronously and sent back. It's not instantaneous, right? I appreciate there's an additional value to being more instant or given back in a few minutes, but it's not obvious to me that that's the most important thing.
Hey, they're at eleven o'clock, they're frustrated. Here, send it in. Pour yourself a glass of wine and go to bed. Then you're just looking at the next morning. It's not like you're being flooded with the inbounds just yet. You're still at a point where you're relatively light. Let's do something that we can do at the beginning of September that we hope we're not going to be able to do at the beginning of October.

**Ellie Rofe | 48:44**
I like that hybrid version where they just see something because then it's not saying to them, "I want time on your calendar during the day when you are already struggling to find time."
It still gives them a point where they can have it and then, yes, I can process it and send it to them.

**Ray | 49:03**
You give them the results of the tool, you give them a personal note, you give them an invitation for a follow-up, and all that.

**Ellie Rofe | 49:10**
Y yeah, absolutely.

**Ray | 49:11**
You're going to put that out there and it's going to be like, nothing happens for a little while.
So, rather than worrying too much about the setup of it, I would just like, how can you in an hour have the page and the form with the upload just on your site?

**Ellie Rofe | 49:30**
Yeah, it is. What I was really worrying about was the friction of it, the booking of a call with me, because that's the bit that feels like it's just... They want sync because they're so busy during the days, and I'm not being referred to them, I'm intruding on them.

**Ray | 49:38**
I see. Yes.

**Ellie Rofe | 49:52**
So it's like, if you need a hand, I can just provide a free analysis for you using this tool that I've developed. Here's what the analysis will look like.

**Ray | 50:01**
No, that seems like a neat, you know, free product using, you know, Priestley's, you know, four proc model.

**Ellie Rofe | 50:02**
Let's go.

**Ray | 50:11**
I like it. Let's see if we can... The and I like the basically the experience of it is just as a form super lightweight. Put this stuff in, you get your email address because that's going to be the way you receive the result.
You say, "Look," and you can even put in the guarantee. I will not... You're going to get a result from this, but I'm not going to bother you after that.

**Ellie Rofe | 50:40**
Yeah, perfect. Okay, that feels cleaner because I have been part of the reason I've been resisting it is again this desire to not have to try and create something, develop something. I'm not a developer,
and this... But not wanting this like, "Hey, book time with me." That's such a big ask rather than an offer in terms of the balance of things.

**Ray | 51:08**
It is not obvious to. Well, I mean, you know, your audience.

**Ellie Rofe | 51:12**
Yeah, it's.

**Ray | 51:12**
But I found a lot of the time, particularly when people are concerned about confidentiality, they're more willing to hop on a call than they are willing to send over a document.

**Ellie Rofe | 51:22**
Yeah, I can see that they're not going to put in their confidential deck, they're going to put their non-confidential in, and that which again will have similar issues. So, yeah, yes, absolutely, yes.

**Ray | 51:34**
And then you put you use that language for the form you say you know make sure you're putting in your non con right to it helps you helps reinforce that you're someone who understands that.

**Ellie Rofe | 51:53**
Okay, that sounds good.

**Ray | 51:57**
So I love the notion of like the tool as super simple form right now. Now we reduce the development costs to a very tiny amount. Not for nothing, you're talking about not being a developer. You're very much a developer. You've made some really impressive stuff.
Just the nature of what should be developed... What you're looking at now is not so much the complexity of the build, you're looking at the lack of clarity. I was just having a conversation with another founder yesterday about what I call the clarity tax, which is when you're not quite sure what to build.
That is when the thing spirals out of control and becomes large.

**Ellie Rofe | 52:27**
Yeah, okay, that makes sense, it makes a lot of sense.

**Ray | 52:29**
And I've been there, too. I've made the exact same mistake. I can think right now of businesses that I drove into the ground by making that kind of mistake.
But the simplicity of what you have here, you have clarity of what you're trying to build. Great. And the fact that it's not completely automated isn't that? That was never the objective. The objective is how it is going to help drive business.

**Ellie Rofe | 52:59**
That's nice. Okay, so a graphic portfolio for these people first and foremost. Long term, maybe some case studies up on the website for VCS-ish. Probably VCS will see the before and after at least figures, amounts.
Then just a very simple form off of people which is basically ready to go because I just need to put a form together. And everything else is fine. Yeah, that seems to work.

**Ray | 53:31**
Okay? Then I'll just look over the course of the week, whatever works for you, please do send me the vomit draft. It'll help you make the page if you do over the weekend, do it next week, whatever, and just send it early, like one of those. Hey, you're working on it at night, and then you are done and, like, you're gonna crash and leave.
Like, just. Yeah, make that. Okay, I'm going to sort of see what Ray has to say about it. And we'll just make a little more progress that way.

**Ellie Rofe | 54:03**
Yep, okay, perfect. Sounds good.

**Ray | 54:05**
Awesome. Okay, well, is there anything else I can do for you before we wrap up here today?

**Ellie Rofe | 54:11**
No, all good. I'm smiling, but I haven't said this in the group yet.

**Ray | 54:14**
Fantastic.

**Ellie Rofe | 54:17**
But I have a thing in my head where I've realized I'm trying to race to see if I can get off a call faster than you get off a call. [Laughter] It's so fast.
It's amazing. [Laughter] I see.

**Ray | 54:33**
Alright, we'll keep track of that. I'll see you on Tuesday. Thank you.

