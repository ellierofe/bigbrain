# Ellie and Ray Zoom - Mar, 20

# Transcript
**rhdeck | 00:04**
Recording in progress. Hey, I am all right.

**Ellie Rofe | 00:07**
Hello, how are you? [Laughter] No offense, apologies for being late.

**rhdeck | 00:12**
I just sent you a note. I hope I didn't cause offense with it. Just asking whether we're meeting up this morning. What's the good?

**Ellie Rofe | 00:21**
One of those calls that wouldn't stop.

**rhdeck | 00:27**
Yes, I get those. I'm... Hopefully it was a good one for you and good for the practice.

**Ellie Rofe | 00:34**
Yes, how how's things.

**rhdeck | 00:39**
Very nice.
Looking outside, we got a little bit of snow last night, which is just papering over the green that I was otherwise looking at earlier this week. But I'll take it. I'll take it. So get this vision of winter lasting just a little bit longer.

**Ellie Rofe | 00:52**
[Laughter] I love how poles apart we are. I like it was 24°C yesterday. I am loving it.

**rhdeck | 01:04**
It's 24 degrees Fahrenheit today, and I'm loving it.

**Ellie Rofe | 01:09**
Exactly.

**rhdeck | 01:12**
I'll take my little bit of a little bit of winters left. I've told Demetrius earlier. And? And I call ear this morning that the, you know, for. There are lots of people who sort of get in like their ten days or whatever. They're going to ski and they do it in February because that's really the high season.
But like for me, I mean, a lot of the days I get are in the shoulder seasons, you know, where the moun either early season when the mountain isn't quite ready or later because that's just there are more days of those, you know, and for me, it's like the mountain, it's perfectly fun, good it's good exercise, it's entertaining.
But I don't have to share it.

**Ellie Rofe | 01:51**
I was going to say so it's quieter and more pleasant. RA.

**rhdeck | 01:55**
It means the grooming lasts longer. So that's what happens. As you go down, people are wearing away the mountain, right? Or wearing away like the snowy part, right?
So getting down to ice underneath, call it getting skied off. Now because there are very few people to it, there's no one else, not no one else, but there are very few people to skate off. It just means it can actually have conditions as nice, perhaps even nicer than what I get in the high part of the season.

**Ellie Rofe | 02:25**
It's really similar here, but with summer season, so head off kayaking on the rivers in April and May. It's beautiful. It's warm enough. It's not 40°C.
Like 100°F or whatever. So it's beautiful, but there aren't a thousand tourists. When you get stuck on a wheel, there aren't a thousand tourists taking photos of you on the bridge above that way, which is nice. [Laughter] So, yeah, I get what you mean. A touristy area out of season is perfect.

**rhdeck | 03:02**
It really can be. But okay, so but here we are this week. I appreciate it's only a half week, right? But we're sort of getting back in the groove here. I suppose we. We can use as much for as little as time as is helpful to you.
So, like, how can we. How can we be aiming this in a way that's going to be creating maximum value for you? And then I think it's your hot seat on Tuesday, too, right? So, like, how can we just sort of, you know, accelerate the week for you?

**Ellie Rofe | 03:30**
Yeah. Well, I think one of the interesting things is I need to do some work on this G delt like database data source. And apparently it's all in big query, which I am. I am slowly understanding.
I thought an interesting exercise just to understand how you work with AI is to... So I'll show you what I did, which was very instinctive. I didn't think too deeply about it. Then I thought, "Let's talk with Ray later."

**rhdeck | 04:10**
Two.

**Ellie Rofe | 04:11**
So in Claude, I'll just share it a second, right? So my first salvo, right? I just love seeing how people work with this stuff better than me, and that's my main goal. My first salvo is often this kind of thing. Can you give me a staged explanation? GCS to a level. To degree. To mastery. To try and bring me through some progression on understanding what it is and the basics of what it's doing?
Then it did that. I got an idea. I'm not really... I'm not perfectly versed, but it's just a grounding so far. Then you gave me all this information. Then obviously by the end of this, it's saying...
Right. So for UK political media research, which is the top-level thing, I told it the most productive next step would be these things. I'm like, "Right before we do that, let's just work out what I actually want to know."
So I said, "I'm doing a research project. I've put data in a knowledge graph, so far I've scraped all these things. This is vast." Then I attached the questions I'm trying to answer with it. Then it started going into what media analysis uniquely contributes to the actual project, coverage, momentum, narrative and framing landscape.
So that was my first pass of it. But I would love to see how you would go about something like this.

**rhdeck | 05:52**
Yeah. So there are a couple of things I'd like to do. The first is when it just data, I like to go look at it. It's a dataset that's available through BIGQUERY, right? So you can just open up a query.

**Ellie Rofe | 06:02**
I haven't even looked at big query yet. I wanted to try to understand what it was. Someone said if you. Someone said it can get very expensive very quickly. Which is why I was trying to.

**rhdeck | 06:12**
Yes, for hosting your own data, absolutely. So like where is there so but their data is in big query.
Is it like an accessible shared database or.

**Ellie Rofe | 06:29**
Yes.

**rhdeck | 06:31**
Try to keep my understanding of that. Now, first of all, they have their free analysis service, which is fine. Then there's a thing in BigQuery, and then you can download it.
Alright, let's click on BigQuery. Well, to understand that more...
Seawor says the full list of tables. Click that... Could scroll down.

**Ellie Rofe | 07:16**
Well, that's interesting.

**rhdeck | 07:19**
Which I'm wondering how to update this thing. Okay.

**Ellie Rofe | 07:26**
Has this stopped that with pain? If it has...

**rhdeck | 07:34**
So that becomes another question I ask, is it current?

**Ellie Rofe | 07:37**
Yeah, okay.

**rhdeck | 07:40**
That seems like a great ChatGPT question.

**Ellie Rofe | 07:46**
Yes.

**rhdeck | 07:59**
I don't need to worry about a subm, and they have an API.

**Ellie Rofe | 08:01**
No, I just wondered what it was saying. So there does seem to be something happening in 2023.
Where are we seeing the API? What am I looking at?

**rhdeck | 08:24**
Sorry, when you flicked away from it, it was the... I don't see that in the GitHub.

**Ellie Rofe | 08:32**
Yeah. Okay. Yeah, it's a Georgetown project as well. I don't know when this is up to date. Okay, so...

**rhdeck | 08:47**
Okay, so the first thing I ask is, "What's the easiest way to query data from the dataset?" I just want to go take a look at it.
So it is all available in Google BigQuery and provides free access to it.

**Ellie Rofe | 09:07**
Are you asking me to look for something?

**rhdeck | 09:09**
No, sorry, I'm actually I what I did was I asked, just what's the easiest way to query data from the G del data set? In Claude and the, it does and it's.

**Ellie Rofe | 09:19**
Claude? Okay.

**rhdeck | 09:28**
To do that, you'll need a GCP project. Do you have a GCP project?

**Ellie Rofe | 09:33**
Probably what, quite a lot of, is that Google? Google Cloud? Yeah.

**rhdeck | 09:37**
Yeah, well, if you click, you seem to be logged in so we can go to so we can go and enable we go to the homepage of it. Yeah, good. And you're in big query. Yes, you're logged into the USC the E in the upper right hand corner. We can enable the BIGQUERY API.
Yeah, and this should be a public dataset that's available to you, which we do inside the Aquerry environment.

**Ellie Rofe | 10:17**
Okay, so what's new in studio files? Explore Gemini, Apache Spark.

**rhdeck | 10:28**
Yeah, so here we have... I don't think Jen Lang clients. What you're looking for, we can search BigQuery resources. Let's just do a search up there and we'll look for Delta.

**Ellie Rofe | 10:47**
Is this just looking at organization?

**rhdeck | 10:50**
Yeah, what do we have up here? There are some other windows up here, search for sources.

**Ellie Rofe | 11:04**
Okay, so, like, I think.

**rhdeck | 11:05**
Now we got... You can see these are all from the Google Delta feetube dataset, right? Which is interesting. So let's... Maybe want to click into windows just for fun. I mean we just start with something and we want to click up Delta too. Now we're getting a vision, right of like what's in GW 2.

**Ellie Rofe | 11:37**
I can't sort by that. Okay, I'll give it a try.

**rhdeck | 11:41**
No, because there's. I mean, these are sort of a series of.

**Ellie Rofe | 11:45**
Yeah, two.

**rhdeck | 11:45**
These are tables that are in here, but then you can click on one to start to get a feel for, like, what's in here.
And this is what I start to do it. I want. I mean, I'm looking at it as a data set, right? And like, there's a lot of stuff in here. Okay, but not forever stuff, you know, like events seem like. Okay, this seems like it's a reasonable place to start, right?
And then, could we get a preview, maybe? And this what it starts to look like is like what data looks like in here.

**Ellie Rofe | 12:20**
Because it's vertical, right? So it's a columnar.

**rhdeck | 12:24**
Each record is going down and the fields go across. Right? That's the basic structure of your table data set.
So you should be able to scroll left and right. Again, this is just by getting a feel. Then you can create queries. Interestingly, you can create conversations, which I think the conversations are about asking questions that allow you to generate queries. I'm like, "Okay, well, that seems interesting."

**Ellie Rofe | 12:52**
Okay.

**rhdeck | 12:54**
And now what more can I, you know, do with these things? Now, the there's a, there's another one, it's called partitioned. So events has a downside of like it searches through all. My goodness, this is quite large, right? All roughly billion, right?

**Ellie Rofe | 13:13**
Yeah, there's quite a bit of data in this, apparently.

**rhdeck | 13:15**
So it's 883,000 records if you go up to... Yeah, if we go up to... Works as tables again, there's no one called events partitioned.

**Ellie Rofe | 13:27**
Yeah.

**rhdeck | 13:29**
Now partitioning is usually by, you know, usually that is by date. So the way this will work is you can partition the query to, you know, to basically say I only want, like, recent stuff and this is the here.

**Ellie Rofe | 13:50**
Can you partition by geography as well, or is it always by...? Will it partition by various things, or is it normally just that they partitioned it by day?

**rhdeck | 13:58**
You're right. So there are two separate questions. The first question is, "Can you query by geography?" The answer is probably yes, right? Filter to just a geography. The second question is partitioning.
Because the question is like, "If I've got this huge thing that's a billion records in it, how much of it do I need to look at to answer your question?"

**Ellie Rofe | 14:20**
Yeah.

**rhdeck | 14:20**
By all the answers, I look at all these, I don't know where anything is.
So the idea behind partitioning is indexing. It's a variant on the idea of indexing. The idea behind partitioning is that I'm going to take chunks of the table to have certain things in common.
Then if you give me a query where you're filtering on that way that it's chunked, instead of having to look at the whole table, I only have to look at those partitions that relate to your query.
Then from there, I'll do the additional filtering that you're talking about. Rest you can always filter down based on any of these criteria or any record that's in here at least, right?
But the way the partitioning thing, doing a date-constrained search, will make it faster and coincidentally make it cheaper because the... You could... But Google is going to bill you for... It's going to be the time it takes you to query the data.

**Ellie Rofe | 15:13**
So this is what they're doing with...

**rhdeck | 15:20**
Ahet so faster equals cheaper.

**Ellie Rofe | 15:21**
Yep. Yes, yep. So it's probably better to start depending on how things are partitioned. Start with the smallest possible partition and expand outwards if you need. Tom.

**rhdeck | 15:42**
Well, or just make sure that your query includes the thing that's partitioned on, for example. I'm pretty sure partitioning here is on dates.

**Ellie Rofe | 15:51**
Y.

**rhdeck | 15:53**
Okay, so the idea here is that if you use the way it's partitioned to filter it and you can ask for help with this, right? I'm not saying you need to go create all this where you know AI is out, right?
But I'm trying to give you the way to think about the question, right? Then AI helps you get the answer but like the partitioning and look, initially you do it naively. Don't worry too much about that, right?
But as you do more of them, the more you use partitions first, it'll go faster for you, right?

**Ellie Rofe | 16:26**
Yeah. Yeah.

**rhdeck | 16:27**
If you were to say, "Hey, I only want the top hundred records of the things that have these dates."
So I'll just say sort by date descending, which will give you the most recent hundred. Unfortunately, you just set yourself up for a huge expensive query because it has to go get everything in order to solve your question right? Even though only return to hundred records had to look at a billion.
If you include the criterion that the partitions on, you only want the things from the last ten days, which actually includes a million records. You want the top hundred of those. Great. Now you've restricted it to only billing you for looking at a million records instead of looking at a billion records.

**Ellie Rofe | 17:03**
Y2?

**rhdeck | 17:03**
And that's, you know, obviously a thousand and one savings so that so the including the way it's partitioned will save you both time and money.

**Ellie Rofe | 17:08**
No.
Yeah.

**rhdeck | 17:17**
And when you're look. And the thing about Big query, these very large datasets is that that's that becomes a kind of thing that allows you to move faster and with greater confidence.
Because, hey, I can now ask more questions because I'm not worried that it's just gonna cost me an arm and a leg.

**Ellie Rofe | 17:34**
Okay, and how do you tell what it's partitioned by? Do you just look that up elsewhere, or is it somewhere here that I can't understand yet?

**rhdeck | 17:42**
Let's take a look at the schema or the details he usually tells us. Partition by field partition time. Partitioned on field partition time. Right, which is of course by partition by day.
So partition time is going to group them up by day.

**Ellie Rofe | 18:00**
Yeah.

**rhdeck | 18:02**
So if we go back over to your schema here of the table, there should be something called partition time.

**Ellie Rofe | 18:14**
How do I know?

**rhdeck | 18:15**
So it's like a virtual thing. Okay, so that means we want to query it, we want to do the work that will include the partition time.

**Ellie Rofe | 18:24**
Got you.

**rhdeck | 18:24**
So let's try to do a query. Yeah, let's do a quick query here. Look at that. See?
It's giving you something, right? So basically, only look at today's stuff.

**Ellie Rofe | 18:35**
YP Y.

**rhdeck | 18:37**
So let's just say select * from * means get everything. Although you can always include fields in here, right? Because you should be able to field as a field.
But STAR is a way to get just the initial give me everything to... Which allows you to investigate a little faster. Have you ever run that?
Do you have building alerts set up in your Google?

**Ellie Rofe | 19:07**
Yeah, yes.

**rhdeck | 19:08**
Okay.

**Ellie Rofe | 19:13**
So I will put some limits on it as well, just to make sure if I do make a massive mistake, it doesn't.

**rhdeck | 19:20**
No one query is going to kill you, but just pay attention to that and get the digs, and that way you can see how it's going on.

**Ellie Rofe | 19:25**
Yeah. Sydney, Calgary. I'm a Catholic.

**rhdeck | 19:28**
I actually only started blowing past my limits because of... Or gain my alerts on account of using Gemini more using the Gemini APIs.
But yeah, now you have a whole bunch of events and data. There's something extra called visualization. To see where it has results of visualization.

**Ellie Rofe | 19:53**
[Laughter] What is this trying to show SQL date?

**rhdeck | 19:54**
It's not very exciting, but like you get to start to create different whatever's in here now that it's the same for all of them.

**Ellie Rofe | 20:03**
So is that just all the records that have a date or something that it's showing? Of course. Okay. The date is 20.26 million.

**rhdeck | 20:13**
Yes.
So right now it's like, "What are you measuring?" It doesn't make any sense to measure this, right?

**Ellie Rofe | 20:21**
But if you put it to num mentions, for example, and num sources, that might be a bit more varied.

**rhdeck | 20:32**
Yeah. And like, you can start to play with it more and like, you know, load data into where you want to visualize it in. I mean, you're.

**Ellie Rofe | 20:39**
Yeah, okay, got you. That made sense.

**rhdeck | 20:45**
So basically this is just listing a bunch of records and giving you this.
It's not the world. I see. It is a global event ID so it's grouping by global event ID and saying how many sources are... Okay, which is maybe not as exciting as it might be, but... But if the event... But yeah, this is one per event, so it's actually not that cool. I like... Can you name these things? What's the question you want to answer?

**Ellie Rofe | 21:10**
Yeah, well, that's... That's what I'm going to have to try and work out, I think, is how I parcel down queries. And I think there's going to be an AI... I need to understand what entities I want to query on.
So for example, in terms of my thinking of the research I'm doing in general, there's a difference between querying on the Green Party and querying on Zack Palanski, the new leader of the Green Party.
How much fragmentation do I want over what timescale to understand trends and what questions am I asking of it? Because there's sentiment analysis, obviously, about various actors in British politics and various parties, but issues.
Part of the understanding is how those things are impacting other actors within the political parties and where media presence doesn't match policy or voter presence and things. So there are a few different ways we'll need to slice and dice it, and part of it will be getting data out of here in a way that it can then go into a knowledge graph to create more nodes and edges.

**rhdeck | 22:35**
Yep. And that's. I mean, that that's all stuff that you can do here and like, I like to start with this kind of thing. That way you can just sort of see what the data looks like.

**Ellie Rofe | 22:43**
192.

**rhdeck | 22:44**
But then that doesn't mean you need to be copying and pasting some of that or anything like that. You just start with looking at it, and then this starts to feel a little bit more like a cloud code type experience where you're going to be posing together.
All right, we won't be able to go look up Big Query. What tools do you need to be able to look up my stuff in my Big Query? All right, we're going to look up this dataset. Okay? Now, what I want to do is answer this question. What seems like a reasonable query for doing that?
Okay, great. Now let's pull that down. Now, let's lead this into a graph and... Yeah, you're the conductor, right? You're letting the. Letting the instruments do their work.

**Ellie Rofe | 23:15**
Yeah. Okay. That's helpful. It's. I think what fascinated me when I spoke with Robert and Demetrius was. And I think you probably sit in the balance point. Robert is just like, just let the hour go and go off and do stuff.
And then, like, just almost he's, almost seeking complete autonomy of the agents and stuff.

**rhdeck | 23:40**
M.

**Ellie Rofe | 23:42**
He doesn't want to be in there. Then Demetrius is like, "No, I'm training these bastards like I'm nailing them down. I'm checking everything and really trying to step in and control and..."
I feel like you're like, "I'm going to understand the bits that I need to understand as a human and see what things look like and scope the landscape, and then I'll go and give the agents the control of something. It feels like a blend of the approaches."

**rhdeck | 24:10**
Yeah, my thing is there's non-management and then there's micromanagement and then there's what I'm trying to do is figure out okay, what is the value I bring over what the AI does. I don't want to be afraid of the AI, that's why budgets matter, right?

**Ellie Rofe | 24:29**
No.

**rhdeck | 24:30**
I gotta tell you, the kinds of costs that you're talking about just aren't going to really move the needle for you. You're not going to be looking at a thousand dollar bill for doing queries year and looking at pennies or dollars, but watch it, just have that up at another tab, and then that way you get to... I find that observability gives you confidence, so I like to start by looking at the data. I'm comfortable looking at data.
I think you're comfortable looking at data, too. By looking at this, I see what's going on. I can see what intuitively might be going on. You know the kinds of shapes that should be produced. Now you can have AI produce those shapes and you can reason check those.

**Ellie Rofe | 25:08**
M.

**rhdeck | 25:08**
You have an idea of what good looks like, whether we're going in the right direction because you've taken the part that is most important, which is the data and made sure that that's within your domain.
Then, as it runs off and does things, you have that control over the word. I think really, we're just talking about confidence. You know what? I think you're going off the rails here. Why do you get this?
Then you can have a conversation about it, like the way you got that was because it was doing something maybe weird or wrong. Maybe it's because it sees something you didn't.

**Ellie Rofe | 25:45**
Yeah.

**rhdeck | 25:46**
But the only way you can evaluate that is through having looked a bit at the data to begin with.
All AI is data analysis.

**Ellie Rofe | 25:55**
Yes.

**rhdeck | 25:57**
My I'm working with my Heckathon partner right now on this project. We're just looking at, basically looking at motions of, prediction markets versus, like, you know, crypto prices.
And the reason we chose that is just because it's data rich and it's a type series data.

**Ellie Rofe | 26:15**
Yeah.

**rhdeck | 26:17**
We're trying the auto research mode of optimizing a model to be able to predict what's going to happen next.
It's a silly use case, right? But the reason I bring it up is that it's using the code along the lines of what Robert's talking about. I go and do things. But the thing that I had to get my partner's mind wrapped around was the most important thing is we need to have an idea of what the game we're trying to play is because we can need to optimize, but only if we know what the game is and the...

**Ellie Rofe | 26:45**
Yeah. 2m.

**rhdeck | 26:50**
Then by being able to play that game afterward, you can evaluate whether or not a given strategy is actually working or not. That only works if you have an idea of what's going on there. So actually, what we're spending our time doing is looking at these CSVs that were coming off of Polymark and, finance and just as you're looking at the data that's sitting underneath...

**Ellie Rofe | 27:09**
9.

**rhdeck | 27:14**
Okay, this was good. What questions do your clients need answered? You can even say, "All right, this seems like a weird result. What was the query you ran to get that?" Then you could try copying and pasting that query to validate or whatever.
But you're not trying to micromanage its lines of code.

**Ellie Rofe | 27:31**
Yeah.

**rhdeck | 27:32**
You're trying to say, "Can I reproduce your results? Do I think those results look correct? Do I think the question looks reasonable?"
Then you know that allows you to let it run much faster while you're able to keep it going roughly in the right direction.

**Ellie Rofe | 27:44**
Yes, yeah. So it took down 12,000 records or 12,000 entities into the knowledge graph from company house because companies like PricewaterhouseCoopers and Ernst & Young had donated to political parties, and it had taken every single officer of those companies.
Because they're LPS, so every like all their executives are partners, it had just dumped them all in. So it's doing what it's been told. I need to then go in and go, "Are these records actually rich for us? Are they salient or are they just noise?"
Then it goes and takes all back out again. So, yes, I get what you mean. You're trying to understand with the Polymark stuff how accurate the predictions are.

**rhdeck | 28:29**
Well, yeah. Well, what we're trying to do is basically understand where there's predictable pricing, right? Because pricing is... There's a whole trend right now in prediction markets of what are called binary outcomes because they're easy to bet on, right?

**Ellie Rofe | 28:46**
M.

**rhdeck | 28:46**
Like, "Well, something as stupid as is Bitcoin going to go up in the next half hour, yes or no?" Or "Is President Trump going to say the word 'great' or something?"

**Ellie Rofe | 28:59**
Tweet something ext.

**rhdeck | 29:03**
Yeah, like in the first...

**Ellie Rofe | 29:03**
Thank you for your attention to this matter, Pierre.

**rhdeck | 29:08**
Exactly.
And the is you can say that in the next, you know, hour or at this meeting or whatever. Like these binary things I think are easy for people to bet on, but they're weird, especially the ones that are tied to financial instruments.

**Ellie Rofe | 29:18**
Yes?

**rhdeck | 29:23**
So the question is, are they mispriced? Because they seem it seems like it's anything that's going to be a magnet for stupid money is likely to get mispriced. And so we're looking for those just discrepancies.
And I'm not so much interested in like making a betting exercise out of it, but the. But using it to sort of see how can we get the AI to make a analysis right? Just by writing code and just by trying strategy after strategy.
I mean, this kind of thing was like a lot of work to set up in old school machine learning, and we're just trying basically. Based on a post from under Karpathy. What if you just have the AI try making code to do this? Then you see how well it works, and then you have it go try it again.
You know, kind of like a variation on like, if you've heard of the Ralph Luop idea, right? Like what you know, which is basically requires an evaluation set to get it to just, you know, dial in and get smarter and come up with different strategies.
And that so the game it's playing is can I make a better Polymark bet, right?

**Ellie Rofe | 30:32**
Yeah.

**rhdeck | 30:34**
Based on good pricing of those. Then if my partner and I were like, "But don't we just want to write more often?"
No, you don't just want to write more often. You want to be right at the right price. Right? So if you are right by a penny three-quarters of a time and you're wrong by a nickel a quarter of the time, you've lost a lot of money.

**Ellie Rofe | 30:56**
Yeah.

**rhdeck | 30:59**
So you want to be right big, and you might be wrong small, so the percentage of time you're right isn't even the key consideration going to be what the degree is sure.

**Ellie Rofe | 31:07**
Nine.

**rhdeck | 31:08**
Off all of which, by the way, saying that's the thing that we're looking into right now as a strategy.
The reason I'm bringing it up is because it's another example of it just comes back to the data, right?

**Ellie Rofe | 31:23**
Yeah.

**rhdeck | 31:24**
The more you're comfortable with the data, the more comfortable you're going to be letting the AI move faster.
That's how you get to stand in the middle between what the robber and Dimitri standing under your shoulders?

**Ellie Rofe | 31:36**
Yes, yeah, okay, that's very helpful. I'd be fascinated to know how well the algorithms prediction algorithms do on stock prices compared to analysts. Yeah.

**rhdeck | 31:49**
Yes, and short term, long term, you know, there there's all sorts of, you know, weird stuff in there. Yeah. I'm. I'm really interested in production markets as well. Like, it's like.
And. And the bigger they get, of course, the more corrupt they'll get, too.

**Ellie Rofe | 32:04**
Yes, yeah, well, that was the other... I mean, the thinking in systems, I guess, but it's always been a thing of mine.
It's like... So one of the interesting things is that a colleague of mine who worked in the dev team of a research bank research house tracked all of the analyst predictions against the actual stock performance over various time scales.
He found that they were basically right about 50% of the time. They were a coin flip. So I was interested to see where... Because obviously, analysts are both better informed and more biased by their constant integration within the companies. They're always talking to various leaders within those companies and trying to understand them.
I wondered if an algorithm that was slightly more dispassionate performed better. But as you say, as soon as you start not only corruption but as soon as you have mass markets betting on things, you have the popul. You have layers of psychology and counter-psychology going on that create interesting movements as well.
So yeah, it is a fascinating one.

**rhdeck | 33:25**
Yeah, the lots of lots move in that. But I didn't mean to completely strike you from the G Delt stuff. That the.

**Ellie Rofe | 33:29**
Yeah. No, distract it.

**rhdeck | 33:30**
That's sort of the way I think about and I suspect that for the kinds of composition you're looking to do, you know, you start by looking at Claude chat, but you start moving into using more of a, you know, Claude code type approach. This I and I introduced Demetrius to this as well.
But like skills can become very helpful too, because it gives it more ideas. Like there's probably no che del scale, but certainly there are big query ones, right?

**Ellie Rofe | 33:55**
Yeah.

**rhdeck | 33:56**
To be smarter about how to think about, you know. Wait. How do I make this kind of query? Where do I look up stuff to get the right syntax? Whatever.
You can... That doesn't need to be your problem.

**Ellie Rofe | 34:06**
I do try to use skills more. Robert gave me a great skill, really nicely developed, which was... It's like an evolution of the project that I created in ChatGPT all those many moons ago at State. Changed to do that marketing exercise.
It is something that leads you through something. Then I replicated it with my niece recently. It's an interesting one to create these skills that aren't just the skills that are talking with you, rather than skills are just going off and doing stuff. There's a check-in point at the right time.
Okay, fabulous. Well, I will... I'll go and start doing that then.

**rhdeck | 34:56**
I mean, I do love the DLSIS stuff. And partially, it's just... It's such an easy way for you to create value and share insights. You create a little bit of visualization. What people really love... They really love charts and they really love maps.

**Ellie Rofe | 35:16**
Yes, yeah. I feel like there is a whole series of stuff I can do with this data way beyond and above what I'm doing with the SDP. It's a beautiful thing to start gathering stuff and having your own amalgamation of data that you can control and pretty easily update.
Because most of these sources that I've been gathering are APIs or CLI or something. Then I have my own picture of a landscape, and I can add to it however I wish. Slice and dice that data and understand what I'm doing with it.
I do have a lot to learn about data analysis, but I have worked on... I have an instinctive understanding of it because I worked in banks for so long and had to deal with big data sets and creating charts and understanding modeling and things.
But this is obviously a different caliber of stuff, so I need to do some sort of statistical analysis, research, and study again to refresh my mind up on certain things. But, yeah, it's good.

**rhdeck | 36:21**
Sure. Do you already have ed T tea on your shelf?

**Ellie Rofe | 36:24**
No, that will...

**rhdeck | 36:26**
Are you familiar with this work like a visual display of quantitative information? Okay, the tankers. Professor Tufty, who was... I was the only freshman in his class.
He's been for 45 years. His classic book is called "Visual Display of Quantitative Information" by Edward Tufty. It is great. I bring it to your attention because the data visualization aspect is such an unlock.
I think you'll find it to be intuitive, and it's... I'm always given book recommendations, but Tufty was like, "Great." He really set me on my path. He was a data scientist before we had the term.

**Ellie Rofe | 37:10**
Yeah, okay.

**rhdeck | 37:11**
He's a guy who had like, you know, he had posts in the Computer Science, Statistics, Graphic design and Political Science at Yale.
So it's he knows the stuff. But the, he wrote a whole series of books, but like, the original is still the best. And for thinking about, like, how you can just sort of very clearly display and communicate insight or use data to generate insight.

**Ellie Rofe | 37:38**
Yeah, yes, okay, fabulous.

**rhdeck | 37:39**
I can't make a stronger recommendation than that Professor.

**Ellie Rofe | 37:43**
I love that he's cantankerous in his name's Tufty, which I don't know if it traveled there, but it's the name of a squirrel. Tufty the squirrel in the UK.
It's like this little cute...
No, really cute little squirrel, so...

**rhdeck | 38:03**
Alright, let me know if there's anything else I can do for you this week, and we'll keep things going Tuesday.

**Ellie Rofe | 38:03**
Yes.
Okay, perfect. Thanks, Ray.

**rhdeck | 38:12**
Sure thing.

**Ellie Rofe | 38:12**
Take by.

**rhdeck | 38:13**
Second bye.

