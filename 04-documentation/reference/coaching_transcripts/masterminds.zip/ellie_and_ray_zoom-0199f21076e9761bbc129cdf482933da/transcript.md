# Ellie and Ray Zoom - Oct, 17

# Transcript
**Ray | 00:00**
Breath.

**Ellie Rofe | 00:00**
Gras apologies for being late today. I heard a call that I should have just said when he booked it in. Maybe we should move it so I don't have a call straight after. Then, it inevitably dragged on in the last five minutes. So,
sorry about that. How are you?

**Ray | 00:23**
I am all right. I had a call like that earlier this week, talking with an agency called Code Store that's based out of France. They were very French and going on about how I'm late for office hours. I need to go to that.

**Ellie Rofe | 00:36**
[Laughter] But being on time is not a big thing here. [Laughter] It's really not. Dear.

**Ray | 00:47**
I read somewhere that in the world of virtual meetings, there's no more excuse for being late, right? There's no traffic, no nothing. I have come to realize that I do get...
I mean, look, yours is fine. Don't worry, I'm not trying to make a comment about your thing, but it does immediately get things off to a bad start when someone is more than 120 seconds late.
So, I've learned to buffer a little bit like you're talking about, but just think. Okay, I've got ten minutes to go. I now need to bring the meeting in for a landing.

**Ellie Rofe | 01:22**
Yeah.

**Ray | 01:22**
As opposed to let's go all the way to the end or find a natural stop or whatever.
It's like I need to be deliberate about it because usually these things get pretty engaged and interesting by the time I get to the 40-minute mark. Okay, we're really cooking. But by the time you get to the 50-minute mark,
you'd think about, "Okay, what's the down ramp?

**Ellie Rofe | 01:37**
Yes, I was trying. Then, even just the clarifying and closing off just required more clarifying, so it just went a bit further, but it was a very interesting call.

**Ray | 01:45**
No.

**Ellie Rofe | 01:49**
It was actually with another guy related to the political party.
But he is... So I've had two conversations with people related to this party this week. One of them is the guy who I've done a website proposal for. He runs about seven different businesses he set up. He helped set up Psychiatry UK, which is like a multibillion-dollar business.
It's huge. And a few other development projects. He's done big development projects. So, he's a proper bona fide entrepreneur who's one of their candidates. So, he's been a really interesting contact.
Then, this guy was... He's actually an energy trader in Düsseldorf, but he has done a lot of work with startups in energy, so he's a potential source of referrals, but he's doing some work on data in the NHS, so fruitful, but maybe not immediately fruitful, depending on this proposal thing.

**Ray | 02:56**
Right, yeah. Well, it's like which category does it go into, right?

**Ellie Rofe | 02:57**
Interesting.

**Ray | 03:01**
Is it studies or sells it ship? The thing about it is that it can feel like ship, but I would posit that if you're not being paid, it's not shipping, which I think helps put things in the right box.

**Ellie Rofe | 03:09**
No? Okay.

**Ray | 03:17**
Right? Okay, well, I'm not being paid for it, so if that's not shipping, then what am I doing? What is the utility of it, right? Because, in the framework of knowledge, reputation, and wealth, right? Which are study, sell, and ship, right?
Right, the job of ship is to create wealth, right?

**Ellie Rofe | 03:32**
Right, I think ship as delivery.

**Ray | 03:34**
And the job of w where work. Yeah.

**Ellie Rofe | 03:36**
Okay, I get it. Yeah. So? Shipping isn't just delivering something. It's actually earning money.

**Ray | 03:45**
I tend to think so, yes, because, for example, you are obviously shipping this, the what you're calling the Observatory, right? This has a product aspect to it, and it's a real product. As such, it delivers value into the world. I kind of expect everything you do can deliver value into the world.
That's not really the standard or that's not the differentiator among them, right? So, everything we do in production is valuable. The question is, is its job to increase our knowledge, increase our reputation, or increase our cash?

**Ellie Rofe | 04:17**
Got you?

**Ray | 04:18**
And there could be things that do multiple jobs, right? This has value in three of these categories. The best stuff we do has multiple applications to it. But the reason I'm bringing this up with you is as you think about how you're carving up your time.
I'm spending a lot of time shipping this week, but I feel so poor. What's going on? It's because what we were actually doing was spending our time studying worse help.

**Ellie Rofe | 04:42**
Yeah, or selling. I don't view the Observatory as shipping. It was just delivering something to a client in my head, that's just in that bucket.
You're right. If it's not getting paid for, then it's just that mean. That's really selling. If anything, with a bit of stuady.

**Ray | 04:59**
Right? It's not so much to be casking ourselves one way or the other, but just it helps us think clearly about it. Okay, what does this thing create?
There's value that it creates in the world, but how's it going to create value for me? In terms of those three categories of KPIs, right? And those three verbs that we use to go with them.
Anyway, I find that to be helpful because certainly, it's easy for me, but in terms of someone you've seen more of this from, Robert, for example, will often talk at length about all the stuff he's doing for Snappy, and some of that is now turning into shipping as he's starting to get paid for it.
But because he's not being paid all that much for it, a lot of his basically every hour he works on that is investment time as opposed to being delivery time, which makes it look more like study or maybe it looks more like cell.
None of us would say he's doing the wrong thing. But once you have those, it becomes a little bit clearer. Wait, this is how it would create value for me. Okay, this is how I need to put it to work. This is me over-indexing, under-indexing, whatever.

**Ellie Rofe | 06:07**
Yeah, okay, very helpful. Yes. And as an aside, part of this work with this political party is selling hopefully selling a kind of brand strategy digital twin.

**Ray | 06:16**
Hey, that's cool.

**Ellie Rofe | 06:23**
So, yeah. And talking with these wealthy businessmen who are happy to donate to the party.

**Ray | 06:33**
Yes.

**Ellie Rofe | 06:33**
A couple of them have already donated a bit of money to fund a campaign manager or something.
And I'm like, maybe you can fund something a bit more fundamental and strategic for these people. Which, you know.

**Ray | 06:49**
That certainly makes a lot of sense. They often care about these things, but my experience with these political donor types is that it's a bit of a club, right? They do go in there to do business with each other and they are going to meet these people who then they have who have unfair now access to these moguls or whoever.
Now it's like, "Hey, you can be doing that. You can be doing that for the party. They can see your quality. They say, "You know what? I've got a business. You need to do this for.

**Ellie Rofe | 07:13**
Yeah. So one of them has just suggested setting up the guild, which is all the people who are members of this, but it's a small party. It's in... It's very much startup mode. I actually said to them, "The gap in the market for you guys is actually entrepreneurialism."
In the UK, we obviously have more than a two-party system, although broadly, it's been part.

**Ray | 07:32**
Yeah. I got it. M.

**Ellie Rofe | 07:34**
And know, Labour is the unions and lots of public sector workers, but none of them have business experience.
Then the Tories are like effectively neoliberalism, large business, slightly kleptocratic reform. The big runners now are finance bros. They're not entrepreneurial in the same way, but those are the people in this part, and then the other side are frankly quite communist.
Those of the people in this party are extremely entrepreneurial to the point that I suggested they might be able to create a donor mechanism where they have an investment fund that funds "Made in Britain" or "Build in Britain" funds that fund startups that are designed to rebuild Britain because it's a basket case at the moment.
They go out and try to get larger donations. They're not going to get unions, they're not going to get the neoliberal billionaires who want favorable terms for their massive multinationals, but they might get people like Stephen Bartlett or JK Rowling who agree with their quite centrist platform and are willing to put into a party that offers them something different.
Anyway, that's a complete aside, but it's really entrepreneurial, and they do have a lot of people there with direct startup and build experience in all sorts of things. So.

**Ray | 08:57**
Yeah. And those are the same kinds of people who like to invest in other startups and try to make them more successful. This actually gets the whole helping those companies sell as being...
Yeah. I think it's wonderful that you're in that mix. I think it seems like a great networking opportunity.

**Ellie Rofe | 09:13**
Yeah. They don't have any strategy whatsoever. So every time I speak to them, I'm blowing their minds with stuff because I'm like, "Wow, could you do that?" Yes, that's totally feasible. In fact, it's advisable, not just could, but should.

**Ray | 09:27**
Yes.

**Ellie Rofe | 09:29**
So it's been interesting. Excuse me.

**Ray | 09:35**
Super cool. All right, so, yeah, I've gone through your report, and you talk about a bunch of stuff. I want to talk about the study versus the shipping part because I think it's helpful for clarifying thinking if I see when I see someone who's saying, "I've spent too much time shipping." I'm now looking for the cash flows. It means you're good with the current cash flow, maybe you're underindexed on building equity.
But actually, that's not the situation here, which is fine, just like it tells us where we are.

**Ellie Rofe | 10:09**
One.

**Ray | 10:09**
But having read through this, you had like, I think an open thread in here about, like, Demetrius or what have you.
But like, how. How can we put these next 45 minutes to work in a way that's going maximum value for you.

**Ellie Rofe | 10:21**
Yeah, I suppose that question is... I occasionally get asked, "I did a website for someone earlier this year. I get asked by people who are starting up to do a website." You're always just listening to signals in the market.
So I'm always interested in this because it's like people who know me come to me with this question around feasibility. People who know me say, "Could you help with a website?" There are two parts to this question. Firstly, I hadn't thought much about this, but if I decided tomorrow I was going to be a web designer and developer, then I would be in a market with God knows how many other people.
It's definitely a bit of a race to the bottom at the moment unless you're a top-end agency. So, I'm looking for this as a core thing, but it's something that happens where people ask me for it.
So, that's one thing I find interesting. Marketing as this would be a road to nowhere, but it's something that the market tells me they want. It's just a very limited version of the market that wants it. People who know me...
Then, when it comes to actually doing it, this is something I'm going to talk frankly with Demetrius about. But in terms of the investment that people actually want to put into a website, it is quite small.
The actual project for getting their website working is... The salon I did earlier this year was pretty simple, right? They're not trying to sell something complex or a service, but Demetrius obviously is in a market where there's lots of competition, and you're trying to teach people what on earth you're talking about anyway?
So, he needs a bit of underlying groundwork and foundational work to actually understand what he's trying to say. I know that some of it struggles because it's his second language, even though he speaks it incredibly well.
So, there's a level of it that's just strategic and understanding the underlying brand strategy, positioning, and who he's talking to, and then there's a level that's execution. It's the same with this guy who...
So, this guy's plan is to start manufacturing artillery shells because he's worked out he can do them cheaper than in Coventry, which is where he ran as the candidate, which is where they spun up during the early part of the 20th century, something like a 12,000-person, 600-acre site to develop artillery engines, et cetera. Obviously, the warm thing, and there's this big story behind it, but he's got to sell it into the mod and everything.
So, they just want the end product. But the end product... I can't just go, "Yeah, that's fine." It will just take me ten hours because the product is stuck in their head, and I can get it out fast.
I'm getting faster and faster at getting these things out of people's heads, but I don't know how to frame it to people to say this is the problem. The problem is not that you can't put a Squarespace website together. The problem is that you don't know what you're trying to say in the first place.
That is the thorny problem that we need to tackle before we can get to the website, and I try and say that, but I think people are just like, "I want a website, and I'm going to pay a better GRA for it."
So, I don't know, I've just dumped a load of thoughts there, and I'm not really coherently asking a question about it, but I suppose I'm trying to understand how I respond to this signal in the market without just giving my time away.

**Ray | 14:11**
The signal in the market tells me there's a product for prospects here, right? Not a core offer, but a profit prospect. There's not a core offer because it's not a core competency, nor is it particularly blue ocean, right?
This that doesn't feel like a good place to be, but it's a thing where people are asking, "Hey, how did I do a website?" In the context of a prospect, you want to be cheap, right? Cheap for them to buy, cheap for you to deliver. The thing I found myself saying to Demetrius is that I'm not sure how much he's buying into it, but I talk to people, and I talked to Mitch about this, right?
Mitch talks about copy and the storytelling and all those things, and all those things need to be improved. But increasingly, I'm thinking that this becomes a problem that causes everyone to seize up. Until you get this thing right, it's just putting the cart before the horse, right?
Okay, well, fair enough. But the fact that I don't have a horse yet doesn't mean I don't need a cart, right? How do people know that even open for business? Well, you gotta tell the story, otherwise the site's not going to convert, blah.
You know what I think? I'm actually not at all convinced that's true. I have seen sites that do massive conversions with no content on them. It's like the company name and an email address. Why? Because the company itself is remarkable and worth looking at and worth talking about.
Then they haven't figured out how to do the marketing. This is not where they want to spend their time. So they have basically a blank page with these two things on it. I look at Demetrius and I frankly, I look at a lot of businesses and I think that those that have not yet figured out how to tell their story should just not tell their story.
But they need just a business card online.

**Ellie Rofe | 16:00**
Uhmhm.

**Ray | 16:01**
There are some site builders out there that are about this. They are often described as a social media bio, LinkedIn bio, Crisp, and then what is it?

**Ellie Rofe | 16:07**
Yeah, definitely.

**Ray | 16:11**
It's a picture of you, your name links to your socials, and a big "Schedule Time" button, and then get the hell out of the way. The trick is, do you need something that's going to describe what your business is when you don't yet know what your business is, right?
That's the cart before the horse problem. You don't have the thinking, and therefore you don't have the words, and therefore you don't have the sight. But the thing is, a site could convey the thinking. It could be elevating them, or it could just be the necessary step they're going through in order to get to what they want to do anyway, right? Are people finding it because of your website? Are they finding you because of your media articles? Are they finding you because of your YouTube? They find me if they're finding me in the way they're getting to you is not your site.
This is a lot of SEO's, getting people to go find your site from Google, right? But if that's not the way that you're marketing, and I often don't recommend that should be the way that you market. You should do it through socials or what have you, things that allow you to build more trust.
Then the website is just the necessary evil step, right? Taking you to net schedule. People expect you to have a website, like some piece of territory that's yours. Otherwise, we're wondering who the hell you are, or how have you marked it?
But that doesn't mean... But then I think after that, every unnecessary word in there, you lose. I think about Demetrius's stuff, right? He wrote some words up there. The words aren't terrible, but they're not great. They're not really moving him along. The graphic design is awful.
I look at how this has improved his situation. He wrote some insightful content or video or whatever he put up on LinkedIn or YouTube or whatever. Then they say, "Hey, this guy Demetrius seems to know what he's talking about." I'm going to go click on his site.
They get to that, and now that's a big fall-off. I don't think he's alone on that. I think a lot of the time we talk to these people, and they don't really have an idea of what to do. So, the trick is that by talking about the strategy and the content of trying to come up basically with a sales letter or what have you, you're setting it up that it starts the cost of the engagements going up, right?
But I think having something to say... The thing I'm finding myself saying is that I don't think you need to be saying this, but the thing I find myself saying when I'm thinking about the website problem is, "Don't have a website. How can you have a business card online?
This is actually increasingly popular for developers who are building their own websites because they think they're supposed to have a website. They don't really know what to have.
If you look around, you start finding more of them that, aside from people who are in developer relations and they've got talks and articles and whatever, it's just a little business card.
They don't expose your email address or they have a form or something to come talk to them. Or they have linked socials or whatever. I think that even the whole idea, you've got the big screen and then there's little rectangles.
This can be super handy because now you've constrained the size of it. You're not trying to fill all the space. You define the rectangle you want to be in. It's sized to that rectangle. What are the two biggest things on it? The art and the click to schedule. Now that's my thesis on what makes for a good site when you don't yet have the content.
Because then I'm not trying to solve the problem of "let's get the content." You are solving the problem of the site being a detractor while you don't have the content. That fills you in. That can then be the lead into the core offer, which is figuring out your strategy, your brand, what you're trying to say, whatever, which can then lead to a second version of the site or whatever you
do. But even somebody who's going to go make art, I... My brother works for a company called Reflection AI, which is based in New York and just raised $2 billion. I swear, their website does not have a hundred words across the whole thing.

**Ellie Rofe | 20:13**
No. but they raised that money off Pitchdeck, not off a website or off relationships and stuff.

**Ray | 20:18**
Exactly.
But which is kind of my point though the website and is the web the website is not critical to their success, right?

**Ellie Rofe | 20:27**
Y.

**Ray | 20:28**
But they are using it to recruit. So they would have a website. Now they click through to the thing they really care about, which is taking you to whatever service you're using for putting out the job postings, whatever.
Right, and then that... So it's a relay station for that. I think someone like Demetrius, I think there's something similar here. I think it's possible as he gets better at articulating himself using words, particularly using written words. You're talking about going onto Medium and all that.
That's great. Now we'll have more things to say, and you can have a site that's going to be about... Okay, let's connect it with his content. Or even have the one piece that you want to be your manifesto that's directly on the screen or whatever.
There are a number of ways you can do that. Because all of a sudden, he has more supply in the form of content and ideas. Then you have demand in terms of space, and right now, it's reversed.

**Ellie Rofe | 21:21**
Yeah, I broadly agree. I mean, my view is if it's just going to be a placeholder, why not just have book a call direct on LinkedIn and YouTube?
Like there's no point in having a website to send people to just to book a call. I would from my observations and I haven't analyzed it deeply, but from my observations, part of the and I am not seeing this from a, pedestal because I am terrible at this myself, but the part of the issue with Demetrius's content, he is very insightful, but he doesn't speak to the people that he needs to speak to. He does not talk to people who need a digital twin, and he doesn't connect with their problems.
So he tends to talk about the interesting things he's learned about the tech or things like that, which is interesting, but I don't think he's often. And I haven't looked at his contents. Maybe he's ramped that up recently. I haven't looked at it for a while,
but I think that's Demetrius's website is a manifestation of that issue that he can... Apart from the design, which he would be better off just getting Framer to knock something up or whatever, or Releue or something.
I think the underlying issue with his site is that he doesn't know who he's talking to and he's in a... I'm absolutely fine with saying just have a book or call and don't have a website if it's too much expense and too much time for this point, but to get people to want to book a call, you're going to have to know who you're talking to and how you're framing their problems.

**Ray | 23:00**
Two.

**Ellie Rofe | 23:10**
Because I can make a digital twin's like who people are. People are buying into services where you just dump some information in. How are you different? Who are you actually doing this for? Are you doing it for SMEs, or are you doing it for solo business owners or like coaches? Mitch showed some examples the other week where he's clearly working with a coach in some kind of Manifest Destiny type thing, not Manifest Destiny or is it manifesting?

**Ray | 23:37**
Commercial development stuff. Yeah, that's his fallback business, right?

**Ellie Rofe | 23:41**
Yeah. So manifesting, et cetera. And, [Laughter].

**Ray | 23:46**
God, that guy's so weird. The partner that works with him, his big claim to fame is he was in Branda, what's her name? The secret, who's the Waddles disciple.
It's all about... Yes, it yes.

**Ellie Rofe | 24:03**
There is a huge woo space. I once spoke with someone who was introduced to me for Moogle, and he was talking about how he coaches people through spirit. I was like, through their spirit. And he's like, no, he communes with Spirit and coaches people, and Spirit was like a spirit with whom he communed.

**Ray | 24:22**
Okay, thanks. All kinds?

**Ellie Rofe | 24:24**
Yeah, exactly.

**Ray | 24:24**
Sure.

**Ellie Rofe | 24:26**
Not my wheelhouse, not my problem. But I don't think Demetrius has articulated this. So he's just talking about the tech. And I think that's what I would like to help him with more than anything before going to the website.
This is what I mean, everyone wants a website, but the underlying problem is always different.

**Ray | 24:40**
I think just is, right? Yes.

**Ellie Rofe | 24:47**
Now with Alistair, in absolute fairness, he does know what he wants on that website. He just can't execute it. He does know that he wants it to be a symbol of a business that he can talk about.
I totally get why he wants this front thing, partly because the mod will need to see something that seems quite professional, but he wants it to be this is what we should be doing. Civic regeneration, industrial self-belief. Peace through strength.
Whatever other things he has around, like the national security in the UK and outsourcing everything. So he does have a narrative. He knows what he wants to do. It's just executing.
It is a problem for him structuring and executing it. So there's a slight difference in use cases, I guess.

**Ray | 25:37**
Yep, and I think but I think what we're getting at is there's do you have a horse yet?

**Ellie Rofe | 25:37**
Stories.

**Ray | 25:45**
Right? If you don't, how can you subtract? You're not exposed to the fact that you don't have a horse. When I need a website, just start thinking about, okay, what do you need for a website? As opposed to how can we make you not need a website? How can we remove that as a barrier to your business? At the beginning, I actually just put a little business card site from by one C change members because I think it does a good job of keeping it super minimal, reducing... He's Austrian, so he's not a native English speaker. He has really good ideas and is smart. He doesn't have the book to call because that's not where he is yet, but his... That is who he is and what he offers, right?
Great gets out of the way. I think... I don't think someone's going to go find him on Google, look at the site and decide to do business with him. I do think if someone finds him through the other stuff he's doing, right, finds him through GitHub or finds them through social media posts he's making or finds them through YouTube that they could come to hear and they're not losing credibility along the way to actually connecting with them on a more direct basis.

**Ellie Rofe | 26:50**
Yeah, but I think there is a part of this. Again, this means it depends who Demetrius is trying to talk to. There is a part of this about the expectations of your audience base.
So, his... The expectations that... Mihali.

**Ray | 27:10**
Meha? Yeah, that's how you pronounce it. It's... Yeah, it's a but a Hungarian name, so, yeah, I think it's pronounced Meha.
By the way, if you know the guy who wrote Flow anyway, his first name is Meha anyway. But, yes, that's how I pronounce it.

**Ellie Rofe | 27:29**
His audience are people who, I would say, are more tolerant and interested in novelty and in that slightly more arch sort of execution of things. That's where it matters who Demetrius is trying to target.
Because if he's trying to target coaches who want to be spoon-fed stuff in the way that they understand things, then it may work, but it might just be people going, "I don't know what he does or how he's different or anything like that." I agree with you. I don't think he should do it yet,
but I think he should spend more time on LinkedIn trying to understand who he's talking to.

**Ray | 28:15**
I know that for sure. I think that's absolutely correct. What I was trying to do here, and you can tell me if I'm beating a dead horse at this point, is separate the concerns.

**Ellie Rofe | 28:26**
Yes.

**Ray | 28:27**
People say I need a website like...
Okay, well, are you at the point where you don't yet have the horse?

**Ellie Rofe | 28:33**
Yeah.

**Ray | 28:33**
Let's talk about defining the website down so that you have something that's not going to be a tractor. You don't want someone to go look up your domain and find something not there, or like a placeholder site from Squarespace or whatever. You want to have something that's going to at least hold your credibility, right?
That's where having a picture of you comes in. So it's clear it's you. Then ideally, being able to take them to the next step so that you might be able to encourage them in the right direction. But essentially, if you're trying to lose ground,
then you have another step of being able to talk about the... To your point, trying to understand who your audience is and what their needs are and how to be talking their language.
That actually feels more like the core offer stuff, right? So the first thing is to get the first part out of the way, and then let's talk about the real thing, which then can lead to... All right, now let's come back around. At the end of the core offer, it starts to look like, "Okay, what does the website need to be, and who do you hire to go do the design for it?"
Because you're going to be able to get that done much cheaper than hiring me. Which allows you to now be out of the technical part of that business, right? And you're now in the elevated part of the business where you want to be, which is the thinking, the writing, you know, et cetera, the copy part, the that arc of it makes a lot of sense to me.

**Ellie Rofe | 29:44**
Yeah.

**Ray | 29:51**
And maybe what they have is you talk to them in the first hour like, "Clearly, they've got something great. Let's talk about the three major types of websites." There's the social proof site, there's the manifesto site, and then there's the... I don't know what the third part is.
I'm making it up here, right? But if what you have is a framework that points them in the right direction, and then there are templates we can do for those. At that point, it becomes a technical exercise, there's a copy exercise, and then there's the technical create the website exercise. I would posit you don't really want to be in the technical create the website exercise part, but you probably do want to be in the copy part, and you can probably offer a smaller engagement to get them really good copy. That then is putting them in the right position to be able to execute on the rest of the site.
Probably for a lot of these startup companies, they don't yet have social proof. Great. All right, that means you don't have that. Corey Haynes had a pretty good seven-part sass website structure. Although, I find actually the most compelling ones I've seen are really the sales layer style.

**Ellie Rofe | 31:06**
Yeah. Generally, Yeah.

**Ray | 31:09**
So, if you have enough to have your manifesto, great. Let's get that out there. The other thing I find to be very compelling is the big Wall of love. Right? I mean, it's actually much more about quantity than having, you know, if having two really good detailed case studies... Fight isn't all that credible. People snooze, right?
But if there are a bunch of people who have been using it, there's actually a lot. Okay, this seems credible to more people. That's my small opinion about this thing. I wouldn't mean to have you take those all the way across,
but just having opinions right about... Do they have an asset that they can manifest as in the site if they do? What's the structure for that? Then being able to help them move forward, that really breaks it down.
I find a lot of people just seized up on the blank page.

**Ellie Rofe | 32:04**
Yeah, I suppose. I guess my underlying philosophy is if you don't know who you're talking to, then you can't even do a digital card site like it. It's still going to be crap because you're still going to just be saying nothing to nobody. So.

**Ray | 32:24**
I think it's okay to say nothing. I think a good business card should have a good tag, but just remove that for a second. Here's your name, here's your company name. Here's book a call. At that point, you're not losing ground. You could do better, but it's so much better than throwing something up and having the floppy all over the place.

**Ellie Rofe | 32:44**
Yeah.

**Ray | 32:47**
You're not really a graphic designer, and even worse, spending a whole bunch of money to fill in to improve the design and still have it with the empty space.
What am I really talking about here? The whole... When you don't have anything to say... Don't say anything. The a website can not say anything. And this may sound weird, but I think it can not say anything. Well.

**Ellie Rofe | 33:12**
Yes, no, I do agree with you. I'm seeing... I am coming round to the concept that saying much less is better than saying more because saying more means that you have to...
The bit is like you will rebuild this. Things will change. If you're not settled in what you're offering and not like, I know exactly what I'm offering forever. But if you don't, even if you're not shipping or whatever, then it is hard because things will change.
So you're going to create something that you then have to renovate. I get what you're saying. Yeah, it's like a minimum viable connection.

**Ray | 33:50**
Right. And then, like, so how do you solve that problem? Basically put a band Aid over, right? And now there there's, I laugh because. And, you know, like, I got bitten by a dog, you know, at this point now, a couple of weeks ago, right?
Like, 13 days ago, my dog and I think a bit about, like the proper sequences. First you do the first aid bandage over.

**Ellie Rofe | 34:16**
Yes. Yes.

**Ray | 34:18**
That's okay, that's not a replacement of what needs to come next. Now, I waited too long. For what need to come next and I paid a bit of a price for that.
But like the but these things sequence, right? Like what constitutes first aid sort of becomes product for prospects, right?

**Ellie Rofe | 34:32**
Y.

**Ray | 34:33**
Like. can do this. I can point you this way. Then, you're doing it on the call with them in half an hour.
Use a service for it. Don't need to make this thing bespoke. Just, there are a number of services out there that can do this. Like, let's do that in a way that will then have you be far more credible than you were yesterday. Now, let's go work on the problem as opposed to your thing, which is terrible.
Now, every minute that you don't have it fixed is something that's causing them stress or what have you.

**Ellie Rofe | 35:01**
Yeah.

**Ray | 35:03**
You the first date isn't going to hold forever, but that's not its job. At the same time, you're not bleeding all over the place while you're trying to put in the perfect as opposed to the merely good or fair.

**Ellie Rofe | 35:15**
Yeah. Yeah, okay. Yes, I think it's a really good idea because I don't think Demetrius has the clarity enough to create a website, and it will require quite a lot of heavy lifting, and he needs to go into the market.

**Ray | 35:32**
And graphic design thing, I actually was working with it. I've pitched to him the business card thing a couple of times, and he's not moved on it.
I think he's not moving on it because there's a little bit of he's not confident that it's the right next step. He wants something he won't be embarrassed by, but the problem is what he has right now is almost worse than nothing.
But the standard of just how can I go to a better isn't the one he's going for, a part. I think maybe because he doesn't quite see what the step after that is right?

**Ellie Rofe | 35:52**
It's yeah, it'.

**Ray | 36:03**
The put on some first aid. He's saying.
But what? How do we cure? It's a perfectly reasonable question. It's just not. What's next?

**Ellie Rofe | 36:10**
Yeah, okay. This is a nice framework because I have increasingly thought. I mean, I did my own audience analysis to help with slightly shifting a bit more to hard tech in general and being more specific about stuff and based on what I've learnt as well, not just top-of-mind stuff from the people I've worked with before.
It took five minutes because I did it with my Claude prompt and, well, actually, my Google prompt and structure, and I tested it over a number of times.

**Ray | 36:44**
Hey.

**Ellie Rofe | 36:49**
And took five minutes to get clarity on that.
Then, that becomes a little tool that you have in your business, or an asset you have in your business that ideally, unlike with Claude projects, you can't update things easily. But ideally, you would update and evaluate every now and then as you learn more about your audience so that you can use it as a lens for everything else you're doing.
That's making the product for prospects. Who are you talking to? What do they care about? What are they saying? If you keep talking about what you care about and you never connect it to what they care about, then, yeah, it's a tough one.

**Ray | 37:25**
No, it's a tough one, and we all face it. I actually just got my butt kicked a little bit by someone who recently left State Church and gave me seven or eight paragraphs in the... I got a little softboarding survey, and they... I said, "Hey, how can I do better?"
It was great. Those fantastic, detailed stuff, super thoughtful. But I think one of the things that I come away with is it's a little too much like what I care about. Not enough what the audience cares about in terms of where I'm describing things. I'm not sure that would solve her problem, but I think she put her finger on a good emerging problem in State Church. Or maybe it's past the point of emerging, but it's something to be doing something about you and into what you're describing.

**Ellie Rofe | 38:11**
Four.

**Ray | 38:17**
Like we the cobbler's children indeed.

**Ellie Rofe | 38:19**
[Laughter] Yes.

**Ray | 38:21**
You know.

**Ellie Rofe | 38:22**
Yeah, it's very difficult. Yes. Okay, so I think maybe what Demetrius really needs is a framework by which he can start understanding how much he is connecting with his audience.

**Ray | 38:38**
I think that's right. The thing I have found myself... I have been really impressed with how well Robert's meetings have worked in connecting him with this audience. And one of the things I actually recommended to Demetrius, I'm starting to say it's a good thing in general, particularly when you're building up for practice, to be just setting up a regular meetup.
So it's actually something I did. I changed before I started State Change, where it was originally done as the MEU and that the ability to get in touch with customers. Of course, you start with people who already like you.
Right? Then being able... How that be a wheel? Back into content and back into events and back into... But really into understanding. You know, it's not obvious to me that Demetrius's problem is a function of needing to lean back in his chair and think about what he's learned.
I think it's a function of him needing to go talk to the more.

**Ellie Rofe | 39:35**
Yeah, that's what I'm saying. He doesn't even know who he's trying to talk to.

**Ray | 39:41**
Yes. and I guess what I'm trying to get at is that people hear that and their first instinct is to study their notes or think about things or whatever. They treat a lot of these marketing questions as problems that need to be solved in the house, as opposed to.

**Ellie Rofe | 40:01**
Yes.

**Ray | 40:03**
I need to get out of the building.

**Ellie Rofe | 40:04**
Yes.

**Ray | 40:05**
And I'm pretty sure I'm... I can be wrong. I'd appreciate your thoughts on this. My take is that most of the time when I hear that, I don't know who I'm talking to, it's not quite... I've been thinking about this.
I've been studying this. Okay, who are you talking to? How many conversations have you had, right? If you haven't had that many conversations, that means you're not talking to anybody. So the solution is that, like, you're creating content needs to be downstream of the confidence that these are having the image of the person you've been talking to live in your mind.

**Ellie Rofe | 40:38**
I think a big part of the issue is it's a feedback mechanism. So people think I need to know who my audience is, I need to know what my offer is, or I need to know what my offer is to know what my audience is.
It is a feedback mechanism, and the two evolve. I think the slight question I have about just talking to the market is I remember Robert saying to me a few times or to the group. He's been talking to the market, and it was inchoate. It was just the market was just anyone who he'd spoken to, and it wasn't actually people in a market that he was trying to address or anything.
So it's if I say I've been speaking to the market because I've had a chat with my MoM about PITCHDEX to take it to a really extreme market. Well, she's not the market, but I've just talked to someone about PITCHDEX like that.
So it's made it. There is an element where you have to have at least a target region of people you're trying to talk to, and if there are people from outside of that who come into the orbit and give you something incredible, that's great.
But to get this is what I mean, it's a bit of a catch-22. You do need to know something about who you're talking to before you just go out and sporadically machine gun content that doesn't connect with anyone?

**Ray | 42:00**
Well, I think you're right about machine gun content. But because you're then... That indicates, on untargeted spraying of bullets into the market, you don't really know who you're talking to. Whatever. I would probably do two things. The first is there's such a thing as practice.

**Ellie Rofe | 42:28**
Yes.

**Ray | 42:28**
I find that most people in these businesses... What happens is they're used to working with... They've had a job or maybe they've had long-term clients, and they are not used to talking to people. They're not used to expressing themselves outside of just "ship", right?
That's why I talked about studying cells. They're not used to saying that, "I'm going to spend a real part of my time learning something I didn't know previously." Because my clients are coming in, they want this stuff to happen.
I will just do that stuff for them. I get paid for it. Isn't that wonderful? Right? That's very much the day job philosophy, whether you are a freelancer or, you know, a two or that's the technical term in the US employee.

**Ellie Rofe | 43:03**
Yeah.

**Ray | 43:06**
The yeah, the it basically is the same kind of dynamic, right? You have a boss telling you what to do, you go do it.
And then that's, you know, you are patted on the head for it, right?

**Ellie Rofe | 43:14**
Yeah.

**Ray | 43:14**
Usually not paid for. Well, but that's a cycle of.

**Ellie Rofe | 43:17**
A pipeline producer or pipeline respondent? Y.

**Ray | 43:21**
So what I find is there are two habits that... There are habits you're not doing when you're in that mode, right? The first habit you're not doing when you're in that mode is you're not selling, right? Or you're not talking to people outside the market.
I actually think if you can just go the whole... Would it be worth it for me to go talk to my mom about it? Yeah, sure. Because I'll keep you in the habit of just talking about it. Now that's not the right person to talk to. It doesn't solve the problem, but it starts the wheel turning.
Like, what is the next thing for you to do? You've already talked to your MoM. You don't go talk to your MoM again. You go find someone else to go talk to. Right. That's how you keep expanding the circle.
And my general take is that live conversations are the fastest way to build no, like trust. And that often like the way you sort of take those, you know, one degree removed people and be able to turn them from people who just kind of heard of you to people who like you to people who do business with you, right?
That's sort of the often the best way to be growing that course circle.

**Ellie Rofe | 44:23**
Yeah.

**Ray | 44:23**
The second and that I talk about is writing. And like, writing is key to be making to get growth in these things, right? And, you know, like.
I mean, for. For me, like, I consider myself, you know, an okay writer. And I but I get into my slumps. And when I get into my slumps, the way I get back out of the slump is by stopping writing for others.
And will write just for me and the way I do that as morning pages.

**Ellie Rofe | 44:52**
Yeah. Yeah.

**Ray | 44:52**
So the. So going back to that, just get back into the habit of writing and the reason I describe these two habits, right? One of writing and one of talking to people is because these are habits are easy to fall out of, right?

**Ellie Rofe | 45:06**
Yes.

**Ray | 45:07**
And so the so when I the you need to come up with your audience and who people you're going to talk to. Yes, absolutely. But I would say even before you know, even before you have the plan of who you're going to talk to, saying that like I can make progress just by talking to people because that's building the habit is actually pretty valuable.
And something that I think most people don't do. And they will use any excuse they can to avoid writing or to avoid talking to people. You don't know your audience yet is super convenient as giving them that excuse.

**Ellie Rofe | 45:40**
Yeah, okay, that's a really good point, and I completely take it on board. I think it's the intent that is really important though. So when I just finished this deck with a-aid, and she's really tense about it,
I said, "She is struggling to not be a scientist when she's presenting, so she's struggling not to use terms that are confusing or whatever." I said to her, "You might be better for the first ten people.

**Ray | 46:04**
Two.

**Ellie Rofe | 46:10**
You try and connect with the people that you think are the wrong fit so you can just practice this thing in low stakes because bear in mind there's not that much out there when they're funding at the moment.

**Ray | 46:16**
Okay.

**Ellie Rofe | 46:23**
So doing your worst version of a pitch to people who might be your best version, best opportunity for funding, maybe I didn't say it like this to her, but I'm thinking maybe that's maybe you do a few reps before you try and do that.
But the key thing is, if this is not your target market, then you take their feedback with an absolute pinch of salt.

**Ray | 46:48**
Absolutely yes, habits are not the same as feedback.

**Ellie Rofe | 46:52**
Yeah. I think this is the thing that I noticed a little bit with Robert when I spoke to as-ago, and he'd been talking about I've been talking to the market.

**Ray | 46:58**
Two.

**Ellie Rofe | 47:01**
I've been talking to the market. And partly because, you know, like me, he's got a little bit of squirrel syndrome. He every time anyone said something, he's like, "Who? And it's so easy to be drifted around by talking to the market if it's too inchoate.
If you're saying, "I am basically practicing talking to the market," and you will judiciously decide, like Sherlock, you are looking for clues, but you are not being defined by these conversations. My direction is not being defined, or I have a process whereby I take all these conversations I've had with the market and then feed them into an AI that I've primed at the end of the week and work out what I can take from them and what I should discard.
I think that's actually the way of framing it because that's what I worry about with some sometimes when people don't know and they're just battered around.

**Ray | 47:59**
Well I think there's a difference. The first, I think you can talk to entirely the right market and get incooit responses. The talking to the right people is not a substitute for being judicious and, you know, integrating, you know, their feedback into your own thinking.
If I talking to bad people could be a really useful way to be getting some practice on that part as well. Those are one things actually makes the mastermind and like the coaching sessions little more helpful because like he's yeah, that yes, definitely scroll syndromem like okay, why does that matter? Why is that important?
Like, tell me the story. Like. Well, it's what he wanted. Like. Okay, why does he want it? What's the story behind that? And like, you know, helping him work through that, because otherwise, you know, I think one of his gifts is that he is easy to talk to, right?
And he listens and he's enthusiastic and taking all this stuff in. He's willing to be malleable about it, but making sure that there's, you know, bones that are sitting underneath it to become important and sort of, you know, be what one can be helpful to help him rediscover his own bones, just as you can be doing with Demetrius. The trick is people look at that and say, "Well, if I'm going to go get a bunch of wrong feedback, I don't want to have that until I get myself straight again." It becomes an excuse not to go talk to people.
Now you have this push and pull, right? How do you get them out into the market and not be crazy? Overinfluenced. My position is, whenever you get them out into the market, they're going to be overinfluenced. What you can do is moderate that.
So they're not crazy, overinfluenced, you're just trying to reduce the amount of variation that's sitting in there, right? But if they're talking to the market, of course, you'll be a little more influenced by the market.
When they're not talking to the market, they're going to be underinfluenced by the market. My friends over at Xano are way underinfluenced by the market. They're only talking to themselves, and that's a big problem, partially.
They're doing it partially because whenever they talk to the market, it's saying that's not what we want, and they're like, "But this is what we want to build." So we're going to go build that. We'll see how that works out for them, right?
Because they are confident they are right about this, I don't know if they are, but this push and pull of how to get them out into the market and yet not be crazy, overinfluenced, and I emphasize the "crazy" part because I think them being overinfluenced is just a side effect of being out in the market.

**Ellie Rofe | 50:25**
Yeah.

**Ray | 50:27**
But a gift that we can give them, helping them remind that they have ideas, and those ideas have merit too. What you're trying to do is integrate those with the market, weighted right by the believability of the people you're talking to.
So when you go talk to your parent, to use your previous example, you may have waited a whole lot less, right?

**Ellie Rofe | 50:48**
Yes, that's what I mean is the waiting.

**Ray | 50:48**
That's a quote. That's a MoM testing.

**Ellie Rofe | 50:51**
Yeah.

**Ray | 50:51**
Yeah.

**Ellie Rofe | 50:51**
Is. it? The WA... Yeah, it is.

**Ray | 50:52**
But the practice of going... Having talked about it... Can be pretty darn valuable.
Getting a bunch of people to say no is your pathway to getting someone to say yes because not... Because it's not just about persistence, but it's because of learning, and I think that part is fine as well.
Anyway, I bring that up because the idea... Who should you be talking to? What are these ideas and what have you? I talked to Mitch about this, and I swear to God, the guy doesn't ship because he keeps on being stuck on... What's the perfect answer to Right.

**Ellie Rofe | 51:29**
It is an absolute. It is a godsend for procrastinators. Ask me how I know. If I told you how many domain names I've bought for ideas and things because I've found this new thing...
Then I'm like, maybe not because of this, that and the other... It's yes, I absolutely think you're right. Emphasize action over thought. Absolutely.

**Ray | 51:55**
Well. we emphasize action, and then we get thought from the action. Go have those conversations, let's talk. That's what I tried to do in these calls too, right? What have you done in the market? Cool. Tell me about it. I'm interested in hearing about it. It gets you to talk about what you're hearing in the market, what you think about that, and that's all getting the gears turning, which is what I wish for you. That combination of action and thought, and the.

**Ellie Rofe | 52:20**
Yeah. Yeah. Not just action and no thought, that would be crazym.

**Ray | 52:26**
But yeah, that would be the kind of thing. And I think when you're talking to meters, or for that matter, talking to these others, right, you're figuring out, okay, where do they need action and where do they need thought and where do we need to apply first aid and where do we need to do cures?

**Ellie Rofe | 52:43**
Yeah, okay, [Laughter] we did.

**Ray | 52:44**
And not all of that, and we do both, right, by applying first aid. You can stop the bleeding today potentially with them bear cash position in the relatively near future, but you're building equity value by working on the cure.
All right? I think we did a good job managing the ramp to get to the end of the hour. All right. Let me know if there's anybody I can be of assistance to you this week. I appreciate we didn't really talk much about the Pitch Observatory part. Did my serve stuff from this week make sense?

**Ellie Rofe | 53:23**
Incredibly. Yeah, it's, that is ticking along nicely.

**Ray | 53:28**
Excellent. Looking forward to seeing more of it.

**Ellie Rofe | 53:28**
Yeah, okay, perfect.

**Ray | 53:30**
And if there's any way for me to serve you in the week between now and next Tuesday, just give me a bus.

**Ellie Rofe | 53:36**
Thanks, Ray. Have a lovely weekend night.

**Ray | 53:38**
You too. Bye. Bye.

