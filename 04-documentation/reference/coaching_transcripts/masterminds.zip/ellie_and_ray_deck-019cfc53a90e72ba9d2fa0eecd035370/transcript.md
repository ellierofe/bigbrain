# Ellie  and Ray Deck - Mar, 17

# Transcript
**Ellie Rofe | 00:05**
Hello.

**Speaker 2 | 00:07**
Hello. How are you doing?

**Ellie Rofe | 00:08**
I do very well, and I apologize for all the messing around in this meeting, which was not very helpful at all. I'm sorry. I didn't manage to keep everything together until I was then in the sphere of my mom and my brother, at which point all my containment tactics go completely out the window.

**Speaker 2 | 00:18**
No.

**Ellie Rofe | 00:30**
So I'm trying to get better at not letting that happen.

**Speaker 2 | 00:35**
The, I hope the trip went well.

**Ellie Rofe | 00:40**
Yeah, that was lovely.

**Speaker 2 | 00:41**
I don't mean to be far off, but you got to meet up with your oncology. Quiet.

**Ellie Rofe | 00:48**
Not a meeting with him next time I go back, yeah?

**Speaker 2 | 00:51**
Okay, I see. I see. You just had a correspondence that was about the accelerator thing.

**Ellie Rofe | 00:56**
Yeah. So, no, I met with a few members of the SDP or part of the wider world of it and Paul in person last week, which was great at UB the UBS contact.
So yeah, good.

**Speaker 2 | 01:14**
Okay, well, that's all that's gone. I mean, I appreciate the report. I guess that my question is, how can I be of maximum service to you today?

**Ellie Rofe | 01:23**
I think the pool one was really interesting, and I would love your thoughts on it. So he was very warm. I think he is in an interesting position at NBS in which he has a lot of responsibility. He's head of global markets products.
I think it's difficult because they have like so many different variations on a title. So he coordinates the global response at UBS, for example, to what research or commentary they're putting out around the Iran war, for example, as one part of it, but thematic research, and the general product base as a whole.
Then he works on events. So he has... I think it's one of those roles where you end up with your finger in a lot of pies. It's slightly lonely. You have to be a bit antagonistic to people. As far as I can gather, he has...
It's... He's not... He's got a department. So he doesn't really have his own cost code, for example, the most salient detail for me, obviously.

**Speaker 2 | 02:43**
Two, he doesn't have a budget, is what you're saying.

**Ellie Rofe | 02:48**
Yeah, I suspect not his own personal one. I think he's involved with everyone else's budgets in various ways.

**Speaker 2 | 02:54**
She's kind of a minister with that portfolio type thing.

**Ellie Rofe | 02:57**
Yeah, I think it's that kind of thing. Nice analogy, so it's an interesting one. I think he's really desperate for me to work with him on this conference. He talked more candidly in person about it. He said he was at UBS before, helped set this conference up in 2020, I guess it would be 2022, and no, sorry, 2020.

**Speaker 2 | 03:22**
Two. So twenty years ago? Not three years ago.

**Ellie Rofe | 03:30**
Yes, sorry, he was a.
So it's coming up to its 25th anniversary. Well, the thematics are at least. And then, went away work to exon. We did very big conferences, kind of like showy, yes, but like really deep thematic stuff and very interesting, provocative talks and things going on and stuff like that.

**Speaker 2 | 03:53**
Hey.

**Ellie Rofe | 03:55**
Then he came back to UBS. It was effectively unchanged from when he left, and he said, "This is not okay. Things have moved on. It's functional, but it's not right." He started revamping it, moved it to a new venue,
and started to rebuild the idea behind the program and the way it runs. It's been very successful, the revamp, but it's incomplete. And even the way he's talking to me, I said, "All right, so what's the theme or focus for this year?"
And he was like, "AI." I was like, "Okay, what does that even mean?"

**Speaker 2 | 04:38**
Yes. Yep, of course, it's AI, yeah.

**Ellie Rofe | 04:40**
Yeah, exactly. It's like saying the Internet. It's like, "Okay, good, what does that actually mean?" So he has some reach.
I mean, he's in touch with Mr. Suleiman. My brain's just gone.

**Speaker 2 | 05:01**
Mustafa Suleiman. Yeah, the co-founder of DeepMind, right?

**Ellie Rofe | 05:05**
Yes, yeah, thank you. Guy Debs is coming to do a live 20-minute BC he's had. The rest is politics there. Both the UK and US versions are doing a live podcast there or whatever, and Gordon Brown and people like that. There's some reach. He's had Andy Murray come in and talk about the craft of sport and how that crosses over into other things.
Anyway. He was like, "I'm not sure I'm going to be able to get you in for this. I'm really trying, but I'm not sure. Can you come and meet the global head of events?" But I'm not sure we're going to be able to get you in for this year. What I'd love for you to do is come along this year, analyze it, and tell us what we could do better, and then that way I can get you in for next year.
That's in November. I'm like, "It's just Willy. It's noisy." Yes, obviously, I think meeting this global head of events. But something popped into my brain, and I was like, "Why don't I just suggest to him?"
Because he is, I think, struggling a little bit with thinking up really genuinely differentiating speakers or events rather than just trotting people through some of the same minds who've been coming up with the slightly stale orthodoxy which is currently crumbling.
It's like you've got Alastair Campbell and Theresa May talking about stuff. You're not getting people who are possibly shaping the new world. They're the ones clinging on to it. Obviously, most of a Suiliman is interesting. I'm not denying that.
Anyway, I just wondered whether there's a part of me that says, "Why don't I just say to him, let me run an innovations thread there, let me find people who are doing the cutting-edge stuff in things that are meaningfully shaping the future?"
We do an innovations hall or I do an innovations seam running through the program, and I help convene it. That gives me some prestige as the convener of that. But I'm not being paid to consult on the wider project.

**Speaker 2 | 07:23**
We'd be paid to do this track.

**Ellie Rofe | 07:27**
Potentially.

**Speaker 2 | 07:28**
Yeah, well, I mean, I think you're professional.

**Ellie Rofe | 07:28**
Potentially.

**Speaker 2 | 07:31**
I mean, I think it becomes like a value added thing. You're going to run on the tracks of the conference and like that. This sounds like the track that he might actually be the most excited about because this is the one that's, you know, like you say, it's like the rest of it is sort of he's. He's got to put this stuff together.
But this is going to be where they get to do, you know, thought leadership stuff. This is where you get like Roy End or whoever else.

**Ellie Rofe | 07:50**
How should it be?

**Speaker 2 | 07:52**
Yeah, no.

**Ellie Rofe | 07:53**
Yeah, exactly. The whole conference should be thought leadership stuff, not just BL bleur whatever. So which is kind of I think he's trying to push it into that space, but it's just slightly, it's slightly wooly because he's got such because he works in, you know, large corporate finance, not corporate finance, sorry, investment banking. There is a sort of sense of him pushing at the edges, but him pushing at the edges is still, like, not exactly wildly innovative. There's some good ideas, don't get me wrong.
So I didn't know whether that was a good pitch or whether I just wait until I meet with this woman and see what she says or how it might work. I know he wants to work with me. I know that he will do whatever he can internally to make it happen.
I just wondered if having a specific thing rather than "Can she come in and just give us some ideas?" or "It's just we pay her a specific amount to run this specific thread through the conference." Then I bring that startup energy, the knowledge part of my money knowledge power piece to bear, and it gives me some kudos and it gives me access to people who might not be interested in talking to me if I wasn't just bringing them in front of potential backers, buyers, CVCS, whatever. It might be the...

**Speaker 2 | 09:27**
You get a business card and, you know, get to go talk to, like, okay, who's exciting and ideally, probably who's exciting on your side of the pond, right? In the world of, you know, of.
Yeah, like say of innovation. AI I can see how that creates a lot of wins. I can see how this becomes the thing they kind of do a little bit more skunk works, a little more underfunded. And this is why bringing you in.
And you're going to be understaffed, but you're put together the things that could be delivering the most memorable lines to conference. I mean you. Then you're going to be given an undersized bat and expect to hit it out of the park.
But like, you can take that responsibility. I think it's a hell of an opportunity.

**Ellie Rofe | 10:11**
That's why I was wondering if I just created an opportunity out of it rather than wait till November to turn up as a static observer and then just go, "All right, let's see what we can do next year."

**Speaker 2 | 10:24**
Right? I think it's a you know, who are the what's next, right? Who's your thirty under thirty, right that you're going for this and the.

**Ellie Rofe | 10:32**
One.

**Speaker 2 | 10:35**
That becomes your brief to go get the speakers. You're going to be pitching the UBS name, which means you get... If you're making calls saying you're calling with UBS, you're doing work for UBS, which proves credibility like that. I can see lots of good stuff in here. I can see why it's good for you, right? They're not dummies.
I'll see why it's good for you, too. The question is, does this solve a big problem for them?

**Ellie Rofe | 10:58**
M.

**Speaker 2 | 10:58**
Right? Because if it does, you're offering the, you know, cheap and easy way to get it, you know, done. And you sort of need to make a proposal that probably for them is like, this is cheap.
And for you, it's like. Yeah, and the but and I think there there's like there's plenty of room in between there if you have the compelling offer. But you're right. Now, assuming they don't have something like that.

**Ellie Rofe | 11:24**
They don't.

**Speaker 2 | 11:24**
Do you know what they look like? Okay.

**Ellie Rofe | 11:26**
Yeah. So Paul is doing this on his own basically at the moment. He's trying to define design, the shape of the conference, and the speakers. He's in between lots of other things, and he's doing it from an institutional point of view, where their analysis is fragmented, interestingly, because they obviously have SOAP. It's 150,000 people at UBS, and it's global.
So they have an interesting tension in that they have to be very careful what they say. The Iran war has been an incredibly interesting sort of walking on eggshells thing for them, for example, but this conference, because it's specific and in London, not broadcast globally, has an opportunity to be a little bit more opinionated than cautious.
I think Paul has lots of ideas, but his ideas, as he did acknowledge to me, are somewhat mainstream. So he's like, twenty minute VC the rest is politics. Maybe we do. The rest is history this year.
And it's like, okay, but these are great, but you're not getting you're not looking at people who are breaking through because you're looking at podcasts that really were big five years ago or became big five years ago, not that they're not big now.
And there's a certain sometimes I mean the rest is history is obviously a historical thing. But some of the more business or political podcast that are coming through that aren't that weren't shaped entirely in the sort of precursor to I guess the inciting incident of Trump 2.0 and the shift and the fragmentation of the US European relationship and that kind of thing.
And what that means US. China, et cetera. As well as the coming of AI and physical AI and ramping and defense and all that kind of thing.

**Speaker 2 | 13:38**
Yeah, and you got deep mind down the street like say you're already and you're talking to SLA Manola who's's no longer at AI he went to work for meta, right?

**Ellie Rofe | 13:46**
Yeah.

**Speaker 2 | 13:47**
The you so deep mind just right there. You've got folks Mistrel on your side of the on your side of the channel. Actually, you know, the fact that they've got this podcast is kind of interesting too, because it gives you the opportunity to go, you know the license to go reach out to people like Stebbings and say, hey, who's more edgy, right? That these folks should be talking to.
And then, hey, you get to go talk to them, which is pretty good as well. And you know, and Simmings is an investor, right? So like him making more of those connections only makes him look good. So like there's a whole to, you know, get all those you know investor podcaster types to be in play.

**Ellie Rofe | 14:28**
No.

**Speaker 2 | 14:28**
Good VC industry is not exactly RIP Ron in the UK at least compared to the US there are certain legal reasons for that, but I mean Stebbings plays... I think he's not an institutional money manager, right? He's basically an angel investor who's a video.
Yeah, so like, you know, I guess who else might sort of be in that category who, you know, who lives there. Graham.

**Ellie Rofe | 14:55**
Graham.

**Speaker 2 | 14:56**
Paul Graham.

**Ellie Rofe | 14:59**
Sorry, yes, that is the age-old Graham versus Graham pronunciation. He does, doesn't he? Yes. I saw him moaning about how horrific it had been. It had been raining and no sunshine for forty days. Why was he there?

**Speaker 2 | 15:13**
Yeah, and you know, I'm and him and what his wife Livingston. Right, you know, the, there anyway, there are lots of opportunities, you know, to be able to make something there.

**Ellie Rofe | 15:18**
M he.

**Speaker 2 | 15:25**
I can see you being there making that pitch. I think what you want to make sure of is this is what your sponsor is really excited about. This is what's the one thing we can do here that would make this super special for you.
Because, like you say, since he doesn't have the money for it, you're going to be looking for him to be spending his political capital on it, right?

**Ellie Rofe | 15:42**
Yes.

**Speaker 2 | 15:42**
And we're going to do that not for you, but for, you know, the thing that is his, you know, passion project in there.

**Ellie Rofe | 15:51**
Yeah.

**Speaker 2 | 15:52**
And it gets through we of traditions.

**Ellie Rofe | 15:55**
So this is his passion project. He's talked occasionally about spinning out something and no longer working institutionally, and when he does, he talks about running an events company that creates this kind of signature. Actually not an events company at a specific conference. A bit like TED, but whatever.
So I think this is a passion project for him. I think he's a bit lonely. And I think he is very smart about the wider movements, but sometimes a little bit naive about who may or may not be available.
Like where there are really interesting voices who will have something sharp to say versus people who are saying stuff that everyone else is saying.

**Speaker 2 | 16:50**
Okay, cool. What else? Okay, so you know that that's coming along you're... It is about doing the legwork with your coach. Basically, this has made me think of strategic selling from the late 1990s, which I don't know if you ever read that book. It's actually a really good book for thinking about selling to large institutions, and most of what sales aren't to large institutions.

**Ellie Rofe | 17:08**
Okay.

**Speaker 2 | 17:16**
But this could be useful for thinking about UBS, and they had this matrix that said they were four constituencies in a large organization that you need to sell into. He called them the coach, the user buyer, the technical buyer, and the economic buyer.
The idea is that the coach is usually one who's getting you in, right? They're giving you inside dope on what's going on. They like you. They want you to succeed, but they don't really have money, and it's not going to be totally their thing.
That sounds a little bit like that might be this guy. Paul, the user buyer, is the person who wants whatever it is that you're selling.

**Ellie Rofe | 17:52**
Yep.

**Speaker 2 | 17:59**
They would profit from it, they get benefit from it. They're like, "Yeah, we want to make this thing happen."
Usually, that's the oftenest person you're spending most time selling to when you're actually trying to make a transaction happen. The technical buyer. I thought it was interesting to call them technical.
But basically, a technical buyer is one whose job is to say no, right? So often, it's their role, right? Like they're the risk management or whatever. That's what that they were talking about sales for.
But I think that's true here. You're trying to find out who that technical buyer is whose job is to be saying, no, we shouldn't be doing a no, we shouldn't be having this sort of weird thing in the conference, you know?

**Ellie Rofe | 18:32**
No.

**Speaker 2 | 18:33**
Because understanding their objections, you're not going to stop them because they're going to have those objections. They will be the devil on the shoulder all the way through.

**Ellie Rofe | 18:40**
1.

**Speaker 2 | 18:41**
But what you want to do is be able to be armed with... Why this is a manageable thing, right?
I'm concerned about X. Well, it doesn't seem like X can be that big a thing. Wow, no, it's squared to zero. Yes, but now what you're doing is elevating the one and diminishing the other that you know, and that then takes you back to the economic buyer, the one who's usually making a decision based on the input from the user buyer and the other.
I think in small sales, you're often talking to the economic buyer, who happens to be the user buyer and who doesn't have enough discipline to have a tech buyer.

**Ellie Rofe | 19:15**
Yp.

**Speaker 2 | 19:20**
And that's the reason why small sales can move faster, right?
But part of the reason you want the coach is so that you can understand who's who in the organization. And then once you do that, you can come out better with. You know, they sort of talk about the win framework, which, you know, win which in their cases, they win for the institution as well as win individually for these various decision makers.
So they can all come out and saying, hey, we're we are ahead of where we were as a result of having done this transaction. Then it's much more likely that the deal's going to go through. Of course, we want to do it in a way that this could be good for you too.
But that idea is personal as well as institutional.

**Ellie Rofe | 19:53**
Yes.

**Speaker 2 | 19:56**
And I bring up the multiple constituencies. And the most reason I was talking about the Paul thing is sort to figure out like which kind he is the.

**Ellie Rofe | 20:03**
Yeah.

**Speaker 2 | 20:05**
Yeah, and the more we can shortcut some of these things... Often, executives have a bit of a slush fund for their top three things. You can make something happen.
Then the goal is to become one of those top three things. But it sounds like if he doesn't have any budget to work with, then that's not really the play. There's nothing that turns him into the economic buyer. He's the coach, and I need to figure out who the other players are on the field.

**Ellie Rofe | 20:29**
Yeah, I mean, I need to check. Maybe he does have some budget, and I would need to check. I mean, the thing is, this is a 5 million pounds conference across three days, so that's significantly more budget than we used to have on the an stuff.
So there should be discretion available here. And whether it's him that owns that budget or someone else, there should be some room to free up 15, right of 5 million. You know, like it's it shouldn't be MAS. It shouldn't be impossible to do that for something that could have an outsized impact.

**Speaker 2 | 21:17**
Right. Although I would flip that around a little bit, say that if there's... Okay, there's a 5 billion-dollar budget, and so there's somebody who's going to have some discretion in there.

**Ellie Rofe | 21:22**
S.

**Speaker 2 | 21:25**
You want to find out who that person is.
It's not your guy, right? And you want to find out what that person cares about because that's going to help you craft the offer right there.

**Ellie Rofe | 21:34**
Yeah,
what I'm trying to work out is Paul does... Paul must have some discretion on this budget because he helps run it.
So he must have some input into where that money goes. But I think that the person who is the economical buyer is the head of global events, who will be the person who owns the budget entirely. Actually, this is really... I hadn't consciously thought of this, but this is what I used to say to people about internal repitch, whether it's VCS or whether you're selling into a corporate, making it really easy for people to sell you on is incredibly important so that Paul isn't having to expend political capital. He's just sharing a very well packaged message that is designed for the people that need to hear it.
So, yes, I really like this breakdown because I didn't break it down into that sort of granularity in my head, but that makes a lot of sense.

**Speaker 2 | 22:37**
Cool, I hope it's yeah, I'm root for you on that. Yeah, the, it's about getting, you know, who's who has what value right and cool. All right, so that meeting is when or is there a meeting even next or what's the next step for that?
Like, where where's how's where do you.

**Ellie Rofe | 22:56**
Well, I think the next step is for me to text Paul and say, "I've got a proposal for you. I've been thinking about it. Can we discuss it?" I think he just needs an informal chat first, and it'll probably be at a weekend where he's running around with his daughter to football or something, and it will just be a bit like that initially, but then the next step is to get the meeting in the books for when I'm back in Easter.

**Speaker 2 | 23:21**
Okay, which is just a couple of weeks away, so yeah.

**Ellie Rofe | 23:24**
Yeah, exactly. So try and get a meeting with that head of global. Huge M flip events.

**Speaker 2 | 23:33**
Yeah, that's great.

**Ellie Rofe | 23:35**
Yes.

**Speaker 2 | 23:36**
So you'll be syncing up with AJ. You'll be syncing up with other guys or whoever these folks are at EBS, that's all to the good. Now there are a couple of threads out there, like if we were to scroll down into the middle of last year of other folks, particularly on the UK side that you've been... You had been chatting with.
Are those threads all dead at this point? Or have you done any scrollback or just looking at your own accountabilities to see where some of these are things you would have highlighted as being significant conversations and where they went or if there's a reboot for them?

**Ellie Rofe | 24:14**
So I think there are two outstanding things, three, actually, that I need to follow up on. One is an AI at Stratasal who I did that very cheap work for because she was at the Crick. To see whether she's raised or not.
I mean, I haven't heard from her. I haven't seen any announcements. But obviously, I need to follow up. Then, Emma Palmer Foster, who in terms of cash flow, could be useful because she just wanted to send me decks.
So I think I just need to slightly tweak the portfolio I made for Paul reshuffle things because that was events-based, but because I spent so long on that, ridiculously long on that. I have got a lot of the assets now in place, so I can just say, "Here's all the design work I do on Dex."
By the way, if you need narrative and strategic work, I can do that too. But she was like, "I just need someone to design things sometimes." That could be a nice source of cash flow work that just keeps things topped up and maybe occasionally turns into something more.
So Emma and then the other one which started and then just completely faded. I realized the other day because I set up an open chat to go through certain folders in my... Because I file things away after your prompting. I file things into clients or prospects, potential partners. What's written there to go through and just sift through it and see what I need to follow up on or not. The other one was the Biotech Industry Association, who I was talking to about doing a VC survey many months ago, and they were going to introduce me, and then we just drifted apart.
I think I followed up and didn't hear back from them, and then didn't follow up on the follow-up, and it just disappeared from my view for a while, so I probably should just check in with them as well.

**Speaker 2 | 26:27**
Okay, cool.

**Ellie Rofe | 26:29**
And then I need to just follow up with Maddie. Just to check in. Because it's definitely time for that check in now to see how she's going on.

**Speaker 2 | 26:36**
Yes, Maddie is a material science person, right?

**Ellie Rofe | 26:39**
Yes.

**Speaker 2 | 26:41**
Okay, well, I'm glad you're lighting up those whole things. You can be shocked at how simple a reconnect can be.

**Ellie Rofe | 26:50**
Yeah, I do feel like things are gradually starting to bubble up. There's it's. I don't know if it was you or someone else who said, like, when you're planting seeds, it can feel like nothing's really growing.
And then over time, you start to suddenly see some shoots coming through and people connecting and going, when I got that email from the Crick, it was like, yeah, okay, that's nice. I mean, I know they just need to fill seats. I'm not like delusional on a panel, but it's great. No.
It's very useful to me to. To be someone on one of those panels for my own, you know, social proof, as it were. Prestige.

**Speaker 2 | 27:36**
Yeah, and, yeah, so I'm it's good to get you out there. Good to have you know, able to position yourself and having these, validators, right, who say that you're a serious person in these, you know, in these fields.

**Ellie Rofe | 27:50**
Yes.

**Speaker 2 | 27:50**
So. Okay, well, I mean, that's coming along. And then, like you say, you sort you're looking to get your top of funnel going. Got to say, this UBS thing has a great opportunity to create top of funnel for you.

**Ellie Rofe | 28:06**
Yeah, I was thinking that too. Just huge amounts of opportunities to talk about, the shape of it, what's happening, what I'm doing, depending on what they would allow to be talked about publicly. Obviously, the very risk-averse.

**Speaker 2 | 28:19**
Well, I mean the fact that you can go call up all of these, you know, startup type companies, you know, saying that you're doing.

**Ellie Rofe | 28:24**
Yeah.

**Speaker 2 | 28:26**
So with UBS, that gets their attention.
And like that's what you that's top of funnel is like how do you get their attention for the first time?

**Ellie Rofe | 28:33**
Yes.

**Speaker 2 | 28:34**
And like you can be doing that for UBS and helping UBS, but then it's prospecting for you.
And I think that's a that that's how you move a lot faster, right in this industry. And then like the X stuff is really about your thought leadership work, right? That you need to sort of get more. Get more out there.

**Ellie Rofe | 28:54**
Yeah. But even with that, I think the real opportunity there is not just me spouting thoughts, although that's useful.

**Speaker 2 | 28:54**
Okay.

**Ellie Rofe | 29:01**
I think the real opportunity is for me to say to people, "I'm doing research on X. Can I talk to you about it?"
Because again, whilst the initial thing you always say to me... Your money. Ask for advice. Advice. Ask for money. Just saying to people, "Can you lend me your expertise while I'm researching this?" The increase in defense spending or the rapid reassuring project if it isn't happening, etc. Shift in energy conversations to nuclear, these kinds of shapes of things.
If I'm saying I'm researching this, I'm thinking about it, and I'm talking about it. Can I talk to you about it? That is again top-funnel work in a more interesting way.

**Speaker 2 | 29:51**
Okay. Yeah the yes, okay. I mean, that's your thinking in terms of the expert that we sort of need to start the wheel turning it all on it right sort of that's like you say, that's sort of underdone.
But you know, if that space is being consumed with these kinds of conversations, right? They get you things like getting onto panels and talking. Indeed, this is you don't want to let your social media presence go to zero, but it's super high value stuff.
So like that, you know, I like the whole there's too little work here. And then you start to talk about these other things, which is, you know, it's cool. You got the other things going. That's a good measure.
And if I just might say, like the, you know, I look at the two little work thing and I think the point is not to do more work. The point is to keep the wheel turning. And, like, you seem to have successfully gotten the wheel turning this past week, so, I mean, bravo.

**Ellie Rofe | 30:50**
Yes, thank you. I think what I mean is some of that wheel turning is because of work I did six months ago. So if I... And that more open, visible work that I was doing, if I don't keep doing that and it's networking, but some of it is just publishing publicly, then that will stop turning at some point. Even if it's turning right now, I would say.

**Speaker 2 | 31:17**
Okay, cool. And I saw that you picked up Claude Bits. One of my sons is right now going through Claude's magnum opus, an unfinished magnum opus.

**Ellie Rofe | 31:26**
Yes. The unfinished one on war, yes, a fascinating stuff.

**Speaker 2 | 31:32**
Have you not read it before?

**Ellie Rofe | 31:33**
No, never read it before. I think I if I'm. I think, if I'm honest, I had a slightly childlike view about war.
And, the last few years, I, you know, and when I say childlike, it's very admirable on some level.

**Speaker 2 | 31:45**
One.

**Ellie Rofe | 31:55**
It's very ideologically admirable to be just like a peacenick and not want war. But it is effectively something that will happen in that I don't see a point at which humanity, in all its wonder, suddenly decides that no socialath is going to rise to power, or no theocratic lunatic is going to try and bring about the end of the world because of a millennial death cult they believe in.
There are a lot of weird people in this world. That's part of its joy and horror. So it's interesting to me to start learning a bit more on AI. I was listening to various analysts and experts and things. Whether on war explicitly or terrorism or the Middle East, which is obviously the focus of a lot of stuff at the moment.
Then I thought, "Why don't I ask Claude to give me the branch at the trunk, not the branch for this sort of area of things?" It immediately came up with Klauswitz. So it's like, "Here we go. Let's give it a..." Well.

**Speaker 2 | 33:05**
Yes, Claude is much more recently in vogue. I think this is substantially... Actually, it's the American military that picked up Claude.
But it's something like thirty years ago or so, it started becoming very popular to be teaching that in the War school.

**Ellie Rofe | 33:20**
99?

**Speaker 2 | 33:25**
Prior to that, there was another guy named Baron Antoine Henri GenAI, a French-Swiss guy, who was a contemporary of Klauswitz. Outlived Klaus, if I recall. Who was a significant thinker on the strategy? Similarly, from the Napoleonic era, which I bring up partially because now that he's not read, it's like, "Wait."
That's an angle that you know and you know the rag on GenAI as that he's too tactical or too formulaic in the way that he approached strategy as opposed to a more philosophical approach of Claude that causes Claude to transcend time.
But it has the advantage of being a finished book, as opposed to "On War," which has two finished chapters, which are great chapters like you quoted one, and that's in the first chapter, but the...
It is a little... It can get a little hard to penetrate as you get further into it because it reads like notes. Zoho comes to mind.

**Ellie Rofe | 34:35**
Yes.

**Speaker 2 | 34:37**
And who else? MAUs Tong. MAUs Toung's work on guer warfare is excellent for thinking about issues of strategy and particularly like, you know, strengthen and weakness stuff. Have you ever and have you ever read Michael Porter?

**Ellie Rofe | 34:55**
No. It's not ringing a bell.

**Speaker 2 | 34:57**
Okay, Michael Porter is the o of business strategy, and the, you know, the he wrote a book called a Competitive Strategy.

**Ellie Rofe | 35:02**
Okay.

**Speaker 2 | 35:09**
It's a very confusing name. But sort of bringing, you know, ideas of, you know, grand strategy and operational strategy or operational thinking into the business world, which can be.
And it's very useful for being in business, right? And once you've heard the five Forces, you can't you'll never forget them.

**Ellie Rofe | 35:29**
Okay.

**Speaker 2 | 35:31**
Anyway, if you're enjoying Claude's mates and you're like, "Man, this is really heavy sledding at this point." I suppose I'm just giving a few other angles you can take that might be ways to be getting deeper into the world of strategy, that are nicely complementary to, especially once you've gotten past book one, I think book eight, the other finished one, those are quite good, and the unfinished ones have some really good ideas in them.

**Ellie Rofe | 35:41**
Yeah, it's really...

**Speaker 2 | 35:58**
But you might find that the as a bloom comes off the rose, it's okay to put that down and, you know, pick up our stuff. I think it's a great. It's a great area to get really versed in.

**Ellie Rofe | 36:10**
Yeah, it's really interesting to me because obviously, as soon as you start reading about this stuff, you realize it has a far wider potential application or than you know, people killing each other.
And it's just it's just a really.

**Speaker 2 | 36:24**
Yes.

**Ellie Rofe | 36:27**
I mean, that's a very reductive way. But it is just interesting to reframe some of my inherited understandings about what war is and how it works. I think you just reminded me, and I'm going to look it up quickly before I forget.
Maybe it's "Rules for Radicals."

**Speaker 2 | 36:57**
Sure. That's... Yeah, that's... On the business side, a book that does not get read as much nowadays, but is really excellent. It's called "Rules for Revolutionaries."
It's by Guy Kawasaki.

**Ellie Rofe | 37:12**
ALR yes.

**Speaker 2 | 37:13**
So it's a business book. As you might imagine, it's Kawasaki.

**Ellie Rofe | 37:20**
His template was the bane of my life when I was trying to get people to do pitch decks.

**Speaker 2 | 37:26**
You were doing using the 10-20-30 template.

**Ellie Rofe | 37:28**
No, I was never using that because it's a nice idea.

**Speaker 2 | 37:30**
Okay.

**Ellie Rofe | 37:31**
It's like, you know, as a kind of primer for people's brains. I get what he was doing, but people took it really literally, and then I was like, no, it's okay.

**Speaker 2 | 37:41**
Yes, nine, eleven, or fifteen, and you are allowed to vary the size of the font.

**Ellie Rofe | 37:41**
You don't just have to have slides, it's fine.

**Speaker 2 | 37:49**
Yeah, you're allowed not to have it be text and just talk to people.

**Ellie Rofe | 37:51**
Exactly, yeah.

**Speaker 2 | 37:55**
That talking to people is a good thing.
But yeah, the Kawasaki's early work, I think is fantastic if, you know, if you haven't read that much of it. I mean, art at the start, which I think is like 2005 or so, was a good book, but I think a lot of his best stuff was before that.

**Ellie Rofe | 38:15**
Okay, interesting times to it. I'm and I'm trying to vary between listening because I had loads of audible credits still and, reading because I think I'm still trying to do that.
So I bought Quest in book form.

**Speaker 2 | 38:34**
You've. You bought. Have you already read the Priz?

**Ellie Rofe | 38:37**
No. I bought the Prize in book form, and yeah, no, you're right.

**Speaker 2 | 38:41**
The Prize is the following.

**Ellie Rofe | 38:45**
I got the Prize in book form. I got some others like "The Globalization Paradox," "The Road to Somewhere," and some really interesting stuff.
So I'm...

**Speaker 2 | 38:57**
I'd like to put this somewhere. Maybe we can describe a whole of non-fiction books. They're titled "The Road to Somewhere." It starts with "The Road to Serfdom," right?

**Ellie Rofe | 39:07**
Exactly.

**Speaker 2 | 39:10**
And then like all the others are like. Yeah.

**Ellie Rofe | 39:13**
Have you heard the theory? It's a guy called David Goodhart, and it was brilliant. I think it probably explains some of the American dynamics, but it was really specifically about the UK where... Or it was he's based in the UK. Somewheres versus Anywheres. This is where this concept comes from.
So part of the political rupture. People keep trying to frame it as left versus right or poor versus old or whatever. Poor versus rich, old versus young. The most meaningful delineator, because of the age of globalization, is people who are rooted in a sense of place. The Somewheres and people who are citizens of the globe who can... A bit more atomic can live anywhere or atomized and live anywhere and don't feel that same rooted sense of their identity being linked to where they are, where they grew up, etc.
That's where things like Brexit or Trump potentially some of the stuff around immigration and open borders, some of these big shifts and points of contention, that's one of the clearest ideological breakpoints.
It's a fascinating idea.

**Speaker 2 | 40:33**
It's an idea that has a deep root that has a... It's a deep foundation of anti-Semitism perception that people of Jewish descent aren't from here, right?

**Ellie Rofe | 40:44**
Interest y.

**Speaker 2 | 40:50**
They could be from anywhere because they're Jewish anywhere. They are and therefore they're not of here.

**Ellie Rofe | 40:58**
Yeah.

**Speaker 2 | 40:58**
And that is, it seemed like it's a bigger deal in Europe in general than in the US has become a little bit more blood and soily in ways that are very disturbing to me. But the. But like what you're describing. The classic words cosmopolitans.
Right? And the and cosmopolitans are people who could, you know, benefit anywhere. They're citizens of the world, not really citizens of here. Not here. And, you know, hard Scrabble, you know, mining town that's, you know, saw us last general store get closed.
And as opposed to, you know, those people who are. There's actually a song that got pretty popular in the USA little while ago called the Rich Men North of Richmond.

**Ellie Rofe | 41:41**
All right, okay, we'll have a look.

**Speaker 2 | 41:45**
Which basically Richmond, Virginia...
What's just north of Richmond, Virginia? Is Washington, D.C.

**Ellie Rofe | 41:50**
Yeah, interesting. Well, what's interesting about his view is it actually explains things aren't just about wealth, because there are very wealthy Brits who are not anywheres.

**Speaker 2 | 42:05**
No.

**Ellie Rofe | 42:06**
They are not rootless cosmopolitans. They're deeply rooted to their locale where they grew up or whatever it might be.

**Speaker 2 | 42:13**
Yeah.

**Ellie Rofe | 42:15**
Yes, it's really interesting because what you get now, obviously, in the worst horrors of the war, the Jews didn't belong to Europe. And what you're getting now is the Jews don't belong to Israel. You're Polish. Why are you in Israel?
Suddenly there's this... Especially against Ashkenazi Jews, this sense of you're not from here. How dare you? You'll be going back to Europe. So it's... It's a very free-floating mechanism via which to engage in one of the oldest bigotries that exists. Really?

**Speaker 2 | 42:51**
Yes, it does. Anyway, I bring up the anti-Semitism angle.

**Ellie Rofe | 42:55**
No.

**Speaker 2 | 42:56**
You know, one, because you immediately see the historical connection, but just to, you know, express a little bit of caution in terms of, you know, how this thing gets discussed in mixed company.

**Ellie Rofe | 43:05**
Two.

**Speaker 2 | 43:06**
Because it goes very close to that, you know, topic very fast, and that can be a way I don't want to having this conversation. All right, now, the, but yeah, that's it that's it's super neat and great that you're sort of, you know, looking at some of these things more broadly, there are other great, you know, sort of you know, political science as well as you know, military tech. There's a guy, who whatever, if you find yourself, you know, wanting to, you know, more of a bibliography on that stuff. I'm glad to be, you know, sharing more of what I've.
I've done my reading over the course of the last few years. I think I've already given half a dozen books.

**Ellie Rofe | 43:46**
Yeah, but it is really interesting. I will delve back into it. I did read politics, for example. I did a... Pardon.

**Speaker 2 | 43:55**
I'm sorry right now. Sorry. When you say you read politics, do you mean Aristotle's politics? Or do you mean just to write about politics?

**Ellie Rofe | 44:02**
Yeah, no, I read, I did a, module semester, whatever on, got us a long time ago, but it was either Greek tragedy or Greek drama.
And as and a bit of Roman, but mostly Greek. And as part of that, obviously you read around the entire area of it. So yeah, I did read it, but it's a long time ago, and I would like to tip back into some of those more sort of fundamental or early explorations of this stuff I haven't.

**Speaker 2 | 44:41**
Yeah, well, I was just going to say that the prize is a fantastic book. I think it's a book that a lot of people should be reading given what's going on right now.

**Ellie Rofe | 44:51**
Yes, that's definitely the next one. I started reading on war first because I was going to see Alister, who was building a defense company, and I honestly just thought it was better PR if I pulled out that book and said, "Here's what I'm reading because he's an absolute geek on certain literature and stuff." It was like a sales effort when he's raising money.

**Speaker 2 | 45:17**
And I mean, on more and the way I look at those kinds of books, there are some books that are about stories and some books are about ideas, right?
So reading, you know, Sam Walton's autobiography, reading one of Jurgen's histories, whatever, like, that's the same about history storytelling, right? But the and then some books are like just ideas.
It's a monograph, right? It could be a philosophy monograph, it could be a strategy monograph. It could be like Claude sort of mel to those two things. But like, I think, you know, when you look at the books, like.
Okay, which are you? What are you doing right now? And then it helps you switch it up because I find that the histories are easier, a little breezier to consume.

**Ellie Rofe | 45:55**
Yes.

**Speaker 2 | 45:56**
But they're long. The ideal ones tend to be shorter.
But they ask a lot more of you. These are good ones too.

**Ellie Rofe | 46:07**
Yeah, they do ask a lot more. It did remind me I had to think more. I had to actually properly process the text more as I was reading it because I was like, "There's a density here, which reminded me of my old life reading secondary reading around the English literature versus the English literature itself." On the first read, which you can do at a clip for most of it, and then once you're delving deep into it. Yes, there were. There was. I find it fascinating when you read these people how they structure arguments.
And I wonder whether this was a way of structuring arguments that was more prevalent in the time where he sets off on this big kind of like they do a big long circuit round. And I wonder whether it's a bit more of an ancient rhetorical thing.
But he starts off talking about how war is, so he puts the alternate hypothesis first. Does that make sense? So now what do you to say?

**Speaker 2 | 47:06**
Well, I was. Yeah, I was. I was just going to say that like, you know, Klausvitz was something of, contemporary to Hegel.

**Ellie Rofe | 47:17**
Right.

**Speaker 2 | 47:17**
A lot of the way we think about idea analysis nowadays and stuff that you see from the mid-19th century forward is heavily influenced by Hegel, the Hegelian idea of thesis and antithesis and synthesis, right? Marx, who really redefined political science, is going to be after that point and think what you will about revolutionary ideas.

**Ellie Rofe | 47:17**
Okay.

**Speaker 2 | 47:40**
But like he's sort of made it much more of science. The, he was the that structure made a lot of sense.

**Ellie Rofe | 47:47**
2hh yeah.

**Speaker 2 | 47:49**
I think one of the things that might be making closets a little harder to read in that way is that Clauusvius is more modeled on the Aristotelian idea of forms.
Right? And so like if you read, like the or if you just sort of get like a cracy on, like, the Nica and ethics or something, you know, shortly before reading Claude Bitts. It's actually a lot easier to follow because you start to understand he's talking about ideal forms of things and that has a lot more of that in common.
And like the tool set that like Amy Hegel's big contribution was how to think about ideas and that we would then use repeatedly over the course of the next 150 years.

**Ellie Rofe | 48:25**
9.

**Speaker 2 | 48:30**
But as of this, it's one of the last thinkers that predates that methodology.

**Ellie Rofe | 48:36**
Yeah. I hadn't thought about it in those times.

**Speaker 2 | 48:37**
I think that this is something I did much later.

**Ellie Rofe | 48:40**
Yeah, that makes sense. Yeah, it makes an awful lot of sense because when you look back at, I guess, an awful lot of philosophers like Augustine and things, it's a long time, but it isn't this nice structured format we're used to and we've been spoon-fed.
It's a little bit like watching early films and then seeing how the... Although in a way, we've actually become more literate. So things can be compressed more now than they used to be, but this is almost the alternative.

**Speaker 2 | 49:22**
Yeah, it's a neat thing when reading ideas. But part of the reason I bring up the Higlian thing is that, like, he's very influenced by, like, Kant, right? In terms of, like, Kant works a lot in terms of forms.
That's how he gets to like, you know, categorical compared and all that. But the. And obviously, I can n it out talking about the history of ideas stuff. But by if you keep that kind of thing in mind, then you find yourself fighting with the text less, right?

**Ellie Rofe | 49:51**
M.

**Speaker 2 | 49:52**
I figure...
Okay. What is it? He's setting up this... And then he's going to have a counter. And then he's going to bring these two things but that's not actually what happens. And if you... But for him, it was like the perfectly logical way of doing things.
But in a way that is... If you can anticipate the structure he's using, it becomes a lot easier to read, as opposed to if you're trying to use the structure that was invented contemporaneous to him. Basically, my knowledge that the two men never met.

**Ellie Rofe | 50:17**
Yeah. No, that makes a lot of sense. It's something, weirdly enough, no one ever mentioned to me during my entire degree, and I never noticed. So partly on them, partly on me, but it makes a huge amount of sense.
It is a nice way because I felt myself reading this going, "This is a list." It's a list. I found the form of it actually quite interesting because it is almost a dialectical list, but it's just like him working. It feels like someone's working through their ideas rather than presenting something that has been worked through.

**Speaker 2 | 51:02**
Yeah, it's amazing how much more efficient philosophy or ideas books written after, say, the American Civil War, feel and part of it is, yes, it's closer to modern English, but a good fraction of it is it's a thinking structure that once set became the basis for how we've been doing over the course of the last century and a half.

**Ellie Rofe | 51:28**
Yeah, it's incredible. Okay, that is very helpful. I know that you feel like it's nerding out, but it is really helpful to me.

**Speaker 2 | 51:38**
I'm very glad for that. I'm super glad for all the progress we made this week. This is super cool. Can I ask what's going to be true next week?
That's not true today or true on Friday, I guess when we're at the next meeting.

**Ellie Rofe | 51:48**
Yes, there's some operational stuff. Getting through certain things the SDP and doing some more data analysis.
But I think the key thing that needs to be true is that I have started... I have followed up with these people. I have connected with Paul about the proposal and the meeting, and I have set out on Twitter and started connecting with people on that top-of-funnel sense to start talking with influential people.

**Speaker 2 | 52:26**
Excellent, and can I quickly ask you if you are able to collect from the SDP yet?

**Ellie Rofe | 52:31**
I we got. I got the first payment, yeah.

**Speaker 2 | 52:34**
Excellent. Sorry. When? When? When you and I talked? But end of last month, that was like in that was an open thread.

**Ellie Rofe | 52:42**
Was it okay? Yeah, that's where I thought I'd put it in the... Ship thing at one point, but yes, it's collected.

**Speaker 2 | 52:51**
Okay, super cool. Yeah, I think there was something about, like, having build for it, right? But I want to, you know, to make sure that you were you had your cash money.

**Ellie Rofe | 52:57**
Yeah.

**Speaker 2 | 52:59**
Okay, that's great.

**Ellie Rofe | 52:59**
Yes. I wasn't starting anything until that was in the account.

**Speaker 2 | 53:04**
Okay, I guess we'll... I'll see you again in a few minutes. We'll do the Group Mastermind, then take care... Bye, record.

**Ellie Rofe | 53:08**
Perfect. Chees. Ray. Take care.

