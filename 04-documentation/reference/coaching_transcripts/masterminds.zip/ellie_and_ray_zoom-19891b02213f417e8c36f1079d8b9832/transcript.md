# Ellie and Ray Zoom - Aug, 29

# Transcript
**Ellie Rofe | 00:20**
Literally. Just took the chewiest bite of something. Just... Recording in progress.

**Ray | 00:28**
Str Look, I got time. We'll take this... The screen will come on, and then the bits will take it longer. I just had an experience yesterday.

**Ellie Rofe | 00:34**
[Laughter] Exactly.

**Ray | 00:37**
Yeah, I homeschool my children, and we do hard stuff.
Today was one of the first serious back-to-school days after quite a while, having been on various trips. The thing is, my wife doesn't keep the same kind of school discipline that I do.
So, when they're traveling, it's like we're doing things. We're having lazy mornings and going out, whatever. I'm then home with them, and it's like, "Okay, we're getting up, we're having some breakfast, and now we're getting into this stuff." It's one of the things we're doing. It's business school.
It's introduction to corporate finance.

**Ellie Rofe | 01:09**
Nice.

**Ray | 01:10**
So remind them that this is grad school level work. It is supposed to be hard. We do hard things, and they are very proud of the fact that they do hard things and all that.

**Ellie Rofe | 01:18**
Yeah. That's Incredible.

**Ray | 01:21**
But one of them had the experience. We're okay, we're going to do a little bit more than half the problem set because the back half is harder. His brother took longer than usual. Usually, they cracked these things off in a couple of hours, but his brother took like a few hours. Our airlift gets out, and then my younger son, a younger by 20 minutes, it took him until almost bedtime, and we made sure he had some breaks.

**Ellie Rofe | 01:46**
Wow.

**Ray | 01:51**
We'd go outside, he went to get some barbecue, had meals, whatever.
But it... It was just the whole day. But he stuck with it. I just have to tell you, I am just so proud. But some things do take longer than we expect. That's just how it goes.

**Ellie Rofe | 02:04**
Yeah absolutely. That's incredible. I do love this homeschooling that you do. I had wondered how close they were in age. They're twins, I'm guessing. Yeah, lovely. Because it's just supercharging.
It's not even growth mindset. It feels like they can move beyond growth mindset. It's not even just like, "I cannot attempt difficult things." It's, "I do difficult things for the sake of it." Even...
Like, this is how I engage with the world.

**Ray | 02:33**
Well, right. An important part of growth mindset is one of identity. Not like, "I'm going to do a hard thing," or "I do hard things." I'm a person who does hard things, right? That last one is a statement of identity that I really want them to associate with themselves. They do it and they do it. They're advanced, and they are getting the extrinsic validation of my pride for it.
Hopefully, if this is something that can be internalized within them, then they will... No, stop them where they can go, which I think is true for us all. All right. We need to see that we are... I once heard a line that the definition of getting old is when your memories become more important than your dreams.

**Ellie Rofe | 03:17**
God. God. That is bleak. But yes. [Laughter].

**Ray | 03:23**
And like, you know, I think it. So when I look at like the people who I admire most kind of regardless of age, including some people who are, you know, on in years is definitely people who have who are, you know, mindful of their ambitions, right?
And they are a person who does these things, not a person who they not that they were a person who did these things. Now they're doing something else, right? They've integrated it. Some of the saddest experiences I've seen are people who say, "Well, I'm grinding today so I can have my fun time later."
There's a whole marshal test aspect to that, of deferred gratification, but I find it to be just unsustainable. If you're not... For me, it's like what I love doing today, and I find that when they put "push get show" for people who are talented who even describe themselves as that, they like what they're doing.

**Ellie Rofe | 04:12**
Yeah, I would agree, definitely. You can tell the passion that people have for something; it can get dimmed. I think I was talking with someone this morning who works in biotech, and she loves what she does, but I think when you're working in an ecosystem, it can be very hard. She said that increasingly. I don't know if you found this, she said, "Increasingly, since we worked back as so many things will eventually, when you look back in the historical terms to the pandemic."
She said the amount of people who don't follow through, who don't provide stuff, who don't engage, even CEOs, she works... She's a finance director, so she helps companies prepare for M&A and sort out data rooms and IPO and stuff like that.
She said she's just noticed a shift in people who seem incapable of engaging in the way that people seem to. She thinks it's pre-pandemic, and she doesn't know if it's just a psychological fallout from it, whether people are in some kind of mental shock or whether it's just working from home.
There are certain people who just have not adapted to that in a way that makes them function.

**Ray | 05:32**
No.

**Ellie Rofe | 05:32**
But I felt quite sad because she's so good at what she does and she loves it. But she's working for five different companies at the moment. She said. Only one of them is even close to functional.
It's surprising.

**Ray | 05:46**
It think that the work from home... I think you're right. There's a lot of pandemic. My thinking actually comes from three phenomena. The first is, yes, the work from home thing has spread it out and it means that people have a bit less focus. I didn't think, in theory, that there's going to be a revolution in real estate, post-pandemic.
I saw it really only happen at a pretty small scale. What I thought was that the types of homes people would be looking for would be homes that you could work in.

**Ellie Rofe | 06:14**
Yeah.

**Ray | 06:17**
And like, the idea that "Hey, you have your home office tucked away somewhere" would become the home to be designed with this in mind.

**Ellie Rofe | 06:24**
Y.

**Ray | 06:26**
And fact, we picked this place because this room that I'm in right now is only connected to the rest of the building by one wall.

**Ellie Rofe | 06:32**
Lovely.

**Ray | 06:32**
And wall is mainly to a bathroom on your side.
Except when they're using the bathroom or banging around in the shower, which happens most of the time, I'm actually well insulated from the rest of what's going on, even in our not-so-huge condo.

**Ellie Rofe | 06:39**
Yeah.

**Ray | 06:47**
And it's like, "Okay, this is a good setup. I'm expecting more people to be doing this.

**Ellie Rofe | 06:51**
Yeah.

**Ray | 06:51**
I didn't find a lot of people doing this. I found a lot of people who work from home or people who are working in relatively wealthy suburban communities.
The houses are intended to be, well, bedroom houses, and are a bit more constrained like this. This needs to be intentional for it to work. Maybe with time it gets that way. But I think that's one of the reasons for RTO is that like the in the main, people are most people are not good self managers.

**Ellie Rofe | 07:14**
Yeah. No.

**Ray | 07:21**
And a result of that, they need the structure around them. So, that's where RTO comes in. They can help each other do that. I'm seeing technology companies that have gone very distributed. Some of which have been successful at this, have been successful for years. Many of which did it as a result of the pandemic or reform post-pandemic, not having nearly the success because it's a whole different discipline.

**Ellie Rofe | 07:41**
Yeah.

**Ray | 07:45**
But I've seen the companies that succeed in remote settings are not the innovative companies, but there are companies that are like, "We have our pattern, and now we're going to remote.

**Ellie Rofe | 07:50**
No.

**Ray | 07:55**
I actually did that with one.
I mean, I have good fortune. I had a company that was like, "It had its pattern." In fact, I was trying to extricate myself from it at the beginning of the pandemic. The pandemic allowed me to do that by going more remote and reducing my costs. My employees are happy because they have more freedom and discretion to just do their jobs.
But don't get me wrong, it's not a high-growth enterprise because it diffuses energy.

**Ellie Rofe | 08:22**
Yes, absolutely. I think it's interesting when I've worked in a large corporate. I rent... I wish I could find it. I can't remember what the type was. HBR is so labyrinthine...
In about 2016, one of my bosses at NBC Universal.

**Ray | 08:36**
This is.

**Ellie Rofe | 08:40**
So we're in the international bit, which is only about 3.5,000 employees, so it's still quite big. She I love this. It was one of the most dysfunctional places I've worked anyway.
But she gave us all this HBR article as part of her. She'd come on board, and she was trying to fire us up, and she talked about innovation, and then she gave us this article that basically said that companies filter for getting rid of innovators and they filter for people who will just execute. They don't want people who are constantly upsetting the apple cart.
I think some of those bigger companies, I think some people there had the idea that they had loads of innovators who, when they worked from home, were suddenly going to be really fired up and just have all this time for all this deep work.
Actually, as my mate who works at Deloitte confirms, an awful lot of these people are just trying to get beat out of the line of fire as much as possible in their job. And so if they can be at home being out of the line of fire, that's not a recipe for amazing innovation or productivity.

**Ray | 09:45**
8.

**Ellie Rofe | 09:48**
That's a recipe for people just doing stuff at the basic tickover level because none of them want to be the one that ends up either with the load of work given to them or in the firing line for having tried an initiative that didn't work.

**Ray | 10:00**
M no, I think that there's a lot to that.
I think that the influx of capital in the pandemic allowed a lot more people to get into this game.

**Ellie Rofe | 10:18**
Yes.

**Ray | 10:18**
And so previously it was a little bit more.
So. So not only did you have the in office structures, but you are more selective. Only people who are good at management, who tend to be, you know, as whatever could actually be starting companies. And now, because there's such a rush for capital, "Hey, no, you science person who won some sort of competition. We want you to be running a company."
Well, you're a great scientist, but you're not a great manager. Just like you're helping them right now because they're not great marketers or storytellers. That creates additional challenges, which I think explains that clerical aspect.
Then the final thing is automation and the idea that we don't have assistants anymore. So, the same person you're talking to today might have had an EA, a secretary, or whatever you're going to call them in your particular culture.

**Ellie Rofe | 11:04**
Yeah.

**Ray | 11:05**
And the remote thing makes that less likely to happen. An expectation that is not what we do anymore because it's a little bit of an upstairs-downstairs thing, particularly in the entrepreneurial world.
That puts even more of the burden on the principle to be their own clerk. It's actually one of the reasons I think KY is so amazing because it takes so much of that follow-up. How do we have back-and-forth about scheduling? No, here's a county link. We do that. You want to have a meeting? We can have a meeting. You don't have a meeting. We don't need to have a meeting.
But we're not going to have six conversations and five emails about it.

**Ellie Rofe | 11:40**
Yes, exactly. No, I completely agree. It's funny you mentioned the funding. As Stacy was talking to me, I suddenly realized and I said to her, "I have a feeling we're at the timeline." Now, when I think about all the people I'm working with where they got funding during that boom, the capital booming, the pandemic, and it makes total sense that they think that funding is just like, "I press a button, and money comes out." Because that's what it felt like to them.

**Ray | 11:59**
Three.

**Ellie Rofe | 12:11**
I talk about science, I press a button, money comes out, and I go and do the science.
Now, they're in an environment where they can't just talk about science. They have to be running a business, and a lot of them aren't running a business. They're just doing a very expensive lab spin-out.
That is where they're getting unstuck. They are just... I had a really... It was very positive. I really thank you for your counsel last week because it really helped frame me in terms of going up to it.
Then the call with Emma at the consultant. She really helped. What? I said to her. She knows Max, the guy who introduced me to this company. The guy who wouldn't choose and was trying to spin out a company with Ghos to investors and stuff.
She said, "Well, you need to do some example work that demonstrates what you can do." When I said, "Yeah, Max has invited me to something," she said, "Who is it?" I said, "A Plitech."
She went, "Dear God." [Laughter] I laughed my head off, and she said, "Yeah, crikey." The CEO had pitched to her, and she said, "He had his head in his hands." I thought it was going to cry.
It's not exactly inspiring for me because she runs a little fund. She said, "The problem is Max is too kind. He's a very nice man." Between what you'd said and what she was saying and me thinking, "Yes, I need to try and push this."
I think he's smart enough to see it, but he does seem burnt out. I had a really productive conversation, but I did keep having to say to him, "If you don't make this decision when you go out for funding, investors are not going to see a CEO they're not going to see someone who is taking difficult decisions." They're going to see someone who's hedging and refusing to make a decision, and that is not confidence-building for them.
It felt... It didn't feel good in terms of me berating a man who was on his last legs. Obviously, I was very gentle as much as I could be. I pointed out that he would probably be slightly less knacked if he wasn't trying to run two companies with two different funding structures and two different exit strategies for these different assets.
But it did feel good because I realized that I was pushing into a greater depth of expertise and actual consulting. Actually, maybe at times, preferably, I will just be parceling a story up, but at times maybe I do need to coral and reflect back to people and be honest with them about stuff rather than being a bit more service-minded about things if that makes sense.
So, maybe.

**Ray | 15:22**
It does, well, I mean, you are being service-minded. The thing is, are you being in... Yeah, there's a little bit like being in the moment, yes or no, sir, right? Then there's the... Are you being a valued counselor or a valuable bull counselor? Forget about being valued.
That's up to them, right? But you can only try to create value. So, okay, so you have the conversation, can I ask... Where do you think it landed or what do you think he heard and whatever he said probably doesn't matter. He needs to be thinking about next or what's your read on the situation?

**Ellie Rofe | 16:02**
My read is... He is burnt out and he has been avoiding making difficult decisions. So, over the course of the call, he went from... Yeah, I do need to consider this too by the end.

**Ray | 16:22**
No.

**Ellie Rofe | 16:22**
Yeah, you're right. I can't carry on with both of these things in the same package. I need you to go and speak to some lawyers and I think partly I'm not expecting. I said to him, "I'm going to
take two weeks." You need to let this settle. We've had quite an in-depth conversation about the direction of your company, and you need to go and look at the logistics of what you're going to do next and talk with some lawyers about what it means to spin stuff out.
But, I don't imagine that in two weeks' time we're going to speak, and he's going to be like, "I've got it all sorted." I do think he needed to be given permission to make the decision. I think he's been trying to hedge, and he's been thinking, I think partly, to be honest, I don't think he's great CEO material.
I think he can get funded. I think he's quite persuasive when he's not walking around with his head in his hands, knackered. But I don't think he will last as a CEO into Series B funding. Lots of people don't.
I think he has been avoiding making the decision because he doesn't want to upset people on his team because he can't decide which one of those is more exciting to him because he's evaluating them in terms of science, not in terms of business.
And I think that's what I was trying to say. Well, that's what I did say to him. You can't just think of these things as a scientist. You have to choose which development pathway you're going along to get funding, and you can't magically get funding without having the right sets of data.
If you're splitting your time constantly between two different concerns, and you're splitting your runway between two different concerns, and your feedback that you're getting is that both of these are too early, then you are not hedging, you're just splitting focus.
Actually, your avoidance of risk is creating the largest risk of all, which is that you get nowhere with either of
So.

**Ray | 18:18**
Okay, that was your council. And we're going to see, like you say, you're not going to turn the ship around. What I find is that the best-case scenario is that people take the core of your advice in the worst possible way.

**Ellie Rofe | 18:27**
[Laughter] Yeah, I'm sure.

**Ray | 18:32**
I they get into the right race, they start doing it, but they're getting into the race completely wrong.
Okay. Well, that's just... What I actually had that scenario happen to me just a few months ago. Yeah, okay, there's nothing more to be done with that when they're so off the right track.
The best you can hope for is that the next thing could be a little bit closer. It could be on your side, but a little bit closer. But that they are hopefully closer to Trig North than they were before.

**Ellie Rofe | 18:59**
Yeah.

**Ray | 19:02**
But then, the next thing that's going to move them up may not be what you have to say about it, but anyway, I'm glad you could do that. That either is going to be trust-building or it'll go the other way.
I've had both of those experiences. Then I guess you'll get to find out in the course of the coming couple of weeks. You know what you think, right in terms of that engagement because just because you have a meeting with them, one, doesn't mean it's going to work, but two, it doesn't mean that, like you had thought last week, that the situation might be be.

**Ellie Rofe | 19:28**
Two.

**Ray | 19:32**
Well, I just sort of need to walk from the engagement because they're not, you know, right. And you may. You may still get need to do that. But you'll have done that having given them the best counsel you can.

**Ellie Rofe | 19:44**
Yeah, yes, this is my thinking. It wasn't, like, yes, I can absolutely... Well, much more when I was younger, I can change him. That's not there now in me.
It's more to do with me saying I have given him what I think I can give him rather than just going, "Shut us down, walk away" because I think it was important, especially for my relationship with Max, to demonstrate that I didn't just go, "This doesn't feel quite right to me." To demonstrate that I have given him a very clear...
AJ directly, a very clear reason why he can't fundraise at the moment because he can't. He can go out and keep wasting his... Burning away all his powder with all his investors. The other reason I thought it might be worth a shot is because yes, he has a PhD and yes, he has spent a long time building a pillar tech, but he has worked at VC funds bizarrely.
So I think I would... When they talk about reprogramming after someone's been an occult and you have to connect them back to who they were beforehand. I sometimes think he talks a lot of VC stuff, but he's not thinking about it in the right way, so I was just trying to connect him back with that.
This is they're not going to fall for this. This isn't going to be something when they go, "Maybe you'll spin out oncology." Fine. They're not going to fall for it. So I just wanted him to be really clear-sighted. Whether he is or not, who knows?
But I thought there was some level of understanding of VC that a lot of people don't have at that point. Who knows.

**Ray | 21:30**
Yes, yesm.

**Ellie Rofe | 21:30**
But can go to Max with my head held high and meet with hopefully meeting up with him and Emma, the consultant, in person when I go back to London.
And it. And I think it gives me a framework to demonstrate that I am not just designing stuff. Max knew me when I did much more design and formatting work and visual representation, so I think I needed to demonstrate to him that I'm not just doing that with people.

**Ray | 22:00**
Yeah, and right, getting people to see you differently as they saw you before is a bit of a challenge, too.

**Ellie Rofe | 22:00**
Even if the pitch deck.

**Ray | 22:07**
There's an old line that the doom of marriage is that women enter marriage thinking the man will change, and men enter marriage thinking the women won't.

**Ellie Rofe | 22:23**
I know. Another slightly bleak phrase. [Laughter] Interesting.

**Ray | 22:28**
Well, it's just a little bit like recognizing that you're the other party, right?
You provide what counsel you know you can, and there's a lot of good you can do, but to your Emma, Emma's the person you're talking to, right? To her point, they are going to be receptive to change or they won't. I actually think that's one of the most important things in a coaching relationship.
Maybe this one where it's a little less about what any individual thing is, it's more about the permission structure and the idea. Wait, there's more change to be had. The more change you're doing, the better it is.
So I'm super glad that you had that conversation, and I'm hoping you're able to have that kind of frank conversation with others, too, right? The counsel I got for having that kind of conversation was to talk as if to a friend who owes you money. money.

**Ellie Rofe | 23:34**
Yeah.

**Ray | 23:36**
That was a useful framework for it, right? Like it's kind of you want them to, but you'd really like them to be financially successful and be able to pay back the loan, and that's counsel for how to talk to investors.
I think it applies pretty well for this. I think it's awesome doing that, actually, in the same vein. I was looking, and I was just so proud of your observation about the BC report, right?
If the reason is... There are multiple reasons to be doing that research, but if you're starting to see, "Hey, wait, these are ways you can be creating profit for me that are not maybe the immediate report." They had the beginning. I'm not sure. I had an idea of a report as being the most important thing at the beginning.
When I think about the story, I've always thought of it as more... I've thought of it like survey creating value because it creates conversations early and then potentially creates an asset later.

**Ellie Rofe | 24:24**
Yeah.

**Ray | 24:29**
But I kind of wonder how many times. Like, this whole survey started and never got finished because it did its job in the round. One.

**Ellie Rofe | 24:35**
Absolutely.

**Ray | 24:36**
And I. Sorry, go I was going to say sort by way of finishing was if it's starting to like if you will.

**Ellie Rofe | 24:38**
No. carry on. I'm sorry.

**Ray | 24:45**
It seems like it's bearing fruit in that you've had conversations.
It's getting people to then tell you things. If you've heard of Cunningham's Law... Okay, so Cunningham's Law is that the best way to get an answer on the Internet is not to ask a question, but to pose something that's wrong.

**Ellie Rofe | 25:03**
[Laughter] Okay. Yeah. [Laughter].

**Ray | 25:06**
So like the fact that you're. Yeah, so there... I mean, of course we'd all rather be right, but there's a Cunningham's Law aspect of it where you talk about this thing that you're doing, and then they push back and say, "You should be doing this."
That's what King is going to talk about, which is great.

**Ellie Rofe | 25:21**
Yeah. exactly.

**Ray | 25:23**
And fact that you have the assets, right, of the research you're doing, the ideas, and the fact that you have a machine that you could be using to give more insights to people...
I think all of that is fantastic and puts you ahead of where you were. So if you're... I want to raise it because one, I want to be encouraging this reinview of what you have, what your assets are, and how they can be put to work for you in the most beneficial way,
not be a... Some of your CEO clients are definitely in the mode of, "I just need to finish the thing I started." If it's not the right thing to finish, yet what you have here is an asset. Let's.

**Ellie Rofe | 26:11**
I think there is absolute value in it for many different reasons, and I'm still going to try and do the survey.
It's just every time I talk to someone who is a VC or a JSON, and they go, "So that in itself tells me something about VCs." It's all market research. It's all deepening your understanding. So, yeah, it's all.

**Ray | 26:33**
Right. If you're finding that talking about it is actually retarding your progress, then let's not do that, right? But if it is something to talk about, and then you get to Cunningham's Law, and you're talking about it, and they're like, "No, that's wrong. You should be thinking about X and it has done it.

**Ellie Rofe | 26:49**
Yeah, exactly. No, it's lovely. I mean, she immediately... She's very smart, Emma anyway, but she immediately... Just came in with... Yeah, they did a report on communication and science, which I can't find, but I'll keep trying to look.
You should just get them to pay you to rewrite that and then republish it. So it was like four years ago and people still need it. I was like, "Brilliant." That's an idea that I wouldn't have had.

**Ray | 27:16**
A wonderful idea. You have a relationship. You can go back and talk to them. You can probably offer them, to your point about feeling underutilized, and you can probably offer them a rate in return for putting your name on the damn thing.

**Ellie Rofe | 27:25**
Yeah, right, what's... I just say to them. No, I don't think I understand. So just say to them, "I will give you money to put my name on this, basis.

**Ray | 27:44**
No. Well, when I say give them a rate, what I mean is like you'll do it on a discount.
Like what you're doing with this other Crickensteute person, right?

**Ellie Rofe | 27:55**
Yeah.

**Ray | 27:55**
I'm not saying it needs to be the same price.

**Ellie Rofe | 27:57**
No.

**Ray | 27:59**
But the... Or even that it has to be legitimately inexpensive to do, right? But you have the relationship and wait, the science communication thing. What's going on with that?
I actually was talking to someone at... Or maybe you could use your name in vain or not or whatever. The SX is getting a little bit long in the tooth. Is there currently a budget to be doing something about that?

**Ellie Rofe | 28:21**
Yeah.

**Ray | 28:23**
There is.
Okay, we'll set the conversation now. But I love the idea of having your name with that institute in terms of being able to then grow the rest of your business. I'm not proposing you do things for free. I don't think you have to, but when I say give a rate, I mean it. You don't need to read it as...
Okay, well, what is my implicit billable hour? And do I need to match that in order to be willing to do the work? It has strategic value for you.

**Ellie Rofe | 28:47**
Yes, absolutely. I think that's when it is fascinating to me, having spent time much more in the B2B online business world versus this funky little hard science biotech world. It is so significantly different in terms of how they think. Obviously, names are certainly eminent. Names are always relevant in the B2B world.
If you said I worked with X, then you know... But working with much smaller companies is much less relevant than just testimonials or this or the other. But when I said to him, when I'm working with someone at the Crick Institute, it's like, "Lean forward, eyebrows up, whatever." It's suddenly like, "Okay, the Crick. Great. Who are you working with there?"
Because they do have such a... It's quite hierarchical, it's very reputation-led, and it's quite rigorous. So, as soon as you mention the Crick, then that sounds like... Okay, you know... So, I think those things.
That's why I've realized that it is useful to be able to try and get some logos on your site, talk about who you're working with, include names, and start connecting with people via those names.
If I do this work for an AI, then hopefully she gets funded, but we... I suspect we'll be able to work together relatively well. She's very business-minded. Being a translational scholar, she's already been thinking about how science moves from the lab into the world,
and that... She's very well connected. Cause she set up AAA charitable and so getting referrals from her or just having her name... She's junior. She's not senior, but I think there's... I remember when I worked on the film festival and a very senior producer said to me, "Everyone always wants to go and work with Ridley Scott or Chris Nolan or whatever."
She said they missed the idea that you need to find the people you move up with. If you haven't got two decades of experience, you really don't want to go and work with Ridley Scott. You need to go and work with people you move up with. You go and get parcels of experience with people, but you create your own peer group.
So it's not just always about reaching upwards. It's about five people you can grow with. Dina, the VC, mentioned that to me. She was like, "Yeah, I think it would be really interesting for you to work with people who are being spun out of..." She was talking about Cambridge.
So, it's really interesting for you because then you can grow with them. I worked on a crossover with her, but she said the people earlier on really need this stuff. Really need this stuff.
Obviously, there is a balance there. Because I have to have money to pay you, I can't keep doing things that are very low ticket. Because it is.

**Ray | 32:01**
Yeah, we can't forever.

**Ellie Rofe | 32:01**
You know it's not.

**Ray | 32:04**
But it's what you start with, that's how we get the wheel training. Then, I work for these people out of Cambridge. I work with these people out of the Sorbonne. The people out of whatever...
That makes for an interesting argument of having you just, if you can, pop up the train to Cambridge, To go give a talk there, to like, "Hey, scientists, we're looking to raise here." I emphasize raising because basically, you're coming in sure you have expertise around the business, but what you'd really be talking about is the fundraising process in general, right?
"Hey, what's the gap?" These are business people. You're scientists, and here's the bridge that needs to get built. Now, we think about that, blah. Anyway, I love the idea of you having more of that because, like you say, it probably creates some money opportunity and seconds reputational.

**Ellie Rofe | 32:53**
Yes, she has no money in her own company yet for Spinner.

**Ray | 32:53**
But I want to quickly ask you about the money thing as it relates to the Crick. Yeah, the individual Crick. She was not willing to spend more than one front, two back, right? So, yeah, totally fine. I get that in terms of the down payment.

**Ellie Rofe | 33:15**
Yeah, that's it. One front, two back. It's not great.

**Ray | 33:19**
Okay, well, okay, sure.

**Ellie Rofe | 33:20**
It's not repeatedly.

**Ray | 33:23**
Now, what I do in those kinds of situations is I charge more for the back because what I'm doing is
you're asking me to take a risk with you. Okay, I can take a risk with you. So, when they're saying, "Well, only pay you X on the back," why are you getting a discount on both sides?

**Ellie Rofe | 33:38**
Yeah.

**Ray | 33:38**
I understand the discount, the front. You're cash-poor, right?
So, we're going to do something as cash-poor. Then, if I'm coming in with you, I'm being paid more on the back. There are two ways for you to get that, by the way. On the back. Part of them thinking about how to get you paid more, right?
Part of them is just thinking about how to improve your position in the market. Like, "Hey, you did this gig, and it cost X, right?" So right now, you reasonably say, assuming it's successful, you'd be paid $3 for it, right? The pay-for-performance prop aspect of it, although I don't know how long it'll take, the other half of that pay-for-performance part could be...
I mean, if she's raising $833, how is she raising it? What do you know about the instrument in which she invests? I mean, okay.

**Ellie Rofe | 34:22**
Some of it will be non-dilutive, some it will be government funding, and some of it will be angels.

**Ray | 34:29**
And what is the instrument by which they invest at this level on your side of the pond? In the States, it would be a SAFE, which is the reason I'm getting at this.
So, I'm wondering what there is for biotech?

**Ellie Rofe | 34:40**
I would imagine it's a combination. This is actually something I need to look up because I've not worked with these early-stage investors that much. I would imagine it's a SAFE and an EIS.
So, two different investment vehicles. One of them is up to fifty.

**Ray | 34:53**
Okay, I bet you.

**Ellie Rofe | 34:55**
And, it gives all sorts of tax rebates and advantages to the investors. The other one, I think, goes up to a million. So, often people do it in two tranches.
Because the SAFE is the smaller one, it gives better advantages.

**Ray | 35:13**
Okay. Well, it may turn out to be more complicated than I thought, but I was wondering whether you can... There are three ways to get paid: upfront, in the back, and then a piece of the race.

**Ellie Rofe | 35:25**
Yeah.

**Ray | 35:25**
There's no means, you know, a piece of company.

**Ellie Rofe | 35:30**
So what I'm thinking of, I think I've always wondered about a piece of the company, but it feels like, especially with those early things, for the amount of a piece I'd get by the time it's diluted, and the amount of risk. Very nice. Knees aren't like two, three years, and then it's exit. It's like seven to ten years a lot of the time.

**Ray | 35:51**
And think it's a terrible way for you to get paid.

**Ellie Rofe | 35:53**
Yeah.

**Ray | 35:54**
Particularly when you're cash poor. But it is a way for you to have, you know, if you're getting if were example 12 and 10 just for the sake of argument. Then you get go next one.
Say you're paid. 13 fifth kick.

**Ellie Rofe | 36:09**
Yeah. So that's an interesting approach. What I was wondering actually is whether I have... It's the same as a percentage, I guess, but framed in absolute terms. Whether I have different back-ends, it would be higher than this one.
But when I have different back-ends based on the amount of the raise. Most of the raises that I deal with or have dealt with have been... Definitely double-digit millions, not under a million.

**Ray | 36:47**
Yes, sure.

**Ellie Rofe | 36:49**
It felt difficult.
I mean, that's very much... When I said that price you feel comfortable with, I think in my head I was slightly put on the spot. I hadn't expected to be talking about it that day.
I knew that she didn't have a huge amount of money in the company. In my head, I think I framed it as that's a very low raise. I'll just put a small amount on the back-end. But yeah, it is too low, Definitely.

**Ray | 37:18**
Well, and then. Right, and we do what we need to do, like early on, like you're just starting to get on the board. I'm asking. I was asking the question to see if there was in a simple way right to be getting you into the, you know, raised to participate alongside, as a way to, like you say, it's not worth that much on present value basis, but it would be a way to be, you know, sort of that. That way, your discussion is less about giving a discount more as to form,
and you're.

**Ellie Rofe | 37:49**
If it was in the US.

**Ray | 37:49**
Yeah, well, the most common way that we see raises happen, particularly at the seed stage in the US is a, you know, convertible debt or what in the more modern form is called a safe, which was pioneered by Y Combinator.

**Ellie Rofe | 37:50**
What would you be suggesting? Just so I can understand the structure you're talking about.

**Ray | 38:07**
So idea of convertible debt is that you basically are getting a loan for the amount of money with a substantial deferment on the interest, right? It's a junior loan. Everything is to be paid first. When the company goes under, you're never going to hear money again. Generally, it is understood.
The key attribute of it is that it's convertible, which is at the next institutional raise, right? IE. When there's a price for the stock, then you get to convert the stock, convert the principal right into a stock, either at par or usually at a
that it becomes a way to solve the early raise problem where, like, your early investors have no idea how to value the right?

**Ellie Rofe | 38:55**
Yeah.

**Ray | 38:57**
And I'm going to raise $250,000.
All right, well, how do we do that? Is that like 1% of a 25 million dollar company? Is that whatever.

**Ellie Rofe | 39:06**
Yeah. Yeah.

**Ray | 39:07**
And then of course, you get it wrong and sort of make a mess of your future rounds.
So let's defer the problem. So what we do is we raise essentially as debt, which doesn't have to value the company because it's just a claim on assets, just a very junior one. And then with understanding that you're going to be able to come in through some combination of... It's going to be no less than this valuation and at a discount of, you know, call it 30% or something. That way, you immediately make money relative to the next round of investors.
It's not super diluting the cap table because usually it's not made up of a huge amount of money. You're allowing the next round of institutional investors to be doing the valuation work to actually be purchasing stock at that point.

**Ellie Rofe | 39:51**
Yeah.

**Ray | 39:51**
Hey, now you have your stock. You immediately made your 30%, of course, on paper.
You get to come along and probably just get diluted right from there on out. So the reason why that's neat is that the S in safe is simple. It's a simple agreement for future equity.
It's constructed as convertible debt, but basically, it's set up that I'm never going to pay. I'm never going to see the principal, right? So you sign away all your rights to the principal, and it basically turns into an option essentially for purchasing at that rething else.

**Ellie Rofe | 40:21**
Yes.
Yeah, the interest on that loan is the discount on future stock, basically. Yeah, okay, but obviously, with the much higher risk, hence the big discount versus what interest you get if you just loan someone a hundred grand, for example.

**Ray | 40:43**
Yeah. I gotta tell you, how many of these safes go out and have no haircut at all? It's like, "Well, let's purchase the next round." Because they're looking for a mechanism by which they can help the founder.
Because, you know, they're the three Fs of early money are friends, family, and the third F is fools.

**Ellie Rofe | 41:02**
Yes. No. Okay. Brim YM.

**Ray | 41:15**
So Bring on the three-five money is before you have sophisticated investors involved anyway. So that orientation, right. I see that a lot in software and certainly a lot in the US but the US has a bit more of a mature venture capital ecosystem than in Europe.
That's the reason why I raised that. So, as you go through this, if you see that kind of opportunity, I'm not sure that you need to worry about working that into a source of wealth for you.
I think later, as your cash flows get good, it becomes an interesting way for you to be able to come in alongside companies that you really believe in. Let's save that for when you're a rich woman at the beginning. The beginning, I think of it as a way for you to at least say face to face, right.

**Ellie Rofe | 42:03**
Yeah?

**Ray | 42:04**
In terms of being able to offer something that's less cash-intensive for them because I'm sure they've got the upfront because they're cash-poor and in the back because they are probably rightly concerned about what the prospectus looks like to the investors.
If a substantial fraction of the cash is going to go to the money associated with raising, like, a bunch of sketchy CFO types do this too. Then, you know, you don't necessarily want to be lumped in with that.

**Ellie Rofe | 42:21**
Yeah, I agree.

**Ray | 42:34**
But there's some opportunity there.

**Ellie Rofe | 42:39**
I think, I mean, what I did with this one, I said to her, "We'll focus on the first two pieces of the process, which is understanding the investment thesis and clarifying that and then developing the structure."
But the really labor-intensive part of this for me is designing the entire deck. So I will help you with explicit visual ways. She mentioned she was struggling with ways to express data that's complex.

**Ray | 43:08**
8I think if people are raising $5 million and looking for deferred payment.

**Ellie Rofe | 43:09**
I said I will help you with explicit versions of that, but I won't do a full revamp on your deck because that's the time-consuming thing that I would normally outsource if I could, some of the formatting stuff.
So I figure that's less intensive for me. It's these Angel decks. Even if I give her a template, she has structure in it. It's already going to look better than everything else that goes out there
because they're all just a nightmare. That's just a mess of science. So, there is a lower upfront for me as well, but I think I do need to consider Trunch's backend. If I'm doing deferred stuff for people, I don't really want to keep doing it if I can avoid it.
But I do need to think about what stages, at which, under one million, one to 55 to 10, that kind of thing, about what I would charge as a deferred payment when people are raising this much.

**Ray | 44:13**
Yet I wonder what's going on there?

**Ellie Rofe | 44:16**
Yeah, well, yeah, that's the problem. That's where we are in the market. That's what I'm saying about these people who were given loads of seed money and are now running out of it with Runway.
I think the key thing is working out where... One of the things I'm finding difficult. So, the company that's deferred and deferred for age is the... The girl I spoke to this morning, the woman I spoke to this morning is involved with them.
I think one of the most difficult things is their science is brilliant. They're in an incredibly hot area. I have a strong suspicion that if I was able to get that deck into shape, then they would have raised the full 50 million that they're looking for at the moment, and instead, they've raised 750,000.
Sorry, 50 million versus 750,000. That this guy spent the whole three or four months he's deferred me looking for, and that I think one of the hardest things is I got paid for that. I'm not like that wasn't a deferred payment at all.
But one of the hardest things to work out at this point is who is actually doing the right work to make it worthwhile in deferring things because it does feel like a lot of people are just playing with monopoly money rather than actually thinking about the future.
So it's a different one.

**Ray | 45:38**
Well, I think that this gets into the whole IR aspect of it because what you're describing, I don't think it is just a result of deferment because I think even the upfront people you want to be associated with winners.

**Ellie Rofe | 45:52**
H.

**Ray | 45:53**
I don't think at this point in your practice, in fact, probably for any party practice in the next two years, you could be paid enough to want to work with a loser.

**Ellie Rofe | 46:00**
He.

**Ray | 46:00**
I want you to go up and... I don't want to see where this business is.
That's not a good deal for you. One, you'll suck the joy out of it, but the other is then it's not contributing to your reputation, and there are probably winners to be found.

**Ellie Rofe | 46:13**
Yeah.

**Ray | 46:18**
So if you're going in there and you're able to see more clearly than the next person that there's potential here, I mean, you might just consider that diagnostic aspect. There's value in that, too.
Right now, you might be using that just to diagnose which companies you want to work with, and you're like, "Look, you look great. I think you can totally raise." So if you want to do the whole third thing, let's just do a de minimis down payment, right?

**Ellie Rofe | 46:37**
H.

**Ray | 46:44**
So that we're clear on this, we move my fee back if that's if you're serious about raising in the course of the next six months.

**Ellie Rofe | 46:53**
Yeah.

**Ray | 46:54**
And can get into this and then discount like you say, it's a deferral.

**Ellie Rofe | 46:57**
Yeah.

**Ray | 47:01**
And getting them to write a check first to make sure that there's a relationship there, and, of course, makes a contract happen. But then, you're in with them because you believe this is something that's going to convert,
and now you're validating that good based on the story told me.

**Ellie Rofe | 47:17**
Yeah. Yeah.

**Ray | 47:21**
It's like, "Why would you wait for them?" If you see the money on the side, you can be the person and say, "Look, I see money for you on the other side. Let's not mess around here." I'm thinking of another conversation I had with a startup company that I've invested in.
I gave them the serious counsel back in March, and they did what I've described, took it the worst possible way, but then I didn't really jump back into the pool with Them.

**Ellie Rofe | 47:57**
H.

**Ray | 47:58**
In retrospect, I look back and I'm like, "Why didn't I just keep on giving them chances?" To be doing this on their own, when in fact, I would have been a better friend to them if I had raised my hand again, sixty days later, based on what I've heard so far.

**Ellie Rofe | 48:12**
Yeah.

**Ray | 48:15**
And, be it. The lessons we learn. I suppose I'm sharing that lesson with you so that you can, instead of making the same mistake I did, you get to make a whole new set of mistakes.

**Ellie Rofe | 48:27**
Yeah, this is a nice bit of feeling approaching new ground, frontier mistakes.

**Ray | 48:33**
What's your mistake?

**Ellie Rofe | 48:33**
[Laughter] Yeah, I do think there's a bit of... I'm trying to work out the incentives of how to...
So part of the problem with this guy is that he's just pushback raising. He's just chaotic, but he didn't seem that on the first call. He seemed quite with it. It was when I got into the deep dive that I realized there was deep chaos going on underneath the surface.
So I do need a way to get that diagnostic more in advance. Maybe that messaging workshop that I do is... Yeah, "diagnostic." A trunche of money upfront.
Then I say, "I'll quote for the rest of the deck." So they have a de minimis output that we get through in a week, like you've talked about before. Quick engagements. Once we've done that, I say to them, "Right, this is a situation I see and go from there." I'm trying to work out the no-go, what were you gonna say?

**Ray | 49:42**
What do you mean, sorry? Go ahead. I was just gonna say what you know, I like the fast, I like the messaging workshop and the... But because I just had this. I had a similar conversation with Demetris earlier today.
I'll ask you the same question I asked him, which is what is the output right of the messaging workshop? Just to make it easier, Se?

**Ellie Rofe | 50:06**
It's the investment thesis. It's defining their investment thesis so they get three to four clear options that they can then take into their business and work out which is the direction they want to go. They almost inevitably need to work out which direction they want to go in their business, which is what I'm starting to realize.

**Ray | 50:26**
No.

**Ellie Rofe | 50:29**
And think there's an interesting time tension going on with a lot of these companies. They want a raise immediately. I think this guy really needed cash flow to raise immediately, but part of the reason that he was struggling to raise is because he hadn't taken the time to choose a proper direction.
So there is a sort of... If I'm working with companies who are Series B, as I have done in the past, although not at the moment, they are at such a different stage. They've still got questions. They've still got stuff to do, but they've done a lot of this work already, and they still might have to make it, but they've had to go through a couple of rounds of this working with these earlier age ones with less or more naive or less focused CO that first messaging workshop piece can end up being something where it holds a mirror up to the fact that they haven't been making decisions or that they have been drifting down a certain path that isn't actually very investor-friendly or isn't very strategically sound.
I think that's an interesting... I know we're coming out to times, so it's a bad time to raise this, but maybe it's time for me to ponder if they're going to do that, there's going to be a big break between them actually raising money, between our call, our first step of that process and then actually raising money.
I think that's partly what happened with this other guy as he realized that he had to go away and fix some stuff because it wasn't in the right state. And that's why he's raised 750 grand, not the 5 million he wanted or the 50 million because everything's a bit chaotic.
So there's a tension there because in the first stage of the process, I'm not... There's an element where they come in thinking I'm just going to redesign or restructure their current pitch deck. The problem with the pitch deck isn't the pitch deck; it's the thinking behind it.
It's the strategy that's sitting within the company that is not articulated, that isn't clear. Maybe I need to have a higher upfront for that process so that if they disappear, I'm not constantly left scrambling to get new clients to get a small proportion of the thing while they go off and restructure things or rework stuff to get ready for funding. Does that make any sense? I feel like I've waffled a bit there.

**Ray | 53:04**
What did they see? Yourselves waffling between.

**Ellie Rofe | 53:10**
I in themselves feel like working with a Series B, the process of saying, "Right, let me learn as much as possible about this company." What's your current investment thesis? What are you trying to put in place?
Okay, fine, here's some nuances of that. Which angle of this are you going to go for? Once you're working with Series B, they're like, "No, we don't want to be second in line. Supplementary therapies or whatever, no, it's a first-in club."
When and so it's pushing through those stages is easier. It's sometimes a bit slower because there are more people, but it's easier when I'm working with these guys early on. I think there's a tension between them not having much money to pay huge amounts on the pitch deck, not having enough strategy properly articulated to then go through the process fast. This is my concern with the process that I have: the first stage of that process, as it necessarily must do, throws things up in the air.
Then, instead of going straight to the next step and the next step after that, unless they really are thinking strategically and they just struggle to articulate what they're doing and put it in a pitch deck. Then we end up in this kind of hiatus stage, which I was in with this other company, and I'm now in with Apil Tech.
Well, I'll just wait for you to sort out your company thenm.

**Ray | 54:47**
Well, okay, so there are one to three things I'm thinking about this. The first is there's been a big difference between seed and series B, because series B has raised before they've been this party. They have discovered that they understand that whatever they had before was causing an unnecessary level of pain. Or they do not have the ego, they like it or whatever.
There's an ease in selling that. Just there's so much money at stake. That's sort of harder for you to break in, right? So there's a little bit like that. Okay, that's not really where we are right now.
So let's step back from that for a minute. The second issue is going to be that when you're talking to a seed company, right? They don't have that ex ante business idea. They're going to be much more, "Here's science, here's business." They're going to be looking for the answer, right?

**Ellie Rofe | 55:36**
Yeah.

**Ray | 55:37**
So there's no company for them to examine, for them to do this. There's their idea of what the company should be because what they have is the lab, right? That's the point you're making before.
It's like even when they've raised money, they're doing some stuff. It looks a lot more like a lab at this stage, right? So they're looking to you for that you know how to do the business because they view making it businessy as a way to extract money from the suits, right? Rather than being the thing they really need to do for their company.
Okay, fine. That's how they see it. And that they might be getting to do the right thing for the wrong reasons. But you're not here to fix the reasons; you're here to fix the thing, right? So there's an aspect of that where you don't really want at the scene level to be opening the door for them to go do other stuff, right? You want to be helping them narrow in because there's not that much there yet.
There's going to be a certain intuitive aspect to that, at least when you get something small enough, like when you describe something. These people are like, "I'm trying to figure out whether I'm A or B or C." It's actually not obvious to me that giving them four options, all of which are kind of viable, is helping that individual make progress because they get stuck on the absence of decision-making. They don't know they don't have the structures to make those decisions better, so that's going to be... The second consideration is that as we think about stages, whether giving them more options is actually that helpful as opposed to making it in the workshop figuring out some options and then dialing in on the one because that one gets them to the point where they want to be in. Which is now there's an engagement to be done.
The truth is, the shift probably... Probably the do we want to tell this story or this story? Probably doesn't matter nearly as much at the seed stage, right? Because there's a lot you can do. You can tell me you think it really does matter, but I tend to find that these are significant jockey bets.
So part of what you're doing with the storytelling is demonstrating that you can actually run a business as opposed to running a lab.

**Ellie Rofe | 57:47**
Somewhat seed stage. This is still ten to 20 million. So, they're not just grabbing a couple of bits and bobs sometimes; they still need a lead in institutional like BC and stuff.

**Ray | 57:58**
It's serious money, absolutely, to be sure.

**Ellie Rofe | 58:00**
Yeah, it is slightly trickier to just narrow them in on one.

**Ray | 58:01**
But the question is, what kind of company is it at that point, and then what is the nature of the bet? Maybe $20 million. I get that, but when at the end of the capital intensity, we say all need to raise nine or ten figures to get the holding done...
There's a... What is the question? This is the lean startup stuff, right? Take the lean startup and just apply it to venture rounds. What is valid learning question? That the investor is looking to be able to answer this $20 million investment.

**Ellie Rofe | 58:41**
We've gone over time, but I think that's given me a lot to think about. I will ponder exactly what I'm feeling like.

**Ray | 58:50**
Okay.

**Ellie Rofe | 58:53**
It's not quite the right process, but I'm not articulating why, so I will ponder it.
I'll review our transcript as well. I will have a workout of what? How I can take it into something that will work on a short term basis.

**Ray | 59:08**
Yeah, sure. If I can be helpful, we're shopping any more of these questions between now and next Friday. I'm certainly very glad to.
I'll talk to you on Tuesday.

**Ellie Rofe | 59:16**
Thank you. Been very helpful. As always, have a lovely weekend.

