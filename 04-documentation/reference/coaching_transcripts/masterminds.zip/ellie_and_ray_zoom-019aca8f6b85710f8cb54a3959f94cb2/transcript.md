# Ellie and Ray Zoom - Nov, 28

# Transcript
**Ellie Rofe | 00:05**
Hello, I can't hear you and you're frozen. Is this my internet?

**Ray | 00:06**
Hello, Ellie. How do you do?

**Ellie Rofe | 00:21**
I think I can hear her. My internet connection is unstable. Great, I can hear you.

**Ray | 00:31**
Okay. Classically, internet connection unstable. Is about CPU usage.

**Ellie Rofe | 00:37**
Interesting. This is there is nada going on in the CP on this one.
Yeah, we're like yeah, we're about 70% idle.

**Ray | 01:03**
Any improvement?

**Ellie Rofe | 01:08**
No.
No, you've frozen again, which was probably me freezing again.

**Ray | 01:27**
These things happen. We make do with what we got. Always easy.

**Ellie Rofe | 01:30**
We do indeed. Let's blame me on Musk for this one as I'm on... Darling. Yeah, the easiest path.

**Ray | 01:42**
My goodness. You know, the, family gatherings and politics, you know, dangerous and, well, thank you.

**Ellie Rofe | 01:51**
Of course. Thanksgiving. Happy... Belated Thanksgiving.

**Ray | 01:56**
The that. And, yeah, that was it. It was interesting because my boys have been consuming a lot more very liberal stuff.
You know, in you know, my wife is much more active in liberal politics, and the, they and they're at that age where they I mean, they have wonderful capacity, right? For, you know, taking in complex ideas.
But they're not really questioning those ideas yet. So they take in these ideas from their mother or from the these other books or what have you, or even things I share with them, and they sort of take them as truth, right?

**Ellie Rofe | 02:39**
Yes.

**Ray | 02:41**
As opposed to these are inputs that sort of be we working in our model and that's perfectly normal, you know, developmental stuff.
And the thing is, we're giving them guns, right? Because they'd have... They usually are the pace at which we learn these things goes along with not having access to as many of the ideas.
They're capable of using those ideas, thinking about those ideas, describing those ideas, and working them into a conversation. The problem is they are just acting as a proxy for the idea and not really as something that stands above.
So they go have a conversation with my stepfather because my mom remarried after my father died, and he has politics that are not in agreement with my wife, frankly, or with my mom. I think that's perfectly fine. Different people think different things.
But boy, they were just going at it. My son Josiah and my stepfather were just going at it. Hammer and tongs.

**Ellie Rofe | 03:43**
Right. Wow, I...

**Ray | 03:44**
Okay, politics and family meetings.

**Ellie Rofe | 03:44**
[Laughter] Yeah, it is fascinating. You've really articulated something that I have been thinking a lot about, the inheritance of ideas rather than the understanding of them.
You can understand an idea, but the contextualization of it. What is that idea in the situation, in the overall grand arc of theories and understanding where they originate from and the underlying suppositions behind them?
I think that's where no one, unless a complete policy and politics nerd, is going to be able to situate those things. But that's where political operators are able to make great leverage. I don't say this either one side or the other.
I think it happens constantly. So it's a really interesting thing you've identified because I think that happens. That is a developmental stage, but it's not just a developmental stage. It's an attitude of mind that exists across lots of people, regardless of their age.

**Ray | 04:53**
Yes.

**Ellie Rofe | 05:01**
So it's fa.

**Ray | 05:02**
Yeah, I would say it has to do with intellectual development, right? You know, rather than being strictly about age. And you make a good point about, like, you know, plenty of people, sort of.
And it's it takes work. I think it was a Frank Herbert line about how understanding is the end of learning.

**Ellie Rofe | 05:21**
Yes, right. Yeah, that's a good one.

**Ray | 05:26**
And that's, you know, how can we the, you know, when you understand idea, you're saying. I don't need to think about that anymore. I'm sure get to file that away.
And the you know, the continued integration is really the it's continued work, but that's where the big values are in even guess my it was good. I sort of let it happen, right? To let him go at it with his grandfather. He. I don't think either of them think super less of the other as a result.
And like this is just a way to get him to have more conversations with people who don't feel the same way he does.

**Ellie Rofe | 06:04**
Yeah, absolutely. I had... My dad was a Tory, like a working-class Tory made good. He grew up very working class and then went to Cambridge, became a lawyer. My mom was an Irish immigrant, grown up in poverty, full socialist.
I was always given the opportunity to see people disagreeing, sometimes too vehemently.

**Ray | 06:32**
Two.

**Ellie Rofe | 06:33**
They did disagree, and they made a whole life together whilst disagreeing about things. So, it's really valuable to see that rather than... There's lots of research now about the... I'm not sure exactly what it is. The cognitive...
But there's something like that around only being around people with your own views and what it... The negative impact it has on you whilst you think it's good, you think it's comfortable and safe and all these things, but actually it's terribly bad for you psychologically, socially, all sorts of ways.
So yeah, I'm really pleased that they went at it. I know it's probably not pleasant for everyone... Half beating...

**Ray | 07:18**
It' it creates a little more stress, you know, but, you know, the these things all continue. Okay, but sorry, I didn't mean to distract it from your stuff for this week. So you're doing this investor ready 2026 event. It seems like that's a significant piece of your week. When is it when is the event itself.

**Ellie Rofe | 07:42**
It's next Friday.

**Ray | 07:44**
Okay.

**Ellie Rofe | 07:44**
Yeah, I don't know that we're going to get anyone, but we're just going to have to record something and see how it goes.

**Ray | 07:52**
You say record something. Can you help me? I actually didn't even know what the event was. So, I've got no grounding...

**Ellie Rofe | 07:57**
Okay, that's the half day workshop I'm doing with the, you know, the.

**Ray | 08:01**
That's what this person is. Okay? Got it. And now, so sorry.

**Ellie Rofe | 08:04**
Yeah. So it's like a series of mini workshops or sessions within the event. I think hopefully we'll get a couple of people. But if not, I would suggest to Natasha that we at least... It's not the same when you don't have interaction.
We at least record what we were going to do and just work through it, even if nothing else to see where it feels wrong to us or to get some content out of it or to just work through it, just honor the thing we're going to do.

**Ray | 08:41**
Just...

**Ellie Rofe | 08:44**
Yeah, we shall see. There's still a week, we'll see how it goes.

**Ray | 08:49**
I think that nobody signed up so far. That's sort of what your observation is.

**Ellie Rofe | 08:51**
Yeah, nobody signed up. We haven't had enough people going to... I don't think so, yeah, interesting.

**Ray | 08:57**
Yeah, fair enough. Another way you might consider doing it is... I've been thinking about this a little more recently because of... Well, actually, I suppose I'm always thinking about this strategy.
It's just turned to a live stream, right? Be working at the live stream. Of course, very few people are going to watch the actual livestream, and you don't need to worry super about that part. The most important part is that the live stream gets it done right. Whereas'll record it and then... That wasn't good. Or whatever. The live stream says, "Okay, now we've shipped it," and now it's shipped over to YouTube, and now we're not going to work.
Now it's out in the world. Then you can just make profit from that.

**Ellie Rofe | 09:42**
I think so. I think so. It was funny enough. It was Nick who said, but if no one turns up, you're still going to record it, aren't you? And that's like, it's interesting. He knows nothing about digital, like marketing or anything like that. He's renovator.
But he was like, but you're still going to do it. It's like, yeah, really interesting. Good question. So yes.

**Ray | 10:04**
And a the service can turn into content. Actually, I was just talking about talking with Demetris a couple of hours ago about my you know, the you know, one of my models for, you know, intellectual property as that there are three is like matter. There are three states of it we're talking about. It'slid state you are. You've heard me use the line that like software is software solidified consulting is liquid software.
And then my theor is that content is the third data matter.

**Ellie Rofe | 10:33**
Yeah, you are avoiding saying content is gas.

**Ray | 10:37**
Yes.

**Ellie Rofe | 10:37**
[Laughter] Yeah, fair enough. That doesn't sound...

**Ray | 10:41**
Yeah, it's hot air at the Zymoot area.

**Ellie Rofe | 10:42**
[Laughter] Yeah, no, I like that a lot. I think it's I think, you know, I used to do stand up many moons ago, and, I loved it.

**Ray | 11:00**
I see, I want to see that.

**Ellie Rofe | 11:02**
Pardon? [Laughter] I tell you, if there are recordings, my Lord, it will be dated. [Laughter] Yes. God, I'm just thinking about some of the topics really dated.
But it's... I always dig in. Like 2011, I guess. I went out to Edinburgh and did a compilation show. So four of us, I think, were across and our show across the month. Some days there were two people in the audience.
There is nothing more intimidating. So I did stand-up, and I've done speeches and talks and stuff in front of 500 people, and that is so much easier than two because there is an intensity and an intimacy that you just don't have.
There's just no room for 20% of this 500-person audience is laughing. Therefore, that sounds like quite a lot of people laughing. It's like that person staring at me like I'm the reincarnation of Hitler.
A person is just looking at their phone like, "Okay. Anyway, I think there is an element that all comics have their stories about having played to no one or two people or whatever. There is an element of just doing the hard jobs."
But I think it's actually just reps. It's just keeping on doing stuff. Just practice. Going, "No matter what the thing is, I think there's a psychological, almost anti-fragility in it, I guess."
So that's where I thought, "Yes, okay, we should do it." I love the idea of live streaming it. I don't love the idea of it, actually, but I think it's a really good idea. [Laughter].

**Ray | 12:59**
Yeah, and then I'm finally getting the stuff with my thing with... Yeah, you've seen going again. Robert's weekly, I think, has really been profitable for him in both directions.
I mean, Demetrius have been gangbusters in terms of attendance, and especially when I'm seeing sign ups, he's just not... But to your point about being hard, he's having a hard time getting himself to go do the next one, right?

**Ellie Rofe | 13:25**
Eight right?

**Ray | 13:31**
And the but I do think it's a pattern that we've shown repeatedly. Works.

**Ellie Rofe | 13:39**
Is he just not loving it? Sorry, no, that's his business. I won't dive into that, but yes, it is hard.

**Ray | 13:47**
But anyway, all of us by the way of saying that if you got the opportunity to be starting to turn that wheel for yourself with this thing, I think that's great. Then, all I'll be doing is looking for the next one.
Not because it's the only way to reach out, but because it becomes an easier way when other things are not moving as fast as we might like. We keep on trying to fix it the right way. In fact, why don't we just fix it the easy way?
Because then once you have momentum, it's so much easier to improve than it is to start.

**Ellie Rofe | 14:20**
Yeah. And I think you there's just a process. I keep thinking this when you were talking about the website and that just being part of your study, it is just a it's just part of the process of learning more about your market and even you and your relationship to that market and where your strengths and weaknesses are and how you're trying to connect with them.

**Ray | 14:43**
Three.

**Ellie Rofe | 14:48**
And so like I'm trying to write a LinkedIn carousel today. Coming from a different angle and talking about the beliefs holding people back about fundraising in a difficult environment.
So like you say, tethering it to the now reality, which I haven't always done and coming at it from a more founder psychology angle, which I don't always do. I'm just testing different angles and approaches.
With that experimentation mindset that I've always said clients should have. Sometimes I haven't been able to exist in myself. I've been a bit more like, "This has got to work." Rather than "Let me see what works."
Because the cobbler's children still have no bloody shoes. But it's AI that feels a certain sense of freedom with that. It's often then pushed back against when I start connecting with people who I feel a bit more impostor syndrome around.
Then I'm like, "Is this real? Am I just talking a load of crap?" And then I have to reset again and get back out. So I think the anticipation of all this stuff is far worse than just getting into it and realizing that you just continue and that there'll be ebbs and flows in your confidence, in your sense of what is working or what isn't in all sorts of things.
But the only constant is you just get on with it. I think that's where I'm settling for the moment until that ebbs and flows as well.

**Ray | 16:37**
Okay, the. Okay, well, I'm and I'm glad you're finding that comfort. And I'm glad that the and like the investor ready things are giving you an opportunity to do that in a way that's not the same thing as the small like it sort of helps turn that wheel a bit.
And so I'm glad that that's happening.

**Ellie Rofe | 16:58**
Yeah. It is a forcing function.

**Ray | 17:00**
Yeah, speaking of forcing functions, you mentioned, like this other, this UBS person.

**Ellie Rofe | 17:06**
Yes.

**Ray | 17:09**
And is there a is there something there or. This is just sort of storytelling about the.
I mean, it's a good story about the week. You' certainly learned some stuff. And I think that and you're sort of, you know, out there getting a reputation going. But is there a next step to it like he sort of talks about like wanting maybe some help for with the event, but then it kind of goes from there.
And it wasn't clear to me. There was sort of more direct follow upm.

**Ellie Rofe | 17:35**
Yeah, he wants to keep meeting up. So I worked with Paul, Exon, for a few years, and we used to run what they call... They had two different conferences. The biggest one was the CEO conference, and then there was the investment something or other. My God, things that are a massive part of my life, and I can't remember the name of them now.
I worked with him on design, cons, and event design because I used to run a film festival, and I ran events at NBC or I established events at NBC Universal. I think he does... I mean, he obviously has worked in equity research for decades, and he does have a lot of contacts.

**Ray | 18:21**
Two.

**Ellie Rofe | 18:24**
I think there's a possibility of making some money from him as a consultant. He's not stingy, but it just depends on UBS and their policy at the moment. There's a possibility of him having contacts. I do keep... He wants to run... He basically wants to set up the equivalent of a Davos or whatever.
People were saying to him that the event that he did at UBS was better than Davos, and he wants me to help him with it. I was thinking about how it could be useful to me, obviously in terms of my overall goals, but I was actually thinking it is a really interesting thing. It would be a longer-term thing.
So it's probably not very useful, but the reason I probably put this in there is because it is useful to just articulate this to you. I feel like a huge amount of the things that move the world are encapsulated between finance, politics, and frontier tech, defense, space, climate, energy, etc.

**Ray | 19:37**
We only need power and knowledge. Sure.

**Ellie Rofe | 19:40**
Yeah, exactly. Money, power, knowledge. Perfect. So when he talks about this, he thinks a lot about finance and politics. I think there is an interesting angle to bring in the knowledge and innovation side of it.
When you look... I've been looking at the hard tech stuff recently, and hard tech founders tend to be... As far as I can tell, hot tech CEOs rather tend to... Well, they seem to be so far more explicitly political, and I guess because politics has such an impact on hard tech in a way that it doesn't necessarily have on software in terms of where money is flowing from government, because most hard tech requires grants as well as other things, regulations, incentives, whatever it might be.
So I was wondering about proposing that to him and weaving that in and having that be a way that I can potentially... I've been thinking more and more about connecting with VCs, and I've got lots of ideas.
But I think that is a way I can borrow authority but become someone who can potentially, depending on how it works, run that wing of it for him.

**Ray | 21:09**
Yeah, sure.

**Ellie Rofe | 21:09**
And...

**Ray | 21:09**
I think the just the you know you being able to take his conference and bring it to the BCS. Hey, would you be interested in as or I'm helping them feel. I'm so. You think I'm so s smart. We can be doing things or you can even this creates an interesting survey opportunity too.

**Ellie Rofe | 21:24**
Yes, exactly. Yeah.

**Ray | 21:25**
So there are a couple of different ways you can be exploiting that. And then for this other guy, the thing about the VC is that the VC you're not trying to pitch them on. Hey, here's... In some academic that he should be talking to, right?
It's like, "No, this is money. You already understand money. This is just where money meets knowledge."

**Ellie Rofe | 21:43**
Yeah, I'm power.

**Ray | 21:47**
Right, so, like, he's got politicians. Although I'm not sure. Theresa may counts as power in any event.
But the.

**Ellie Rofe | 21:54**
No, not so much.

**Ray | 21:57**
I think she will show up at any conference that she's invited to. But there was a somewhat embarrassing piece in the American Political Journal about Theresa May showing up at an American political conference.

**Ellie Rofe | 22:03**
Started badly. So, you know.

**Ray | 22:17**
You know, conservative one, obviously, and like, basically sort of kind of like your story about, you know, playing to two people in the audience care. She was the former prime minister of the United Kingdom and like, just. Wait, what? Although I think that head of lettuce, though, that might have actually, you know, done better anyway, the.
But yeah, that that' you're totally right like that. Those people are thinking about all three of those things. And of course, money brings power and that has that aspect. So, yeah, I love that. You being at the Intersect, being able to bring more of that in, and the thing about running a conference is the first thing you want to do is find the sponsors, find the sponsor.

**Ellie Rofe | 22:57**
Yeah, well, I yeah, I actually don't know.

**Ray | 22:59**
Believe that funding. Funding could be paying for you.

**Ellie Rofe | 23:04**
So he was saying to me, "There's no point in running a two million conference anymore. It has to be five million." And I don't know whether that's just a straight UBS budget or whether that is sponsored. I'd have to look, actually, we spoke for about 45 minutes, but he was always very fond of me.
He said every time I think about who I needed at the conference this year, it was you. So it's a positive sign.

**Ray | 23:31**
Yeah, the I mean, the.

**Ellie Rofe | 23:32**
Yeah, it is interesting. I don't know how much sponsorship they raise for it. I mean, I guess they would do it. It makes sense.

**Ray | 23:47**
This kind of conference should make money.

**Ellie Rofe | 23:51**
Yes. A lot of the time they make money by deal flow coming from it, though, because it's an investment bank.

**Ray | 23:57**
Sure, UBS makes money through the deal flow. UBS is paying for the conference.

**Ellie Rofe | 24:00**
Yeah.

**Ray | 24:02**
UBS the conference makes money because UBS is sponsoring it.

**Ellie Rofe | 24:02**
Yeah. Yes, got it.

**Ray | 24:06**
If you see what the distinction I'm making. So like the this is a if this is a UBS event, right? Then I totally get what you're saying, right? But then, like, UBS becomes a sponsor. So when you think about the flow of money, all right, that means UBS is paying for the things that need to happen in there, right?

**Ellie Rofe | 24:20**
H.

**Ray | 24:21**
There's no reason to be gifting anything to UBS because UBS is the ones make money through the deal flow.
Like you talk about and that that's true for like other sponsors too, like when you look at, you know, conferences in general, like who who's sponsoring, who's exhibiting, why are they there? They're there because they have usually have a fairly clear, you know, promotional goal coming out of it.

**Ellie Rofe | 24:43**
Yeah, okay, yes, I think that... There are definitely opportunities, even simple ones like the other angle I bring to it, not like as the perfect text someone who certainly knows more than him and other people in that company is how you can use AI within the structure of the event to create more value.

**Ray | 24:48**
To be clear, who's the vendor, who's the client?

**Ellie Rofe | 25:15**
Very simple things.

**Ray | 25:15**
He...

**Ellie Rofe | 25:17**
And they're not doing that at the minute. I mean, he had like a humanoid, he had some futurist invest interview a humanoid robot. But that's not quite the same thing as building it into the experience and finding ways to suggest meetings to people or, you know, whatever it might be like just a basic suggestion engine that's not even there.

**Ray | 25:40**
No, yeah, that's a fair point, I guess.

**Ellie Rofe | 25:46**
So...

**Ray | 25:49**
There was a question like how good the solution engine can be at this point. You and I had this conversation a year ago that the solution engine would have been terrible at this now would it not be terrible?

**Ellie Rofe | 25:56**
Yes.

**Ray | 25:59**
I mean, these are people who are all, you know, the this sounds like the both the attendees and the and certainly the speakers what have you are people who have, you know, fairly jealous of their calendars, right?
So who are they looking to meet? They often know who they're looking to meet. And so, like, what is the problem to be solved with the. I bring it up because, like, this G engine I can find other people for you to meet. Is like.
It's a classic one that keeps on showing up and I can't tell you how often. It's just like, trash. Why do I want to be? Da? These people.

**Ellie Rofe | 26:31**
Yes, I think... What I was thinking about was when you get people who have a public profile, you have an understanding of what that person is interested in, but you don't have an understanding of the frontier of what that person is interested in because the new things they're looking into or their current preoccupations are not part of their brand yet.

**Ray | 26:55**
He...

**Ellie Rofe | 26:56**
I think there is an opportunity specifically around that to say, "I'm really interested in this at the moment and for other people to go, actually, yes, no one else knows this yet because it's at the forefront and it's not something I've talked about at conferences yet, but it's something that's there."
That's where I was thinking. Because they are all broadly... They're known or they have a profile at least because they're going to be CEOs of public companies or rising companies or whatever it might be.
Investors, financiers, and merchant bankers. So yeah, there is a job title and a profile and then there is potential interest. It was a potential interest that I felt was not surfaced, but it might be something that just doesn't function very well with that group.

**Ray | 27:52**
Yeah. I wasn't trying to criticize it just to say that there's a difference between... I think this leads into what you're talking about. So some of the stuff you're talking about with the study, right?
There's a discovery process. What is in here? That's good, right? As opposed to a we'll come up with a meeting matcher and then you're working on building the meeting. I had a conversation with somebody who I was saying that they were afraid of their business associates flatlining
and they need to consider building a new product, right? They've got wonderful talent, they still have a bankroll. There's time you can do things. So you're saying what they need to do is go head into a skunk works.
So yes, skunk works but not go into a hole and go build things. They need to go become native to whatever this new environment is. They need to experiment, right? They need to have room for that if you leave it to the last minute.
Sure, you can probably have room for a bill, but whatever you can do anyway, just by way, it can be shocking what it is good for. Then some in the preconceive the preconceives can be a little bit weirdo, but that's super cool. You get to be involved in a conference.
I think conference call could be something that nicely elevates your profile. I mean, that's all to the end particularly. If UBS is going to be the primary sponsor, that makes it much easier for there to be a flow of money. "I'm glad to help with this."

**Ellie Rofe | 29:15**
Yeah.

**Ray | 29:15**
That's just big. Yeah.

**Ellie Rofe | 29:17**
Yeah, absolutely. He was very keen to have me on as a consultant on it rather than just be like, "I'll just chat with Ellie every month, and she'll give me ideas."
You've just made me realize one of the things is my client interviews, market research style thing of saying, "Let's talk to some of the people who were there last year." If there were some of them wouldn't give a TOS.

**Ray | 29:39**
He.

**Ellie Rofe | 29:41**
But let's talk to them and see what was missing, what they loved, what they didn't, and work out ways so that we're not just building blind and speculating on what people will love.

**Ray | 29:54**
What was great, what was terrible, what was missing? These tell you basically how to refocus.

**Ellie Rofe | 29:59**
Yeah.

**Ray | 30:00**
Cool. Okay. All right, I'm super curious to be asking about the ingestion engine, but I don't mean to be driving the conversation.
So how about I step back for a second and ask what... How can we be putting this time to work that will create maximum value for you in the coming week?

**Ellie Rofe | 30:16**
It is the ingestion engine or rather that sort of area of stuff. So I like meetings as forcing functions, deadlines for me, because otherwise I drag things out. I have a meeting on Monday with that... God. Her name's just gone.
But the woman who's an angel investor herself, who is a scout for Hustle. VC She's focused on biotech herself. Hustle is wider. I would love to be able to show her what I'm trying to create in terms of the research area and the insights.
It's not about research, it's about the insights and the ways in which I can help earlier-stage companies who can't because she works early-stage and can't afford me yet. But just to the whole point for me is to position myself as someone who is thinking differently about this, who is not just like "Here's a template or here's a consultancy thing," but actually trying to think about the wider ecosystem and position myself in it.
This is where I need you to either... Well, possibly just to stop me before I make everything. Make things... The everything engine, as I tend to have a habit of doing. I was thinking about the value of the pitch deck analysis because the value isn't just in stats. I great doc send analysis because obviously, doc send has stats on pitch decks almost entirely. Sales and so, they were talking about the number of pitches out of 260.
I think it was the number with a problem slide, the "why now," etc. The amount of... Then they had stuff which was more about the number of investor contacts reached versus the number of meetings versus the actual money raised.
So that was really interesting stuff that I can't quite get at the moment.

**Ray | 32:24**
Two?

**Ellie Rofe | 32:28**
But as I was looking through this, I thought, "I have to bring out insights. There are ways I can..." As I'm doing my manual review of Dex.
So what I'm doing is just putting PDFs into a local file, processing it through ChatGPT, getting ChatGPT to output a load of analysis into Superbase. Now, just because I wanted a bit more robust than Notion, which I'm finding a bit frustrating.
Superbase is easy to use, so it's fine. Then I do a manual review of what the AI has outputted because I will have differences of opinion. It helps me target. I'm doing them in batches of five. It helps me target the prompts a bit more and work out where there's detail missing or things glossed over or assumptions being made.
As I'm doing that, I'm trying to then flag where there's a really good team slide, for example. So I'm trying to find exemplars for bits of content I can put out and a way that potentially the Pitch Observatory can be a page on my website that people can go in and look at and see.
Here's a great team slide because it does this and starts to self-serve for the people who can't afford me, and hopefully, that's too time-consuming for people who can. So that's the whole point.
As I was doing this, I thought, "If they're able to search this thing and look at breakdowns of public decks because, obviously, I can't do that for every deck that's in there, but see breakdowns to the public deck, a score report, and analysis of it."
Should there be a way they can ask it questions rather than just filter and search and stuff? If there is, should I then incorporate things like Josh Wolf's Lux Capital Q3 2025 investor letter or McKinsey reports that are relative to hard tech and things like that, as we've discussed before, having a knowledge source?
Then I was thinking, and this is how... Because there are so many... Then I know that I'm overthinking it, but if you can help me calm the madness in my brain, then I was thinking one way of looking at this is for there to be an option for people to upload their deck and get a free, slim light-like, streamlined report, not the full thing.
They'll be able to see full reports on other decks so they can see the depth of insight they could get if they work with me. But they will be able to see... They'll be able to upload their end deck and get a report.
What I was thinking is one of the columns in the thing is, "Investors who invested in a deck that got funded." I don't want to overdo it. There's obviously just crunch debt crunch base already and things, so there's no point in me overdoing too much.
I wondered whether one of the ways I could reach out is to VCs if you're happy to share your investment thesis with me, then I would be able to... When people upload their decks, they'll be able to see which VCs have an investment thesis that overlaps, so that you're getting more targeted introductions and the founders are being more targeted than who they talk to.
As I said out loud, it sounds a bit... I think that might be something further down the line when it's actually more... When it's got more reputation as a reliable, useful source of information. Then it becomes desirable for them to be part of it.
That's what I think.

**Ray | 36:31**
Yeah, I think that it is... I think asking them their investment thesis is useful. I think using that information for being able to feedback into here makes it a more useful tool and then eventually being able to feed that back, you know, around... But giving them more cold deals though I'm not sure is the strongest sale.

**Ellie Rofe | 36:49**
Yeah.

**Ray | 36:53**
I think what this is really doing is demonstrating your own, you know, commitment to the craft and the knowledge in the industry. So like I would I think it's great let' to do more of that.

**Ellie Rofe | 37:05**
I do think that is the biggest signal that comes from it is that someone lands on my page and it's just the page it is now. Then it's like, "Alright, okay, well, she clearly enjoys this. There's lots.
You know, this feels like a nice slide deck. Whatever. Someone sees that there is a repository of like a hundred pitch decks that have been analyzed and you know, that is searchable, then it feels tangible.

**Ray | 37:30**
And obsessive the which I think is a good thing.

**Ellie Rofe | 37:32**
Yes.

**Ray | 37:34**
Like you obsess over this stuff, you obsess over picture text. You think they're really interesting. You have made your website into one of these things, if that is what you're selling to be, you know, putting that out there as like the say that you're all over it, like, okay, you seem like the really obvious person we want to talk to about that, right? You're not the cheapest person, but you're going to be the. The one who's.
You know, you. You've done this, you've been thoughtful about this. You're, you know, somebody else might say, well, I know how to make a really nice pitch deck. And I sort of talk about this personally. You're like, yeah, that's a good point, you know?
And, you know, if you if you're looking for ideas about how to think about a pitch deck. I actually have a what I call the Pitch Observatory, which lets you look at, you know, what hundreds of them you found. 50 more you know, and the that you can surf through see you know see some analyzes on it and you know just be gain some inspiration and then we I've got my pitch what we're calling analyzer judge.

**Ellie Rofe | 38:33**
Yeah. What have I called it? Can't remember at this point, but yeah, something like that. [Laughter] Bed jury?

**Ray | 38:44**
Because it should be more than one persona analyzing it.

**Ellie Rofe | 38:49**
Yes. Because there's more than one angle. I do.

**Ray | 38:52**
That's right, yeah, you've already got that. So I just heard that there's just a little bit of, like, you know, packaging around that.
And like, I think you've got yourself something that feels, you know, richer. You know, the anyway, but the Pitchtech and the Kilsey but the you it just it all seems to tell a story that's like moving in the right direction.
And I think about, like, that story you told about the materials, you know?

**Ellie Rofe | 39:20**
Yeah.

**Ray | 39:20**
Woman right. I already went this other way. Well, that's because she had the conversation first and committed to it. But she had looked at both your websites before she died of those things and her...
Thing is, your website wasn't telling her a story that was like... Well, it may even have been a better story than the other one, but it wasn't so much better that it won the... Person first game.

**Ellie Rofe | 39:45**
I think she looked at mine after she'd confirmed the vendor, but I could be wrong, but yes.

**Ray | 39:50**
Well, in which case, maybe there's absolutely nothing about that. Or, you know, whatever.

**Ellie Rofe | 39:53**
Yeah.

**Ray | 39:55**
There are all sorts of little angles on this. But my broader point is, this creates something where they can be discovering more about you in a much shorter period of time.
I don't think it doesn't have the feel... I mean, I use little lines like, "Pitchtech," but the other North Star should be... This is not something that should be a Massive, months-long project for you.

**Ellie Rofe | 40:17**
No, and that's why I'm trying to process things faster. And so I'm trying to think of, like the hour long, like, experiments, sprints, whatever I do to get this up as quickly as possible.
Like if I can get 50 up by Monday. Fantastic. Like that's, you know, even back. Excuse me. But that's where I'm so it's a sort of MVP really, which is just the initial start is just getting them up there as a resource as a thing showing analysis.
And then the next step, I guess, is the submission. So people being able to put themselves in front of the pitch jury and see what comes back. That's a report which effectively is just retooling the process I've already got in place for ingesting all the other pitch decks.
So it's not particularly difficult. It's just adding a couple of steps around grabbing email addresses and managing the upload and stuff and how the report returns to them. So that's the first step and then the second step and then after that, I think it's just marketing the living hell out of it whilst continually trying to get more decks into it to create more impressive machines and more useful stats across multiple different angles because once you have...
So there are so many different parameters for what's useful, what stage it is, what geography it is, what year it was, what vertical it is. It's not there. There are lots of different things that would be... You could get a thousand decks in there and still not have great comparatives for energy tech in 2024.
So seed or something. So that's where it's trying to build. Then I think it's just what I'm hoping is getting that into place as quickly as possible with the goal of just across December when people aren't as busy and they're not at loads of meetings and stuff. Getting them to put their deck into it and hopefully getting some leads basically and positioning myself during quieter times when other people might not be posting on LinkedIn as much. Just having interesting stats and content and positioning stuff to put out there.

**Ray | 42:56**
Yeah, I think there are carousels about this. There's like, you know, infographics about this. There's the, you know, Nanna Banana does that now very well. The but yeah, the it's the data asset, right?
If you have a data asset, then you can be squeezing that data asset for all sorts of things that create value. You know, along the way you can repeat yourself. All that stuff is totally fine. So I love this thing existing for you and just I would you know how it can be done with fewer of your hours, right? Not just like we got to do it faster. I got to put in more hours today.
Like, how can it be fewer of your hours today? That would be.

**Ellie Rofe | 43:37**
Yeah, absolutely. Do you...? I know this is a detailed question, but do you know of any great...? One of the things I end up sinking a lot of ours into is UX.
Because I get there, but it takes me a while to get there with things. Like with the pitch, like with my website, I get there, but it does take me a few iterations and stuff. What I saw someone do very effectively was create using Gemini the new Gemini 3 in the studio. They created a really impressive superhuman but for news mix. Now, I'm not suggesting that I'm trying to create a whole app, but have you seen really good UX in terms of this kind of resource, this repository that I could just go and replicate and have spun up?

**Ray | 44:39**
Well, you've seen how crappy the UX is over a crunch base, right?

**Ellie Rofe | 44:44**
That's not my favorite thing.

**Ray | 44:47**
Yeah, and the thing is, like the sort of I have. Okay, you know, first answer is no, I've not seen gorgeous you know UX for this because what happens as you increase your data density, and you know, you want to support multiple and somewhat heterogeneous data you have you know you wind up need to make more accommodations, you know, for it.
And that's one of the reason why Crenchbase looks the way it does. And what people really care about is the data far more than your nicer presentation of it, right? So with the good enough presentation plus excellent data wins over a gorgeous presentation and mediocre data.
So I think that was the observation in the past, but I think that's one of the reasons why it doesn't necessarily look as gorgeous as the heterogeneity is actually a big piece of that. Now, if the slide share...
I mean, the way that LinkedIn handles slide share, not super beautiful, but very transparent in terms of... Okay. You can find your slide share. You'll find your presentation. Then you can get through them and give your commentary and get out of the way. I'm not sure it's going to win Massive design awards, but what I find in general is the things that win Massive design awards are not the things that are... They are...
Because they picked their data problem to be one that would respond well to design, and that's not usually what we get to do.

**Ellie Rofe | 46:12**
Y yeah.

**Ray | 46:18**
In your case, you've got this gorgeous data and insight.
I think that the data is what will make it gorgeous, not the design as much and not for nothing that does feel like a lot of this... What I hear from your tech stuff too.

**Ellie Rofe | 46:34**
H.

**Ray | 46:35**
It's about the storytelling.
Then the design gets easier. It actually gets easier to make it look good as your story becomes clearer. That's actually one of the reasons why an observatory has a harder time because the data is heterogeneous.
If you were doing it for any one deck, it would be easy. Doing it for 50 gets hard.

**Ellie Rofe | 46:54**
Yes.

**Ray | 46:54**
It's an acrena problem, right? All unhappy families are different.

**Ellie Rofe | 47:05**
So I'm wondering whether one of the ways to... Yeah, it's understanding the analysis, how the analysis is presented in a way that's digestible rather than just insanely long blogs.
I guess it's just a vertical thing, but... Yeahs.

**Ray | 47:27**
Partially, if I might, Gemini is really interesting for this because it can take something that's... I've done the whole instantly along blog with AI to Gemini or even taking my own 800 board post and turning it into something like that.
Then the next level up is like, "Can you...?" This again, this is more like the you're talking about Gemini before, but particularly the newest image generator one is actually very good at doing infographics text in AI was very bad, right?

**Ellie Rofe | 47:58**
Yeah.

**Ray | 48:00**
It does a really good job, shockingly good. Not through giving it special prompts, but just comprehending this idea, organizing it, and then being able to convey... Again, I'm not saying it can solve the same way for everything, but provides you with a way of maybe getting a little bit of scale on this question of how to present this.
Because if you have the words that you like, but they're just going to get overwhelmed with all this... Your question really is how to provide it to them in different modes that would be easier for them to consume, which is the essential problem of a pitch deck. Anyway.

**Ellie Rofe | 48:35**
Yeah. Yeah. Yes, that's true and it is in I put I used Stitch the other day, so yeah, another Google product.

**Ray | 48:44**
The Google product... I think it's fantastic because the more AI is able to handle all of this detail work, the more value it puts into your higher-level stuff.

**Ellie Rofe | 48:47**
Yeah, I hadn't really consciously clocked this, but I asked it in text to use the recool letter, which is a specific font, and it didn't use it because it didn't know what it was.
Then I uploaded an image with some recoll type in it, and it then reproduced the entire font in subsequent images. So the... I mean, it couldn't even produce letters and now it can actually reproduce a font, it's quite impressive.
So yeah, okay.

**Ray | 49:30**
Because you're like, "Man, how am I ever going to make... How do I take your level of insight and turn it into what I need? This just seems like so much work and not for nothing. You're talking about some of these AI tools being suitable because I think that just increases the value of what you do even as it might decrease the value of that other person who the materials woman hired."

**Ellie Rofe | 49:43**
Yeah. I have been wondering a lot whether all pitch decks in the future will just be HTML of some sort rather than physical slides, because that's what AI produces so much better than anything else.

**Ray | 50:08**
With AI vers the HTML versus though.

**Ellie Rofe | 50:11**
Versus trying to use it in PowerPoint versus even something like...
I know that they're still using it, but they're just not doing it very well. But I find Gemini a bit frustrating, personally, but that's because I'm probably a bit of a perfectionist on this.

**Ray | 50:28**
Well, as a professional right that you... It's a robot one. What you want is a bicycle.

**Ellie Rofe | 50:33**
Yeah.
But yeah, there is... I just think there's a point at which AI doesn't create things very well in things like PowerPoint, and it doesn't create... PowerPoint has its own style sheet built in.
AI is trying to use CSS and then when you download stuff from AI, even when you say, "Right, I'm going to convert this from ChatGPT, for example, which produces slides using Python and then put it into a PowerPoint slide." None of the style is sitting in that template.
So people who aren't PowerPoint experts are not going to be able to work with that file very well without it becoming an absolute madhouse of colors and fonts and things. And I think that the casting that Gordian knot is just things will be in HTML which then leaves it easier for things like DocuSign to actually analyze things. Analyze
the dwell time and things.

**Ray | 51:34**
That's a good point. Gamma seems to be solving this problem to a slightly higher level of abstraction than the HTML, right? That allows them to export to these different formats. Google Slides, Gemini now has fairly native integration with Google Slides, which is mostly an HTML-based system, but exports these others. I certainly take your point.
I think that's a really interesting direction. Stuff and not for nothing, I think that's good content for you to be talking not just about how to do X but this is the direction of things. We get the position to a little bit more as thought theater, which elevates you, right?
So instead of being that I'm the person who's in the scrum, you're the person who's advising them about that at a higher level, that which the review work, the storytelling work, and what have you...
Yeah, I'm just reminded of the story from the car industry, right? About all these robots taking over the factories. It radically increased the compensation of car designers because now the best car designers in the world are worth a whole lot more because there's so much leverage on them.

**Ellie Rofe | 52:34**
Yeah.
Yes, I would love to not have to spend hours creating slides.

**Ray | 52:50**
I appreciate it. You look at some of these things, it's not quite good enough. Fair enough. Yeah, I'm not trying to suggest that you should be training yourself to say something that's good enough.
That's not good enough, but... My goodness, the stuff's getting much better.

**Ellie Rofe | 53:02**
It is getting better. Yeah, my fundamental issue with things like Gemini and it's the PowerPoint thing. Right from the very start of PowerPoint, existence is the first thing it provides you with is a headline and some bullet points.
That's literally the default slide that everyone for 40 years or something has been trained in. A headline and bullet points are okay if you're doing a company update internally or if you're doing something that is not high leverage.
But I was reminded of it when Mitch did his half of the talk I saw with Demetrius, and he had slide after slide of bullet points. Two days later, I could not remember what he talked about because there was no visual hook.
There are lots of reasons why too many bullet points are really bad. People are reading instead of listening to you. You can't read and listen at the same time because they're both auditory processes and you're not leading the room. Then you're not being listened to properly, which puts you at a disadvantage. Immediately, you're not just like a meat sack standing in front of slides that people are looking at.
It's not a particularly great dynamic for you. I think Gemini leans too heavily into that because it's trying to fix a design problem rather than a communication problem.

**Ray | 54:24**
Yeah, that's a really good point. Like, I've used Gamma to make an infographic, but it doesn't come up with the infographic. It was like, hey, I have an idea. Like, here's. I can structure something.
And I've. What I've learned is like here they structure, and then they can go implement that structure. Not always perfectly. Like, it doesn't tell the difference in lower left and lower right. Whatever.
Like, I was trying to get a do wheel, but the but the you're quite right. And like, that idea of, hey, here are things that are still hard, right? They're worth talking about. I love that. That sounds like great content, too.

**Ellie Rofe | 54:57**
Yeah.

**Ray | 54:58**
I'd love to hear more from that about you, and I suspect others would profit from that as well, but I think that's all fantastic stuff. Is there a way that I can be of better assistance to you in the coming week between now and when we talk next Friday?

**Ellie Rofe | 55:14**
I would love to send you the website when it's done and just see, maybe a go/no-go. And any top three priority fixes so that it's less for you to have to go through the whole thing and give me feedback on everything.

**Ray | 55:25**
Two.

**Ellie Rofe | 55:30**
And I won't then get into analysis paralysis.

**Ray | 55:34**
Sounds great. Yeah, I would. I would love to see where we have whenever we have it.

**Ellie Rofe | 55:39**
Yeah.

**Ray | 55:39**
If the observatory is coming along, you're at all interested in sharing...
I'm a glutton for data.

**Ellie Rofe | 55:48**
Yes. Okay, I will share. Perfect, thank you.

**Ray | 55:52**
Fantastic. Well. And until then, do you have yourself a fantastic weekend? And we'll talk again next week?

**Ellie Rofe | 55:58**
You too. Take care. See you.

