# Ellie and Ray Zoom - Dec, 19

# Transcript
**Ellie Rofe | 00:08**
Ray, hello, how are you?

**Ray | 00:12**
Well, it's looking very Christmas Eve behind you.

**Ellie Rofe | 00:15**
Yes, it's exceptionally Christmasy. [Laughter] I love it, I really love it. We didn't have a Christmas tree here for a few years, so it's so lovely to have one again because it's just... Yeah, warms, micro-ckles.

**Ray | 00:29**
The, that's, yeah, very nice. The. It is something we actually haven't had in our place for the time that we have been here. Yeah, I like having a tree in the home. Has not been my idea of a favorite thing. Fortunately, I have relatives for whom it is their favorite thing.
And so the boys get to go like, he love Christmas tree. So wor.

**Ellie Rofe | 00:51**
[Laughter] I love it. The smell, especially the first few days, God, but then...

**Ray | 00:58**
A real te.

**Ellie Rofe | 01:00**
REALTREE. Yeah, I can't. Eventually, I think we'll just grow one and just have it in a bucket that we can bring in and out and then not keep chopping down each year.
But, I can't stand plastic trees. It was my. My MoM. My nm. There's like AA long history of that being like a central part of Christmas. So, yeah, it's it really does, like, bring me sustenance on some level.

**Ray | 01:21**
Firefoxt. Great. So it has been two weeks.

**Ellie Rofe | 01:31**
Yes, it has.

**Ray | 01:34**
And what? And how has December been treating you?

**Ellie Rofe | 01:41**
It's been much better in the last week. So I think I said I did that.

**Ray | 01:45**
2.

**Ellie Rofe | 01:51**
I tested that Mark Manson thing just out of interest. Some of the questions asked were very enlightening. I didn't carry on with a subscription, but it was really interesting, and working out the micro moments where I might go awry and get distracted. I was thinking about how I really should have created more. There should be more output for the last six months than there is.
Some of that is just inefficiency, some of it is distractions, and some of it is lack of focus. A big thing, though, for me is just lack of finishing. Something of just pushing through. So, that really helped me realize that external pressures really make a difference.
This week, knowing that at 08:00 am every morning, I'm going to be speaking with Justina, and I'm going to be telling her how many tasks I actually achieved the day before and not allowing any fudging of that and not going,
"Well, I did 60% of it." Just being really strict has created a sense of determination and push through that I think I just need externally. I just have to admit that is the way, at least.
Maybe three, six months of this. Maybe it just internalizes more.

**Ray | 03:21**
He?

**Ellie Rofe | 03:22**
I realized the rate of output and decent quality output when I was working on events and the internal energy I had when I was working on big events because they are so deadline-driven and because there are so many people depending on you, and they are quite creative as well.

**Ray | 03:45**
Yeah.

**Ellie Rofe | 03:49**
A lot of the time, you're finding creative fixes for problems. You are doing creative production work.
Like designing the event itself and the graphics within it or whatever it might be. So, AI realized I've tried to follow up with Paul on that event because I thought I really actually... There's part of me that really enjoys working on events as long as it's the right event, so I should try and do that.
BI just thought I needed some mechanisms in place to keep me on the straight and narrow. And I was wondering... Tell me how you feel about this because obviously, it's important for you to feel like this is worthwhile. I was wondering whether we could change the rhythm of the coaching so that every other week is a slightly different focus.
So I have discussed a project that I'm going to work on for two weeks, and the check-in in the middle week is more accountability and review because what I've realized is that I think sometimes in these sessions because my brain hooks on to ideas easily, and I'm like, "New idea."
Then I go off and start becoming like an idea-generating machine after the sessions, and I'm not actually executing enough on certain things. So I wondered whether we could switch the cadence so it's like ideation, come up with a project, and then I deliver on a project for two weeks or something like that.

**Ray | 05:40**
Sure. Well, let me ask you this. Why two weeks?

**Ellie Rofe | 05:45**
Why two weeks?
It's a good question. I think in my head, I just think most things I'm doing end up taking... Not end up, they end up taking much longer or don't get finished.
It feels like that is a way of not rushing something, I guess. But if you think that a weekly pressure is better...

**Ray | 06:36**
Well, it depends on what you think is better, right?

**Ellie Rofe | 06:37**
I guess break something down.

**Ray | 06:42**
A lot of this comes from self-knowledge.

**Ellie Rofe | 06:45**
M.

**Ray | 06:46**
I do wonder a little bit whether two weeks was driven by the idea of having alternating coaching sessions.
And that that's having an external consideration to drive something which actually, you know, I hear what you're saying in terms of not finishing, you know, and I think that would be a reasonable thing for us to be working on here.
And it's one of the reasons why I sort of lean into this whole studies hell ship thing, because shipping is finishing, right? When you're working with a client, of course you're finishing. You do the thing for Mattie or whatever, right?
And you're. You're finishing. Like. Wait. That felt good because I just gave that to her. And then you do the study thing and it kind of wanders off. And you do the selling thing. You kind of wind up not putting up the post or whatever.
And like those and one of the reasons I encourage like that cadence right of you know, putting out those posts is because they are internally driven by you and then you are shipping you. I know, I say.
So it's a ship, but like you're the eat. You get these things you have knocked out the door you are in a habit of finishing without having it come from a client. Because what you're talking about with the event is all these deadlines come up. Whatever. Yes.
It's because you're in the context of an initiative that has pressures, and the initiative is in making you ship. But you're not making you ship. You're not self driven, you're externally driven. And people who have, like, day jobs are being externally driven. They're being told what they need to do and then they go do them right. When you have a client, they have what they need and you're doing it.
And you know, they're looking to you for leadership and advice and what have you, but their needs are what's then driving it. But what you're doing studying and cell. It's not like that. And but I think part of the reason why you sort of look back, hey, what have I actually done? Is because, you know, you've had less to ship because you're still building things up because.
Because these first two become preconditioned. But these first two have that. You know, the fire's got to come from within part and your use of the accountability, you know, higher I think is really cool.
And I think and I'm. I'm glad that's sort of helping out with that. You talking to me is helping out with that. Part of the trick of talking with me is that I'm an idea factory, too. And the. And that means you start to come up with, like, more stuff and more ways we can do things.
And. And I'm glad to have the conversation like try to focus more on the accountability part, but when I look at this, I am not, you know, I'm seeing study. Lots of work at Mattie's Desk Mattie's Deck. No, that's not study, that's shipping.

**Ellie Rofe | 09:17**
But you said to me the other week, "I'm not getting paid. It's not shipping."

**Ray | 09:21**
Well, you're not being paid yet, right?

**Ellie Rofe | 09:22**
Yeah, and Mattie might not be paid.

**Ray | 09:24**
Okay, is that risk work? You mean okay, but it's at risk, they're still shipping. You're getting paid because there isn't an agreement for compensation. Now there's risk there's always collection risk. You can be doing work for a client who's never going to pay you, right?
You can say, "Hey, they'll pay me $10,000." Then they just ghost you. Of course, this has happened to you. This has happened to all of us. Right? So the fact that we might not get paid doesn't keep it from being shipping.
It's client-led. So one talk about the whole compensation thing is that when there's a compensation structure in place, the work looks different, right? So from where does Mattie's stuff fall into the shipping category because there's an arrangement by which you can get paid?
It is being driven by the needs of the client. It has... You're getting less momentum. I think when you do that, you find... Wait, all momentum is sitting in Krisp, which is perfectly normal. I think that's true for most people.
Then the hard part is getting activated on the study and cell, which is the reason why I talk about the books and whatever.

**Ellie Rofe | 10:27**
Right.

**Ray | 10:33**
Like what? What can we do to sort of move the. Move the ball? That because I don't think you need accountability help to get, you know, batty stuff going.
That's good, right? The sales part, like getting yourself out there. By the way, I think you've been doing delightful work on LinkedIn. I've really been liking your posts, and, I'd love to get, you know, more eyeballs on them, but I think we get that through consistency, through young people, and there are techniques for that.

**Ellie Rofe | 10:51**
Thank you.

**Ray | 11:02**
You have like this one.
And like when I look at Cell like that, that's those things are necessarily pushing, right? Those things are things that you're shipping. And one thing that I really like about Cell is that how often it is a, you know, thing that you can ship on a week to week basis. Wait, I shipped three posts on LinkedIn. I shipped four, you know, two YouTube videos I shipped, you know, these five, you know, outreaches, right? In terms of emails, right there are these little things that give you that little dopamine head of I got something done. They can feel quite stressful to do. I totally get that. To push that button and say I'm gonna put that into the world, but the but then they're done you get those it is so I think that your accountability partner seems to be helping out with that that's great.
That's something I can be paying attention to. Is something I've asked about before. And then. And then we get to study. I look at study here and I think it's really under indexed. And I think your story of not getting things done kind of boils down to study having fallen off the cliff. Yes, one of the things in the study was really shipping, right?
That's why you're getting momentum on it. And we part that comes from for this I you know, thinking about the Demetrius thing, I think that's good. That's a good study question, but I'm not seeing study initiatives in here.
The two study initiatives that you've talked about before that I think we've been relatively good ideas are the Observatory and book reading, both of them. I mean, finishing a book is shipping that counts as finishing anything. You have now downloaded more ideas in your head. Sure, it's more... But more passive than other things you have created as artifacts.
But I have this. I think you can tell me. I'm just repeating myself totally here, but I've got this learning framework: learn, experiment, build, teach, and the... When I look at this, I think the Observatory is built.

**Ellie Rofe | 12:58**
Yeah.

**Ray | 12:58**
Right books are okay.

**Ellie Rofe | 12:58**
What's the part of the issue?

**Ray | 13:02**
Well, actually... Then maybe one that it sounds like you already talked about some reserves now, but I shut up for a minute and got your thoughts and brain output on that.

**Ellie Rofe | 13:11**
No, I think that's the element where... You're completely right in the... Yes, external accountability for delivering stuff is there, and I hit deadlines and I work... That's fine.
I will if I need to work over the odds to get something done or I want to make that the habit, but that's there. There's a habit of pumping stuff out on LinkedIn that I need to get into, and it's not even particularly to do with it being nerve-wracking or something.
I think I just find it bit boring. So I end up avoiding it. But that's the habit, and I need to get more excited about it. I think some of that is to do with shaping who I'm connected with and who I'm listening to, which I'm trying to encourage and curate a bit more as well.
So there are those two parts. I think the thing I'm really struggling with is what you said in terms of study, the study that drives into marketing that creates the pitch observatory. I think the problem I have is those things.
If I don't have a deadline, then I will just keep morphing them and playing with them and experimenting with them. It's one thing to read books and just not have any external visible output from that.
But things like... I've half-planned a VC survey and then go, "Well, I just... It would just be too much cold emailing." So that just ends up by the wayside. I've half-done the Pitch Observatory, and then it ends up as a hybrid.
Then I've been looking at it, thinking, "Well, how useful is it to retrospectively look at Deckx from 2020 and things end up in this kind of mire where things will drag on, and it's finishing stuff like..." I was reminded of a friend who, sadly, I was in touch with because she lost her dad recently.
But I haven't spoken to her for ages. I was reminded of her saying to me about ten years ago, "If you ever finish anything, you'll be queen of the world." I was like, "Okay, fine. This is a pattern."
It's not unique to me. I know. It is certainly not unique to my whatever brain structure or deficiencies. But the problem is, when there are more ideas coming through, it's very easy for me to go, "That's a better idea than this one. I'll just go and follow that one rather than push through the messy middle of a project."
That's where I think that's the pattern I'm feeling, which has been a pattern in my past, which is like, "This has got gluey and lots of questions."

**Ray | 16:16**
Yes.

**Ellie Rofe | 16:24**
I'm... Let's go for the exciting thing.
Because I can get really amped up and work like. You know, like a fiend on something, then?

**Ray | 16:36**
Okay. It's your hot seat. This week in the Mastermind, if I might.

**Ellie Rofe | 16:40**
Yes.

**Ray | 16:44**
One thing you could do here. Then we can come back to how we do cadence here. But I'm trying to think about how to help you even on a short-term basis.
I think the two-week thing feels like a compromise.

**Ellie Rofe | 16:54**
Yp.

**Ray | 16:55**
What you've got is a bunch of assets, right?

**Ellie Rofe | 16:55**
Okay.

**Ray | 17:02**
That are sitting inside not starring the world right now. You have too many ideas of how they create a whole lot of value, and that's creating a traffic jam, right?
I think what you want is a couple of clear... Let's ship these things, right? So that you get the good, you don't get the perfect, but you get profit as a result, right? You turn these... You take your geese, and you get to a couple of golden eggs, and you can put them into the world.
The golden egg will never be as valuable as the goose, right? That's just not the way it works. But you want some help from other people to pull this stuff out of you? I would look at this a little bit less...
How do you whip yourself into finishing things? I've heard many people describe it that way. What I've usually found is that you have these pieces that are pretty done and pretty valuable, and the gap has a lot more to do with your expectation of what it should be right rather than the value of what is. I gotta tell you, I'm talking to a company right now that is breaking my heart because they are stuck on an idea of what they're supposed to be, and they're sitting on this mountain of super valuable assets. They have staff, they have a bankroll, they have talent, and they have a brand in the market.
It is just not going the right way. They're just bleeding out cash-wise. I think a lot of it has to do with they will not let go of the assets to use them in ways that are outside of what they previously conceived.

**Ellie Rofe | 18:54**
Yeah.

**Ray | 18:54**
Now you can see evidence of this, like a bunch of what I call side quests that they're doing right, these little features where they're touching on things. Boy, if they follow through on that, it would be really valuable.
But the problem isn't that they're not following through on the individual things. The problem is that their overall view of their business as a singular product of what it's supposed to be as opposed to the collections of assets that it is.
If they're willing to break up that idea a bit, they could unlock a lot of value and probably will propel themselves into the next thing. I don't know if that's the situation you've got, but it does seem like a familiar pattern.
So making use of the mastermind, you can be sharing some of the stuff, and you can say, "Hey, that looks really cool." Then the discipline is... I can be helping with this in the room. Not trying to create the one ring to rule them all.
All right? Not trying to... Not worry too much about how all this stuff connects and how it can become one big thing, but that's really cool. Let's do that. Then it's not... How can I do that in two weeks? I do that in a day.

**Ellie Rofe | 20:00**
Yeah.

**Ray | 20:01**
Robert. Robert sometimes talks about, like, having seen me attack a problem.
Like, he'd asked me for help with a technical problem, and I think he was a little scared at the end of the call because I attack it with, you know, ferocity and with, in intensity. And, you know, Robert's line was, Man, I don't want to be that problem.

**Ellie Rofe | 20:23**
[Laughter] Do you have a recording of that call? I would like to see it.

**Ray | 20:28**
That's an interesting point. Let me see if I can dig that up. I'll share it with you because it was a one-on-one call. But I'm glad to share it with you. He'll appreciate that, too.
The reason I bring it up is that the reason that I do that is because I want to solve the problem today and not tomorrow.

**Ellie Rofe | 20:48**
Yeah.

**Ray | 20:50**
Right? There is an opportunity through just turning the wheel faster.

**Ellie Rofe | 20:50**
Yeah.

**Ray | 20:54**
And that's a lot of what he was seeing was like, say, that wasn't right. It's like, no, what's the next idea? And like that whole parade of ideas getting focused on a single problem, but for hours, not for days, can produce a lot of value. Now that by itself might be something sort of requires a little bit of governance.
Maybe that's sort of hard for you to be doing when you're sitting alone in a room. I'm glad to help out with that. You know, like if having like, you know, I can imagine something where like, you know, we when we talk about changing the cadence.
Like having a thing where we have a day where we meet three times. All right, every I'm getting going with. Here's plan midday. Here's where I am to end of day. Let's, you know, and then probably there's some more stuff to do after your end of day cause my day.
And then, you know, then that's sort of guiding you into the evening, and then it puts you in a position that you're much more able to ship the next day or the day after or whatever that would be. That I think is the direction of the opportunity.
Do you know how to use these AI tools? They let you go so much faster, right? The thing is, it's not like you need... This isn't inventing from a blank sheet of paper. It's not like, "Man, Ray, I can't go from zero to something." The thing is, I'm pretty sure you're 80-90% of the way there for end things already. Let's take one.
Maybe you don't even recognize what the thing is yet, because it's part of the rest of this. You can use that combination of the mastermind of your accountability person working with me to then move that through.
So it's not like, "How can I get this done at all?" Not even "How can I get this done faster?" But "How can I reconceive this?" I've got something that I'm spending months or weeks on, something I'm going to spend a day on.
Then once you've done that, one, you're going to be exhausted, and two, you're going to be like, "Why can't I do that again?" Because it's a pretty good feeling to then get that done. All right, I hope... We'll find out about that.
That's a direction of opportunity that I would wish for you, and the fact that means more of my time in the course of working with you. It means three half-hour calls. Whatever. That's all fine. It doesn't have to be on Friday. We can do another day of the week. Let's figure out the sequence that would work for you, and you've got access to my calendar. We can totally do it.
Then you're turning the wheel and...

**Ellie Rofe | 23:16**
That sorry, I interrupted.

**Ray | 23:17**
Yeah, no, I sorry, I was only saying that I'd be glad to do that more than once. You know, like, just the my your point of, like, feeling like you're not finishing. I suspect that means you've got a bunch of stuff that you're almost there on, and if I can help you get from almost to actual, I'd be happy to.

**Ellie Rofe | 23:37**
Yes, I think that would be really helpful. I think a huge part of it is... I can't remember what your term was, but I call it the "everything project."
So the pitch observatory was like, "I'm going to get some pitch text. I'm going to analyze them according to a certain amount of things, get loads of meta statistics and stuff, benchmarks, and... I then overthink that because as I'm looking at them, I'm like, "Are these the actual decks that people presented?"
I think that is a potentially poison data source that's something like... There are no financials or whatever. But even then, I get the data, and I can probably try and interpret the data, but then I'm like, "Well, these benchmarks that I'm using would be useful for decks I'm working on."
Then I start doing that. Then that becomes a thing where I'm like, "Well, I could just start using this for me in my business when I'm bringing in Maddy's deck. I just assessed it personally." Then I use that to build an assessment tool.
Then I'm like, "Well, that assessment will be really useful for a lead magnet for other people to bring them in." Maybe I can start testing that. Well, hang on, shouldn't this be a working tool?
Because it's not just about assessing the deck, it's about fixing the strategy and then how that feeds into the narrative. Then once you've got the narrative, then you could probably get something to start creating the deck.
It's just BBB, and then suddenly I've got seven different pieces of something that's not quite there on any of those different pieces and is trying to be the "everything project." And the AI tools are a double-edged sword with that because it is so easy to get them to do something.
But they're actually not that great at finishing because if you're not careful, if you haven't planned it properly, they get into the "bub" territory or destructive editing or that kind of thing.
So then my weakness is being exacerbated by that. [Laughter] So yes, I think I do get excited by the idea of just going right. This is what I'm doing now and having the forcing function of going. At this point, I will be having another call with Ray.
So get something done. Just push it out. It's not like all the optionality in the world. It's just a straight line.

**Ray | 26:15**
Yeah. Okay, so a couple of things as I listen to this, I hear what you're saying in terms of the AI.
The AI is a puppy.

**Ellie Rofe | 26:27**
Yes.

**Ray | 26:27**
It wants to make you happy. I actually have in state change.
I've got the state change assistant's AI for people occasional use or get a read of me. I'm now getting the what I think is a compliment that sounds like me but I asked how... Why does it sound like me? Well, I've picked a cranky mentor.

**Ellie Rofe | 26:41**
Okay.

**Ray | 26:47**
Yeah, I have. I've got a number of different... Persons have different tools and biases, like one more expert in Zano, whatever.

**Ellie Rofe | 26:53**
Yeah.

**Ray | 26:53**
But the cranky one I actually found to be very helpful because the cranky one turns the whole puppy thing on its head, right where it gets rewarded for poking me in the eye. That caused it to go work for flaws and what have you...

**Ellie Rofe | 27:01**
Yeah.

**Ray | 27:03**
And I find that the dyspeptic AI as much as that might be terrifying from a, you know, end of the universe point of view. Is. Has been helpful for me. I've found it helpful to be asking it what's most important, what matters, and then that gives me more of a North Star, because otherwise, hey, could we do this? The answer is yes. Which part matters?
That's focusing, right? And like, you know, when you're having conversations with people, I'm sure you have, like, expansive questions, you know, focusing questions, right? And there's a similar discipline of using the AI to be, you know, to know what kind of question you're asking and therefore which direction the puppy is. Can be perfectly happy to run.

**Ellie Rofe | 27:44**
1.

**Ray | 27:45**
But I can be... Human beings can be helpful with that too. As I listen to you, I think there's an observatory, which is the database, which is like the air table that you set up.
I think that's valuable. I think you should share it. If it doesn't have proprietary information, I think you should share it, embed it in a page on your Nicelyput website, and be something you can share. "Hey, look, I've got a database of X, hard tech and biotech things, and
I've been working my way through it. People who are looking for references you can go check out." Of course, since it contains some of your commentary, it's immediately a selling point for you, right?
Because there's an embedded... Your page gives them... They can contact you if they want to get to it. Or you can do a whole lead magnet thing, and they can get to it if they fill out a form or whatever. You can figure out what all that looks like. My point is it's an asset that exists today that you can do a lot with.
If it is as simple as, "Hey, let's do a session where you are setting up the page and doing that," then you've shipped the page. I think that's something you could easily do in a couple of hours. Probably something you can do well, less than an hour.
But the objective, though, is not to figure out something that you could do in two hours. The objective is something you can do if you do it. You do it in half an hour, and then you go take a nap, and then we have a call. I'm not feeling any worse about it.
If anything, it's better because it's shown that we can cycle it down. What else can I do with that? Well, you have your little machine that makes an analysis of one of these presentations, right? Do you make an interesting analysis? Fantastic. I want a deck of the day, where you can be making use of the observatory.
Now you think about the free content, which is the analysis. You have the CTA that goes along with it, which is, "Hey, go check out the rest of my observatory." The rest of your observatory is what links.
I mean, now you're stairstepping the trust thing, right? Now you have an asset that's working for you, right? As opposed to just your efforts, you're not just playing your time, you're playing like the stuff that you got.
I'm bringing these up, and I appreciate this falls in the same category for you. Keep on giving more ideas. That's not helpful. But there are micro things that you can ship, right? That's why I say it's not necessarily a two-week thing.
Maybe we run through the inventory of this, and we start to look at things and need to be bigger. But I think we've got a whole lot in the house that just needs to get moved out of the house, and at the market, it creates more value.
But, Ray, wouldn't the observatory be better if it could be a chatbot? Sure. Let's still put out the database and then later put out the chatbot because the positive feedback you get from the database is... You want to have the chatbot.
One of the weird things about chatbots right now is I'm not really sure what the easy experience is. Say, "Hey, I want to have a chatbot. I want to have it on this data, and I want to share it with people. What do I do?"
The offerings for that are surprisingly thin. So that puts you in a position to say that's something I like to do when it becomes easy to do. Wait, "Hey, new thing came out now you've got multiple angles of cell, right? You get to use that tool. You get to... And you are in the CAPBD seat because you've got the thing that matters, which is the data. The data is the asset, not the bot. The bot is just a way of taking the golden egg and curving it into jewelry, right?"
That's magnifying the value of the underlying gold, but it's still... If they didn't have the gold, they would be able to make the joy. So I'm glad to do the two-week thing. I'm glad to do the alternate thing, if that's what you want to do. I'm proposing the more intensive thing because I think you get a lot of value out of that.
It would shorten it. I'd be glad to do that next week. I'd be glad to do it the week after. I can see a pattern where you're ending the year saying, "Hey, it took me... It feels like it took me the whole year to finish that thing."
But there's been a lot of stuff that you've almost finished that you can move to finish, and then what we're talking about in 2020-2026 is like, "All right, you built that out there, what's next?"

**Ellie Rofe | 32:16**
Yeah, yes, yeah, I do. I you're right about the two-week cadence. I don't need anything that drags out because then it just becomes a project, mark two, mark three, mark four. Just keep it on going.
Then even as you're talking, I'm like, "Yeah." Because then as I do this, I need to go and contact founders and get them to send me their pitch decks and interview them, and it's like, "Nope. Just focus on the one thing."
So even the space of us talking for ten minutes, my brain is trying to do that. Then, yes, I need a focused space of time to just do something rather than that. Absolutely. It's slightly different.
It's slightly difficult in terms of logistical basis between now and Christmas. It's a bit difficult. Just in terms of availabilities, but...

**Ray | 33:12**
Yeah, sure. And I'm not trying to put pressure on you for, like, any particular day. I'm just trying to say I am glad to be available. To be able to. To help you do what you want to do between now and the end of the year.

**Ellie Rofe | 33:22**
Yeah, I would love to do that on December 30th or something, if that works for you, but yeah, it's just a bit chaotic otherwise. In the meantime... Okay, that's really helpful.
Where I do like... Maybe I will try not... Maybe I will try to do that on my own tomorrow and see if I can just get some sort of boom, let's go hay.

**Ray | 34:02**
I think based on your experimentation with that, you can then be taking your lessons that... I mean, look, you use the hot seat for...
However you want to use it. But I think this... This is a use of it that could be high value for you.

**Ellie Rofe | 34:15**
Yes, absolutely, I agree. Okay, cool. I did have a question. I don't really want to... I want to make sure I'm not treading on any toes or anything because I'm obviously doing some work with Demetrius, and obviously anything that's confidential, then, I'm not trying to pry, but is there...? I'm trying to help him create content. We've worked on who he's talking to. We're trying to work on what his product is and what he's actually trying to do.
I know that it's in flux. So I'm trying to give him scope to be in flux with learning and progressing, but I've given him some exercises to do in terms of actually just writing, and I think there are three layers of issues. One is that his English isn't fluent, so he's struggling.
I think there's actually a cultural shift. I mentioned I studied ancient Greek. Just in terms of the dialogic Socratic way in which they think about circles and... Just a culture, like your language frames your culture. You're thinking as much as you frame the language.
So I think there's an element there, but I don't want to go too deep into that with him. Then there's just a marketing awareness thing. I know that Demetrius has occasionally some perfectionist and impostor syndrome areas.
So I don't know whether I just say to him, "Use AI, and we will try and create an AI project, Claude, for you that will retain your uniqueness and your voice, but will strip out some of this complexity and confusion."
Because I don't know, I have asked him to do some exercises, and they actually came out more confused than the originals.

**Ray | 36:20**
2. No.

**Ellie Rofe | 36:22**
So I don't know whether... I don't know if you have any ideas on how to approach it so as not to demoralize Demetrius. You've worked with him for a long time.
I don't want to demoralize him.

**Ray | 36:42**
So my take is he needs to write it less. He's not an English speaker. Cope is not going to be his strong suit.

**Ellie Rofe | 36:53**
9Y.

**Ray | 36:55**
Stop fighting it. What we need is Demetrius and his, you know, big smile, his strong Greek jaw.
You know. Excited about this topic. Video picture headline button. Get f out of the way. He. I actually tried to get him to use, like, one of those bio websites, because I don't think he should be using a full website at all, because I don't think he the he doesn't have he's not.

**Ellie Rofe | 37:28**
Yeah.

**Ray | 37:32**
I mean, I'm a writer. He will write a lot of copy. I can certainly get myself into trouble with it, right? But communicating via the written word, that's my bag. I'm down with that. Mitch thinks that a lot of us who have... Have a bit more to marketing. We've... Have cotton.
Because we can do copy, and we think about these things, and we think about writing. We enjoy the written word. Demetrius is not, and a lot of his customers don't either, so let's not fight it. How does he communicate right now? What is the way that he's best able to communicate into the market? Two things that seemed to have been working for him: video and events.
So what should be on his... What should be on any site that people are going to? That's three nuggets or Demetriuscos.com or whatever. I would be looking for videos, right, or links to videos back to them, but if they're coming to that from LinkedIn... Wait, there's YouTube bounce.
That's going to sell him much more than his website will. What does the website do? His website is taking orders, so I think the best thing to do with the website is for it to be...

**Ellie Rofe | 38:44**
Hi, did...

**Ray | 38:50**
Yes. You've actually reached Demetrius because he's got a big picture of him. He's not a table picture, but a big picture of him, right? Any work the ideal of probably like a book, a session with them.
If it's going to have work...

**Ellie Rofe | 39:05**
He then added another three or four sections.

**Ray | 39:06**
Yeah.

**Ellie Rofe | 39:08**
I literally just said, "Just do that simple thing there, don't worry about all the rest of it." My rationale was not even just that. He doesn't even know who's talking to yet.

**Ray | 39:17**
I think that's probably right, but then the... But what? I just... The one other thing I'd throw in besides what I just described is the social proof and then done get the... You repeat the CCA at the bottom and that's it.
I think that the more people watch him, the more credibility he has. The more people read him, the less credibility he has. The more his page is based on graphic design, the worse he does. The more his page has the button that allows me to... I discovered Demetrius.
I think he's interesting. I want to be able to take the next step. What's the next step? The next step is probably joining one of those events, right? Then the step after that or if you really want to... Because you're really ready to go, let's book an initial call. I, by the way, gave him our session was a little earlier today.

**Ellie Rofe | 40:16**
5?

**Ray | 40:17**
I fed him an idea, which was that his introductory calls he should just turn into a graph and then send them a graph of them themselves based on what the introductory call was, because he could probably do that relatively low risk, and that would immediately get them linked up into it.
If they're excited about that, it turns them into a more prospect. If they're not excited about that, they weren't going to go anywhere anyway. It sort of becomes qualifying as well. But that's the kind of thing where the words should be. The words are not coming from him. The words are coming from the client. In that case, the words don't come from him, they come from the customer.
I appreciate there's a bit of... Well, you go on the website like, "What's he about?" You find out in the videos. You have one tagline. You look, you help them out with a tagline. Then, frankly, people expect that the market has written the deadline anyway and then get out of the way.
Authentic Demetrius writing doesn't... No, not good.

**Ellie Rofe | 41:11**
No.

**Ray | 41:12**
In fact, it calls itself three nuggets. I'm not sure it really helps them in any other way, but all that is obviously just going to be him.
So I'm not sure AI slop is the way I do it either. I would just not have the words and... If what you're doing is you're helping him by through subtraction rather than improved addition, it's a little bit like what we just talked about relative to your shipping stuff.
I think we're all going to see... Maybe this is just me seeing the same thing happening because I'm stuck on an idea or whatever. But I do think there's something somewhere in here where if he subtracts, he will do better. Subtract, tighten it, and then put it down and stop worrying about it. What he needs to do is work on his YouTube channel. What is the YouTube channel of writing copy?

**Ellie Rofe | 41:59**
Yes.

**Ray | 42:01**
It involves making videos that are compelling to people and make them say, "Yeah, this guy's really smart. I want to work with him."
Then he goes to it, and then they click the link, which takes him to it, which is a page that makes it a one-click experience to execute on that intent and make sure they're not feeling conned. They're in the wrong place. No, wait, big picture of a smiling Beatrice and then let's go.
I think it's like a business card website. I'm not sure I would do more.

**Ellie Rofe | 42:32**
Yeah, I do. My only concern is who he's trying to sell to with that.

**Ray | 42:37**
Well, I think you're totally right. I think that's less clear, all the more reason to have less copy.

**Ellie Rofe | 42:43**
Yeah, but it feels like a lot of his content, his thinking, and his work are geared toward other builders. Is that who he's selling to?
Because if so, he needs to just double down on that. But he's saying that he wants to sell building digital twins to consultants and coaches. SOS.

**Ray | 43:05**
I think he wants to do that. I don't think he's ready to do that. And I think that might be another essential thing we're getting to is like three levels of mastery, right? You go from being an a novice right to being an initiate where you have mastery of the you know the material. You can push the buttons, but you don't you haven't gotten to phase three, which is to really transcend it and then be able which allows you to communicate people about it.
I've been talking with him a bit about this. Like, you know, he's a little too stuck on. Like, how do you push the buttons on the ofour J? And, you know, and as I get into it's like, you know what?

**Ellie Rofe | 43:35**
Y.

**Ray | 43:39**
"I need to not be telling him to stop doing that because he's not really at level two yet."

**Ellie Rofe | 43:43**
Right.

**Ray | 43:44**
So he needs to go through level two to get to level three. Only at level three is he going to be equipped to be able to sell to the kinds of consultants that we think he should be able to sell to. I think at level 2. Which he's almost getting to. Which he's almost. He's getting to he's almost at level two. He's in a position where he can sell to other foxes, right?

**Ellie Rofe | 44:03**
Okay.

**Ray | 44:04**
Because he's not really he's not ready yet to transcend the, you know, the techno babble aspect of it, right? He's like, I get this, I can make this happen. And it's very exciting for him. He's not yet at the point of like, you know, I was actually encouraging today to read Donald Meadows right. Thinking and systems because that will cause them to think about graphs in a higher order way.
And that's sort of the elution that's the journey that he has to go on has not gone on yet. And I think you are seeing that that's what he should be doing. You're trying to help him sell that, but that's not what he has yet.
And that's the disconnect, I think, that you're experiencing.

**Ellie Rofe | 44:41**
Yes, I didn't realize until we looked at the Krisp thing together that it wasn't quite there yet, so yes, okay, and what's he selling to other builders?

**Ray | 44:56**
Well, I think at that point you could be selling just the knowledge graph expertise of people who know that what they want to do is they want to have chatbots that can use knowledge graph, whatever.
He's having some of those conversations, and I think he's in a good position to be able to sell himself as somebody who is competent, to be able to help them with that and someone who's thoughtful about that, what have you... He's not yet...
The... Is LLaMA, right?

**Ellie Rofe | 45:18**
Yeah. Okay.

**Ray | 45:20**
But he will. But if he stays on this and turns that wheel quickly, keeps on turning that wheel consistently... I guess is what I'm trying to say that he will in a relatively short order, in the first quarter of this coming year, be that LLaMA.

**Ellie Rofe | 45:34**
Yeah.

**Ray | 45:34**
Because it's the, you know, the same reasons we talked about before, like intensity can do a lot for you know, and it's going to be when he sort of, you know, stops. And he has, frankly, over the course of the last month, not been studying as much.
You know, he has not been reading as much. But the important reasons I encourage the books, things, right? Because they put you in a mode of growth.

**Ellie Rofe | 45:55**
Yup.

**Ray | 45:56**
And those... But partially it's about the ideas from the books themselves.
And partially it's because you are now in a mode where you're accepting new ideas that cause you to learn whatever else you're learning faster. And that's the opportunity that I think that he has in front of him.
I think the reason you're experiencing the challenges that you've been experiencing is because you're like, "I want you." What he is saying he's saying where he wants to be, right? And you're trying to...
Okay, well, let's help you sell that. But then you're discovering the assets are him here, and so we can be ready for him as he's moving up, but you give me the things necessary to sell at this... He just doesn't have that stuff yet.
So he's selling in this slow way, but that's not what you want to sell to. That's right, but that's not what he's not... It's like he's on a journey, right? He hasn't gotten to his destination yet.

**Ellie Rofe | 46:48**
Yeah, absolutely.

**Ray | 46:49**
So he... But by selling to people he can't sell to today, he makes... He's able to help fund it and make faster progress. Then we get up to here. So there's a little bit of... We as advisors, right, to our friends and to our clients, we hear them say what they want.
Then we need to dig into, is that a statement of status or of aspiration? Right? If it's aspiration, how do we help them on that journey to get to here? So they can be selling what they mean to sell.
If it's a status, then because when those two things are aligned, then our job to be done changes.

**Ellie Rofe | 47:29**
Where he is at the moment, I guess, is if someone like me said one of my clients needs one of these things, I will manage the relationship you help with tech.
That's the position he's in at the moment, I guess.

**Ray | 47:46**
If you were to say one of my clients needs this, then, yeah, you would probably want to be running it with a client. I think an advantage Demetrius has is that he is perfectly presentable.
Then you can be putting him in front of the client. One of the things I was talking to Demetrius about... I've actually talked to Mitch about this too, because I tend... I really think this is a great thing to do with graph stuff, and none of them take me up on it yet. I think both of us should be interviewing more, right?
So the idea of taking the conversation turned to a graph. I think there is a lot of value in... We have meetings, and every time we have a meeting, the graph is growing. I think that could be just such a great way. They excite the client to want to have more sessions, to want to pay you more rate, all that stuff.
But that's more of a LLaMA thing, right? It's something where he needs to get himself to that higher level because if he's spending his time talking to the client about Neo4J like the client who's ready for that interview level thing, they're like, "I'm not sure I know," because they're not in line with them.
So when he's talking to the techie who's like, "I want to build a graph, I want to use Neo4J." It seems that Doo is the guy that he is. He's at their level, right? He's not at the level of the person he wants to work with and that and for that, he just needs to, you know, get on that path.
And the. And that's something I'm not it. I'm a little embarrassed. It probably took me a few weeks to figure out that was a discoatch going on, but having recognized it, that's sort of the that's the journey that I've got him on at this point.

**Ellie Rofe | 49:23**
Yeah, okay, great.

**Ray | 49:31**
We are none of us where we want to be, right? So we have our aspirations, and we have our state, and then we try to exploit our state and move towards our aspirations.

**Ellie Rofe | 49:43**
Yeah, okay, I like him. It makes sense. It explains why he's been so obsessively talking about technology. Every time I try and move away from it, he goes straight back to it because he's not ready to talk about the process or the actual outcome.

**Ray | 50:05**
I think the more he talks about the technology, the more he's developing those patterns in his head, and the less he'll have to do it in the future.
I want him to be talking about technology a lot. I don't think he's going to scare anybody off who's ready to do business with them by talking about Neo4J today. I want that wheel to be turning, and then he'll be talking about different stuff come 60 days from now.

**Ellie Rofe | 50:34**
Yeah. I've been solving the wrong problem for him. He was asking how he sells to these people, and you don't sell into a business coach by talking about Neo4J.
If he's just needs to be speaking to peers or near peers, then that's fine.

**Ray | 50:50**
Right? There's a question, "Who and how do I sell to these people? The answers get the answer is study cell, right? In fact, the answer is study like if you want to, you know, go work in the you know, go work with a nuclear physicists go saydy nuclear physics first.
And he is studying nuclear physics. But he's more akin to a nuclear physics student, maybe even a grad student, than he is to someone with a Ph.

**Ellie Rofe | 51:11**
But. Right?

**Ray | 51:16**
D and that. And we can help him shorten that path, but we don't pretend the path isn't there so that might take on the Demetrius thing.

**Ellie Rofe | 51:24**
Yeah. Okay, that's useful.

**Ray | 51:29**
So if you're able to help him, I think what I would probably start with is make his copy independent of his state. That way he'll be increasing his state without having to always be changing his copy.
You're not trying to fight the copy to pretend he's someone he's not. Then ideally, I would love to have that credibility of him knowing how to solve problems, be his clients speaking back to him. Demetrius really knew his stuff about building my knowledge graph. Bla. Bla blah.

**Ellie Rofe | 51:56**
Right?

**Ray | 51:58**
In that even the fact that he did something from this level for this client, their testimonial can make him look more like he's someone at this level, which, by the way, is where he will be by two weeks from now.
Whatever, as long as we keep on that train.

**Ellie Rofe | 52:12**
Yeah, okay, he needs to solve problems for people. I think he does need to just get in the weeds a bit, but there's a bit of a chicken and egg in terms of him connecting enough with people to get people to come to him and say, "I understand what you do, and I need this problem solved."
I think he is doing that better through the events than anything else with his peers. But I don't know if he's getting... I don't know what follow-up he's doing or what sort of product or service he's suggesting with them because if he's trying to sell them creating a digital twin in their business, I think that's the wrong route out of it.

**Ray | 52:57**
I don't think it's a route that's going to last very long, right?

**Ellie Rofe | 53:00**
H yeah.

**Ray | 53:02**
We need to think about what the intersect of supply and demand is, right? What is a market ready to buy from him?
I know there we can say we wish he was ready to buy, but he was ready to sell something else, but we get there through work and just doing the reps. I think they're... He's on the path he is.
I mean, you've known him for like whatever it is eight or nine months at this point, right? It's come a long way, and he's going to come another long way in the next period of time, too. It's just that the digital trend thing was... You've been doing what for the last 90-120 days?
Maybe he's gone from zero to here, and he'll go... From that, you can sort of draw a bit of a line, and I'm trying to help increase the slope of that line. But it's definitely growing fast, and it's definitely in the direction of where the market is going and profiting more from this stuff.
So I look at it and think he's in the right race, right? He's training to become the right horse.

**Ellie Rofe | 54:14**
And the knowledge graph market is has got that growth in it. I don't know enough about it. I've. I've asked him, but I'm not sure he knows enough about the market. Market?

**Ray | 54:26**
Well, I think just the AI market is growing. And the question of how you work with data in ways that are different from what we're working with data, in say, 2020, is big graph databases are hard.
So him being able to study and understand the stuff, I think puts them in a much better position to be able to... When the wind shifts direction, to be able to shift with it in and so I don't know what it's going to look like.

**Ellie Rofe | 54:49**
Yeah.

**Ray | 54:53**
I do know that...
The ideas behind graphs have a lot of juice to them. You see it all over the place in nature and physics, and we'll see it in computer science as well. Neural networks, they are the underlying technology behind most of these things. But whether it looks like he's building things in Neo4j, I don't know, probably not.
But that's how he gets there, right?

**Ellie Rofe | 55:15**
Yes, yeah.

**Ray | 55:15**
And what? God? What? Gods? Here doesn't get there right. But first you need to get to here. That I think is the journey that he's on and the journey that I think I'm certainly part of my job is to be helping him along with that.
And when you're thinking about the marketing, if you sort of have keep that journey in mind, you know if you'll be in a better position to provide him good counsels too.

**Ellie Rofe | 55:40**
Okay, I shall stop making him run before he's walking.
Yes, no, that's really helpful.

**Ray | 55:48**
Okay. I appreciate that. It brings us to the end of our hours. Is there anything else I can do to be a service to you before we wrap up here?

**Ellie Rofe | 55:56**
The final thing to say though, is that next Friday is Boxing Day, I think.

**Ray | 56:01**
It certainly is.

**Ellie Rofe | 56:02**
Yeah, and I am not around. I am out visiting friends and seeing family in the morning, so I don't know whether...

**Ray | 56:06**
Okay.

**Ellie Rofe | 56:13**
Then I am. Then I'm basically traveling back here having Christmas with Nick because he's not able to come back to the UK.
And then it's the 9/30.

**Ray | 56:21**
Three.

**Ellie Rofe | 56:23**
So I don't know if you're okay to skip to then and then maybe we...

**Ray | 56:28**
Sure.

**Ellie Rofe | 56:29**
And then maybe rather coaching.

**Ray | 56:30**
Well, yeah, I'm going to take this off the board right now, okay? And what I would like you to do, is I would like you to give thought to the 30th.
And whether you want to be doing something a little bit along the lines of what we talked about previously, like sort of book that time to this other kind of maybe multiple sessions or whatever, and maybe and like if you got an idea for it, just go ahead, book some time with me, you know, on that day.

**Ellie Rofe | 56:55**
Yeah, okay.

**Ray | 56:58**
And if that is and if you sort of have more question marks about just email about it. But I think let's look at something we Sal before Christmas, right?

**Ellie Rofe | 57:07**
Yeah.

**Ray | 57:08**
So we made that decision and then that puts us in a better position to do right by you in the last week of the month.

**Ellie Rofe | 57:14**
But how...? Well, I attempt it tomorrow and let you know how it goes. External accountability and then that gives us a deadline and I'll let you know the 30th, but I would like to basically...

**Ray | 57:21**
Two... May make a deadline out of it.

**Ellie Rofe | 57:29**
Yeah, perfect.

**Ray | 57:29**
I rep you that. Okay, great. I'll record hearing you tomorrow.

**Ellie Rofe | 57:33**
Thanks, Ray. Take care, too.

**Ray | 57:35**
Have a good day. Bye-bye.

