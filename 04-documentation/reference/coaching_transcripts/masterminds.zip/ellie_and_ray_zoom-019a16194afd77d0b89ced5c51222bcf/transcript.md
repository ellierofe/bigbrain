# Ellie and Ray Zoom - Oct, 24

# Transcript
**Ellie Rofe | 00:03**
Hey, how are you doing?

**Ray | 00:06**
I am. Well, ma'am, that's looking out the window. And like you know when I was doing my call with a couple of hours ago, it was completely dark out and that sort of winter is coming thing as the shorter days I do I got it, I think right.

**Ellie Rofe | 00:17**
Yes. Yeah. You love winter, don't you?

**Ray | 00:28**
You know, if I turn off the desk a little bit, you can see my new snowboard over there.

**Ellie Rofe | 00:32**
How co.

**Ray | 00:32**
Or was the back of it? In the fall pricing, you know, get the discount stuff for last season's whatever.
But for me, it's like, "Hey, this can be a new board." The trick is I don't want to take the new board out in the early season conditions. Bang it up, right? You want to take the old board out and then have that get banged up on the rocks, exposed rocks or whatever. That can be fun, but are...
Then have the new board be when there's lots of snow and you can be carving through and doing all that business.

**Ellie Rofe | 01:06**
Very nice.

**Ray | 01:08**
Very tempting to bring out the new thing, though. Always, Ted. To bring out the new thing.
And having the discipline of saying, "No, that's for later.

**Ellie Rofe | 01:14**
Yes, I used to be like that. Whenever I used to go clothes shopping, I would immediately put on something that I bought. It's like, "Whoa, new, let's go.

**Ray | 01:28**
The marshmallow test, right? It's about how can we deal with just a little bit of deferred, what have you.

**Ellie Rofe | 01:33**
Yes, exactly, yeah.

**Ray | 01:36**
All right, how can we be helping you have a good next week? I rather report... I certainly hear the health thing going back and forth, especially with the dog bite that I went through early this month, all sorts of craziness.
Not to be comparing any one thing with any other, but what's... I saw that you got paid right by Crick. That's great. Crick's no client. I don't know if that logo has grown up.

**Ellie Rofe | 02:06**
Yes. Yeah, it's going up. I need to sort my website out of it. Actually, I need to just jig some bits. I haven't reviewed it since I put it up in June Or.

**Ray | 02:19**
Yeah, went up in the summer, right? And sort of the impression I have is that, like, this week is, you know, that cell is sort of the big whed or a big turn, right? The big pivot of the guesses.

**Ellie Rofe | 02:31**
I think what would be really good is to give me... Not to give me, but to help me work out some targets. I think what would be good is to then get back to some proper metrics on the weekly thing that I fell out on, at an accountability level.
I think that would be really good. Whether that is posts, reports, I don't know. I'm thinking posts on LinkedIn. I'm wondering whether I should set up on YouTube or that's too soon. Just start thinking. What are the metrics I can put in place to refocus selling in my head, rather than just...
I've been in endless execution on these last two decks. It's been good in that because I have such thorny decks and I'm having to do so much thinking and so much work on the story and the visual storytelling and the detail and client management.

**Ray | 03:36**
Two.

**Ellie Rofe | 03:45**
Like, my God. Getting a straight answer sometimes is like, "Okay, this is a dance. I shall have to learn a few new steps." But that's been it. It has taken a lot of mental space, I guess.

**Ray | 03:53**
Yes.

**Ellie Rofe | 04:02**
But it has taught me an awful lot.
As I've been going along, I've been making notes in my little content planning thing in Notion about the types of content I can put out. That should be over as of Monday next week. That's done. There's a pillar tech one that has to be done, and that's it.
It's going to one of the board members, the one who introduced me to them, who then gave them a deadline to get this done now. So, it feels like this is a very good time to just go right. Let's really refocus on selling and incorporate that into my day-to-day as a default part of my days.
Maybe that's my November. Every day, I'm doing some form of selling. Obviously, the last bit of October as well. But this is the habit-building period. So, it doesn't go a single day.
Then that will help build up to this thing. She's quite good. Well, she's very good at posting regularly, but this Natasha wants to do a joint workshop or challenge. It will help me build up to that.
Actually, by the time that comes, I will have some momentum of my own and be able to go into it running rather than just being like.

**Ray | 05:23**
Yep. Okay, there's a little bit of the what and the when. When do you find you are most able to make the thing happen?
That is the lift for you? There's a Mark Twain line about this that I can bring back to the party, but really, the key... I would probably start with the "when." So, were you allocating the time or the sequence to make this thing happen?
That is obviously not natural, at least not yet, because it hasn't been happening yet.

**Ellie Rofe | 06:08**
The problem is what's natural to me, which is overcomplicating things and going off down rabbit holes.

**Ray | 06:14**
2.

**Ellie Rofe | 06:15**
I think that might be a big part of the problem. When I think about posting stuff and immediately...
Right. So I've got to think about this, got to think about this. I've got to think about this. And I think maybe I just need to say, "Get the muscle memory. It doesn't matter if it's crap. No one cares. Just get the muscle memory and keep going."
I think we've spoken about this before. A big part of it is I'm like, "Well, my whole thing is that I have to help other people be clear." So if I'm not clear and persuasive, then that undermines my positioning.
So I end up in this slightly over-engineered trap. But I did read something that talked about a data asset, actually that they do a quarterly report of LinkedIn and stuff, and one of them said, "Have fun when you're starting out because nobody's watching." [Laughter] It's a really nice way to think about it.

**Ray | 07:12**
Now let's go to YouTube.

**Ellie Rofe | 07:13**
[Laughter] Yes.

**Ray | 07:14**
GU yes.

**Ellie Rofe | 07:15**
Yeah. Nobody cares. Nobody's looking at you. Just have fun.

**Ray | 07:23**
That very good counsel. Okay, the way I might look at the state of this is I think about the three biggest questions too, but I think the three biggest ones are the "when," the "what," and the "how." My general observation is that people get stuck on the "how" they put it.
First, I'm gonna do this, whatever, and I need to be doing it in a way that's good enough, and I don't want to do anything that's wrong. I keep on hearing, "I don't want to do anything that's wrong." That becomes a good excuse not to do anything because that's the easiest way to avoid that particular kind of risk.
So what I propose... Usually, when leads to the what, and then the what leads to the when, the reverse happens in the order I would do it. Say there's a set of time you're going to spend on this activity. I find the Mark Twain role works well.
Things I do first are the things that are most likely to get done. Things that happen before my boys get up in the morning are things that are stuff's going to get done, and then like... Because after that, I can be pulled along in meetings,
but my proactive work suffers. After that, I can sometimes get a second wind later in the day, but the afternoon stuff is often not that great. One of the reasons why I feel more comfortable saying, "Okay, go snowboard now and just listen to a book."
That's what my brain's going to be most good for. The win is what I start with this survey. That's the thing I'm going to do first, either through allocating the time for it or just allocating the sequence for it. Morning pages.
That's how I built that effort, the essay writing, that's how I built that. Other things, similarly, if it's going to be proactive, I try to do it first. If another time of the day works better for you, that can be fine, right?
If you can allocate and do that consistently, that's great. But I would just ask what's easiest for you to put in. With that in hand, I look at the what, what are you trying to accomplish
with that time? With that time, I'm going to make a video, I'm going to write an email, I'm going to... What is the thing? Making a list of things gets very tempting. I think doing one thing really drives a lot more value than doing many things. One thing that can then be repeatedly used is
more of a fan of starting with the core of looking at correspondence for ideas of something you're going to put out there then doing it as a one-to-one thing because usually, the sales and sales email replying to someone is more straightforward. Doing cold email or reigniting conversation can be hard and a lift, but even so, I don't think that's quite where we're talking about right now. We're talking about how to build credibility with those folks.
So, what does that look like? I suspect the answer is either writing or recording. Then that then takes you to the how, how do you want to go about doing that? I remember when I was doing lots of essay writing. I would do it by disconnecting my laptop from the screens and going to an environment that was not my main desk. It was so early in the morning
before I picked her up. Then I would bang on the essay and have a three-part pass to it, right? I would write the draft, I would look back at what had lots of red lights from Grammarly or whatever, and I would rewrite those paragraphs. I wouldn't use it as grammar corrections. I'd use it to indicate this is why I'm not being clear in my thinking.
Then I'd do the Grammarly pass and then chip it. That eventually turned into a pattern that was working well for me. I write the first draft with a lot more confidence because I wasn't worried about, "Am I saying this right?" No, they'll catch it for me.
Then I can just focus on the parts that seem to be... If I am writing 17-word sentences, there's probably an indication that my thinking is not yet queer.

**Ellie Rofe | 11:26**
Yeah.

**Ray | 11:27**
And like. And so the solution is to rewrite, not just fix the sentence like that.
That's trying to sit back for a little anyway, but that was a way of doing that recording. A video can fall into that category. You're just going to do a video and then, like, what are the passes? You do the video.
Maybe you do the video second time, or maybe you do the first half of the video until... Yeah, and then you do the video second time. That works enough. You do whatever the key parts are to be able to get published.
Then you push that out. Then, allow other automated tools to be like for slicing a social media or whatever, because that usually works. It works surprisingly well and almost disappointingly well because...
But wait, my good crafting should be so much better. Do my good crafted emails get views of this and the ones that then optimize get views like that? And that's just what happens. All of us by the way of saying that, like, what is that?
The final thing about the when part is when people are asking, "Hey, are you doing this every day?" My answer was, "I'm doing it today." Then, I'm hoping I'll do it tomorrow, but the thing I can control is I'm doing it today. The thing I can be happy with is I did it today, and then you want to have the endorphins from that be taking you into doing it tomorrow.
That's the wheel. If it's like, "I've got to do 30 of these," and then you're like, a week later, you've only done one, you're like, "Okay, I'll make up the time." No, that doesn't work. At least I haven't got it to work.
So that's the way I approach content creation, factory part. It starts with the "when" and then goes to "what" and then the "how" follows from there because you set the "when", the "how" is timeboxed, right? The it keeps you from going too much to the perfect. Being the enemy of the good.
Because now you got to ship the sink. Cause you get to the rest of your day.

**Ellie Rofe | 13:35**
Yeah, okay, I think that's good. I think I do generally wake up quite early. And then I've actually slipped into recently because it's dark in the mornings so dark so quickly.
I've slipped into being a bit cocooned and just reading something. But actually, I think it is the perfect time to just get up and get on. I'm not going to do videos in the morning. I'll be perfectly honest with you, I'm not going to be getting up and doing my hair and everything in order to do a video in the morning, but I will work out our time to build videos into it.

**Ray | 14:21**
What is all.

**Ellie Rofe | 14:25**
I think at the moment, I think videos are perfect, being the enemy of good for me. At the moment, yes, I should be posting videos, but as soon as I start thinking I've got to post videos, I stop posting at all, and I just need to build the habit, and then get to the point when I've got maybe more clarity on what I'm talking about and I'm not spending hours and hours going around in circles on a video.

**Ray | 14:48**
Yeah, well, my secret to being able to make videos is to have that context that made it easy for me to do it, which is the chairlift thing. The second secret was to start an event series, right? That was just doing the thing with the scene, which should then turn into having the shorts that they come from it. The number of views I got from the long was way smaller than the number of views I got from the shorts.
But that's fine. So put me out there, put him out there as smart people. Then that's how that wheel turns, and we're now into doing more of the long as I start to experiment with a different modality here.
But I think you know what you want to do is find things that are easy for you and what was easy for me before I did videos, writing. So, if you're more of a writer, then go ahead and write.

**Ellie Rofe | 15:40**
Yeah, well, I think writing and visuals.

**Ray | 15:40**
Like, is the easy way for you to express your expertise as a gift into the world?

**Ellie Rofe | 15:49**
I need the before and after of these decks and things to be eye-catching. The visuals around the reports, the structure analysis, and stuff are eye-catching. I should easily be able to create it. It doesn't even have to be an image rather than a carousel and times up and nots there, but like a how-to or five things to check, whatever. Just create some stuff which is formalizing my thinking, but doing it in images as well as writing because it's a huge part of what I do.
It's the visualization of ideas, so I should probably do it for my own.

**Ray | 16:28**
That's great. So then the question... So then that seems fine. I think even just you doing a slide analysis. What's your slide per day?
Then you can put that up, and then that can go up into 15 formats or whatever. That can be tweetworthy, that can be LinkedIn worthy, that can be whatever. I mean, LinkedIn is probably the most useful.
Then it goes onto your own properties, right? As you collect a few of these, you can be doing your weekend review video. Hey, are the slides. And what's most interesting about them that being useful? I really do think that the whole event thing can be pretty useful as well.
Like you talking about marketing and design and pitch deck, is there somebody else you could be talking with as well? Right? To have that conversation back and forth. I know that's the podcast dynamic, but it becomes the easy way for you to express your expertise on camera that could then be multiplied app.

**Ellie Rofe | 17:30**
Yeah.

**Ray | 17:34**
And of course, if you're comfortable just doing your expertise directly to camera, that's fantastic. I think that can potentially be better, but I'm trying to figure out what allows it to be easy for you to get out that...
For me, once you've figured out the when and the what, then it's like, what is the cost-minimizing how.

**Ellie Rofe | 17:52**
I was just trying to think of who would be great. I'll keep that in mind because I can't think of anyone immediately, but there must be absolutely. I did. I'm going to follow up because someone from...
It's Innovation Labs at Harvard. So it all seemed pretty when I said I was looking for this. Who is the head of the community at Innovation Labs at Harvard? Posted something about, I love introducing people.
So tell me what you're working on, and I'll find someone to introduce you to. I'm working on this hard tech analysis, et cetera.

**Ray | 18:35**
He.

**Ellie Rofe | 18:40**
And replied back saying, "Is it just hard tech?" That's literally what I just said.
I'm guessing that she's just more focused on either consumer or S&A, I'm not sure, but I'm not sure what she was more focused on because I couldn't really find it in her bio, but
yeah, I'm going to try and follow that up again and just see if there's... I think, I agree with you on the event side of things, but I think maybe one of the things I need to be trying to do is... Although again, it's with early-stage and they're pain is teaching like I have wondered...
I've got connections at Judge Business School at Cambridge for example, but then I'm again working with or even spin-outs from there. But then again, you're working with the precedent. I think that educational thing can be really useful. Workshops or whatever.

**Ray | 19:42**
That can be very useful. You make a good point. They don't have as much money, although the school has more money.

**Ellie Rofe | 19:48**
H.

**Ray | 19:50**
So, the credibility of... Hey, I've worked with this school and I've taught people in B-school courses. Makes you more credible to the investors as well.
It's like there's a limited set of founder or startup types who have the ability to pay and the need for the money lined up at the same time. But they are, and that's a psychographic, right? It's transient, as compared with institutions that are dealing with this everyday, they're dealing with deal flow, whatever. What do they value and how can you be in front of them?
I've always liked the whole being in front of the VC whisper or the school becomes a really interesting part of that too, because they're definitely in that mix. They want people to be going to their schools and building successful businesses.

**Ellie Rofe | 20:43**
Yes, in terms of VCs, I absolutely agree with you.

**Ray | 20:43**
53I would encourage you to like if.

**Ellie Rofe | 20:50**
I just think it's... I think they're so evidence-focused that if I can just get a couple of recent wins...
The other thing is, I look back at the decks for the other ones and they're not the most amazing decks. It was just that money was flowing everywhere, and I don't mean that as diminishing what I did. I was in a different relationship dynamic with those clients, and I advised them on structure, but they were just like, "Whatever."
So that's again, a little bit perfect, being an enemy of good. It was old. It's at the boom time, and I need something from now to be able to say to a VC here's what it was before, here's what it is now.
They got funded in this environment because we worked on some foundational stuff and got it so that every investor could see why it was investable and just decide whether it worked with their thesis.
That's basically it.

**Ray | 21:54**
If Aid over at Crick got the pitch of choice, have you already made a post celebrating her for that? That makes her feel better about you?

**Ellie Rofe | 22:05**
No. I was going to, though. That was my little notes. I need to celebrate her. Yeah, I think that's where.

**Ray | 22:14**
Like, connects you to it. That's all the good stuff, to your point of looking for more evidence, right? Your success allows YouTube. You don't need to be saying...
This is the thing I made you just say I was staying next to it. The other people know that you're personal. People understand that speechwriters write speeches even though they're never named by the politicians who are giving speeches, right?
They'll say, "Hey, who did that?" Then, yeah, because that's what people who are in the know will do. Okay, cool. It seems like writing the slide design or something along those lines, you might try the slide review or slide roast, right? For one. Did that work? Didn't move on next.
You know, the approach I took when I was doing much more of the writing and I think I should be doing this again is I did my morning pages and went straight into the essay. What I found was by doing the morning pages, my brain was getting cleared up. I'm thinking about the thing that's going to be coming up next.
Then my brain was like... I had a rolling start to the race. [Laughter].

**Ellie Rofe | 23:36**
Yes, I think I have been avoiding talking about slides specifically because so many people just think I want a designer, but I think I can actually translate that into talking about structure a lot rather than just slides.
So, not just talking about how it looks, but actually what's in it, what's going on in the deck overall, and that kind of thing. I think it's about, well, visual storytelling is a woolly term, but it is that's effectively what it is.
It's saying, how do you effectively make it quite technical? Not just "I made it pretty," but I made this convey the information in a way that makes more sense to investors and is easier to read, conveying the most important messages in this way or that way.
Something about the technical meeting the form meets the function rather than just, "Here's how to make it look pretty." Or, "Here's a template for a slide.

**Ray | 24:42**
Yeah, there's... Yeah, you combine that hard tech idea. I think there's a neat thing there. I don't know if we're putting it up on your LinkedIn yet, but you know you're a heart tech specialist. The whole thing...
I've been thinking about that, running through the back of my mind since you were talking about the Harvard Innovation Lab thing, right? Like, wait, you. The people who are into hard tech, they're like, "Wait, you're one of us.

**Ellie Rofe | 25:18**
Yeah. Yeah.

**Ray | 25:19**
Everyone else says, "You do hard tech?"
I know like 700,000 people who are doing SaaS or whatever, or making another AI agent wrapper or something, but this is what you do. There's a little bit like, "Hey, what is hard tech?" That could actually be a pretty good fit, too.
But that's what you focus on, and there's even an opportunity for a turn of phrase, right? Easy sales for hard tech. That helps. Not everything in hard tech needs to be hard.

**Ellie Rofe | 25:55**
Yes. Yeah. [Laughter] Yes, that's actually really nice. [Laughter].

**Ray | 26:03**
And regardless of the wording of it, the sentiment, right, what you're doing is, "Hey, I'm with you." The technology is hard, you have a patent, and you need to raise a whole bunch of money in order to be able to make this stuff happen.
But stories are still stories, right?

**Ellie Rofe | 26:21**
YP.

**Ray | 26:21**
And now we can focus on like how to how do we connect this with the investment professionals, with the business professionals, with the whoever debt will then allow this to come to the world and make a better place.

**Ellie Rofe | 26:32**
Yeah. Yeah, absolutely. There's a potential, this is very loose. I think I spoke about him just before we spoke last week. He is in energy. He's an energy trader who helps energy stars. He lives in Düsseldorf and has been for 50 years, 15 years.
We talked about and I mentioned this to you. The idea of effectively creating a digital twin for a political party and their policies.

**Ray | 27:06**
23.

**Ellie Rofe | 27:06**
And he. I gave him an idea of how I would structure a strategy if I was taking an idea like his, "thing about NHS data and AI," and turning that into not just... We've written a blog and some people want to look at it, but here's how we actually make this a source of conversation, a route of conversation, rather than just occasionally throwing out a blog that reacts to stuff. You're not going to grow like that.
He came back and said, because he's got some coding... As soon as I started talking about knowledge graphs, he went, "Yeah, I use those." And sod off, he's ahead of me. But he came back and said, "Do we want to build this for the SDP or do we want to build it and let them use it cheaply?"
I was like, "That's an interesting positioning because he's a member rather than a party political." I'm going to try and talk further with him. I'm going to ask him for some pitch tech and if he knows anyone in energy that needs a hand with this cause hard tech.
I'm going to see whether this is something that people in his sphere might need to develop the concept of that underlying strategic plan for a hard tech outfit. I don't know how you replicate it. I was trying to ask Mitch this the other day.
Sorry. I'm now just free wheeling, but hopefully this is coming to something useful. When Mitch was talking about digital twins and he was like, "Yeah, so you need to do this and you need to map this knowledge graph and everything."
I said, "Can you create a kind of knowledge graph template that you put specific data into and map metadata and data? Or is each one individual?" I guess that's one of the questions I have.
Does each one have to be entirely mapped afresh and new or can you somewhat template it or productize it or ever? So you go. Here's the basic thing.
And we push data into it and along these nodes and these metadata bits here and these relations here. Do you think they're all unique?

**Ray | 29:31**
The virtue of a graph database is how loosely structured is like the more you talk about, you know, having hefty ear structure, the more you can sort of see how it falls into a usual tabular structure, right?
And the CHO graph database is where it doesn't fit into a tabl structure. And like that, I think that's worth you're sort of considering, right? Like you have these. These nuggets of information or entities or whatever.
And they have relationships, and those relationships don't have to be emergent. You could have some sternization of them, but I think that the mind freeing aspect of working with a graph database is saying, but wait, as could be anything, right?

**Ellie Rofe | 30:11**
Yeah.

**Ray | 30:13**
And you flip it around. Do you have a plan for it? I think you combine this with some stuff that Demetrius has been working on around using MCP for the stuff. To discover what things make sense and to be suggesting, "Hey, maybe these things are useful ways to be starting to look at the connections."
Let's look at the connections. The Graph Rail came out, and the big inside of Graph Rail was that you spent more tokens building the graph, right? So you got fewer tokens doing inference from the graph.
Since you're more likely to read it more times than you write, that's the theory of it, right? That you can go have efficiency for that. The trick is that you're using tokens to do that job because you are discovering what those relationships are. In fact, you can discover them over multiple passes.
That's what makes the graph database exceptional because these relationships, which could be a little bit wider, hither and thither, are not super tightly structured the way they would be if you were trying to do this through a relational database.

**Ellie Rofe | 31:22**
Yeah. Yeah.

**Ray | 31:24**
So I think the answer is, how could you practice it? Absolutely. You can practice it in a way that you are more competent at, which is through prompting, through setting up norms and suggestions and starting points, as opposed to where I might be perceived to be more competent, which is setting up code and rules, right?
That kind of code and rules approach is one of the reasons why people with my background have had a harder time getting their brains around the graph databases because of that higher level of dynamism and chaos inside it.
And that AI, of course, as the search engine, is very interesting, but AI enables you to be able to work with this kind of data structure because AI was causing traditional developers to have connections in terms of creating code for it.

**Ellie Rofe | 32:10**
Yeah.

**Ray | 32:18**
Are is so much easier to do when it's the AI that comes along and says, "Hey, this kind of makes sense. I'll go do this now."
The person who's trying to not have to go write all that stuff directly, AI is like, "Sure, I don't mind doing this 100,000 times.

**Ellie Rofe | 32:24**
4Y.

**Ray | 32:32**
Like just paying for tokens, right? Which is so much more paying for a person.
So, yeah, go for it. Then it does it, and then you do a second round, and the second round as well. These things already have this relationship, which makes you think they probably have a relationship with the thing over here.
Then that... So the multiple passes thing, a human you never want to do, and the machine's very happy to do it. That would be the way I might approach this idea of working with graphs, but one is something that their traditional technologists, you know, "Hey, could you have your coders just do it? They're actually going to have a big pushback against it because that shifts a mental model and being AI allows you to do it better, and you're primed to be there in a way that many others aren't, so I really like that.
You know, you being in that zone because it allows you to put strength against weakness.

**Ellie Rofe | 33:21**
Yeah, and I do love the exploration with people. It's one of my favorite parts of it. Initially, I guess that's part of it as well. Initially, you are spotting the gaps in their strategy and talking them through it and making them identify.
Over time, the database and the model start understanding the gaps in the strategy or can start analyzing it so that itself becomes woven in. Yeah, okay, that's really interesting. So basically, it's something that we'd either say, right?
I mean, I don't know that they've got any money to pay a fee. So, say we build this for you and you pay us a monthly license for it or something. I don't know. That seems they need to own it. I'll talk with them about that.
I think that's just... I think that's a red herring, Possibly.

**Ray | 34:30**
What are they doing? Thing for the political party.

**Ellie Rofe | 34:34**
I think the thing for the political party could be a really interesting proof of concept because they obviously have... What are you talking about? Everything in the world, certainly everything in Britain, but how it all connects in terms of foreign policy and other things.
But it's when he said, "Do we just build it for them or build it and license it to them?" That was a bit... I was getting a bit. I'm not sure the value of licensing.

**Ray | 35:07**
Seven?

**Ellie Rofe | 35:09**
One thing that's built bespoke for someone to them is.

**Ray | 35:13**
Yeah, I'm not sure that you need to totally... If you license it to them, it's just a form of financing.
So it's like you're basically lending the money, and you can decide how useful that thing is. I look at this, and when I think about these kinds of political endeavors, I'm looking for the donor who's going to pay for this, and the.

**Ellie Rofe | 35:34**
Yes.

**Ray | 35:36**
The party almost never pays for it. The party is a vehicle for funneling money and organization into candidates, and its job is to get its candidates elected.
So, if there was a donor who was super excited about this, in the US, there are these things, super PACs or whatever, that will pay for this kind of endeavor because that's what they're doing, providing support mechanisms, right?
Usually, they provide support mechanisms that the donor who's behind the super PAC wants to make it happen. So, you're just to theors saying, "Hey, wouldn't this be great?" Sometimes, it's because it's going to help people win more races. Sometimes, it's because you think this is a better way of doing politics.
It's one of the reasons why donors often take parties to extremes because they really care about this particular weird issue. Tactics like this are a smarter way of doing politics.
This is where the technology or whatever comes into play. The parties pay for these things when they become more middle-of-the-bell-curve, right? To use Jeff More's structure for that, the doctors, the early doctors, often have a bigger willingness to pay.

**Ellie Rofe | 36:49**
Four.

**Ray | 36:54**
So it's not like you'd be getting a big discount on it, but it is there. It's usually a rich person who is saying, "Hey, I want this stuff, and how do we do this better and how can we use better technology?" We can use digital twins. Great. Who's great at doing digital twins? Great. We'll hire you and we'll pay for this
working for those people is often a much better-paid gig, right? Whereas, working for the party might be a higher prestige gig and get you closer, maybe, to what you really care about.
If you're a political operative, you're not a political operative. You are a marketing professional, which will come across. I think the closer you are to the party, the more you're surrounded by the true believers who don't have money.
That is like the opposite of what you need. You need people who are thoughtful, analytic, trying to make smart decisions and who have money to work with. That's why I'm talking about the donor approach.
I don't know how it exactly works in the UK, but those kinds of structures... Way I would look at it if I were having this conversation aside.

**Ellie Rofe | 38:02**
Yes. I think it is a really interesting potential opportunity. Before I think what I'm going to suggest to him after everything you just said and what I think about this party. This is effectively a rerun of Alder and a pillar tech on some level. There is a huge gap in the market for this party in Britain right now. They perfectly fit something that 50 to 60% of people in all polls say that they want, if not higher.
The question is whether they are going to actually pull their finger out at their ass or whether they are just, like, you say, a bunch of really politically engaged people who are not going to think about it strategically but are just going to be enjoying, going around, talking and making the pitch.

**Ray | 39:05**
If I might ask, what's the pitch of the party? What's the... Yeah, I don't know. This party.

**Ellie Rofe | 39:11**
Yeah. So it's the SDP. They're effectively... Again, this is the problem. I need to work with them on the pitch. But their policies are effectively economically center-left, culturally or socially center-right, and very much like community, like family, nation. Very much not highly ideological, very pragmatic. Lots and lots of policies that people love in polls but just don't see represented in the parties. They are effectively like a bridge between the past that lots of people are nostalgic for and the future that lots of people are desperate for. They have a pragmatic, very future-forward, very expansive vision of what Britain should be.
They are aware of some of the biggest ideological mistakes that have happened from both the left and right across the last 20-30 years. Anyway, that's again, they're very policy-one key, and they need some proper marketing and branding. They have a strong policy position. They haven't translated it into pitches, which is what I'm trying to help them with very gently on the edge, because my concern is that some of these people were in town planning, and one of them used to be a member of the Communist Party, and there's lots of discussion about stuff if it doesn't look like...
But there are some really strategic business people there too. If it looks like it is just mired in process and noise, then I'm not going to put too much time into it because it's a waste of time. It doesn't matter what you build for people if they just want to sit around navel-gazing.
If it looks like there is a genuine appetite for a strategic approach, then I think it's worth it. So I think it's a gatekeeping thing for me at this point. I will talk with this Kris guy. He's got the ear of the chairman directly, who is a businessman who is very well connected.
I will talk to him and say, I think we need a gatekeeper before we do any of this stuff, which is, are they actually going to be serious about strategy? Or is it just going to be lots and lots of people who want to talk about deep political stuff like policy stuff, but not actually get out to the massess?

**Ray | 41:33**
Well, yeah, I mean, that certainly tells you, like, whether it's gonna be a win, right? And that would be something you would care about, but you care about when you care about the ability to pay. I do think the whole license doesn't smell right to me.
It's a single client. No, I don't see why you'd be doing a financing thing. It can be a... It doesn't have to be a ridiculous amount of money to do the engagement. But, you know, it's probably a four-figure engagement, right?
Let me think. I think they're either ready to buy that or they're not.

**Ellie Rofe | 42:09**
Yeah, I obviously the willingness to pay is absolutely part of it. I think the ability to get a donor to do something like this depends on whether they are actually showing any donors that they have the plan in place to actually grow this party and become a meaningful part of UK politics rather than a curiosity that a lot of people who have deep political wants love.
But a lot of other people don't. That's where I was tying in. The willingness and ability to pay are very much tied into whether they're actually going to get off their asses and do something.

**Ray | 42:47**
Yeah, I got to say, I've seen a number of parties, professionals, whatever, who are deep policy wonks, and I've seen them get into power, but not as the face, you know, like the technocrats got in power because of Bill Clinton, right?

**Ellie Rofe | 43:02**
Yeah.

**Ray | 43:08**
But he was all Mr. Southern charming. I feel your pain. Barack Obama, who is actually quite the technocrat personally, was the first African American president, right? He wrote on something else, right?
The reason that I bring all that stuff up is the idea that we're going to be the party of technocracy. I cannot think of a situation in which that has succeeded in a democratic environment in mature democracies in the last lastentury.

**Ellie Rofe | 43:48**
No, it hasn't. That's what I mean. They need a way to express the policies that they do that people love. It's the old trap when you do a blind survey. They very rarely actually end up being shown the party that they vote for when you ask them what policies they like, because people vote emotively and based on identity and stuff like that.
So this is what I'm trying to express to them. You cannot just keep going. We've written a 70-page energy paper which is filled with magical information and ideas. No one will read it, and no one cares.
Those people who are struggling to pay their energy bill will never hear about this. To be honest, they don't even care whether the energy is coming from nuclear or whoopiks.

**Ray | 44:45**
Yes.

**Ellie Rofe | 44:46**
They don't care. They just want cheaper
yeah, there are a lot of battles to be won across the thing, obviously, but the biggest one is that they need to actually connect with humans emotionally, which is partly what this would be trying to help them be.

**Ray | 45:08**
We need them, Cliff. With humans, it is sound to say true, it's challenging.

**Ellie Rofe | 45:11**
[Laughter] [laughter] Yeah, no, it's okay, I'll keep that in mind.

**Ray | 45:16**
Yeah, PA that.

**Ellie Rofe | 45:20**
I think I'll talk with Chris. We'll jail very well, and there might be other opportunities there. I will just ask him if he's got any decks I can use for the analysis for this thing in the first instance and move on from there with it. I am intrigued.

**Ray | 45:34**
Yep. Yeah, and I would give myself permission. I have done the work with Demetrius. Demetrius put out a video that I want to be very encouraging that he's putting out videos as good as he's putting them.
By the way, I thought his thumbnail was fantastic for his current first most recent one. As could anything come before, I don't know if you had influence on that.

**Ellie Rofe | 45:52**
I haven't seen it yet. I'll have a look. I've given him a new brand.

**Ray | 45:54**
It's it yep, like I suppose the big white field, it's got little structure to it.

**Ellie Rofe | 45:55**
A brand? A very quick refresh. But yeah.

**Ray | 46:03**
It's like him. It's much more him. I think he's a handsome Greek guy. Let's put that front and center. That's been... Whatever influence you're having on the visual refresh, I was immediately seeing improvements, so that was totally awesome.
The other thing I bring up is that he's been thinking about this graph stuff as it relates to using MCP and Claude and whatever. Your approach is... Do I need to build a whole lot of technology? I'm not at all sure you do.
I think this might just be... You pop open the cloud and you're starting to go, and you have your account with Neo4j or Amazon Neptune or whatever. You are just letting it load, let's play with it, let's make some connections and see how it works.
I will put you in a position to learn more. These connections seem to work better, and now you're building out your project or your skill or whatever that is, giving it better insight for the better one-shotting to be climbing that curve.
I think that's a lot more what software looks like nowadays, and you've been doing that for the marking stuff, it's just like the software that dares not speak its STA.

**Ellie Rofe | 47:19**
Yes, I'm going on to the call later this afternoon as well to listen. So yeah.

**Ray | 47:25**
Yeah, I'll be checking it out as well, partially trying to show the FLA because last time it was conflicting with the state change thing. And but because I'm... I'm excited to hear what they're talking about
because this is a really hard topic.

**Ellie Rofe | 47:38**
Yes, it is. It's really interesting. Okay, I will head on to that. I will park that. So, in terms of targets...
Because I think it will be useful even if I don't meet them, but I should meet them to have something in my brain. I know I can only say, "I'm doing it today", et cetera, but I think by the end of the week, that could just add up to a whole lot of...
Well, I didn't do it today, so I think I need to have something to work towards. Have a target.

**Ray | 48:19**
I might propose that you want to have created and shipped seven pieces in the course of that. I say seven because I find the daily schedule works so much better. Like, the weekends really break things up.
You know? I don't... It's fine for it to be fifteen minutes. It's fine for it to be an hour. I would start with the when of it and then come back to you. You have shipped these seven pieces and you have that at the end of the week.

**Ellie Rofe | 48:50**
Yeah, okay, seven pieces.

**Ray | 48:51**
You're going to get so much better if you have it.
The first day you miss it makes it very unlikely you're going to get back to it.

**Ellie Rofe | 49:03**
I think I should target a certain amount of comments. I think that is an important thing to be doing. Just for my own... As well, connecting with people rather than just pronouncing to the world.

**Ray | 49:16**
I think that's a good thing. I would be perfectly happy if all you do from a metrics point of view is worry about the content. See, I think the comments are going to happen because you're like, "I need an idea here."
So you're going to go out and you're going to look, you're going to engage, right? Part of the thing about writing is that it makes you read more, so, selling pulls you into doing more study.
How am I going to do this? What am I going to write about? You go find something and you go comment about it. This makes it more natural that you're having the conversation because you're actually interested in the topic. "Hey, this is such a great topic. Thank you so much for bringing that up."
That's engaging. It's positive. Then you turn around. You make your own thing, which you can even, by the way, link back as a comment later because you were genuinely interested in it.
So I think that the thing about writing is that it makes you engage more. Or, when I was doing more videos, which, again, I need to be doing more videos myself, right? Carpenters, the cobblers, children and all that. When I was going on, dropping comments and things like forms or the Xano forum or Dan or whatever, those things give me more ideas, right?
Then that makes it easier for me to do the video part. You're having that kind of problem? How about I just go make a video? I try to describe the problem, and now I'm thinking about that person, which makes it so much easier than trying to think about the whole universe.
Those become the videos that were most watched.

**Ellie Rofe | 50:50**
Yeah. Yeah.

**Ray | 50:51**
They're actually... I'm not suggesting you need to be doing all videos. That's not the point I'm making. But if you sort of have the... What you're doing is your hour of making content, and then what that's going to inspire you to do other things, I think.

**Ellie Rofe | 51:05**
Yeah.

**Ray | 51:07**
So the... So I try not to have too many metrics, right? If I've got... I'm trying to hit all these five things. Well, how about you have the one that's important to you? It's like, "All right, which days did you make a chip?"
If we start with Saturday, right?

**Ellie Rofe | 51:28**
Yeah.

**Ray | 51:28**
Sunday, Wednesday went through to Friday. Then you're like, "Hey, this is what I did." Basically, Gray, I was able to keep on going. Then Wednesday happened, and then I fell off the wagon. I never got back on.
What we're doing is making it easy to get back on. That's not the worst use of our time.

**Ellie Rofe | 51:44**
Okay, sounds good to me. So seven pieces of content by the time we next speak next Friday, and I will... As soon as I wake up.

**Ray | 51:56**
Two.

**Ellie Rofe | 51:59**
Basically.

**Ray | 52:02**
That'd be my proposals somewhere close to that. My operating theory is that your brain is at its sharpest when you're closest to having had rest, the further away you are from having had rest.

**Ellie Rofe | 52:11**
Yeah.

**Ray | 52:13**
The. rest. The more tired out your brain's going to be.
And that makes... I find it for myself that makes a hard start.

**Ellie Rofe | 52:20**
Yes, I think with things like this, definitely. I've worked out if I have some caffeine I can get really creative in the afternoon.
I can just sit down and really start ripping through some slides and some design or whatever. But you're absolutely right, things that require structure are quite important to do first thing. So that's nice. I'll get into that rhythm's first hour just goes bing content.

**Ray | 52:53**
I'll see you again in about whatever it is, three hours or so, four hours. So, is there anything else I can do to be helpful to you as you head into your weekend.

**Ellie Rofe | 53:04**
No, I think that's really helpful. Yeah, I think this is the thing I need to focus on. Well, get rid of this deck and then just this and the laboratory.

**Ray | 53:16**
Yeah, cool.

**Ellie Rofe | 53:17**
This and the observatory is my wheel until I can get some stuff in.

**Ray | 53:22**
By the way, the Observatory makes for a pretty good content base, too. Like, "Hey, you saw something interesting in the Observatory, making a commentary about that can be pretty useful.

**Ellie Rofe | 53:27**
Yes.

**Ray | 53:33**
There is a whole post-it note approach to video creation that could apply to creating things out there as well.
But I would have you experiment for a week and then we could be comparing more tactics. The reason I was talking about the how and the when is to keep us focused on the when to create, see on the what.

**Ellie Rofe | 53:56**
Yeah, YP yes, I think that's right.

**Ray | 53:58**
And then, like, we can be talking tactics on the how once we've got that wheel turning, all the good.

**Ellie Rofe | 54:04**
I think I just need to post.

**Ray | 54:08**
All right, leave you to it. I'll see you, NPRS.

**Ellie Rofe | 54:10**
Thanks, RA. Take care.

