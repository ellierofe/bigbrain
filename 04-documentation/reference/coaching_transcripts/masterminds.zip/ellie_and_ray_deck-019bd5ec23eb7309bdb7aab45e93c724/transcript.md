# Ellie and Ray Deck - Jan, 19

# Transcript
**Ellie Rofe | 00:01**
No record.

**ray@statechange.ai | 00:02**
Recording in progress. Hey, Ellie.

**Ellie Rofe | 00:05**
Hi, how are you doing, Ray?

**ray@statechange.ai | 00:07**
Very well.

**Ellie Rofe | 00:08**
Happy Monday, very early morning to you.

**ray@statechange.ai | 00:11**
Yes, and it's actually an observed holiday here in the US too. It's the birthday of Dr. Martin Luther King, who was a leader in the civil rights movement.

**Ellie Rofe | 00:19**
Okay, day. I'm sorry.

**ray@statechange.ai | 00:22**
No. I didn't say it was a day off for me. I just said it all in the...

**Ellie Rofe | 00:27**
Yes, I forget those, well, some of the US-specific ones you have. Is it Labor Day at the beginning of spring and then something else at the end of autumn? I can't remember.

**ray@statechange.ai | 00:42**
No, our Labor Day is observed at the beginning of autumn, as opposed to being around May Day, which is more the International Day of Labor.

**Ellie Rofe | 00:52**
Got you. That's where I get confused. Yes, there are various bits and bobs like that where we're completely out of alignment. Well, birthday to a great man, very impressive thinker.

**ray@statechange.ai | 00:59**
Yeah, well, it all is. It is good to see you again. Yes, it was.

**Ellie Rofe | 01:07**
Eraso and all sorts of other things. Yes. So slap it on through some development today, which is good. I've already identified five or six people I think I could talk to in interviews that I know.
So I'm just trying to keep building on that. So that's good. Then today I'm thinking I've defined what the output is going to be and how that differentiates it from other things and is actually functionally useful to people in a way that AI needs to be rather than some sort of boondoggle thing that says we can do this, that, or the other with it.
So, I've already done that piece. So then what I was thinking was... I spent an hour just planning the bits I need to get that into place. I don't need an hour for that. Half an hour planning the steps I need to get into place and then just try and work through them all in a maximum of an hour.

**ray@statechange.ai | 02:11**
Well, let me just sort of. I mean, can I just sort of ask about what the planning steps are, what are things need to be sorting out. That is sort of between you and action.

**Ellie Rofe | 02:20**
Well, a very good question. So I know that the output needs to be here based on just the deck alone is what we think your investment case is.
These are the bits of the deck that point to that and these are the bits of the deck that undermine it. It might be that there's more than one because they're telling two or three different stories.
Then the gap map overview of if we break down every bit of strategy, here's what's present and what it's saying about your company and then any key investor questions or concerns that would arise from this deck.

**ray@statechange.ai | 03:00**
Okay. I mean, you're describing elements of what would make for good engagement, but not necessarily what planning you need to do right now.

**Ellie Rofe | 03:09**
No. So what I need to do is... This is actually... Some way you can help me. I think I work from what needs to be delivered on the front end backwards. So this is the UI we need, which I've already got some of.
That's fine, I just need to tweak it. So I just want to write down in baby steps what I need to tweak so that I don't get lost and stuff. A lot of it is just me breaking stuff down so that I don't just end up fumbling around a bit.
Then, the. So work out with that is plan what needs to be captured in a database and set up the structures or adapt the structures I've got in the superbase to make sure that I've got the right information. Work out what API calls I need and then work out what auxiliary stuff I need,
like the upload part of it, the upload form, and the processing and stuff. So it's just breaking down what pieces I need and then just hammering them through.

**ray@statechange.ai | 04:17**
Okay, this does sound like the kind of thing I can help with quite a bit, right? But I think you might be overestimating how much you need to plan before you can start to build it. It seems like the essential... It seems like there's an essential pipeline here of "Give me your deck through uploading and then on the backend, giving them some kind of report."
Okay, so it seems like there are then three essential steps. The first is where they are able to upload. What is the processing required in the middle? That's frankly the most interesting part.
Then what is the report you need to give them at the end? Now how are you imagining giving them the report at the end? Can I ask what the medium is?

**Ellie Rofe | 05:10**
Initially, I'm thinking it's a web page and then an option to download it as a PDF because it seems that that's quite trivial to set up.

**ray@statechange.ai | 05:24**
Okay, what about a form that gives them two things, which is upload your up upload your presentation and give me your email address and all you do is email them the PDF this way you it becomes lead capture immediately gives you the data, right?

**Ellie Rofe | 05:41**
Yeah.

**ray@statechange.ai | 05:42**
It gives it back in the same format that they're giving it to you, which is the PDF.
And then it's like, you know, you're able to send it back with, you know, here's. Here's your thing. Along with an invitation to talk...

**Ellie Rofe | 05:57**
Yes, so that all those parts of a funnel will be there in the capture. I would ideally like to know what stage they're at if it's not there.

**ray@statechange.ai | 06:07**
Sure, for the front-end form, right? Exactly.

**Ellie Rofe | 06:10**
Yeah, it might, but it's not always so fortunate.

**ray@statechange.ai | 06:10**
Although that might be implied by the presentation, right? Sure. Yeah, and in fact, it might even be part of the problem, right? That they're raising at the around...
I mean, they're calling it a C because it's their third bite at the apple, but they're not really a C-level investment.

**Ellie Rofe | 06:28**
Exactly. Yeah, there's all sorts of, like, questions around that. It's there's so many different parts you can try and capture. Like, when I think about the sort of parameters you've got like the vertical, the stage, the geography, but I think the most is the stage.
And everything else can either be inferred or worked out later. It's not the most humane thing to this, but I think out of everything e mail name email stage I had considered are you currently raising or just preparing as one question just so that I understand a bit more about where they are.
And but that's it. And then upload the deck processes through. And I plan to show them something on the backend. Partly because that gives me something to sort of chat about on online as well. It's sort of fancy and interesting and video worthy of, like, showing the stuff, but maybe a PDF it's just.
Yeah, I'll think about that.

**ray@statechange.ai | 07:33**
The reason I bring up the PDF thing or whatever is just an eye towards making your life simpler, right?

**Ellie Rofe | 07:40**
H yeah, yes.

**ray@statechange.ai | 07:41**
Like, are you a great web developer? Great. Then develop a great webpage. Are you a great creator of documents? Then create a great document.
Let's put you in a position of strength because if anything, the webpage is a distraction from what you really want, which is for it to show up in their inbox if they have a way of getting to it that involves not having to use their inbox.
Well, then isn't it much more likely they're going to give you a fake email address or whatever so you don't have to be contacted? Then you won't want to require a bit of trust from them, right?
Then you redeem that trust. Anyway, all of this by the way when I ask about the planning, the best planning is what can you cut? I wrote a line about Musk talking about how engineers keep on optimizing things that shouldn't exist.

**Ellie Rofe | 08:30**
Right?

**ray@statechange.ai | 08:32**
Well, I think that sounds fantastic. So it was like, what's the front end? Does that need to exist that you need to code? Is that like just a type form or something that you just need to embed right? That way you get to stay focused on the data.
Now we get to what you're talking about with the other bits, which is okay, what's in the middle there, right? Which allows you to turn from A to B. Can I ask what's the mechanic through which you're...? Is it just...? Where are you doing the processing of it?

**Ellie Rofe | 09:03**
So at the moment, I use the Claude PDF endpoint to extract the information and work it out.

**ray@statechange.ai | 09:09**
In Jeff there of Suff Yashire.

**Ellie Rofe | 09:13**
I'm sorry, Postman's just arrived. Then I will... I pass it through so I get it to analyze all the slides individually and the deck as a whole.
So it goes through a number of passes, but it's all layering up on the previous. Yeah, so it's... I've practiced or played around with that for quite a while now to work out the best process. There is another option which is just to create pictures from the PDF and just push those through a vision endpoint. It doesn't make a massive difference, to be honest.

**ray@statechange.ai | 09:45**
Interesting. Okay, well, the reason I bring that stuff up is that I think what people really want is to hear something they didn't already know.

**Ellie Rofe | 09:56**
Yes, sorry, one second. I'm going to have to just grab this bin thing, man.

**ray@statechange.ai | 09:58**
Yeah.

**Ellie Rofe | 10:31**
Sorry, I was talking about Musk. That was my new styling...

**ray@statechange.ai | 10:41**
It's wrong. I actually just discovered that we've been losing Airnet overnight over the course of the last month or so, and my Mac has been failing over to work with my hotspot overnight has been driving up my data bills to the roof.

**Ellie Rofe | 10:47**
No?
Yeah, I can.

**ray@statechange.ai | 10:58**
My wife and I could figure out why we were being charged for overage over and over. What's going on?
I'm pretty sure what's going on is it loses connection and it was just talking to my phone and like, "Hey, how you doing?"

**Ellie Rofe | 11:08**
[Laughter] I'll take you, thanks. Yep. Wow. Is that with Link?

**ray@statechange.ai | 11:15**
Apparently, yes. Sorry.

**Ellie Rofe | 11:19**
Is that with Starling?

**ray@statechange.ai | 11:21**
No, it's not. Sterling. We actually have a wired connection which is fairly reliable, but I think it's just been fleaky on the overnight. And I think there's like a new feature in Mac OS that it will more aggressively, you know, go over to the hotspots so it doesn't, you know, lose its connection, which overnight. Whatever. Stop.

**Ellie Rofe | 11:38**
Yeah, exactly. We don't need this. So people want something they didn't know before.

**ray@statechange.ai | 11:47**
Y so the anyway, the development of insight, I think is going to be the most valuable thing. Lots of people create things that are pretty. I just got pitched by, Mark Pearson over, you know, the guy who was very chabby overs change, and he was.

**Ellie Rofe | 12:03**
His native a im.

**ray@statechange.ai | 12:07**
Yes, well, in his case, he was pitching on a company that's making pitch text for him that he was very excited about working with. I am very glad, I suppose.
Yeah. Someone named Melanie Platt from Pitchers. I don't know if you're familiar with the name.

**Ellie Rofe | 12:23**
Okay, interesting.

**ray@statechange.ai | 12:26**
I'm going to copy the link address I'm sticking into the chat. So you know about somebody else who's out there?
But the reason I bring it up is that lots of other people are saying, "Hey, we can give you a thing that looks like a thing, but where it's you being able to share a real level of insight, like just a taste of what it's like to work with you." That would be the thing I would be most excited about.
The reason I bring it up is that's in the middle, right? The ability to gather the insight.

**Ellie Rofe | 12:54**
Yeah, absolutely. I have done a lot of work on that in various guises now on how those problems act and how they come out.
I think the thing now is just edge cases. It's just working out like I discovered with the pitch analysis when I was doing a public... Doesn't understand moonshots. So then you have to go in and tweak and adjust.
I think for this, I just need to get people to give me their decks and tweak it. And to be honest, if it comes out with bad stuff, I get an opportunity to have a chat with someone who might be angry, but will at least get to see me
resolve something. Sometimes how someone resolves an issue can make you much more attractive to them as a potential partner and things. So, yeah, there's... I'm just going to... The goal, hopefully, is to just have something functioning that I can get out and get people testing.

**ray@statechange.ai | 13:53**
Sounds awesome.

**Ellie Rofe | 13:54**
Yeah.

**ray@statechange.ai | 13:54**
Okay, well, I was only probing on the planning thing because it sounds like you might have a simpler setup and what you've seen to now have described as a simple front end, simple back end.
Then, the interesting part of the middle keeps you focused on the part that's probably the most intellectually interesting to you anyway, and that will add more value and can be shrunk.

**Ellie Rofe | 14:17**
No. My weakness is I absolutely love developing front ends, but it's not like it's not where I should be spending my time. It's just fun and delightful, no?

**ray@statechange.ai | 14:27**
Well, right there, there's a little bit of a lesson here about what was her name? Maddy? The person he worked with over there, right? Who hired someone else to do the pretty front end?
Right? But didn't have a brain, its pretty head. I know that you can make things pretty, but the fact that you've got a brain is your big competitive advantage.

**Ellie Rofe | 14:47**
Yes, yeah, I'm trying to lean more into that. [Laughter] It's so ridiculous. I try to lean more into having a brain. [Laughter].

**ray@statechange.ai | 14:57**
Which time which I look forward to. Yeah, I saw your recent post about, like, the three things in Hetech, and like, just, like, get more li brained, and I'm excited about that.
Okay, so we're talking again later this afternoon.

**Ellie Rofe | 15:14**
Yes.

**ray@statechange.ai | 15:15**
Okay.

**Ellie Rofe | 15:15**
Yeah.

**ray@statechange.ai | 15:15**
Is there any...? And it sounds like you're off to the races. It's a full six hours. Is there anything I can do for you between now and then that would help you in terms of staying on track or having this be a good afternoon project for you?

**Ellie Rofe | 15:29**
I'll tell you what would be useful, and it's something because I'm not a developer. Sometimes I end up a bit... Do you have a stack where you just go right for something like this, which is a simple project like this? This is what you do as the setup. Or is there a plugin or something or a Git repository that you'd just be like, "Clone this as the basis of something like this?" Or is it just to tell the AI to get on with it
and let it choose the right things?

**ray@statechange.ai | 15:58**
Well, AI often has pretty good choices, but what I would do in this situation is I would outsource the form to someone else, right? I'd use a Jot Form or a Type Form or whatever, right?
Say, "Okay, put in your thing. Here are my other questions." Sure, have it there being embedded on your page, make it not your problem, right? Then all it does is send data to whatever the... Now we're probably talking about running a server function, right?
That's going to be doing whatever it is you want to do. You're using Superbase. You can totally use Superbase functions for this, right? Now you have... Okay, well, I've got this, and it's sending data here.
Now AI you're working on that, right? That recipient of the function because it's job is to take the data that came in the door process, produce a document, and email that document out. That seems like a job to be done, right?
Of course, store stuff in the Superbase database along the way. By doing that, it becomes much simpler. The one other thing I do in these situations... You know what you're doing, you want to deploy to that function, but it doesn't need to start there, right? It can start locally and then you can push it up.
But you get the AI to help you with that. The thing I have found that really helps is I keep on instructing the AI to... And this isn't quite a stack, but like, this is the instruction I found to be helpful.
You'd even stick into your Claude empty or whatever. It doesn't put its prompts, its templated prompts, into separate markdown files.

**Ellie Rofe | 17:36**
Yes.

**ray@statechange.ai | 17:38**
By not having it in the same just in with the code, it makes it a lot easier for you to examine the most important part of this.
Because really, what this thing is doing is stringing together "I'm loading this into the memory and blah." Now you want to get the... But the big judgment. The part that's going to be the reflection of Ellie insight is going to be in there.
Then you can say, "Well, you know what? Maybe I want to get the AI to put something in there." Maybe you just want to go touch that file yourself and that becomes a lot easier to touch.

**Ellie Rofe | 18:04**
He.

**ray@statechange.ai | 18:07**
Modify that file because you're not dealing with all the orchestration stuff, which is more Cody and at the same time far less added value.
Because a big added value is going to be whatever reason in that props.

**Ellie Rofe | 18:16**
Yes, I did eventually work that out when it automatically put in loads prompts in line with code. And I was like, it's just it's even if you can read the code, which I can now, it's just less fluid. Being able to just, you know, go and tweak and change and adapt and everything that I having to worry about, you know?
Yeah. Okay, cool.

**ray@statechange.ai | 18:37**
Sure, but th that that's my biggest thing. And then otherwise, you know, in second, you're thinking, well, can I just sort of turn this into something AI does for me? Like can you turn something that like some other service provider does for you is even nicer because that way you're not trying to wrangle that the AI is doing something wrong or you're only paying peripheral attention.

**Ellie Rofe | 18:57**
Yeah. I think I got fed up with everything. I found the freedom of getting the AI to do something with things like forms was quite amazing because it could do it quite well compared to having to faf with type form or something.
But I think you're right. It does open more potential bugs and things that type form has just worked out, so...

**ray@statechange.ai | 19:21**
That's a good point. You can ask, "Could the AI simply configure that on the service provider for you?"

**Ellie Rofe | 19:29**
Yes.

**ray@statechange.ai | 19:29**
Which I found be helpful as well anyway, but I'll that's sort of my you make a good point.
Like if you find yourself just sort of wait using the vendor isn't worth the juice. You just sort of, you know, go have the AI build it and you do it with the. The North Star is like how to minimize your complexity for that part and then could be what do you want to focus your attention on a part that has the biggest value added?

**Ellie Rofe | 19:44**
Yeah, yes, absolutely. Okay, let's see what I can get done in the next six and a half hours or so.

**ray@statechange.ai | 19:51**
Okay, awesome. I'll talk to you later.

**Ellie Rofe | 19:56**
GenAI to.

**ray@statechange.ai | 19:57**
Bye. Three.

