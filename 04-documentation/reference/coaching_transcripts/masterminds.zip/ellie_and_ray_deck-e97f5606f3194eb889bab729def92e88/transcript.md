# Ellie and Ray Deck - Sep, 22

# Transcript
**ray@statechange.ai | 00:12**
Hello, Allie. What do I find in the world today?

**Ellie Rofe | 00:16**
I am in my brother's house, which is next door to my bum's house in Buntingford.

**ray@statechange.ai | 00:24**
Wow, you guys got the best names for things. Funding works a lot it.

**Ellie Rofe | 00:25**
[Laughter].

**ray@statechange.ai | 00:31**
Okay, so. Well, I suppose I need to ask what kind of week it's been because I tried to brief myself through the weekly.
We haven't done it in a couple of weeks now.

**Ellie Rofe | 00:39**
I know, I've realized. I'm so sorry, it's been chaos here. So, it's not quite as case. It's just been difficult to keep up because I think my mom is unfortunately getting dementia.
So, it's a fractious time when I'm here, and it's very difficult to keep up with other things. So, I find myself running from pillar to post and various panics and all sorts of problems. So, I realized as I was driving back from dropping my arm off that I hadn't done that again.
So, I genuinely apologize, and hopefully, I will be back to normal from tomorrow. I'm traveling back tomorrow.

**ray@statechange.ai | 01:24**
Okay, a tactic Robert uses with these is we switch him from having a more structured output.

**Ellie Rofe | 01:30**
Two.

**ray@statechange.ai | 01:34**
He is much more comfortable just writing some paragraphs.

**Ellie Rofe | 01:37**
Yeah, this.

**ray@statechange.ai | 01:39**
So, if that is more comfortable for you, the point is to be keeping this record of how you've been doing. A certain amount of it is about KPIs, but a lot of it is just where your brain is at.
The document is useful for certainly for us being a running start to our conversation. That's really useful for you to be able to review and be able to see the trend of it. If we don't have the record, then you don't get that benefit.

**Ellie Rofe | 02:05**
Yes, I fully agree. I'm not just ignoring it or not interested in it. It's been intense. There's been... I've been caring for people, one of them has very much got dementia, and one of them probably has. Yes, it's been a tricky time. I'm constantly interrupted by my brother and his kids and stuff while I'm here, so it's hard to fit in clients and client work and just keep up a basic level of anything. I'm here at the moment?

**ray@statechange.ai | 02:35**
Totally. Hear that? I suppose what I'm trying to do is put together a combination of the "why" it's important and then for you to get clarity on that, being able to identify how to 80/20 it.
Right? So sometimes people say, "This thing is important, you really need to do this." But it's not that you need to do this. The question is how we can get the value of this in a way that's compatible with what you're doing. The thing I'm responding to a little bit is the idea that next week I get to be normal. I can't tell you how many times I've heard that in sequence over the course of a year from an entrepreneur. Next week, it'll be normal.
I'll be able to do this stuff. The question we really need to answer is how in the midst of the current chaos do we do this stuff that's important, right? The stuff that's not important that burns now, and I bring up Les to focus on this particular document.
But it becomes a useful thought exercise, right? For how in the midst of the chaos that you're in right now to be able to sift out what's important, what's not, and make sure that you're doing those things in a way that's actually compatible with all the other stuff going on because I certainly hear what you're saying. I just got the news that the metastas have now reached my uncle's bones.
It's.

**Ellie Rofe | 03:53**
Sorry.

**ray@statechange.ai | 03:53**
You know this.

**Ellie Rofe | 03:54**
It's horrific.

**ray@statechange.ai | 03:56**
This is the guy who's probably been the closest to a father figure I've had since my own father died, a quarter century ago. I've had other relatives and
situations like you're talking about as well as just my own health issues, going through cancer and what have you. All of which, by the way of saying, I've got some experience with chaos, right?

**Ellie Rofe | 04:16**
Yes.

**ray@statechange.ai | 04:16**
And totally hear what you are saying. So, when we're getting into more of a chaos mode, it becomes very tempting to think, "This is the thing I should do," and things are too chaotic, so I will do it tomorrow. As opposed to what I think is the thing that requires a more cognitive investment but pays higher dividends, which is what is the most important stuff that needs to be accomplished
and how can I make sure that stuff happens right? It is perfectly okay to be making it happen in a way that does not involve just you doing it the right way or what have you. I'm a big fan of saying, "How can we? How can I just do this wrong?"
Because that's better than not having it all.

**Ellie Rofe | 05:05**
Yeah, okay, I do think I am increasingly coming back to... It worked very well for a while until it didn't. For her personal reasons,
but I do think I need to find a VA or some sort of person I can pay for fifteen minutes a day to just do a live check every morning because I think I need external structure to get... To get focused and make sure that I'm even reflecting on what I need to do that day rather than waking up with my hair on fire.
I think that there is a huge... It really was working well when I was doing it with Charlotte, and I don't mean to disrespect her personally. I didn't need a DHD coaching from her. That's not what she was doing for me. I just needed someone there so that for fifteen minutes every morning, I was working out what I needed to do, where my tasks were, like where my project was, basically reorienting myself each day.
Otherwise, I think, yeah, it just doesn't happen for me. So I think that is a really important way because within that, then I know that I've got it. It puts me in the right frame of mind to do exactly what you're saying.
It's not a high investment. It's not like, God, if I do this and it's taken a massive chunk out of my day. It's almost like the old reticular activation system where it's like... You know, if you buy...
It's the reason affirmations work. If you buy a red Volvo or something and suddenly you see red Volvos everywhere because a little part of your brain has been primed to notice that thing that you hadn't noticed before.

**ray@statechange.ai | 07:07**
Yes.

**Ellie Rofe | 07:07**
And why affirmations can work if they're done structured correctly. And I think actually, this is my form of affirmations, it's like I don't need to sit there and state things. I need to just go through and go, "I'm reorienting my brain towards this today rather than letting it just flow.

**ray@statechange.ai | 07:24**
Yeah.

**Ellie Rofe | 07:26**
So I think it's a really astute observation. You're right. It's managing stuff in chaos because if especially if things are going the way they're going, I suspect there will be some level of chaos for quite a long time to come, so...
Yeah, absolutely.

**ray@statechange.ai | 07:44**
Yes, and I might just quickly note, entrepreneurship is chaos.

**Ellie Rofe | 07:50**
Yes it is. That is a very was rushed.

**ray@statechange.ai | 07:53**
So the, you the prize, right? For being successful in building the practice is gonna be having more chaos in the business as well as, you know, it's gonna have.
What's going on with the family friend, et cetera?
So like, you know, this is where like just the and that's the reason I bring up the tool set, right? Tools for working in the context of chaos. As opposed to saying no, today was chaos, tomorrow will be chaos.

**Ellie Rofe | 08:15**
[Laughter] Yes, I did.

**ray@statechange.ai | 08:17**
I'm pretty sure tomorrow's going to be chaos, too.

**Ellie Rofe | 08:25**
Again, I don't know why I keep referring to him when I listen to so many other people, but he does have some good ways of putting things. I did love it when Daniel Prieste was like, "I spend all my time trying to get to the perfect repeatable week because I know that you need to be able to create some form of flywheel in a business."
But as soon as I get to that, I get bored and I try and mess with it and try and do other stuff because I want stability, but I just want chaos. And it's like... I think there's an awful lot of that. If everyone who is trying to build a business just wanted the same thing day and day out, they'd have a
like.

**ray@statechange.ai | 09:02**
Yeah, but you're totally right. It's a difference in the things that you want. I was thinking about that. I was talking with another DRC changer earlier this morning who's got a client who's just running into the... He sees how that client is doing all the things we've talked about in entrepreneurship of building first and being very happy, getting to be an important person, taking a lot of meetings and taking meetings with vendors and being really loved by those vendors because I just want to take their money.
But where's the sale and all that? And that's tough because they're clearly going down a road that we've seen before, the stations you've seen before, the road
we've been on ourselves. How do you get that person off that road? The comment that I made was that this person is often looking for the more chaotic it gets. Their idea of why they want to be in the entrepreneurship game in the first place has to do with their idea of freedom.
Their idea of freedom is nobody saying no to them, and that's... The perfect week that Brisley is talking about is when nobody else is imposing their chaos on him. So, he then turns around and simply brings his own chaos, which can be fun for a minute, and then you're back in the chaos, and we're still left with the question: how do we manage the chaos?

**Ellie Rofe | 10:27**
[Laughter].

**ray@statechange.ai | 10:36**
Right. That could be something that becomes an ongoing thing for our conversations. Although bringing back to the original... It's a lot easier when I have a little bit of a sense of what the chaos was coming to the conversation.
I think we've had that part of the conversation. We get to move on now.

**Ellie Rofe | 10:52**
Yeah, no, I fully understand. Yes, I think that chaos is a really interesting thing. But yeah, I will... I think that touching point is just important. I will look for some people today and see if I can just find someone who will literally be there.

**ray@statechange.ai | 11:12**
Yeah.

**Ellie Rofe | 11:13**
It's reliability as much as anything. They don't even need to do anything.

**ray@statechange.ai | 11:17**
Yeah. sure. I can quickly add. I mean, can you quickly ask like whether. Sort of what happened with the Charlotte stuff for you at the end.

**Ellie Rofe | 11:25**
Yeah, I had every sympathy with her because I think she started not showing up for the calls and then not responding and not... So we had a call that would be 9:00 am in the morning, and then she wouldn't reply. She wouldn't mention anything till 6:00.
She went, "Sorry. Actually, no..." Which was the thing that finally got to me in the end. But I realized something had started to happen because she was quite bouncing and into it all.
Then she said she'd had a breakup and it was all bad, and I was like, "I totally.

**ray@statechange.ai | 12:02**
Yeah, she turned on me that.

**Ellie Rofe | 12:02**
And how?

**ray@statechange.ai | 12:05**
I mean, I turned on her, and she didn't do anything evil to me, but she just became a lot less reliable, a lot less helpful to me.

**Ellie Rofe | 12:07**
No, yeah, she was having some trouble.

**ray@statechange.ai | 12:10**
And the course of home.

**Ellie Rofe | 12:13**
And did say, "Do you just want to take a week and just try to take a breath and get back into sleep and whatever else you need to do?"
She kept saying no, and then she kept just not turning up again.

**ray@statechange.ai | 12:27**
Yes.

**Ellie Rofe | 12:28**
And gave her another chance, and she said no, and then just kept not turning up again. Then she did turn up for two sessions where she had the camera off and clearly wasn't listening at all to what we were saying and what was going on about, and then didn't turn up again.
So basically, I said, "Look, this isn't working." You know? I understand fully where you are. I'm really sorry that that's where you are, but the whole point is reliability.

**ray@statechange.ai | 12:53**
Yeah, yes, I totally hear with that.

**Ellie Rofe | 12:56**
So yeah.

**ray@statechange.ai | 12:57**
I'll just say that a good employee is a point in time. The things need to align with who they are, where they are in their lives, and what your particular needs are.
These things often fall out of sync fairly rapidly when you are in entrepreneurship. It's one of the tricky things. Wait, all of a sudden, why is nothing getting done?

**Ellie Rofe | 13:12**
No.

**ray@statechange.ai | 13:18**
You've got the wrong people.
I hired the absolute best people.

**Ellie Rofe | 13:21**
M yeah, and I completely recognized I really appreciated her ambition and her initial sort of she clearly had worked hard on that business, just like completely slacking it.

**ray@statechange.ai | 13:22**
For what? You were six months ago.

**Ellie Rofe | 13:38**
She'd put together the materials. She was doing training programs. She was really thinking about it, so I completely understood. I just recognized at that age, things like that throw you off course even more than they do now.
That would.

**ray@statechange.ai | 13:52**
2.

**Ellie Rofe | 13:53**
I totally get what was going on. So, I didn't... It wasn't judging. It was just like, "It's not going to happen.

**ray@statechange.ai | 13:59**
Well, we see that, and I remember I had... I was doing this other business, a business I tried to build in 2018 with a partner. He... I got to witness the dissolution of his marriage as he went from being a little concerned about his wife's friend at work to... Yes, it all went a certain way.
But that I'll just say that the we talk about young people and their relationships and this. This guy was over 40, and he was just wrecked by this and it took down the whole business because the business was predicated on the partnership.
The business was predicated on the partnership. When one partner is just totally going off rails, eventually, doing some very stupid things, he was a lawyer. He did some stupid stuff with his law practice. Law practice in the US involves managing money.
He did things that I think were more sloppy than malignant, but got him into trouble.

**Ellie Rofe | 14:52**
Yes.

**ray@statechange.ai | 14:58**
And like, all of a sudden. Wait, if you're not, you know, a totally high quality, you know, well respected lawyer, the marketing value of the partnership goes to zero.

**Ellie Rofe | 15:07**
Yeah. Misuse of client funds tends not to look great, even if it's.

**ray@statechange.ai | 15:11**
It really doesn't look good.

**Ellie Rofe | 15:15**
Go.

**ray@statechange.ai | 15:15**
Anyhow.
I'll which by way of saying that, like, I think these, you know, matters of the heart affect us all.

**Ellie Rofe | 15:21**
Yeah, no, it does.

**ray@statechange.ai | 15:23**
Okay, so can we just check in maybe? So, with all that in mind, what has been happening with you this week?

**Ellie Rofe | 15:31**
Yes. So, as I say, it's been a bit all over the place, but I have had a positive meeting in person down the road in Buntingford, which was very unusual, with Adja, a Pilla tech.
So, the guy that I gave... You've got to make a decision. He made a decision to go ahead with his anti-microbial stuff, which is fabulous. He's specializing there. What I hadn't quite realized before we met Up that he's actually very well connected.
So, he is going to introduce me. He's at a place up the road called Stevenage, and they have a kind of lab, biotech, campus-type thing at Park.

**ray@statechange.ai | 16:27**
2.

**Ellie Rofe | 16:29**
And going to introduce me to the guy who helps with business development as part of that and see if I want to go. They'll bring in AstraZeneca to come and talk to them or have a bit of a beauty pageant or whatever.
I will go and potentially talk to them about pitching, structuring a pitch deck, and seeing if there are some people who want some work.

**ray@statechange.ai | 16:47**
He.

**Ellie Rofe | 16:52**
He he's being mentored by one of the guys who did, you know, Crisper, you know, like, yeah, the three big companies that came out of that.

**ray@statechange.ai | 16:59**
Yes.

**Ellie Rofe | 17:05**
I can't remember.
I think he said he's inspired or something. I can't remember.'s being mentored by this guy who was one of his best MATES from his PhD who happens to run a VC and is obviously with Crisper. A massive deal.
And so he said, this guy is trying to help him raise funds in terms of structuring his science so really deep into how the what investors need to see and how to define strategize his trials and tests and stuff that he's doing at the moment. Experiments.
So I said to him, well, look, one way you can pay me because it's like I want to pay you as well, by the way. Like this shouldn't just be free. I really appreciate everything you've done. We're just waiting until we get some more, like we win some more service contracts in the business or something.
And I said, well, one way you could partially pay me is by saying when we get this deck finalized, hopefully in the next week or so, showing it to this guy and saying, look at the difference. She's really helped me. Is there some, you know, do any of your portfolio companies need it?

**ray@statechange.ai | 18:12**
Yes.

**Ellie Rofe | 18:13**
Yeah, so it was a really useful meeting. There are a couple of other people he mentioned introducing me to. I've got some notes somewhere, but my brain's got a bit on those now. Yeah, it was a really nice meeting. It was good to meet him in person.
I think it makes a massive difference when you meet someone in person because they're real. I'm trying to come back in October as well for more meetings. I've got a call booked in with a guy who he was doing a startup.
I think he's... I'm waiting to hear more from him. I think he's gone back into equity research, but he knows a lot of people who are doing startups in different realms. He's one of the equity research guys because they work across so many different verticals.
So I've got a meeting with him, but I'm finishing off the work with the woman from the Crick, so tomorrow, Wednesday, I'm doing that. That's been interesting because she keeps working on the deck whilst I'm trying to work on it.
Like I was saying, we're going through the process. This is we have to get the story right, and then we get the beats right.

**ray@statechange.ai | 19:24**
Yeah.

**Ellie Rofe | 19:25**
Like have to get the investment thesis right. Then we get the beats and the arguments and the story right. Work out the proof points. Then we go out, and every time I talk to her, she then goes and frantically works on the pitch deck.
So it's interesting. She's massive, achieved like huge overachiever, this incredibly smart woman from Cuba who has decided she's going to do a hundred-mile race, and she's really disappointed that so far she's only managed a 50-mile race. So I think she works a million miles an hour. It's been an interesting thing in terms of slowing her down enough to actually let the process itself work out rather than constantly jumping the gun.
But yeah, huge.

**ray@statechange.ai | 20:11**
Okay, well, I'm... which is okay, I guess in this question like, "What there's a little bit of that about her." What about how do you think that connects with your practice though?

**Ellie Rofe | 20:26**
Yeah, I wonder. I tell people verbally what the process is. I do say, "Try not to work on the deck in the meantime." I have been wondering whether I just have to accept that some people will... Because they will just be...
I think there's a bit of a gap sometimes because people just keep taking meetings, and I do keep trying to say to them, "Make the most out of those meetings by going in with a deck that really makes sense rather than just going into a meeting because you've got a meeting." Try and do it once. Try and take those meetings once we've done this process rather than just rush in on it because then you're talking to people without the right deck.
But I think they're so excited and they're so desperate to get feedback, and they're so hopeful that this meeting will be the one that does it.

**ray@statechange.ai | 21:23**
Eight.

**Ellie Rofe | 21:23**
And I think partly it's communication on my end,
and partly, I think I'm going to have to accept that some of them will just keep doing it because they're manic about it and they just... It feels like control to them. What do you think?

**ray@statechange.ai | 21:36**
Yeah, I think that's the last one that's the key: control and freedom, right? The reason they're doing entrepreneurial stuff is because they're looking for freedom.
Now you're saying you want to have more control. What you're describing and part of the reason I want to go a little deeper into it. This is a pretty common tension as you move into more senior work. See, when you're more junior, they're handing you the deck and saying, "Go fix it," and then you go fix it, right?
But you're doing relatively junior-level work on it because, of course, you're not privy to their brains. You're not improving the storytelling, or if yours really only around the edges, right? You're giving it nicer colors and whatever, right? Are things you can do when you don't have access to them.
As you have more access to them, you're able to make a bigger impact. But you're absolutely much more at the mercy of what they want and whatever their schedule is. They're not handing it to you to say, "Go fix this and give it to me tomorrow.

**Ellie Rofe | 22:32**
4. He.

**ray@statechange.ai | 22:32**
The tomorrow." process you're going through, like the month or whatever, is helping evolve their brains.

**Ellie Rofe | 22:36**
47.

**ray@statechange.ai | 22:37**
They are looking to have you make their brains better, but they're not looking to just give up control or they're not likely to give up freedom, right?
That means that with there, there's a view of doing this higher-end work as being a progression, right, from being the outsourced stuff. But actually, it's different in right?

**Ellie Rofe | 22:59**
He.

**ray@statechange.ai | 23:00**
What you're providing them is advisory work. Your biggest impact is as much on their brains as it is on the document.
So certainly, they can look at the document afterwards. "Hey, this document is so much better." That becomes a way you can show what's going on, but that's not really the real benefit.
Because that's not how the real benefit is going to be in their presentations and their relationships with the investors, right? Because it's an IR game and it's not really the method. So what do I bring all this up to? I bring all this up because I think it's great that you have this client who is jumping in and wanting to make changes and what have you.
Because the highest form of what you do is getting them to own those changes, right? Because the changes are really coming from them. You're a vector for their ideas, really, and you have some frameworks through which their idea flows, but if they're owning those ideas on the page, that's something to be encouraged rather than discouraged.

**Ellie Rofe | 23:55**
1.

**ray@statechange.ai | 24:01**
Now if what they're doing is they're doing it in a chaotic way that is not going to sell as well, then what you're looking to do is influence that flow. You can redirect the river, but you can't... Now that there's this different set of skills. Actually, I think you do.
I've seen you in conversation. Do you do quite well at just helping them see more clearly what it is that they really want, and then they can go down that road? Which is not necessarily the same as the road that you would have had them go down.
Like when I'm having these conversations with you or Robert or Demetrius or even on this level, you're going to do what you're going to do in the next round.
It's one of the reasons why the weeklies are so important because we can talk about a thing, I can have a mental model of. This is the stuff we talked about, and then we went down a different way, which could be because of circumstances. It could be because of where you are, what you're finding to be working for you.
So, me discovering that as part of my job, right? As you know, and to help you elevate the best part of yourself, right? So similarly, you're doing that for your client. So I think you're going to find this person who's running around. They may not be exactly like the what every other client is going to be, but that smells like what this high-end work is.
You might embrace that a little bit and learn from it. Because if you can get the clients who are more passive to be a little more like this, they will own it more. They will bring it into their presentations. They'll be more successful business people, right? As they are, but they'll be harder to work with, right?
Because they are moving even as you're trying to make things go. Because basically, in order for them to get that greater amount of freedom, you need to be giving up more of that control, and they'll pay you more for its.

**Ellie Rofe | 25:59**
Yeah.
Yeah, that's really interesting. There is definitely a part of it where I'm feeling like, please, stop doing this. Just give me the deck. Because it's like a sense of impatience in me.
It's a really interesting reflection that instinct isn't the right instinct. And I guess the question then is, how do I impart some of it? It's just that they don't know how to do the storytelling, so they're constantly overcomplicating or messing up the flow of it all and that kind of stuff. Some of it is that they just don't know how to do visual storytelling, so I'm not just talking about design, I'm talking about the way they express certain ideas visually. It doesn't make
is the role not just coaching? Is it education? Am I trying to teach them how to do better stuff? Because I guess in my head, I've always been like, you have much more important things to be doing than fiddling around with PowerPoint slides.
That's in my head. But maybe I don't know, maybe I'm missing opportunities there. Does that make sense as a question.

**ray@statechange.ai | 27:28**
I think there's a spectrum, right? Where we might call it influencing teaching and doing right. As you move up the ladder, you discover you're exposed to more of these.
At the most junior level, we talk about the doing, right? That's saying, "Hey, make this thing pretty." That can be done as a doing thing, but perceiving that to be not a thing that I do right?
Then there's the teaching part. The teaching part is imparting some combination of data, frameworks, ideas, really into their brains, it is usually that they did not have before. You need to figure out which ones they are almost ready to accept, right?
That's going to somewhat drive the direction and the pace of the engagement. Then there's a higher level of it. The guy who's written about this the best, Robert Keegan. He talks about how the way we talk affects the way we work and community change. Two of his bigger books and he talks about what he calls adaptive problems where "adapt" was technical problems. Technical problems are ones where you have this problem. Here is the solution, here is the recipe, here is what we do.
Education often looks like that, but this higher part, the counseling part, is about helping them look back in themselves to understand what it is that they really value. To understand the things that they, as he describes it, the things that you know that they know are blocking them, right?
Then getting behind that. Why? What are the values they have? They're then causing those blocking behaviors. They're then blocking the thing that they perceive needs to be changed or improved.
These adaptive problems are completely different because that's not you imparting knowledge to them, right? That's you enabling them to gain knowledge out of themselves and that they need to have that deeper level of understanding themselves in order to be able to make the changes that are adaptive challenges as opposed to being technical challenges.
So, as we get more senior in these gigs, you find that the nature of leadership, advisory, counseling, coaching, whatever the word is we're using for it.

**Ellie Rofe | 29:53**
5.

**ray@statechange.ai | 30:00**
Like, it really coaching?
It's all the same thing, right? It's just a bunch of syndromes, but the seniority of the relationship, and the more trust you have in the relationship, the more value you get from being higher in that spectrum, right?
This is why, a therapist probably has the most privileged position in that, right? But you're not at that level, but there is an aspect here of by understanding where they are...
Okay, why do we think that you need to get all this stuff? Okay, sure. What? Why do you think this stuff is really important? Can we talk about when you've told these stories before? What were they found? Not so much to get them to acknowledge that they are wrong, right?
But if they understand why they feel these things are important, then you can really drill down to what is that key 20% that they're trying to not lose or that they perceive to be important. Maybe when they look at it in the mirror, they're like, "Wait, this is less important." Or maybe it is important, but it doesn't need to be the whole thing. This is why it is tough talking to CEO types because they both have the responsibility for sales, which is mechanical, but they've got responsibility for the idea and for being and for the goose that laid that particular egg of the idea, and there's an ego that goes with it.

**Ellie Rofe | 31:27**
M.

**ray@statechange.ai | 31:31**
But just need to understand the internals, the goose.

**Ellie Rofe | 31:34**
Yes?

**ray@statechange.ai | 31:34**
And they need to understand that for themselves. The reason I bring all this stuff up is that as you get more senior with these folks, right? You're going to find that you're absolutely right. Yes, it's more education than it was doing right.
The education, and I sometimes talk about the code in someone's head as opposed to the code that's given to the computers. Being part of that's most important. I think similarly here, there's an aspect of the marketing ideas, but then there's a level above that gets to...
Okay. What's going on here? It's not something you can open the engagement with, but as you have more trust with them, it becomes a place where you drive more value because you can help if they understand themselves better and understand the reason why they have these kinds of resistances.
The way they're thinking about those things. You can be the whisperer, helping them take the best part of that, right? And then not have the other part that's holding them up.

**Ellie Rofe | 32:34**
Yeah, okay.

**ray@statechange.ai | 32:34**
You're able to provide a whole lot more value and have a higher impact for them, which, of course, then shows up in their willingness to continue to do business and fees and all that.

**Ellie Rofe | 32:45**
I can definitely see how this fits with me talking with Enid about this, because she's absolutely a doer, and she's feeling that need to keep moving.
But she's just splashing around, exhausting herself in the water. So, yeah, I can see how there's a way to coach her a bit more on that. Yeah.

**ray@statechange.ai | 33:28**
Well, there are different ways this can look.

**Ellie Rofe | 33:28**
Sorry.

**ray@statechange.ai | 33:31**
Like, for example, somebody who really wants to move fast. You know? Hey, I've got a weekly cadence and like this.
Like, maybe that person just needs a daily cadence. You know? They don't want a month, they want a week. They're glad to pay for your time over the course of a week, but that's the pace they're going to move because they can't let this thing just sit for a week. This isn't a back burner thing. This is a front burner thing.
But then they're not... But that's something they need to be thinking about. Yeah, but they weren't going to do that anyway. So let's focus on what really creates value for them, and that's where the ability to read...
Okay, what should they be doing? But then what will they be doing? What's your expectation of progress, which is based on what you think should be... It's not just normative. It's obviously positive based on experience.

**Ellie Rofe | 34:14**
Yeah. I guess the challenge for me there is speeding up my process enough that I can cope with a daily cadence, for example, because it takes me, at the moment, especially... I'm not a scientist, so it takes me time to ingest the information, research it, really dive into it, get my head around it, do the market analysis, work out the landscape. I obviously use AI to help me with that, but it needs... I don't find AI sudden.
It's taking some heavy lifting away, but there's still a huge amount of deep thinking that needs to go into it to question it. So I think that's the challenge there. But that's something I'm going to have to work out, which is how to speed up my processes.
So I don't need two or three days between a call with someone to process everything and come up with ideas. That's an interesting mo.

**ray@statechange.ai | 35:17**
And. might find, and just termed in multiple moving parts here, that the chaos you've got in the rest of your life rewards a more intensive process because it gives fewer chances for chaos to go
and derail things. Or it might just be like, "Hey, you know what? This is great. I've got a bunch of homework I need to do here. Let's not meet tomorrow. Let's meet the next day, which is fine, but there are..." You can dial this in the way that you think makes the most sense to you.
I think there's a... You get to embrace the chaos. I guess what I'm trying to hear when they are looking to move fast, you can move fast and you can be saying, "Okay, here's the amount of chaos I can deal with for this particular session." Now, it's not like you're setting up a rule for all time.
You're just trying to accommodate based on circumstances.

**Ellie Rofe | 36:14**
Yeah. Okay. Interestingly, I saw a little peak come up while we were talking, and she's literally just said a thing going, "I know you said you're getting it to me on Thursday, but I'll be working on this all Wednesday afternoon, so..." [Laughter] I'm like,
"Okay, let's have a call on Wednesday after you've had this meeting with this investor." Check in and we'll turn it fast. Yeah, that's really nice.

**ray@statechange.ai | 36:42**
Because that's what they want to do. "Hey, I just had this meeting. I'm excited, I'm full of ideas. I want to go, great, Wednesday's end of the meeting.
All right, let's set something up for an hour after that. That way you can go and get hydrated and have your lunch. Whatever. then.

**Ellie Rofe | 36:58**
I hadn't thought of that. Do you know? It's such an interesting thing. There's such an emphasis, and maybe this is coming from an emphasis in women in entrepreneurship sometimes where it... I think because it comes from women who are having to deal with such constraints around being a mum a lot of the time.
But they're like, "No, this is your process, and you set your process up, and then people either just take it or leave it. And I think I have been... It's really fascinating. Thank you for this, because I think I have been thinking in rigid terms in ways that give me structure, blah.
But isn't it more interesting? Isn't it more of a challenge for me? Isn't it more developmental to see how I can ebb and flow to clients and actually be more useful to them rather than just be like, "Now, computer says no, this is just locking it down." Yeah?

**ray@statechange.ai | 38:00**
I think influencers really give a lot of emphasis to structure because it's a thing you can write about as a thing you can be written about. Yeah, sure. That structure makes a whole lot of sense.
Then you go see their actual lives, and then some of them are really quite structured, but many of them are just swimming in the same chaos as the rest of us. I think managing chaos is something where you're doing a bunch of things that are continuously wrong.
I came up as what we now call a data scientist, but I was learning stats when I was in college, and the key lesson I learned is that there's no such thing as right in stats, there's always error.
So you're just trying to minimize the error, which is put differently, you're trying to be less wrong.

**Ellie Rofe | 38:51**
Yeah. I think there's a subtle difference in what I learned studying English, which is two completely contradictory things.

**ray@statechange.ai | 38:59**
[Laughter] Well.

**Ellie Rofe | 39:01**
Aright?

**ray@statechange.ai | 39:03**
And brings us back to my son's favorite line from Sutherland, which is that the opposite of a good idea is often a good idea.

**Ellie Rofe | 39:11**
[Laughter] Fantastic line. Yeah, I had a supervisor who said, "If you can't live in the gray areas, you cannot study English literature." [Laughter] That's like, okay, I know, I did think that.

**ray@statechange.ai | 39:26**
I think if you can't live in gray areas, I don't know where you live, because there are all gray areas.

**Ellie Rofe | 39:33**
Yes, it's really interesting.
It's a good idea. I think it does free me up a little bit. I think there's a difference. That's possibly where you have the Dubsado or whatever, this kind of software that processes a client thing, and it's day one, day three, blah, email. This, that, and the other.
It builds this incredibly strong structure around it. I think the framework is useful. Saying these are the basic steps I go through. But then I kind of... Because with this woman, she's so early on, it's not like she's done enough investigation to have two or three different directions that this company is going in or two or three different ways to pitch it.
It's like, what's the angle? Are we focusing on the crisis, or are you focusing on the opportunity? That's basically the choices she has. It's not like a totally different, completely different investment thesis would be manufactured.
So, whilst I have the process in my head, I've already adjusted it for her, and I've just not been thinking about her cadence, which is like such an interesting thing to consider. There's a linear process, but...
So, I was like, "No, I adjust that." But I hadn't thought about the pace at which we go through this and should be, in fact, not just can be but sometimes should be to push this through faster.
So yes, it's a very good insight.

**ray@statechange.ai | 41:14**
And you may come to find that like the. Well, it becomes another reason why the, you know, sort of the morning pages technique you've been using the, you know, the weekly write ups, they give the opportunity to review to see the patterns that have been evolving. I'm reminded that, like, you know, improv troupes rehearse all the time, right?

**Ellie Rofe | 41:35**
H.

**ray@statechange.ai | 41:36**
Which seems like it, but it's improvisational. How could they possibly reverse?
It's because they keep on practicing the scenarios so that when they come into a scenario, they're able to bring the creativity that is peculiar, idiosyncratic, right? To that one situation.
But it's not systematic, right? They're like, "Wait, hey, this is just that kind of game." All right, this is what I'm going to do.

**Ellie Rofe | 41:59**
Right, yeah, they're practicing the tools and the techniques all the time.

**ray@statechange.ai | 41:59**
And the only thing they're trying to bring creativity to is going to be the weird thing about the situation. Which is why the joke gets to be funny.

**Ellie Rofe | 42:11**
The yes and the way of thinking.

**ray@statechange.ai | 42:14**
Assumely, you're going to recognize. Wait, one of these engagements has these seven parts, right? This is standard on the is four. They are wacky doodle on these two.
They don't seem to have an opinion on the seventh right?

**Ellie Rofe | 42:29**
He.

**ray@statechange.ai | 42:30**
So I can drive in the opinion on this one because they don't really care. And these other two, these are the ones I need to really pay attention to because that's going to be where they get people most special.
But that comes with experience in terms of seeing those things, right? And being able to see through the chaos to see the structure that's underneath the chaos. That doesn't mean there's no real chaos. Not the chaos is a lie.
It's just that chaos usually comes with bones underneath, right? When you understand what those bones are, you can. You can 80/20 the chaos.

**Ellie Rofe | 43:05**
Yes, absolutely. I think what's... I guess what's the joy of learning this stuff as well? That's so interesting. I have worked with Series A, B, crossover, but suddenly going to people who are seed, and maybe that's where I need to embrace the chaos of people who got funded in a boom time and don't understand how to structure anything or the...
This isn't even barely seed. This is pre-seed. This is spinning out from academia. It's so early on, it brings a different kind of... It brings a different set of bones underneath the chaos, so it's a different shape, maybe.
There are so many different permutations. That's part of the process of learning to be better at what I do and be able to apply the same underlying concepts to everything. I get to it. I'm always slightly reminded of when Dina the VC said to me, "I need to be in a pitch deck."
It's so simple. What are you talking about? Why do you need to go and talk to VCs? Why do you need to learn from them what they want to see, et cetera? What needs to be in the deck?
I think on some level, I have to remember she's absolutely right. I do. The thing that's most important for me to learn is how to be better at helping people with that. It's not just that I needed to know that.
Then I can just go, "Well, I'll do it for you." Which is, I think, partly what I've been thinking, because I'm slightly impatient. It's really frustrating trying to lead people through telling a story when they keep diving off down dead ends and
trying to make something look dreadful.

**ray@statechange.ai | 45:24**
Yes.

**Ellie Rofe | 45:25**
So, yeah, there's just a sense of building my own patience and learning how to lead people through something. And the sort of frustrations you must feel sometimes listening to the people you're coaching.

**ray@statechange.ai | 45:43**
It can be a terrible thing to see the potential right that the other person has right in front of them and know and like. But I can see what the right answer is. But actually, I don't see what the right answer is. I can see what I would do in that circumstance.
But that is not the same. This is why I talk about technical versus adaptive stuff, right?

**Ellie Rofe | 45:59**
Three one.

**ray@statechange.ai | 46:04**
Because the technical thing would be like, "Okay, here's the recipe you can use. Now it's only a question of execution."
Maybe you even want to move with the execution that goes down that road, right? If you're moving down from education to the doing, but the way you make real big value is by helping them elevate who they are. I often use the analogy of the bridge right. An entrepreneur is a bridge between supply and demand.
You're helping build a bridge right between wherever their entrepreneur is, right, and wherever the VC is. Dina is making the point that the VC isn't the same point, it's the same darn island, right?
But because each entrepreneur is coming from a different place, they're all different bridges.

**Ellie Rofe | 46:48**
Yes.

**ray@statechange.ai | 46:48**
And out how to make the bridge, it's going to work from that particular island, whatever that distance is or going through whatever the territories might be in between, that's new every time, right?
That's the reason why. That's a Halfordina is wrong, right?

**Ellie Rofe | 47:04**
He.

**ray@statechange.ai | 47:04**
Because, yeah, sure, you know what the VC needs, you know where everyone needs to go. But that's not the same as having solved the problem getting because that requires the s.

**Ellie Rofe | 47:17**
Yeah, yes. It's like stretching a muscle. You have to know the origin as well as the insertion because you've got to stretch the point between the four.

**ray@statechange.ai | 47:31**
And all different origins, which means the thing you need to learn about things can be different every time. It's about the origin. Frankly, you might be able to help move the origin. That might be the biggest value you can do.
Then instead of starting to build the bridge, we can reposition the island a little bit. Or maybe what you need to do is build a bad bridge, and that's going to help them understand what they need to do. Then they move to the island, they need another bridge, and iterate.
I mean, you will build this again, right? That's the kind of iterative process that can be driving value as well. Because what they really care about at the end is the delivery of one to the other.
It's not about the first move. It's about what the last one is, of course. Around the clock too, which means pace matters and whatever.

**Ellie Rofe | 48:08**
Yeah. Absolutely.

**ray@statechange.ai | 48:14**
And course, everything starts to mix up and get involved here.
But I think it's very cool that you have that insight with that particular client because that's a good thing to see because it's how you see the next level up of the value you can create for them.
If you can help, if you can understand that you know where they are, where they're coming from, then you're in a far better position to be able to make a big impact on their ability to accomplish what they want to accomplish, which is to be able to raise the money and build a great business.

**Ellie Rofe | 48:42**
Four.
I think it's just a much more... I don't get me wrong, I'm sure there will be difficulties and frustrations because you're dealing in margins and gray areas, and it adds a load to a project in terms of there's an underlying level that or meta level or whatever that's going on.
I've got to learn. I'm learning about the business and I'm understanding the client on their level. But instinctively, as we talk about it, even though I can sense those frustrations in the future, I know that feels much more of an interesting role to be playing than just going, "Nope, here's the process." Just fit into it and move along.
Yeah, I can see how it's much more interesting for you as a service provider as someone who is working with people.

**ray@statechange.ai | 49:56**
And much more compatible for them. Because if they're like, "Here is this square hole," and you just need to get a square peg to put into the square hole, and you get great value.
That's like low SaaS software, right? But the difference between SaaS software that's charging $3 and yours, which is more, is the fact that you're adapting to whatever the strange shape of the peg is that they've got and the fact that the peg might actually be changed in shape on a continuous basis.

**Ellie Rofe | 50:23**
Yeah, yes, [Laughter] we might have to change shape. It is. And that's me a bit more leeway as well. I noticed. I mean, I know I'm doing it a lot today because I'm a bit tired and stressed, but one of the bits of feedback I had from someone who'd heard AJ pitch was unsolicited. Whenever he talks, he's doing this, he's like, "God."
And you're like, "Well, we haven't talked about presenting." We haven't talked about how he presents himself and stuff. I'm like, "No, I can feel like that's part of the process with him of understanding who he is and trying to get him to not constantly be looking like he's at his wit's end whenever he talks about his company. Not to take it on as a responsibility, but as an opportunity."
Because like you said, you want to work with winners and you want to be associated with wins and so not work with winners because sometimes you have to help them become that. But you... Yeah, exactly.

**ray@statechange.ai | 51:32**
So at the end, like we said, the end of the engagement is what matters. At the end of the engagement, if they are a winner, you've won.

**Ellie Rofe | 51:43**
Yes, very interesting. Thank you. That. I'm. I came in like. What's the word? My brain's gone flowing.

**ray@statechange.ai | 51:58**
I think that might safe.

**Ellie Rofe | 51:59**
[Laughter] be came in, my brain's gone... [Laughter] I was just rushing at a million miles an hour with like fifty things going through my head.
Actually, that has slowed me down and brought me to something that's really interesting and able to see deep value in it, which is not how I felt for a lot of the last week in terms of just things being so...
So, it's really helpful. I think it's reinforced that the fifteen-minute morning check-in is another way of doing that for myself without having to rely on you to bring me back to Earth [Laughter] once a week or something, or twice a week.
But yeah, that's really helpful.

**ray@statechange.ai | 52:52**
Cool. Can I very quickly ask before we go, what... How are the calls with Robert and Demetrius going for you or are you still doing them or how that worksm.

**Ellie Rofe | 53:02**
I dipped in and out. I haven't been able to make a couple of the last ones. They are good. They're more accountability than content creation specifically, I would say. And I do really like it.

**ray@statechange.ai | 53:14**
Okay.

**Ellie Rofe | 53:17**
I've realized it works slightly differently to focus, mate. Which, again, is something I want to get a bit more back in the habit with because of the context of the call.
So when I'm... When I'm on a call and there's Robert and Demetrius there, it puts me in the framework of this kind of thinking that we do in the Masterminds. So I'm actually not necessarily in content creation, although I might be a bit more...
I've been realigning stuff, I guess, but it's been really interesting.

**ray@statechange.ai | 53:44**
No.

**Ellie Rofe | 53:45**
And we get a chance to just chat through some... Dimitri showed us some stuff he was doing about automation, and we get a chance to bounce ideas off each other a little bit if we've got time at the end of a call as well, so it's really interesting.

**ray@statechange.ai | 54:01**
Something that's worth continuing on. Or I suppose that's what I'm trying to understand, how to be encouraging to the three of you in a way that creates value for all of you.

**Ellie Rofe | 54:03**
I think so.
Yeah. I mean, as far as I can see from my point of view, I think they're really worthwhile. I'm really pleased that it came up, and Robert's been continually organizing them. I think it's a chance to just get to know each other's practices a bit more, even outside of the one call per week, and to bounce ideas around.
I mean, they're really smart, so it's always useful for me to hear from them and play around with ideas with them.

**ray@statechange.ai | 54:44**
Super cool. Alright. I appreciate the feedback, and I'll
let you go running into your chaos week. My heart goes out to your family, and I appreciate this is a tough thing. It's not going to be a short-term thing. If there's a way that I can be a better service to you through the week, know.

**Ellie Rofe | 55:04**
Thank you.

**ray@statechange.ai | 55:05**
I hopefully will reach out.

**Ellie Rofe | 55:06**
Thank you. And saying to you, I'm very sorry to hear about your uncle. All my love. On that.

