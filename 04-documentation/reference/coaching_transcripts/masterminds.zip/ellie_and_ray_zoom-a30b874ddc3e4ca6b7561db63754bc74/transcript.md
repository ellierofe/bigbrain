# Ellie and Ray Zoom - Aug, 01

# Transcript
**Ellie Rofe | 00:00**
Progress hello, I'm very well, and you are... on your mammoth marathon meeting run?

**Speaker 2 | 00:06**
Hello, Ellily. How do you do today? It looks like it's going to be a little bit lighter than some other days have been. Today it's going to be 12345 meetings today, sure.

**Ellie Rofe | 00:25**
No, barely anything, sir. I'm just going to let the cat out now. Wolf, he for some reason gets he's unboered by everything except zoom calls. [Laughter] Maybe he was in a corporate world in a former life or something.

**Speaker 2 | 00:42**
Or AA pre press, pre pandemic. Like now it's like all zoom all the time, you know?

**Ellie Rofe | 00:49**
Exactly.

**Speaker 2 | 00:51**
Which has been quite fit for my lifestyle, I have to say.

**Ellie Rofe | 00:54**
I know it's very well, I mean, I couldn't do much from out here. If it wasn't, I'd be.

**Speaker 2 | 00:58**
Y same here.

**Ellie Rofe | 00:58**
I'd be pretty stuck. Now, he enjoyed this last.

**Speaker 2 | 01:02**
Yeah, absolutely.
So forgive me, I am not as well briefed as I might be on the week because I didn't see the report yet.

**Ellie Rofe | 01:14**
I did put it up there.

**Speaker 2 | 01:17**
Okay, the last thing I have and perhaps this is just me being not quite in shape, it just had my last thing, through the... Now I see it.
Yeah, 25th to 31st got it. There it is, yeah, start. Thank you for having done that.

**Ellie Rofe | 01:35**
Sorry. [Laughter] I was thinking, how did I manage to hallucinate doing that? I know my brain hasn't been great lately, but my God, [Laughter].

**Speaker 2 | 01:44**
No, you're all too good. Okay, well. Well, sort of in your own words, what kind of week has been for you? I've seen a couple of your, you know, daily things come through, which was, you know, cool to sort of see or keep my discipline.
But how is it, how's it sorting out for you? Especially on the other side of, like, getting yourself into this new, you know, health mode.

**Ellie Rofe | 02:07**
Yeah, it's still very up and down. I have to be honest, I mentioned in the thing. I think I'm in a slight catch-22, but that fingers crossed should be resolving in the next week or so. In terms of money, it's obviously run quite low now,
and some of the health initiatives would be useful for me, like my car's broken down, I need to fix that before I can get to the gym. There are just various bits and pieces on that note. I'm postponing my operation, so that's not another chunk of money coming out, and so I won't need to move next week's meeting unless you already have, so fine.

**Speaker 2 | 02:39**
Okay.
No, it's perfectly fine. I'm not thrilled about putting off things related to health when, you know, but, yeah.

**Ellie Rofe | 02:56**
It's not. So, since I've been doing physio, I really just needed to know what exercises to do from home. I didn't even need the massive amounts of physio. I did trainers of PT and Pilates when I was younger.
So now I know I was always a bit hazy on the shoulder joint. Now I know what I'm meant to be doing. It's great, and I've got a lot less pain and even less restriction from it. So, it's not something that is deleterious to my health at the moment. It would just be good to get it gone, but that's fine.
I think there are various bits and pieces, and it's just one of those catch-22s. So, it's Genoa. It's more brain fog that I struggle with, as you may know, occasionally with this. And I think some of that is going to take time, and some of it is going to take having more money to buy better ingredients and possibly some supplements and be able to go to the gym more often.
But broadly speaking, much better. I am. Considering I mentioned that note, I don't think I've got... At the moment, I think part of the mistake I've been making is thinking I've got eight to ten hours of good hours in me in a day, and I don't think I have.
Maybe when I'm doing more calls because I think you do, too. I find calls a different type of energy and a different type of concentration, then that will make that process a bit easier. But at the moment, I think what I'm going to say to myself is...
Because I'm spending a lot of time feeling guilty as well. Which is just natural. I mean, I was brought up Catholic, so... [Laughter] I went to a Catholic school. So I think if I say to myself, "Do five good hours," plan for five good hours.
Then everything on top of that is a bonus. I think I might be in a better shape in terms of actually just focusing psychologically. The structure it gives me in the days, does that make sense?

**Speaker 2 | 05:02**
It does. It does. I went through, early in the days, or in the midst of the pandemic. I, too, was having some trouble with focus. My thing that I started doing was after discovering Julie Cameron, I'd heard about morning pages before I knew about people who did them. I just started doing that as a discipline, and I counted that as a thing I'd accomplished for the day.

**Ellie Rofe | 05:32**
Yes, yeah.

**Speaker 2 | 05:34**
And think that it is a real thing. Like you're sitting down writing, if you create a habit of writing, I mean, you. I mean, when I'm writing with my little half-sized pieces of paper, morning pages are roughly 400 words, and writing 400 words is, frankly, more than most people. Noonday.

**Ellie Rofe | 05:49**
Yes, I am.

**Speaker 2 | 05:49**
And I tack them. Yeah, okay, well, it's good for clearing the head, but I think it really falls in the category of building a habit.

**Ellie Rofe | 05:52**
I do three pages of this beast. But it is good. Even just to clear the head sometimes.

**Speaker 2 | 06:07**
And your habit is to be thinking, and you have to push your thinking to actually express it in words, you're giving us permission to not have to be perfect. It makes a big difference, I find.
Anyway, we're always saying. I hear what you're saying about the five hours you're just trying to build up to what is going to be an existing thing. I found that even something as small as morning pages, particularly when I didn't yet have a schedule full of calls, right? This is late...
I think it was early 2021. I started doing this, this is coming out of my previous EP I've been doing with a partner. It fell apart over the course of 2020 and then focused on family, blah.
Now I'm trying to be like, "Okay, what's the next thing?" Right? I was and I found that it created structure. I had thoughts, and then those thoughts were driving me for the rest of the day.
The rest of the day might not involve quote-unquote productive stuff, but I was engaged, and it was building me up. I did that for PA calls. I did it for 60 days. I did the morning pages.
Then I started writing an essay a day, and I did that for a few months, and then I built into the next thing.

**Ellie Rofe | 07:17**
HH.

**Speaker 2 | 07:22**
And then this would eventually lead me down the road that would take me towards, you know, state change and.
And our staff that was, you know, a reboot of the career. This is all to say, to be in praise of doing a small thing, right?

**Ellie Rofe | 07:35**
Yeah. absolutely.

**Speaker 2 | 07:35**
So it's not like, "God, I do ten hours. I need to lean into that, or even needing the five hours."
If what you can do is have that consistent one hour, "Hey, here's the thing I did. You'll be able to look back on that, you'll say, "Wait, that's an accomplishment, and it's a real accomplishment." The fact that it's relatively unstructured, it's still writing, it's something that you do well. You're a copywriter.
If you have that practice being kept up, even as other things aren't quite where you want them to be, you are way ahead of where most people are in this regard.

**Ellie Rofe | 08:10**
Yeah, I think it's good. A sucker for my brain as well. If, then, nothing creative comes out of it because I love that I used to actually do screenwriting, prose writing, and studied English literature.
I think that helps me as well feel like tapping into a bit of creativity, a different type of creativity to the type that you end up using in PITCHDEX or whatever, like a more free-roaming, mad random corners of the brain type of creativity.
Sometimes that comes together into something, but in line back to the other stuff as well. So, yeah, 100%. The other thing I started adding to the recap of the week because I have realized I'm a bit bad at recognizing...
So, I always find this fascinating whenever I cook something. The first bite I take. So, I put it down for us to have dinner. The first bite I take, I'm going, "It's okay, but I think I could have done this."
My other half makes food, and he's going, "Cool, that's lovely. I really like it. [Laughter] And I've realized that, and this partly comes from my family, partly comes from doing events where, as you're going along, you're thinking, "Right, how do I make the next one better?" How do I make the next one better?
But I very rarely go, "Hang on, some good things happened or something was done well." So, I've just added some wins rather than, "That wasn't good enough. I'll try and do it again." So, this week, the call was booked in with the VC.
I know, Dina. That's a nice win. I had a call with the Biotech Industry Association, the guy there who runs their startup events. It's quite... I mean, it's a big place. It's well established.

**Speaker 2 | 10:08**
No?

**Ellie Rofe | 10:08**
And really likes the idea of the VC report. He
said, "How many VCs do you need to speak to?" I said, "Twenty to thirty, probably for the first one." He said, "Okay, we can't blast you out to all of our VCs then, but I'll introduce you to some of our bench that is most like..."
So, that's really nice. Hours of cold calling ahead of me. Hopefully, a bit more of a warm introduction to some people who are happy to do this. He suggested that in March next year.
So, it's a while away from now, but it's nice to build stuff up that I could be working with them on their pitch, that kind of pitchfest thing that they do as part of their Startup Entrepreneurs event.

**Speaker 2 | 10:52**
Yeah, well, I mean, once you get even like the first pass of the BC report, you're going to become. That makes you a viable speaker.

**Ellie Rofe | 11:02**
Yeah.

**Speaker 2 | 11:03**
You'd be sharing the state of the industry stuff, which is a very strong position to be in, which, of course, for the Marsh thing, I'm sure for others as well, is awesome. Congratulations to that. Not for nothing,
put them in wins. When that's going to be... What's the psychological bear for you? I think of this as those are accomplishments in sales, right? You have wins in the sales category. It's fantastic you do, especially given you're concerned about income, right? There is no ship.
It sounds like... Actually, I'll want to understand the "it" part here a little bit, because, to my understanding, you don't currently have clients. But the "I" look and say, "Hey, great. You're making progress."
Some of it is about your metrics so far, and if the a little bit of guilt stuff or whatever has to do with the number of hours worth the quantity of stuff. But you've accomplished things.
I'm glad you're putting that down into celebration. I would say that it's okay, "Hey, that for me, that makes sales look a lot better, right?" Because you only put out one post.
Okay, fine. But I booked a meeting with the VC, and I had a call with the trade association. That's fantastic. What is is.

**Ellie Rofe | 12:19**
Okay, fair point, well made. I do have a client. I still have the one in waiting, but I have a client who is a deferred payment as a favor to the guy who introduced me to the Biotechnology Industry Association and various other people.
Yeah, not something.

**Speaker 2 | 12:36**
Okay, deferred like, you know, contingent on raising money, that kind of deferred. Okay, and.

**Ellie Rofe | 12:44**
Not something I would do where it's completely free upfront and then deferred, but just this guy has been introducing me to people freely and generously.

**Speaker 2 | 12:54**
Yeah, and I got to say it. There's a little bit of a question like, "Why do we do the work?" So, some of it would do the work because of the money, and that can be a good thing, but we do the work because we enjoy doing the work.
So, having "Hey, somebody we can help and who's ready to go, they just don't have the ability to pay, and I don't otherwise have a client." Great. That allows me to do some stuff. I think that's...
But that's perfectly great, as far as I'm concerned.

**Ellie Rofe | 13:17**
That was a lot of my thinking as well. Let's just get some reps in for you in terms of working with people again because you enjoy it. It's good for your whole thing to be doing the
think that just makes everything much easier. As you've said multiple times, actually doing the thing makes everything come together. It is interesting. I do have a question about that, actually, just in terms of the consulting thing.

**Speaker 2 | 13:44**
Okay.

**Ellie Rofe | 13:46**
But, So, sorry, what were we going to say?

**Speaker 2 | 13:52**
I was only going to check in a little bit on the study part. I mean, we're obviously doing the report, which is actually part of your big initiatives, right? For probably heading into the rest of August.

**Ellie Rofe | 14:03**
Yeah.

**Speaker 2 | 14:05**
But I wanted to learn a little bit about what you were looking at with this thesis thing.

**Ellie Rofe | 14:12**
One.

**Speaker 2 | 14:13**
As I know, Daniel Petro is really excited about the thesis. They're otherwise a little bit of a speck in the industry, but
seeing you come around to it, I'm curious about your angle on it.

**Ellie Rofe | 14:27**
Well, I'm thinking, and this is a foundational question. This was another question I had, actually, so let's do this one first.

**Speaker 2 | 14:35**
Yes, sure, and didn't mean to interrupt your thing. I just wanted to quickly survey the study cellship Yeah.

**Ellie Rofe | 14:41**
I'm with you. What I was thinking is when I gather all this information for a report,
I will then sift through it and find my takeaways from it. But every by its nature has a lot more source data than is surfaced in the actual report, and I was thinking of just giving people a tool. It doesn't look like Thesis, plus MCPS. It doesn't look like...
It's incredibly difficult to give people a tool where they could interrogate, question, ask the report questions and get data in a nice visual format, basically as a little... It's a dynamic report rather than just something static.

**Speaker 2 | 15:36**
I think there is a lot to be said for that from where I sit, and I've talked with Mich Vanden about this a little bit. This is part of where the whole digital twin thing comes from. You and I have talked about that too, in the context of the pitch deck and turning it into the digital twin of the individual.
Similarly, here we have the same idea, not a digital twin of the report, but it's an alternative public publication medium, right.

**Ellie Rofe | 16:05**
Yeahm.

**Speaker 2 | 16:05**
And think, as a medium, we're... I am expecting that we're going to see a lot more of this in the coming twelve months.
So, I think you have some interesting opportunities to be able to turn it into something like that. I expect, as the weeks progress, that you're going to find tooling comes out for other people who realize that this is another gold rush, and they're selling the picks and shovels, right?
So, you don't need to dig with your hands at that point.

**Ellie Rofe | 16:34**
Got you.

**Speaker 2 | 16:34**
So the thesis is, I think, interesting, and they are in that dynamic, generative UI game. I'm doing generative UI stuff using what's called Assistant UI, which is a React framework. I'm doing that for state change,
and I'm glad to share more about that. The stuff that this is doing is neat. They have heavily integrated, and as I can tell, they're not making any sales. Their Discord community is like... It has twelve people in it.
It's just not like... I don't know if you saw the presentation that their DA did with Dan Petro.

**Ellie Rofe | 17:14**
I did. That was one and a half hours, so I hadn't landed on a thesis, but yes, it was terrible, if I'm honest with you.

**Speaker 2 | 17:18**
Y was terrible. They were not competent at that job. Which might point you towards, "Hey, wait, there are a lot more companies that need more marketing help."
In the world of AI, right, it's bits, not atoms, but there's a lot of capital sloshing around in there, and a lot of... As you can see, marketing that's not being done very well.

**Ellie Rofe | 17:44**
Yeah, absolutely. That might be the next iteration. I think I just need to get some pitch decks under the belt for cash flow first.
But absolutely.

**Speaker 2 | 17:53**
But the.

**Ellie Rofe | 17:53**
Yeah.

**Speaker 2 | 17:53**
But the... The thing I want to bring to your attention is the... I suppose the thing I wanted to understand was what you're thinking about the thesis. I think the idea of a publication paradigm for that is really quite powerful.
I think it will be different from making a formal report. So I wouldn't be slowing down one to do the other. I'm expecting the tooling to get a lot better as we get into Q4.
So it's not like you need to be... I say, where you are finding fast progress, go for it, and otherwise don't dig with your hands. I just came off a call with Demetrius. He and I did our accountability call earlier.
It's by morning, and he's doing some S work around Notion now, right? Actually, at the recommendation of that same day in Petro from a different meeting, I found that Notion is doing a lot of the work that he thought he would have to build for himself in Zapier or what have you. Asser falls in the category of these tools that are just evolving and taking more of the stuff off of our plate.
You've heard me use the wine versus bottle analogy. I think the glass blowers are getting good at the stuff, right?

**Ellie Rofe | 19:04**
H.

**Speaker 2 | 19:04**
Allowing you to focus much more on the wine rather than, "Hey, what's the technology I would use to transport it?

**Ellie Rofe | 19:11**
Okay, so why? I was looking into doing it sooner partly. It was actually partly, especially when I was cold calling VCS, to give them an insight into what would be happening and to give them a very loose demo of what it would look like.

**Speaker 2 | 19:34**
What the report will look like.

**Ellie Rofe | 19:35**
Yeah, show them that they were contributing to something that VCS liked shiny things. I know it's ridiculous, but show that they were something that would be a little bit more dynamic.

**Speaker 2 | 19:44**
Yeah?

**Ellie Rofe | 19:48**
And you know, they all seem to be quite excited by AI on a shiny level.

**Speaker 2 | 19:52**
Yeah. Well, that's a reason point, too. Yeah.

**Ellie Rofe | 19:56**
So that's why I was looking at stuff. Now I hadn't landed on Thesis, and that's why I was going to ask you. It doesn't seem terribly complicated to me, you're looking at, but the...
So when I was building Moogle, the thing I was always much better at was the sort of logic flows or logic within the client side or whatever. But this, the data structure and stack is the area that I'm not so good at.
So that's where I was like, "If I've got 35,000 rows in an Excel sheet for SBR data or whatever it is.

**Speaker 2 | 20:33**
Hey.

**Ellie Rofe | 20:33**
SRI BI always gets it wrong. SP R: Where does that presumably... I just have to find a place to hold that and then get an MCP to talk to it.
Anyway, I was going to speak with Robert as well. He's the MCP king, but I was just... I was thinking it shouldn't be desperately complicated to get a basic little example up to show people what they're contributing to.
That's my goal here. But if you think I'm just going to sink ours into something where the current solutions are a bit crappy and will take me forever, and there's something coming down the pike that is just going to make it all redundant, then I can rethink.

**Speaker 2 | 21:23**
My take on this is that mostly, particularly in the case of your demo, you're just going to have a document behind the scenes. I'm probably just going to do it using context stuffing, which is... Rather than creating a complicated database or whatever else.

**Ellie Rofe | 21:33**
Okay.

**Speaker 2 | 21:36**
Maybe you're going to wind up with 35,000 things, but I bet you if you took that whole document and you formatted it a little bit, you'd wind up with something that's maybe a quarter of a million tokens.
That is something that Gemini can handle just fine, right? So, could you? Your demo could be as simple as a Gemini project that has that document loaded into context, right? Just like you do with Claude or, frankly, a cloud project because you know how to do those too well for scale or whatever you.

**Ellie Rofe | 22:04**
Yeah. I think Jem and I might be a better call for some of this stuff.

**Speaker 2 | 22:09**
But my broader point is, you don't need to go build an app and say, "Here's my app.

**Ellie Rofe | 22:10**
Yeah.

**Speaker 2 | 22:15**
You can be prototyping it by saying, well, here is the, you know, here it is as the project because it's really about the data anyway, right?
And then that allows you to be focusing on the question like what is the data you're looking to present and iterating on the, if you will, the prompting of it or whatever, as opposed to, you know, trying to create a, you know, your own user experience. To be running this stuff when I was building out a state change system, part of the reason I was doing it was because it's a gen to UI aspect.
But there are so many different original pieces of information, right? So it's like, "Hey, this came up in office hours and here are some insights." It comes up with a summary, and then you can click through that to bring up the original office hours.
That's super valuable because I have so much information in the original data. That becomes a useful way for someone to go down the rabbit hole. Whereas the 35,000 gross in the FBI report, which I think is...
I mean, that's small business innovation and research or something.

**Ellie Rofe | 23:12**
As the graphs I give st.

**Speaker 2 | 23:14**
Yeah, there's SBIR and SPUR, I think.

**Ellie Rofe | 23:15**
R&R and stuff like that.

**Speaker 2 | 23:20**
Anyway, but what whatever there. The reason I was bringing it up was, even then, I'm discovering that the actual UX of it is getting diminishing marginal returns, and that a lot of the bigger value is just in exposing it as MCP because of the front-end.
AI is really good at its job, and so it allows you to be simpler about it, and you can decide which way you want to go with that anyway. All of which by the way of saying that the data is the most interesting part about this and giving them insights. The most interesting part.
To the extent you can stay focused on the part which is surfacing that information, the wind, right? Rather than spending too much time creating the bottle. I think you are in better shape.
The fact that you can do a lot of that using a personal project in Claude or what have you makes you look pretty good and probably plays to your storytelling too. Of being a marketing expert rather than being a frontend developer.

**Ellie Rofe | 24:25**
M.

**Speaker 2 | 24:27**
So that that's my thinking about it and something that hopefully that what we're the objective is to help you show more with less work, which is always sort of the mantra we have around like this all this low code stuff.

**Ellie Rofe | 24:39**
Yeah, I'm trying to think of the positioning of it. So, part of the issue I've come across is copyright as well. There are loads of stuff that I just can't put into it because it's all copyrighted.

**Speaker 2 | 24:54**
Yeah. That's about the data again, Yes.

**Ellie Rofe | 24:57**
Pardon?

**Speaker 2 | 24:58**
That's all about data, right?

**Ellie Rofe | 25:00**
Yes, but there's loads of data that is publicly available that I couldn't put into this report or use in the back end of this report because it's all copyrighted, so I wouldn't be able to ingest it for anything.

**Speaker 2 | 25:01**
Yeah, the useful bit of the presentation isn't from the SPR that's not where the good stuff comes from.

**Ellie Rofe | 25:12**
Because I would be ripping off their work, basically. So, McKinsey things and stuff like that, there is a coup. There are a couple of bits of biotech funding information that don't appear to be copyrighted.
That's great. That's before I can get some stuff about UK and US funding, at least. I think what I'm trying to work out is maybe the demo of it isn't very useful because if I'm just saying I don't see the value proposition in me showing them a Claude screen with some SPR data, which isn't particularly... I mean, it's vaguely relevant, obviously, it's useful for VCS, but just going, I've ingested this,
and here are some questions I'm asking it. Am I just being?

**Speaker 2 | 26:06**
It's going to be... It's going to be digitally twinning your analysis and insight, right? And you know, when you talk about the McKenzie stuff, what I would do is I would ingest McKenzie, summarize it, and then have that in your context, right?

**Ellie Rofe | 26:20**
Yeah.

**Speaker 2 | 26:21**
Because the derivative work isn't going to be the thing that is as copyrighted. Then you keep the bibliography itself becomes valuable. The fact that you're citing McKenzie Quarterly helps you.
So I would encourage that because the issue isn't copyright, the issue is plagiarism, which can get manifested in a copyright.

**Ellie Rofe | 26:39**
Right.

**Speaker 2 | 26:44**
You're ripping off our work as your own. Well, no, I'm citing your work, right?
The two are not the same thing. If I'm doing academic research or whatever, it doesn't need to be academic. I can be doing business writing for my book, which I'm going to go make money on. I can be citing their stuff. I can be quoting their stuff.
It's not a copyright violation if I'm saying they're so smart, look at them, and I'm repeating what they have to say because I'm not appropriating their work as my own.

**Ellie Rofe | 27:07**
Yeah.

**Speaker 2 | 27:08**
That's p that's why plagiarism is the fundamental issue.

**Ellie Rofe | 27:13**
H.

**Speaker 2 | 27:13**
So you make a good point of not just ingesting the raw report as part of what you would then go present to them, although you might ingest it as part of what you're going to use for your research.
Those two things don't need to be the same, but that's why the data thing matters.

**Ellie Rofe | 27:27**
Yes. Yeah, absolutely. Okay.

**Speaker 2 | 27:33**
So looking at Claude doesn't necessarily hurt your credibility for it to be Claude, right? That this is a Claude project that you're making basically a custom GPT for them is I think a compelling thing that's new and that's innovative.
I think compared to what they've seen. Like I say, I think this is an emerging area and something that you've shown a remarkable ability to make valuable, like in the sessions you did over at State Change.
So I think you have a leg up in that regard. I don't think you need to take on a lot more technical complexity in order to be able to take advantage of it.

**Ellie Rofe | 28:14**
Yeah, okay, cool. That's very helpful. The idea of summarizing and adding maybe some metadata and links and stuff to source things like McKinsey is a resider.

**Speaker 2 | 28:26**
And yeah, giving some prompting, hey, identify the source. Da. I'm like, you'll. And some of these things are better than others for that. And the. But I think you've got lots of opportunity to, you know, one put that to work for you to help you with your process potentially to be sharing it with the BC.
But I think the big thing is, like, what are the insights rather than what is the mechanism? Again? Is the wine. Not the bottle.

**Ellie Rofe | 28:56**
Yeah, okay, cool. The other question I had was more of a consulting consulting question.

**Speaker 2 | 29:09**
Yes.

**Ellie Rofe | 29:10**
And long questioned this when working with startups and solopreneurs. The guys I'm working with,
well, I won't say their name because it's not fashionable, but the ones on a deferred payment, when I'm working with them on the pitch deck, it feels like I'm always crossing a line, and I'm never sure how far to cross it between their actual business strategy and direction and advising them on the pitch deck.
I think I've found a way where I do it subtly, which is where the vast majority of them... Part of the issue is they're trying to tell ten different stories, and they're trying to do that. They're trying to not choose a path and they're trying to hedge the path forward and stuff.
So for these guys, for example, they have a platform technology which helps speed up and potentially correctly identify the right drug targets and which molecules might work on those targets. Like this enzyme and this molecule in a constructed complete reconstruction of a cell or a microenvironment tumor environment. That kind of thing. That technology, I mean, it's very clever, but most biotech investors, especially in this thing, don't really care about the platform. They're more interested in the product, the drug. They then have two different drugs that they've identified, two different targets in two different areas.
Internally, as a team and as a VC, they can't really decide. Now what I will do is give them three to four different narratives for their pitch deck that take one value proposition and say, "This is a value proposition you could go with." This is a value proposition you could go with.
Value proposition SLA angle, which I call a narrative and how that breaks down in the pitch deck, the sale, what the investment thesis is for it. But I often come up against this, and it feels like I'm stepping way out of bounds to start talking to them about strategy. I'm not an expert in building biotech, but I do know that they're trying to do too many things at once and trying to be all things to all people.

**Speaker 2 | 31:44**
8.

**Ellie Rofe | 31:45**
So have you come across this? How? How do you manage it? That. Delicately. Or. Do you?

**Speaker 2 | 31:55**
You are an expert on strategy. It's the issue. You're just trying to... It does feel a little bit like the whole "stay in your lane" thing feels classic to me.

**Ellie Rofe | 32:07**
Okay?

**Speaker 2 | 32:07**
Like you're saying, "Well, I'm just the lowly copyrightter making the pitch deck over here. I don't know much about all this biotech business.
Not even ten minutes ago, you were telling me you'd been invited to the Biotechnology Industry Association and you're meeting with VCs. Do you know what these people think of you? You are an industry expert, right? Let's start with you appreciating what you are.
Right. Which is a marketing expert in the field of this. Right? When I say marketing, it is always about what you are selling, right? I think that the job of a CEO, most often, is not to sell to the doctors. They will eventually hire pharma reps for that. The job of the CEO is to sell really to two entities that matter. One is regulators, and the other is investors.
So, they're in the business of selling credibility and stock. That's one of those two things that you owe your RAse expert expertise on, right? Which is you are an expert in the selling of biotech stock.

**Ellie Rofe | 33:21**
Uhmhm.

**Speaker 2 | 33:21**
So I would embrace that. As a company, I can't speak to what the doctors are going to want from this, right? But I can tell you what will sell your stock, and you can describe it however you want to describe it.
But that is something you are an expert on, and you are essentially counseling them on that, and you're using the pitch deck as a specific mechanism that you identify as being high value to help them successfully sell their stock. You're not measured based on whether or not they have a nice pitch deck. You're measured based on whether or not they successfully raised.
So, you're in the business of selling company stock. When you are talking with them, you're not just about this: "This is the color you should have on your slide." Which isn't the kind of thing you do anyway.
It's about the biggest thing. It's about the story because it's fundamental to them being able to sell to those investors. You are an expert on that relationship. You are a whisper. You're talking to the VCs.
That's one of the reasons we're having you do that, both in reality and to be able to position you as a whisper in that regard. Then they're listening to your advice because you're helping them sell to those companies better.

**Ellie Rofe | 34:38**
M.

**Speaker 2 | 34:38**
You're talking to them about narratives and stories because you believe that that's the highest leverage thing they can be working on to successfully make that sale. Not because that's your lane. I think that means to ends thing.

**Ellie Rofe | 34:51**
Yeah, I see what you're saying, but I'm not yet an expert in the various facets of the biotech industry. There's a lot that I still don't know.

**Speaker 2 | 35:08**
Sure, most people don't know everything about the biotech industry, but I'm not saying you're an expert in the biotech industry. I'm saying you're an expert in selling biotech stocks.
I'm not trying to say that because you know everything there is to know about it. I'm saying that because if you were to make a list of all the people who are experts in selling biotech stocks, I will...
I will hit you before I run out of fingers and toes. Pretty soon, I'll hit you. Before I run out of fingers. Pretty soon, I'll take it in one hand.

**Ellie Rofe | 35:37**
Yes, okay, I get it. I'm with you, and I think historically, this process has really helped me with that. Actually, historically, I think I have been quite afraid of that and the process of learning more and understanding more of getting the VC report, saying, "Right, I'm going to talk with these people, I'm going to understand exactly what they want right now. As well as the wide process I've been on since I was last doing these decks more regularly, I think it has really helped me.
Say, I used to just go, "I'll tell you how to tell the story, but you have to tell me what the story is, basically." Now, I'm able to say, "Okay, now I can identify where the story isn't convincing." This, of course, answers the question perfectly.
It is my responsibility if these people want to raise to tell them where there are problems in their story and their investment thesis, which is, for example, you can't try and tell people that you're a platform technology and this and oncology and a service business or whatever. It just feels crazy.
So yeah. The CEO ultimately is the one that has to make the decision about which direction they go in, but they have to be made aware that they are trying to do too many things at once.

**Speaker 2 | 37:10**
You give them your best counsel, right?
And the and then they're gonna make decision. That's always the way with consulting. The most frustrating thing about consulting and things that sort of drives us back into entrepreneurship is, my goodness, these people won't just take my counsel, right?
And then you go to do entrepreneurship, you realize it's harder than that. But when I hear the story that you're telling the other thing I might just sort of throw in as an expert in CL like consulting is the word choice in here, right? Surely you're providing help with the storytelling and you're providing help with the narrative, but these are not words they're going to respect nearly as much, right?
And like that is a kind of word that puts you in the marketing box, whereas if what you want to be is in the investor box, investment thesis is synonymous with story and narrative.

**Ellie Rofe | 38:05**
Yeah.

**Speaker 2 | 38:11**
And is a word choice that puts you in line with the VCs, right? right?

**Ellie Rofe | 38:16**
Yeah.

**Speaker 2 | 38:17**
As opposed to putting you in line with those marketing people that they think that they really haven't had to work with so far because they're just brilliant scientists and they should be doing whatever they're supposed to be doing.
Now. But wait, you're the person who speaks the language of the VCS, and you speak it back to them, right? Okay. When we talk to them, they have an investment visa. Their investment visa acts like... What's... How do we link into that? What was the investment thesis for investing in this company?
Then, if it's almost like straight mad lib style word substitution, fine. I wonder if you, as a professional, and we, as marketing professionals, use words like narrative and storytelling and what have you in fairly substantive ways.
But the people who work in science... Then, when they turn on Access Hollywood, they hear those same things and they associate it with politicians bsing or Hollywood and the way fiction gets written.
There's probably not too much daylight between those two examples, but the investment... They turn around something else. Have you ever heard about Barr-Gilman disease? Okay, so this is a Michael Krieger thing where he talks about how you go and open up the newspaper right back in the newspapers. You open up a newspaper and you go...
In his case, because he was a screenwriter and a doctor, then he went over to the Hollywood section and read about all this stuff going on. These people are complete idiots. They don't know what's really going on. They say, "You think these people were talking to these people?" No way, that was going on.
Then he turns it over to the Foreign Affairs section and reads it like it's gospel. So, there's a similar thing that's going to happen here, I think. If you could be in the category of where they will care about more, right?
The part where they are, frankly, looking for the gospel, right? You become the Foreign Affairs section. I think that becomes very handy, right? You're concerned you're not the expert in the part where, if they were to read the Hollywood section, you'd be saying that you're afraid of being that Hollywood section and having them answer the questions that way.
But if what you are is a whisper to the VCs, now we're getting somewhere, right? You don't want to be interposing yourself as a bear expert on the thing that they are expert on. Because, frankly, if they were expert on it, why are we having this conversation?

**Ellie Rofe | 41:01**
Yeah.

**Speaker 2 | 41:01**
You're filling in the gaps. Something they're not expert on and, frankly, they're not looking to become expert on long term because they want to keep on being scientists. All in all of that is fine.
It's in the vein of what you were talking about before: do you think you were getting out over your skis or getting too far away from your core proposition? I think a bit of this is needing to see your core proposition more broadly.
This company that's doing this deferred deal only is going to pay you if the bigger thing is met. So you want that bigger thing to happen. They want to raise... You want them to raise...
So you being focused on the thing that's going to help them raise is, I think, correct. Using the language, having you be the stand-in for the investor so that they can then be making that sale better is actually serving them better, and I think is very much what they are looking for.
I think a little bit of language choice can help you reposition yourself in them, much as you're advising them to use word choice to reposition themselves relative to the investors.

**Ellie Rofe | 42:20**
Yes, absolutely. I did think recently, I was calling it things like a strategic story and stuff, and I was like, "No, it's got to be an investment thesis." Wasn't it?
All right, you're completely right. I realize what happens a lot in biotech when you're not a scientist, even when you didn't have a Ph.D. People introduce you, and they go, "Max told me you're not a scientist."
It's the first thing you hear frequently. Of course, he's not a scientist. The CEO I used to work with was not a scientist, so they weren't taken seriously in the industry. I think there's a huge amount of that that goes on.
So, I think that's a drip, drip occasionally, but actually, you're completely right. There's a reason I work with scientists, and there's a reason they need more help because they are terrible at storytelling and terrible at putting investment thesis together versus an academic paper in slide format.
So yes, it's completely rights.

**Speaker 2 | 43:26**
Yeah, I hope all of that just sort of giving you the or starts to give you a bit of the permission structure, right? To be having conversations I think will be more useful for them and positioned in a way that's easier for them to digest as I what did I say this to? It was ant changer if we were, like, going in for a job interview. Was talking to a CEO who I know and so who was asking for my counsel on that.
And I said. And he was like, well, if I've seen some of the problems with the product and DA. I said, you know, do you think I should be talking about those things? I said, you know, tell him what you think.
But you don't need. Tom's baby is ugly, you know. So the like you want you he you need you want him to trust that you're going to be an advocate for his product because it was basically a sales position and the.
So being open eyed about the challenges while at the same time being enthusiastic and positive. I think it's the thing that all of us, when we're going to that kind of advisory role, need to keep doing.
Right. So, giving them the good and authentic counsel. But that's not the same thing as being blunt and trying to tear down their egos.

**Ellie Rofe | 44:36**
Yeah, and look, in this funding environment, none of them need their egos torn down. They're like, "God, to go and raise someone." I just... They're coming out of conversations with other founders who've raised, like, the war-wounded.
She had to speak with 200 VCs to raise 7 million. It's tough, but she probably had a terrible death like this. So, hopefully, we can get you a better one to make that 100 or 50 CS.

**Speaker 2 | 45:10**
The. Yeah. And you reinvent deals, which is good. The other the part of VC that dare not speak its name. And just in terms of like just thinking like one step ahead. Further on this is the LP of the house.

**Ellie Rofe | 45:27**
Yeah, yes.

**Speaker 2 | 45:29**
The don't know where you are on...
Well, I suppose one is the LP side of the house, the other is just who VCs wish they were. And most VCs wish they... VC is a terrible way to manage money. It's a 200-million fund, usually pretty small, right?
They look across the street at the Black Rocks or the Bain Capitals or whatever, and they're like, "My goodness, we're pissants." There are a couple of S that are quite large, but most of them are really tiny. I sort of think about that a little bit in terms of what the language is, right? That VCs think about or that their aspirations think about, so they'll be able to put that back into the mouths of your potential. Portco.

**Ellie Rofe | 46:18**
And have been looking at that. I think the interesting thing is a huge amount of VC noise is about S&A, and sometimes adjacent stuff when you get the really big guys who've gone into other stuff.
But they often started in that S&A play. As far as I can tell, and I'm looking forward to speaking with more VCs, but a couple of VCs I've spoken to in biotech and the people I see talking about it online are thankfully less bullshit-laden. There's a brilliant Twitter account, it's something like VC's being self-important or something, and it's full of... Is that okay?

**Speaker 2 | 46:58**
Congratulating themselves. Yes, I follow that account. It's wonderful.

**Ellie Rofe | 47:01**
There you go.
Yeah, there's a lot of that stuff that goes on, but I don't think it's less so. So, I'm hoping that I don't have to inculcate people into such terrible ways of thinking and being with the biotech VCs, but we shall see as we come along.

**Speaker 2 | 47:26**
Yeah, and the reason I was talking about the whole aspirational thing is that it falls in the same category of the words because you are reading that.
That's what you're reading, right? Breville's done that. Jeff Besky has written some pretty good books out of the VC world. It's not a world that gets written about quite as much as I might have thought, but it's basically only about a generation old, right?
The BC world, as we understand it today, is maybe 25 or 30 years old. So, a lot of the first-generationers are still over at Sequoia and all that. The question is why I'm bringing any of this up. There's just a question of what if you can be bringing more of that financial language in or even financial structure right to the way that you're talking about the storytelling, et cetera. We talk about the investment thesis part, I think it improves credibility, but probably gives your clients a better shot than average because, one of the other ways I think that was okay, they're going to invest in your company. They're later going to have their annual meeting for their LPs, who do they want to trot out, right? To show the LPs you made such a good decision investing in us.
By the way, here's our new fund.

**Ellie Rofe | 48:45**
Yeah, exactly. Sorry, something annoying.

**Speaker 2 | 48:49**
Okay? That?

**Ellie Rofe | 48:50**
Yeah, no, I completely agree with you.

**Speaker 2 | 48:50**
Yeah. But. Okay.

**Ellie Rofe | 48:53**
And I've always talked or tried to talk to clients about the re-pitch as well. You need to make a story or an investment thesis so simple and so clear and so obvious that it is incredibly easy for them to just re-pitch it to the partners if they're not one, or the LPs or their peers and their Monday meetings, whatever.

**Speaker 2 | 49:05**
Two.

**Ellie Rofe | 49:16**
You need to make it clear, not just this thing and there's this platform and there's this other thing.
So absolutely, it's interesting. When I ask founders what VCs are thinking, feeling, or what they want, they just be like that. So I don't think they've worked out that VCs are anything but a pot of money behind a big, massive wall that they can't break through.

**Speaker 2 | 49:44**
Right. When in fact, they're just... They're middlemen, right, between the startup company and the actual funders who are pension funds or high net worth individuals or whatever, what whatever else.

**Ellie Rofe | 49:47**
Yeah.

**Speaker 2 | 49:59**
The, makes a lot of sense.
I have more thought. Yeah, I just wanted to throw in my two cents on the platform thing. I think it is a terrible word. I think platforms have come up a lot in the course of the last 20 years, and it feels very played out to me as a source of an investment thesis.

**Ellie Rofe | 50:15**
Yes.

**Speaker 2 | 50:18**
Nobody cares about.
You know. Mr Wonka's Chocolate Factory? They care a lot about the chocolate bars.

**Ellie Rofe | 50:24**
Yeah. but this is the thing with biotech. Some people just have what in the industry they term a platform, and then other people have products, and you can have a platform that helps you generate products. You can have a technology that can then be used with multiple different things.

**Speaker 2 | 50:38**
Yes. That's true he.

**Ellie Rofe | 50:42**
But that fancy needle that you use for injections or something is not as valuable as that one drug product that might become. For example, Wiggo, as a really extreme one. They're all looking for the next example of that in cancer, in particular, oncology at the moment. Everything has like in the pie charts. It's always metabolic disease.
It's obesity. So, oncology, obesity, some autoimmune stuff. They're looking for those drug products, and that's where the platform is completely terrible. It's a terrible word, but that's what they call it, a technology platform rather than a drug product, I think.

**Speaker 2 | 51:32**
Okay, got it. Okay, we opened with my survey of questions we did your consulting question. How else can we be a service to you and our time remaining here today?

**Ellie Rofe | 51:46**
I think I'm more good. I think we can have a little, like, comfort break. But before the next meeting [Laughter] occurs. I'm going into some accountability with Dimetrius and I think Rob.

**Speaker 2 | 51:58**
Excellent. I hope you have a great call there, and I think this Tuesday is your hot seat.

**Ellie Rofe | 52:08**
It is. Yes, I had a mild start with Robert last week or this week.

**Speaker 2 | 52:10**
Okay, and.

**Ellie Rofe | 52:14**
I had a mild panic that I got it wrong and it was mine.
I was sitting there while Troy was talking. God.

**Speaker 2 | 52:24**
No, that's why I raised it. Okay, cool. Then, anything I can do for you between now and then, just let me know, and otherwise, we'll talk on auday.

**Ellie Rofe | 52:32**
Thank you so much. Take care of a lovely weend.

**Speaker 2 | 52:33**
Thank you. Have a wonderful weekend. Bye.

