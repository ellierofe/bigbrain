# Ellie and Ray Zoom - Aug, 15

# Transcript
**Ellie Rofe | 00:15**
Hello?

**Ray | 00:16**
I here early. How are you doing today? Okay, pulling out a pen. There you go. Can I ask, is it perhaps a little bit... Is the heat wave passed? What I want to ask.

**Ellie Rofe | 00:37**
No, not at all. It has been physically, it has been a horrible week. It's been very little sleep. But, between windows being open, a sudden influx of mosquitoes, even with mosquito nets and blinds and stuff, just waking up being bitten alive. They love me, unfortunately, and I react really badly.
Then with windows open, cats coming in the middle of the night and suddenly appearing on me and just... I know they're really intense cats. This one just comes and licks there and it's like an initially rough tongue.

**Ray | 01:20**
These are your domestic cats or these are cats that are just wandering around the countryside in France?

**Ellie Rofe | 01:22**
Yeah, and I know these are domestic cats, [Laughter] but there's a reason I never had.

**Ray | 01:27**
Okay. I was more worried about, like, cats just coming in through the window and. You know.

**Ellie Rofe | 01:31**
[Laughter] And foxes and birds, it's like Snow White here. So, yeah, it has been a blurry week on the physical level with little sleep and just the intensity of the heat here.

**Ray | 01:46**
Yeah.

**Ellie Rofe | 01:46**
Yeah, just not great, but fine. I think that's part of the reason things dipped. Then I had... Because it's been so intense yet again, my partner was let down for his... With an assistant. So he does renovations.
It's very hard to find people who are good.

**Ray | 02:04**
Twotwo.

**Ellie Rofe | 02:06**
And I went in yesterday to help him. That's when I was working in 40 degrees, 105 roughly. Saw the note and went, yes, but I accidentally dismissed it and then completely forgot about doing the document again.
So, apologies for that. It's been.

**Ray | 02:23**
Y the fract just moving on to frags. I'm sorry for the conditions.

**Ellie Rofe | 02:25**
It's been a fractious week, I have to say.

**Ray | 02:40**
I hope the renovation went okay, and I hope that you didn't hurt yourself in the process because you've talked about having your partner help your partner, perhaps not hurt himself. You've mentioned before that sometimes your job and these engagements with your partner, when you're helping your partner with the renovations, are helping him not hurt himself.

**Ellie Rofe | 02:59**
Yeah, no, he has this instilled from his father, I'm sure, but this obsession that leaving early or being ill is a bad thing. I'm like, "It's 40 degrees, and you are working like a donkey."
You don't... The clients are sitting cocooned in a living room with aircon and all the blinds shut in the cool because they won't even walk out to their garden. It's so hot, and you are working like a dog.
It's fine to call off early, but we shall see. Yes, no, it's interesting, it's an interesting dynamic. We're both trying to build businesses. His is immediate and physical, but not particularly... There isn't a huge amount of money in it. It doesn't make any long-term sense for me to put my time into that.
I think he should be thinking about something else, but it's in the immediacy of it. It's difficult to just go, "No, go suffermate." So, it's a balancing time, I guess.

**Ray | 04:13**
I hear that, you know, the, what was it?

**Ellie Rofe | 04:14**
He that.

**Ray | 04:16**
Jeffrey Moore.
You know, he wrote after Crossing the Chasm. He wrote about other runs of books that didn't really get near as much attention. He wrote about what was inside the Tornado and then the Guerrilla Game, and those were popular books, right?
He was in the right moment, late 90s, and he's there for the tech investment thing, and people are talking about his ideas a lot. Then he wrote another series of books after that, another trilogy, actually, and they did not do well at all because they were all in that dip post, 2000, right?
I bring it up because he's got some fantastic ideas in those books. One of the ideas he talks about is the idea of good revenues, neutral revenues, and bad revenues. I bring this up because I was thinking about that when you were talking about you and your partner. Good revenues are revenues that both pay the bills,
cover overhead, but create strategic value for the company, right? Working on the right type of stuff, things that generate more knowledge, more secrets, more references, working for a lighthouse customer, referenceable stuff, right? Those are examples of good revenues.
Then you have neutral revenues where they come in, they're getting paid, and this is good. You're doing what you're supposed to be doing. This is the engine that runs the company.
Probably there's a good deal of revenues in there, and then there are bad revenues that, when you get them, they are making your company worse off from an equity point of view. So you're basically spending down your equity in order to get cash, and sometimes we have to do that kind of thing.
But it is like Robin Hood, PayPal, right? It's like what's the term? Yeah, they were things that ate the body, right? And the reason that I bring up that distinction is that, as I was listening to your story, it sounds like there are aspects to that right in what you're talking about in terms of things that are investing but things that are... Is this good revenue, and some of it could be good revenue here? We're making some money, and some of it is we're spending down our body or the quality of life or what have you in order to get that. It can make it bad revenue, and I use that framework to think about those things and think sometimes I was like, "Wait, that was bad revenue. That doesn't necessarily make me regret doing it, but it helps me understand what the price was that was paid and what the gains really were."
Okay. Why should we be looking for... How would that become good revenue, or what would be the trend for that?

**Ellie Rofe | 06:49**
Yeah, absolutely. It is a really interesting one. I know we're not here to talk about his business, but he has done this job on a bit of a discount because he wanted to get a really good renovation.
There have been lots of bits and pieces, and he has... It's a beautiful piece of work that you helped helped.

**Ray | 07:12**
Two.

**Ellie Rofe | 07:12**
Design and plan and everything. I think, like you say, he has put effort into this to be able to... On the idea that it would be good revenue because in your case, you are building a portfolio, and you have this amazing project that you can show people, et cetera.

**Ray | 07:29**
Twom.

**Ellie Rofe | 07:33**
I think the underlying issue is that we're not in London anymore, and the market here is very different. There is actually a very small luxury market. The vast majority of the market is very middle-of-the-road.
It is very like. We moved to renovate because the property was cheaper. We had no idea that renovations in France are actually really expensive. And now our budget is really squeezed. So we will nickel and dime things.
We want the old classic. We want it fast, cheap and high quality. In addition to that, despite there being quite a lot of demand for trades out here, getting reliable trades out here is very difficult because people movem.

**Ray | 08:22**
Was consistent with supply and demand, and a balance, right? There's lots of demand and it's hard to get supply. Those two things go together, and eventually, it becomes over-indexed, and there's a cloud of supply. That's just the way markets swing. Cool.
Yeah, as you say, we're here for me to talk about your thing, but certainly his business is affecting you personally, and you personally are a big part of your business, so it doesn't need to be that way. Hey, that piece is off the table for us to be talking about, but it sounds like that was a bit of your week.
I appreciate the whole reminder coming in, like, "Wait, I didn't fill that in." Demetrius and Robert use these reports a little differently than the way you come in. Okay? I have the structure that I set out for you in an effort to make it easy.
I'll tell you that. What Demetrius does is he will fill in these kinds of bullets, and he finds that structure to be helpful, although sometimes he underfills it. I had a conversation with him earlier today where he didn't count what he was reading. He was reading Sutherland, but he wasn't counting it. Why?
Because he wasn't sure how to apply it. That still counts as study. If anything, that's more important to study. The Robert will write me, like, seven paragraphs. That's just the way he spells it out.
For both of them doing that the previous day means that we come into the meeting with them having reflected on their week, right? That's what I'm trying to get to, the format is less important than the job to be done. The job to be done is to get you to reflect on your week.
Give me something to read the night before. Like, "Let me catch up to where your brain is at that particular moment." That's really what I'm looking for. Yeah, how does this hint at how your thinking can be most helpful to you? Because you've reflected on it, you can be coming in with,
"All right, here's what I want to be doing next." As opposed to a lot of the storytelling about what was happening the previous week, and to the extent that that's giving insight to what we want to do next or how we want to think next, that can be valuable.
But that's the job to be done of the meeting. So as you think about what you were talking about, like you were using voice memos before and the like, right? If what you want to do is use voice and then get AI to transcribe it and clean it up a little bit so it can be good to me, that's fine.
What I would wish for you to do and to give yourself permission to experiment with how to put something into this document. I do want the longitudinal record so that that's the reason for the document.
That is, you know, sharing the information that helps us keep track of where we are. But then, more importantly, is helping you consider what the week was so that you are probably somewhat inspired to yourself.
Like, "Hey, this is what I want to do next." But then helping us figure out how to make good use of this time. Does that make sense?

**Ellie Rofe | 11:16**
Absolutely. What I want to experiment with is just making notes every day, even if that then gets sanitized into a proper reflection at the end of the week.

**Ray | 11:27**
M.

**Ellie Rofe | 11:29**
Because I think part of my issue... So it's similar. I lose weight best if I weigh myself every day because I'm checking in every day and I'm thinking about it keeping in front of mine.

**Ray | 11:38**
Yes, I'm with you. Daily cycles are so much easier to keep up with. Yeah.

**Ellie Rofe | 11:43**
Yeah, weekly, I think I just forget.
I know it sounds ridiculous, but MoM talked about.

**Ray | 11:51**
That him.

**Ellie Rofe | 11:52**
I'm like, "I don't remember what happened. How did I fit? What was going on on Saturday and Sunday? I have no idea." It's gone. Very not goldfish because they actually have brilliant memories, apparently, but very... Almost like a memento level, waking up in the day.
It's a new kind of thing. Sometimes. So, yeah.

**Ray | 12:14**
Yeah, I hear that. If we can be taking the weekly part and making that more automated, so they have a better thing then the part that's coming from your brain is the part that's more daily. I'm down with all that.
But I was trying to express the job to be done part so that you can be giving yourself permission to experiment with it. I don't want you to lay it down to... I'm not just not getting it done.
Maybe that's something that's not working just because the form doesn't work for you, right? Because I think the job itself is an important one because if we're not considering that and getting that read back just to yourself on that kind of basis.
That is the kind of thing that just doing it daily is two small units of progress for that reflection. But the collection can be happening daily, and then what we can then be doing with this is taking that reflection and then lifting that into action into the coming week.

**Ellie Rofe | 13:08**
Yeah, yes, I like that.

**Ray | 13:10**
So.

**Ellie Rofe | 13:11**
Collect then reflect, then something else. Ending an act. Conf. Fact know. [Laughter].

**Ray | 13:16**
And I'll talk to Ray Deck to now way I know what's going on that the... Okay, so, just in terms of the week, it sounds like you had potentially a couple of interesting market interactions, right? The VC call and the one you follow up on, and then you've been doing some work around data, et cetera.
So, obviously, I've read the doc, but in terms of your thinking, what did you come into the room with? Question-wise, that would help us orient the coming week to be as profitable for you as we can.

**Ellie Rofe | 13:54**
Yes, I think the call with the VC led to me working more on the data and structure of it and trying to create something from it. Because she was not nastily but she's just very direct. She was like, "I don't see why any VC would be interested in this report or talking to you about this stuff."
You know what needs to go into a deck? You just need VCs to say to other people, "She's done a really nice job on this deck, and you do a really nice job on decks," so you just need to work your network so you're just so buff about it.
So, I thought two things from that. Firstly, I did start to reflect on that thing I mentioned about how I've seen, given that they're all working with the same people as me, biotech founders. I've just seen this group of people all liking each other's stuff and all talking to each other on LinkedIn, but very rarely any interactions. Now, I know that engagement and interactions aren't necessarily the thing that matters because people could be looking at that and then get in touch with you directly without engaging with any post.
But I have now booked in calls for next week with all of these people I see on this circuit, partly to talk with them. So, the one guy I already spoke with was... I think I might have niche too low. I'm struggling to get clients, et cetera.
He's a LinkedIn expert who teaches others how to use LinkedIn. So, it's interesting, but I just want to gauge, not necessarily whether I should be doing stuff on LinkedIn because I still think I should.
But what am I trying to achieve there? Because I don't know that it's leads. I think it might be verification, validation, credibility, or whatever. If so, that's a slightly different thing.
I felt a bit obviously not helped by the horrific temperatures and no sleep and it not being my favorite thing anyway. So, I ended up dipping on the LinkedIn activity this week and I've tried to pick it up today. Finally, I had a bit of sleep last night, and I'm refreshed. I'm like, "Right, let's pick it up a bit again today and not let perfection be the enemy of good." Try and keep some consistency anyway until I understand and have a strategic reason for changing direction rather than all gut feeling. It doesn't feel like this is actually doing much to move the needle in my business, which is why I've built those cool-ins.
So, that's one thing that's going on in my brain, whether... I'm sorry, I think I've just been bitten again. [Laughter] Whether I am doing the right thing. The one-pager wasn't too bad to put together. The big bugbearer I've had is trying to find non-confidential decks and then trying to connect with people and find old resort-like archives and stuff to get non-confidential decks. I can share because that's something she specifically asked for, and instead, I've struggled with that.
So I'm now just redacting stuff, and I'm going to send her redacted stuff. Fine. So that side of things is good, but with what I was then thinking with the tool, I do want to continue the BC report. I know she doesn't think it's important because she's a VC and it's not like the stuff that's going to come through for her.
But I do think founders will find it important, and I do think it adds some level of credibility to me. To do that, I now think the biggest point of leverage I have is that the biotech industry association, who said they would introduce me to lots of BCS.
So I need to follow up with them. But I want to follow up with something, and I want to follow up with something that they can't do, which is why I've been trying to work on all this data analysis and bring things together, and which has been interesting and frustrating in equal measure, but I think I'm getting somewhere.

**Ray | 17:52**
He.

**Ellie Rofe | 18:07**
I've tried Sim theory. It didn't really work for what I'm trying to do. It seemed very glitchy and not quite. It didn't seem to do a huge amount more than a Claude project, if I'm honest.

**Ray | 18:22**
Zero.

**Ellie Rofe | 18:23**
Yeah, projects I found interesting. I don't know what they're working on in terms of RAG, but I have noticed that they tend towards the first bits of information that they come across. Gemini similarly.
It's difficult to get stuff in there. So I started working on just in a Claude code setup, whatever. I started working on trying to get them into VectAI and just doing assessments on that.
Before that, I started thinking about breaking these documents down. So having one report, but multiple sections, and each section has a bit of metadata, and each section gets put into VectAI. I tried to do that programmatically.
It just didn't work very well at all. So the next step I think is to break down because I'm not dealing with massive amounts of PDFs. Break them down because when I was trying to get a whole PDF translated to Markdown, I
lost all of the visuals and charts and tables, which are the actual data, that's the stuff that has light commentary on. So then I was trying to use Claude Vision to read things and summarize them or translate them into Markdown with descriptions of the charts and the tables.

**Ray | 19:53**
Yes.

**Ellie Rofe | 19:54**
And I tried to do that, it then just completely abridged them, so a 30-page report would become three sections of a thousand tokens or whatever.

**Ray | 20:06**
Yes.

**Ellie Rofe | 20:10**
So there's quite a lot of manual stuff involved, but all the way through, I'm thinking this is good because if I'm having to work this out, other people aren't working it out.

**Ray | 20:18**
Yes.

**Ellie Rofe | 20:20**
Including, like you said last week, the BI at the Biotechnology Industry Association, they're not going to be working this out.
I can tell because they're not using AI on anything in their actual site, they're not incorporating it into another thing. So if I can just show them something that does use this data but does create something that's interesting.

**Ray | 20:37**
2I think there's a lot of wisdom in that.

**Ellie Rofe | 20:43**
That's the process that I've been going through.

**Ray | 20:48**
I think that the idea of using AI to build useful analysis that then becomes shareable and that it has that human touch on top of it is under-indexed. You like, "Hey, how can I have a chatbot that shares my documents along the lines of the most extreme form? The kind of thing you did in those sessions, right?
Creating a project and asking questions." That's some really cool stuff. But you don't have to have that. I actually got one piece of feedback from the town hall last week for the Can Assist. One piece of feedback I got was, "This is great, but it's asking lots of questions and giving some good stuff. Is there a document I can just have that has some of those key insights
and frameworks that you're using?" Because I would like to learn those. That's a really good point. So, being able to go back into the data, using data to create data for him, not completely on demand because he doesn't quite know how to do that. He wants what can you just give me this? Give me those insights.
So the way that you're doing it, the static output. Your brain and your skills applied to this in the middle create what I call semi-secrets. Right, it's public data, but your gift for analysis and distillation to create something that the market doesn't otherwise have. They almost know this stuff, but they don't quite. It can be a little confusing. Sometimes people put in analysis that isn't really that differentiating, right?
It's not like anything. Any processing will do that, but it sounds like what you're doing is actually hard. There's a lot that you're running through. The fact that you're putting time into it is a good signal.
As long as one, it's very you analysis, right? As opposed to you trying to pretend to be another AI person might do or whatever, that keeps you close to the wine.
I think it will produce a lot of value there. There's demand for that, right? The fact that you're using AI as part of your process as opposed to having the delivery... Yeah, there's a lot there.
I think you're totally on the right track for that, and that's awesome. They're like, "Hey." Then, redaction is actually a pretty good use case for that kind of thing and be able to share and tell that story.
That's fantastic.

**Ellie Rofe | 23:04**
Yeah, absolutely.

**Ray | 23:05**
Hard work.

**Ellie Rofe | 23:05**
And I think yeah, it is it's a pain.

**Ray | 23:06**
I'.

**Ellie Rofe | 23:10**
There's lots of different types of data. You have to understand the quality of the data, the relevance of it. I think that's what's always fascinated me. I guess it's the core thing about AI, which so many people refuse to accept, is that it is about the context it has. You can't just dump a load of stuff into it and expect it to magically filter it, because it doesn't at all.
It's not magic.

**Ray | 23:37**
No such thing.

**Ellie Rofe | 23:38**
And think, yes, and it's a bit frustrating. I did mention whether she'd allow me to have access to her decks, and she's like, "I don't think any VC's going to give you access to their decks," which is a shame. Even their rejects...
But you know that would have been... That would have been a layer of pure secret stuff that I have, but that's not there. So, I think it is a case of trying to put something in front of the BIA that impresses them, putting stuff in front of Dina that she can then put in front of other VCs just to try and get work through anyway.
That is my most direct route to work, obviously, as well as the free stuff I'm doing. He's going to get that right. He'll refer me. He'll talk to his board and people and say, "If you need someone." He's very good, that kind of thing.
The VC, she's got eight partners she's going to hand it to. She's got a couple of companies and deals that are going through that she's going to introduce me to. That's key. Some other people in the industry
and... The BIA, if they can then introduce me to another load of investors under the idea that I'm doing this report, that it's something different that the BIA themselves, who are incredibly well connected, have a lot of interest in. Then that hopefully just gets me back in front of more VCs and in front of more founders afterwards.
So I think that's.

**Ray | 25:11**
Mean for me...
The big mission of the report is just to elevate you, right? To say that instead of, "Hey, you're trying to solve a pitching problem." I need pitching or story, whatever.
You become the expert on... Okay, this is how investments happen, right? Because of that, they are trusting you for the piece of the puzzle that you're actually selling. I bring that up just so that we're keeping our eye on the job to be done rather than the form of it, right?
So, you're going to find that all this knowledge that you're gathering out... I'm doing this data analysis and this wrangling, and you're discovering... Well, maybe redaction is really what matters. That might have been not what we thought it was going to be a few weeks ago, but having redacted and being able to do the roast of no presentation in particular, right? To be able to tell that kind of story.
Hey, this is... This is why the VCs have a problem with it because not because it fails to tell the story, but because they can't figure out how. How to evaluate it. And which is because it doesn't tell the story, but all the...
And then, like, "Hey, you've been talking to a bunch of VCs, and it all sort of feeds in, right?" So, all of which, by the way of saying that the things you're like, "Hey, this is a lot of effort." The effort itself is the value.
It sounds like really cool stuff, and I can't wait to see more about what you've learned.

**Ellie Rofe | 26:41**
Yeah, well, hopefully, it will actually come to something that's workable. But yeah, it is interesting, it is useful. I think possibly the LinkedIn stuff... Do you know, I've realized a lot of it is that I really love working with the founders on stuff.
That's the bit that I really enjoy. I'm sure this is the same for everyone.

**Ray | 27:07**
222.

**Ellie Rofe | 27:09**
Despite me actually really liking helping other people with marketing, I find marketing for myself boring and frustrating and uncomfortable on certain levels.
So, I think I spend so much time on marketing because that's where the root is. It can make me feel very divorced from the process and the stuff that I actually really like about this work.
So, I think the client who's a deferred payment and b working on stuff that at least feels like it's adjacent to being better at the stuff I do, or is really a conduit to being better at the stuff I do, is so much more rewarding. I'm so much more like, "I enjoy that so much more."
I know the marketing has an aspect of that because the more you try and discuss what you do and the more you try and talk about what you do, you clarify frameworks, models, thoughts, underlying processes, philosophies, whatever else. It was just a bit dull there, especially because I'm not...
I think the extra layer in it all is that I am not me in the content that I create. So I'm having it's like having to divorce myself from the thing I like doing and who I am to create content for marketing.
Because this isn't an icky guy fit where I'm made to be working in biotech, but it's an important professional fit. I don't know if that makes any sense, but it's like some complete stream of consciousness about what I've realized. Why? I much prefer shipping and studying to the marketing side of things.

**Ray | 29:03**
Well, then maybe we should just talk about that marketing bit for a minute because you're talking about how it felt a little bit less genuine or mechanical or what have you. Or there were things that you were supposed to be doing.
I think the best of the marketing looks like some combination of studying and shipping in public. Because it's the best marketing I find is just thought leadership work. So it's, "Hey, your ideas I have, and I'm sharing them with you, right?" Ideas about the VC landscape, one of the reasons why you're gathering more information on it. Being able to share a couple of those insights, this is where things like the Opus clip stuff can be. I mean, I appreciate it.
So it wasn't quite getting exactly the right stuff for you, but how to just package up a couple of those things and send them to the market.

**Ellie Rofe | 30:00**
Yeah.

**Ray | 30:01**
And what I think. I was just talking to Demetrius about this earlier, and he, of course, in the mastermind was talking about this mechanical aspect. I'm doing a personal thing. I'm doing it whatever.
He's figuring out some of these things to create engagement, what actually is going to create sales. Okay, well, we figure out some of the mechanical things, but let's bring the joy back into it, right?
Because if people look at you and they say, "Wait, hey, here is Ellie, and she is smart and she obviously cares about the subject." I mean, talk about the guy, how much do you really care about the domain, whatever.
I think it does. I talk to you about it, you talk about it in energetic and interesting ways. I don't know if it's the thing that gives you all the meaning in the universe, but it certainly gives enough.
More than way more than average from people I talk to. So, I would... I want to hear more of that from you. I think that bit of it has the potential to be more psychologically rewarding for you as well, as opposed to being draining. We talk about good profits, bad profits.
I think, are we investing, are we drawing down on your emotional reserves in order to build up your market presence? That I think is bad marketing for the use of the same framework as the thing we did at the beginning of the call.
I think there is an opportunity for you to look at that and say, why is that bad marketing? Why is that drawing down on me? What is the part that's drawing up that I could do more of?
Because people will read through not just the content you're doing but the energy that you are putting back into the market. To your point about validating versus finding.
Yeah, sure. If these people all know each other, then they're told, "I should go talk to Ellie." They go, "Look at Ellie's profile." What are they going to find that will make them want to work with them?
Probably the most important thing is, who else have you worked with? Do they know? Right. It's asking me the network part, but the part after that is so... If I say the most important gear is your other customers, right? After your other customers comes your track record, and after your track record comes your ideas.
So, I think that was the point that your BC was making to you was like, do you need to be selling your customers and your track records? Go Google with that. That's fine. My impression, though, is that I sometimes think of it as selling your network right to the people you know.
You should totally do that. The reason for the marketing, what we've been calling the marketing aspect, is to grow that network so that there are more people who are almost ready to buy from you.
Then that increases your addressable market, and that's it.

**Ellie Rofe | 32:48**
I agree with that, but that's where I just... I don't know how well LinkedIn functions for that, increasing the addressable market. That's where I am.

**Ray | 33:06**
And now I understand it's about linked. LinkedIn is not important.

**Ellie Rofe | 33:12**
No.
But that's where I've been focusing.

**Ray | 33:13**
The thought leadership is important.

**Ellie Rofe | 33:15**
Marketing efforts. It's not like, you know, I think this is the question right in my head. Going in doing a conference where like with, you know, the BA talk about doing something in March where I would help with the pitching or whatever, that feels like that one event would get me in front of more founders who are interested to buy than a thousand LinkedIn posts.

**Ray | 33:40**
Yesm, absolutely.

**Ellie Rofe | 33:47**
And is where I'm like, I don't know what the answer is because being sporadic on LinkedIn is the question in that it takes quite a lot of energy and time, partly because it's like...
It is energetic, not emotional, like that, but it is an energetic drain to put it that way. I find LinkedIn generally dull, but that's fine. I think partly it's an issue of the platform. Do I need to go and hang out my shingle on X?
But that's... I think that's more for sales founders. Still, I think these biotech founders are quite insular. I think they're quite academic. I think they live in a world of networking. I don't think many of them spend very long on LinkedIn. I don't even think many of the VCs spend very long on LinkedIn, as far as I can tell.
So it's about where I deploy my energies?

**Ray | 34:52**
The reason to be shipping on LinkedIn, the reason I encourage that of all of you is to be creating the daily habit of speaking to the market.

**Ellie Rofe | 35:03**
2. Yeah.

**Ray | 35:05**
The problem with the conference is that it's in a few months, and it's very easy to say, "I'll do that in a few months then." What are you doing in the meantime?
Well, I'm gathering some data and doing some stuff over here. Then you wind up making what? What? You what? Could have been like a week's worth of progress taking two months. Now you're measuring yourself based on things that are going to happen every 60 or 90 days, and that becomes the pace at which your business moves. The thing I like about the social media part is it's just a venue or a medium for you to express yourself into the market. LinkedIn is a professional social networking place. You tend to be around other people who are professional.
It's not that you're not surrounded by a bunch of people who are talking about politics or doing worse stuff because X has turned into a shit hole, right?
So you're around the right people. When people are looking you up because they'll often look up your profile, they will then find this stuff as proof of life. But the most important thing is the idea that you are a person with important ideas and that your. You trade in ideas through study.
We're saying the important thing in study is that you're getting more ideas. Then, the important thing about selling is that you're sharing those ideas in the market, and it provides you with a medium for doing that.
If you then turn around and find, "Wait, there's another medium that I should just..." I've got a bunch of people who are following me. I'm going to turn this into a newsletter, and I'm going to be doing that on that very frequent basis.
But just like that thing we talked about, the whole weekly report being harder for you than the daily, I'm with you on this. That's the reason why I'm doing the daily posts. That's the reason why I frankly automate a lot of the posting stuff, even though it gets less reach. I don't care. What I care about is being able to put my ideas into the market and then other people carry them or they don't, and that gives me a lot more insight.
So, how much engagement did you get? Not the important thing. The question is going to be, "How do the people who you care about associate you as someone who has useful ideas and insight that ideally goes beyond just the immediate thing that you can do for them?" When you do that, they think you... No, sorry, go ahead, please.

**Ellie Rofe | 37:19**
Back again? Am I still sorry? It just brings me back around again. But am I talking to the market or am I talking to people who aren't the market for me?

**Ray | 37:34**
Well, you talked to lots of people who aren't in the market, but the fact that lots of people who aren't the market are hearing you isn't the important part. It is important that some people who are in the market might be hearing you.
But I think the most important thing is that you are speaking regularly, right? In a way, the whole idea of morning pages is to get you speaking to yourself on a more regular basis. I want you to be speaking to the market on that more regular basis. What I found is that the cadence at which we move then determines the pace at which our practice moves.
If we have a conference every ninety days, we want to do things every ninety days, and that's our sale, our intervention into the market, then we're not going to improve on that pace.
Don't get me wrong, you just put things out every day. It's not like all of a sudden you're going to be going from... It's going to improve things by 90x or anything, but it will improve it by quite a bit.
Frankly, by the time you get to that conference, instead of you formulating ideas for the first time as you're talking to people, you're going to have things you said thirty times before. They won't have heard it before, but you're going to come across as much more expert in these ideas because you've had the opportunity to practice them both in terms of content and local conversations. Whatever you had along the way, and that's going to be the difference between you and your neighbor. They're going to say, "Wow, Alie was really smart. I really want to work with Alie now."
That brings in the transactions, right? You're looking forward. That's the thought leadership part, that's the whole... Blair ends the most important tool in marketing is the pen. That's the spirit of it, right?
I bring that up because, just like we're talking about the jobs we've done in the previous... If you look at this, you're like, "Wait, there's another way for me to be getting to that same kind of daily cadence and speaking to the audience I care about, that's better?"
Totally go for it. But the important thing to me is the frequent cadence of you expressing your ideas into the market. That is the way that thought leadership creates returns, and until you have something better linked in as a baseline.

**Ellie Rofe | 39:43**
Yeah. Okay, so I think then my goal is to find ways to make it take up less time wherever possible.

**Ray | 39:56**
Ideas per hour might be a useful metric for looking at this. So if you can press an idea in...
Well, I would do this. How do I do LinkedIn through the
will pop onto... When in the winter, right? I'll be on the snowboard, and I'll fire off these things. That becomes the way that I express myself into the market using LinkedIn. More recently, I've been doing this vidcast with you. Ner in CCH runs her own community, and we do the thing.
So it's an hour per week. Then I've been using Opu to go find the top seven clips that relate to me, and I'm getting those things to auto-post. It's the ability to auto-opus that is not super fantastic yet, but it's something and it's moving me a bit more in the right direction. He actually just showed me this thing that is making sure it's based on basically brain-rot video principles.
Subway Surfer type videos, and he's getting a lot of engagement with it. I think they're crap. I don't think it's going to help them with this business, and that's why I talk about ideas.
It's not about engagement, it's about ideas. Then you're going to have an idea like... Someone's going to reflect on that. You can definitely bring the same idea back around as you know, respin it.
I've done that a number of times, and these will create assets for you. The whole thing of like, "Okay, what am I doing with LinkedIn?" There's a little bit of like, "You've built your connections, great. You've probably done a bunch of that at this point."
That's probably done. There's a little bit of keeping up with people on a direct basis, but that's a lot of what you say, setting up meetings and what have you. Then there's what the thought leadership is.
How can you be doing thought leadership on a radically more frequent basis than anyone else? I don't want every one of them to be a banger. I'm expecting most of them won't be. But by doing more...
It's like the parable of the pots. You're going to have more of those good ideas that will click and give you more opportunities to win. That's what I want for you, more opportunities to win.

**Ellie Rofe | 42:08**
Yeah. Okay. So I'm going to stop thinking about LinkedIn as much as a selling discipline as it is about a thinking discipline and an ideas discipline.

**Ray | 42:19**
I think if you can help make your audience smarter, right? You want them to come away and say, "Wow, I'm smarter. I'm going to do better business today as a result of having listened to Ellie."
Then that's the thing you want to hang your practice on. Jerry Vanerchuck, you know, is the expert at this kind of personal brand marketing. He calls it personal brand marketing. I really like the idea of thinking of it as thought leadership, taking the Blair ends idea and mixing it with a mirror idea and that frequency of bringing things to the market and then building up that trust. They're looking for their fix for the day
and then you have your idea. It doesn't need to be super huge, but moving them along. And then, his thing is jab, right hook, right where... You don't need to be worried about what the sale is, but then every once in a while, it's like...
Just so you know, I help businesses, biotech businesses, raise money by getting the story so that the investor can actually evaluate this.

**Ellie Rofe | 43:32**
I totally understand when people whose market is on LinkedIn, but I don't think it works to frame it to myself that I'm doing this, because every time I post, the people who need to see this stuff are seeing it and it's making them do their job a bit better. I don't think the people who need this are seeing it.

**Ray | 43:57**
Okay.

**Ellie Rofe | 43:57**
I don't think they go in their network.

**Ray | 43:57**
Where did they go?

**Ellie Rofe | 44:01**
I think they go to conferences. I don't think they're.

**Ray | 44:03**
Their comp is infrequent. Where do they get more on day.

**Ellie Rofe | 44:10**
I a day-to-day mean, most of them seem to just be stuck in a lab or in their business and working with their network. They're not particularly, as far as I can tell, hooked on LinkedIn, it seems to me.
This is something I'm trying to verify. So I might just be plucking assumptions out of my butt and it'll be wrong. But it seems to me like the biotech industry in particular is being drawn down so specifically from academia and science, it is quite insular.
It is nowhere near as self-promoting on certainly in this early stage basis as SaaS. And that is what people think of when they think of the startup world, this culture seems to be radically different.
I've looked for different VCs talking about it. You don't get many biotech VCs making massive noise. You get hard tech VCs who are covering different stuff, who talk about the big, exciting shifts and that's frontier technology across the board.
But biotech in itself seems quite insular, it's quite small. So, I don't mind thinking of this as a discipline for me in terms of thinking, so that when I do talk to people, I'm more intelligent, and I'm coming out with better ideas, and I'm making myself smarter.
I think it feels like... I think that's past possibilities. And look, I want to verify this with other people as well, but it feels like it's self-defeating for me if I think I'm connecting with the people I need to connect with and changing their practice. That just feels like a lie. That feels like it's not real.
As soon as there's that disconnect, I start going, "This isn't real." But reframing it for myself to go, "This is a practice I do to make myself smarter." Fundamentally, even if no one looks at this stuff beyond the small coterie of other consultants who are all talking about the same kind of thing on LinkedIn or talking about their area and angle of work on LinkedIn, that doesn't matter because when I do speak to people, A) they can see. Would they go and look at my LinkedIn profile? Once they've been referred to me, they can see that I am not an idiot.
And in BI, when I speak to them, I will have more to say to them to help my case. I think what to say to them isn't even about sales. Because, to be honest, most of the time, if you get introduced by a VC in particular to someone and they're like, "I think this person could help with your deck," then an awful lot of founders alike, right? The VC wants me, or the person on my board in particular, wants me to work with this person on the deck. I'm going to have a really good reason not to.
I don't think it's helping with the sales, but I do think it will help with my value word of mouth and the ability to raise my rates. That's where I think the leverage would come from.

**Ray | 47:28**
Sure that sounds reasonable to me. I think you're probably right that I do think of it as proof of life stuff. The people who see the shorts...
For example, my shorts are people who are already following me, right? They don't find me through the shorts, right? There are other ways that I can promote discovery, but I think you're general...
I think you're right that people aren't going to... People who have never met you or never even heard of you, or otherwise going to be suddenly influenced by stuff. No, you're right, that's not going to happen.
But when they're your audience, then it does happen. So I think your point is that these people are mostly in the lab and they aren't even thinking about selling because they're not doing study sell ship right? They're just shipping all the time. Or maybe they're studying all the time, depending on your point of view on that.

**Ellie Rofe | 48:16**
Stuff here. A huge amount of SHH.

**Ray | 48:17**
The not selling.
Okay, so now you come in and you're able to be where they are selling, but they're not thinking about it until that point. So you're developing your ideas. But then once they are thinking about selling, where do they go and who do they find?
They're not going to find anybody but you. Then your ideas become super helpful, right? So it's a little bit like, are you getting value from the river or are you getting value from the lake? The river flows into...
What you're doing is you're building up that proof of lifestyle and of what you have done and what you have thought about. And then people go do that. I talk to people who are way... I found your video through X, through how to or whatever, right?
Then they start having the shorts show up in their feed. After that, it leads them to actually do some sort of transaction. But the reason I'm able to get some of those bigger ones is because I've been thinking about these ideas and thinking about the ideas. I find that the shipping can help with that, or that the shipping on the daily can help with that if linked is not the right way to do that.
For example, YouTube can be a very good way of communicating these kinds of things. Again, I don't know where they're looking. What do they do when they're looking to turn off their brains? I don't know.
But I have a pretty easy time that they're like everyone else and they do bring out social media. The question is, can you be bringing less brain rot and some quality into it? That is the way that I do the distinction.
Right? "Hey, I've got..." Right after the Brain Rob video and right before the law and order clip, there is Ray on the chair lift talking about some sort of business idea, right? That becomes the thing that's not like the others.
Okay? That's the way I contribute into that. Similarly, I think you have the opportunity. "Hey, this is a topic they care about, and who else is talking about that topic?" Nobody.
Here's you, the discipline of the thinking, I think is really valuable. But if it is only the discipline and you're not actually reaching anybody, you're going to feel drained by it. So like it? It turns it into a study thing instead of a cell thing in order for it to sort of stay in the brain.
But then comes... Okay. How do we sell into the rest of the market? This is where a newsletter can come into play, and whatever comes into play. Maybe there's a little bit of just finding out where these people go.
Then, the same assets you've been making in shipping into LinkedIn, you can go across and apply somewhere else, which can be a really delightful thing. I have a huge library now of these shorts that I've made there over on YouTube, and discover new social networks. Great, boom, I've got a library I can go apply to that, right?
So you can do those things more cheaply, but it might be worth asking the question, "Do you use YouTube? Do you use whatever else?" Then, to your point, "Well, they're just in the lab, and they're not thinking about sales." Fair enough.
But what do they do when they're looking to move off of whatever hardcore thing they're doing when they pick up their phone and they're like, "Okay, well, this experiment is running for 20 minutes. What am I going to do now?" Where do they turn?
I think that understanding that might help you with your sales process, and frankly, just asking the question probably really elevates you and people who are thinking about selling this field.

**Ellie Rofe | 51:49**
I definitely will ask. I haven't yet, and this is why I wanted to speak to all these other consultants.

**Ray | 51:57**
No.

**Ellie Rofe | 51:57**
I haven't yet heard of anyone picking up business from LinkedIn or from...
So, I've heard of people connecting it's like connections and network and recommendations. It is fascinating to me. It feels to me like the thought leadership route is the route for this business,
but that thought leadership largely comes through the way that they think of thought leadership, which is networks and and.

**Ray | 52:28**
Okay.

**Ellie Rofe | 52:30**
And if I am doing these things as a kind of muscle reps, you know, online to get my thinking clear, which I do need to do, it takes me time to get my thinking clear. I work instinctively a lot of the time, and to actually express it and articulate it is important for me to do reps.

**Ray | 52:48**
Two.

**Ellie Rofe | 52:51**
But yeah, it is a really good question. And I was just thinking. I will be asking people. I know about it.

**Ray | 52:58**
Cool, yeah, and like the right... I think then you're able to match your message to the medium to the audience.

**Ellie Rofe | 53:00**
Yeah?

**Ray | 53:13**
But for me, LinkedIn is like democracy, right?
It's best. Except for all yours. From a social media point of view or sorry, what best except for worst it's worst form except for all as right that's Churchill, the what I would wish for you is if we can find something that's even better than that fantastic. It for me, the biggest thing is how to make it so that you are doing that publicly on that more frequent basis because that'll be good for your reps.
I think in the short to medium term, it's a lot better for your progress, right? To be able to trend the fixture for your business, which is what I would wish for you. I don't want to be like, "Hey, your next big sales opportunity is in this conference
in 60 days." Then you're going to have a sales cycle that's going to go after that, and maybe one of those things turns into it. Now we're talking about you getting $10,000 six months from now.
That's not what I wish for you.

**Ellie Rofe | 54:09**
No, not at all. I think the sales cycle initially is the best opportunity I have, apart from ones that are bubbling. But you know, on hiatus is if I grade it this VC introducing me to her companies directly, two of her portfolio companies and eight of her partners directly. Great. Potentially getting introduced once I finish this pitch deck from the people that I'm doing the deferred payment thing on.

**Ray | 54:43**
He.

**Ellie Rofe | 54:43**
Potentially get work from the guy who put it on hold in April.
I mean, he's a nightmare. Who knows? I'm not holding out on that one. But that might be... I think of revenue streams. This is where I'm looking. Potentially getting the BIA to introduce me to loads of VCs who will all have lots of portfolio companies, and who will all be vaguely interested. 30% interested in knowing a pitch consultant who can help them in the future if they don't need something right now.
Then I put LinkedIn... That's where I see the greatest likelihood of actual money coming my way.

**Ray | 55:25**
Two.

**Ellie Rofe | 55:25**
So that... That's not... I don't think that's a negative thing. I think it's just realistic. It just seems like networking is the way.

**Ray | 55:35**
Yeah, absolutely.

**Ellie Rofe | 55:35**
But yeah, reframing LinkedIn as a tool for my thinking and a process is fine.

**Ray | 55:39**
II I'm trying to understand, right?

**Ellie Rofe | 55:44**
I just have to then, like, reframe it and think of it like that, rather than I'm going to try and connect with these people and do this and then suddenly start building and.

**Ray | 55:54**
You're not going to connect with people through LinkedIn? LinkedIn is far more useful, I think, as a publishing platform than as a network platform.

**Ellie Rofe | 56:02**
But who am I publishing to? Loads of people who have absolutely no relation to this world whatsoever.

**Ray | 56:09**
Sure, most people don't, and a few people do, but the few people who do, you're not publishing to them in real time.

**Ellie Rofe | 56:09**
Like that's.

**Ray | 56:15**
This is where the proof of life stuff comes in after, and to your point, then you gain the value of the reps, and you're gaining the value of the improved reputational aspect of that.
If you have someone who's trying to refer you, them... Having a linked post, right? That you did is a lot more powerful than just the raw email or this is just how does it create assets for you? I think would be the way to look at it.
That's why I talk about the lake and river. But if the thing you wrote is from six months ago, it actually loses a lot of value. This is why continuing to refresh the lake becomes important. Repetition is not the worst thing in the world as it relates to that.

**Ellie Rofe | 56:55**
Yeah.

**Ray | 57:01**
But another thing works. FA like if there's like a I don't know, like a I'm making things up here, but there's like a jamma forum or something, then that might be the better way to do that. Form based marketing is very, powerful, you know?
And if you're out there speaking about hey, fundraising right, the broader thing in the content and then the how to help you know V cs understand what the value is here. There's juice in that. You know, but to your point like and sort of, you know, maybe close with what we had at the beginning, you know, there there's idea of, you know, good profits, bad profits and good initiatives, bad initiatives.
And I would wish that the initiative that however you're allocating your time, you know, in the coming week is something that is both giving you energy and moving you forward in your business. And you're finding. Wa. This is just kind of draining. Especially having had some practice for a while.
Maybe we use as a signal to say that. Okay, there's. There's something wrong with that. What can we do about it.

**Ellie Rofe | 58:05**
I think I need to push through a bit further. I think I'm happy to do that in a month, but for the moment, I think I need to push through because it's very easy for my brain to just reach for comfort. That's not what I want to do because you... That's not the way forward. So, I will continue to see ways to reframe it because I think it's important not to push. Just go, don't like it and stop it.

**Ray | 58:37**
Right? We don't want to stop at the... But I do think listening to the signal and then tuning it to be able to get the best of both... I do think that the two have both on the table.
It's not like I need to suffer in order to make progress. Sometimes we're suffering because we're starting, and then we discover what works, but that's just the discovery. It wants to have us stay open to...
All right, I appreciate we've hit the end of the hour.

**Ellie Rofe | 59:01**
Yes. Yes.

**Ray | 59:05**
I'm actually kind of excited for what you've got, especially what you're talking about the connections, et cetera that you've got in the coming week. Do you think you'll have any of these meetings that you've been opening the doors to between now and we talk again next Friday?

**Ellie Rofe | 59:18**
Yeah, I've got a couple of books for next week already.

**Ray | 59:21**
Super cool.
All right. We're looking forward to talking about that. If there's any other way it can be helpful between now and then, just give me a buzz.

**Ellie Rofe | 59:29**
Thank you. Okay, we'll speak soon.

**Ray | 59:31**
Turnw. Bye.

