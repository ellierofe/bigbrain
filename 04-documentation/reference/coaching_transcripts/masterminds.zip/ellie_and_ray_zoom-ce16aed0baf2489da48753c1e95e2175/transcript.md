# Ellie and Ray Zoom - Jul, 04

# Transcript
**Ray Deck @ statechange.ai | 00:01**
One, fab needs to be in the room and second, you need to be in a context that works with fathom. Yeah,

**Ellie Rofe | 00:07**
No, that's why it's saying it's recording now. So I shall see. Interesting. Okay.

**Ray Deck @ statechange.ai | 00:12**
Excellent. Excellent. Great. So. Well, forgive me, I could be looking at the. Yeah, okay. You did just put in the. Well, actually, have you put in your thing for today?

**Ellie Rofe | 00:32**
Raining in my head at the moment. Sorry. I realized this morning that I hadn't done that and so I need to set up a reminder in my notion to do that to make sure that I actually put those things in and I apologize.

**Ray Deck @ statechange.ai | 00:52**
Yeah, I would just make it the previous day. Now we're getting some weird echo things. I think it might be because your zoom is set up to use Krisp for one and you and not use CRISPR for both. Microphone as well. Speaker. If you go to audio in your zoom, you can see what you got for. And when those two things are misaligned, there can be a delay and that then causes the feedback.

**Ellie Rofe | 01:24**
Same as system. Okay, how about this?

**Ray Deck @ statechange.ai | 01:32**
And so far you're sounding just fine. No, there's. There's me. Seems like I can hear myself a little bit there.

**Ellie Rofe | 01:40**
I've got it set to the crisp microphone.

**Ray Deck @ statechange.ai | 01:43**
And the crisp beaker.

**Ellie Rofe | 01:49**
No. What happens if I lose crispy? Yeah,

**Ray Deck @ statechange.ai | 01:53**
That should make things better. Let's try talking. We'll. We'll see how we do.

**Ellie Rofe | 02:05**
Okay. All right. Sorry for this. I have clearly arrived with nothing in my pocket, bringing nothing to the table but chaos. Chaos

**Ray Deck @ statechange.ai | 02:16**
Is not terrible. Chaos has changed. You know, like the I. I realized was talking to, you know, another company that needs to be a little bit more in a startup mode. Okay.

**Ellie Rofe | 02:29**
Sorry, one second, Ray. Sorry. The problem I have is by changing it to the Chris speaker, I use an external speaker.

**Ray Deck @ statechange.ai | 02:38**
I see.

**Ellie Rofe | 02:39**
Hang on. No, sorry. I should have tested this long before. Totally

**Ray Deck @ statechange.ai | 02:47**
Fine.

**Ellie Rofe | 02:48**
Okay. Are you getting any feedback?

**Ray Deck @ statechange.ai | 02:50**
I am not getting feedback presently, no. A little bit.

**Ellie Rofe | 02:54**
Okay, let's see how we go. Sure

**Ray Deck @ statechange.ai | 02:57**
Thing. And I wouldn't worry about too much. I think it's something to experiment with and I'm glad to be part of the experimentation, by the way. I think that's. That is profit from the session if you are in a position to be able to use the thing in the future. Yes. And I'm a big believer in having both the belt and suspenders. In addition to having crisp, I use software called Backtrack, which is automatically recording both my screen and microphone kind of at all times and keeps a rolling Last, I think it's set to right now three hours. So if like I forget to record something right. I can go back and pull like the last 90 minutes. And now I've got, you know, at least what was represented on the screen. It doesn't look exactly like we're having on. On a zoom or whatever, but it's, you know, as my father would say, it's better than nothing.

**Ellie Rofe | 03:52**
That's really interesting. So I could. Because what would be useful for me is occasionally to just as I'm working on something, to just literally talk through it without having to faff around with recording something on my phone and sending that somewhere or recording into AI. Okay, Backtrack. Interesting. I'll have a look. So

**Ray Deck @ statechange.ai | 04:12**
The Backtrack is one service for this. Another one is called Rewind. Backtrack is nice, it's a free app, runs locally. They have a paid service too, but their paid service is all about cloud storage and the big utility is all locally. I think there's a broader thing about like where the advantages in business right now of, you know, data collection versus data analysis and being able to collect from that front end and having that, you know, backup plan. The times it's let me down has been when it's been recording the wrong screen. Right.

**Ellie Rofe | 04:45**
Because

**Ray Deck @ statechange.ai | 04:46**
Having multiple monitors actually makes a little bit of a thing with that which is, you know, okay, whatever. But that's been a thing the voice memo thing that you and I have been talking about a little bit, I have been making. I have myself in recording, just doing voice memos and I now have a bit of a pipeline too. They go up actually into Xeno of all things. And then I have a function that is then running them to get transcribed from assembly and AI as well as then I described it as summarizing, but just transform it from the transcript of whatever I was babbling about into as I put it, like a five paragraph essay.

**Ellie Rofe | 05:31**
Yeah.

**Ray Deck @ statechange.ai | 05:32**
And it's like that's actually pretty good. And the low friction of being able to capture ideas that way has been I found pretty useful with a little bit of prompting, able to get it to pick up turns of phrase that I use as well. And it keeps it from just sounding like AI. Yeah,

**Ellie Rofe | 05:52**
Yeah, absolutely. It is crucial and it can do it. You just have to hold it down and go, no, say it in the right way. Don't try to AI. Yeah.

**Ray Deck @ statechange.ai | 06:07**
But then the very cool thing for me in that experience was and this is sort of all along with the way of me saying thank you to you I was able to, you know, by, by dialing in that one prompt was able to get leverage across 13 of these memos. Right. And then, you know, turn them all into essays. Actually, the in, in state Change Assistant, which should be coming out sometime next week, there will be a, a section for essays that I've written. Right. That were things I wrote and another one for my, what I'm calling my memos, which are coming off of that, you know, voice

**Ellie Rofe | 06:42**
Transmission. That's really nice. I love it. Yes. I, I was getting it to. What was I getting it to do? It depends on what I'm, I'm putting in. So I have, I have one set up where I will talk through a presentation, like talk through a client presentation and then get it to give me responses on like structure and points and visuals and stuff like that. And then when I'm thinking about ideas, giving me like objections to the idea further thinking where points to clarify that kind of thing. So it doesn't just summarize what I say, it pushes back at me and goes, what about this? What about this? What haven't you seen? But I think you're a thinker than I am. I think I'm, I, I'm quite an intuitive thinker. But then it's all chaos

**Ray Deck @ statechange.ai | 07:39**
And

**Ellie Rofe | 07:39**
It takes a while to come into some sort of light. Whereas I think you're, well, you're very intuitive as well as far as I can tell, but just very clear in the way you think. It seems to come from your brain quite well into the, into the foreground.

**Ray Deck @ statechange.ai | 07:54**
Yeah. Or it's only come up with occasional terms of phrase. The but. The but I hear what you're saying that, you know, one of the things I have, I had another company, they sent me their strategic plan for the next year and I, I, I put it into, I, I, I took it, I put it into. Claude, to, to your point of like asking for like, you know, objections or what have you. And the way I expressed it was, you're an investor. Call bullshit on this. And

**Ellie Rofe | 08:24**
I

**Ray Deck @ statechange.ai | 08:24**
Go and like, and, and, and my feedback was, you're being too nice.

**Ellie Rofe | 08:29**
Yeah.

**Ray Deck @ statechange.ai | 08:30**
I found that to be just really helpful because AI does want to be all patting you on the head because it wants positive reinforcement, but it does seem to have the ability to come back. And it might not, I mean the ways it calls bullshit might not be what? I might not think those are accurate, but at least it's pushing on those ideas.

**Ellie Rofe | 08:50**
Yeah, exactly. Yeah. I find if you are the sassier, you are better. It Will do it because obviously it responds to your tone. So. Because it's kind of trying to be like you.

**Ray Deck @ statechange.ai | 09:04**
Yeah.

**Ellie Rofe | 09:05**
Part of that positive reinforcement. I mean, obviously, as we know, that's quite a haunting, potentially terrifying future. I mean, even present there's people who are getting sucked in. But if you say roast the absolute out of this thing, then it will be like And have a bit more sass to it when it's roasting something.

**Ray Deck @ statechange.ai | 09:27**
It will. It will the. And that I. I found that to be helpful. Although I did have an experience with cursor where I was, you know, getting a little frustrated at it for not figuring out a problem. And I was frankly swearing at it regularly in the, in the prompt. And finally it said, let's keep this professional.

**Ellie Rofe | 09:48**
Wow. They have like just come

**Ray Deck @ statechange.ai | 09:51**
One

**Ellie Rofe | 09:51**
Of those sites if you're abusive to our LLMs, you may be ejected.

**Ray Deck @ statechange.ai | 09:58**
And to be fair, I was being pretty abusive at that point. I was, I was, I was, I was ticked off. But it was, it was actually helpful for it to do that because while I was, you know, in a bit of a red rage with. In direction towards it, probably for reasons didn't deserve the, you know, it pushed back and that caused the thing to clear and to think more clearly. Yeah. And that was that. That can be. That was not a thing I expected AI to be able to. To do. Anyway, I don't mean to be completely hijacking. I meant to be opening just with a thank you. Of course. I don't have your previous week in

**Ellie Rofe | 10:33**
Review,

**Ray Deck @ statechange.ai | 10:34**
So I, I come in a little bit cold here and I guess I would ask, you know, what I try to do is not have the meeting be a. Let's review the week. Right. That's the purpose of the document. That way we could talk about what's next, you know.

**Ellie Rofe | 10:46**
Yeah.

**Ray Deck @ statechange.ai | 10:47**
So what I'd like to do is give you the homework. If I could impose on you doing the thing. There's afternoon. Okay. Just

**Ellie Rofe | 10:56**
So

**Ray Deck @ statechange.ai | 10:57**
I don't want the week to go by without it. But, but I'd like to have some more utility for you out of the conversation of, you know, how is it that we can help you make next week better than this week? Sometimes they go, I can do that better for you when I have perspective. Right. On the week from the report.

**Ellie Rofe | 11:15**
Yes,

**Ray Deck @ statechange.ai | 11:16**
But you know, but, but you. Little bit cold. You know, rather than a. Well, let's just sort of talk about it and catch up. I think that's not a great use of your time. So, you know, based on like the experiences you've been having, like, what were you imagining would be like, profit you could be getting from the hour that we sit here today? It's

**Ellie Rofe | 11:34**
A very good question. I suppose one of the things I, I wanted to sense, check with you, is I have spent quite a long time creating a carousel for LinkedIn and. But it's not just the carousel, I think. And this is where I'm like, am I just being perfectionist about one bloody carousel and wasting hours,

**Ray Deck @ statechange.ai | 12:05**
Or

**Ellie Rofe | 12:05**
Is this actually study and experimentation? So, I don't know. One second. Sorry, we've got the laptop versus main thing again. Okay.

**Ray Deck @ statechange.ai | 12:22**
Yeah. You want to show it? That's great.

**Ellie Rofe | 12:24**
Yeah, that's why. Right. I was

**Ray Deck @ statechange.ai | 12:29**
Talking with David Petro who's having great luck using, using Gamma for carousels.

**Ellie Rofe | 12:36**
Who's that? Sorry?

**Ray Deck @ statechange.ai | 12:37**
Daniel Petro. He's the, he's a dev rel over at Xano. He's a member of Stage. I've known him for a few years. He happens to be working in Xana right now. But he was talking about like great success he was having of. You know, because carousels do get more engagement. It's a great tool to use. And the, and, and one of the neat features of Gamma is that you can, you know, make a presentation, you know, and even know, set up to be designed to go to into LinkedIn.

**Ellie Rofe | 13:04**
I did try. So one of the reasons this was more of an experiment is. And this is where I don't know whether it's, it's a true or false thing. I. This is like, Jesus. Okay, I've exported this and it's a gigabyte, so that's not particularly helpful. I might, I might just try and join on from my laptop and just share from there.

**Ray Deck @ statechange.ai | 13:31**
Don't worry, don't. Don't worry about like blips in the call. Like the, the purpose is to create maximum value for you in the course of our time.

**Ellie Rofe | 13:37**
Yes. So I couldn't get on with Gamma for carousels in terms of what I was trying to do. I can see where the utility is. Yeah,

**Ray Deck @ statechange.ai | 13:52**
You might want to mute that and turn off the volume.

**Ellie Rofe | 13:57**
Yeah, just muted. So hopefully that's all right. Okay. So I'm thinking part of the reason I, I think maybe I get perfectionist about stuff is in my head.

**Ray Deck @ statechange.ai | 14:16**
I

**Ellie Rofe | 14:17**
Think if I'm telling people that I help them with storytelling and design and wordsmithing, then chucking out something that has been made with Gamma, which is nice, but it's not storytelling and design. Like I've Tried and I've played with it and I'm pretty good at prompting AI. It's okay, but it's not an expression of what I can do for people. So is it, Funnily enough, listening to Rory Sutherland, who in my head is just Andy Serkis's dad, by the way. It's just pure emphasis. His dad listening to him, I'm like, okay. There is an element of signaling potentially here where I'm saying, I do these things and I put time into them. I can do these for you. And of course, it's come up. Hang on. Right, I know what I'm going to do. I'm just going to share the Photoshop,

**Ray Deck @ statechange.ai | 15:18**
Just show your screen, you know, we don't need to make it more

**Ellie Rofe | 15:21**
Complicated.

**Ray Deck @ statechange.ai | 15:21**
Weird than that.

**Ellie Rofe | 15:23**
Yeah, it's all right. I was trying to share a PDF I'd done of it, but it's fine because that's all in. Right, so this is like a kind of. This is like the underlying thesis of how I work. And I've been putting this together and I know it's long, but it's deliberately long in terms of. It doesn't have a shit ton of text on every page. It's not just text, it's design and sort of telling a story. So that's basically my. My argument is this is design, it's telling a story. It's a central thesis. I'm putting it together like this because it's made me have to think about. It's made me have to put it. When I translate stuff from just text into visuals, I have to think about the essence of something. I have to think about what I'm actually trying to say, streamline it. And now I've done this, almost finished. I can then repurpose all the thinking and work I've done in this into other things. Anyway,

**Ray Deck @ statechange.ai | 16:30**
Yeah,

**Ellie Rofe | 16:32**
So it's a kind of experiment and putting this out there as a carousel, which I will repost every couple of weeks or try and get feedback on, that kind of thing is its own experiment in terms of marketing and how people respond. Not that I think it's going to get loads and loads of response because I'm still not exactly getting a ton of reach on LinkedIn. But it's part of the. The point has been the process, and part of the point is a marketing asset. Does that make sense?

**Ray Deck @ statechange.ai | 17:04**
Yes, I'm understanding where you're coming from. I think we'll. We'll have more of a discussion about a minute. I want. I want to download from you where. Where you are today?

**Ellie Rofe | 17:13**
Yeah. So I almost finished this and I'm going to post it.

**Ray Deck @ statechange.ai | 17:17**
I

**Ellie Rofe | 17:17**
Think tomorrow morning I'll post it. But once I finished it today, what I was going to do is then work out some posts, video other things off the back of this and just trial this as a piece of IP that summarizes what I do. Does this seem like a useful experiment for me to be playing with?

**Ray Deck @ statechange.ai | 17:46**
Yes. My framework is learn, experiment, build teachers. And I don't know if you saw any of that talk they gave on the subject but like the ideas I have, you know, it's a two by two as often my things are right. And the. And then what. What you're doing here is this could potentially be thought of as being a few different things. But I think like you say it's an experiment. Right. And so the experiments job is to learn. You're trying to figure, you're trying to determine something for yourself. Right. And we'll have the side benefit of you being able to sell experiments to my mind should be based on a question you're asking about the market. Right. Sometimes that question is super well formed and very explicit. Sometimes questions a little more intuitive. But like you're trying to learn the thing. Right. And that's its job is to teach you something. But seconds they have to be fast. So one of the tricks about doing things that are really core to your practice or to your identity is that it makes it harder to go fast. Because your point about perfection like fear of putting something out that doesn't quite right. You know the. And you make a good point that like you know, using a tool like Gamma, you're sort of outsourcing design. Now of course I'm not a designer, right. I care much more about the copy and I care about the ideas. You talk about me being clear thinkers. Well that's what kind of one thing I want to present and that and, and, and this is that becomes kind of tool that is like decreasing the friction on my ideas. Yeah. You are a person who does ideas. Your person does words, your person does images. I would posit that you might be too concerned about having to be all three of those things at the same time in all the things you do. And when you do that you're going to slow yourself down significantly. Right. And there because there are people who will care about your design, people who care about your words, people who care about your ideas. But it is entirely possible in fact very likely that you're going to go and talk to a client and they're going to be using their aesthetics, not yours, right? And the. And, and so like you showing that you can get ideas out there that are remarkable for them in the 15 seconds you have of their attention is kind of where I would start. Now the trick of having like this very, very long carousel is the carousel itself can be engaging. If they've gone through five slides, they can go through the rest. Right? But what is it that gets them into it? Like the. And. And I think that is an open question that you don't have an answer to. By doing this, you're sort of committing yourself to the first one having been, right? And then it goes the rest of the way. When I talk about experiments being quick, I usually, I think about that in terms of like the 1, 2 framework, right? Like it should be. You're spending an hour, if it's not working out, you're. You're putting it down and you're looking something you can ship by the second and second hour, right? And the. And it's. It's going to be when you get out of that zone of comfort of understanding of things that we move into what I call built, which is the framework that comes after that. But build is something when we're committing to making a bigger artifact, right? But that's downstream of the experimentation now. It's still part of the learning framework because we're still learning things from the build. The build is there to help answer usually a bigger, a deeper question, right? But the idea I have is that learn and experiment versus build and teach. So learn, experiment are like you getting information into your brain. Build and teach are about putting things into the world, right? And then from a left and right, like, you know, learn and learn and teach are largely about ideas, right? Whereas experiment and build are often much more about artifacts, right? They're the process of creation. The thing I didn't think about and was only pointed out to you when I gave the talk was that there's another axis of it which is you can look at them as the way they cross. And I hadn't quite seen it myself, but the idea is that like on the diagonals you have fast versus slow. So like learn. You often talk about, hear me talk about like go reading a book, long form things that are hard, right? And build similarly is something that's deeper. The. Whereas teach is fast, you know, get things out that like, are getting the good ideas in other people's head with less friction. And you know, I talk about like you're making shorter videos. What have you and then experiment similarly is relatively quick, you know, iteration. And I think the trick is when we try to use the wrong timescale, right. For the wrong part of that or on the wrong diagonal. Right. So like I think what some people do is they think they're reading blog posts and they're learning, but they're not. Right? They're not. It's, it's, it's not, it's not deep enough to really be. Be changing your neurons. People like get into significant building and call it an experiment. But you're not doing enough experiments to have a high pace. Right. Of learning. Right. It's confusing the experimentation in the building. I would propose that that's kind of the phenomenon that you're looking at right now and the reason and you are intuitively identifying that tension right now. Like I'm doing this thing, it's an experiment. But boy, it seems like a big project. But it has to be a big project because I'm building this, I'm putting this into the world. So the how can we reduce the stakes, right. As it relates to you being able to get meaningful ideas into the world that will that allow the world to be feeding back to you. Right. That can be your. Be your experiment. That's where the gamma thing is interesting to me in terms of being able to do experiment level stuff. It's not the same as a build. And right now I have my portfolio. I've got what I'm doing for learning. I've got what I'm doing for experimenting with. And what I'm doing for right now I'm doing experimentation around augmented reality. I'm doing building around state change assistant. The thing I'm trying to get for next week, I've got the Learning, which is a book that I'm working on. On right. And then teaching, which is me setting up, you know, yet another session. I'm now doing Marketing Mondays in addition to MCP Mastermind. Yes. Everything has apparently m alliteration. I'm not sure what's going on with that. It's like two regular sessions now in State change. Right. So we're more content oriented as opposed to the more office hour stuff. The. The reason I bring all this stuff up is to. It might be a helpful framework for you to think about like what which bucket is this thing going into? Right. And then if what you're looking for is an experiment that you're. The way to get past the perfectionism is through the time discipline. Like all right, I've got two hours at the End of the two hours this thing needs to ship. What could I ship that will feel comfortable at the end of those two hours? Or don't get me wrong, you're always going to be uncomfortable at the end of the two hours when you push that button. But I'm not saying work all two hours and like minute 119 is when you're pushing the button. Right? Like I, I look, my usual thing is like if you want to spend an hour, like what's a 50 minute project? And because it usually takes longer than you think it will and then, but the, but then you have the time to like do the first thing like, I'm kind of proud of that, or have thoughts about that, and then you give yourself and you get the room to tinker, refine, whatever, and that still doesn't grow out of control. So I might ask the question, like, what is it sort of, you know, if you shrink it down. You heard me. Like when you and Mitch were doing the, the session, I said, what can you do in 15 minutes? And the reason I gave 50 minute standard was because someone can say, all right, I will go try the 15 minute thing now. And then they wind up spending an hour on it. Right. It's something you, you, it has different permission structure to it. The. And that's what I would look for here. I think it looks like a beautiful carousel. I suspect it's a lot that's going to be the iceberg that's just under the water. No one's ever going to see it as an experiment. For you, that's fine. But the experimentation, learning part I'm down with. But because it's part of X, it needs to be short timetable on a per effort basis. So how is it that we could be getting pieces of this into the market so that it can be doing its job of teaching you about, you know, the market, what it responds to and what, what gives you that same feeling of pride as well? It's

**Ellie Rofe | 26:11**
A very good question. I think, I think the reason I'm resisting it is because in my head the need in marketing at the moment is of course to be connecting with pain points and to be connecting with the audience and stuff. But the sentiment is that there is a lot of noise, there is a lot of AI slop as the phrase, you know, that people love and just people churning stuff out there that has very low value and feels very blurry. And I think in my head this is maybe something I need to let go of. I'm like, when everyone Else zigs, you zag. If everyone else is obsessively trying to create a carousel in like 20 minutes on Gamma, and they're all going to start looking like those Gamma templates and they're all going to start being quickly pumped out, then you go, no, this is the handcrafted version of this. But I'm aware that that is possibly a belief I am very comfortable in having because it feeds into my perfectionism. So what I'm trying to work out is how to get something of quality out there in terms of marketing when that fast. That's, that's the question. And this is, I think, possibly an issue with the way my brain processes stuff. I think my brain processes things slowly. I pick up ideas fast. I, I can bring ideas in, I can synthesize them quickly in my head, but the time between that and going outwards can be slower, at least to get it in a sense that's clear. When

**Ray Deck @ statechange.ai | 28:26**
I think if, if I might be so bold,

**Ellie Rofe | 28:31**
I've

**Ray Deck @ statechange.ai | 28:31**
Seen you do presentations on marketing topics, you know, and you have afterwards, you know, apologized for having been scattershot about it. And yet my goodness, everybody learned so much from you. The, the, the, the, the distance that you see between your articulation and what the articulation could be is, is very large. And that's a journey that you're going to go on. There's a question of like, how much of the sausage do you show getting made. Right. Of working on those ideas. But my thesis for marketing is that the unit of marketing is the idea, right? So the, the, in the course of a week, you want to ship more ideas and surface more ideas, you know, into the market. Ideas that are worth spreading, like Ted likes to say. Right. And you have a bunch of those, and I get those just by having these conversations with you. Right. And you know, you were, I remember talking to you at NCS back in Paris. Right. And the, you know, the riffing and insights you had, both about staging, but just about your practice. Like, I learned so much from you in a very short period of time. It doesn't take you a long time to be articulating those things. I think that the thing you're having a hard time with is giving yourself the permission to allow those to be exiting and, and, and, and, and going into the world in a slightly broader, slightly broader audience. And the. Of course it's going to be imperfect. You will never be worse at it than you are today. Yes, right. The. But, the but, but you're not Going to be better at it tomorrow if you don't ship it today. Right. Like, it's the whole parable of the pots thing. So I would. Experimentation is fast because it's measured in the number of turns that you take. Right. On those. On the. You know, which then becomes the ideas and lessons you're able to get from it. The. The longer that you spend doing one pot, the longer it is before you are learning its lesson. To be able to. And then be able to apply it into the. The next one. Yeah. And, you know, and the, you know, whatever. I can sort of stop with the analogies at that point. The. I look at like, what, what. What you have and the ideas that you have, and I would love to have those ideas, you know, just in the market. And the experimental question I ask is, how can you get more of your ideas into the market with less effort on your part, you know? Yeah. Without. Without the cost of your dignity. Right. So, like, if you're like, wait, I don't want to be like that. AI Slop perfectly fine. So what. What, what can we do that isn't AI. I gotta tell you, the number one thing that's not AI Slop is video.

**Ellie Rofe | 31:24**
Yeah.

**Ray Deck @ statechange.ai | 31:26**
So you

**Ellie Rofe | 31:26**
Framed

**Ray Deck @ statechange.ai | 31:27**
Like this talking to the camera about the idea that you've been working on, showing one of those slides. Right. As well. I mean, this is where you could do. Be doing something direct to camera like this. You could be using tele. And if you're having a hard time getting going with this. Actually, one of the things I think I'll bring up in the Mastermind is how I think that all of you have really, really good ideas and you're not shipping nearly enough of them into the market. And like, I was looking at Demetrius stuff. Demetrius is shipping every day into the market and he is disappointed with the results he's getting. I looked at what he's shipping, and the problem is he's shipping. He's not shipping. AI Slope. Everything he's writing is, you know, artisanal, you know, but he's like, upset that it's not producing. Why is it not producing? Right. It's what we looked at our coaching session was earlier today. And you can look at his stuff too. Like, there's no super secret about this. Just like, what's in Public Domain. And he. And like, my conclusion is, like, I looked at his last 30 things and there are only two or three of them that really jumped out at me. And they all had one thing in common. You saw him and the ability to make that connection was really a big deal. Now that is intrinsic to his practice. Right. He and Robert both have. Practices are very much about being live on camera with the customer and being able to charge more on a per hour basis as a result of providing that high value. So part of it was giving people the preview of what would be like to work with them. And I thought that mattered. But the other thing was there's no AI that produce a picture of Demetrius. Right. And lots of AI that would produce content that would look kind of like what he was writing as he was trying to figure out how to write something that he thought the audience wanted. Right. He was kind of simulating what the AI would do as a result. So the, that's the reason I bring up the video thing. Right. Like if there's a significant potential for that to be something that can really allow you to show something, allow you to show something that's imperfect because you're not presenting it as a done thing. And it has the great benefit of being something AI could never do and is. And the final thing that's really key about it is you can do a three minute video in three minutes. Well, yeah. The thing is the hard part of doing the video isn't about like the post production or any of that stuff. It's about just, just starting it and the, the, the when you are. And this where like, I think a little bit of like mutual accountability stuff can help. Like if you have somebody who's sort of, you know, encouraging you to be doing it and then you put on the teller and you're moving that together, then you get the win. Like my, my thinking is that like if, if you were to be spending an hour with, I don't know, Demetrius, Robert, whatever, right. And each of you were to have shipped one 3 minute video, you'd be so much further along. That'd be a great use of your hour compared to, you know, most other things. It's not like you need to have an hour of video in the can at the end of that. Right. Your problem right now is getting anything in the first place. Anyway. Why am I bringing this up? I'm bringing this up because it is an example of a different experiment you could run related to how you can be putting ideas into the market that you can be proud of. Right. And that aren't requiring that same level of time because perfectionism can turn into an excuse for inaction. Right. And the, and, and I don't think it's ever what we mean to do, but it Often turns out that way, right? And it's like, a week later, how much have I shipped? I haven't shipped anything. Why haven't I shipped anything? It's because I want to make sure this is going to be good. Well, is it good enough? It's not quite good enough. Here's the other imperfection I found. You're going to keep on finding those, right? Even when you ship something to the client, there's gonna be imperfections at the end, right? Because you had to work on that time schedule or whatever. But the, but, but when you're doing client work, client work can be slow because they, they're paying you to be slow, to be really producing something that's very careful at the end. But the, the, the right now where you are is you need to be, if you will, learning how to market your marketing, right? Because you're trying to figure out like what works in the market. In order to do that, you need to get more, more of these things shipped. And that's why I talk about experimentation needing to be a quicker thing. And if showing your direct work product as like for example, a carousel, like, hey, these are slides that I made. If you're like, I don't know, I'm sort of holding back on that. A video where you show the slides that you're working on, right. Can be a way to give yourself permission to show that in a way that gives it to the customer and is giving them more you in the process. That could be just sort of a win, win you having a, you know, if not a carousel, then how about just a shot of like one of them? Right? Sure, they, they go in a sequence, right? But like this is part of a sequence that becomes like something of interest that can be pulling them in. You could have a carousel that's just like a few of them. You could have a carousel that is including shots of them, but actually is not them themselves. Right. And this is just me trying to spin ideas like how you could give yourself a little bit of permission to do something that. Showing more work in progress, Work in progress. Or at least using that as a, hey, this is a beta or whatever, but giving people the opportunity to see you, your ideas, your methods and action. But that's why I talk about experiment needs to be quicker. And the, the, the, the, the, the. I think there, there's a, a danger of saying, of, of saying, well, I'm a perfectionist and it's going to take a while. Okay, fine. That perfectionism might be great when you're shipping, but it's not great when you're selling. So

**Ellie Rofe | 37:21**
How can

**Ray Deck @ statechange.ai | 37:21**
We, what could we ship that would be earlier? And this is where you know, some of those ideas. But just maybe putting in from someone else and says, hey, and maybe using that kind of signal for, let's put that into the market. I know there's gonna be like, how you feel about these things, but the more I think about, the more I think that like, you putting in front of someone else and getting someone else to be giving you that shove would be really useful. And like you, I think you might have an easier time showing off some of that working product behind closed doors like that, that, that, the, the, that multi, multi page Photoshop thing that you were just showing me. I think you show like you could take like a screenshot, you could like do a, you know, a region screenshot of like a few of those and you'd have something to talk about.

**Ellie Rofe | 38:14**
Yeah. And

**Ray Deck @ statechange.ai | 38:17**
I think that you have something to talk about that'd be marvelous, that would educate the world, that would bring value to, to other folks and be giving a great, you know, case study and what it's like to work with you. Because this is, this is how you think about this stuff.

**Ellie Rofe | 38:30**
Yeah. Well the irony is, I mean, and this is where I could just say, like, the irony is I help other people do this, which is part of the reason I'm so horrible at doing it for myself. So, like, the, the opportunity of going, here's a screenshot of what I'm working on. And I spent way too long on this because I'm too close to this and I'm in the weeds. I need a version of me to help me with it, basically to help me with these things, like

**Ray Deck @ statechange.ai | 39:03**
Just,

**Ellie Rofe | 39:03**
I feel your pain. I do understand how difficult it is to put your ideas out into the world because I find it difficult. Like there is, there is value even in that, even in the meta posting.

**Ray Deck @ statechange.ai | 39:17**
I think, yeah, you're just looking for the permission. And I think part of what you need is the permission and the encouragement. Because when you're sitting alone in the dark and trying to decide whether or not you're going to push that button, all the negative thoughts come out, Right? And some of those negative thoughts have been super positive in terms of helping you, you know, think more carefully and cleanly about, like, how the stuff works and make sure the quality goes. But some of them are just holding you back. And like, when you have the additional thing with the client, I think that that becomes the Pusher to get out. When it's just you and the button, it, the, the. It can be a bigger burden. And that's the reason why I'm sort of, you know, saying, having someone.

**Ellie Rofe | 40:01**
Yeah, I've definitely got better in terms of. I've been posting things, making comments and stuff and not overthinking them. So I think there's. There is an element of that in me, but that I think with this part of that element is that like you do when you do something that is this. Like, it's the same as someone saying, I can help with your social media. And then you go and look at them and they've got 20 followers and no engagement and like. Or saying, I'll help you with your SEO. And they don't rank in the first page for anything. Right. That there is an element there where, if there is a sense of having to put your best foot forward when you're producing something like this. But I think I, Yeah, I'm probably still massively overthinking it. I think partly is because I think a big part of what I end up doing is trying to. I think you said this when you were like, which bit of this presentation is really important? Because I have a habit of everything just being connected. Like systems thinking, systems thinking, brain just going in overload and then everything is connected. Yeah. And then trying to put too much into stuff and trying to like, go, but this all but this, all but this. And I know that that is. I'm not alone in that because that's what all my clients do as well. So I think partly it's me having to rein that in and step back. And maybe that's where. That's where it's like, right, so in two hours, which bit of this whole big system, how can I isolate it? How can I find one part and talk about that in a way that's meaningful without worrying about every other bastard piece of it?

**Ray Deck @ statechange.ai | 41:56**
And I think you just put your finger on it, talk about it, right? The thing about the carousel idea is it makes the work product, the, the marketing piece, right? That's the thing they're going to go read. When I actually think your criticism is far more interesting, right. You're like, well, when I say criticism, I mean like, you know, a discussion of it, right? And the like, if it's your own work, well, then you can be discussing, hey, this is the right thing. Actually, I was thinking about this relative to. As you were going through this, I was thinking about this relative to the AI slap and Thinking, you know, I, of course just going harshly on someone else's work is a bad look. But having Gamma go make something and then not use it as like your own stuff, but say, look, this is the problem with using AI stuff, right? I made a prompt, I put it into Gamma and it made something that kind of looks replacement level, right? But let's talk about like where the, where the story points, you know, need to be and like what the, what the challenges are. This is then you like getting to talk and use your critic brain on it, right? And like this is the three ways you probably make a change that would then, you know, improve on it. And then maybe what that's doing is then getting them to go back to the AI to be, you know, using prompts to be improving things. But that might be exactly the right thing to do. You're not necessarily going out there saying the only way to do it is your particular artisanal method, right? You're saying there are certain principles of what you've discovered are really important and then the application of those principles are where you continue to be innovating and you know, creative. But, but all of which is by way of saying that like the, it seems like the real thing to be marketing here isn't, is, isn't. I mean, if you're market, if you're running a carousel or anything else, the thing you're marketing is always you. So how can it be your idea that you're putting into the, the market and, and, and that's where you'd be looking for something, you know, a little quicker. Like you did that whole studying thing to sort of, hey, this is what I think a good slide presentation looks like. Great. Let's take a piece of it and have a conversation about it. Let's take another piece, have a conversation about it. Maybe you eventually have a, I'm going to ship it all, put that into the market. Great, you can do that too. That, that becomes like another piece that is low marginal cost over the rest. But, but either way, like, you know, the I, you know, you're, you're, you're a professional, you take a certain amount of professional pride in what you do. And I would just say that you are, you, you, you, you deserve that professional pride. I think what you do is really good and I want you to, I, I would hope that you share more of that with the world.

**Ellie Rofe | 44:39**
Yeah, okay, that's useful. I'm gonna try and do, I mean, I, I, I don't have work coming in, so, you know, I need to just, it's just as well for me to have spent by the time we speak next week for me to have done five two hour experiments and worked out what I can get out than to have just spent another 10 hours on a carousel. So, yeah, okay.

**Ray Deck @ statechange.ai | 45:04**
The. And I would propose reaching out to, you know, Robert and you know, you got both their emails. If you don't have it any other way, you certainly have it through the Mastermind scheduling. I propose, like, whoever it is you would want to have that conversation with, like, do, do, do like a session where you're sort of, you know, using that to see if you can sort of sort of help be an unlock. Right. Like it's easier to say, okay, I'm not going to be recording a video, he's recording a video. You, you can do this whole thing in zoom and bring up whatever else you want to do for recording. Right. Those two are sort of allowed to be there side by side. I, I find that having someone to talk to as I'm doing this can make it feel like a more human, you know, experience. And the other person can get you hepped up and that can be, that can be really useful. I find this a lot easier to do these things on camera when my heart rate's a little bit more up. Especially one of the reasons I was, I discovered that's one of the secrets to the, the chairlift stuff. Right. The reason why it was easier for me to do the things on the chairlift is because I just come off of know, a big piece of exercise. Yeah. And that was, it was helpful for just getting, getting something out the door,

**Ellie Rofe | 46:18**
Trying to get it. I'm, I'm better standing after. I've just done a bit of, of pumping up.

**Ray Deck @ statechange.ai | 46:24**
Yeah.

**Ellie Rofe | 46:24**
Yeah.

**Ray Deck @ statechange.ai | 46:25**
And, and then like, you know, and none of this trying to make it perfect, but just say like the, I have found that it's a lot easier to do something that I'm sort of more resident to do. Like, it was the thing that got me back going to the gym was playing squash. And I think that the big thing wasn't like intrinsic to the sport. It was the fact there was somebody waiting for me.

**Ellie Rofe | 46:45**
Yeah. Yeah.

**Ray Deck @ statechange.ai | 46:51**
I think that activation energy is how you take something that's slow sort of into build mode and is inappropriately in build mode. Because build mode is you exploiting lessons you took from experiment, but you haven't learned those lessons yet. Right. But now that you have this asset that you've been building in build mode, can you rip out pieces to be turning that turn, turning that learning flywheel. And then I really think the more you do this, you're going to, in a relatively short period of time, go from just doing more things to doing better things.

**Ellie Rofe | 47:27**
Yes. Yeah, absolutely. Get reps in. That's definitely the way forward. Okay, so five or six two hour experiments by next week, next time we speak. Sounds good.

**Ray Deck @ statechange.ai | 47:39**
I think that'd be awesome. And is there a way that I can be helpful to you on that front between now and then?

**Ellie Rofe | 47:51**
No, I think you've. I think you've really helped. I think this is like. I think it's a question of reframing and I think I just need to take a deep breath and do that, reframe, you know, rather than just go, but, but, but I just go, what have I got to lose? Absolutely nothing. So let's just go for it.

**Ray Deck @ statechange.ai | 48:10**
Sure. If what you want for one of those experiments is to, you know, have me around, because that would be something that would be helpful to you. You have my VIP calendar? Yes,

**Ellie Rofe | 48:22**
Yes. Okay.

**Ray Deck @ statechange.ai | 48:25**
Don't be hesitating to book me for that. My North Star is. I want you to make the progress you want to make heading into next week, not to be minimizing my time investment on it. So if as you look at it, you're like, wait, hey, I meant to do that yesterday. I didn't quite get to that. And you think it could be made more helpful through me being even just me being present. Right. Like, you don't have a particular thing for me. It's just a. But so I don't have to stare at myself on the camera. That's fine. I'm glad to be there, you know, for you on that. I think the earlier return that wheel for you, the, you know, the more profit you're gonna see.

**Ellie Rofe | 49:03**
Just remembered I've got an annual Focus Mate thing as well,

**Ray Deck @ statechange.ai | 49:08**
Like

**Ellie Rofe | 49:09**
Accountability. So I just need to say, right, I'm gonna get on there and in like 40 minutes, I will. 50 minutes, I will do something like, I'll record a video.

**Ray Deck @ statechange.ai | 49:19**
Fantastic. If you wouldn't mind, I'd like to make that an agenda item for our time next week. Is like, what you're. You know how you are getting profit from Focus Mate? Because that sounds like a. I've heard of not used it. And I'd love to see how you're making that work for your practice.

**Ellie Rofe | 49:35**
Yeah. Okay. Well, I haven't been using it for a while, but I will get back to it and then let you all know.

**Ray Deck @ statechange.ai | 49:40**
All right. Fair enough. Great. Have a great rest of. So I would appreciate if you could do the report from this week at your. The. If you. And then I hope you have a wonderful weekend and we'll be. And if we don't talk before, we'll talk on Tuesday. And

**Ellie Rofe | 50:01**
I came onto this in such a fluster that I forgot to say Happy 4th of July. Happy independence from Ocelot Day. It's very important. Congratulations.

**Ray Deck @ statechange.ai | 50:15**
And I'm from. I'm from Boston as well, so sort of a. A big, big deal for us. And if I recall, like next. Yeah. Next year is 250.

**Ellie Rofe | 50:26**
Really? Wow. Okay. I was once in New York for July 4th and I did consider dressing up like George III and just sort of wandering around and trying to beat people with a stick or something, but I decided that might not be such a good idea.

**Ray Deck @ statechange.ai | 50:44**
I. I think you made the right decision. Yeah. Yeah,

**Ellie Rofe | 50:49**
Probably.

**Ray Deck @ statechange.ai | 50:49**
It was wonderful game. Talk to you. We'll talk in Tuesday. Take care.

**Ellie Rofe | 50:52**
Have a lovely weekend. Cheers.

