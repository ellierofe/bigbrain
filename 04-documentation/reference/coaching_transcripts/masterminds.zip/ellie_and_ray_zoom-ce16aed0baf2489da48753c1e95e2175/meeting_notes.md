# Ellie and Ray Zoom - Jul, 04

## Key Points
- Technical difficulties with audio settings were discussed, focusing on resolving echo issues due to misaligned microphone and speaker settings. 
- Ray shared his use of software like Backtrack and Rewind for automatic recording and backup, emphasizing the value of data collection and analysis. 
- Ray detailed his process of using voice memos and AI for transcribing and summarizing ideas, highlighting the benefits of capturing and refining thoughts efficiently. 
- Ellie shared her use of AI for feedback on presentations and idea development, noting the importance of a sassily critical tone for effective responses. 
- Ray introduced his framework of learn, experiment, build, and teach, advising Ellie to focus on quick experiments to reduce perfectionism and increase idea output. 
- Ray encouraged Ellie to use video as a medium for sharing her ideas, arguing that it can bypass AI slop and connect more personally with her audience. 
- Ellie and Ray discussed the value of sharing work-in-progress to overcome perfectionism and gain feedback, suggesting Ellie collaborate with others for mutual accountability. 
- Ray proposed Ellie conduct several two-hour experiments to test and refine her ideas, emphasizing the importance of quick iterations and learning from the process. 
- Ellie committed to conducting five or six two-hour experiments by the next meeting, aiming to reframe her approach and reduce overthinking. 


## Action Items
- **Ellie to complete the weekly report from the current week.** - _Ellie Rofe_
- **Ellie to prepare to discuss how she gets profit from Focus Mate during the next meeting with Ray on Tuesday.** - _Ellie Rofe_
- **Ellie to set up a reminder in Notion to complete her weekly review document the day before their scheduled meetings.** - _Ellie Rofe_
- **Ellie to record a video using Focus Mate as an accountability tool.** - _Ellie Rofe_
- **Ellie to finish the carousel presentation today and post it on LinkedIn tomorrow morning.** - _Ellie Rofe_
- **Ellie to reach out to Robert via email to schedule a collaborative session that could help unlock her content creation process.** - _Ellie Rofe_
- **Ellie to work out additional posts, videos, and other content based on the carousel presentation to trial it as a piece of IP that summarizes her work.** - _Ellie Rofe_
- **Ellie to complete five two-hour marketing experiments by next week's meeting with Ray.** - _Ellie Rofe_



