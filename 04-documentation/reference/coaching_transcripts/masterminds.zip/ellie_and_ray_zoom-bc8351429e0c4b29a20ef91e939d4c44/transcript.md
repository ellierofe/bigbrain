# Ellie and Ray Zoom - Sep, 12

# Transcript
**Ellie Rofe | 00:06**
Hello, excuse the absolute state of me. I got the hour wrong because I've changed time zones and I've just woken up from a nap as I'm a bit poorly, obviously because I've traveled [Laughter] scuse the absolute state.

**Ray | 00:21**
Welcome to the United Kingdom.

**Ellie Rofe | 00:23**
[Laughter] Thank you. 
Yeah, great work. How are you?

**Ray | 00:32**
I am well, I gotta say maybe doing a little bit better. You seeing low coffee? Are you? I mean, in addition to the npper, are you feeling well? Are you sure?

**Ellie Rofe | 00:40**
No, that's why I was napping. I feel dreadful, I have a sort of fluy thing.

**Ray | 00:47**
I'm so sorry about that. And of course, I don't really have a an update from last week. 
So we don't need to use if you could sort of maybe just sort of fill in the brief at a time of your convenience this weekend to be, you know, great.

**Ellie Rofe | 00:52**
God, I'm sorry again. I forgot that.

**Ray | 01:04**
And we don't need to make this into the full hour, like the purpose is to try to help accelerate your week, not to cause you to suffer for an extra hour on a Friday. 
So. You know. I suppose I come in not really knowing much about your week. I do know you've got the. We have the mastermind we can put to work for you next week or this coming week, because that's your turn. 
But I guess I would just ask a question. How can I be of service to you today? Like, there was this new, you know, the new, you know, your marketing SLA digital twin consulting brand coming in.

**Ellie Rofe | 01:37**
Yeah.

**Ray | 01:40**
You know, let me just sort of, you know, throw open the door. How? How? How can we put this to work in a way that's going to create value from you and not cause you to suffer through the cold? The earth going suffering? Enough.

**Ellie Rofe | 01:51**
Okay. I had, a bit of a well, not an epiphany. It's the thing that's been bothering me for a while, but I keep kind of like trying to, ignore it. And I don't think it's working, which is that I as the digital twin thing and the, you know, the brand strategy side of things as that friend popped back up and was like, can you help me? I was just so much more excited about it than working in biotech.

**Ray | 02:28**
Eight.

**Ellie Rofe | 02:28**
And I wonder whether this is a case of the question I keep asking myself is this time for stoicism rather than, you know, not hedonism as such? But there is obviously. 
Like I was thinking the reason I left working in biotech before was just because I've been burnt out and I've been sucked into this business too much. This like this startup thing and it wasn't a natural affinity for me. 
It is I like I enjoy the science, but I'm not a scientist. And that is a block at times with people. They can be very much like when Max, for example, has been introducing these people, they've all said, Max told me you're not a scientist. 
Like that's the first thing that's clearly going on here, which is fine. Like, I don't care. There's people who want scientists who work in biotech. That's possible. But I'm not a scientist, and it's for many reasons, and one of them is that environment is not ideal for me in certain ways. 
So I just keep wondering. I don't. I don't feel enlivened. When I get off the phone from people working in this industry, I'll just like, they were nice. That's fine. I don't feel buzzing with ideas and stuff, but I think that's going to be the case at some point in everything I do, so should I. Is it just a time for stoicism and crack on? Or am I thinking of this as like a bank rade where I'm like, okay for the next six months or so, I just try and get as many referrals and get as much money as I can in this to get my cash flow up and running and then basically pivot or have like be building other stuff alongside it? I don't know. I just feel very uninspired. I'm struggling to make content because I don't know really what to talk about, because I feel like I can't talk with authority about the industry itself because I don't have authority on the industry itself or the kind of entire flow of it and the ins and outs of it. 
And I can't get in touch with VCS, so it's very difficult for me to talk from the point of view of a VC I can talk from the view of a founder, and I can talk in a limited sense about DEX, but it just I just feel like it's just not very interesting. I'm not inspired by the content I write, and I feel like that's probably going to keep reflecting itself. 
So I'm wondering whether I just do direct outreach networking and then look to over the next six months go right. I pivot to brand strategy and. And, you know, work on that side of things. I don't know. I don't know.

**Ray | 05:43**
Well, when we talk about stoicism is not stcuiveness. Stoicism is identifying the difference between things you can control and things that you can't, right? 
And the. And, you know, it's funny. I was just two of the books I found to be most interesting from a, you know, behavioral economics decision theory point of view in the course of the last year that I read. One was actually was a book by from the RAND Corporation. It was a book they wrote for the CIA because it got know about part of a whole bunch of declassifications. 
And, you know, I fed it into eleven Labs reader and sort of turned it into an Audibo was pretty good. It's called strategic surrender. And so the idea is like, under what circumstances is it rational to be saying, okay, we need to be laying down our arms versus, you know, fighting on basically the, you know, sure, Winston Churchill was, you know, as is a hero for his stickuness, but that's not necessarily the correct move in all circumstances, right? The idea like, you know, really asking the question like, was it right for the French to lay down their arms? It was like one of the four examples they use the. In a second book I read, just more recent. I don't know if you read any of any Duke's books. She's a poker player.

**Ellie Rofe | 06:57**
No.

**Ray | 06:58**
She's a poker player who has written a few books on, decision theory, including one called thinking and Bets, which is the most popular. 
And like one of the following books called Quitting, which is about, you know, just and this is where, like, you know, Steve Pressman's War of Art kicks in my brain because he talks a lot about the difference between stopping and quitting, right? 
And when she says quitting, what she really means to stopping like the notion of like, you know when you're a poker player, the being goaded into sticking through the hand to the end is a great way to lose your stack, right? 
And understanding you know when you should be bailing because the other guys got it and. But that's the hand that's not the game, and sometimes you walk away from the game because it's just a game. It's not the career, it's not the week in Vegas, right? 
It's like, okay, this is the game, this game. I'm on tilt, I'm I need to just go sleep. I go sleep. I'll become better, but that means I don't get to play that game anymore. I would just go to the next one, but in the meantime've preserved my stack for that, you know? 
So the reason I bring all this stuff up is that I think it's very healthy to look at the world and say, what should I stop? Right? Don't just keep doing what you're doing because it's what you were doing yesterday and you think you can stick with it, right? I don't think you particularly lack stick to itiveness. There is a but. 
But one of the reasons I talk in terms of study, cell and ship is that each of these things has a job to be done, right? And like the point of doing shipping work isn't that you should just be grinding to ship. 
It's like, no, shipping works is successful when it makes you money. Selling works successful when it's producing leads and customers that you can ship to. And studying work is successful. 1, it gives you insight and the and if what you're getting is an insight of, you know, one, where you get joy, but second, where the market is looking wants to hire you, then that's good insight. 
That's good market insight for you to have. So the as I think about what you're describing, the way I thought about the biotech thing was not that biotech was there because it was, you know, the thing that you found to be absolutely most exciting, a thing where we had a pre existing reputation, right? 
And frankly, the work is intellectually interesting because it's hard, right? You're building a bridge between these finance people and these weird technical people. And you are the whisperer who's able to help go from the weird ideas in their head to, you know, getting them expressed in terms of financial value. I forget who I said about this recently, but I said, like, you know, this person was a magnificent salesman. 
And then their company died for lack of sales. And they were magnificent salesmen because they were able to get 5 million dollars raised for their company. They sold their stock for a ridiculous amount of money. They're good at high end sales. When it was, you know, raising money, you know, from the investors because that's what they're doing, they're selling their stock. 
And that's why, as a marketing professional, you come in like. This is why investor relations and marketing are so tightly interwound because you're selling that stuff and trying to keep up the value of that stock. 
And that's, I really like the whole IR aspect of Mr of IR as high as super high end marketing. And that spin on your business has been the thing that sort of in my head was sort of pretty cool about it. That you are a marketing professional applying it in the high end game and helping build a pretty long bridge between people who have a valuable asset they can't quite monetize and being able to connect that to the way they monetize it, which is, you know, raising the money, being able to sell the interest in the company. 
And when you've got an idea that is what you can sell is equity interest, right? Proxation is a whole different story. So when I hear your tale and what you're talking about, like, hey, they are the broader brand strategy, what have you. I actually don't think these things are in conflict with each other. 
I think they're just playing the game at different, you know, at different levels and having some different angles to them. And the question I have is what has that good intersect of a market that's more receptive and ready to buy from you, right? 
And that is creating. And that sort of is creating the room for you to build out equity value, right? So that you are your business looks better tomorrow than it does today. So one of the reasons for like that whole, you know, let's go interview investors and let's do some research on that, right? Is to it's is to build you up so that you can be, you know, stronger in that domain. 
But I got to say, the fact that you did that work, you're going to be able to now go talk about hard things with everybody else in the market because you're now at the sharp end of the stick, not just specifically about biotech, but like, yeah, this actually reminds me of thing I learned in biotech. 
And now what you're doing is you're bringing something from a hard domain back to them, which will create value outside of that domain. And you can be asking. All right, well, I've done a bunch of that studying, and, you know, and you're now seeing diminishing returns or if you are seeing diminishing returns, then it's like, okay, what's the next thing to be studying? That will produce more returns for you and the. 
And similarly with sales and then the question like which then who wants to buy from you? I don't think it's a matter of a hard pivot now versus six months from now. I think it's you asking kind of on a continual basis what market want to buy and what does it buy specifically, does it want to buy for me? 
And then you can be selling that and they can be getting value from that. And now you're turning a value and reputation wheel that's moving you in the right direction. And when you go talk to those, you know, the VCS or the biotech people like, yeah, why I can squeeze you in. 
And now you're more likely to be making that sale. And when it's you know, when you're talking to someone who's like not in biotech, for example, just if you were like marketing yourself particularly to biotech, which right now my CPUT doesn't really right, sort of just broader marketing. 
But if you were to position yourself more as a specialist. I think you'll find people say, I found you to be really impressive. Do you do work with my thing? Kind of like what your friend just did, right? 
Because the high end, more specialist work you do builds reputation in a way that just being in generalist does not. So there's a little bit of like epic alane partially just to be communicating to the market that you're not just another duffer, you're thinking about this in a sharper way.

**Ellie Rofe | 13:17**
2.

**Ray | 13:28**
I was earlier today, I was having my coaching call with Deetris, and I was and he actually has been having some good success in the course of the last week. Getting a lot more businesses. 
But it's not all digital twin business. Like, that's fantastic. It's okay, it's not a digital twin business. What you want to be doing is doing even more marketing, the digital twin stuff, because people are going to say, wait, you not only know this tech, you have a thesis of what you can do with it. That creates real value and that' going to make people both want the specific thing you're offering the digital print stuff, but the, you know, step back and say but I have a need that's not quite that. Does it still fit? 
And they will book the calls, which is exactly the phenomenons happening to him right now. All of which is by way of saying that, like, I don't think you need to be tied right to the idea like, you just do pitch decks for biotech. 
It's, you know, it's both bigger than that in the world of biotech. It's bigger than that in the world of VC and it's bigger than that in the world of marketing. You get like three angles you get to work here and it's just whatever is going to be producing that combination of remuneration and remuneration intellectual satisfaction and joy for you, right? Which is a word I'm brought into a couple of our previous conversations. 
And if you're like, this is a grind and I hate it. All right, well, let's not do it. Let's figure out something else you don't hate. And because you are a smart person who can create a lot of value for these companies and the. 
And I would rather be doing it in a way that is, you know, giving you energy rather than taking it away as you're working through it. Now, you've got a cold right now, you're feeling awful. This will have an emotional consequence, you know? 
So like the this is like, you know, again, Anyie Duke talking about quitting, saying just go get a night of sleep, right? The that is the level of quitting that she does advocate for on a very regular basis. 
And then there are like bigger levels of like, you know, what are the, hey, you have a goal?

**Ellie Rofe | 15:23**
But.

**Ray | 15:27**
But like, is the, you know, she talked about the idea of having a quitting coach, right? Having someone who's saying, is this still the thing you really wanted? We're sort of thinking about it at a bigger level, but, you know, I don't want to confuse those two things. I don't, like, have a conversation about, like, leaving this domain when you're just sort of feeling shay today, right? 
But I've been hearing a little bit of this from you, so. And the fact that you've got opportunities coming in there sort of outside the domain. I don't want you to be turning those away because think. 
But I should be doing this over here.

**Ellie Rofe | 15:57**
No.

**Ray | 15:58**
There's at least I can think of one company right now who is just saying, well, we're not going to do that stuff over there. That could make us money because we're focused on the way he put the term he used with me is we're fixing the hole in the bucket, right?

**Ellie Rofe | 16:11**
Right. Okay. That sounds inspiring.

**Ray | 16:18**
Exactly. 
Right. And the and as I thought about, like, the metaphor. I realized that the problem is not that he has a hole in his bucket. The problem is he's taking his bucket over to the lake bed. You know, the over to lake to, you know, pull the water. 
And then he's bringing it back home. He's wondering why there's no water in the bucket.

**Ellie Rofe | 16:35**
Yeah.

**Ray | 16:35**
The reason is there's no more water in the lake. The market moved. And he's like. But there must be something wrong with the bucket.

**Ellie Rofe | 16:43**
[Laughter] I suppose this is where I was thinking of biotech in particular, because I do have contacts there more than any other industry in some level, like, because my history has been so fractured.

**Ray | 17:00**
Two.

**Ellie Rofe | 17:05**
The area I have most contacts is finance, but it's equity research and M&A stuff. 
And it's all of their Deckt work is shipped out outsourced to India. So that market isn't there for doing that work here.

**Ray | 17:19**
You're not for doing deck workk at least.

**Ellie Rofe | 17:22**
And, I've done some marketing and comms work with these companies. They're not big into strategy and brand like they're it's a very different beast or it has been. 
And so I hadn't realized how different the environment was in Biote Biotech. I think that's been part of the issue. I think I said, Jo, I spoke with someone who felt that an awful lot of the CEOs she's working with at the moment are people who got funding in the boom and they don't really know what they're doing. 
And? And so they're. They're fractious, they're difficult to work with. They're doing things like disappearing for months on end. So I didn't think it would be ready money, but I thought there would be more opportunity than I'm finding at the moment. 
And I still think there's AI still think there's a possibility of just going and like doing the like emailing the opportunity the option to get the pitch deck analysis done for people and just see what that brings back because that's a different route in as well. 
I think I don't want to just prematurely go this isn't right just because I'm coming up against obstacles or feeling crappy. But one of the reasons I was worried about the brand strategy side of things, that kind of stuff and the digital twin stuff. 
Like I'm impressed with Demetris because it just feels like such a saturated market already. It feels like everyone's talking about that, but maybe that's just in the corner of the world I'm in. That's what loads of people are talking about. 
So, yeah, I don't know, I think I just. I felt like it was gonna be harder to differentiate there, but instead, I'm finding it. You know, like I. I'm not highly differentiated in. In the biotech. Other than, like, not being a scientist.

**Ray | 19:24**
Right? Differentiation is local, not global, right? It's like, what is the environment you're in, right? In which people know I trust you, right? And what are they ready to buy from you, right? 
And like, you know, the, you know, that lots of people have, you know, can make a hot dog cart, right? But if what you are is you're standing next to a crowd of people who are really hungry, and you're like saying, hey, who wants a nice ice cold Coca Cola? 
And they're like, we don't want ice cold Coca Cola. Because you know what we really want is. We were here. But what I want to sell you is so cool. And what we need to is just bring over the hot dog cart, right? 
And the fact that a hot dog cart doesn't feel very differentiated isn't important. What's important is you're connecting it to the crowd, right? And that your observation that wait, there's an opportunity here to be making this connection is a differentiate. There's the insight, you know, and the, you know, when you talk about, like, digital twin stuff.

**Ellie Rofe | 20:21**
No.

**Ray | 20:24**
Gang talked about it is kind of off and on. 
Like I can go have conversations with 50 people and I'll be telling them what a digital twin is forty nine times the fact that it sort of feels like there's a lot of stuff sort of buzzing underneath.

**Ellie Rofe | 20:33**
Right.

**Ray | 20:40**
It's a little bit like agents. I was just talking with the VP of marketing over at Xano, right? Xano has made this big pitch. We're gonna be the agentic backend and like, number of sales are made with that is zero, right?

**Ellie Rofe | 20:51**
Right?

**Ray | 20:51**
It's just gone awe and the, it's like but what's you know, I keep on reading everybody's doing agents like, yeah, sure, but lot lots of people are sort of talking the talk, right? Who's walking the walk, do you know how? 
I mean, and I actually suggested to him that like, you know, taking more of an educational approach. What is an agent? How do you do these things? And of course, they have no fucking idea, right? What they have is just a bit of technology. They're hoping that they can sort of clop onto a trend.

**Ellie Rofe | 21:18**
Yeah.

**Ray | 21:20**
So the I think that the digital twin stuff, I think all this AI stuff has this quality to it. On the business side, I was like, even in the world of dev tools, could I just ran the AI Mastermind yesterday for a change.

**Ellie Rofe | 21:26**
It does. One.

**Ray | 21:34**
I'm not breaking into two. We're going to have two AI masterminds. One's can we build for AI once we built with AI because the kind of I've morched and build for AI but the there's big demand for build with it even among people who are like looking at developer tools, which is like yeah, there's a lot of market for that. 
It's a really, it's a fractured market. And the amount of adoption is a lot less. You might think based on the level of the discourse people are looking for. Who can I trust in this?

**Ellie Rofe | 21:59**
Yeah.

**Ray | 21:59**
So I you feel like, hey, this is where everybody's talking about this. Why would they ever want to buy it for me? People who have trust in you will want to buy professional services from you, right? 
And the job of like the you know, the social media posting or thought leadership or suff or what have you, it's really to get people who almost already trust you to trust you and people who almost already trust you to move to almost trust, right, the sort of moving them along the pipe. 
It is not the case that somebody who's never met you is then going to turn around and hire you for $10000. So that's. That's too far a leap. So the question is, like, what topics interest you that you then can make them smarter about? 
That's the Vaynerchuck thing, right? That's the just blre ends on Marri Cha. Just, you know, you go out, you share your ideas that will help them make better decisions and succeed more in the market. 
And then because frankly, ideas are easier to think about than they are to execute on. That leads you to the work of helping them, you know, execute on that. And if you're talking about the things that your friends, people who know, like trust you are already almost looking to hire you to do, and then you're showing. Wait. You like me because of my character? 
And now I'm demonstrating this area of competence. That is in the domain that you care about, it takes over. So that's why the hot dog cart analogy kind of works, because you don't need to be selling them some very specific, weird kind of food. You just need to be the bridge to the food that you know they need, and I think that's perfectly okay.

**Ellie Rofe | 23:36**
Okay.

**Ray | 23:40**
You ever seen mean girls?

**Ellie Rofe | 23:42**
Yeah. A long time ago.

**Ray | 23:44**
Okay, there. There's one recurring gag where, like a member of the. One of the mean girls is trying to make. Is trying to catch phrase you don't to make fetch happen, you know?

**Ellie Rofe | 23:55**
Trapping Gretchen. [Laughter] Yeah, [Laughter] okay. So in terms of sort of next hour thinking, just cause my head's bit fuzzy partly sleep. Partly though, I feel like there's a curiosity itch in me to just say, right, let's put this pitch deck analysis tool out there directly to people, see what that gets back and then maybe start talking more about how I'm using AI in strategy and with pitch deex and stuff and think about that.

**Ray | 24:29**
Yeah.

**Ellie Rofe | 24:45**
Yeah.

**Ray | 24:46**
I you know, I've said before, and I'll say again, I thought those workshops you did in state change or you walk them through. All right, all you need to have is a Claude account, and we're going to do the XY and Z. 
And I don't know if, like, Claude free terms would lie to projects. Like if you can sort of do it without.

**Ellie Rofe | 25:03**
Un. Fortunately.

**Ray | 25:05**
Okay, well, then, whatever it turns out to be, if it just has Claude or whatever, you could. 
I think that's a wonderful workshop to do. I think you could do it. You know, you can sort of offer it as, say, hey, these are things I've learned. And by the way, I'm gonna do this workshop, and it's gonna be fun. 
And by the way, if you schedule, I'll show up and the. And you can, you know, walk people through it. You know, I thought the way that you did it within state change was really great. It was credibility building. It was to an audience of people that aren't ready to buy that kind of professional service, right? 
But I think you can be probably initially maybe doing people not doing that so much, but you record it all and it's content for you, right? It's clips, the whole thing, whatever you want. I'm a big fan of. 
I think you've been doing a lot of, you know, LinkedIn stuff. I think YouTube is way up there too ands of a way of even on business side like the you know I. BM Even MCKINSEY, they do wonderful, you know, YouTube content and the sort of the serious people are looking for that to get a feeling of like what it would be like to work with you.

**Ellie Rofe | 26:03**
No.

**Ray | 26:08**
And of course, that since you're more remote, that would be the way it works anyway.

**Ellie Rofe | 26:12**
No.

**Ray | 26:12**
So, you know, putting that up there, I think would be useful. And by the way, I was saying the same thing to Doris in term of, like, the digital twitting workshops things. 
But the. But, you know, Robert's, you know, shown the way a little bit on this. Like he's gone out, he's done these things, he's done, like, whatever, five or six weeks of them, and now business is rolling in the door, which and yes, I've. 
I've referred a bit of business to him too, but like the people are using that sort of validate. Yeah, you care about thing I care about. And then able to take, a step up, you know, with that. Particularly if they can see the clear path to what you're talking about to being able to make money. This is where like, you can use a strategy, but then it's got to go kind of directly into like, okay, how does this affect tactics, how's affect copy, how does it effect right? 
And then this will they get excited about these things. And then they completely failed to implement them. And that is exactly why they're looking to get more of your help. And I think there are multiple angles you could do with that, you know, which. Which would probably be compounding in terms of improving your credibility as a marketing expert. I actually I especially love the idea of you being a marketing expert focused on IR.

**Ellie Rofe | 27:38**
Yeah. I mean, the IR stuff is. Unfortunately, the area that is least interesting to me. Just 'cause it's.

**Ray | 27:46**
Then. Then there we go. We got to make sure it's we need to make sure that it is creating both wealth, you know, intellectual satisfaction and joy. 
Well. The. Have you heard of. Like the hedgehog principle from, Jim Collins's, you know, good to great. He talked about the fox. You know the story of the fox and the hedgehog, right? Fox knows many small things. Hedgehog knows one big thing. 
And the this like this from aesop I think but the idea but the he calls the Haychalk hypothesis is the intersection of three things.

**Ellie Rofe | 28:16**
One?

**Ray | 28:22**
Okay, first, what do you care about? This is why the your point about Ira really matters, because if you don't care about it can't be part of your intersection of greatness, right? 
Second is what? What's the market willing to pay for and pay you for and like if that because you know there can be things you really feel, you know, very passionate about that the market's not willing to pay you for snowboarding might be that for me.

**Ellie Rofe | 28:36**
No.

**Ray | 28:50**
And third, and this is important, what can you be world class at? I say that you're world class at today, but you can be world. That's why I talk about study sellingship, right? The being able to work your way up. 
Like when you have that kind of capability, that's where you can, you know, really do remarkable stuff. And if you care about it, then you have, you know, this emotional intrinsic motivation. If you're with the markets won't pay for it. Then you're getting. 
You know. Paid. You know, you're able to survive and you get the extrinsic motivation and the and then you're able to really achieve that kind of greatness and that that's the Intersect that I look for of what makes for a really good practice.

**Ellie Rofe | 29:21**
4.

**Ray | 29:32**
And a lot of, you know, I think kind of what we're doing here, always doing here is figuring out what's that AEROSAC for, you know, at least at this point in time.

**Ellie Rofe | 29:43**
It's something I struggled with for a while. 
So I need to work it out quite urgently.

**Ray | 29:50**
I think you can work it out in the market. This is not an internal thinking exercise. So, like, you have a friend who's like saying, hey, I think you're great at XI want to pay you for X. Let's listen to that, right? That that's certainly telling you about number two, right? Which is the market will pay for it. Are you really good at it? You're really good, and I suspect you are really good at it, and the and then there's a question like, okay, does it do you care about it? Does it bring you joy? 
And if it does? Well, then, you know, we. We. We've. We've. We've got something to work with here.

**Ellie Rofe | 30:23**
The Bran's strategy stuff, I absolutely love doing it. I am really good at it. It's hard to sell to the market. So this friend does it. Because she did it with me. On a very low rate because she'd been stuck for like two years of not being able to go forward.

**Ray | 30:43**
2.

**Ellie Rofe | 30:44**
And now that she's done it on a very low rate, she's like, I need your help because you're the person who helps me see clearly. You're the person who helps me understand the direction, the strategic direction of my business.

**Ray | 30:57**
No.

**Ellie Rofe | 30:58**
It's hard to sell into the market because it isn't marketing tactics, it's underlying strategy. As I said, it's the back end stuff, and to me, it's the only stuff that makes sense. If you don't know it, then you. You. You don't really make much progress because you sort of go aroundn in circles or chase tactics over strategy, and I'm terrible at doing it for myself. 
Yeah.

**Ray | 31:27**
Except the cobblers's children.

**Ellie Rofe | 31:28**
Exactly. But I mean, maybe I just haven't sold it hard enough. Maybe I should just try and push it consistently and, just work out that kink because it is the thing that, you know, work out AA wrapping, a packaging that does make sense to people. That does seem worth spending money on.

**Ray | 31:56**
Well, here's the other way of looking at it. If I might, the, my dad was a business strategy consultant in, like, the 1970 s and the, and he worked at this firm and he did strategy work with that firm. The firm never really got that big. 
You know, he was good at this. He was just sort of going out to growing markets. He was particularly doing international work. And that's sort of where, you know, I didn't get see much of him as a child because he was doing these, you know, three and four week trips out to Asia and what have you.

**Ellie Rofe | 32:25**
4.

**Ray | 32:27**
Making an impact. A little side note. He was a. He's past, but he was a literature Ph. D.

**Ellie Rofe | 32:37**
Wow.

**Ray | 32:38**
So he was and who decided that he really didn't like teaching. It was a whole thing to discover after getting literatubi and this so he went to he's or went into that line business, but as a result, he was doctor, you know Raymond Jack in his case and he was and because he could be introduced and that was actually a very big deal overseas, right?

**Ellie Rofe | 32:53**
One eight.

**Ray | 33:00**
So like in Asia, to be doctor as opposed to Mr for the rest of these consultants was actually source of advantage. But leaving that aside, no, the way the firm really made money was when it sold out to a bigger consulting firm. 
Because what they found was that strategy is the sharp end of the stick that gets you in the door with a client and then leads to bigger engagements.

**Ellie Rofe | 33:19**
Well, he.

**Ray | 33:25**
The way you make money with this is not through getting people to pay you top dollar for this. You'll there will be a few clients who can do that, but they'd tend to be larger clients, right? 
But most clients, you're, if you will, you're probably giving away the strategy part, right?

**Ellie Rofe | 33:37**
Yeah.

**Ray | 33:38**
Because the rest of the business that they really need help with because it opens the doors to the, you know, the execution part parts.

**Ellie Rofe | 33:45**
You. Now.

**Ray | 33:47**
This leads to an interesting point where like that could be something that you do directly or something you're referring right? This is you know, affiliate can work. This is a little bit like was thinking about like with the Dimitri stuff, right? The. You need, you know, through our insight. 
You know, you're spending a couple hours with me and you need X and I'm paying you and they're paying you for that, and then they need. Why? Okay. Can you either subcontract that or can you refer that and be, you know, paid a piece of that on the backend, which by the way, your client would be really excited about because they want you to be, you know, writing heard on this. Now you doing the work that you don't care about. 
It is you managing the relationship with a client who you care about. It is you making sure it's in line with the strategy. It has lots of potential to sort of be, a win type thing for you.

**Ellie Rofe | 34:33**
4.

**Ray | 34:33**
But I bring up partially because strategy in particular is intellectually very satisfying. 
But you know, the willingness to pay just isn't quite there. So the big consulting firm in this case, the thing was Deloitte, that bought his little firm. He was an associate at the firm, the, Delight was super excited to get these, you know, strategy consultants in and then send them out.

**Ellie Rofe | 34:52**
1?

**Ray | 34:59**
They're not making big money on the strategy folks, at least not directly. What they're doing is. Is a door opener.

**Ellie Rofe | 35:05**
Yeah.

**Ray | 35:06**
So looking at that correctly can help you. So, like, well, I want to do the strategy, but I don't want to do the execution. But the problem is, people don't want to pay for strategy without execution. 
Okay. Well, you know. That's a solvable problem. Right. Like, one, give them what they want to pay for, right? To do the part that you find exciting. And three, be the bridge. Right? Because really, if what you're doing is strategy work, and that is giving you a positive relationship with a client, then you much easier for them to buy the strategy work because you just don't charge for it. Or, you know, it's like a couple of hours, right? 
And then as opposed to being some really big piece of work and you know, okay, now they have needs.

**Ellie Rofe | 35:42**
Yeah. H.

**Ray | 35:46**
Great. You have built a trust relationship at that point that you can be turning into, you know, sales of products or services that they really want toy from you because they trust you in.

**Ellie Rofe | 35:57**
Yeah.

**Ray | 35:59**
And that creates a win. It's a win for the client because they get what they want, which is, you know, the ability to have that trust they give. It's say. And they know what they need now and like. Okay, that's great. We know what to do. How do we do that? Now? Can you help us with that? 
It's like I know exactly who can help you with that.

**Ellie Rofe | 36:17**
Yeah. Yeah.

**Ray | 36:18**
And it's a win for like the people who you're working with who are just executing now for the client. Sure. They if they do really good work, they develop their own relationship with the client. They can cut you out, but not a problem because you create a big win for the client. You get to move on to the next thing. This is like nothing. 
But you know, you don't need to be making sure you keep on getting your piece of that engagement. It's about the relationships in the market you're having. They're going to create the real value.

**Ellie Rofe | 36:44**
Yeah.

**Ray | 36:44**
I should just say it releases you from the idea that I need to sell this specific thing for money.

**Ellie Rofe | 36:50**
Hey, yeah.

**Ray | 36:51**
Because you can be selling it for knowledge, reputation in addition to a bit of money. Don't give things away for free. But like the. Yeah, but that creates more than just the dollar that's in front of you and then. 
Okay, now what do I need to do in order to build out that business? Well, I need not only chickens, I need some foxes. And just the relationships. And then now that's great. You could talk to other smart marketing people and like, hey, you really know what you're doing. 
And you're doing that tactical stuff. That's great. Actually, I've got a client over here, and then they love hearing that.

**Ellie Rofe | 37:23**
Yeah. Okay.

**Ray | 37:26**
I can totally see you doing that. Like, you can go be credible, you can be strategic, you can be doing these workshops, you can be doing, you know, maybe they go, well, we need some of the strategy. Sure, let's talk about that. 
Well, we really need someone who can help execute. Okay, well, look, I know a few people on those lines. What I would propose doing is I can do a little bit of a you know, an audit check in with you. 
And like this is how much it costs, which is not going to be large compared to what they would otherwise do. And then, you know, and then we can talk about like what kind of strategy, what kind of approach makes sense.

**Ellie Rofe | 37:55**
Eight yeah, okay, it does.

**Ray | 37:55**
And if you like, I have some trusted vendors who I work with.

**Ellie Rofe | 38:03**
I mean, it feels instinctively a much better and sort of ecosystem for me to be sitting within in terms of the in terms of creating an engine, I think a repeatable engine. 
Okay, yes.

**Ray | 38:22**
In a repeatable engine, that leaves you better off on all three axes with knowledge, reputation and wealth after each turn, right? You want it to be something that creates money for you don't want to give everything away. I don't think you to. 
I think you can do something where it's cheap for them and good for you. And like, that's that that's an easy one, that you know more at the ends, giving you access to secrets. And that's building up your reputation on, like, both sides. 
And when you see yourself as being not at, like one you. You are a vendor, and then they are a client. But instead you are a bridge between supply and demand. You' now fing your true purpose as a marketer.

**Ellie Rofe | 39:06**
Yes. Okay, lovely. That sounds good to me.

**Ray | 39:12**
Or at least for turning over your head in your feverish dreams.

**Ellie Rofe | 39:16**
Yeah, exactly. That too. Okay, I think I have hit the boundary of my brain now in.

**Ray | 39:28**
Okay, yeah, the let me know if I think I sent you a county link before in our correspondence if I can be helpful like in sort of helping you land and do maximally well with like this you know this brand strategy SLA digital twitting thing. I'd be. I'd be very glad to. We don't need to be doing that right now. I was sort of thinking about probably one of our topics. 
But, you know. And the. And we'll obviously we'll talk in on Tuesday. But, like, if there's anything that sort of comes to mind that you think I can be more helpful with, I would. I would wish to do so. 
I mean, your success is my success, right?

**Ellie Rofe | 40:11**
Yes, yeah, absolutely, thank you. Yes, great.

**Ray | 40:18**
I will leave you to it then. I hope you get better. With great rapidity.

**Ellie Rofe | 40:23**
I will be thank you very much. Have a lovely weekend. Cheers to you.

**Ray | 40:27**
And you.

